# -*- coding: utf-8 -*-
"""Match an episode title to TMDb's (season, episode) list, strictly.

Rules follow Nightshift's episode-name matcher: Roman numerals (I, II, III...) must match exactly, other words
may differ by one character, leading 'the/a/an' is ignored. A match is accepted only when exactly one episode fits,
or when several fit and exactly one of them is in the season the source named. Otherwise there is no match."""
import json
import re
import urllib.parse
import urllib.request

API = 'https://api.themoviedb.org/3'
def _to_roman(n):
    vals = [(10, 'x'), (9, 'ix'), (5, 'v'), (4, 'iv'), (1, 'i')]
    out = ''
    for v, s in vals:
        while n >= v:
            out += s
            n -= v
    return out


_ROMAN = frozenset(_to_roman(n) for n in range(1, 40))


def _norm_tokens(text):
    words = re.sub(r'[^a-z0-9]+', ' ', (text or '').lower()).split()
    while words and words[0] in ('the', 'a', 'an') and len(words) > 1:
        words = words[1:]
    return words


def _distance(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _token_match(a, b):
    if a in _ROMAN or b in _ROMAN:
        return a == b                       # Roman numerals: exact only
    if a == b:
        return True
    if min(len(a), len(b)) < 4:
        return False                        # short words: exact only
    return _distance(a, b) <= 1


def names_match(a, b):
    ta, tb = _norm_tokens(a), _norm_tokens(b)
    if not ta or not tb or len(ta) != len(tb):
        return False
    return all(_token_match(x, y) for x, y in zip(ta, tb))


def match_episode(title, episodes, source_season=None):
    """episodes: [{'season': int, 'number': int, 'name': str}]. Returns one of them, or None."""
    hits = [e for e in episodes if e.get('name') and names_match(title, e['name'])]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1 and source_season is not None:
        same = [h for h in hits if h.get('season') == source_season]
        if len(same) == 1:
            return same[0]
    return None


def _get(path, key, **params):
    params['api_key'] = key
    params.setdefault('language', 'en-US')
    url = '%s%s?%s' % (API, path, urllib.parse.urlencode(params))
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'Accept': 'application/json'}),
                                    timeout=20) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception:
        return None


def tmdb_episodes(key, tmdb_id):
    """Every episode of a TMDb show, specials included, in two requests (up to 20 seasons per request).
    Each row: season, number, name, air_date, tmdb episode id. [] when unavailable."""
    if not key or not tmdb_id:
        return []
    show = _get('/tv/%s' % int(tmdb_id), key)
    if not isinstance(show, dict):
        return []
    nums = sorted({int(s['season_number']) for s in show.get('seasons') or [] if s.get('season_number') is not None})
    out = []
    for i in range(0, len(nums), 20):
        chunk = nums[i:i + 20]
        data = _get('/tv/%s' % int(tmdb_id), key, append_to_response=','.join('season/%d' % n for n in chunk))
        if not isinstance(data, dict):
            continue
        for n in chunk:
            for e in (data.get('season/%d' % n) or {}).get('episodes') or []:
                if e.get('episode_number') is None:
                    continue
                out.append({'season': e.get('season_number', n), 'number': e.get('episode_number'),
                            'name': e.get('name'), 'air_date': e.get('air_date'), 'id': e.get('id')})
    return out


def resolve(title, tmdb_id, source_season, key, cache):
    """(season, number) in TMDb numbering for an episode title, or None. cache is a dict shared by one run."""
    if tmdb_id not in cache:
        cache[tmdb_id] = tmdb_episodes(key, tmdb_id)
    hit = match_episode(title, cache[tmdb_id], source_season)
    return (hit['season'], hit['number']) if hit else None


def tmdb_bundle(key, tmdb_id, get=None):
    """The saved TMDb output: the show object plus one 'season/N' block per season (season/0 included), made with
    append_to_response (up to 20 seasons per request). get is injected for tests; defaults to the TMDb API."""
    get = get or _get
    show = get('/tv/%d' % int(tmdb_id), key)
    if not isinstance(show, dict):
        return None
    out = dict(show)
    nums = sorted({int(s['season_number']) for s in show.get('seasons') or [] if s.get('season_number') is not None})
    for i in range(0, len(nums), 20):
        chunk = nums[i:i + 20]
        data = get('/tv/%d' % int(tmdb_id), key, append_to_response=','.join('season/%d' % n for n in chunk))
        for n in chunk:
            if isinstance(data, dict) and data.get('season/%d' % n) is not None:
                out['season/%d' % n] = data['season/%d' % n]
    return out
