# -*- coding: utf-8 -*-
"""Device sign-in without blocking Kodi. The plugin stores the code in a window property;
the service polls the provider and shows progress in a non-modal notice."""
import json
import threading
import time

import xbmcgui

import fullscreen

PROP = 'watchvault.login'
LABELS = {'mdblist': 'MDBList', 'trakt': 'Trakt', 'simkl': 'Simkl', 'punchplay': 'PunchPlay'}
DEFAULT_VERIFY = {'mdblist': 'https://mdblist.com/oauth/device/', 'trakt': 'https://trakt.tv/activate',
                  'simkl': 'https://simkl.com/pin', 'punchplay': 'https://punchplay.tv'}
RESULT_SECONDS = 5


def _win():
    return xbmcgui.Window(10000)


def _load():
    raw = _win().getProperty(PROP)
    return json.loads(raw) if raw else None


def _save(st):
    _win().setProperty(PROP, json.dumps(st))


def _clear():
    _win().clearProperty(PROP)


def start_login(provider, start):
    """Called by the plugin after the provider's device-start request."""
    if not isinstance(start, dict) or not start.get('ok'):
        err = (start or {}).get('error') or (start or {}).get('status') or 'unknown error'
        st = {'provider': provider, 'kind': 'error', 'error': str(err)[:300],
              'shown': False, 'expires_at': time.time() + 60}
    else:
        verify = (start.get('verification_uri_complete') or start.get('verification_uri')
                  or start.get('verification_url') or DEFAULT_VERIFY[provider])
        st = {'provider': provider, 'kind': 'device', 'device_code': start.get('device_code'),
              'user_code': start.get('user_code') or '', 'verify': verify,
              'expires_at': time.time() + int(start.get('expires_in') or 300),
              'interval': max(3, int(start.get('interval') or 5)), 'next_at': 0, 'shown': False}
    _save(st)


def _waiting_text(st):
    return ('Open %s\nand enter code:  %s\n\nWaiting for approval...\nPress Back to hide.'
            % (st['verify'], st['user_code']))


def _finish(heading, text):
    _clear()
    fullscreen.show_notice(heading, text)
    t = threading.Timer(RESULT_SECONDS, fullscreen.close_notice)
    t.daemon = True
    t.start()


def request_notice(provider, heading, text):
    """Plugin asks the service to show a result notice (non-blocking)."""
    _save({'provider': provider, 'kind': 'notice', 'heading': heading, 'text': text})


def step():
    """Run once a second from the service. Never blocks for long."""
    st = _load()
    if not st:
        return
    label = LABELS.get(st.get('provider'), 'Sign-in')
    heading = label + ' sign-in'
    if st.get('kind') == 'notice':
        return _finish(st.get('heading') or heading, st.get('text') or '')
    if st.get('kind') == 'error':
        return _finish(heading, 'Could not start sign-in:\n' + st.get('error', 'unknown error'))
    now = time.time()
    if now > st['expires_at']:
        return _finish(heading, 'The code expired. Start sign-in again.')
    if not st.get('shown'):
        if not fullscreen.close_modal_settings():
            return  # a dialog is still open; try again next tick
        fullscreen.show_notice(heading, _waiting_text(st))
        st['shown'] = True
        _save(st)
        return
    if now < st['next_at']:
        return
    import provider_sync
    poll_fn = getattr(provider_sync, st['provider'] + '_device_poll')
    try:
        poll = poll_fn(st['device_code'])
    except Exception as e:
        return _finish(heading, '%s\n%s' % (label, e))
    if poll.get('ok'):
        name = poll.get('username') or ''
        return _finish(heading, ('%s logged in as %s' % (label, name)) if name else (label + ' logged in'))
    err = poll.get('error') or {}
    code = err.get('error') if isinstance(err, dict) else None
    if code in ('access_denied', 'expired_token'):
        return _finish(heading, 'Sign-in was cancelled or expired. Start it again.')
    if code == 'slow_down':
        st['interval'] += 5
    st['next_at'] = now + st['interval']
    _save(st)
