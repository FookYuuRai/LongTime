# -*- coding: utf-8 -*-
"""Season ids.

TVDB  extended series (GET /series/{id}/extended): data.seasons[] = {id, number, type.type, name}. Each season has
      its own TVDB id. Episode records do NOT carry a season id; a live episode gets its season by seriesId +
      seasonNumber against this list (order type 'official' is the one episodes are numbered in).
TMDb  show (GET /tv/{id}): seasons[] = {id, season_number, name, episode_count}. Numeric season id per season.

Routing to a store row (anime rows are separate titles of one TVDB series): a TVDB season N belongs to the row whose
Kometa tvdb_season is N (tvdb_id = series). If exactly one row matches, the season is stored on that row.
Season 0 (specials, movies by offset) has several rows and is not routed automatically.
"""


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def parse_tvdb_extended(obj):
    data = obj.get('data', obj) if isinstance(obj, dict) else {}
    rows = []
    for s in data.get('seasons') or []:
        number = _int(s.get('number'))
        if number is None:
            continue
        rows.append({'number': number, 'order_type': (s.get('type') or {}).get('type') or 'official',
                     'tvdb_season_id': _int(s.get('id')), 'name': s.get('name')})
    return {'provider': 'tvdb', 'series_id': _int(data.get('id')), 'seasons': rows}


def parse_tmdb_show(obj):
    rows = []
    for s in obj.get('seasons') or []:
        number = _int(s.get('season_number'))
        if number is None:
            continue
        rows.append({'number': number, 'order_type': 'official', 'tmdb_season_id': _int(s.get('id')),
                     'name': s.get('name')})
    return {'provider': 'tmdb', 'show_tmdb_id': _int(obj.get('id')), 'seasons': rows}


def _write_season(con, show_id, row, source):
    con.execute('INSERT INTO season(show_id, number, order_type, tvdb_season_id, tmdb_season_id, name, sources) '
                'VALUES(?,?,?,?,?,?,?) ON CONFLICT(show_id, number, order_type) DO UPDATE SET '
                'tvdb_season_id=COALESCE(season.tvdb_season_id, excluded.tvdb_season_id), '
                'tmdb_season_id=COALESCE(season.tmdb_season_id, excluded.tmdb_season_id), '
                'name=COALESCE(season.name, excluded.name)',
                (show_id, row['number'], row['order_type'], row.get('tvdb_season_id'), row.get('tmdb_season_id'),
                 row.get('name'), source))
    return con.execute('SELECT id FROM season WHERE show_id=? AND number=? AND order_type=?',
                       (show_id, row['number'], row['order_type'])).fetchone()[0]


def route_tvdb(con, parsed):
    """Store each official TVDB season on the anime row that owns it (Kometa tvdb_season). Returns a report."""
    series_id = parsed['series_id']
    report = {'routed': [], 'ambiguous': [], 'no_row': []}
    for row in parsed['seasons']:
        if row['order_type'] != 'official' or row['number'] == 0:
            continue
        owners = con.execute('SELECT id FROM media WHERE kind IN ("show","movie") AND tvdb_id=? AND tvdb_season=? '
                             'ORDER BY id', (series_id, row['number'])).fetchall()
        if len(owners) == 1:
            season_row = _write_season(con, owners[0][0], row, 'tvdb')
            report['routed'].append({'season': row['number'], 'tvdb_season_id': row['tvdb_season_id'],
                                     'show_id': owners[0][0], 'season_row': season_row})
        elif owners and _offsets_split(con, owners):
            # one TVDB season spans several anime rows; Kometa's episode offsets say which episodes each owns
            for (show_id,) in owners:
                _write_season(con, show_id, row, 'tvdb')
            report.setdefault('split', []).append({'season': row['number'], 'tvdb_season_id': row['tvdb_season_id'],
                                                   'rows': [o[0] for o in owners]})
        elif owners:
            report['ambiguous'].append({'season': row['number'], 'rows': [o[0] for o in owners]})
        else:
            report['no_row'].append({'season': row['number'], 'tvdb_season_id': row['tvdb_season_id']})
    return report


def _offsets_split(con, owners):
    offsets = []
    for (show_id,) in owners:
        off = con.execute('SELECT tvdb_epoffset FROM media WHERE id=?', (show_id,)).fetchone()[0]
        if off is None:
            return False
        offsets.append(off)
    return len(set(offsets)) == len(offsets)


def route_tmdb(con, parsed):
    """TMDb show seasons go to the show row with that TMDb id (one row per show)."""
    rows = con.execute('SELECT id FROM media WHERE kind="show" AND tmdb_id=?', (parsed['show_tmdb_id'],)).fetchall()
    if len(rows) != 1:
        return {'routed': 0, 'show_rows': len(rows)}
    n = 0
    for row in parsed['seasons']:
        if row['number'] == 0:
            continue
        _write_season(con, rows[0][0], row, 'tmdb')
        n += 1
    return {'routed': n, 'show_rows': 1}


def resolve_live(con, series_id, season_number=None, season_id=None, episode_id=None, episode_number=None):
    """A live TVDB record (seriesId, seasonNumber or season id, episode number and/or episode id) -> store show,
    season and episode rows. A season shared by several rows is split by episode number: the row with the largest
    Kometa offset below the episode number owns it."""
    if season_id is not None:
        rows = con.execute('SELECT s.show_id, s.id, s.number, m.tvdb_epoffset FROM season s JOIN media m ON m.id=s.show_id '
                           'WHERE s.tvdb_season_id=?', (season_id,)).fetchall()
    else:
        rows = con.execute('SELECT s.show_id, s.id, s.number, m.tvdb_epoffset FROM season s JOIN media m ON m.id=s.show_id '
                           'WHERE m.tvdb_id=? AND s.number=? AND s.order_type="official"',
                           (series_id, season_number)).fetchall()
    if len(rows) > 1:
        if episode_number is None:
            return None
        below = [r for r in rows if r[3] is not None and r[3] < episode_number]
        if not below:
            return None
        rows = [max(below, key=lambda r: r[3])]
    row = rows[0] if rows else None
    if row is None:
        return None
    out = {'show_id': row[0], 'season_row': row[1], 'season': row[2], 'episode_id': None}
    if episode_id is not None:
        ep = con.execute('SELECT id FROM media WHERE kind="episode" AND tvdb_id=? AND show_id=?',
                         (episode_id, row[0])).fetchone()
        out['episode_id'] = ep[0] if ep else None
    return out
