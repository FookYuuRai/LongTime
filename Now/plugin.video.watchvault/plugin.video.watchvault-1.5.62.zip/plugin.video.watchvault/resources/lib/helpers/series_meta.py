# -*- coding: utf-8 -*-
"""Extended series data -> unified show row: ids, names and the useful series fields.

Ids: remoteIds with sourceName 'IMDB' -> imdb_id, 'TheMovieDB.com' -> tmdb_id; the TVDB series id is the series.
  Every remote id (fan sites, social accounts, ...) is kept in extra_ids so it can be looked up too.
Meta (JSON on the show row): genres, status, first/last/next aired, networks, air days and time, runtime, score,
  country, season types, default season type, order randomized. Artworks, characters, companies, lists, tags,
  trailers and translations are not stored (large, not needed for matching or next-episode lookups).
"""
import json
import re

_SOURCE_NAMESPACE = {'imdb': 'imdb_id', 'themoviedb.com': 'tmdb_id'}


def _slug(text):
    return re.sub(r'[^a-z0-9]+', '_', (text or '').lower()).strip('_')


def from_extended(data):
    """Return {'show': record for unified.upsert, 'meta': dict}. data is the extended series object (data)."""
    if isinstance(data, dict) and isinstance(data.get('languages'), dict):
        # a full bundle: the English block carries the series fields
        block = data['languages'].get('eng') or next(iter(data['languages'].values()), {})
        data = block.get('data') or {}
    data = data.get('data', data) if isinstance(data, dict) else {}
    series_id = data.get('id')
    show = {'kind': 'show', 'tvdb_id': int(series_id) if series_id is not None else None,
            'title': data.get('name'), 'year': int(str(data.get('year'))[:4]) if data.get('year') else None,
            'extra': {}}
    for rid in data.get('remoteIds') or []:
        source, value = (rid.get('sourceName') or ''), rid.get('id')
        if not value:
            continue
        key = _SOURCE_NAMESPACE.get(source.lower())
        if key == 'imdb_id':
            show['imdb_id'] = str(value)
        elif key == 'tmdb_id':
            try:
                show['tmdb_id'] = int(str(value))
            except ValueError:
                pass
        else:
            show['extra'][_slug(source) or 'remote'] = str(value)
    names = lambda items: [i.get('name') for i in items or [] if isinstance(i, dict) and i.get('name')]
    meta = {
        'genres': names(data.get('genres')),
        'status': (data.get('status') or {}).get('name'),
        'first_aired': data.get('firstAired'),
        'last_aired': data.get('lastAired'),
        'next_aired': data.get('nextAired'),
        'original_network': (data.get('originalNetwork') or {}).get('name'),
        'latest_network': (data.get('latestNetwork') or {}).get('name'),
        'airs_days': data.get('airsDays'),
        'airs_time': data.get('airsTime'),
        'average_runtime': data.get('averageRuntime'),
        'score': data.get('score'),
        'original_country': data.get('originalCountry'),
        'season_types': [t.get('type') for t in data.get('seasonTypes') or [] if isinstance(t, dict)],
        'default_season_type': (data.get('defaultSeasonType') or None),
        'order_randomized': data.get('isOrderRandomized'),
    }
    meta = {k: v for k, v in meta.items() if v not in (None, '', [])}
    if meta:
        show['meta'] = json.dumps(meta, ensure_ascii=False, sort_keys=True)
    return {'show': show, 'meta': meta}


def ingest(con, data, source='tvdb'):
    """Upsert the series as a series row (kind series) and attach its seasons and movies as children, linking by any shared id (tvdb, imdb, tmdb, extra remote ids).
    Returns the show row id."""
    import unified
    parsed = from_extended(data)
    rec = dict(parsed['show'])
    meta = rec.pop('meta', None)
    rec = {k: v for k, v in rec.items() if v not in (None, '')}
    rec['kind'] = 'series'
    sid = unified.upsert(con, 'series', rec, source, link='any')
    if meta:
        cur = con.execute('SELECT meta FROM media WHERE id=?', (sid,)).fetchone()
        if cur and not cur[0]:
            con.execute('UPDATE media SET meta=? WHERE id=?', (meta, sid))
    unified.attach_to_series(con, sid)
    return sid
