# -*- coding: utf-8 -*-
"""Build the unified database from the downloaded offline and Kometa files.

Writes the store file only through the helpers below; the store is one file (watchvault.db). A failed build keeps the
previous database. Returns counts per source."""
import os
import sqlite3

import unified
from helpers import kometa as kometa_helper
from helpers import offline as offline_helper


def rebuild(target_path, offline_path=None, kometa_path=None, edits_path=None, previous_path=None):
    tmp = target_path + '.tmp'
    if os.path.exists(tmp):
        os.remove(tmp)
    con = sqlite3.connect(tmp)
    counts = {'offline': 0, 'kometa': 0}
    try:
        con.execute('PRAGMA journal_mode=OFF')
        unified.ensure(con)
        if offline_path and os.path.exists(offline_path):
            for rec in offline_helper.records(offline_path):
                unified.upsert(con, rec['kind'], rec, 'offline')
                counts['offline'] += 1
        if kometa_path and os.path.exists(kometa_path):
            for rec in kometa_helper.records(kometa_path, edits_path if edits_path and os.path.exists(edits_path) else None):
                unified.upsert(con, rec['kind'], rec, 'kometa')
                counts['kometa'] += 1
        if previous_path and os.path.exists(previous_path):
            counts['carried'] = carry_over(previous_path, con)
        con.commit()
    except Exception:
        con.close()
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    con.close()
    os.replace(tmp, target_path)
    return counts


CARRY_SOURCES = ('tvdb', 'tmdb', 'mdblist', 'nightwatch')


def carry_over(previous_path, con):
    """Re-add rows from the previous store that came from series files or provider exports. Anime rows
    from offline and Kometa are rebuilt from their downloads, so they are not carried over. Returns the row count."""
    old = sqlite3.connect(previous_path)
    try:
        names = [d[0] for d in old.execute('SELECT * FROM media LIMIT 0').description]
        rows = [dict(zip(names, r)) for r in old.execute('SELECT * FROM media').fetchall()]
    finally:
        old.close()
    keep = [r for r in rows if any(src in (r.get('sources') or '') for src in CARRY_SOURCES)]
    id_map = {}
    moved = 0
    for r in sorted((r for r in keep if r['kind'] != 'episode'), key=lambda r: r['id']):
        rec = {k: r.get(k) for k in unified.FIELDS if r.get(k) is not None}
        rec['extra'] = unified.json.loads(r.get('extra_ids') or '{}')
        srcs = [x for x in (r.get('sources') or '').split(',') if x in CARRY_SOURCES] or ['carried']
        for src in srcs:
            new_id = unified.upsert(con, r['kind'], rec, src)
        id_map[r['id']] = new_id
        moved += 1
    for r in keep:
        if r['kind'] != 'episode' or r.get('show_id') not in id_map:
            continue
        rec = {k: r.get(k) for k in unified.FIELDS if r.get(k) is not None}
        rec['extra'] = unified.json.loads(r.get('extra_ids') or '{}')
        rec.update({k: r.get(k) for k in unified.EXTRA_COLS if r.get(k) is not None})
        rec['season'], rec['number'], rec['numbering'] = r.get('season'), r.get('number'), r.get('numbering')
        src = [x for x in (r.get('sources') or '').split(',') if x in CARRY_SOURCES] or ['carried']
        unified.upsert(con, 'episode', rec, src[0], show_id=id_map[r['show_id']])
        moved += 1
    return moved


def merge_into(target_path, offline_path=None, kometa_path=None, edits_path=None):
    """Add offline + Kometa records into the store (watchvault.db), or create it.
    Never deletes existing rows. Only fills empty fields via unified.upsert merge rules.
    Returns counts of records processed from each source (not net new rows)."""
    import os
    exists = os.path.exists(target_path)
    con = sqlite3.connect(target_path)
    counts = {'offline': 0, 'kometa': 0, 'created': not exists}
    try:
        unified.ensure(con)
        if offline_path and os.path.exists(offline_path):
            for rec in offline_helper.records(offline_path):
                unified.upsert(con, rec['kind'], rec, 'offline')
                counts['offline'] += 1
        if kometa_path and os.path.exists(kometa_path):
            for rec in kometa_helper.records(
                    kometa_path,
                    edits_path if edits_path and os.path.exists(edits_path) else None):
                unified.upsert(con, rec['kind'], rec, 'kometa')
                counts['kometa'] += 1
        con.commit()
    except Exception:
        con.close()
        raise
    con.close()
    # attach the new anime rows to their series (rows added before a series arrive are joined here)
    try:
        import sqlite3 as _sq
        with _sq.connect(target_path) as _c:
            unified.ensure(_c)
            counts['attached'] = unified.attach_orphans(_c)
            counts['folded'] = unified.consolidate_anime(_c)
            _c.commit()
    except Exception:
        pass
    return counts


def copy_store(source_path, con):
    """Copy every row of another media store into con (shows first, then movies, then episodes)."""
    import sqlite3
    src = sqlite3.connect(source_path)
    try:
        names = [d[0] for d in src.execute('SELECT * FROM media LIMIT 0').description]
        rows = [dict(zip(names, r)) for r in src.execute('SELECT * FROM media ORDER BY id').fetchall()]
    finally:
        src.close()
    id_map, moved = {}, 0
    for r in rows:
        if r['kind'] == 'episode':
            continue
        rec = {k: r.get(k) for k in unified.FIELDS if r.get(k) is not None}
        rec['extra'] = unified.json.loads(r.get('extra_ids') or '{}')
        for src_name in (r.get('sources') or 'migrated').split(','):
            new_id = unified.upsert(con, r['kind'], rec, src_name or 'migrated', link='any')
        id_map[r['id']] = new_id
        moved += 1
    for r in rows:
        if r['kind'] != 'episode' or r.get('show_id') not in id_map:
            continue
        rec = {k: r.get(k) for k in unified.FIELDS if r.get(k) is not None}
        rec['extra'] = unified.json.loads(r.get('extra_ids') or '{}')
        rec.update({k: r.get(k) for k in unified.EXTRA_COLS if r.get(k) is not None})
        rec['season'], rec['number'], rec['numbering'] = r.get('season'), r.get('number'), r.get('numbering')
        unified.upsert(con, 'episode', rec, (r.get('sources') or 'migrated').split(',')[0],
                       show_id=id_map[r['show_id']])
        moved += 1
    return moved
