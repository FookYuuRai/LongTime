# -*- coding: utf-8 -*-
"""MDBList -> unified catalog rows + watch records. Two input modes:

  export : the site export file (sections movies, episodes, seasons, watch_history; flat fields such as tmdb_id,
           show_tmdb_id, season_number|season_num, episode_number|episode_num, last_watched_at|watched_at).
  sync   : the nested response of the device-flow sync call (/sync/watched shape: movies[], shows[], episodes[]
           whose items carry movie / show / episode objects with ids).

Both modes return {'catalog': [...], 'watches': [...], 'mode': ..., 'truncated': bool}.
  catalog records follow helpers/CONTRACT.md (kind show|movie|episode, tmdb_id, season, number, ...).
  watch records use the same keys as the import pipeline (kind, title, year, tmdb_id, imdb_id, tvdb_id, season,
  episode, ep_tmdb, ep_tvdb, numbering, played_at)."""
import json


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _iso(value):
    """MDBList dates -> 'YYYY-MM-DDTHH:MM:SSZ' (UTC). None when unreadable."""
    if not value:
        return None
    text = str(value)[:19]
    try:
        from datetime import datetime
        return datetime.strptime(text, '%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%dT%H:%M:%SZ')
    except ValueError:
        return None


def _section_items(text, name):
    """Complete objects of one array in a possibly truncated JSON export. Returns (items, complete)."""
    marker = '"%s":[' % name
    at = text.find(marker)
    if at < 0:
        return [], True
    dec = json.JSONDecoder()
    i = at + len(marker)
    items = []
    while True:
        while i < len(text) and text[i] in ', \n\r\t':
            i += 1
        if i >= len(text):
            return items, False
        if text[i] == ']':
            return items, True
        if text[i] != '{':
            return items, False
        try:
            obj, i = dec.raw_decode(text, i)
        except ValueError:
            return items, False
        items.append(obj)


def parse_export_text(text):
    catalog, watches, truncated = [], [], False
    seen_ep = set()  # (show_tmdb, season, number)
    for section in ('movies', 'episodes', 'seasons', 'watch_history'):
        items, complete = _section_items(text, section)
        truncated = truncated or not complete
        if section == 'movies':
            for m in items:
                _export_movie(m, catalog, watches)
        elif section == 'episodes':
            for e in items:
                key = _export_episode(e, catalog, watches)
                if key:
                    seen_ep.add(key)
        elif section == 'watch_history':
            for row in items:
                key = _export_watch_history(row, catalog, watches)
                if key:
                    seen_ep.add(key)
    return {'mode': 'export', 'catalog': catalog, 'watches': watches, 'truncated': truncated}


def _export_movie(m, catalog, watches):
    tmdb = _int(m.get('tmdb_id'))
    if tmdb is None:
        return
    played = _iso(m.get('last_watched_at') or m.get('watched_at'))
    if m.get('mediatype') == 'movie' or m.get('item_type') == 'movie':
        catalog.append({'kind': 'movie', 'tmdb_id': tmdb})
        if played:
            watches.append({'kind': 'movie', 'tmdb_id': tmdb, 'played_at': played, 'numbering': 'tmdb'})
    else:
        catalog.append({'kind': 'show', 'tmdb_id': tmdb})
        if played:
            watches.append({'kind': 'show', 'tmdb_id': tmdb, 'played_at': played,
                            'watched_episode_count': _int(m.get('watched_episode_count'))})


def _season_num(obj):
    return _int(obj.get('season_number') if obj.get('season_number') is not None else obj.get('season_num'))


def _episode_num(obj):
    return _int(obj.get('episode_number') if obj.get('episode_number') is not None else obj.get('episode_num'))


def _export_episode(e, catalog, watches):
    show = _int(e.get('show_tmdb_id') or e.get('tmdb_id'))
    season, number = _season_num(e), _episode_num(e)
    ep_tmdb = _int(e.get('episode_tmdb_id'))
    if show is None or season is None or number is None:
        return None
    if season < 0 or number < 0:
        return None
    catalog.append({'kind': 'show', 'tmdb_id': show})
    catalog.append({'kind': 'episode', 'show_tmdb_id': show, 'season': season, 'number': number,
                    'tmdb_id': ep_tmdb, 'numbering': 'tmdb',
                    'extra': {'season_tmdb': _int(e.get('season_tmdb_id'))}})
    played = _iso(e.get('last_watched_at') or e.get('watched_at'))
    if played:
        watches.append({'kind': 'episode', 'tmdb_id': show, 'season': season, 'episode': number,
                        'ep_tmdb': ep_tmdb, 'numbering': 'tmdb', 'played_at': played})
    return (show, season, number)


def _export_watch_history(row, catalog, watches):
    """Flat watch_history rows from the site export (season_num/episode_num naming)."""
    item_type = (row.get('item_type') or row.get('mediatype') or '').lower()
    if item_type == 'movie':
        tmdb = _int(row.get('tmdb_id'))
        if tmdb is None:
            return None
        catalog.append({'kind': 'movie', 'tmdb_id': tmdb})
        played = _iso(row.get('watched_at') or row.get('last_watched_at'))
        if played:
            watches.append({'kind': 'movie', 'tmdb_id': tmdb, 'played_at': played, 'numbering': 'tmdb'})
        return None
    # episode
    show = _int(row.get('show_tmdb_id') or row.get('tmdb_id'))
    season, number = _season_num(row), _episode_num(row)
    ep_tmdb = _int(row.get('episode_tmdb_id'))
    if show is None or season is None or number is None or season < 0 or number < 0:
        return None
    catalog.append({'kind': 'show', 'tmdb_id': show})
    catalog.append({'kind': 'episode', 'show_tmdb_id': show, 'season': season, 'number': number,
                    'tmdb_id': ep_tmdb, 'numbering': 'tmdb'})
    played = _iso(row.get('watched_at') or row.get('last_watched_at'))
    if played:
        watches.append({'kind': 'episode', 'tmdb_id': show, 'season': season, 'episode': number,
                        'ep_tmdb': ep_tmdb, 'numbering': 'tmdb', 'played_at': played})
    return (show, season, number)


def parse_sync_obj(obj):
    catalog, watches = [], []
    for item in obj.get('movies') or []:
        m = item.get('movie') or {}
        ids = m.get('ids') or {}
        tmdb = _int(ids.get('tmdb'))
        if tmdb is None:
            continue
        catalog.append({'kind': 'movie', 'tmdb_id': tmdb, 'title': m.get('title'), 'year': _int(m.get('year')),
                        'imdb_id': ids.get('imdb')})
        watches.append({'kind': 'movie', 'title': m.get('title'), 'year': _int(m.get('year')), 'tmdb_id': tmdb,
                        'imdb_id': ids.get('imdb'), 'played_at': _iso(item.get('last_watched_at'))})
    for item in obj.get('shows') or []:
        s = item.get('show') or {}
        ids = s.get('ids') or {}
        tmdb = _int(ids.get('tmdb'))
        if tmdb is not None:
            catalog.append({'kind': 'show', 'tmdb_id': tmdb, 'title': s.get('title'), 'year': _int(s.get('year')),
                            'imdb_id': ids.get('imdb'), 'tvdb_id': _int(ids.get('tvdb'))})
    for item in obj.get('episodes') or []:
        ep = item.get('episode') or {}
        show = ep.get('show') or {}
        sids = show.get('ids') or {}
        eids = ep.get('ids') or {}
        show_tmdb = _int(sids.get('tmdb'))
        season, number = _int(ep.get('season')), _int(ep.get('number'))
        if show_tmdb is None or season is None or number is None:
            continue
        catalog.append({'kind': 'episode', 'show_tmdb_id': show_tmdb, 'season': season, 'number': number,
                        'tmdb_id': _int(eids.get('tmdb')), 'tvdb_id': _int(eids.get('tvdb')),
                        'numbering': 'tmdb', 'title': ep.get('title')})
        watches.append({'kind': 'episode', 'title': show.get('title'), 'year': _int(show.get('year')),
                        'tmdb_id': show_tmdb, 'tvdb_id': _int(sids.get('tvdb')), 'imdb_id': sids.get('imdb'),
                        'season': season, 'episode': number, 'ep_tmdb': _int(eids.get('tmdb')),
                        'ep_tvdb': _int(eids.get('tvdb')), 'numbering': 'tmdb',
                        'played_at': _iso(item.get('last_watched_at') or item.get('watched_at'))})
    return {'mode': 'sync', 'catalog': catalog, 'watches': watches, 'truncated': False}


def parse_export_file(path):
    with open(path, encoding='utf-8') as handle:
        return parse_export_text(handle.read())


def parse(source, mode=None):
    """source: path to an export file, or a dict (sync response). mode: 'export' | 'sync' | None (detect)."""
    if isinstance(source, dict):
        if mode == 'export' or (mode is None and 'schema_version' in source):
            return parse_export_text(json.dumps(source))
        return parse_sync_obj(source)
    with open(source, encoding='utf-8') as handle:
        text = handle.read()
    if mode == 'sync' or (mode is None and text.lstrip().startswith('{"movies"') and '"episode":{' in text[:4000]):
        return parse_sync_obj(json.loads(text))
    return parse_export_text(text)



def format_outgoing(payload):
    """unified.watched_for_providers() shape -> MDBList /sync/watched body (tvdb/tmdb/imdb)."""
    shows, movies = [], []
    for s in payload.get('shows') or []:
        ids = s.get('ids') or {}
        body = {'ids': {}}
        if ids.get('tvdb'):
            body['ids']['tvdb'] = ids['tvdb']
        if ids.get('tmdb'):
            body['ids']['tmdb'] = ids['tmdb']
        if ids.get('imdb'):
            body['ids']['imdb'] = ids['imdb']
        if not body['ids']:
            continue
        seasons = []
        for season in s.get('seasons') or []:
            seasons.append({
                'number': season.get('number'),
                'episodes': [{'number': e.get('number')} for e in season.get('episodes') or []],
            })
        body['seasons'] = seasons
        shows.append(body)
    for m in payload.get('movies') or []:
        ids = m.get('ids') or {}
        body = {'ids': {}}
        if ids.get('tvdb'):
            body['ids']['tvdb'] = ids['tvdb']
        if ids.get('tmdb'):
            body['ids']['tmdb'] = ids['tmdb']
        if ids.get('imdb'):
            body['ids']['imdb'] = ids['imdb']
        if body['ids']:
            movies.append(body)
    return {'shows': shows, 'movies': movies}
