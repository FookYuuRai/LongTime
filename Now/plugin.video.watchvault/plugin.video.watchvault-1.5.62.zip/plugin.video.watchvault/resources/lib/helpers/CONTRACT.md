# WatchVault single database contract

## One file
`special://profile/addon_data/plugin.video.watchvault/watchvault.db`

## Tables
- **media** — only catalog + watch state (show | movie | episode). All providers and Nightshift parse into this shape.
- **changes** — append-only event log for incremental pull/push (seq cursor).
- **sources** — registered video add-ons and their ack_seq.
- Legacy `shows` / `episodes` / `movies` may still be written for transition; **reads prefer media**.

## media columns
kind, show_id, season, number, title, title_en, year,
anidb_id, anilist_id, mal_id, tvdb_id, tmdb_id, imdb_id,
tvdb_season, tvdb_epoffset, numbering, extra_ids, sources,
ep_tvdb_season, ep_tvdb_number, ep_tmdb_season, ep_tmdb_number, ep_type, air_date,
watched, play_count, last_watched, runtime, remaining, play_source

## Helper modules (`resources/lib/helpers/`)
| module | inbound | outbound |
|--------|---------|----------|
| offline.py | cedya77 JSONL → media | — |
| kometa.py | Anime-IDs → media | — |
| nightshift.py | announce/mark → media | media → tvdb/tmdb mark payload |
| mdblist.py | export/sync → catalog+watches | watched_for_providers → /sync/watched body |
| trakt.py | history → catalog+watches | watched_for_providers → history objects |
| simkl.py | history → catalog+watches | same |
| punchplay.py | — | watched_for_providers → tvdb:/tmdb:/mal: paths |
| series.py | TVDB/TMDb series files → media episodes | — |
| build.py | merge_into offline+kometa (add/fill only) | — |

## ID preference
TVDB first, then TMDb, then anime ids (anilist/mal/anidb), then IMDb.
Merge never overwrites a filled field; empty fields are filled; sources are appended.

## Title merge
- `title`: original / romaji / native. Filled once; English overwrites only when existing title is CJK-heavy.
- `title_en`: English display name. Nightshift/TMDb/TVDB/providers may fill or overwrite when the value looks English.
- Romaji (offline) + later English mark → title stays romaji, title_en becomes English.

## Reference format (canonical)
Every id is written `namespace:value`: `anilist:1412`, `mal:1412`, `anidb:421`, `tvdb:71863`, `tmdb:82684`,
`imdb:tt0089943`, `kitsu:1286`, `anime_planet:...`, `anisearch:...`. Logs, lookups and this document use this form.
- `unified.format_ref(ns, value)` and `unified.parse_ref(text)` convert between the parts and the text.
- `unified.find(con, 'tvdb:71863')` returns every row with that TVDB id (shows, movies and episodes of that id).
- A bare number (`1412`) is searched in every namespace and each result lists which id types it matched.
- `unified.describe(con, ref)` lists every matched row with its title, year, kind and all of its refs, for checking by hand.
- Linking (`link='any'`) matches the same ids; the `ns:value` form only names them.

## Season table (`season`)
| column | meaning |
|---|---|
| show_id | the store row the season belongs to |
| number | season number in `order_type` |
| order_type | `official` (what episodes are numbered in), `dvd`, `absolute`, `regional` (TVDB); `official` for TMDb |
| tvdb_season_id | TVDB season id (extended series `seasons[].id`) |
| tmdb_season_id | TMDb season id (show `seasons[].id`) |

Routing (`helpers/seasons.py`): a TVDB official season N goes to the one row with tvdb_id = series and Kometa
tvdb_season = N. Season 0 and seasons with several rows are reported, not routed.
Live resolution: `resolve_live(con, series_id, season_number=N)` or `resolve_live(con, series_id, season_id=...)`
returns the show row, the season row and (with an episode id) the episode row.
Episode records do not carry season ids; the season comes from seriesId + seasonNumber against the series' seasons list.

## Episode order and partial live data
- `helpers/order.py`: `aired_order(con, show_id)` sorts by (air_date, season, number), specials excluded;
  `next_episode(con, episode_id, order='aired'|'official')`; `compare_orders(con, show_id)` reports where the two agree.
- `helpers/enrich.py`: `enrich_partial(con, partial, fetch_extended)` finds the TVDB series id from the partial data
  (or from a TMDb / IMDb / AniList / MAL id that the store links to exactly one TVDB id), makes one extended series call
  through `fetch_extended`, routes the seasons, and resolves the season and episode rows.
- The extended series response carries seasons with ids. Episodes come from the separate episodes call.
