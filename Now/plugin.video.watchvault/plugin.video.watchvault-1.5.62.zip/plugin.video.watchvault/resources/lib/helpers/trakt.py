# -*- coding: utf-8 -*-
"""Trakt history / sync payloads -> catalog + watches (same shape as helpers.mdblist)."""
import json


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def _iso(value):
    if not value:
        return None
    try:
        from datetime import datetime
        return datetime.strptime(str(value)[:19], '%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%dT%H:%M:%SZ')
    except Exception:
        return None


def parse_history_list(rows):
    """Trakt /sync/history or /users/me/history style list of rows."""
    catalog, watches = [], []
    for row in rows or []:
        played = _iso(row.get('watched_at'))
        typ = row.get('type')
        if typ == 'movie' or row.get('movie'):
            m = row.get('movie') or {}
            ids = m.get('ids') or {}
            tmdb = _int(ids.get('tmdb'))
            if tmdb is None:
                continue
            catalog.append({'kind': 'movie', 'tmdb_id': tmdb, 'title': m.get('title'),
                            'year': _int(m.get('year')), 'imdb_id': ids.get('imdb'),
                            'tvdb_id': _int(ids.get('tvdb'))})
            watches.append({'kind': 'movie', 'title': m.get('title'), 'year': _int(m.get('year')),
                            'tmdb_id': tmdb, 'imdb_id': ids.get('imdb'), 'tvdb_id': _int(ids.get('tvdb')),
                            'played_at': played})
        elif typ == 'episode' or row.get('episode'):
            s = row.get('show') or {}
            sids = s.get('ids') or {}
            e = row.get('episode') or {}
            eids = e.get('ids') or {}
            show_tmdb = _int(sids.get('tmdb'))
            season, number = _int(e.get('season')), _int(e.get('number'))
            if show_tmdb is None or season is None or number is None:
                continue
            catalog.append({'kind': 'show', 'tmdb_id': show_tmdb, 'title': s.get('title'),
                            'year': _int(s.get('year')), 'tvdb_id': _int(sids.get('tvdb')),
                            'imdb_id': sids.get('imdb')})
            catalog.append({'kind': 'episode', 'show_tmdb_id': show_tmdb, 'season': season, 'number': number,
                            'tmdb_id': _int(eids.get('tmdb')), 'tvdb_id': _int(eids.get('tvdb')),
                            'numbering': 'tmdb', 'title': e.get('title')})
            watches.append({'kind': 'episode', 'title': s.get('title'), 'year': _int(s.get('year')),
                            'tmdb_id': show_tmdb, 'tvdb_id': _int(sids.get('tvdb')), 'imdb_id': sids.get('imdb'),
                            'season': season, 'episode': number, 'ep_tmdb': _int(eids.get('tmdb')),
                            'ep_tvdb': _int(eids.get('tvdb')), 'numbering': 'tmdb', 'played_at': played})
    return {'mode': 'history', 'catalog': catalog, 'watches': watches, 'truncated': False}


def parse(source):
    if isinstance(source, list):
        return parse_history_list(source)
    if isinstance(source, dict) and isinstance(source.get('history'), list):
        return parse_history_list(source['history'])
    path = source
    with open(path, encoding='utf-8') as handle:
        data = json.load(handle)
    if isinstance(data, list):
        return parse_history_list(data)
    return parse_history_list(data.get('history') or data.get('watched') or [])


def format_outgoing(payload):
    """unified.watched_for_providers -> list of history-style objects for push helpers."""
    out = []
    for s in payload.get('shows') or []:
        ids = s.get('ids') or {}
        for season in s.get('seasons') or []:
            for e in season.get('episodes') or []:
                out.append({
                    'type': 'episode',
                    'show': {'title': s.get('title'), 'year': s.get('year'), 'ids': ids},
                    'episode': {'season': season.get('number'), 'number': e.get('number'), 'ids': {}},
                })
    for m in payload.get('movies') or []:
        out.append({'type': 'movie', 'movie': {'title': m.get('title'), 'year': m.get('year'),
                                              'ids': m.get('ids') or {}}})
    return out
