# -*- coding: utf-8 -*-
"""cedya77 anime-offline-database (JSONL, or the full JSON document) -> unified records.

Input: one anime per line (the first line may be a metadata object without 'sources'), or {"data": [...]}.
Output: records as described in CONTRACT.md. A record is kept when it has at least one id."""
import json
import re

# source URL -> id namespace. Namespaces without a media column go to extra_ids.
_PATTERNS = [
    ('anidb', re.compile(r'anidb\.net/(?:anime|a)/?(\d+)', re.I)),
    ('anilist', re.compile(r'anilist\.co/anime/(\d+)', re.I)),
    ('mal', re.compile(r'myanimelist\.net/anime/(\d+)', re.I)),
    ('kitsu', re.compile(r'kitsu\.(?:app|io)/anime/(\d+)', re.I)),
    ('anime_planet', re.compile(r'anime-planet\.com/anime/([^/?#]+)', re.I)),
    ('anisearch', re.compile(r'anisearch\.(?:com|de)/anime/(\d+)', re.I)),
    ('tmdb_show', re.compile(r'themoviedb\.org/(?:tv|tvshow)/(\d+)', re.I)),
    ('tmdb_movie', re.compile(r'themoviedb\.org/movie/(\d+)', re.I)),
    ('tvdb', re.compile(r'thetvdb\.com/(?:series|dereferrer/series)/(\d+)', re.I)),
    ('imdb', re.compile(r'imdb\.com/title/(tt\d+)', re.I)),
]


def source_ids(sources):
    """{namespace: value} from the source URLs; the first URL per namespace wins."""
    found = {}
    for raw in sources or []:
        text = str(raw)
        for key, pattern in _PATTERNS:
            m = pattern.search(text)
            if m and key not in found:
                found[key] = m.group(1)
    return found


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def iter_items(path):
    """Anime objects from the JSONL release or the full JSON document. Non-anime lines are skipped."""
    with open(path, encoding='utf-8') as handle:
        first = handle.readline()
        if not first.strip():
            return
        head = json.loads(first)
        if isinstance(head, dict) and isinstance(head.get('data'), list):
            for item in head['data']:
                if isinstance(item, dict) and item.get('sources'):
                    yield item
            return
        if isinstance(head, dict) and head.get('sources'):
            yield head
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
            except ValueError:
                continue
            if isinstance(item, dict) and item.get('sources'):
                yield item


def to_record(item):
    """One offline anime -> record, or None when it has no id at all."""
    ids = source_ids(item.get('sources'))
    if not ids:
        return None
    kind = 'movie' if str(item.get('type') or '').upper() == 'MOVIE' else 'show'
    season = item.get('animeSeason') if isinstance(item.get('animeSeason'), dict) else {}
    tmdb = ids.get('tmdb_movie') if kind == 'movie' else ids.get('tmdb_show')
    rec = {
        'kind': kind,
        'title': item.get('title'),
        'year': _int(season.get('year')),
        'anidb_id': _int(ids.get('anidb')),
        'anilist_id': _int(ids.get('anilist')),
        'mal_id': _int(ids.get('mal')),
        'tvdb_id': _int(ids.get('tvdb')),
        'tmdb_id': _int(tmdb),
        'imdb_id': ids.get('imdb'),
        'extra': {k: v for k, v in ids.items()
                  if k in ('kitsu', 'anime_planet', 'anisearch') or
                  (k == 'tmdb_show' and kind == 'movie') or (k == 'tmdb_movie' and kind == 'show')},
    }
    rec['extra'] = {k: v for k, v in rec['extra'].items() if v not in (None, '')}
    return rec


def records(path):
    for item in iter_items(path):
        rec = to_record(item)
        if rec is not None:
            yield rec
