# -*- coding: utf-8 -*-
"""Nightshift / Nightwatch <-> unified media records.

Incoming (Nightshift announce / mark): ids + title -> unified record (+ optional watch).
Outgoing (Nightshift needs mark UI / next-up): unified row -> tvdb/tmdb payload.
"""
from __future__ import annotations


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def parse_mark(info):
    """Nightshift mark/announce dict -> {'catalog': [...], 'watch': rec|None}.

    info keys: title, year, season, episode, tvdb_id, tmdb_id, imdb_id, anilist_id, mal_id,
    episode_tvdb_id, episode_tmdb_id, watched, played_at, source, runtime, remaining.
    """
    info = info or {}
    season, episode = _int(info.get('season')), _int(info.get('episode'))
    is_ep = season is not None and episode is not None
    catalog = []
    if is_ep:
        show = {
            'kind': 'show',
            'title': info.get('title'),
            'year': _int(info.get('year')),
            'tvdb_id': _int(info.get('tvdb_id')),
            'tmdb_id': _int(info.get('tmdb_id')),
            'imdb_id': info.get('imdb_id'),
            'anilist_id': _int(info.get('anilist_id')),
            'mal_id': _int(info.get('mal_id')),
        }
        catalog.append(show)
        ep = {
            'kind': 'episode',
            'title': info.get('episode_title') or info.get('title'),
            'season': season,
            'number': episode,
            'tvdb_id': _int(info.get('episode_tvdb_id')),
            'tmdb_id': _int(info.get('episode_tmdb_id')),
            'numbering': 'tvdb' if info.get('episode_tvdb_id') or info.get('tvdb_id') else 'tmdb',
            'show_tvdb_id': _int(info.get('tvdb_id')),
            'show_tmdb_id': _int(info.get('tmdb_id')),
        }
        catalog.append(ep)
        watch = dict(ep)
        watch['watched'] = bool(info.get('watched', True))
        watch['played_at'] = info.get('played_at')
        watch['runtime'] = info.get('runtime')
        watch['remaining'] = info.get('remaining')
        watch['play_source'] = info.get('source') or 'nightshift'
        return {'catalog': catalog, 'watch': watch, 'kind': 'episode'}
    movie = {
        'kind': 'movie',
        'title': info.get('title'),
        'year': _int(info.get('year')),
        'tvdb_id': _int(info.get('tvdb_id')),
        'tmdb_id': _int(info.get('tmdb_id')),
        'imdb_id': info.get('imdb_id'),
        'anilist_id': _int(info.get('anilist_id')),
        'mal_id': _int(info.get('mal_id')),
    }
    catalog.append(movie)
    watch = dict(movie)
    watch['watched'] = bool(info.get('watched', True))
    watch['played_at'] = info.get('played_at')
    watch['runtime'] = info.get('runtime')
    watch['remaining'] = info.get('remaining')
    watch['play_source'] = info.get('source') or 'nightshift'
    return {'catalog': catalog, 'watch': watch, 'kind': 'movie'}


def format_for_nightshift(row, show=None):
    """Unified media row -> dict Nightshift can use to mark/query (tvdb first, tmdb fallback)."""
    if not row:
        return None
    if row.get('kind') == 'episode':
        show = show or {}
        return {
            'title': show.get('title') or row.get('title'),
            'year': show.get('year'),
            'season': row.get('season'),
            'episode': row.get('number'),
            'tvdb_id': show.get('tvdb_id'),
            'tmdb_id': show.get('tmdb_id'),
            'imdb_id': show.get('imdb_id'),
            'anilist_id': show.get('anilist_id'),
            'mal_id': show.get('mal_id'),
            'episode_tvdb_id': row.get('tvdb_id') if row.get('numbering') == 'tvdb' else None,
            'episode_tmdb_id': row.get('tmdb_id'),
            'watched': bool(row.get('watched')),
            'last_watched': row.get('last_watched'),
            'runtime': row.get('runtime'),
            'remaining': row.get('remaining'),
        }
    return {
        'title': row.get('title'),
        'year': row.get('year'),
        'tvdb_id': row.get('tvdb_id'),
        'tmdb_id': row.get('tmdb_id'),
        'imdb_id': row.get('imdb_id'),
        'anilist_id': row.get('anilist_id'),
        'mal_id': row.get('mal_id'),
        'watched': bool(row.get('watched')),
        'last_watched': row.get('last_watched'),
        'runtime': row.get('runtime'),
        'remaining': row.get('remaining'),
    }


def apply_to_unified(con, parsed, source='nightshift'):
    """Write parse_mark() result into unified media (+ watch). Returns episode/movie row id."""
    import unified
    show_id = None
    watch = parsed.get('watch')
    for rec in parsed.get('catalog') or []:
        kind = rec['kind']
        if kind == 'show':
            show_id = unified.upsert(con, 'show', rec, source, link='any')
        elif kind == 'episode':
            if show_id is None and (rec.get('show_tmdb_id') or rec.get('show_tvdb_id')):
                show_id = unified.upsert(con, 'show', {
                    'kind': 'show',
                    'tmdb_id': rec.get('show_tmdb_id'),
                    'tvdb_id': rec.get('show_tvdb_id'),
                    'title': rec.get('title'),
                }, source, link='any')
            if watch and watch.get('kind') == 'episode':
                return unified.set_watched(
                    con, 'episode', rec,
                    watched=watch.get('watched', True),
                    source=watch.get('play_source') or source,
                    played_at=watch.get('played_at'),
                    runtime=watch.get('runtime'),
                    remaining=watch.get('remaining'),
                    show_id=show_id,
                )
            return unified.upsert(con, 'episode', rec, source, show_id=show_id)
        elif kind == 'movie':
            if watch and watch.get('kind') == 'movie':
                return unified.set_watched(
                    con, 'movie', rec,
                    watched=watch.get('watched', True),
                    source=watch.get('play_source') or source,
                    played_at=watch.get('played_at'),
                    runtime=watch.get('runtime'),
                    remaining=watch.get('remaining'),
                )
            return unified.upsert(con, 'movie', rec, source)
    return show_id
