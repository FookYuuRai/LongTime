# -*- coding: utf-8 -*-
"""Simkl history / sync payloads -> catalog + watches."""
import json


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def _iso(value):
    if not value:
        return None
    try:
        from datetime import datetime
        return datetime.strptime(str(value)[:19], '%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%dT%H:%M:%SZ')
    except Exception:
        return None


def _ids(obj):
    ids = (obj or {}).get('ids') or {}
    return {
        'tmdb': _int(ids.get('tmdb')),
        'tvdb': _int(ids.get('tvdb') or ids.get('thetvdb')),
        'imdb': ids.get('imdb'),
        'mal': _int(ids.get('mal')),
        'anilist': _int(ids.get('anilist')),
    }


def parse_history_list(rows):
    catalog, watches = [], []
    for row in rows or []:
        played = _iso(row.get('last_watched_at') or row.get('watched_at') or row.get('date'))
        if row.get('movie') or row.get('type') == 'movie':
            m = row.get('movie') or row
            ids = _ids(m)
            if ids['tmdb'] is None and ids['mal'] is None:
                continue
            catalog.append({'kind': 'movie', 'tmdb_id': ids['tmdb'], 'title': m.get('title'),
                            'year': _int(m.get('year')), 'imdb_id': ids['imdb'], 'mal_id': ids['mal'],
                            'anilist_id': ids['anilist']})
            watches.append({'kind': 'movie', 'title': m.get('title'), 'year': _int(m.get('year')),
                            'tmdb_id': ids['tmdb'], 'imdb_id': ids['imdb'], 'mal_id': ids['mal'],
                            'anilist_id': ids['anilist'], 'played_at': played})
            continue
        show = row.get('show') or {}
        ep = row.get('episode') or {}
        sids = _ids(show)
        season = _int(ep.get('season') if ep.get('season') is not None else row.get('season'))
        number = _int(ep.get('number') if ep.get('number') is not None else
                      (ep.get('episode') if ep.get('episode') is not None else row.get('episode')))
        if sids['tmdb'] is None and sids['tvdb'] is None and sids['mal'] is None:
            continue
        if season is None or number is None:
            continue
        catalog.append({'kind': 'show', 'tmdb_id': sids['tmdb'], 'tvdb_id': sids['tvdb'],
                        'title': show.get('title'), 'year': _int(show.get('year')),
                        'imdb_id': sids['imdb'], 'mal_id': sids['mal'], 'anilist_id': sids['anilist']})
        catalog.append({'kind': 'episode', 'show_tmdb_id': sids['tmdb'], 'season': season, 'number': number,
                        'tmdb_id': _int((ep.get('ids') or {}).get('tmdb')),
                        'tvdb_id': _int((ep.get('ids') or {}).get('tvdb')), 'numbering': 'tmdb',
                        'title': ep.get('title')})
        watches.append({'kind': 'episode', 'title': show.get('title'), 'year': _int(show.get('year')),
                        'tmdb_id': sids['tmdb'], 'tvdb_id': sids['tvdb'], 'imdb_id': sids['imdb'],
                        'mal_id': sids['mal'], 'anilist_id': sids['anilist'],
                        'season': season, 'episode': number,
                        'ep_tmdb': _int((ep.get('ids') or {}).get('tmdb')),
                        'ep_tvdb': _int((ep.get('ids') or {}).get('tvdb')),
                        'numbering': 'tmdb', 'played_at': played})
    return {'mode': 'history', 'catalog': catalog, 'watches': watches, 'truncated': False}


def parse(source):
    if isinstance(source, list):
        return parse_history_list(source)
    if isinstance(source, dict):
        for key in ('history', 'watched', 'episodes', 'movies'):
            if isinstance(source.get(key), list):
                return parse_history_list(source[key])
        return parse_history_list([source])
    with open(source, encoding='utf-8') as handle:
        data = json.load(handle)
    return parse(data)


def format_outgoing(payload):
    """unified.watched_for_providers -> list of history-style objects for push helpers."""
    out = []
    for s in payload.get('shows') or []:
        ids = s.get('ids') or {}
        for season in s.get('seasons') or []:
            for e in season.get('episodes') or []:
                out.append({
                    'type': 'episode',
                    'show': {'title': s.get('title'), 'year': s.get('year'), 'ids': ids},
                    'episode': {'season': season.get('number'), 'number': e.get('number'), 'ids': {}},
                })
    for m in payload.get('movies') or []:
        out.append({'type': 'movie', 'movie': {'title': m.get('title'), 'year': m.get('year'),
                                              'ids': m.get('ids') or {}}})
    return out
