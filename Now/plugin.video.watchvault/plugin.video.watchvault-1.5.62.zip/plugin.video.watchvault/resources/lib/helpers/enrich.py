# -*- coding: utf-8 -*-
"""Partial live data -> full store data with one extended series call.

Incoming live data may carry only a title, a show id and an episode id. enrich_partial:
  1. finds the TVDB series id (from the given tvdb id, or from the store row for the given TMDb / other id);
  2. makes one extended-series request (injected as fetch_extended, so the caller owns the API and the key);
  3. routes the seasons (season ids, see helpers/seasons.py);
  4. returns what it resolved, including the episode row when an episode id was given.
The extended response carries the seasons (with ids) and show data. Episodes come from the paged episodes call,
which is separate; enrich_partial reports whether episode rows are present yet."""
import unified
from helpers import seasons as seasons_helper


def enrich_partial(con, partial, fetch_extended):
    unified.ensure(con)
    series_id = partial.get('tvdb_id')
    if series_id is None:
        ref = next(((k, v) for k, v in (('tmdb_id', partial.get('tmdb_id')), ('imdb_id', partial.get('imdb_id')),
                                          ('anilist_id', partial.get('anilist_id')), ('mal_id', partial.get('mal_id')))
                    if v not in (None, '')), None)
        if ref is None:
            return {'ok': False, 'error': 'need a tvdb id, or a tmdb / imdb / anilist / mal id to look it up'}
        ns = {'tmdb_id': 'tmdb', 'imdb_id': 'imdb', 'anilist_id': 'anilist', 'mal_id': 'mal'}[ref[0]]
        rows = unified.find(con, '%s:%s' % (ns, ref[1]))
        series_rows = [r for r in rows if r.get('tvdb_id')]
        if len(series_rows) != 1:
            return {'ok': False, 'error': 'no single tvdb id for %s:%s (%d rows)' % (ns, ref[1], len(series_rows))}
        series_id = series_rows[0]['tvdb_id']
    extended = fetch_extended(series_id)
    if not extended:
        return {'ok': False, 'error': 'extended series request failed for tvdb:%s' % series_id}
    parsed = seasons_helper.parse_tvdb_extended(extended)
    routed = seasons_helper.route_tvdb(con, parsed)
    resolved = seasons_helper.resolve_live(con, series_id,
                                           season_number=partial.get('season_number'),
                                           season_id=partial.get('season_id'),
                                           episode_id=partial.get('episode_id'))
    con.commit()
    return {'ok': True, 'series': 'tvdb:%s' % series_id, 'seasons_routed': len(routed['routed']),
            'seasons_ambiguous': len(routed['ambiguous']), 'seasons_without_row': len(routed['no_row']),
            'resolved': resolved}
