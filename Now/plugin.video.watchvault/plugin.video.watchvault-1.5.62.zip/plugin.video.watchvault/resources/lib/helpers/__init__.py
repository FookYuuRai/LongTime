"""Helpers turn each anime source into unified-store records (see CONTRACT.md)."""
