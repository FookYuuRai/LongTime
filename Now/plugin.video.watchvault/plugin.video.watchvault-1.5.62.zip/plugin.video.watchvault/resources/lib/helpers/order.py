# -*- coding: utf-8 -*-
"""Episode order for next-episode lookups.

Air date order: episodes of a show sorted by (air_date, season, number). Specials (season 0) are excluded from the
main sequence unless asked for. Works from the store's own air dates (TVDB episode 'aired', TMDb 'air_date').
Official order: (season, number) in the stored numbering (TVDB official when the row has it, else TMDb).
Next episode: the episode after the given one in the chosen order (None at the end)."""


def _sequence(con, show_id, order, include_specials):
    rows = con.execute(
        'SELECT id, season, number, air_date, ep_type FROM media WHERE kind="episode" AND show_id=?',
        (show_id,)).fetchall()
    items = [dict(id=r[0], season=r[1], number=r[2], air_date=r[3], ep_type=r[4]) for r in rows]
    if not include_specials:
        items = [i for i in items if (i['season'] or 0) != 0 and i['ep_type'] != 'special']
    if order == 'aired':
        if any(i['air_date'] is None for i in items):
            # episodes without an air date are placed after the dated ones, in official order
            items.sort(key=lambda i: (i['air_date'] is None, i['air_date'] or '', i['season'] or 0, i['number'] or 0))
        else:
            items.sort(key=lambda i: (i['air_date'], i['season'] or 0, i['number'] or 0))
    else:
        items.sort(key=lambda i: (i['season'] or 0, i['number'] or 0))
    return items


def aired_order(con, show_id, include_specials=False):
    """Episode row ids in air-date order."""
    return [i['id'] for i in _sequence(con, show_id, 'aired', include_specials)]


def next_episode(con, episode_id, order='aired', include_specials=False):
    """The episode after episode_id in the given order, or None. order: 'aired' | 'official'."""
    row = con.execute('SELECT show_id FROM media WHERE kind="episode" AND id=?', (episode_id,)).fetchone()
    if row is None:
        return None
    seq = _sequence(con, row[0], order, include_specials)
    ids = [i['id'] for i in seq]
    if episode_id not in ids:
        return None
    pos = ids.index(episode_id)
    return ids[pos + 1] if pos + 1 < len(ids) else None


def compare_orders(con, show_id):
    """How far air-date order and official order agree for a show. Returns counts for checking by hand."""
    aired = _sequence(con, show_id, 'aired', False)
    official = _sequence(con, show_id, 'official', False)
    pos = {i['id']: n for n, i in enumerate(official)}
    moved = sum(1 for n, i in enumerate(aired) if pos.get(i['id']) != n)
    return {'episodes': len(aired), 'same_position': len(aired) - moved, 'different_position': moved,
            'undated': sum(1 for i in aired if i['air_date'] is None)}
