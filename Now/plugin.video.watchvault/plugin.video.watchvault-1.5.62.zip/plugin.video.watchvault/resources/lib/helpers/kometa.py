# -*- coding: utf-8 -*-
"""Kometa Anime-IDs (anime_ids.json, keyed by AniDB id) + anime_id_edits.json -> unified records.

Edits win over the base file for the same AniDB key. A field with several values (e.g. "849,4382") keeps the first
as the column value and the rest in extra_ids as <field>_more."""
import json


def _values(value):
    if value is None:
        return []
    text = str(value)
    return [v.strip() for v in text.split(',') if v.strip()]


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def load(base_path, edits_path=None):
    with open(base_path, encoding='utf-8') as handle:
        base = json.load(handle)
    edits = {}
    if edits_path:
        try:
            with open(edits_path, encoding='utf-8') as handle:
                edits = json.load(handle)
        except (OSError, ValueError):
            edits = {}
    merged = {}
    for key, row in base.items():
        merged[str(key)] = dict(row or {})
    for key, row in edits.items():
        merged.setdefault(str(key), {}).update(row or {})
    return merged


def records(base_path, edits_path=None):
    for key, row in load(base_path, edits_path).items():
        anidb = _int(key)
        if anidb is None:
            continue
        extra = {}
        mal = _values(row.get('mal_id'))
        anilist = _values(row.get('anilist_id'))
        tvdb = _values(row.get('tvdb_id'))
        if len(mal) > 1:
            extra['mal_more'] = mal[1:]
        if len(anilist) > 1:
            extra['anilist_more'] = anilist[1:]
        if len(tvdb) > 1:
            extra['tvdb_more'] = tvdb[1:]
        rec = {
            'kind': 'show',
            'anidb_id': anidb,
            'tvdb_id': _int(tvdb[0]) if tvdb else None,
            'mal_id': _int(mal[0]) if mal else None,
            'anilist_id': _int(anilist[0]) if anilist else None,
            'imdb_id': row.get('imdb_id') or None,
            'tvdb_season': _int(row.get('tvdb_season')),
            'tvdb_epoffset': _int(row.get('tvdb_epoffset')),
            'extra': extra,
        }
        yield rec
