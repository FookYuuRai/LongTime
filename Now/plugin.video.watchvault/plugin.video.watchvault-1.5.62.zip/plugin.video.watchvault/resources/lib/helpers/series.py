# -*- coding: utf-8 -*-
"""Series-level files -> unified store, one import per provider.

TVDB file  (series with languages.{lang}.data.episodes): the show gets tvdb_id, name, year; each episode gets
           tvdb_id, ep_tvdb_season / ep_tvdb_number (official order), ep_type (episode | special | movie), air_date.
TMDb file  (show with season/N.episodes): the show gets tmdb_id, name, year; each episode gets tmdb_id,
           ep_tmdb_season / ep_tmdb_number, season / number (TMDb numbering), ep_type, air_date.

Linking: after an import, every episode of the show that has only one provider's id is matched to the other
provider's rows of the same show: same numbers first, then the strict episode name, then the air date.
Specials only match specials. A show from the other provider is linked by its name, only when that is unique.
"""
import json

import unified
import episode_match


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _ep_type(season, is_movie=False):
    if is_movie:
        return 'movie'
    return 'special' if season == 0 else 'episode'


def parse_tvdb(path_or_obj):
    data = path_or_obj if isinstance(path_or_obj, dict) else json.load(open(path_or_obj, encoding='utf-8'))
    langs = data.get('languages') or {}
    jpn = (langs.get('jpn') or {}).get('data') or {}
    eng = (langs.get('eng') or {}).get('data') or {}
    base = jpn or eng
    series_id = _int(data.get('seriesId') or base.get('id'))
    # English title: the eng block's name when it differs, else the first English alias
    alias_en = next((a.get('name') for a in base.get('aliases') or [] if a.get('language') == 'eng'), None)
    title_en = (eng.get('name') if eng.get('name') and eng.get('name') != base.get('name') else None) or alias_en
    show = {'kind': 'show', 'tvdb_id': series_id, 'title': base.get('name'), 'title_en': title_en,
            'year': _int(base.get('year'))}
    episodes = []
    for e in (eng or base).get('episodes') or []:
        season = _int(e.get('seasonNumber'))
        number = _int(e.get('number'))
        if season is None or number is None:
            continue
        is_movie = bool(e.get('isMovie'))
        episodes.append({
            'kind': 'episode', 'show_tvdb_id': series_id, 'tvdb_id': _int(e.get('id')),
            'ep_tvdb_season': season, 'ep_tvdb_number': number,
            'season': season, 'number': number, 'numbering': 'tvdb_official',
            'title': e.get('name'), 'air_date': e.get('aired') or None,
            'ep_type': _ep_type(season, is_movie),
        })
    return {'provider': 'tvdb', 'show': show, 'episodes': episodes}


def parse_tmdb(path_or_obj):
    data = path_or_obj if isinstance(path_or_obj, dict) else json.load(open(path_or_obj, encoding='utf-8'))
    show_id = _int(data.get('id'))
    show = {'kind': 'show', 'tmdb_id': show_id, 'title': data.get('original_name') or data.get('name'),
            'title_en': data.get('name') if data.get('name') != data.get('original_name') else None,
            'year': _int((data.get('first_air_date') or '')[:4])}
    episodes = []
    for key, block in data.items():
        if not key.startswith('season/') or not isinstance(block, dict):
            continue
        for e in block.get('episodes') or []:
            season, number = _int(e.get('season_number')), _int(e.get('episode_number'))
            if season is None or number is None:
                continue
            episodes.append({
                'kind': 'episode', 'show_tmdb_id': show_id, 'tmdb_id': _int(e.get('id')),
                'ep_tmdb_season': season, 'ep_tmdb_number': number,
                'season': season, 'number': number, 'numbering': 'tmdb',
                'title': e.get('name'), 'air_date': e.get('air_date') or None,
                'ep_type': _ep_type(season),
            })
    return {'provider': 'tmdb', 'show': show, 'episodes': episodes}


_EP_COLS = ('ep_tvdb_season', 'ep_tvdb_number', 'ep_tmdb_season', 'ep_tmdb_number', 'ep_type', 'air_date')


def _show_row(con, show, source):
    keys = {k: show[k] for k in ('tvdb_id', 'tmdb_id') if show.get(k) is not None}
    rec = dict(keys, title=show.get('title'), title_en=show.get('title_en'), year=show.get('year'))
    if not keys:
        raise ValueError('series file has no id')
    return unified.upsert(con, 'show', rec, source, link='any')


def _link_other_provider_show(con, show_id, show, source):
    """Find another show row of the same series under the other provider, and merge the two by name."""
    if show.get('tvdb_id') and not show.get('tmdb_id'):
        other, col = 'tmdb_id', 'tmdb'
    elif show.get('tmdb_id') and not show.get('tvdb_id'):
        other, col = 'tvdb_id', 'tvdb'
    else:
        return None
    name = show.get('title')
    if not name:
        return None
    mine = 'tvdb_id' if other == 'tmdb_id' else 'tmdb_id'          # the id this import brings
    rows = con.execute('SELECT id FROM media WHERE kind="show" AND %s IS NULL AND %s IS NOT NULL AND id!=? '
                       'AND (title=? OR title_en=?)' % (mine, other), (show_id, name, name)).fetchall()
    if len(rows) != 1:
        return None   # no name match, or ambiguous: left unlinked
    return rows[0][0]


def _upsert_episode(con, show_id, ep, source):
    rec = {k: ep.get(k) for k in ('season', 'number', 'numbering', 'title', 'air_date', 'ep_type',
                                   'ep_tvdb_season', 'ep_tvdb_number', 'ep_tmdb_season', 'ep_tmdb_number')
           if ep.get(k) is not None}
    rec['tvdb_id'] = ep.get('tvdb_id')
    rec['tmdb_id'] = ep.get('tmdb_id')
    return unified.upsert(con, 'episode', rec, source, show_id=show_id)


def import_series(con, parsed):
    """Store one provider's parsed series. Returns counts and the link result."""
    unified.ensure(con)
    provider = parsed['provider']
    show = parsed['show']
    show_id = _show_row(con, show, provider)
    counts = {'episodes': 0}
    for ep in parsed['episodes']:
        if ep.get('tvdb_id') is None and ep.get('tmdb_id') is None:
            continue
        _upsert_episode(con, show_id, ep, provider)
        counts['episodes'] += 1
    linked_show = _link_other_provider_show(con, show_id, show, provider)
    if linked_show is not None:
        counts['show_linked'] = True
        show_id = _merge_shows(con, show_id, linked_show)
    counts['episodes_linked'] = link_episodes(con, show_id)
    return counts


def _merge_shows(con, keep_id, other_id):
    """Move the other show row's episodes onto keep_id and merge its ids into keep_id."""
    cols = [c for c in ('tvdb_id', 'tmdb_id', 'title', 'title_en', 'year') ]
    for c in cols:
        val = con.execute('SELECT %s FROM media WHERE id=?' % c, (other_id,)).fetchone()[0]
        if val is not None:
            con.execute('UPDATE media SET %s=COALESCE(%s, ?) WHERE id=?' % (c, c), (val, keep_id))
    con.execute('UPDATE media SET show_id=? WHERE show_id=?', (keep_id, other_id))
    con.execute('DELETE FROM media WHERE id=?', (other_id,))
    return keep_id


def link_episodes(con, show_id):
    """Pair episodes that have only one provider's id with the other provider's episodes of the same show.
    Order: same season and number, then strict name, then air date. Returns the number of pairs made."""
    tv_only = [dict(zip(['id', 'season', 'number', 'title', 'air_date', 'ep_type', 'tvdb_id'], r)) for r in
               con.execute('SELECT id, season, number, title, air_date, ep_type, tvdb_id FROM media '
                           'WHERE kind="episode" AND show_id=? AND tvdb_id IS NOT NULL AND tmdb_id IS NULL', (show_id,))]
    tm_only = [dict(zip(['id', 'season', 'number', 'title', 'air_date', 'ep_type', 'tmdb_id'], r)) for r in
               con.execute('SELECT id, season, number, title, air_date, ep_type, tmdb_id FROM media '
                           'WHERE kind="episode" AND show_id=? AND tmdb_id IS NOT NULL AND tvdb_id IS NULL', (show_id,))]
    pairs = 0
    taken = set()
    for t in tv_only:
        # season 0 pairs with season 0 (specials and season-0 movies alike); regular seasons never do
        pool = [x for x in tm_only if x['id'] not in taken and (x['season'] == 0) == (t['season'] == 0)]
        hit = next((x for x in pool if x['season'] == t['season'] and x['number'] == t['number']), None)
        if hit is None and t['title']:
            hits = [x for x in pool if x['title'] and episode_match.names_match(t['title'], x['title'])]
            hit = hits[0] if len(hits) == 1 else None
        if hit is None and t['air_date']:
            hits = [x for x in pool if x['air_date'] == t['air_date']]
            hit = hits[0] if len(hits) == 1 else None
        if hit is None:
            continue
        taken.add(hit['id'])
        # merge the TMDb-only row into the TVDB row: the TVDB row gets the TMDb id and TMDb numbering
        tmdb_row = con.execute('SELECT tmdb_id, sources, ep_tmdb_season, ep_tmdb_number FROM media WHERE id=?',
                               (hit['id'],)).fetchone()
        tv_row = con.execute('SELECT sources FROM media WHERE id=?', (t['id'],)).fetchone()
        srcs = sorted(set(filter(None, ((tv_row[0] or '') + ',' + (tmdb_row[1] or '')).split(','))))
        con.execute('UPDATE media SET tmdb_id=?, ep_tmdb_season=?, ep_tmdb_number=?, season=?, number=?, '
                    'numbering=?, sources=? WHERE id=?',
                    (tmdb_row[0], hit['season'], hit['number'], hit['season'], hit['number'], 'tmdb',
                     ','.join(srcs), t['id']))
        con.execute('DELETE FROM media WHERE id=?', (hit['id'],))
        pairs += 1
    return pairs


def run_import(con, provider, path):
    parsed = parse_tvdb(path) if provider == 'tvdb' else parse_tmdb(path)
    counts = import_series(con, parsed)
    con.commit()
    return counts
