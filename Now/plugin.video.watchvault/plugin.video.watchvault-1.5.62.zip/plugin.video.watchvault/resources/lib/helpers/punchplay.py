# -*- coding: utf-8 -*-
"""PunchPlay: history in (GET /api/platform/v1/me/history items) and out (sync payloads).

Inbound items are flat: type (movie|episode), tmdbId, title, year, watchedAt, showTmdbId, season, episode,
sourceSeason, sourceEpisode (TMDb numbering), episodeTitle, showSourceId, sourceId, mediaSource.
Returns {'mode', 'catalog', 'watches'} in the same shape as helpers/trakt.py."""
import json


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def _iso(value):
    if not value:
        return None
    from datetime import datetime
    try:
        return datetime.strptime(str(value)[:19], '%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%dT%H:%M:%SZ')
    except ValueError:
        return None


def parse_history_list(rows):
    catalog, watches = [], []
    for row in rows or []:
        played = _iso(row.get('watchedAt'))
        if row.get('type') == 'movie':
            tmdb = _int(row.get('tmdbId'))
            if tmdb is None:
                continue
            catalog.append({'kind': 'movie', 'tmdb_id': tmdb, 'title': row.get('title'), 'year': _int(row.get('year'))})
            watches.append({'kind': 'movie', 'title': row.get('title'), 'year': _int(row.get('year')),
                            'tmdb_id': tmdb, 'played_at': played})
        elif row.get('type') == 'episode':
            show_tmdb = _int(row.get('showTmdbId'))
            season = _int(row.get('sourceSeason') if row.get('sourceSeason') is not None else row.get('season'))
            number = _int(row.get('sourceEpisode') if row.get('sourceEpisode') is not None else row.get('episode'))
            if show_tmdb is None or season is None or number is None:
                continue
            ep_tmdb = _int(row.get('tmdbId'))
            catalog.append({'kind': 'show', 'tmdb_id': show_tmdb, 'title': row.get('title'),
                            'year': _int(row.get('year'))})
            catalog.append({'kind': 'episode', 'show_tmdb_id': show_tmdb, 'season': season, 'number': number,
                            'tmdb_id': ep_tmdb, 'numbering': 'tmdb', 'title': row.get('episodeTitle')})
            watches.append({'kind': 'episode', 'title': row.get('title'), 'year': _int(row.get('year')),
                            'tmdb_id': show_tmdb, 'season': season, 'episode': number, 'ep_tmdb': ep_tmdb,
                            'numbering': 'tmdb', 'played_at': played})
    return {'mode': 'history', 'catalog': catalog, 'watches': watches, 'truncated': False}


def format_outgoing(payload):
    """Return list of {kind, path} for PunchPlay watch endpoints (tvdb preferred)."""
    items = []
    for s in payload.get('shows') or []:
        ids = s.get('ids') or {}
        if ids.get('tvdb'):
            root = 'tvdb:%s' % ids['tvdb']
        elif ids.get('tmdb'):
            root = 'tmdb:%s' % ids['tmdb']
        elif ids.get('mal'):
            root = 'mal:%s' % ids['mal']
        else:
            continue
        for season in s.get('seasons') or []:
            for e in season.get('episodes') or []:
                items.append({
                    'kind': 'episode',
                    'path': root,
                    'season': season.get('number'),
                    'number': e.get('number'),
                    'ids': ids,
                    'title': s.get('title'),
                })
    for m in payload.get('movies') or []:
        ids = m.get('ids') or {}
        if ids.get('tvdb'):
            path = 'tvdb:%s' % ids['tvdb']
        elif ids.get('tmdb'):
            path = 'tmdb:%s' % ids['tmdb']
        elif ids.get('mal'):
            path = 'mal:%s' % ids['mal']
        else:
            continue
        items.append({'kind': 'movie', 'path': path, 'ids': ids, 'title': m.get('title')})
    return items
