# -*- coding: utf-8 -*-
"""TVDB v4 episode bundles: one episode order (official by default, falls back to default when it is empty), paged,
with the show's original-language episode names attached as name_original.

Ported from tvdb_series_episodes.py (the CLI helper). Pure logic: the HTTP call is passed in as req(path, token=...)
so the module can be tested without network access.
"""

DEFAULT_ORDER = 'official'
FALLBACK_ORDER = 'default'
MAX_PAGES = 500


def _episode_pages(req, token, series_id, season_type, language):
    """All episode pages for one order and language. Returns (episodes, first page's data block)."""
    out, meta, page = [], None, 0
    while page < MAX_PAGES:
        res = req('/series/%d/episodes/%s/%s?page=%d' % (int(series_id), season_type, language, page), token=token)
        data = (res.get('data') if isinstance(res, dict) else None) or {}
        if meta is None:
            meta = data
        out.extend(data.get('episodes') or [])
        links = res.get('links') if isinstance(res, dict) else None
        if not links or not links.get('next'):
            break
        page += 1
    return out, (meta or {})


def tmdb_id_from_remote(remote_list):
    """TMDb id from a TVDB remoteIds list (sourceName TheMovieDB.com). None when absent."""
    for r in remote_list or []:
        src = (r.get('sourceName') or '').lower().replace(' ', '')
        if src in ('themoviedb.com', 'themoviedb'):
            try:
                return int(r.get('id'))
            except (TypeError, ValueError):
                return None
    return None


def fetch_series_tmdb_id(req, token, series_id):
    """GET /series/{id}/extended, then the TMDb id from its remoteIds. None when TVDB has none."""
    res = req('/series/%d/extended' % int(series_id), token=token)
    data = (res.get('data') if isinstance(res, dict) else None) or {}
    return tmdb_id_from_remote(data.get('remoteIds') or data.get('remote_ids'))


def attach_original(english, other):
    """Set name_original on each English episode, matched by season and number, else by episode id."""
    by_se = {(e.get('seasonNumber'), e.get('number')): e for e in other}
    by_id = {e.get('id'): e for e in other if e.get('id') is not None}
    for ep in english:
        match = by_se.get((ep.get('seasonNumber'), ep.get('number'))) or by_id.get(ep.get('id')) or {}
        ep['name_original'] = match.get('name') or None
    return english


def fetch_bundle(req, token, series_id, season_type=DEFAULT_ORDER, original_names=True):
    """Episodes for one show. Returns a dict: seasonType (the order actually used), originalLanguage, episodes
    (English, with name_original when available)."""
    used = season_type or DEFAULT_ORDER
    english, meta = _episode_pages(req, token, series_id, used, 'eng')
    if not english and used != FALLBACK_ORDER:
        used = FALLBACK_ORDER
        english, meta = _episode_pages(req, token, series_id, used, 'eng')
    orig_lang = (meta.get('originalLanguage') or '').strip().lower()
    tmdb_id = fetch_series_tmdb_id(req, token, series_id)
    if original_names and orig_lang and orig_lang not in ('eng', 'en'):
        other, _ = _episode_pages(req, token, series_id, used, orig_lang)
        attach_original(english, other)
    else:
        for ep in english:
            ep['name_original'] = None
    return {'seasonType': used, 'originalLanguage': orig_lang or None, 'tmdb_id': tmdb_id, 'episodes': english}


# ---- full series bundle, in the shape of the saved TVDB output (languages -> {status, requestedLanguage, data}) ----

def _series_extended(req, token, series_id):
    """GET /series/{id}/extended: series fields, seasons (with TVDB season ids), remoteIds, artworks, ..."""
    res = req('/series/%d/extended' % int(series_id), token=token)
    return dict((res.get('data') if isinstance(res, dict) else None) or {})


def fetch_extended_bundle(req, token, series_id, season_type=DEFAULT_ORDER, languages=None):
    """One output per series: seriesId, seasonType (order actually used), seasonTypeRequested, originalLanguage,
    and languages {lang: {status, requestedLanguage, data}}. data holds the series fields, the seasons list (with
    TVDB season ids) and that language's episode list (paged episodes endpoint). Default languages: eng, then the
    series' original language."""
    sid = int(series_id)
    series = _series_extended(req, token, sid)
    seasons = series.pop('episodes', None)           # episodes come from the paged call, per language
    orig = (series.get('originalLanguage') or '').strip().lower() or None
    langs = languages or [l for l in dict.fromkeys(['eng', orig]) if l]
    used = season_type or DEFAULT_ORDER
    episodes = {}
    for lang in langs:
        eps, _meta = _episode_pages(req, token, sid, used, lang)
        if not eps and lang == langs[0] and used != FALLBACK_ORDER:
            used = FALLBACK_ORDER
            eps, _meta = _episode_pages(req, token, sid, used, lang)
        episodes[lang] = eps
    blocks = {}
    for lang in langs:
        data = dict(series)
        data['episodes'] = episodes.get(lang) or []
        blocks[lang] = {'status': 'success' if data['episodes'] else 'empty', 'requestedLanguage': lang, 'data': data}
    return {'seriesId': sid, 'seasonType': used, 'seasonTypeRequested': season_type or DEFAULT_ORDER,
            'originalLanguage': orig, 'languages': blocks}
