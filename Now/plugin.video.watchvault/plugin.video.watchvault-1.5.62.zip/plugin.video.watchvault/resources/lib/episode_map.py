# -*- coding: utf-8 -*-
"""TVDB episode -> TMDb (season, episode) map, stored in WatchVault's database.

Built once per show, from one TVDB episode list and one TMDb episode list, then reused. Lookups use the TVDB
episode id only. Matching follows Nightshift's order mapping: same season and number first, then the episode name
(strict: Roman numerals exact, one character tolerance on other words), then the air date. Specials only ever map
to TMDb specials, and regular episodes never to specials."""
import episode_match

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS show_map(
         tvdb_show INTEGER PRIMARY KEY, tmdb_show INTEGER, built TEXT, episodes INTEGER, mapped INTEGER)""",
    """CREATE TABLE IF NOT EXISTS episode_map(
         tvdb_show INTEGER NOT NULL, tvdb_ep INTEGER NOT NULL, tmdb_show INTEGER,
         season INTEGER, number INTEGER, how TEXT, PRIMARY KEY(tvdb_show, tvdb_ep))""",
]


def ensure_tables(con):
    for stmt in SCHEMA:
        con.execute(stmt)


def has_show(con, tvdb_show):
    return con.execute('SELECT 1 FROM show_map WHERE tvdb_show=?', (int(tvdb_show),)).fetchone() is not None


def lookup(con, tvdb_show, tvdb_ep):
    """(season, number) in TMDb numbering, or None when the episode has no mapping."""
    row = con.execute('SELECT season, number, how FROM episode_map WHERE tvdb_show=? AND tvdb_ep=?',
                      (int(tvdb_show), int(tvdb_ep))).fetchone()
    if not row or not row[2] or row[2] == 'none':
        return None
    return row[0], row[1]


def _pool(tmdb_eps, tvdb_season):
    special = int(tvdb_season or 0) == 0
    return [e for e in tmdb_eps if (int(e.get('season') or 0) == 0) == special]


def pick(tv, tmdb_eps):
    """tv: one TVDB episode {season, episode, title, aired}. Returns (season, number, how)."""
    pool = _pool(tmdb_eps, tv.get('season'))
    season, number = tv.get('season'), tv.get('episode')
    for e in pool:
        if e.get('season') == season and e.get('number') == number:
            return e['season'], e['number'], 'number'
    hit = episode_match.match_episode(tv.get('title') or '', pool, season) if tv.get('title') else None
    if hit:
        return hit['season'], hit['number'], 'name'
    aired = tv.get('aired')
    if aired:
        same = [e for e in pool if e.get('air_date') == aired]
        if len(same) == 1:
            return same[0]['season'], same[0]['number'], 'aired'
    return None, None, 'none'


def build(con, tvdb_show, tmdb_show, tvdb_eps, tmdb_eps):
    """Write the map for one show. Returns {'episodes': n, 'mapped': m}."""
    ensure_tables(con)
    con.execute('DELETE FROM episode_map WHERE tvdb_show=?', (int(tvdb_show),))
    mapped = total = 0
    for tv in tvdb_eps or []:
        if tv.get('tvdb_id') is None or tv.get('season') is None or tv.get('episode') is None:
            continue
        total += 1
        s, n, how = pick(tv, tmdb_eps or [])
        if how != 'none':
            mapped += 1
        con.execute('INSERT OR REPLACE INTO episode_map(tvdb_show,tvdb_ep,tmdb_show,season,number,how) '
                    'VALUES(?,?,?,?,?,?)', (int(tvdb_show), int(tv['tvdb_id']), tmdb_show, s, n, how))
    con.execute('INSERT OR REPLACE INTO show_map(tvdb_show,tmdb_show,built,episodes,mapped) VALUES(?,?,?,?,?)',
                (int(tvdb_show), tmdb_show, 'now', total, mapped))
    return {'episodes': total, 'mapped': mapped}


def build_for_show(con, tvdb_show, tvdb_key, tvdb_pin, tmdb_key, tmdb_show=None):
    """Make sure a show has a stored map. Uses the local databases first for the TMDb show id, then TVDB.
    Returns True when the show is mapped (already stored or built now)."""
    ensure_tables(con)
    if has_show(con, tvdb_show):
        return True
    if not tmdb_key:
        return False
    if not tmdb_show:
        import anime_data
        local = anime_data.resolve(tvdb_id=tvdb_show) or {}
        tmdb_show = local.get('tmdb_id') or None
    import tvdb_catalog
    if not tmdb_show:
        tvdb_catalog._login(tvdb_key, pin=tvdb_pin or None)
        tmdb_show = tvdb_catalog.resolve_tmdb_from_tvdb(tvdb_key, tvdb_show)
    if not tmdb_show:
        return False
    tvdb_catalog._login(tvdb_key, pin=tvdb_pin or None)
    tvdb_eps = tvdb_catalog.fetch_episodes(tvdb_key, tvdb_show)
    tmdb_eps = episode_match.tmdb_episodes(tmdb_key, tmdb_show)
    if not tvdb_eps or not tmdb_eps:
        return False
    build(con, tvdb_show, tmdb_show, tvdb_eps, tmdb_eps)
    return True
