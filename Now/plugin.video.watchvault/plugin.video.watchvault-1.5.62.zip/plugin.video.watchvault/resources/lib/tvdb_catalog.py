# -*- coding: utf-8 -*-
"""Optional TVDB episode lists (aired order, specials = season 0).

Runs only when the user has typed their own TVDB API key. No key is stored
here, and an empty key makes no network call.
"""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

import watchvault as wv
import tvdb_episodes

API = 'https://api4.thetvdb.com/v4'
_token = {}


def _req(path, token=None, data=None):
    headers = {'Accept': 'application/json', 'Content-Type': 'application/json',
               'User-Agent': 'WatchVault'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = urllib.request.Request(API + path, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        err = RuntimeError('TVDB request failed (%s)' % e.code)
        err.code = e.code
        raise err
    except urllib.error.URLError:
        raise RuntimeError('TVDB request failed')


def _login(key, pin=None):
    key = (key or '').strip()
    if not key:
        raise RuntimeError('TVDB key is empty')
    pin = (pin or '').strip() or None
    if not pin:
        try:
            import xbmcaddon
            pin = (xbmcaddon.Addon().getSettingString('tvdb_pin') or '').strip() or None
        except Exception:
            pin = None
    cache_key = key + '|' + (pin or '')
    if _token.get('cache_key') != cache_key:
        body = {'apikey': key}
        if pin:
            body['pin'] = pin
        res = _req('/login', data=body)
        token = ((res.get('data') or {}).get('token')) if isinstance(res, dict) else None
        if not token:
            raise RuntimeError('TVDB login failed')
        _token['cache_key'] = cache_key
        _token['key'] = key
        _token['token'] = token
    return _token['token']


def _http_error_code(exc):
    if isinstance(exc, RuntimeError):
        m = re.search(r'\((\d+)\)', str(exc))
        if m:
            return int(m.group(1))
    return None


def _tvdb_id_of(hit):
    if not isinstance(hit, dict):
        return None
    tid = hit.get('tvdb_id') or str(hit.get('id') or '').replace('series-', '').replace('movie-', '')
    try:
        return int(tid)
    except (TypeError, ValueError):
        return None


def resolve_tvdb_id(key, title, year=None, movie=False):
    """Exact name (+ year when given) search. Prefer year match; require normalized title equality."""
    if not (key or '').strip() or not (title or '').strip():
        return None
    tok = _login(key)
    kind = 'movie' if movie else 'series'
    q = '/search?type=%s&query=%s' % (kind, urllib.parse.quote(title))
    if year:
        q += '&year=%s' % year
    res = _req(q, token=tok)
    want = _norm_name(title)
    exact, year_hits, any_hits = [], [], []
    for r in (res.get('data') or []) if isinstance(res, dict) else []:
        tid = _tvdb_id_of(r)
        if not tid:
            continue
        names = [r.get('name')]
        translations = r.get('translations') or {}
        if isinstance(translations, dict):
            names.extend(translations.values())
        for alias in r.get('aliases') or []:
            if isinstance(alias, str):
                names.append(alias)
            elif isinstance(alias, dict):
                names.append(alias.get('name'))
        name_ok = any(_norm_name(n) == want for n in names if n)
        if not name_ok:
            continue
        any_hits.append(tid)
        ry = r.get('year')
        try:
            ry = int(ry) if ry not in (None, '') else None
        except (TypeError, ValueError):
            ry = None
        if year and ry == int(year):
            year_hits.append(tid)
            exact.append(tid)
        elif not year:
            exact.append(tid)
    # Unique match only. Multiple exact hits → miss (caller may neg-cache).
    for pool in (exact, year_hits):
        uniq = list(dict.fromkeys(pool))
        if len(uniq) == 1:
            return uniq[0]
        if len(uniq) > 1:
            return None
    if not year:
        uniq = list(dict.fromkeys(any_hits))
        if len(uniq) == 1:
            return uniq[0]
    return None


def resolve_tvdb_by_remote(key, remote_id, movie=False):
    """GET /search/remoteid/{id} — TMDb, IMDb, etc. Prefer series or movie entity."""
    if not (key or '').strip() or remote_id in (None, ''):
        return None
    tok = _login(key)
    rid = str(remote_id).strip()
    res = _req('/search/remoteid/' + urllib.parse.quote(rid, safe=''), token=tok)
    rows = (res.get('data') or []) if isinstance(res, dict) else []
    prefer = 'movie' if movie else 'series'
    other = 'series' if movie else 'movie'
    for kind in (prefer, other):
        for row in rows:
            if not isinstance(row, dict):
                continue
            entity = row.get(kind)
            if isinstance(entity, dict) and entity.get('id'):
                try:
                    return int(entity['id'])
                except (TypeError, ValueError):
                    continue
    return None



def tmdb_id_from_remote_list(remote_list):
    for r in remote_list or []:
        src = (r.get('sourceName') or '').lower().replace(' ', '')
        if src in ('themoviedb.com', 'themoviedb'):
            val = r.get('id')
            try:
                return int(val)
            except (TypeError, ValueError):
                return val
    return None


def resolve_tmdb_from_tvdb(key, tvdb_id, movie=False):
    """GET /series|movie/{id}/extended → TMDb id from remoteIds."""
    if not (key or '').strip() or not tvdb_id:
        return None
    tok = _login(key)
    kind = 'movies' if movie else 'series'
    res = _req('/%s/%s/extended' % (kind, int(tvdb_id)), token=tok)
    data = (res.get('data') or {}) if isinstance(res, dict) else {}
    return tmdb_id_from_remote_list(data.get('remoteIds') or data.get('remote_ids'))

def _episodes_from(res):
    data = res.get('data') if isinstance(res, dict) else None
    if isinstance(data, dict):
        return data.get('episodes') or []
    if isinstance(data, list):
        return data
    return []


def _norm_name(value):
    text = re.sub(r'[^a-z0-9]+', ' ', (value or '').lower())
    return re.sub(r'\s+', ' ', text).strip()


def _year_close(movie_year, episode_year):
    if not movie_year or not episode_year:
        return True
    try:
        return abs(int(movie_year) - int(episode_year)) <= 1
    except (TypeError, ValueError):
        return True


def _names_of(row):
    names = [row.get('name'), row.get('extended_title')]
    translations = row.get('translations') or {}
    if isinstance(translations, dict):
        names.extend(value for value in translations.values() if isinstance(value, str))
    for alias in row.get('aliases') or []:
        if isinstance(alias, str):
            names.append(alias)
        elif isinstance(alias, dict):
            names.append(alias.get('name') or alias.get('title'))
    return [name for name in names if name]


_FILLER = {'the', 'a', 'an', 'movie', 'film', 'special', 'specials', 'ova', 'ona', 'oad', 'part', 'episode', 'ep'}


def _title_hit(episode_title, movie_names):
    want = _norm_name(episode_title)
    words = [word for word in want.split() if word not in _FILLER and len(word) > 2]
    if not words or len(want) < 8:
        return False
    for name in movie_names:
        norm = _norm_name(name)
        if norm and (norm == want or want in norm):
            return True
    return False


def _anilist_movie(title, year):
    query = ('query ($search: String) { Page(perPage: 5) { media(search: $search, type: ANIME, format: MOVIE) '
             '{ id idMal title { romaji english } startDate { year } } } }')
    body = json.dumps({'query': query, 'variables': {'search': title}}).encode('utf-8')
    req = urllib.request.Request(
        'https://graphql.anilist.co', data=body,
        headers={'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': 'WatchVault'})
    try:
        with urllib.request.urlopen(req, timeout=20) as res:
            payload = json.loads(res.read().decode('utf-8'))
    except Exception:
        return None
    media = (((payload.get('data') or {}).get('Page') or {}).get('media')) or []
    want = _norm_name(title)
    for item in media:
        names = item.get('title') or {}
        if not _title_hit(title, [names.get('english'), names.get('romaji')]):
            continue
        movie_year = (item.get('startDate') or {}).get('year')
        if not _year_close(movie_year, year):
            continue
        return {'title': names.get('english') or names.get('romaji') or title, 'year': movie_year,
                'anilist_id': item.get('id'), 'mal_id': item.get('idMal')}
    return None


def search_as_movie(key, title, year=None, show_title=None):
    """Movie-mode lookup. TVDB is used only when a key is set. AniList needs no key.
    A hit must use the same name, not a loose search result. show_title is accepted
    so callers can pass the series name; matching stays on the episode title."""
    del show_title
    if not (title or '').strip():
        return None
    found = None
    if (key or '').strip():
        try:
            tok = _login(key)
            res = _req('/search?type=movie&query=' + urllib.parse.quote(title), token=tok)
        except Exception:
            res = {}
        want = _norm_name(title)
        for row in (res.get('data') or []) if isinstance(res, dict) else []:
            if not _title_hit(title, _names_of(row)):
                continue
            movie_year = row.get('year')
            try:
                movie_year = int(str(movie_year)[:4]) if movie_year else None
            except (TypeError, ValueError):
                movie_year = None
            if not _year_close(movie_year, year):
                continue
            raw_id = row.get('tvdb_id') or row.get('id')
            try:
                raw_id = int(str(raw_id).replace('movie-', ''))
            except (TypeError, ValueError):
                raw_id = None
            found = {'title': row.get('name') or row.get('title') or title, 'year': movie_year, 'tvdb_id': raw_id}
            break
    other = _anilist_movie(title, year)
    if found and other:
        found['anilist_id'] = other.get('anilist_id')
        found['mal_id'] = other.get('mal_id')
        return found
    return found or other


def movie_name(key, movie_id, fallback):
    """English movie name when TVDB has one. Empty key: no network."""
    if not (key or '').strip() or not movie_id:
        return fallback
    try:
        tok = _login(key)
        res = _req('/movies/%d/translations/eng' % int(movie_id), token=tok)
        data = res.get('data') if isinstance(res, dict) else None
        name = data.get('name') if isinstance(data, dict) else None
        return name or fallback
    except Exception:
        return fallback


def fetch_episodes(key, tvdb_id, season_type=None, original_names=True):
    """Episodes for one series in the chosen order (official by default, default when that is empty), with
    name_original set when the show has an original language. Empty key: no network, empty list."""
    if not (key or '').strip():
        return []
    tok = _login(key)
    bundle = tvdb_episodes.fetch_bundle(_req, tok, int(tvdb_id),
                                        season_type=season_type or tvdb_episodes.DEFAULT_ORDER,
                                        original_names=original_names)
    return bundle['episodes']


def fetch_series(key, tvdb_id):
    """Name and year for a series id. Empty key: no network."""
    if not (key or '').strip():
        return {'title': None, 'year': None}
    tok = _login(key)
    res = _req('/series/%d' % int(tvdb_id), token=tok)
    data = res.get('data') if isinstance(res, dict) else None
    if not isinstance(data, dict):
        data = {}
    year = data.get('year')
    if not year and data.get('firstAired'):
        year = str(data.get('firstAired'))[:4]
    try:
        year = int(str(year)[:4])
    except (TypeError, ValueError):
        year = None
    return {'title': data.get('name') or None, 'year': year}


def _norm_ep(e):
    if not isinstance(e, dict):
        return None
    season = e.get('seasonNumber', e.get('season'))
    number = e.get('number', e.get('episode'))
    if season is None or number is None:
        return None
    try:
        season, number = int(season), int(number)
    except (TypeError, ValueError):
        return None
    eid = e.get('id') if ('seasonNumber' in e or 'number' in e) else e.get('tvdb_id')
    if 'seasonNumber' not in e and 'number' not in e:
        eid = e.get('tvdb_id')
    title = e.get('name') if e.get('name') else e.get('title')
    original = e.get('name_original') or e.get('title_original')
    linked = e.get('linkedMovie', e.get('linked_movie'))
    flag = e.get('isMovie', e.get('is_movie'))
    return {'season': season, 'episode': number, 'tvdb_id': eid,
            'title': title or None, 'aired': e.get('aired') or None,
            'is_movie': 1 if flag in (1, True, '1') else 0,
            'title_original': original or None,
            'linked_movie': linked}


def _placeholder(title, tvdb_id):
    t = (title or '').strip()
    return t in ('', 'Unknown show') or t == 'TVDB %s' % tvdb_id


def replace_with_episodes(tvdb_id, episodes, title=None, year=None, show_id=None):
    """Purge saved episode entries for this TVDB id, then write the given list
    as watched. No network. Returns the number of episodes written."""
    tvdb_id = int(tvdb_id)
    rows = []
    for raw in episodes or []:
        ep = _norm_ep(raw)
        if ep:
            rows.append(ep)
    if not rows:
        return {'ok': False, 'error': 'no episodes', 'episodes': 0, 'title': title, 'tvdb_id': tvdb_id}
    with wv.db() as con:
        by_tv = con.execute('SELECT * FROM shows WHERE tvdb_id=?', (tvdb_id,)).fetchone()
        target = None
        if show_id:
            target = con.execute('SELECT * FROM shows WHERE id=?', (int(show_id),)).fetchone()
        if target and by_tv and by_tv['id'] != target['id']:
            con.execute('DELETE FROM episodes WHERE show_id=?', (by_tv['id'],))
            con.execute('UPDATE shows SET tvdb_id=NULL WHERE id=?', (by_tv['id'],))
            con.execute('DELETE FROM shows WHERE id=?', (by_tv['id'],))
            by_tv = None
        if target is None:
            target = by_tv
        final_year = year
        if target is None:
            name = title or ('TVDB %s' % tvdb_id)
            cur = con.execute(
                'INSERT INTO shows(tvdb_id,imdb_id,tmdb_id,title,year,created) VALUES(?,?,?,?,?,?)',
                (tvdb_id, None, None, name, year, wv._now()))
            sid = cur.lastrowid
            final_title = name
        else:
            sid = target['id']
            con.execute('DELETE FROM episodes WHERE show_id=?', (sid,))
            final_title = target['title']
            if title and _placeholder(final_title, tvdb_id):
                final_title = title
            final_year = target['year'] or year
            con.execute('UPDATE shows SET tvdb_id=?, title=?, year=? WHERE id=?',
                        (tvdb_id, final_title, final_year, sid))
        n = 0
        ts = wv._now()
        for ep in rows:
            con.execute(
                'INSERT INTO episodes(show_id,season,episode,tvdb_id,title,title_original,aired,watched,play_count,last_watched)'
                ' VALUES(?,?,?,?,?,?,?,1,1,?) ON CONFLICT(show_id,season,episode) DO UPDATE SET'
                ' tvdb_id=COALESCE(excluded.tvdb_id,episodes.tvdb_id),'
                ' title=COALESCE(excluded.title,episodes.title),'
                ' title_original=COALESCE(excluded.title_original,episodes.title_original),'
                ' aired=COALESCE(excluded.aired,episodes.aired),'
                ' watched=1, play_count=1, last_watched=excluded.last_watched',
                (sid, ep['season'], ep['episode'], wv._id(ep.get('tvdb_id')), ep.get('title'),
                 ep.get('title_original'), ep.get('aired'), ts))
            wv.remember_movie_link(con, sid, ep['season'], ep['episode'], ep.get('title'),
                                   ep.get('is_movie'), ep.get('linked_movie'))
            n += 1
        wv._log_change(con, 'full', final_title, final_year, tvdb_id, None, None, None, None, True, 'manual')
    wv._notify('changed', {'full': True})
    return {'ok': True, 'episodes': n, 'title': final_title, 'tvdb_id': tvdb_id, 'show_id': sid}


def purge_and_complete(key, tvdb_id, show_id=None):
    """Confirm-path: fetch the series, then purge saved entries and mark the
    full aired-order list watched. Empty key does not touch the network or the
    database."""
    if not (key or '').strip():
        return {'ok': False, 'error': 'no key', 'episodes': 0}
    try:
        tvdb_id = int(tvdb_id)
    except (TypeError, ValueError):
        return {'ok': False, 'error': 'bad id', 'episodes': 0}
    if tvdb_id <= 0:
        return {'ok': False, 'error': 'bad id', 'episodes': 0}
    meta = fetch_series(key, tvdb_id)
    eps = fetch_episodes(key, tvdb_id)
    if not eps:
        return {'ok': False, 'error': 'no episodes', 'episodes': 0, 'title': meta.get('title'),
                'tvdb_id': tvdb_id}
    result = replace_with_episodes(tvdb_id, eps, title=meta.get('title'), year=meta.get('year'),
                                   show_id=show_id)
    if result.get('ok') and result.get('show_id'):
        wv.link_show_movies(result['show_id'])
    return result


def fill_show(key, show_id, season_type=None, original_names=True):
    """Resolve the tvdb id if missing, then add every aired-order episode
    (leaving watched flags alone) so the list is complete.
    Returns the number of episodes seen. Empty key: 0, no network."""
    if not (key or '').strip():
        return 0
    with wv.db() as con:
        s = con.execute('SELECT * FROM shows WHERE id=?', (show_id,)).fetchone()
    if not s:
        return 0
    tvdb_id = s['tvdb_id']
    if not tvdb_id:
        tvdb_id = resolve_tvdb_id(key, s['title'], s['year'])
        if not tvdb_id:
            return 0
        with wv.db() as con:
            if not con.execute('SELECT 1 FROM shows WHERE tvdb_id=?', (tvdb_id,)).fetchone():
                con.execute('UPDATE shows SET tvdb_id=? WHERE id=?', (tvdb_id, show_id))
    tok = _login(key)
    bundle = tvdb_episodes.fetch_bundle(_req, tok, int(tvdb_id),
                                        season_type=season_type or tvdb_episodes.DEFAULT_ORDER,
                                        original_names=original_names)
    eps = bundle['episodes']
    if bundle.get('tmdb_id'):
        with wv.db() as con:
            con.execute('UPDATE shows SET tmdb_id=COALESCE(tmdb_id,?) WHERE id=?', (bundle['tmdb_id'], show_id))
    count = 0
    with wv.db() as con:
        for raw in eps:
            ep = _norm_ep(raw)
            if not ep:
                continue
            con.execute(
                'INSERT INTO episodes(show_id,season,episode,tvdb_id,title,title_original,aired,watched,play_count)'
                ' VALUES(?,?,?,?,?,?,?,0,0) ON CONFLICT(show_id,season,episode) DO UPDATE SET'
                ' tvdb_id=COALESCE(excluded.tvdb_id,episodes.tvdb_id),'
                ' title=COALESCE(excluded.title,episodes.title),'
                ' title_original=COALESCE(excluded.title_original,episodes.title_original),'
                ' aired=COALESCE(excluded.aired,episodes.aired)',
                (show_id, ep['season'], ep['episode'], wv._id(ep.get('tvdb_id')), ep.get('title'),
                 ep.get('title_original'), ep.get('aired')))
            wv.remember_movie_link(con, show_id, ep['season'], ep['episode'], ep.get('title'),
                                   ep.get('is_movie'), ep.get('linked_movie'))
            count += 1
    wv.link_show_movies(show_id)
    return count
