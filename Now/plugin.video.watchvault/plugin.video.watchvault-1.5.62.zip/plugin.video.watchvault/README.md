# WatchVault (plugin.video.watchvault)

Local watch history for Kodi. No Trakt / Simkl / MDBList account.

* Shows: show name, year, TVDB id, episodes as season/episode (season 0 = specials, TVDB aired order).
* Movies: title, year, TVDB id (imdb / tmdb optional).
* Add the video add-ons you use (Add-on > "+ Add a video add-on", or Settings > Add a video add-on).
  Playback from those add-ons is added to watch history at the "mark as watched after %" point.
* The history service (HistoryService) watches playback and applies that rule.
* Wipe or update any video add-on: the history lives here, and the add-on pulls it back through the helper.
* Export / import: JSON file and database file (merge or replace). Optional automatic JSON backup folder;
  if WatchVault's own data is ever wiped it restores from that backup at start-up.
* Nothing is sent over the internet except the optional downloads below. No keys are bundled.
  Optional: enter your own TVDB API key to fetch full episode lists.
* Anime datasets are optional and independent. Anime Offline Database and Kometa Anime-IDs
  each download once a day into a local cache. Titles and ids are then resolved on disk, with
  no per-lookup API call. Turn either source off without affecting the other. If a download
  fails or the file is not valid, the previous working copy stays.
* Manual TVDB id: Settings has a text field for a TVDB series id. Enter the id and choose
  "Purge saved entries and complete this TVDB id" (also on the main menu, or on a show).
  After you confirm, WatchVault purges that show's saved episode entries and writes the full
  TVDB episode list as watched. An empty API key does nothing and makes no network call.
* One show, episode or movie keeps TVDB, IMDb, TMDB, AniList and MAL ids on the same row.
  A later update that only has one of those ids still finds that same file.
* A normal episode is not a movie. On the TV episode list, isMovie 1 is the marker: that
  episode is marked "Is movie also? Yes" and the movie list gets the same entry. linkedMovie
  is kept only when that same episode already includes it. The movie is not looked up again.
* Playback stores runtime and time remaining (seconds) so it can be resumed.
  A stop below the watched threshold saves that progress and does not mark the item watched.
  At the threshold, or when playback ends, it is marked watched and the time remaining is kept
  (zero when it played to the end).
* Database count lists shows, episodes and the database file size. Purge all now clears saved
  shows, episodes and movies after you confirm. Video add-ons you added are kept.

## For add-on authors
Copy `helper/watchvault_helper.py` into your add-on (docs at the top of the file).
Without the helper you can also call, from any add-on:

    RunPlugin(plugin://plugin.video.watchvault/?action=mark_watched&title=Show&year=2019&season=1&episode=2&tvdb_id=12345&source=plugin.video.x)
    RunPlugin(plugin://plugin.video.watchvault/?action=announce&title=Show&year=2019&season=1&episode=2&tvdb_id=12345&source=plugin.video.x)

JSON layout: `{"format":"watchvault","version":1,"shows":[{"title","year","tvdb_id","imdb_id","tmdb_id","episodes":[{"season","episode","title","aired","watched","play_count","last_watched"}]}],"movies":[...],"sources":[...]}`

## Watch history details
* Watch history: a played item is saved as watched at the "mark as watched after %" point, or when it plays to the end. Add-ons that pass the TVDB id, season and episode give the most reliable results. Use the helper's `announce()` or `mark()` when the add-on doesn't pass these.
* Matching: items without a TVDB id are matched by show name and year, and get their id later.
* Episode lists: the full aired-order list (specials as season 0) needs your own TVDB API key in Settings. It is off by default.


## ID fill pipeline

1. **Local (no network)** — Anime Offline Database + Kometa Anime-IDs. Fills empty AniList, MAL, TVDB, TMDb, IMDb. Never overwrites.
2. **TMDb/IMDb → TVDB** — `GET /search/remoteid/{id}` for rows missing TVDB.
3. **Name + year → TVDB** — exact normalized title match; unique hit only (ambiguous → miss + 7-day negative cache).
4. **TVDB → TMDb** — `GET /series|movies/{id}/extended` remoteIds when TMDb is empty.

Runs:
- On **mark** (local always; optional one-shot network if "Fill TVDB/TMDb on mark" is on).
- After **dataset refresh** (local fill; negative cache cleared when datasets change).
- **Sync fill** every N hours (default 6), batch size default 50; also **Run sync fill now** in the menu/settings.

Provenance is stored in `id_sources` and shown on show/movie plots. Last run stats: menu → Last fill stats.

## Provider sync (optional)

Nightshift keeps using **WatchVault / Nightshift** for on-device watched state.

When **Enable provider sync** is on, WatchVault pushes *its* watched episodes/movies to any
enabled provider on the interval you set (5 minutes–12 hours), and optionally after each mark.

- **MDBList** — API key; full watched push implemented (ids sent **tvdb, tmdb, imdb** in that order)
- **PunchPlay** — client id + device login or paste tokens\n  - Title ids: **tvdb:ID** (preferred), TMDb number, **mal:ID**, or IMDb `tt…`\n  - **AniList is not supported** by PunchPlay title paths (docs)\n  - Paths: `/title/show|{id}/season/n/watch`, `/title/movie|{id}/history`
- **Trakt / Simkl** — client id + access token; history POST implemented when configured
- **PunchPlay** — token setting reserved (API push not finished)

Off = **WatchVault-only** mode (no remote provider traffic).


### Provider sync behaviour

- **Incremental**: uses the WatchVault change log + per-provider cursor (only new marks / unmarks).
- **Unwatch**: sends `sync/watched/remove` (MDBList) when `watched=0` appears in the log.
- **MDBList auth**: device-code OAuth preferred (`Authorization: Bearer`); API key is legacy fallback as Bearer header only — never `?apikey=` in the URL.
