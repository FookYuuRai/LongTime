# -*- coding: utf-8 -*-
"""Drop this single file into any Kodi video add-on.  Every function is safe to
call whether or not WatchVault is installed (it simply does nothing / returns
empty).  No import of WatchVault is required in your addon.xml (optional:
<import addon="plugin.video.watchvault" optional="true"/>).

    import watchvault_helper as wvh

    # 1) just before you resolve/play something:
    wvh.announce(title='Show Name', year=2019, season=1, episode=2, tvdb_id=12345,
                 anilist_id=1, mal_id=2, imdb_id='tt1', tmdb_id=3,
                 source='plugin.video.myaddon')                 # movies: omit season/episode

    # 2) or mark directly (e.g. your own "mark watched" menu item):
    wvh.mark(title='Show Name', year=2019, season=1, episode=2, tvdb_id=12345,
             episode_anilist_id=9, runtime=1440, remaining=120,
             source='plugin.video.myaddon', watched=True)

    # 3) on addon start / after a wipe, pull what changed (or everything):
    for ch in wvh.pull_changes('plugin.video.myaddon'):
        if ch['kind'] == 'full':
            data = wvh.get_clean_list(watched_only=True, compact=True)   # rebuild all
        else:   # kind 'episode' or 'movie'
            ...apply ch['title'], ch['year'], ch['tvdb_id'], ch['season'], ch['episode'], ch['watched']

    wvh.get_clean_list(watched_only=True, compact=True)
        -> {'shows': [{'title','year','tvdb_id','episodes': ['S00E01','S01E01',...]}], 'movies': [...]}
    wvh.is_watched(season=1, episode=2, tvdb_id=12345)            # episode
    wvh.is_watched(tvdb_id=777)                                   # movie
    wvh.watched_episodes(tvdb_id=12345)                           # {1: [1,2,3], 0: [1]}

To be told instantly, listen in your service:
    def onNotification(self, sender, method, data):
        if sender == 'plugin.video.watchvault' and method == 'Other.changed': ...pull_changes(...)
"""
import os
import sys

_ID = 'plugin.video.watchvault'
_wv = None


def _load():
    global _wv
    if _wv is not None:
        return _wv or None
    try:
        import xbmcaddon
        path = xbmcaddon.Addon(_ID).getAddonInfo('path')
        lib = os.path.join(path, 'resources', 'lib')
        if lib not in sys.path:
            sys.path.append(lib)
        import watchvault
        _wv = watchvault
    except Exception:
        _wv = False
    return _wv or None


def available():
    return _load() is not None


def _call(name, default, *a, **kw):
    mod = _load()
    if not mod:
        return default
    try:
        return getattr(mod, name)(*a, **kw)
    except Exception:
        return default


def announce(**info):
    return _call('announce', None, **info)


def mark(**kw):
    return _call('mark_watched', None, **kw)


def pull_changes(addon_id, ack=True):
    return _call('pull_changes', [], addon_id, ack)


def get_clean_list(watched_only=False, compact=False, include_movies=True):
    return _call('get_clean_list', {'shows': [], 'movies': []}, watched_only, compact, include_movies)


def is_watched(**kw):
    return _call('is_watched', False, **kw)


def watched_show_ids():
    return _call('watched_show_ids', [])


def watched_episodes(**kw):
    return _call('watched_episodes', {}, **kw)


def save_progress(**kw):
    """runtime and remaining are seconds. Does not change the watched flag."""
    return _call('save_progress', None, **kw)


def get_resume(**kw):
    """{'runtime', 'remaining', 'position', 'watched'} in seconds, or None."""
    return _call('get_resume', None, **kw)


def clear_progress(**kw):
    """Clear remaining (resume seek) without changing watched."""
    return _call('clear_progress', None, **kw)


def resolve_anime(**kw):
    """Local title and id match from the cached anime datasets. None if unavailable."""
    return _call('resolve_anime', None, **kw)
