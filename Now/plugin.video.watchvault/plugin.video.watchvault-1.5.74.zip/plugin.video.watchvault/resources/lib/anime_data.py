"""Local anime title and id lookup.

Two optional datasets, each updated on its own:

* Anime Offline Database (titles, AniList, MAL, AniDB, and any ids in the source URLs)
* Kometa Anime-IDs (AniDB to TVDB, IMDb, TMDB, MAL, AniList)

A failed download or a file that does not validate leaves the previous copy in place.
Lookups read the local cache only.
"""

import json
import os
import re
import sqlite3
import time
import urllib.error
import urllib.request

def _log(msg):
    try:
        import xbmc
        xbmc.log('[WatchVault anime] %s' % msg, xbmc.LOGINFO)
    except Exception:
        pass

OFFLINE_URL = 'https://github.com/cedya77/anime-offline-database/releases/download/latest/anime-offline-database.jsonl'
KOMETA_URL = 'https://raw.githubusercontent.com/Kometa-Team/Anime-IDs/master/anime_ids.json'
KOMETA_EDITS_URL = 'https://raw.githubusercontent.com/Kometa-Team/Anime-IDs/master/anime_id_edits.json'
DAY = 24 * 60 * 60

def cache_dir():
    import watchvault as wv
    path = os.path.join(wv.data_dir(), 'anime')
    os.makedirs(path, exist_ok=True)
    return path


def _file(name):
    return os.path.join(cache_dir(), name)


def enabled(name):
    key = 'anime_offline' if name == 'offline' else 'anime_kometa'
    try:
        import xbmcaddon
        return bool(xbmcaddon.Addon('plugin.video.watchvault').getSettingBool(key))
    except Exception:
        return True


def _meta():
    path = _file('meta.json')
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_meta(data):
    path = _file('meta.json')
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
    os.replace(tmp, path)


def _download(url, dest, previous):
    headers = {
        'User-Agent': 'WatchVault/1.5 (Kodi; Android)',
        'Accept': 'application/json,*/*',
    }
    if previous.get('etag'):
        headers['If-None-Match'] = previous['etag']
    if previous.get('modified'):
        headers['If-Modified-Since'] = previous['modified']
    _log('GET %s' % url)
    req = urllib.request.Request(url, headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=300)
    except urllib.error.HTTPError as exc:
        if exc.code == 304:
            _log('304 Not Modified (keep previous) %s' % url)
            return {'status': 'unchanged'}
        body = ''
        try:
            body = exc.read()[:200].decode('utf-8', 'replace')
        except Exception:
            pass
        _log('HTTP %s FAIL %s — %s' % (exc.code, url, body))
        raise RuntimeError('HTTP %s for %s: %s' % (exc.code, url, body))
    except Exception as exc:
        _log('FAIL %s — %s' % (url, exc))
        raise RuntimeError('%s for %s' % (exc, url))
    try:
        tmp = dest + '.part'
        total = 0
        with resp, open(tmp, 'wb') as out:
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                total += len(chunk)
        os.replace(tmp, dest)
        _log('OK bytes=%s path=%s url=%s' % (total, dest, url))
        return {
            'status': 'ok',
            'etag': resp.headers.get('ETag') or '',
            'modified': resp.headers.get('Last-Modified') or '',
            'bytes': total,
            'url': url,
        }
    finally:
        resp.close()


def _due(meta, name, force):
    if force:
        return True
    checked = (meta.get(name) or {}).get('checked') or 0
    return time.time() - float(checked) >= DAY


def _drop(path):
    try:
        os.remove(path)
    except OSError:
        pass


def update(force=False, fetch=None):
    """Download datasets that are due. One source failing does not touch the other."""
    fetch = fetch or _download
    _log('update start force=%s' % force)
    meta = _meta()
    result = {}
    result['offline'] = _update_offline(meta, force, fetch)
    result['kometa'] = _update_kometa(meta, force, fetch)
    unchanged = all(isinstance(result.get(k), dict) and result[k].get('unchanged') for k in ('offline', 'kometa'))
    if unchanged and (meta.get('unified') or {}).get('built'):
        result['unified'] = {'ok': True, 'skipped': 'datasets unchanged'}   # the merge only moves when data moved
    else:
        result['unified'] = _rebuild_unified()
        if result['unified'].get('ok'):
            meta['unified'] = {'built': time.time()}
            _save_meta(meta)
    _log('update done offline=%s kometa=%s unified=%s' % (result.get('offline'), result.get('kometa'),
                                                          result.get('unified')))
    return result


def _rebuild_unified():
    """Merge offline + Kometa into the store (watchvault.db). Incremental: existing rows are kept; empty fields fill."""
    offline_path = _file('offline.jsonl') if os.path.exists(_file('offline.jsonl')) else (
        _file('offline.json') if os.path.exists(_file('offline.json')) else None)
    kometa_path = _file('kometa.json') if os.path.exists(_file('kometa.json')) else None
    edits_path = _file('kometa-edits.json') if os.path.exists(_file('kometa-edits.json')) else None
    if not offline_path and not kometa_path:
        _log('unified merge skipped: no offline/kometa files')
        return {'ok': False, 'error': 'no source files'}
    try:
        from helpers import build as unified_build
        _migrate_legacy_unified()
        counts = unified_build.merge_into(
            unified_path(), offline_path=offline_path, kometa_path=kometa_path, edits_path=edits_path)
        _log('unified merge offline=%s kometa=%s' % (counts.get('offline'), counts.get('kometa')))
        return {'ok': True, 'entries': counts}
    except Exception as exc:
        _log('unified merge failed: %s' % exc)
        return {'ok': False, 'error': str(exc)}



def _update_offline(meta, force, fetch):
    if not enabled('offline'):
        return {'ok': True, 'skipped': True}
    if not _due(meta, 'offline', force):
        return {'ok': True, 'unchanged': True}
    tmp = _file('offline.jsonl.tmp')
    _drop(tmp)
    err = None
    fetched = None
    for url in (OFFLINE_URL,):
        try:
            fetched = fetch(url, tmp, meta.get('offline') or {})
            err = None
            break
        except Exception as exc:
            err = str(exc)
            _drop(tmp)
            continue
    if fetched is None:
        _log('offline download failed: %s' % (err or 'download failed'))
        return {'ok': False, 'kept': True, 'error': err or 'download failed'}
    if fetched.get('status') == 'unchanged':
        slot = dict(meta.get('offline') or {})
        slot['checked'] = time.time()
        meta['offline'] = slot
        _save_meta(meta)
        return {'ok': True, 'unchanged': True}
    kometa_path = _file('kometa.json')
    edits_path = _file('kometa-edits.json')
    try:
        from helpers import offline as offline_helper
        counts = {'offline': sum(1 for _ in offline_helper.records(tmp))}
        if counts['offline'] == 0:
            raise ValueError('no anime records')
    except Exception as exc:
        _drop(tmp)
        _log('offline download invalid: %s' % exc)
        return {'ok': False, 'kept': True, 'error': 'invalid: %s' % exc}
    os.replace(tmp, _file('offline.jsonl'))
    meta['offline'] = {
        'checked': time.time(), 'entries': counts['offline'],
        'etag': fetched.get('etag') or '', 'modified': fetched.get('modified') or '',
    }
    _save_meta(meta)
    _log('offline ready entries=%s' % counts['offline'])
    return {'ok': True, 'entries': counts['offline']}


def _update_kometa(meta, force, fetch):
    if not enabled('kometa'):
        return {'ok': True, 'skipped': True}
    if not _due(meta, 'kometa', force):
        return {'ok': True, 'unchanged': True}
    tmp = _file('kometa.json.tmp')
    edits_tmp = _file('kometa-edits.json.tmp')
    _drop(tmp)
    _drop(edits_tmp)
    try:
        fetched = fetch(KOMETA_URL, tmp, meta.get('kometa') or {})
    except Exception:
        _drop(tmp)
        return {'ok': False, 'kept': True, 'error': 'download failed'}
    edits_fetched = {'status': 'missing'}
    try:
        edits_fetched = fetch(KOMETA_EDITS_URL, edits_tmp, meta.get('kometa_edits') or {})
    except Exception:
        _drop(edits_tmp)
        edits_fetched = {'status': 'kept'}
    ids_unchanged = fetched.get('status') == 'unchanged'
    edits_unchanged = edits_fetched.get('status') in ('unchanged', 'missing', 'kept')
    if ids_unchanged and edits_fetched.get('status') == 'unchanged':
        slot = dict(meta.get('kometa') or {})
        slot['checked'] = time.time()
        meta['kometa'] = slot
        _save_meta(meta)
        return {'ok': True, 'unchanged': True}
    ids_path = _file('kometa.json') if ids_unchanged else tmp
    if ids_unchanged and not os.path.exists(ids_path):
        return {'ok': False, 'kept': True, 'error': 'download failed'}
    if edits_fetched.get('status') == 'ok':
        edits_path = edits_tmp
    elif os.path.exists(_file('kometa-edits.json')):
        edits_path = _file('kometa-edits.json')
    else:
        edits_path = None
    try:
        from helpers import kometa as kometa_helper
        counts = {'kometa': sum(1 for _ in kometa_helper.records(
            ids_path, edits_path if edits_path and os.path.exists(edits_path) else None))}
        if counts['kometa'] == 0:
            raise ValueError('no kometa rows')
    except Exception:
        _drop(tmp)
        _drop(edits_tmp)
        return {'ok': False, 'kept': True, 'error': 'invalid'}
    if not ids_unchanged:
        os.replace(tmp, _file('kometa.json'))
    if edits_fetched.get('status') == 'ok':
        os.replace(edits_tmp, _file('kometa-edits.json'))
        meta['kometa_edits'] = {
            'checked': time.time(), 'etag': edits_fetched.get('etag') or '',
            'modified': edits_fetched.get('modified') or '',
        }
    meta['kometa'] = {
        'checked': time.time(), 'entries': counts['kometa'],
        'etag': (meta.get('kometa') or {}).get('etag') if ids_unchanged else (fetched.get('etag') or ''),
        'modified': (meta.get('kometa') or {}).get('modified') if ids_unchanged else (fetched.get('modified') or ''),
    }
    _save_meta(meta)
    result = {'ok': True, 'entries': counts['kometa']}
    if edits_fetched.get('status') == 'kept':
        result['edits_kept'] = True
    if edits_unchanged and ids_unchanged:
        result['unchanged'] = True
    return result


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def unified_path():
    """The single WatchVault store (watchvault.db): anime, series, provider and watch data."""
    try:
        import watchvault as wv
        return wv.db_path()
    except Exception:
        return _file('watchvault.db')


def _migrate_legacy_unified():
    """Copy rows from the old separate unified.db into the single store, then remove it."""
    legacy = _file('unified.db')
    if not os.path.exists(legacy):
        return 0
    import sqlite3
    import unified
    from helpers import build as unified_build
    target = unified_path()
    moved = 0
    with sqlite3.connect(target) as dst:
        unified.ensure(dst)
        moved = unified_build.copy_store(legacy, dst)
    os.remove(legacy)
    _log('migrated %d rows from unified.db into watchvault.db' % moved)
    return moved




def resolve(title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
            anilist_id=None, mal_id=None, anidb_id=None, movie=False,
            use_offline=None, use_kometa=None):
    """Match a title or any known id against the unified database. No network.
    Returns a dict (title, year, anidb_id, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, sources) or None.
    The offline and Kometa switches only decide whether the lookup runs at all."""
    use_offline = enabled('offline') if use_offline is None else bool(use_offline)
    use_kometa = enabled('kometa') if use_kometa is None else bool(use_kometa)
    if not use_offline and not use_kometa:
        return None
    path = unified_path()
    if not os.path.exists(path):
        return None
    import sqlite3
    import unified
    con = sqlite3.connect(path)
    try:
        return unified.resolve(con, title=title, year=year, tvdb_id=tvdb_id, imdb_id=imdb_id,
                               tmdb_id=tmdb_id, anilist_id=anilist_id, mal_id=mal_id,
                               anidb_id=anidb_id, movie=movie)
    finally:
        con.close()


def dataset_info():
    """Sizes and counts for the anime datasets (not watch history)."""
    meta = _meta()
    info = {
        'offline_entries': int((meta.get('offline') or {}).get('entries') or 0),
        'kometa_entries': int((meta.get('kometa') or {}).get('entries') or 0),
        'offline_checked': (meta.get('offline') or {}).get('checked') or 0,
        'kometa_checked': (meta.get('kometa') or {}).get('checked') or 0,
        'offline_file_bytes': 0,
        'kometa_file_bytes': 0,
        'unified_bytes': 0,
        'unified_rows': 0,
        'anime_total_bytes': 0,
    }
    for name in ('offline.jsonl', 'offline.json'):
        path = _file(name)
        if os.path.exists(path):
            info['offline_file_bytes'] = os.path.getsize(path)
            break
    kp = _file('kometa.json')
    if os.path.exists(kp):
        info['kometa_file_bytes'] = os.path.getsize(kp)
    up = unified_path()
    if os.path.exists(up):
        info['unified_bytes'] = os.path.getsize(up)
        try:
            import sqlite3
            con = sqlite3.connect(up)
            info['unified_rows'] = con.execute('SELECT COUNT(*) FROM media').fetchone()[0]
            con.close()
        except Exception:
            pass
    info['anime_total_bytes'] = info['offline_file_bytes'] + info['kometa_file_bytes'] + info['unified_bytes']
    return info
