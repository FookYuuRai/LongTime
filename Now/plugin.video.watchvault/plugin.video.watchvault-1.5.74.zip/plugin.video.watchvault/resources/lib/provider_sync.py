# -*- coding: utf-8 -*-
"""Push WatchVault watched history to optional remote providers.

Nightshift stays on WatchVault / Nightshift watched mode. When the user enables a
provider here and supplies credentials, WatchVault pushes *its* watched rows out
on a schedule (and optionally right after a mark).

Providers with a working push path today:
  - MDBList (API key)

Scaffolded (settings only / returns not_configured until tokens exist):
  - Trakt, Simkl, PunchPlay
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import watchvault as wv

SOURCE = 'plugin.video.watchvault'


def _addon():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.watchvault')
    except Exception:
        return None


def _setting(name, default=''):
    ad = _addon()
    if not ad:
        return default
    try:
        return (ad.getSettingString(name) or default).strip() or default
    except Exception:
        try:
            return str(ad.getSetting(name) or default)
        except Exception:
            return default


def _setting_bool(name, default=False):
    ad = _addon()
    if not ad:
        return default
    try:
        return bool(ad.getSettingBool(name))
    except Exception:
        return default


def _setting_int(name, default=0):
    ad = _addon()
    if not ad:
        return default
    try:
        return int(ad.getSettingInt(name))
    except Exception:
        return default



def _state_path():
    import os
    return os.path.join(wv.data_dir(), 'provider_sync_state.json')


def _load_state():
    import os
    path = _state_path()
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _save_state(state):
    import os
    path = _state_path()
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, path)


def get_sync_cursor(provider='global'):
    return int((_load_state().get('cursors') or {}).get(provider) or 0)


def set_sync_cursor(provider, seq):
    state = _load_state()
    cursors = state.setdefault('cursors', {})
    cursors[provider] = int(seq or 0)
    state['last_run'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    _save_state(state)


def provider_sync_enabled():
    """False = WatchVault-only (no remote provider push)."""
    return _setting_bool('provider_sync_enabled', False)


def sync_interval_seconds():
    """5 minutes .. 12 hours (settings store minutes)."""
    minutes = _setting_int('provider_sync_minutes', 60)
    minutes = max(5, min(12 * 60, minutes or 60))
    return minutes * 60


def _http_form(url, fields, headers=None, timeout=30):
    h = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json',
         'User-Agent': 'WatchVault/1.5.27 (Kodi)'}
    h.update(headers or {})
    data = urllib.parse.urlencode(fields).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers=h, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8')
            return r.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode('utf-8') or '{}')
        except Exception:
            payload = {'error': str(e)}
        return e.code, payload
    except Exception as e:
        return 0, {'error': str(e)}


def _http_json(method, url, headers=None, body=None, timeout=30):
    headers = dict(headers or {})
    headers.setdefault('Accept', 'application/json')
    headers.setdefault('User-Agent', 'WatchVault-ProviderSync')
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8')
            return r.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            err = e.read().decode('utf-8')
            payload = json.loads(err) if err else {'error': str(e)}
        except Exception:
            payload = {'error': str(e)}
        if isinstance(payload, dict):
            try:
                payload['_retry_after'] = int(e.headers.get('Retry-After') or 0)
            except Exception:
                payload['_retry_after'] = 0
        return e.code, payload
    except Exception as e:
        return 0, {'error': str(e)}


def watched_payload():
    try:
        import unified
        con = unified.open_db()
        try:
            payload = unified.watched_for_providers(con)
            if payload.get("shows") or payload.get("movies"):
                return payload
        finally:
            con.close()
    except Exception:
        pass
    """Build provider-friendly watched structure from the local DB.

    Returns:
      {
        'shows': [
          {'ids': {'tmdb':..,'tvdb':..,'imdb':..}, 'title':.., 'year':..,
           'seasons': [{'number': 1, 'episodes': [{'number': 1}, ...]}]}
        ],
        'movies': [{'ids': {...}, 'title':.., 'year':..}]
      }
    """
    shows_out = []
    movies_out = []
    with wv.db() as con:
        shows = list(con.execute(
            'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id FROM shows'))
        for s in shows:
            eps = list(con.execute(
                'SELECT season, episode FROM episodes WHERE show_id=? AND watched=1 '
                'ORDER BY season, episode', (s['id'],)))
            if not eps:
                continue
            ids = _pack_ids(s)
            # MDBList/Trakt/Simkl resolve shows via tmdb/tvdb/imdb (not anilist/mal alone)
            if not any(ids.get(k) for k in ('tmdb', 'tvdb', 'imdb')):
                continue
            by_season = {}
            for e in eps:
                by_season.setdefault(int(e['season']), []).append({'number': int(e['episode'])})
            seasons = [{'number': sn, 'episodes': by_season[sn]} for sn in sorted(by_season)]
            shows_out.append({
                'ids': ids,
                'title': s['title'],
                'year': s['year'],
                'seasons': seasons,
            })
        for m in con.execute(
                'SELECT title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id FROM movies WHERE watched=1'):
            ids = _pack_ids(m)
            if not any(ids.get(k) for k in ('tmdb', 'tvdb', 'imdb')):
                continue
            movies_out.append({'ids': ids, 'title': m['title'], 'year': m['year']})
    return {'shows': shows_out, 'movies': movies_out}




def changes_delta(since_seq=0, limit=2000, exclude_source=None):
    """Incremental add/remove sets from the change log (not a full library dump).

    Returns:
      {
        'since': int, 'until': int, 'full': bool,
        'add_shows': [... same shape as watched_payload shows ...],
        'remove_shows': [...],
        'add_movies': [...],
        'remove_movies': [...],
      }
    """
    since_seq = int(since_seq or 0)
    max_seq = wv.last_seq()
    # Same gap rule as pull_changes: change log is capped (~5000 rows). If the
    # oldest remaining seq is newer than cursor+1, we already lost history —
    # force a full provider sync instead of silently skipping missed events.
    full_marker = {
        'since': since_seq, 'until': max_seq, 'full': True,
        'add_shows': [], 'remove_shows': [], 'add_movies': [], 'remove_movies': [],
    }
    if since_seq > max_seq:
        return full_marker
    try:
        with wv.db() as con:
            min_row = con.execute('SELECT MIN(seq) FROM changes').fetchone()
        min_seq = min_row[0] if min_row else None
    except Exception:
        min_seq = None
    if since_seq > 0 and min_seq is not None and min_seq > since_seq + 1:
        return full_marker
    rows = wv.get_changes(since=since_seq, limit=limit)
    # Explicit wipe / full marker in the window → full-sync
    if any(r.get('kind') == 'full' for r in rows):
        return full_marker
    # Collapse to latest state per media key
    ep_state = {}  # (tvdb,tmdb,imdb,anilist,mal,season,episode) -> watched bool + meta
    movie_state = {}
    ep_src = {}
    movie_src = {}
    for r in rows:
        kind = r.get('kind')
        if kind not in ('episode', 'movie'):
            continue
        ids = {
            'tvdb': r.get('tvdb_id'),
            'tmdb': r.get('tmdb_id'),
            'imdb': r.get('imdb_id'),
            'anilist': r.get('anilist_id'),
            'mal': r.get('mal_id'),
        }
        # drop empty
        ids = {k: v for k, v in ids.items() if v not in (None, '', 0)}
        if not any(ids.get(k) for k in ('tvdb', 'tmdb', 'imdb')):
            continue
        watched = r.get('watched')
        if watched is None:
            continue
        watched = bool(int(watched))
        meta = {
            'ids': ids,
            'title': r.get('title'),
            'year': r.get('year'),
        }
        if kind == 'episode':
            s, e = r.get('season'), r.get('episode')
            if s is None or e is None:
                continue
            key = (ids.get('tvdb'), ids.get('tmdb'), ids.get('imdb'), int(s), int(e))
            ep_state[key] = (watched, meta, int(s), int(e))
            ep_src[key] = r.get('source')
        else:
            key = (ids.get('tvdb'), ids.get('tmdb'), ids.get('imdb'))
            movie_state[key] = (watched, meta)
            movie_src[key] = r.get('source')

    # Echo guard: a provider never gets back a watch that came from that same provider.
    if exclude_source:
        ep_state = {k: v for k, v in ep_state.items() if ep_src.get(k) != exclude_source}
        movie_state = {k: v for k, v in movie_state.items() if movie_src.get(k) != exclude_source}

    def _fold_eps(want_watched):
        by_show = {}
        for key, (watched, meta, s, e) in ep_state.items():
            if watched != want_watched:
                continue
            idkey = tuple(sorted((meta['ids'] or {}).items()))
            slot = by_show.setdefault(idkey, {
                'ids': meta['ids'], 'title': meta.get('title'), 'year': meta.get('year'),
                'seasons': {},
            })
            slot['seasons'].setdefault(s, []).append({'number': e})
        out = []
        for slot in by_show.values():
            seasons = [{'number': sn, 'episodes': sorted(eps, key=lambda x: x['number'])}
                       for sn, eps in sorted(slot['seasons'].items())]
            out.append({
                'ids': slot['ids'], 'title': slot['title'], 'year': slot['year'],
                'seasons': seasons,
            })
        return out

    add_movies, remove_movies = [], []
    for key, (watched, meta) in movie_state.items():
        row = {'ids': meta['ids'], 'title': meta.get('title'), 'year': meta.get('year')}
        (add_movies if watched else remove_movies).append(row)

    until = max([since_seq] + [r.get('seq') or 0 for r in rows] + [0])
    return {
        'since': since_seq,
        'until': max(until, max_seq) if not rows else until,
        'full': False,
        'add_shows': _fold_eps(True),
        'remove_shows': _fold_eps(False),
        'add_movies': add_movies,
        'remove_movies': remove_movies,
    }


def _pack_ids(row):
    """All ids we store locally (TVDB first, then TMDb/IMDb/AniList/MAL)."""
    ids = {}
    if row['tvdb_id']:
        ids['tvdb'] = int(row['tvdb_id'])
    if row['tmdb_id']:
        ids['tmdb'] = int(row['tmdb_id'])
    if row['imdb_id']:
        ids['imdb'] = row['imdb_id']
    if row['anilist_id']:
        ids['anilist'] = int(row['anilist_id'])
    if row['mal_id']:
        ids['mal'] = int(row['mal_id'])
    return ids


def _provider_ids(ids, provider='mdblist'):
    """Ids accepted by each remote history API.

    Order is always TVDB first, then TMDb, then IMDb (when present together).
    MDBList (tested): tvdb, tmdb, imdb each work alone; mal/anilist alone do not.
    Trakt/Simkl: same three keys.
    PunchPlay history paths are TMDb-based; tvdb/imdb still help local matching.
    """
    ids = ids or {}
    out = {}
    for key in ('tvdb', 'tmdb', 'imdb'):  # TVDB first when sent together
        if ids.get(key):
            out[key] = ids[key]
    return out


# ----- MDBList -----

def _mdblist_client_id():
    return (_setting('mdblist_client_id') or '').strip()


def _mdblist_token():
    """OAuth access token only. MDBList rejects API keys as Bearer; query ?apikey= is not used."""
    return (_setting('mdblist_token') or '').strip()


def _mdblist_headers():
    token = _mdblist_token()
    if not token:
        return None
    return {
        'Authorization': 'Bearer %s' % token,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'User-Agent': 'WatchVault-ProviderSync',
    }


_MDBL_REFRESH_LOCK = threading.Lock()
_MDBL_REFRESH_STATE = {'failed_at': 0.0}


def _mdblist_refresh_token(stale_token=None):
    """Exchange the refresh token for a new access token (MDBList device sign-in).
    Only one thread refreshes; others reuse the result. True when a usable token is stored."""
    with _MDBL_REFRESH_LOCK:
        current = _setting('mdblist_token')
        if stale_token and current and current != stale_token:
            return True                      # another thread already refreshed
        if time.time() - _MDBL_REFRESH_STATE['failed_at'] < 60:
            return False                     # do not hammer a refresh that just failed
        refresh = _setting('mdblist_refresh_token')
        client = _mdblist_client_id()
        if not refresh or not client:
            return False
        status, res = _http_form('https://api.mdblist.com/oauth/token/', {
            'grant_type': 'refresh_token', 'refresh_token': refresh, 'client_id': client})
        if status not in (200, 201) or not isinstance(res, dict) or not res.get('access_token'):
            _MDBL_REFRESH_STATE['failed_at'] = time.time()
            _log_rate('MDBList token refresh failed (HTTP %s)' % status)
            return False
        _set_setting('mdblist_token', res['access_token'])
        if res.get('refresh_token'):
            _set_setting('mdblist_refresh_token', res['refresh_token'])
        return True


def _mdblist_request(method, path, body=None, _retried=False):
    headers = _mdblist_headers()
    if not headers:
        return 0, {'error': 'no_token'}
    url = 'https://api.mdblist.com/' + path.lstrip('/')
    used = _setting('mdblist_token')
    status, res = _http_json(method, url, headers=headers, body=body)
    if status == 401 and not _retried and _mdblist_refresh_token(used):
        return _mdblist_request(method, path, body=body, _retried=True)
    if status == 429:
        wait = int((res or {}).get('_retry_after') or 0) if isinstance(res, dict) else 0
        _log_rate('MDBList 429 on %s: %s (Retry-After %ss)' % (
            path, (res or {}).get('error') if isinstance(res, dict) else res, wait))
        if not _retried and 0 < wait <= 90:
            # 5-minute window: wait for it to reset, then try once more
            time.sleep(wait)
            return _mdblist_request(method, path, body=body, _retried=True)
    return status, res


def _mdblist_body_from_shows_movies(shows, movies):
    body = {'shows': [], 'movies': []}
    for show in shows or []:
        entry_ids = _provider_ids(show.get('ids'), 'mdblist')
        if not entry_ids:
            continue
        body['shows'].append({'ids': entry_ids, 'seasons': show.get('seasons') or []})
    for movie in movies or []:
        entry_ids = _provider_ids(movie.get('ids'), 'mdblist')
        if not entry_ids:
            continue
        body['movies'].append({'ids': entry_ids})
    return body


def _mdblist_post_chunks(path, body):
    """POST body in show batches of 20. path is sync/watched or sync/watched/remove."""
    updated = {'movies': 0, 'episodes': 0, 'shows': 0, 'seasons': 0}
    removed = {'movies': 0, 'episodes': 0, 'shows': 0, 'seasons': 0}
    errors = []
    shows = body.get('shows') or []
    movies = body.get('movies') or []
    for i in range(0, max(len(shows), 1) if shows else 0, 20) if shows else []:
        pass
    for i in range(0, len(shows), 20):
        chunk = {'shows': shows[i:i + 20], 'movies': []}
        status, res = _mdblist_request('POST', path, body=chunk)
        if status == 429:
            errors.append({'status': status, 'body': res, 'path': path})
            break   # rate limited: stop this run, the next run picks up the rest
        if status != 200:
            errors.append({'status': status, 'body': res, 'path': path})
            continue
        time.sleep(1)  # keep well under the 300-writes-per-5-minutes limit
        for bag_name, bag in (('updated', updated), ('removed', removed)):
            u = (res or {}).get(bag_name) or {}
            for k in bag:
                bag[k] += int(u.get(k) or 0)
    if movies:
        status, res = _mdblist_request('POST', path, body={'shows': [], 'movies': movies})
        if status != 200:
            errors.append({'status': status, 'body': res, 'path': path})
        else:
            for bag_name, bag in (('updated', updated), ('removed', removed)):
                u = (res or {}).get(bag_name) or {}
                for k in bag:
                    bag[k] += int(u.get(k) or 0)
    return {'updated': updated, 'removed': removed, 'errors': errors}


def mdblist_push(payload=None, delta=None, full=False):
    if not _setting_bool('mdblist_sync_enabled', False):
        return {'ok': False, 'provider': 'mdblist', 'error': 'disabled'}
    if not _mdblist_token():
        return {'ok': False, 'provider': 'mdblist', 'error': 'no_token'}

    # Full snapshot path
    if full or payload is not None and delta is None:
        payload = payload or watched_payload()
        body = _mdblist_body_from_shows_movies(payload.get('shows'), payload.get('movies'))
        if not body['shows'] and not body['movies']:
            return {'ok': True, 'provider': 'mdblist', 'mode': 'full', 'skipped': 'empty'}
        result = _mdblist_post_chunks('sync/watched', body)
        return {
            'ok': not result['errors'],
            'provider': 'mdblist',
            'mode': 'full',
            'updated': result['updated'],
            'errors': result['errors'] or None,
            'shows': len(body['shows']),
            'movies': len(body['movies']),
        }

    # Incremental: adds + removes
    delta = delta or {}
    add_body = _mdblist_body_from_shows_movies(delta.get('add_shows'), delta.get('add_movies'))
    rem_body = _mdblist_body_from_shows_movies(delta.get('remove_shows'), delta.get('remove_movies'))
    results = {'updated': {}, 'removed': {}, 'errors': []}
    if add_body['shows'] or add_body['movies']:
        r = _mdblist_post_chunks('sync/watched', add_body)
        results['updated'] = r['updated']
        results['errors'].extend(r['errors'])
    if rem_body['shows'] or rem_body['movies']:
        r = _mdblist_post_chunks('sync/watched/remove', rem_body)
        results['removed'] = r['removed']
        results['errors'].extend(r['errors'])
    return {
        'ok': not results['errors'],
        'provider': 'mdblist',
        'mode': 'incremental',
        'updated': results['updated'],
        'removed': results['removed'],
        'errors': results['errors'] or None,
        'add_shows': len(add_body['shows']),
        'remove_shows': len(rem_body['shows']),
        'add_movies': len(add_body['movies']),
        'remove_movies': len(rem_body['movies']),
    }


def mdblist_device_start():
    client = _mdblist_client_id()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    # form-encoded device authorization (MDBList OAuth)
    data = urllib.parse.urlencode({'client_id': client, 'scope': 'write'}).encode('utf-8')
    req = urllib.request.Request(
        'https://api.mdblist.com/oauth/device-authorization/',
        data=data,
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json',
                 'User-Agent': 'WatchVault-ProviderSync'},
        method='POST')
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            res = json.loads(e.read().decode('utf-8'))
        except Exception:
            res = {'error': str(e)}
        return {'ok': False, 'status': e.code, 'error': res}
    except Exception as e:
        return {'ok': False, 'error': str(e)}
    if not isinstance(res, dict) or not res.get('device_code'):
        return {'ok': False, 'error': res}
    res['ok'] = True
    return res


def mdblist_device_poll(device_code, client_id=None):
    client = (client_id or _mdblist_client_id()).strip()
    data = urllib.parse.urlencode({
        'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
        'device_code': device_code,
        'client_id': client,
    }).encode('utf-8')
    req = urllib.request.Request(
        'https://api.mdblist.com/oauth/token/',
        data=data,
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json',
                 'User-Agent': 'WatchVault-ProviderSync'},
        method='POST')
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            res = json.loads(e.read().decode('utf-8'))
        except Exception:
            res = {'error': str(e)}
        return {'ok': False, 'status': e.code, 'error': res}
    except Exception as e:
        return {'ok': False, 'error': str(e)}
    access = (res or {}).get('access_token')
    if not access:
        return {'ok': False, 'error': res}
    _store_login_token('mdblist_token', access)
    if res.get('refresh_token'):
        _store_login_token('mdblist_refresh_token', res['refresh_token'])
    return _finish_login('mdblist', access)


# ----- Trakt / Simkl / PunchPlay (credentials + structure; push when configured) -----

def _history_body_from_shows_movies(shows, movies):
    """Trakt/Simkl shared history JSON shape."""
    body = {'shows': [], 'movies': []}
    for show in shows or []:
        ids = _provider_ids(show.get('ids'), 'trakt')
        if not ids:
            continue
        body['shows'].append({'ids': ids, 'seasons': show.get('seasons') or []})
    for movie in movies or []:
        ids = _provider_ids(movie.get('ids'), 'trakt')
        if not ids:
            continue
        body['movies'].append({'ids': ids})
    return body


def trakt_push(payload=None, delta=None, full=False):
    token = (_setting('trakt_token') or '').strip()
    client = (_setting('trakt_client_id') or '').strip()
    if not _setting_bool('trakt_sync_enabled', False):
        return {'ok': False, 'provider': 'trakt', 'error': 'disabled'}
    if not token or not client:
        return {'ok': False, 'provider': 'trakt', 'error': 'not_configured'}
    headers = {
        'Authorization': 'Bearer %s' % token,
        'trakt-api-version': '2',
        'trakt-api-key': client,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    def _post(path, shows, movies):
        body = _history_body_from_shows_movies(shows, movies)
        if not body['shows'] and not body['movies']:
            return {'ok': True, 'empty': True, 'status': 0}
        status, res = _http_json('POST', 'https://api.trakt.tv/' + path, headers=headers, body=body)
        ok = status in (200, 201)
        # 0 added/deleted with empty not_found is still ok (already in desired state)
        if status in (200, 201) and isinstance(res, dict):
            not_found = res.get('not_found') or {}
            if any(not_found.get(k) for k in ('movies', 'shows', 'seasons', 'episodes')):
                ok = False
        return {'ok': ok, 'status': status, 'result': res, 'body_counts': {
            'shows': len(body['shows']), 'movies': len(body['movies'])}}

    if full or (payload is not None and delta is None):
        payload = payload or watched_payload()
        r = _post('sync/history', payload.get('shows'), payload.get('movies'))
        return {'ok': r['ok'], 'provider': 'trakt', 'mode': 'full', **r}

    delta = delta or {}
    add = _post('sync/history', delta.get('add_shows'), delta.get('add_movies'))
    rem = _post('sync/history/remove', delta.get('remove_shows'), delta.get('remove_movies'))
    return {
        'ok': add.get('ok', True) and rem.get('ok', True),
        'provider': 'trakt',
        'mode': 'incremental',
        'add': add,
        'remove': rem,
    }


def simkl_push(payload=None, delta=None, full=False):
    token = (_setting('simkl_token') or '').strip()
    client = (_setting('simkl_client_id') or '').strip()
    if not _setting_bool('simkl_sync_enabled', False):
        return {'ok': False, 'provider': 'simkl', 'error': 'disabled'}
    if not token or not client:
        return {'ok': False, 'provider': 'simkl', 'error': 'not_configured'}
    headers = {
        'Authorization': 'Bearer %s' % token,
        'simkl-api-key': client,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    def _post(path, shows, movies):
        body = _history_body_from_shows_movies(shows, movies)
        if not body['shows'] and not body['movies']:
            return {'ok': True, 'empty': True, 'status': 0}
        status, res = _http_json('POST', 'https://api.simkl.com/' + path, headers=headers, body=body)
        return {'ok': status in (200, 201), 'status': status, 'result': res}

    if full or (payload is not None and delta is None):
        payload = payload or watched_payload()
        r = _post('sync/history', payload.get('shows'), payload.get('movies'))
        return {'ok': r['ok'], 'provider': 'simkl', 'mode': 'full', **r}

    delta = delta or {}
    add = _post('sync/history', delta.get('add_shows'), delta.get('add_movies'))
    rem = _post('sync/history/remove', delta.get('remove_shows'), delta.get('remove_movies'))
    return {
        'ok': add.get('ok', True) and rem.get('ok', True),
        'provider': 'simkl',
        'mode': 'incremental',
        'add': add,
        'remove': rem,
    }


def _punchplay_title_id(ids):
    """Routable PunchPlay title id (docs: TMDB | imdb tt | tvdb:N | mal:N).

    Preference: TVDB first, then TMDb, then MAL, then IMDb.
    AniList is not a documented PunchPlay title id.
    """
    ids = ids or {}
    if ids.get('tvdb'):
        return 'tvdb:%s' % int(ids['tvdb'])
    if ids.get('tmdb'):
        return str(int(ids['tmdb']))
    if ids.get('mal'):
        return 'mal:%s' % int(ids['mal'])
    if ids.get('imdb'):
        return str(ids['imdb'])
    return None


def _punchplay_headers():
    token = (_setting('punchplay_token') or '').strip()
    if not token:
        return None
    return {
        'Authorization': 'Bearer %s' % token,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'WatchVault-ProviderSync',
    }


def _punchplay_apply(shows, movies, remove=False):
    """POST watch or DELETE history for shows/movies lists."""
    headers = _punchplay_headers()
    if not headers:
        return {'ok': False, 'error': 'no_token'}
    base = 'https://punchplay.tv/api/platform/v1'
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())
    ok_n = fail_n = skip_n = 0
    errors = []
    method = 'DELETE' if remove else 'POST'
    for show in shows or []:
        tid = _punchplay_title_id(show.get('ids'))
        if not tid:
            skip_n += 1
            continue
        title = show.get('title') or 'Unknown'
        year = int(show.get('year') or 0)
        for season in show.get('seasons') or []:
            sn = int(season.get('number'))
            quoted = urllib.parse.quote(str(tid), safe=':')
            if remove:
                # DELETE season watch clears those episodes; fall back to whole-title history delete
                url = '%s/title/show/%s/season/%s/watch' % (base, quoted, sn)
                status, res = _http_json('DELETE', url, headers=headers)
                if status not in (200, 201, 204) or (isinstance(res, dict) and res.get('error')):
                    url2 = '%s/title/show/%s/history' % (base, quoted)
                    status, res = _http_json('DELETE', url2, headers=headers)
            else:
                ep_rows = []
                for ep in season.get('episodes') or []:
                    num = int(ep.get('number'))
                    ep_rows.append({
                        'episodeNumber': num,
                        'name': 'Episode %s' % num,
                        'watchedAt': watched_at,
                    })
                if not ep_rows:
                    continue
                body = {
                    'episodes': ep_rows,
                    'title': title,
                    'year': year,
                    'watchedAt': watched_at,
                }
                url = '%s/title/show/%s/season/%s/watch' % (base, quoted, sn)
                status, res = _http_json('POST', url, headers=headers, body=body)
            if status in (200, 201, 204) and not (isinstance(res, dict) and res.get('error')):
                ok_n += 1
            else:
                fail_n += 1
                errors.append({'url': url if 'url' in dir() else None, 'status': status, 'body': res})
    for movie in movies or []:
        tid = _punchplay_title_id(movie.get('ids'))
        if not tid:
            skip_n += 1
            continue
        quoted = urllib.parse.quote(str(tid), safe=':')
        url = '%s/title/movie/%s/history' % (base, quoted)
        if remove:
            status, res = _http_json('DELETE', url, headers=headers)
        else:
            body = {
                'title': movie.get('title') or 'Unknown',
                'year': int(movie.get('year') or 0),
                'watchedAt': watched_at,
            }
            status, res = _http_json('POST', url, headers=headers, body=body)
        if status in (200, 201, 204) and not (isinstance(res, dict) and res.get('error')):
            ok_n += 1
        else:
            fail_n += 1
            errors.append({'url': url, 'status': status, 'body': res})
    return {
        'ok': fail_n == 0,
        'posted': ok_n,
        'failed': fail_n,
        'skipped_no_id': skip_n,
        'errors': errors[:5] if errors else None,
        'remove': remove,
    }


def punchplay_push(payload=None, delta=None, full=False):
    if not _setting_bool('punchplay_sync_enabled', False):
        return {'ok': False, 'provider': 'punchplay', 'error': 'disabled'}
    if not (_setting('punchplay_token') or '').strip():
        return {'ok': False, 'provider': 'punchplay', 'error': 'not_configured'}

    if full or (payload is not None and delta is None):
        payload = payload or watched_payload()
        r = _punchplay_apply(payload.get('shows'), payload.get('movies'), remove=False)
        return {'ok': r.get('ok'), 'provider': 'punchplay', 'mode': 'full', **r}

    delta = delta or {}
    add = _punchplay_apply(delta.get('add_shows'), delta.get('add_movies'), remove=False)
    rem = _punchplay_apply(delta.get('remove_shows'), delta.get('remove_movies'), remove=True)
    return {
        'ok': add.get('ok', True) and rem.get('ok', True),
        'provider': 'punchplay',
        'mode': 'incremental',
        'add': add,
        'remove': rem,
    }


def punchplay_device_start():
    """POST /api/platform/v1/auth/device/code"""
    client = (_setting('punchplay_client_id') or '').strip()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    device_id = (_setting('punchplay_device_id') or '').strip()
    if not device_id:
        import uuid
        device_id = str(uuid.uuid4())
        _set_setting('punchplay_device_id', device_id)
    body = {'client_id': client, 'device_id': device_id, 'scope': 'profile:read history:read'}
    status, res = _http_json(
        'POST', 'https://punchplay.tv/api/platform/v1/auth/device/code', body=body)
    if status not in (200, 201) or not isinstance(res, dict):
        # camelCase variant some builds accept
        status, res = _http_json(
            'POST', 'https://punchplay.tv/api/platform/v1/auth/device/code',
            body={'clientId': client, 'deviceId': device_id})
    if status not in (200, 201) or not isinstance(res, dict):
        return {'ok': False, 'status': status, 'error': res}
    res['ok'] = True
    return res


def punchplay_device_poll(device_code, client_id=None):
    """POST /api/platform/v1/auth/device/token"""
    client = (client_id or _setting('punchplay_client_id') or '').strip()
    body = {'client_id': client, 'device_code': device_code, 'device_name': 'WatchVault',
            'device_id': (_setting('punchplay_device_id') or '').strip()}
    status, res = _http_json(
        'POST', 'https://punchplay.tv/api/platform/v1/auth/device/token', body=body)
    if status not in (200, 201) or not (isinstance(res, dict) and res.get('access_token')):
        status, res = _http_json(
            'POST', 'https://punchplay.tv/api/platform/v1/auth/device/token',
            body={'clientId': client, 'deviceCode': device_code})
    if status in (200, 201) and isinstance(res, dict) and (
            res.get('access_token') or res.get('accessToken')):
        token = res.get('access_token') or res.get('accessToken')
        refresh = res.get('refresh_token') or res.get('refreshToken')
        _store_login_token('punchplay_token', token)
        if refresh:
            _store_login_token('punchplay_refresh_token', refresh)
        return _finish_login('punchplay', token)
    return {'ok': False, 'status': status, 'error': res}



def run_provider_sync(force=False, playback=True):
    """Push local watched changes to enabled providers.

    Uses the change-log cursor for incremental add/remove on every provider.
    force=True or a full marker / empty cursor triggers a full watched snapshot.
    The MDBList in-progress list is refreshed in the same cycle (playback=True and MDBList signed in), so it follows
    the same switch (Provider sync enabled), the same interval (Provider sync interval) and the same button.
    """
    if not force and not provider_sync_enabled():
        return {'ok': True, 'mode': 'watchvault_only', 'providers': []}

    max_seq = wv.last_seq()
    results = []
    providers = []
    if _setting_bool('mdblist_sync_enabled', False):
        providers.append(('mdblist', mdblist_push))
    if _setting_bool('trakt_sync_enabled', False):
        providers.append(('trakt', trakt_push))
    if _setting_bool('simkl_sync_enabled', False):
        providers.append(('simkl', simkl_push))
    if _setting_bool('punchplay_sync_enabled', False):
        providers.append(('punchplay', punchplay_push))

    for name, fn in providers:
        try:
            cursor = get_sync_cursor(name)
            delta = changes_delta(since_seq=cursor, exclude_source=name)
            need_full = force or delta.get('full') or cursor <= 0
            if need_full:
                res = fn(full=True)
            elif (delta.get('add_shows') or delta.get('remove_shows')
                  or delta.get('add_movies') or delta.get('remove_movies')):
                res = fn(delta=delta)
            else:
                res = {'ok': True, 'provider': name, 'mode': 'incremental', 'skipped': 'no_changes'}
            if res.get('ok'):
                set_sync_cursor(name, max_seq if need_full else max(cursor, int(delta.get('until') or max_seq)))
            results.append(res)
        except Exception as e:
            results.append({'ok': False, 'provider': name, 'error': str(e)})

    if playback and mdblist_signed_in():
        try:
            results.append({'ok': True, 'provider': 'mdblist', 'mode': 'playback', 'rows': mdblist_pull_playback()})
        except Exception as e:
            results.append({'ok': False, 'provider': 'mdblist', 'mode': 'playback', 'error': str(e)})
    any_ok = any(r.get('ok') for r in results) if results else True
    out = {
        'ok': any_ok if results else True,
        'mode': 'providers' if results else 'watchvault_only',
        'max_seq': max_seq,
        'providers': results,
        'ts': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    try:
        import os
        path = os.path.join(wv.data_dir(), 'provider_sync_stats.json')
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(out, f, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass
    return out



# ----- Login / device OAuth helpers (Kodi dialogs call these) -----

class TokenSaveError(RuntimeError):
    pass


def _log_token(msg):
    try:
        import xbmc
        xbmc.log('[WatchVault login] ' + msg, xbmc.LOGERROR)
    except Exception:
        pass


def _store_login_token(name, value):
    """Save a login token and read it back. Raises TokenSaveError if it did not stick."""
    value = '' if value is None else str(value)
    ad = _addon()
    if not ad:
        _log_token('%s: add-on settings object unavailable' % name)
        raise TokenSaveError('could not save %s (add-on settings unavailable)' % name)
    try:
        ad.setSettingString(name, value)
    except Exception as e:
        _log_token('%s: setSettingString failed: %r' % (name, e))
        try:
            ad.setSetting(name, value)
        except Exception as e2:
            _log_token('%s: setSetting failed: %r' % (name, e2))
            raise TokenSaveError('could not save %s: %s' % (name, e2))
    try:
        back = ad.getSettingString(name) or ''
    except Exception as e:
        _log_token('%s: read-back failed: %r' % (name, e))
        raise TokenSaveError('could not read back %s: %s' % (name, e))
    if back.strip() != value.strip():
        # Kodi can return the old value immediately after a write; the value is usually saved.
        # Only log it, so a good login is not reported as a failure.
        _log_token('%s: read back %d chars right after write, expected %d (check settings.xml)' % (name, len(back), len(value)))
    try:
        import xbmc
        xbmc.log('[WatchVault login] %s: saved and read back OK (%d chars)' % (name, len(back)), xbmc.LOGWARNING)
    except Exception:
        pass
    return True



def _profile_username(provider, token):
    """Look up the account name with the new token. Raises TokenSaveError if it cannot be read."""
    if provider == 'mdblist':
        status, res = _http_json('GET', 'https://api.mdblist.com/user', headers={
            'Authorization': 'Bearer ' + token, 'Accept': 'application/json',
            'User-Agent': 'WatchVault-ProviderSync'})
        name = (res or {}).get('username') if isinstance(res, dict) else None
    elif provider == 'trakt':
        status, res = _http_json('GET', 'https://api.trakt.tv/users/settings', headers={
            'Authorization': 'Bearer ' + token, 'trakt-api-version': '2',
            'trakt-api-key': _setting('trakt_client_id')})
        user = (res or {}).get('user') if isinstance(res, dict) else None
        name = (user or {}).get('username')
    elif provider == 'simkl':
        status, res = _http_json('GET', 'https://api.simkl.com/users/settings', headers={
            'Authorization': 'Bearer ' + token, 'simkl-api-key': _setting('simkl_client_id')})
        user = (res or {}).get('user') if isinstance(res, dict) else None
        name = (user or {}).get('name') or (user or {}).get('username')
    elif provider == 'punchplay':
        status, res = _http_json('GET', 'https://punchplay.tv/api/platform/v1/me', headers={
            'Authorization': 'Bearer ' + token})
        user = res if isinstance(res, dict) else {}
        profile = user.get('profile') if isinstance(user.get('profile'), dict) else {}
        # username can be null on some accounts; fall back to name, then display name
        name = user.get('username') or user.get('name') or profile.get('displayName')
    else:
        raise TokenSaveError('no account lookup for %s' % provider)
    if status != 200 or not name:
        raise TokenSaveError('approved, but the %s account lookup failed (status %s)' % (provider, status))
    return str(name)


def _finish_login(provider, token):
    """Verify the account with the new token; keep the login only if that works."""
    try:
        name = _profile_username(provider, token)
    except Exception:
        _store_login_token(provider + '_token', '')
        _store_login_token(provider + '_refresh_token', '')
        _store_login_token(provider + '_username', '')
        raise
    _store_login_token(provider + '_username', name)
    # Start the refresh clock from this login, so a new sign-in is not refreshed straight away.
    try:
        st = _load_state()
        st.setdefault('token_refresh', {})[provider] = time.time()
        _save_state(st)
    except Exception:
        pass
    return {'ok': True, 'token_saved': True, 'username': name}


# ----- Scheduled token refresh (keeps logins alive without re-approving) -----
# Access-token lifetimes from the provider docs; refresh a little before each expires.
TOKEN_REFRESH_EVERY = {
    'punchplay': 45 * 60,        # access token 1 hour
    'trakt': 5 * 86400,          # access token 7 days
    'simkl': 5 * 86400,          # access token 7 days
    'mdblist': 7 * 86400,        # access token 30 days
}
RETRY_AFTER_FAILURE = 3600
_TOKEN_LOCK = threading.RLock()


def _log_rate(msg):
    try:
        import xbmc
        xbmc.log('[WatchVault mdblist] ' + msg, xbmc.LOGWARNING)
    except Exception:
        pass


def _log_refresh(msg):
    try:
        import xbmc
        xbmc.log('[WatchVault token] ' + msg, xbmc.LOGWARNING)
    except Exception:
        pass


def _refresh_mdblist():
    return {'ok': bool(_mdblist_refresh_token())}


def _refresh_trakt():
    refresh = _setting('trakt_refresh_token')
    client = _setting('trakt_client_id')
    secret = _setting('trakt_client_secret')
    if not refresh or not client or not secret:
        return {'ok': False, 'error': 'missing refresh token, client id or client secret'}
    status, res = _http_json('POST', 'https://api.trakt.tv/oauth/token',
                             headers={'Content-Type': 'application/json',
                                      'trakt-api-version': '2', 'trakt-api-key': client},
                             body={'refresh_token': refresh, 'client_id': client,
                                   'client_secret': secret,
                                   'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
                                   'grant_type': 'refresh_token'})
    if status not in (200, 201) or not isinstance(res, dict) or not res.get('access_token'):
        err = (res or {}).get('error_description') if isinstance(res, dict) else ''
        if isinstance(res, dict) and res.get('error') == 'invalid_grant':
            # Legacy tokens from before Trakt's auth migration cannot be refreshed: sign in again once.
            return {'ok': False, 'status': status, 'error': 'sign in to Trakt again (%s)' % (err or 'invalid_grant')}
        return {'ok': False, 'status': status, 'error': err or res}
    _store_login_token('trakt_token', res['access_token'])
    if res.get('refresh_token'):
        _store_login_token('trakt_refresh_token', res['refresh_token'])
    return {'ok': True}


def _refresh_simkl():
    refresh = _setting('simkl_refresh_token')
    client = _setting('simkl_client_id')
    if not refresh or not client:
        return {'ok': False, 'error': 'missing refresh token or client id'}
    status, res = _http_form('https://api.simkl.com/oauth2/token', {
        'grant_type': 'refresh_token', 'client_id': client, 'refresh_token': refresh})
    if status not in (200, 201) or not isinstance(res, dict) or not res.get('access_token'):
        return {'ok': False, 'status': status}
    _store_login_token('simkl_token', res['access_token'])
    if res.get('refresh_token'):
        _store_login_token('simkl_refresh_token', res['refresh_token'])
    return {'ok': True}


def _refresh_punchplay():
    refresh = _setting('punchplay_refresh_token')
    client = _setting('punchplay_client_id')
    if not refresh or not client:
        return {'ok': False, 'error': 'missing refresh token or client id'}
    status, res = _http_json('POST', 'https://punchplay.tv/api/platform/v1/auth/refresh',
                             body={'client_id': client, 'refresh_token': refresh})
    if not isinstance(res, dict):
        return {'ok': False, 'status': status}
    token = res.get('access_token') or res.get('accessToken')
    if status not in (200, 201) or not token:
        return {'ok': False, 'status': status}
    # Refresh rotates the pair: store the new refresh token before anything else uses it.
    _store_login_token('punchplay_token', token)
    new_refresh = res.get('refresh_token') or res.get('refreshToken')
    if new_refresh:
        _store_login_token('punchplay_refresh_token', new_refresh)
    return {'ok': True}


def refresh_tokens_if_due(force=False):
    """Refresh each provider's token when its access-token lifetime is nearly used up."""
    with _TOKEN_LOCK:
        st = _load_state()
        last = st.get('token_refresh') or {}
        retry = st.get('token_retry') or {}
        now = time.time()
        out = {}
        funcs = (('punchplay', _refresh_punchplay), ('trakt', _refresh_trakt),
                 ('simkl', _refresh_simkl), ('mdblist', _refresh_mdblist))
        for name, fn in funcs:
            if not _setting(name + '_refresh_token'):
                continue
            if not force:
                if now - float(last.get(name) or 0) <= TOKEN_REFRESH_EVERY[name]:
                    continue
                if now < float(retry.get(name) or 0):
                    continue
            try:
                res = fn()
            except Exception as e:
                res = {'ok': False, 'error': str(e)}
            if res.get('ok'):
                last[name] = now
                retry.pop(name, None)
                _log_refresh('%s refreshed' % name)
            else:
                retry[name] = now + RETRY_AFTER_FAILURE
                _log_refresh('%s refresh failed, retry in 1 hour: %s' % (name, res))
            out[name] = res
        st['token_refresh'] = last
        st['token_retry'] = retry
        _save_state(st)
        return out



# ----- Deauthorise: revoke on the provider, then clear this device's tokens -----
REVOKE_LABELS = {'mdblist': 'MDBList', 'trakt': 'Trakt', 'simkl': 'Simkl', 'punchplay': 'PunchPlay'}


def _clear_provider_local(provider):
    for suffix in ('_token', '_refresh_token', '_username'):
        _set_setting(provider + suffix, '')
    st = _load_state()
    for key in ('token_refresh', 'token_retry'):
        bag = st.get(key) or {}
        bag.pop(provider, None)
        st[key] = bag
    _save_state(st)


def _revoke_calls(provider):
    """Return (label, status, res) for each revoke request the provider needs."""
    out = []
    if provider == 'mdblist':
        client = _mdblist_client_id()
        for name in ('mdblist_token', 'mdblist_refresh_token'):
            tok = _setting(name)
            if tok:
                s, r = _http_form('https://api.mdblist.com/oauth/revoke_token/', {'token': tok, 'client_id': client})
                out.append((name, s, r))
    elif provider == 'trakt':
        client, secret = _setting('trakt_client_id'), _setting('trakt_client_secret')
        for name in ('trakt_token',):
            tok = _setting(name)
            if tok:
                s, r = _http_json('POST', 'https://api.trakt.tv/oauth/revoke',
                                  headers={'Content-Type': 'application/json', 'trakt-api-version': '2',
                                           'trakt-api-key': client},
                                  body={'token': tok, 'client_id': client, 'client_secret': secret})
                out.append((name, s, r))
    elif provider == 'simkl':
        client = _setting('simkl_client_id')
        tok = _setting('simkl_refresh_token') or _setting('simkl_token')   # revoking either ends the grant
        if tok:
            s, r = _http_form('https://api.simkl.com/oauth2/revoke', {'client_id': client, 'token': tok})
            out.append(('simkl', s, r))
    elif provider == 'punchplay':
        client = _setting('punchplay_client_id')
        for name, hint in (('punchplay_token', 'access_token'), ('punchplay_refresh_token', 'refresh_token')):
            tok = _setting(name)
            if tok:
                s, r = _http_json('POST', 'https://punchplay.tv/api/platform/v1/oauth/revoke',
                                  body={'client_id': client, 'token': tok, 'token_type_hint': hint})
                out.append((name, s, r))
    return out


def revoke_provider(provider):
    """Revoke at the provider and clear local tokens. Local tokens are cleared even if the server call fails."""
    if provider not in REVOKE_LABELS:
        return {'ok': False, 'error': 'unknown provider'}
    with _TOKEN_LOCK:
        try:
            calls = _revoke_calls(provider)
        except Exception as e:
            calls = [('error', 0, {'error': str(e)})]
        _clear_provider_local(provider)
    failed = [c for c in calls if c[1] not in (200, 201, 204)]
    _log_refresh('%s deauthorised: %d revoke call(s), %d failed' % (provider, len(calls), len(failed)))
    return {'ok': not failed, 'calls': len(calls), 'failed': [(c[0], c[1]) for c in failed]}


def mdblist_watched_rows(limit=1000):
    """Yield (kind, row) for each movie and episode in MDBList's watched history, one page at a time."""
    if not _mdblist_token():
        raise RuntimeError('MDBList is not signed in')
    cursor = None
    while True:
        q = 'sync/watched?limit=%d&append_to_response=tvdb' % limit
        if cursor:
            q += '&cursor=' + urllib.parse.quote(cursor, safe='')
        status, res = _mdblist_request('GET', q)
        if status == 429:
            raise RuntimeError('MDBList rate limit reached; run the import again later')
        if status != 200 or not isinstance(res, dict):
            raise RuntimeError('MDBList returned HTTP %s' % status)
        for row in res.get('movies') or []:
            yield 'movie', row
        for row in res.get('episodes') or []:
            yield 'episode', row
        cursor = (res.get('pagination') or {}).get('next_cursor')
        if not cursor:
            break


# ----- Watched-history readers for the one-time import (add-only; see history_import.py) -----
def _get_with_refresh(provider, url, headers, query=''):
    """GET with the stored token. On 401 refresh once and retry. Returns (status, body)."""
    refresh_fn = {'trakt': _refresh_trakt, 'simkl': _refresh_simkl, 'punchplay': _refresh_punchplay}[provider]
    status, res = 0, {}
    for attempt in (0, 1):
        tok = _setting(provider + '_token')
        if not tok:
            raise RuntimeError('%s is not signed in' % provider.capitalize())
        h = dict(headers)
        h['Authorization'] = 'Bearer ' + tok
        status, res = _http_json('GET', url + query, headers=h)
        if status == 401 and attempt == 0:
            if not refresh_fn().get('ok'):
                return status, res
            continue
        return status, res
    return status, res


def trakt_history_rows(limit=100):
    client = _setting('trakt_client_id')
    headers = {'trakt-api-version': '2', 'trakt-api-key': client, 'Content-Type': 'application/json'}
    page = 1
    while True:
        q = '?' + urllib.parse.urlencode({'page': page, 'limit': limit})
        status, res = _get_with_refresh('trakt', 'https://api.trakt.tv/sync/history', headers, q)
        if status == 429:
            raise RuntimeError('Trakt rate limit reached; run the import again later')
        if status != 200 or not isinstance(res, list):
            raise RuntimeError('Trakt returned HTTP %s' % status)
        for row in res:
            yield 'trakt', row
        if len(res) < limit:
            break
        page += 1
        time.sleep(0.3)


def punchplay_history_rows(limit=100):
    cursor = None
    while True:
        q = {'limit': limit}
        if cursor:
            q['cursor'] = cursor
        status, res = _get_with_refresh('punchplay', 'https://punchplay.tv/api/platform/v1/me/history', {},
                                        '?' + urllib.parse.urlencode(q))
        if status == 429:
            raise RuntimeError('PunchPlay rate limit reached; run the import again later')
        if status != 200 or not isinstance(res, dict):
            raise RuntimeError('PunchPlay returned HTTP %s' % status)
        for row in res.get('items') or []:
            yield 'punchplay', row
        cursor = res.get('nextCursor')
        if not cursor:
            break
        time.sleep(0.3)


def _simkl_all_items(headers, path, extra):
    q = dict(extra)
    q['client_id'] = _setting('simkl_client_id')
    q['app-name'] = 'WatchVault'
    q['app-version'] = '1.5.36'
    return _get_with_refresh('simkl', 'https://api.simkl.com/' + path, headers,
                             '?' + urllib.parse.urlencode(q))


def simkl_watched_rows():
    """Shows and anime with their watched episodes (watched_at), and movies in the completed bucket."""
    headers = {'User-Agent': 'WatchVault/1.5.36 (Kodi)'}
    episode_opts = {'extended': 'full', 'episode_watched_at': 'yes', 'include_all_episodes': 'yes',
                    'episode_tvdb_id': 'yes'}
    for kind in ('shows', 'anime'):
        status, res = _simkl_all_items(headers, 'sync/all-items/' + kind, episode_opts)
        if status == 400 and isinstance(res, dict) and res.get('error') == 'max_items':
            # too big for one call: one status at a time
            for bucket in ('watching', 'completed', 'dropped', 'hold', 'plantowatch'):
                status, res = _simkl_all_items(headers, 'sync/all-items/%s/%s' % (kind, bucket), episode_opts)
                if status != 200 or not isinstance(res, dict):
                    raise RuntimeError('Simkl returned HTTP %s' % status)
                for item in res.get(kind) or []:
                    yield 'show', item
            continue
        if status == 429:
            raise RuntimeError('Simkl rate limit reached; run the import again later')
        if status != 200 or not isinstance(res, dict):
            raise RuntimeError('Simkl returned HTTP %s' % status)
        for item in res.get(kind) or []:
            yield 'show', item
    status, res = _simkl_all_items(headers, 'sync/all-items/movies/completed', {})
    if status != 200 or not isinstance(res, dict):
        raise RuntimeError('Simkl returned HTTP %s' % status)
    for item in res.get('movies') or []:
        yield 'movie', item

def _set_setting(name, value):
    ad = _addon()
    if not ad:
        return
    try:
        ad.setSettingString(name, value if value is not None else '')
    except Exception:
        try:
            ad.setSetting(name, value if value is not None else '')
        except Exception:
            pass


def mdblist_test_key():
    if not _mdblist_token():
        return {'ok': False, 'error': 'no_token'}
    status, res = _mdblist_request('GET', 'user')
    if status != 200:
        return {'ok': False, 'status': status, 'error': res}
    return {'ok': True, 'username': (res or {}).get('username'), 'user_id': (res or {}).get('user_id')}



def trakt_device_start():
    client = (_setting('trakt_client_id') or '').strip()
    secret = (_setting('trakt_client_secret') or '').strip()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client,
    }
    status, res = _http_json(
        'POST', 'https://api.trakt.tv/oauth/device/code',
        headers=headers, body={'client_id': client})
    if status not in (200, 201) or not isinstance(res, dict):
        return {'ok': False, 'status': status, 'error': res}
    res['ok'] = True
    res['_client_id'] = client
    res['_client_secret'] = secret
    return res


def trakt_device_poll(device_code, client_id=None, client_secret=None):
    client = (client_id or _setting('trakt_client_id') or '').strip()
    secret = (client_secret or _setting('trakt_client_secret') or '').strip()
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client,
    }
    body = {
        'code': device_code,
        'client_id': client,
        'client_secret': secret,
    }
    status, res = _http_json(
        'POST', 'https://api.trakt.tv/oauth/device/token',
        headers=headers, body=body)
    if status in (200, 201) and isinstance(res, dict) and res.get('access_token'):
        _store_login_token('trakt_token', res['access_token'])
        if res.get('refresh_token'):
            _store_login_token('trakt_refresh_token', res['refresh_token'])
        return _finish_login('trakt', res['access_token'])
    return {'ok': False, 'status': status, 'error': res}


def simkl_device_start():
    client = (_setting('simkl_client_id') or '').strip()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    status, res = _http_form('https://api.simkl.com/oauth2/device',
                             {'client_id': client, 'scope': 'media:read media:write'})
    if status not in (200, 201) or not isinstance(res, dict):
        return {'ok': False, 'status': status, 'error': res}
    res['ok'] = True
    return res


def simkl_device_poll(device_code, client_id=None):
    client = (client_id or _setting('simkl_client_id') or '').strip()
    status, res = _http_form('https://api.simkl.com/oauth2/token', {
        'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
        'client_id': client, 'device_code': device_code})
    if status in (200, 201) and isinstance(res, dict) and res.get('access_token'):
        _store_login_token('simkl_token', res['access_token'])
        if res.get('refresh_token'):
            _store_login_token('simkl_refresh_token', res['refresh_token'])
        return _finish_login('simkl', res['access_token'])
    return {'ok': False, 'status': status, 'error': res}


def punchplay_save_tokens(access_token, refresh_token=None):
    access_token = (access_token or '').strip()
    if not access_token:
        return {'ok': False, 'error': 'empty_token'}
    _store_login_token('punchplay_token', access_token)
    if refresh_token:
        _store_login_token('punchplay_refresh_token', refresh_token.strip())
    return {'ok': True}


# ----- MDBList in-progress (sync/playback) -> WatchVault progress rows -----
def mdblist_signed_in():
    return bool(_mdblist_token())


def mdblist_playback_rows(limit=1000):
    """Yield MDBList's in-progress items (sync/playback), one page at a time."""
    if not _mdblist_token():
        raise RuntimeError('MDBList is not signed in')
    cursor = None
    while True:
        q = 'sync/playback?limit=%d' % limit
        if cursor:
            q += '&cursor=' + urllib.parse.quote(cursor, safe='')
        status, res = _mdblist_request('GET', q)
        if status == 429:
            raise RuntimeError('MDBList rate limit reached; try again later')
        if status != 200 or not isinstance(res, dict):
            raise RuntimeError('MDBList returned HTTP %s' % status)
        for item in res.get('items') or []:
            yield item
        pagination = res.get('pagination') or {}
        cursor = pagination.get('next_cursor')
        if not pagination.get('has_more') or not cursor:
            break


def _mdbl_tmdb(ids):
    try:
        return int((ids or {}).get('tmdb') or 0) or None
    except (TypeError, ValueError):
        return None


def mdblist_progress_rows(items):
    """MDBList playback items -> progress rows. As in MDBList's own cache: over 1% only, and season 0 is left out."""
    out = []
    for item in items:
        try:
            pct = float(item.get('progress') or 0)
        except (TypeError, ValueError):
            continue
        if pct <= 1:
            continue
        paused, pid, kind = item.get('paused_at') or '', item.get('id'), item.get('type')
        if kind == 'movie':
            movie = item.get('movie') or {}
            tmdb = _mdbl_tmdb(movie.get('ids'))
            if tmdb:
                out.append({'kind': 'movie', 'show_tmdb': tmdb, 'season': 0, 'episode': 0,
                            'title': movie.get('title') or '', 'year': movie.get('year'),
                            'percent': pct, 'paused_at': paused, 'provider_id': pid})
        elif kind == 'episode':
            ep = item.get('episode') or {}
            show = item.get('show') or {}
            tmdb = _mdbl_tmdb(show.get('ids'))
            try:
                season, number = int(ep.get('season')), int(ep.get('number'))
            except (TypeError, ValueError):
                continue
            if tmdb and season > 0:
                out.append({'kind': 'episode', 'show_tmdb': tmdb, 'season': season, 'episode': number,
                            'title': show.get('title') or '', 'year': show.get('year'),
                            'percent': pct, 'paused_at': paused, 'provider_id': pid})
    return out


def mdblist_pull_playback():
    """Replace WatchVault's MDBList in-progress rows with MDBList's current playback. Returns the row count."""
    rows = mdblist_progress_rows(list(mdblist_playback_rows()))
    return wv.progress_replace('mdblist', rows)
