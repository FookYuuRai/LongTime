# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
import watchvault as wv  # noqa: E402

BACKUP_NAME = 'watchvault-backup.json'


_EPISODE_ORDER = ('official', 'default', 'absolute', 'dvd', 'alternate')

def _episode_order_name(addon=None):
    try:
        ad = addon or cfg()
        # new int list setting; fall back to legacy string
        try:
            idx = int(ad.getSettingInt('episode_order'))
            return _EPISODE_ORDER[idx] if 0 <= idx < len(_EPISODE_ORDER) else 'official'
        except Exception:
            pass
        val = (ad.getSettingString('episode_order') or 'official').strip().lower()
        return val if val in _EPISODE_ORDER else 'official'
    except Exception:
        return 'official'


def log(msg):
    xbmc.log('[WatchVault] %s' % msg, xbmc.LOGINFO)


_CFG = None
_CFG_TS = 0.0

def cfg():
    global _CFG, _CFG_TS
    now = time.time()
    if _CFG is None or now - _CFG_TS > 5.0:
        _CFG = xbmcaddon.Addon()
        _CFG_TS = now
    return _CFG


def _safe_setting_str(name, default=''):
    try:
        val = (cfg().getSettingString(name) or default).strip()
    except Exception:
        try:
            val = (cfg().getSetting(name) or default).strip()
        except Exception:
            return default
    # Kodi 22 needs a non-empty XML default; we use a single space placeholder.
    return val if val else default


def _safe_setting_bool(name, default=False):
    try:
        return bool(cfg().getSettingBool(name))
    except Exception:
        return default


def _safe_setting_int(name, default=0):
    try:
        return int(cfg().getSettingInt(name))
    except Exception:
        return default


def _source_from(path):
    m = re.match(r'^plugin://([^/]+)/', path or '')
    return m.group(1) if m else None



def _is_video_playback(player):
    """True only for real video playback (not music/ambience/pictures)."""
    try:
        if not player.isPlaying():
            return False
    except Exception:
        return False
    try:
        if player.isPlayingVideo():
            return True
    except Exception:
        pass
    # Fallback: media type labels
    try:
        mt = (xbmc.getInfoLabel('Player.Fileextension') or '').lower()
        if mt in ('mp3', 'flac', 'aac', 'ogg', 'opus', 'wav', 'm4a', 'wma'):
            return False
    except Exception:
        pass
    try:
        return bool(xbmc.getCondVisibility('Player.HasVideo'))
    except Exception:
        return False


def _is_audio_path(path):
    p = (path or '').lower().split('?', 1)[0]
    if not p:
        return False
    for ext in ('.mp3', '.flac', '.aac', '.ogg', '.opus', '.wav', '.m4a', '.wma', '.ape', '.mpa'):
        if p.endswith(ext):
            return True
    # Nightshift ambience / theme plugins often use these hosts
    if 'ambience' in p or 'theme_song' in p or 'themesong' in p:
        return True
    return False


def _ignore_source(source):
    """Skip known non-library video sources that should not create history."""
    if not source:
        return False
    s = source.lower()
    skip = (
        'script.service.nightshift.ambience',
        'service.nightshift',
        'plugin.video.watchvault',
    )
    return any(x in s for x in skip)


def _blank(v):
    return v is None or v == ''


class HistoryService(xbmc.Player):
    """History service: updates watch history from playback."""

    def __init__(self):
        super().__init__()
        self.cur = None
        self.pos = 0.0
        self.total = 0.0

    # ---- Kodi callbacks
    def onAVStarted(self):
        self.pos = self.total = 0.0
        try:
            if not _is_video_playback(self):
                self.cur = None
                return
            self.cur = self._snapshot()
        except Exception as e:  # never let a bad plugin crash the service
            log('snapshot failed: %s' % e)
            self.cur = None

    def onPlayBackEnded(self):
        self._finish(True)

    def onPlayBackStopped(self):
        self._finish(False)

    def onPlayBackError(self):
        self.cur = None

    # ---- logic
    def _snapshot(self):
        win = xbmcgui.Window(10000)
        ann = {}
        raw = win.getProperty('watchvault.announce')
        if raw:
            win.clearProperty('watchvault.announce')
            try:
                ann = json.loads(raw)
                if time.time() - float(ann.get('ts', 0)) > 180:
                    ann = {}
            except ValueError:
                ann = {}

        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            playing = ''
        source = ann.get('source') or _source_from(playing) or _source_from(
            xbmc.getInfoLabel('Player.Filenameandpath')) or xbmc.getInfoLabel('Container.PluginName') or None

        mode = _safe_setting_int('track_mode', 0)  # 0 = only add-ons I added, 1 = everything
        src_row = wv.get_source(source)
        if mode == 0 and not (src_row and src_row['enabled']):
            return None
        if src_row is not None and not src_row['enabled']:
            return None
        if _ignore_source(source):
            return None
        if _is_audio_path(playing) or _is_audio_path(xbmc.getInfoLabel('Player.Filenameandpath')):
            return None
        if not _is_video_playback(self):
            return None

        info = {'title': None, 'year': None, 'season': None, 'episode': None,
                'tvdb_id': None, 'imdb_id': None, 'tmdb_id': None,
                'anilist_id': None, 'mal_id': None,
                'episode_tvdb_id': None, 'episode_imdb_id': None, 'episode_tmdb_id': None,
                'episode_anilist_id': None, 'episode_mal_id': None}
        mediatype = ''
        try:
            tag = self.getVideoInfoTag()
            mediatype = tag.getMediaType()
            if mediatype == 'episode':
                info['title'] = tag.getTVShowTitle()
                info['season'] = tag.getSeason() if tag.getSeason() >= 0 else None
                info['episode'] = tag.getEpisode() if tag.getEpisode() >= 0 else None
            else:
                info['title'] = tag.getTitle() or tag.getOriginalTitle()
            info['year'] = tag.getYear() or None
            show_keys = (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'),
                         ('anilist', 'anilist_id'), ('mal', 'mal_id'))
            ep_keys = (('tvdb', 'episode_tvdb_id'), ('imdb', 'episode_imdb_id'),
                       ('tmdb', 'episode_tmdb_id'), ('anilist', 'episode_anilist_id'),
                       ('mal', 'episode_mal_id'))
            for key, fld in show_keys:
                try:
                    v = tag.getUniqueID(key)
                    if v:
                        info[fld] = v
                except Exception:
                    pass
            if mediatype == 'episode':
                for key, fld in ep_keys:
                    try:
                        v = tag.getUniqueID('episode.' + key)
                        if v:
                            info[fld] = v
                    except Exception:
                        pass
            try:  # a movie's own tvdb id, or an explicit show-level id
                keys = ('tvshow.tvdb', 'tvdb') if mediatype == 'episode' else ('tvdb',)
                for k in keys:
                    v = tag.getUniqueID(k)
                    if v:
                        info['tvdb_id'] = v
                        break
            except Exception:
                pass
        except RuntimeError:
            pass
        if not info['title']:
            info['title'] = xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or xbmc.getInfoLabel('VideoPlayer.Title')
        if not mediatype:
            mediatype = 'episode' if xbmc.getInfoLabel('VideoPlayer.TVShowTitle') else 'movie'
            if mediatype == 'episode':
                info['season'] = xbmc.getInfoLabel('VideoPlayer.Season')
                info['episode'] = xbmc.getInfoLabel('VideoPlayer.Episode')
        for key, fld in (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'), ('tvdb', 'tvdb_id'),
                         ('anilist', 'anilist_id'), ('mal', 'mal_id')):
            if _blank(info.get(fld)):
                v = xbmc.getInfoLabel('VideoPlayer.UniqueID(%s)' % key)
                if not _blank(v):
                    info[fld] = v
        info.update({k: v for k, v in ann.items() if k in info and not _blank(v)})
        if ann and not _blank(info.get('season')) and not _blank(info.get('episode')):
            mediatype = 'episode'       # an explicit announce wins over Kodi's guess
        elif mediatype in ('', 'video'):
            mediatype = 'movie'
        if mediatype == 'episode' and (_blank(info.get('season')) or _blank(info.get('episode'))):
            return None
        if mediatype == 'movie':
            info['season'] = info['episode'] = None
            for key in ('episode_tvdb_id', 'episode_imdb_id', 'episode_tmdb_id',
                        'episode_anilist_id', 'episode_mal_id'):
                info[key] = None
        named = (info['title'], info['tvdb_id'], info['imdb_id'], info['tmdb_id'],
                 info['anilist_id'], info['mal_id'])
        if mediatype not in ('episode', 'movie') or not any(not _blank(v) for v in named):
            return None
        info['episode_title'] = ann.get('episode_title') or (
            xbmc.getInfoLabel('VideoPlayer.Title') if mediatype == 'episode' else None)
        info['aired'] = ann.get('aired')
        return {'info': info, 'source': source}

    def tick(self):
        if self.cur and not _is_video_playback(self):
            # Theme/ambience took over — abandon incomplete video session
            self.cur = None
            return
        if self.cur and _is_video_playback(self):
            try:
                self.pos = self.getTime()
                self.total = self.getTotalTime()
            except RuntimeError:
                pass

    def _timing(self, ended):
        total = self.total if self.total and self.total > 0 else 0.0
        pos = self.pos if self.pos and self.pos > 0 else 0.0
        if total and pos > total:
            pos = total
        if not total:
            return None, None
        runtime = int(round(total))
        if ended:
            remaining = 0
        else:
            remaining = max(0, int(round(total - pos)))
        return runtime, remaining

    def _finish(self, ended):
        cur, self.cur = self.cur, None
        if not cur:
            return
        pct = 100.0 if ended else (self.pos / self.total * 100.0 if self.total > 0 else 0.0)
        runtime, remaining = self._timing(ended)
        extra = {}
        if runtime is not None:
            extra['runtime'] = runtime
        if remaining is not None:
            extra['remaining'] = remaining
        if pct < _safe_setting_int('threshold', 90):
            if extra:
                wv.save_progress(source=cur['source'], **cur['info'], **extra)
                log('progress %s from %s runtime=%s remaining=%s' % (
                    cur['info'].get('title'), cur['source'], runtime, remaining))
            return
        res = wv.mark_watched(source=cur['source'], **cur['info'], **extra)
        log('marked %s from %s: %s' % (cur['info'].get('title'), cur['source'], res))
        if res.get('ok') and _safe_setting_bool('notify', True):
            i = cur['info']
            label = i['title'] if _blank(i.get('season')) else '%s S%02dE%02d' % (
                i['title'], int(i['season']), int(i['episode']))
            xbmcgui.Dialog().notification(
                cfg().getAddonInfo('name') or 'WatchVault',
                cfg().getLocalizedString(30120) % label,
                xbmcgui.NOTIFICATION_INFO, 2500, False)
        self._maybe_catalog(i=cur['info'])

    def _maybe_catalog(self, i):
        c = cfg()
        key = _safe_setting_str('tvdb_key')
        if i.get('season') is None or not key or not _safe_setting_bool('fetch_catalog'):
            return
        try:
            import tvdb_catalog
            with wv.db() as con:
                sid = wv._show_id(con, i['title'], i.get('year'), i.get('tvdb_id'), i.get('imdb_id'),
                                  i.get('tmdb_id'), create=False)
                have = con.execute('SELECT COUNT(*) FROM episodes WHERE show_id=? AND watched=0',
                                   (sid,)).fetchone()[0] if sid else 1
            if sid and not have:
                c2 = cfg()
                tvdb_catalog.fill_show(key, sid, season_type=_episode_order_name(c2),
                                       original_names=_safe_setting_bool('original_names', True))
        except Exception as e:
            log('catalog fetch failed: %s' % e)


# ------------------------------------------------------------------ backups
def _backup_dir():
    folder = _safe_setting_str('backup_path')
    return folder or None


def _write_backup():
    folder = _backup_dir()
    if not folder or not _safe_setting_bool('auto_backup'):
        return
    tmp = os.path.join(xbmcvfs.translatePath('special://temp/'), BACKUP_NAME)
    wv.export_json(tmp)
    dest = xbmcvfs.makeLegalFilename(folder.rstrip('/\\') + '/' + BACKUP_NAME) if not folder.startswith(
        ('smb://', 'nfs://', 'special://')) else folder.rstrip('/') + '/' + BACKUP_NAME
    if xbmcvfs.exists(dest):
        xbmcvfs.delete(dest)
    xbmcvfs.copy(tmp, dest)


def _restore_if_empty():
    folder = _backup_dir()
    c = wv.counts()
    if not folder or c['shows'] or c['movies']:
        return
    src = folder.rstrip('/\\') + '/' + BACKUP_NAME
    if not xbmcvfs.exists(src):
        return
    tmp = os.path.join(xbmcvfs.translatePath('special://temp/'), 'watchvault-restore.json')
    if xbmcvfs.copy(src, tmp):
        try:
            res = wv.import_json(tmp)
            log('restored from automatic backup: %s' % res)
            xbmcgui.Dialog().notification(
                cfg().getAddonInfo('name') or 'WatchVault',
                cfg().getLocalizedString(30121),
                xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception as e:
            log('restore failed: %s' % e)


def _refresh_anime():
    try:
        import anime_data
        log('anime datasets refresh starting')
        result = anime_data.update(force=False)
        log('anime datasets %s' % result)
        try:
            wv.fill_local_ids(missing_anime=True)
        except Exception as e:
            log('anime local fill after refresh: %s' % e)
    except Exception as e:
        log('anime datasets refresh error: %s' % e)



def _batch_fill_network():
    """Periodic TVDB network fill for missing TVDB ids (remote-id then name)."""
    c = cfg()
    if not _safe_setting_bool('sync_fill_enabled'):
        return
    key = _safe_setting_str('tvdb_key')
    if not key:
        log('sync fill skipped: no TVDB key')
        return
    try:
        limit = _safe_setting_int('sync_fill_batch', 50) or 50
    except Exception:
        limit = 50
    try:
        # Local first (no network), then TVDB batch
        local = wv.fill_local_ids(missing_anime=True)
        log('sync local fill %s' % local)
        net = wv.batch_fill_network(api_key=key, limit=limit)
        log('sync network fill %s' % net)
    except Exception as e:
        log('sync fill failed: %s' % e)


_PROVIDER_SYNC_LOCK = threading.Lock()


def _provider_sync(force=False):
    if not _PROVIDER_SYNC_LOCK.acquire(blocking=False):
        return                      # one push at a time; a run already in progress covers these changes
    try:
        import provider_sync
        if not force and not provider_sync.provider_sync_enabled():
            return
        res = provider_sync.run_provider_sync(force=force)
        log('provider sync %s' % res)
    except Exception as e:
        log('provider sync failed: %s' % e)
    finally:
        _PROVIDER_SYNC_LOCK.release()




def _check_pending_dbcount():
    """Open the Database count window once the settings dialog has closed."""
    try:
        w = xbmcgui.Window(10000)
        if w.getProperty('watchvault.dbcount.pending') != '1':
            return
        if xbmcgui.getCurrentWindowDialogId() != 9999:
            return
        heading = w.getProperty('watchvault.dbcount.heading') or 'Database count'
        text = w.getProperty('watchvault.dbcount.text') or ''
        w.clearProperty('watchvault.dbcount.pending')
        w.clearProperty('watchvault.dbcount.text')
        w.clearProperty('watchvault.dbcount.heading')
        import fullscreen
        threading.Thread(target=fullscreen.show_fullscreen_text, args=(heading, text), daemon=True).start()
    except Exception as e:
        xbmc.log('[WatchVault] deferred database count failed: %s' % e, xbmc.LOGERROR)



def _token_refresh():
    try:
        import provider_sync as _ps
        _ps.refresh_tokens_if_due()
    except Exception as e:
        log('token refresh error: %s' % e)


def _login_loop(monitor):
    try:
        import login_flow
    except Exception as e:
        log('login flow unavailable: %s' % e)
        return
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        try:
            login_flow.step()
        except Exception as e:
            log('login step error: %s' % e)
        try:
            import history_import
            history_import.tick()
        except Exception as e:
            log('import tick error: %s' % e)


def main():
    monitor = xbmc.Monitor()
    threading.Thread(target=_login_loop, args=(monitor,), daemon=True).start()
    player = HistoryService()
    log('history service started')
    try:
        _restore_if_empty()
    except Exception as e:
        log('restore error: %s' % e)
    threading.Thread(target=_refresh_anime, daemon=True).start()
    last_seq = wv.last_seq()
    last_backup = time.time()
    last_anime = time.time()
    last_sync = time.time() - 5 * 60  # first run ~5 min after start (adjusted by interval check)
    last_provider_sync = 0
    last_token_check = 0
    try:
        last_provider_seq = wv.last_seq()
    except Exception as e:
        # The store can be locked for a moment at startup. Do not stop the service; the loop reads it again.
        log('start: change counter not readable yet: %s' % e)
        last_provider_seq = -1
    last_seq_check = 0.0
    sync_due = 0
    # Kick first network fill shortly after start without blocking
    def _deferred_sync():
        monitor.waitForAbort(5 * 60)
        if not monitor.abortRequested():
            _batch_fill_network()
    threading.Thread(target=_deferred_sync, daemon=True).start()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        _check_pending_dbcount()
        player.tick()
        if time.time() - last_backup > 120:
            try:
                seq = wv.last_seq()
                if seq != last_seq:
                    _write_backup()
                    last_seq = seq
            except Exception as e:
                log('backup error: %s' % e)
            last_backup = time.time()
        if time.time() - last_token_check > 10 * 60:
            threading.Thread(target=_token_refresh, daemon=True).start()
            last_token_check = time.time()
        if time.time() - last_anime > 24 * 60 * 60:
            threading.Thread(target=_refresh_anime, daemon=True).start()
            last_anime = time.time()
        try:
            interval_h = _safe_setting_int('sync_fill_hours', 6) or 6
        except Exception:
            interval_h = 6
        if _safe_setting_bool('sync_fill_enabled') and time.time() - last_sync > interval_h * 3600:
            threading.Thread(target=_batch_fill_network, daemon=True).start()
            last_sync = time.time()
        try:
            import provider_sync as _ps
            if _ps.provider_sync_enabled():
                interval_s = _ps.sync_interval_seconds()
                if time.time() - last_provider_sync > interval_s:
                    threading.Thread(target=_provider_sync, daemon=True).start()
                    last_provider_sync = time.time()
                # Push after local marks change: check the change counter every 5 s, and run one push about
                # 20 s after the last change, not one thread per change (an import used to start one per second).
                if _safe_setting_bool('provider_sync_on_mark') and time.time() - last_seq_check >= 5:
                    last_seq_check = time.time()
                    seq = wv.last_seq()
                    if seq != last_provider_seq:
                        last_provider_seq = seq
                        sync_due = sync_due or time.time() + 20
                if sync_due and time.time() >= sync_due:
                    sync_due = 0
                    threading.Thread(target=_provider_sync, daemon=True).start()
        except Exception as e:
            log('provider sync schedule error: %s' % e)
    try:
        _write_backup()
    except Exception as e:
        log('final backup error: %s' % e)


if __name__ == '__main__':
    main()
