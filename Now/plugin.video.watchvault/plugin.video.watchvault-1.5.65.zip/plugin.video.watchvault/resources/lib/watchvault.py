# -*- coding: utf-8 -*-
"""WatchVault core: a local watch-history database plus a small API that other
Kodi add-ons can call. Works inside Kodi and (for testing) outside it.

Identity rules
  * TV episodes are stored under their show (tvdb id preferred, title+year as
    fallback) as season / episode.  Season 0 = specials (TVDB aired order).
  * Movies are stored by tvdb id (imdb / tmdb optional) or title+year.
Nothing in here talks to the internet.
"""
import json
import os
import re
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime

ADDON_ID = 'plugin.video.watchvault'
FORMAT = 'watchvault'
FORMAT_VERSION = 1
CHANGE_LOG_LIMIT = 5000

SCHEMA = """
CREATE TABLE IF NOT EXISTS shows(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tvdb_id INTEGER UNIQUE, imdb_id TEXT, tmdb_id INTEGER,
  anilist_id INTEGER, mal_id INTEGER,
  title TEXT NOT NULL, year INTEGER, created TEXT);
CREATE INDEX IF NOT EXISTS ix_shows_title ON shows(title COLLATE NOCASE);
CREATE TABLE IF NOT EXISTS episodes(
  show_id INTEGER NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
  season INTEGER NOT NULL, episode INTEGER NOT NULL,
  tvdb_id INTEGER, imdb_id TEXT, tmdb_id INTEGER, anilist_id INTEGER, mal_id INTEGER,
  title TEXT, aired TEXT,
  watched INTEGER NOT NULL DEFAULT 0,
  play_count INTEGER NOT NULL DEFAULT 0,
  last_watched TEXT,
  runtime INTEGER, remaining INTEGER,
  is_movie INTEGER NOT NULL DEFAULT 0,
  episode_type TEXT,
  movie_tvdb_id INTEGER,
  PRIMARY KEY(show_id, season, episode));
CREATE TABLE IF NOT EXISTS movies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tvdb_id INTEGER UNIQUE, imdb_id TEXT, tmdb_id INTEGER,
  anilist_id INTEGER, mal_id INTEGER,
  title TEXT NOT NULL, year INTEGER,
  watched INTEGER NOT NULL DEFAULT 0,
  play_count INTEGER NOT NULL DEFAULT 0,
  last_watched TEXT, created TEXT,
  runtime INTEGER, remaining INTEGER);
CREATE TABLE IF NOT EXISTS negative_cache(
  media TEXT NOT NULL,
  media_id INTEGER NOT NULL,
  method TEXT NOT NULL,
  key TEXT NOT NULL,
  ts TEXT NOT NULL,
  PRIMARY KEY(media, media_id, method));
CREATE TABLE IF NOT EXISTS id_sources(
  media TEXT NOT NULL,
  media_id INTEGER NOT NULL,
  field TEXT NOT NULL,
  value TEXT NOT NULL,
  source TEXT NOT NULL,
  ts TEXT,
  PRIMARY KEY(media, media_id, field));
CREATE TABLE IF NOT EXISTS sources(
  addon_id TEXT PRIMARY KEY, name TEXT,
  enabled INTEGER NOT NULL DEFAULT 1,
  ack_seq INTEGER NOT NULL DEFAULT 0, added TEXT);
CREATE TABLE IF NOT EXISTS changes(
  seq INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, kind TEXT,
  title TEXT, year INTEGER, tvdb_id INTEGER, imdb_id TEXT, tmdb_id INTEGER,
  anilist_id INTEGER, mal_id INTEGER,
  season INTEGER, episode INTEGER, watched INTEGER, source TEXT,
  runtime INTEGER, remaining INTEGER,
  ep_tvdb_id INTEGER, ep_imdb_id TEXT, ep_tmdb_id INTEGER,
  ep_anilist_id INTEGER, ep_mal_id INTEGER);
"""


# ----------------------------------------------------------------- plumbing
def data_dir():
    env = os.environ.get('WATCHVAULT_DIR')
    if env:
        path = env
    else:
        try:
            import xbmcvfs
            path = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
        except ImportError:
            path = os.path.join(os.path.expanduser('~'), '.watchvault')
    os.makedirs(path, exist_ok=True)
    return path


def db_path():
    return os.path.join(data_dir(), 'watchvault.db')


def _init(con):
    if con.execute('PRAGMA user_version').fetchone()[0] < 1:
        con.executescript(SCHEMA)
        con.execute('PRAGMA user_version=1')
        con.commit()
    cols = [r[1] for r in con.execute('PRAGMA table_info(sources)')]
    legacy = 'cur' + 'sor'  # name used by 1.0 databases for the sync position
    if cols and legacy in cols and 'ack_seq' not in cols:
        con.execute('ALTER TABLE sources RENAME COLUMN %s TO ack_seq' % legacy)
        con.commit()
    for table, extra in (
            ('shows', (('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'))),
            ('movies', (('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'))),
            ('episodes', (('title_original', 'TEXT'), ('runtime', 'INTEGER'), ('remaining', 'INTEGER'),
                          ('imdb_id', 'TEXT'), ('tmdb_id', 'INTEGER'),
                          ('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'),
                          ('is_movie', 'INTEGER'), ('episode_type', 'TEXT'),
                          ('movie_tvdb_id', 'INTEGER'))),
            ('changes', (('runtime', 'INTEGER'), ('remaining', 'INTEGER'),
                         ('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'),
                         ('ep_tvdb_id', 'INTEGER'), ('ep_imdb_id', 'TEXT'),
                         ('ep_tmdb_id', 'INTEGER'), ('ep_anilist_id', 'INTEGER'),
                         ('ep_mal_id', 'INTEGER')))):
        have = {r[1] for r in con.execute('PRAGMA table_info(%s)' % table)}
        for name, decl in extra:
            if name not in have:
                con.execute('ALTER TABLE %s ADD COLUMN %s %s' % (table, name, decl))
        con.commit()
    con.execute(
        'CREATE TABLE IF NOT EXISTS id_sources('
        'media TEXT NOT NULL, media_id INTEGER NOT NULL, field TEXT NOT NULL, '
        'value TEXT NOT NULL, source TEXT NOT NULL, ts TEXT, '
        'PRIMARY KEY(media, media_id, field))')
    con.execute(
        'CREATE TABLE IF NOT EXISTS negative_cache('
        'media TEXT NOT NULL, media_id INTEGER NOT NULL, method TEXT NOT NULL, '
        'key TEXT NOT NULL, ts TEXT NOT NULL, '
        'PRIMARY KEY(media, media_id, method))')
    for stmt in (
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_shows_anilist ON shows(anilist_id) WHERE anilist_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_shows_mal ON shows(mal_id) WHERE mal_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_movies_anilist ON movies(anilist_id) WHERE anilist_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_movies_mal ON movies(mal_id) WHERE mal_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_tvdb ON episodes(tvdb_id) WHERE tvdb_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_imdb ON episodes(imdb_id) WHERE imdb_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_tmdb ON episodes(tmdb_id) WHERE tmdb_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_anilist ON episodes(anilist_id) WHERE anilist_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_mal ON episodes(mal_id) WHERE mal_id IS NOT NULL'):
        try:
            con.execute(stmt)
        except sqlite3.Error:
            pass
    con.commit()


_INITED = set()
_INIT_TRIED = {}
_INIT_LOCK = threading.Lock()
_INIT_RETRY_S = 60


def connect(path=None):
    p = path or db_path()
    con = sqlite3.connect(p, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=30000')
    if p not in _INITED and time.time() - _INIT_TRIED.get(p, 0.0) >= _INIT_RETRY_S:
        with _INIT_LOCK:
            if p not in _INITED and time.time() - _INIT_TRIED.get(p, 0.0) >= _INIT_RETRY_S:
                _INIT_TRIED[p] = time.time()
                try:
                    # The first open switches the file to WAL, which needs the lock. If another connection holds it
                    # (the upgrade started while the old service was still running), do not wait 30 s or raise:
                    # this connection works in the old mode, and the switch is retried in 60 s.
                    con.execute('PRAGMA busy_timeout=2000')
                    con.execute('PRAGMA journal_mode=WAL')
                    con.execute('PRAGMA synchronous=NORMAL')
                    _init(con)
                    _INITED.add(p)
                except sqlite3.Error:
                    pass
                finally:
                    con.execute('PRAGMA busy_timeout=30000')
    return con


@contextmanager
def db(path=None):
    con = connect(path)
    try:
        with con:
            yield con
    finally:
        con.close()


@contextmanager
def _use(con=None):
    """Use the caller's open connection (an import keeps one transaction open for its run) or open a new one."""
    if con is not None:
        yield con
        return
    with db() as c:
        yield c


def _now():
    return datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')


def _secs(v):
    """Seconds for runtime or time remaining. Empty stays empty. Negatives are dropped."""
    if v is None or v == '' or isinstance(v, bool):
        return None
    try:
        n = int(round(float(v)))
    except (TypeError, ValueError):
        return None
    if n < 0:
        return None
    return n


def _col(row, name):
    return row[name] if name in row.keys() else None


def _int(v):
    try:
        if v is None or v == '' or isinstance(v, bool):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


def _id(v):
    i = _int(v)
    return i if i and i > 0 else None


def _txt(v):
    v = (v or '').strip() if isinstance(v, str) else v
    return v or None


def _split_title(title):
    title = (title or '').strip()
    m = re.match(r'^(.*?)\s*\((\d{4})\)\s*$', title)
    if m and m.group(1):
        return m.group(1).strip(), int(m.group(2))
    return title, None


def _sort_title(t):
    t = (t or '').lower()
    return re.sub(r'^(the|a|an)\s+', '', t)


def _notify(message, data=None):
    try:
        import xbmc
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
            'params': {'sender': ADDON_ID, 'message': message, 'data': data or {}}}))
    except Exception:
        pass


def _log_change(con, kind, title=None, year=None, tvdb_id=None, imdb_id=None,
                tmdb_id=None, season=None, episode=None, watched=None, source=None,
                runtime=None, remaining=None, anilist_id=None, mal_id=None, ep_ids=None):
    ep_ids = ep_ids or {}
    cur = con.execute(
        'INSERT INTO changes(ts,kind,title,year,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
        'season,episode,watched,source,runtime,remaining,ep_tvdb_id,ep_imdb_id,ep_tmdb_id,ep_anilist_id,ep_mal_id)'
        ' VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        (_now(), kind, title, year, _id(tvdb_id), _txt(imdb_id), _id(tmdb_id), _id(anilist_id), _id(mal_id),
         season, episode, None if watched is None else int(bool(watched)), source,
         _secs(runtime), _secs(remaining),
         ep_ids.get('tvdb_id'), ep_ids.get('imdb_id'), ep_ids.get('tmdb_id'),
         ep_ids.get('anilist_id'), ep_ids.get('mal_id')))
    seq = cur.lastrowid
    con.execute('DELETE FROM changes WHERE seq <= ?', (seq - CHANGE_LOG_LIMIT,))
    return seq


# ------------------------------------------------------------ identity lookup
_ID_KEYS = ('tvdb_id', 'imdb_id', 'tmdb_id', 'anilist_id', 'mal_id')


def _media_ids(tvdb_id=None, imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None):
    return {
        'tvdb_id': _id(tvdb_id),
        'imdb_id': _txt(imdb_id),
        'tmdb_id': _id(tmdb_id),
        'anilist_id': _id(anilist_id),
        'mal_id': _id(mal_id),
    }


def _known(ids):
    return any(ids.values())


def _fallback_title(ids, movie=False):
    if ids.get('tvdb_id'):
        return 'TVDB %s' % ids['tvdb_id']
    if ids.get('imdb_id'):
        return ids['imdb_id']
    if ids.get('tmdb_id'):
        return 'TMDB %s' % ids['tmdb_id']
    if ids.get('anilist_id'):
        return 'AniList %s' % ids['anilist_id']
    if ids.get('mal_id'):
        return 'MAL %s' % ids['mal_id']
    return 'Unknown movie' if movie else 'Unknown show'


def _lookup(con, table, ids):
    for key in _ID_KEYS:
        if ids.get(key):
            row = con.execute('SELECT * FROM %s WHERE %s=?' % (table, key), (ids[key],)).fetchone()
            if row:
                return row
    return None


def _attach(con, table, row, ids, year=None):
    sets, args = [], []
    for key in _ID_KEYS:
        val = ids.get(key)
        if val and not row[key]:
            other = con.execute(
                'SELECT id FROM %s WHERE %s=? AND id!=?' % (table, key), (val, row['id'])).fetchone()
            if other:
                continue
            sets.append(key + '=?')
            args.append(val)
    if year and not row['year']:
        sets.append('year=?')
        args.append(year)
    if sets:
        con.execute('UPDATE %s SET %s WHERE id=?' % (table, ','.join(sets)), args + [row['id']])


def _title_match(con, table, title, year, ids):
    for row in con.execute('SELECT * FROM %s WHERE lower(title)=lower(?)' % table, (title,)):
        if year and row['year'] and row['year'] != year:
            continue
        clash = False
        for key in _ID_KEYS:
            if ids.get(key) and row[key] and row[key] != ids[key]:
                clash = True
                break
        if not clash:
            return row
    return None


def _show_row(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
              anilist_id=None, mal_id=None):
    title, y2 = _split_title(title)
    year = _id(year) or y2
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    row = _lookup(con, 'shows', ids)
    if row:
        return row
    if title:
        return _title_match(con, 'shows', title, year, ids)
    return None


def _from_anime(title, year, ids, movie):
    """Fill empty ids from the local anime cache. Never raises and never replaces an id.

    Returns (title, year, ids, sources) where sources maps newly filled fields
    to offline|kometa for optional provenance recording by the caller.
    """
    title, y2 = _split_title(title)
    year = _id(year) or y2
    try:
        import anime_data
        found = anime_data.resolve(
            title=title, year=year, movie=movie, tvdb_id=ids.get('tvdb_id'), imdb_id=ids.get('imdb_id'),
            tmdb_id=ids.get('tmdb_id'), anilist_id=ids.get('anilist_id'), mal_id=ids.get('mal_id'))
    except Exception:
        found = None
    if not found:
        return title, year, ids, {}
    merged = dict(ids)
    filled_sources = {}
    srcmap = found.get('sources') or {}
    for key in _ID_KEYS:
        if not merged.get(key) and found.get(key):
            merged[key] = found[key]
            if srcmap.get(key):
                filled_sources[key] = srcmap[key]
    if year is None and found.get('year'):
        year = found['year']
    if not title and found.get('title'):
        title = found['title']
    return title, year, merged, filled_sources


def _show_id(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
             anilist_id=None, mal_id=None, create=True):
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    title, year, ids, filled_sources = _from_anime(title, year, ids, False)
    row = _show_row(con, title, year, **ids)
    title, y2 = _split_title(title)
    year = _id(year) or y2
    if row:
        before = {k: row[k] for k in _ID_KEYS}
        _attach(con, 'shows', row, ids, year)
        fresh = con.execute('SELECT * FROM shows WHERE id=?', (row['id'],)).fetchone()
        for key in _ID_KEYS:
            if not before.get(key) and fresh[key] and filled_sources.get(key):
                _record_id_source(con, 'show', row['id'], key, fresh[key], filled_sources[key])
        return row['id']
    if not create:
        return None
    title = title or _fallback_title(ids)
    cur = con.execute(
        'INSERT INTO shows(tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,title,year,created)'
        ' VALUES(?,?,?,?,?,?,?,?)',
        (ids['tvdb_id'], ids['imdb_id'], ids['tmdb_id'], ids['anilist_id'], ids['mal_id'],
         title, year, _now()))
    sid = cur.lastrowid
    for key, src in (filled_sources or {}).items():
        if ids.get(key):
            _record_id_source(con, 'show', sid, key, ids[key], src)
    return sid


def _movie_row(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
               anilist_id=None, mal_id=None):
    title, y2 = _split_title(title)
    year = _id(year) or y2
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    row = _lookup(con, 'movies', ids)
    if row:
        return row
    if title:
        return _title_match(con, 'movies', title, year, ids)
    return None


def _movie_id(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
              anilist_id=None, mal_id=None, create=True):
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    title, year, ids, filled_sources = _from_anime(title, year, ids, True)
    row = _movie_row(con, title, year, **ids)
    title, y2 = _split_title(title)
    year = _id(year) or y2
    if row:
        before = {k: row[k] for k in _ID_KEYS}
        _attach(con, 'movies', row, ids, year)
        fresh = con.execute('SELECT * FROM movies WHERE id=?', (row['id'],)).fetchone()
        for key in _ID_KEYS:
            if not before.get(key) and fresh[key] and filled_sources.get(key):
                _record_id_source(con, 'movie', row['id'], key, fresh[key], filled_sources[key])
        return row['id']
    if not create:
        return None
    title = title or _fallback_title(ids, movie=True)
    cur = con.execute(
        'INSERT INTO movies(tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,title,year,created)'
        ' VALUES(?,?,?,?,?,?,?,?)',
        (ids['tvdb_id'], ids['imdb_id'], ids['tmdb_id'], ids['anilist_id'], ids['mal_id'],
         title, year, _now()))
    mid = cur.lastrowid
    for key, src in (filled_sources or {}).items():
        if ids.get(key):
            _record_id_source(con, 'movie', mid, key, ids[key], src)
    return mid


def _resolve_episode(con, title, year, series_ids, season, episode, ep_ids, create=True):
    """One episode row for every id that points at the same file."""
    hit = _lookup(con, 'episodes', ep_ids)
    if hit:
        show = con.execute('SELECT * FROM shows WHERE id=?', (hit['show_id'],)).fetchone()
        if show:
            _attach(con, 'shows', show, series_ids, _id(year))
        return hit['show_id'], hit['season'], hit['episode']
    sid = _show_id(con, title, year, create=create, **series_ids)
    return sid, season, episode


def _write_episode(con, sid, season, episode, ep_ids, title, aired, mode, ts, runtime, remaining):
    ids = [ep_ids[k] for k in _ID_KEYS]
    base = [sid, season, episode] + ids + [_txt(title), _txt(aired)]
    if mode == 'watch':
        con.execute(
            'INSERT INTO episodes(show_id,season,episode,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
            'title,aired,watched,play_count,last_watched,runtime,remaining)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,1,1,?,?,?)'
            ' ON CONFLICT(show_id,season,episode) DO UPDATE SET'
            ' watched=1, play_count=episodes.play_count+1, last_watched=excluded.last_watched,'
            ' tvdb_id=COALESCE(episodes.tvdb_id,excluded.tvdb_id),'
            ' imdb_id=COALESCE(episodes.imdb_id,excluded.imdb_id),'
            ' tmdb_id=COALESCE(episodes.tmdb_id,excluded.tmdb_id),'
            ' anilist_id=COALESCE(episodes.anilist_id,excluded.anilist_id),'
            ' mal_id=COALESCE(episodes.mal_id,excluded.mal_id),'
            ' title=COALESCE(excluded.title,episodes.title),'
            ' aired=COALESCE(excluded.aired,episodes.aired),'
            ' runtime=COALESCE(excluded.runtime,episodes.runtime),'
            ' remaining=COALESCE(excluded.remaining,episodes.remaining)',
            base + [ts, runtime, remaining])
    elif mode == 'unwatch':
        con.execute(
            'INSERT INTO episodes(show_id,season,episode,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
            'title,aired,watched,play_count,runtime,remaining)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,0,0,?,?)'
            ' ON CONFLICT(show_id,season,episode) DO UPDATE SET'
            ' watched=0, play_count=0, last_watched=NULL, remaining=NULL,'
            ' tvdb_id=COALESCE(episodes.tvdb_id,excluded.tvdb_id),'
            ' imdb_id=COALESCE(episodes.imdb_id,excluded.imdb_id),'
            ' tmdb_id=COALESCE(episodes.tmdb_id,excluded.tmdb_id),'
            ' anilist_id=COALESCE(episodes.anilist_id,excluded.anilist_id),'
            ' mal_id=COALESCE(episodes.mal_id,excluded.mal_id),'
            ' title=COALESCE(excluded.title,episodes.title),'
            ' aired=COALESCE(excluded.aired,episodes.aired),'
            ' runtime=COALESCE(excluded.runtime,episodes.runtime)',
            base + [runtime, None])
    else:
        con.execute(
            'INSERT INTO episodes(show_id,season,episode,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
            'title,aired,watched,play_count,runtime,remaining)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,0,0,?,?)'
            ' ON CONFLICT(show_id,season,episode) DO UPDATE SET'
            ' tvdb_id=COALESCE(episodes.tvdb_id,excluded.tvdb_id),'
            ' imdb_id=COALESCE(episodes.imdb_id,excluded.imdb_id),'
            ' tmdb_id=COALESCE(episodes.tmdb_id,excluded.tmdb_id),'
            ' anilist_id=COALESCE(episodes.anilist_id,excluded.anilist_id),'
            ' mal_id=COALESCE(episodes.mal_id,excluded.mal_id),'
            ' title=COALESCE(excluded.title,episodes.title),'
            ' aired=COALESCE(excluded.aired,episodes.aired),'
            ' runtime=COALESCE(excluded.runtime,episodes.runtime),'
            ' remaining=COALESCE(excluded.remaining,episodes.remaining)',
            base + [runtime, remaining])
    stored = con.execute(
        'SELECT title FROM episodes WHERE show_id=? AND season=? AND episode=?',
        (sid, season, episode)).fetchone()
    _stamp_kind(con, sid, season, episode, stored['title'] if stored else title)


def _episode_ids_of(row):
    return {key: row[key] for key in _ID_KEYS}


_MOVIE_KINDS = {'special', 'specials', 'ova', 'ona', 'oad', 'oav'}


def checks_allowed():
    return os.environ.get('WATCHVAULT_MOVIE_CHECK', '1') != '0'


def episode_kind(season, episode_type=None, title=None):
    """Season 0 / specials / OVA / ONA / OAD can also be movies. Anything else cannot."""
    kind = (episode_type or '').strip().lower()
    if kind in _MOVIE_KINDS:
        return 'special' if kind in ('special', 'specials') else kind
    text = title or ''
    for word in ('ova', 'ona', 'oad', 'oav'):
        if re.search(r'\b%s\b' % word, text, re.I):
            return word
    if _int(season) == 0:
        return 'special'
    return ''


def movie_candidate(season, episode_type=None, title=None):
    return bool(episode_kind(season, episode_type, title))


def _specific_title(title):
    text = (title or '').strip()
    if len(text) < 4:
        return False
    return re.match(r'^(special|specials|ova|ona|oad|oav|episode|ep|sp|recap|trailer|extra)s?(\s*\d+)?$',
                    text, re.I) is None


def _stamp_kind(con, sid, season, episode, title=None, episode_type=None, is_movie=None):
    kind = episode_kind(season, episode_type, title)
    if not kind:
        con.execute(
            'UPDATE episodes SET is_movie=0, episode_type=NULL WHERE show_id=? AND season=? AND episode=?',
            (sid, season, episode))
        return ''
    if is_movie is None:
        con.execute(
            'UPDATE episodes SET episode_type=? WHERE show_id=? AND season=? AND episode=?',
            (kind, sid, season, episode))
    else:
        con.execute(
            'UPDATE episodes SET episode_type=?, is_movie=? WHERE show_id=? AND season=? AND episode=?',
            (kind, 1 if is_movie else 0, sid, season, episode))
    return kind


def stamp_episode(con, show_id, season, episode, title=None, episode_type=None, is_movie=None):
    return _stamp_kind(con, show_id, season, episode, title, episode_type, is_movie)


def _tvdb_key():
    try:
        import xbmcaddon
        return (xbmcaddon.Addon().getSettingString('tvdb_key') or '').strip()
    except Exception:
        return ''


def _mirror_movie(con, show, episode, hit, source=None):
    """Put the same watched state on the movie row for this special."""
    ids = _media_ids(hit.get('tvdb_id'), hit.get('imdb_id'), hit.get('tmdb_id'),
                     hit.get('anilist_id'), hit.get('mal_id'))
    title = hit.get('title') or episode['title'] or show['title']
    year = _id(hit.get('year'))
    mid = _movie_id(con, title, year, **ids)
    if episode['watched']:
        con.execute(
            'UPDATE movies SET watched=1,'
            ' play_count=CASE WHEN watched=1 THEN play_count ELSE MAX(play_count,1) END,'
            ' last_watched=COALESCE(last_watched, ?) WHERE id=?',
            (_now(), mid))
        movie = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
        _log_change(con, 'movie', movie['title'], movie['year'], movie['tvdb_id'], movie['imdb_id'],
                    movie['tmdb_id'], None, None, True, source, None, None,
                    movie['anilist_id'], movie['mal_id'])
    return mid


def check_episode_movie(show_id, season, episode, key=None, search=None, source=None):
    """Look up a special in movie mode. Regular episodes are forced to no, with no lookup."""
    season, episode = _int(season), _int(episode)
    with db() as con:
        show = con.execute('SELECT * FROM shows WHERE id=?', (show_id,)).fetchone()
        row = None
        if show and season is not None and episode is not None:
            row = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (show_id, season, episode)).fetchone()
    if not show or not row:
        return {'is_movie': 0, 'checked': False}
    kind = episode_kind(row['season'], row['episode_type'], row['title'])
    if not kind or not _specific_title(row['title']):
        with db() as con:
            _stamp_kind(con, show_id, season, episode, row['title'], row['episode_type'], 0)
        return {'is_movie': 0, 'checked': False}
    year = None
    if row['aired']:
        try:
            year = int(str(row['aired'])[:4])
        except (TypeError, ValueError):
            year = None
    if search is None:
        import tvdb_catalog
        use_key = key if key is not None else _tvdb_key()

        def search(title, movie_year, show_title, use_key=use_key):
            return tvdb_catalog.search_as_movie(use_key, title, movie_year, show_title)
    try:
        hit = search(row['title'], year, show['title'])
    except Exception:
        hit = None
    flag = 1 if hit else 0
    with db() as con:
        con.execute(
            'UPDATE episodes SET is_movie=?, episode_type=? WHERE show_id=? AND season=? AND episode=?',
            (flag, kind, show_id, season, episode))
        if hit:
            fresh = con.execute('SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                                (show_id, season, episode)).fetchone()
            show = con.execute('SELECT * FROM shows WHERE id=?', (show_id,)).fetchone()
            _mirror_movie(con, show, fresh, hit, source)
    return {'is_movie': flag, 'checked': True, 'movie': hit}


def remember_movie_link(con, show_id, season, episode, title=None, is_movie=None, linked_movie=None):
    """isMovie on the episode list is the marker. linkedMovie is stored only when that
    same episode already includes it. Nothing is looked up."""
    flag = 1 if is_movie in (1, True) or str(is_movie) == '1' else 0
    linked = _id(linked_movie) if flag else None
    kind = episode_kind(season, None, title)
    if flag:
        con.execute(
            'UPDATE episodes SET is_movie=1, episode_type=?, movie_tvdb_id=? '
            'WHERE show_id=? AND season=? AND episode=?',
            (kind or None, linked, show_id, season, episode))
    else:
        _stamp_kind(con, show_id, season, episode, title, None, 0)
        con.execute(
            'UPDATE episodes SET movie_tvdb_id=NULL WHERE show_id=? AND season=? AND episode=?',
            (show_id, season, episode))
    return flag


def link_show_movies(show_id, key=None):
    """Copy isMovie episodes into the movie list. key is ignored: no movie lookup."""
    del key
    with db() as con:
        show = con.execute('SELECT * FROM shows WHERE id=?', (show_id,)).fetchone()
        rows = [dict(r) for r in con.execute(
            'SELECT * FROM episodes WHERE show_id=? AND is_movie=1', (show_id,))]
    if not show:
        return 0
    linked = 0
    for row in rows:
        year = None
        if row['aired']:
            try:
                year = int(str(row['aired'])[:4])
            except (TypeError, ValueError):
                year = None
        with db() as con:
            show = con.execute('SELECT * FROM shows WHERE id=?', (show_id,)).fetchone()
            fresh = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (show_id, row['season'], row['episode'])).fetchone()
            _mirror_movie(con, show, fresh, {
                'title': fresh['title'], 'year': year, 'tvdb_id': fresh['movie_tvdb_id']})
        linked += 1
    return linked


# ------------------------------------------------------------------ public API


def _record_id_source(con, media, media_id, field, value, source):
    if not value or not source:
        return
    con.execute(
        'INSERT OR REPLACE INTO id_sources(media, media_id, field, value, source, ts) VALUES(?,?,?,?,?,?)',
        (media, media_id, field, str(value), source, _now()))



NEG_CACHE_DAYS = 7


def _neg_get(con, media, media_id, method):
    row = con.execute(
        'SELECT ts, key FROM negative_cache WHERE media=? AND media_id=? AND method=?',
        (media, media_id, method)).fetchone()
    return row


def _neg_fresh(row, days=NEG_CACHE_DAYS):
    if not row:
        return False
    try:
        # ts is ISO UTC from _now()
        from datetime import datetime
        ts = datetime.strptime(row['ts'], '%Y-%m-%dT%H:%M:%SZ')
        age = (datetime.utcnow() - ts).total_seconds()
        return age < days * 24 * 3600
    except Exception:
        return False


def _neg_set(con, media, media_id, method, key):
    con.execute(
        'INSERT OR REPLACE INTO negative_cache(media, media_id, method, key, ts) VALUES(?,?,?,?,?)',
        (media, media_id, method, str(key or ''), _now()))


def _neg_clear(con, media, media_id, method=None):
    if method:
        con.execute('DELETE FROM negative_cache WHERE media=? AND media_id=? AND method=?',
                    (media, media_id, method))
    else:
        con.execute('DELETE FROM negative_cache WHERE media=? AND media_id=?',
                    (media, media_id))


def _tvdb_settings():
    """Read TVDB key/pin/delay from addon settings when running inside Kodi."""
    key = pin = ''
    sleep_s = 0.35
    try:
        import xbmcaddon
        ad = xbmcaddon.Addon()
        key = (ad.getSettingString('tvdb_key') or '').strip()
        pin = (ad.getSettingString('tvdb_pin') or '').strip()
        try:
            ms = ad.getSettingInt('tvdb_delay_ms')
            if ms and ms > 0:
                sleep_s = max(0.05, ms / 1000.0)
        except Exception:
            pass
    except Exception:
        pass
    return key, pin, sleep_s


def _save_fill_stats(kind, payload):
    try:
        path = os.path.join(data_dir(), 'fill_stats.json')
        data = {}
        if os.path.exists(path):
            try:
                with open(path, encoding='utf-8') as f:
                    data = json.load(f) or {}
            except Exception:
                data = {}
        data[kind] = dict(payload)
        data[kind]['ts'] = _now()
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass


def get_fill_stats():
    path = os.path.join(data_dir(), 'fill_stats.json')
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f) or {}
    except Exception:
        return {}


def batch_fill_network(api_key=None, limit=50, sleep_s=None):
    """Fill missing TVDB/TMDb ids using TVDB network calls. Never overwrites.

    Order:
      1. Caller should run fill_local_ids first (offline/Kometa)
      2. TMDb-only or IMDb-only rows → /search/remoteid/{id}
      3. Name+year rows still missing TVDB → unique exact name/year search
      4. TVDB present, TMDb missing → /series|movies/{id}/extended remoteIds

    Negative cache: misses stored 7 days (cleared on dataset change).
    """
    import time
    key, pin, default_sleep = _tvdb_settings()
    key = (api_key or key or '').strip()
    if sleep_s is None:
        sleep_s = default_sleep
    if not key:
        return {'ok': False, 'error': 'no_tvdb_key', 'scanned': 0, 'changed': 0, 'filled': 0}

    try:
        import tvdb_catalog
        # seed login with pin once
        tvdb_catalog._login(key, pin=pin or None)
    except Exception as e:
        return {'ok': False, 'error': str(e), 'scanned': 0, 'changed': 0, 'filled': 0}

    scanned = changed = filled = remote_hits = name_hits = tmdb_hits = misses = 0
    limit = max(1, int(limit or 50))

    def _sleep_backoff(exc, attempt):
        code = getattr(exc, 'code', None) or 0
        if code == 429:
            time.sleep(min(30, 2 ** attempt))
            return True
        return False

    def _call(fn, *args, **kwargs):
        attempt = 0
        while True:
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                attempt += 1
                if attempt <= 3 and _sleep_backoff(exc, attempt):
                    continue
                return None

    with db() as con:
        # Remote-id candidates: missing TVDB, have TMDb or IMDb
        remote_rows = list(con.execute(
            'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, "show" AS media '
            'FROM shows WHERE tvdb_id IS NULL AND (tmdb_id IS NOT NULL OR (imdb_id IS NOT NULL AND imdb_id != "")) '
            'UNION ALL '
            'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, "movie" AS media '
            'FROM movies WHERE tvdb_id IS NULL AND (tmdb_id IS NOT NULL OR (imdb_id IS NOT NULL AND imdb_id != "")) '
            'ORDER BY id LIMIT ?', (limit,)))

        remain = max(0, limit - len(remote_rows))
        name_rows = []
        if remain:
            name_rows = list(con.execute(
                'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, "show" AS media '
                'FROM shows WHERE tvdb_id IS NULL AND title IS NOT NULL AND title != "" '
                'UNION ALL '
                'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, "movie" AS media '
                'FROM movies WHERE tvdb_id IS NULL AND title IS NOT NULL AND title != "" '
                'ORDER BY id LIMIT ?', (remain,)))

        # TVDB → TMDb candidates
        tmdb_rows = list(con.execute(
            'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, "show" AS media '
            'FROM shows WHERE tvdb_id IS NOT NULL AND tmdb_id IS NULL '
            'UNION ALL '
            'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, "movie" AS media '
            'FROM movies WHERE tvdb_id IS NOT NULL AND tmdb_id IS NULL '
            'ORDER BY id LIMIT ?', (limit,)))

        def handle_remote(row):
            nonlocal scanned, changed, filled, remote_hits, misses
            scanned += 1
            media, mid = row['media'], row['id']
            method = 'tvdb_remote'
            if _neg_fresh(_neg_get(con, media, mid, method)):
                return
            remote = row['tmdb_id'] or row['imdb_id']
            tid = _call(tvdb_catalog.resolve_tvdb_by_remote, key, remote, movie=(media == 'movie'))
            time.sleep(sleep_s)
            table = 'shows' if media == 'show' else 'movies'
            if not tid:
                _neg_set(con, media, mid, method, 'remote:%s' % remote)
                misses += 1
                return
            before = row['tvdb_id']
            _attach(con, table, row, {'tvdb_id': tid, 'imdb_id': None, 'tmdb_id': None,
                                      'anilist_id': None, 'mal_id': None})
            fresh = con.execute('SELECT * FROM %s WHERE id=?' % table, (mid,)).fetchone()
            if not before and fresh['tvdb_id']:
                changed += 1
                filled += 1
                remote_hits += 1
                _record_id_source(con, media, mid, 'tvdb_id', fresh['tvdb_id'], 'tvdb_remote')
                _neg_clear(con, media, mid, method)

        def handle_name(row):
            nonlocal scanned, changed, filled, name_hits, misses
            table = 'shows' if row['media'] == 'show' else 'movies'
            cur = con.execute('SELECT * FROM %s WHERE id=?' % table, (row['id'],)).fetchone()
            if cur and cur['tvdb_id']:
                return
            scanned += 1
            media, mid = row['media'], row['id']
            method = 'tvdb_name'
            if _neg_fresh(_neg_get(con, media, mid, method)):
                return
            tid = _call(tvdb_catalog.resolve_tvdb_id, key, cur['title'], year=cur['year'],
                        movie=(media == 'movie'))
            time.sleep(sleep_s)
            if not tid:
                _neg_set(con, media, mid, method, '%s|%s' % (cur['title'], cur['year'] or ''))
                misses += 1
                return
            before = cur['tvdb_id']
            _attach(con, table, cur, {'tvdb_id': tid, 'imdb_id': None, 'tmdb_id': None,
                                      'anilist_id': None, 'mal_id': None})
            fresh = con.execute('SELECT * FROM %s WHERE id=?' % table, (mid,)).fetchone()
            if not before and fresh['tvdb_id']:
                changed += 1
                filled += 1
                name_hits += 1
                _record_id_source(con, media, mid, 'tvdb_id', fresh['tvdb_id'], 'tvdb_name')
                _neg_clear(con, media, mid, method)

        def handle_tmdb(row):
            nonlocal scanned, changed, filled, tmdb_hits, misses
            scanned += 1
            media, mid = row['media'], row['id']
            method = 'tmdb_from_tvdb'
            if _neg_fresh(_neg_get(con, media, mid, method)):
                return
            tmdb = _call(tvdb_catalog.resolve_tmdb_from_tvdb, key, row['tvdb_id'],
                         movie=(media == 'movie'))
            time.sleep(sleep_s)
            table = 'shows' if media == 'show' else 'movies'
            if not tmdb:
                _neg_set(con, media, mid, method, 'tvdb:%s' % row['tvdb_id'])
                misses += 1
                return
            before = row['tmdb_id']
            _attach(con, table, row, {'tvdb_id': None, 'imdb_id': None, 'tmdb_id': tmdb,
                                      'anilist_id': None, 'mal_id': None})
            fresh = con.execute('SELECT * FROM %s WHERE id=?' % table, (mid,)).fetchone()
            if not before and fresh['tmdb_id']:
                changed += 1
                filled += 1
                tmdb_hits += 1
                _record_id_source(con, media, mid, 'tmdb_id', fresh['tmdb_id'], 'tvdb_extended')
                _neg_clear(con, media, mid, method)

        for row in remote_rows:
            handle_remote(row)
        for row in name_rows:
            handle_name(row)
        for row in tmdb_rows:
            handle_tmdb(row)

    result = {
        'ok': True,
        'scanned': scanned,
        'changed': changed,
        'filled': filled,
        'remote_hits': remote_hits,
        'name_hits': name_hits,
        'tmdb_hits': tmdb_hits,
        'misses': misses,
    }
    _save_fill_stats('network', result)
    return result


def enrich_on_mark(title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
                   anilist_id=None, mal_id=None, movie=False):
    """One-shot network fill at mark time for missing TVDB/TMDb. Honors neg-cache.

    Returns updated id dict (empty fields only filled). No-op without TVDB key
    or when mark-time network fill is disabled.
    """
    import time
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    try:
        import xbmcaddon
        ad = xbmcaddon.Addon()
        if not ad.getSettingBool('mark_network_fill'):
            return ids
    except Exception:
        pass  # outside Kodi: allow when key provided via settings helper

    key, pin, sleep_s = _tvdb_settings()
    if not key:
        return ids
    try:
        import tvdb_catalog
        tvdb_catalog._login(key, pin=pin or None)
    except Exception:
        return ids

    # Resolve a stable media row key for neg-cache when possible
    media = 'movie' if movie else 'show'
    media_id = 0
    with db() as con:
        table = 'movies' if movie else 'shows'
        row = _lookup(con, table, ids)
        if row is None and title:
            row = _title_match(con, table, title, year, ids)
        if row:
            media_id = row['id']

    def neg_ok(method):
        if not media_id:
            return True
        with db() as con:
            return not _neg_fresh(_neg_get(con, media, media_id, method))

    def neg_miss(method, key_s):
        if not media_id:
            return
        with db() as con:
            _neg_set(con, media, media_id, method, key_s)

    def neg_clear(method):
        if not media_id:
            return
        with db() as con:
            _neg_clear(con, media, media_id, method)

    # TVDB from remote or name
    if not ids.get('tvdb_id'):
        tid = None
        method = None
        if ids.get('tmdb_id') or ids.get('imdb_id'):
            method = 'tvdb_remote'
            if neg_ok(method):
                remote = ids.get('tmdb_id') or ids.get('imdb_id')
                try:
                    tid = tvdb_catalog.resolve_tvdb_by_remote(key, remote, movie=movie)
                except Exception:
                    tid = None
                time.sleep(sleep_s)
                if not tid:
                    neg_miss(method, 'remote:%s' % remote)
        if not tid and title:
            method = 'tvdb_name'
            if neg_ok(method):
                try:
                    tid = tvdb_catalog.resolve_tvdb_id(key, title, year=year, movie=movie)
                except Exception:
                    tid = None
                time.sleep(sleep_s)
                if not tid:
                    neg_miss(method, '%s|%s' % (title, year or ''))
        if tid:
            ids['tvdb_id'] = tid
            if method:
                neg_clear(method)

    # TMDb from TVDB extended
    if ids.get('tvdb_id') and not ids.get('tmdb_id'):
        method = 'tmdb_from_tvdb'
        if neg_ok(method):
            try:
                tmdb = tvdb_catalog.resolve_tmdb_from_tvdb(key, ids['tvdb_id'], movie=movie)
            except Exception:
                tmdb = None
            time.sleep(sleep_s)
            if tmdb:
                ids['tmdb_id'] = tmdb
                neg_clear(method)
            else:
                neg_miss(method, 'tvdb:%s' % ids['tvdb_id'])
    return ids



def clear_negative_cache():
    """Drop all negative-cache rows (e.g. after dataset refresh)."""
    with db() as con:
        con.execute('DELETE FROM negative_cache')
    return True

def fill_local_ids(limit=None, missing_anime=True):
    """Fill empty show/movie ids from the local Offline/Kometa cache only.

    No network. Never overwrites an existing id. Prefer rows still missing
    AniList or MAL when missing_anime is True; otherwise any incomplete id set.
    Returns counts of rows scanned, rows changed, and fields filled.
    """
    scanned = changed = filled = 0
    with db() as con:
        clauses = []
        if missing_anime:
            clauses.append('(anilist_id IS NULL OR mal_id IS NULL)')
        else:
            clauses.append(
                '(tvdb_id IS NULL OR imdb_id IS NULL OR tmdb_id IS NULL '
                'OR anilist_id IS NULL OR mal_id IS NULL)')
        where = ' OR '.join(clauses) if clauses else '1=1'
        sql_shows = 'SELECT * FROM shows WHERE %s ORDER BY id' % where
        sql_movies = 'SELECT * FROM movies WHERE %s ORDER BY id' % where
        if limit:
            sql_shows += ' LIMIT %d' % int(limit)
            sql_movies += ' LIMIT %d' % int(limit)

        def _apply(table, media, row):
            nonlocal scanned, changed, filled
            scanned += 1
            ids = _media_ids(row['tvdb_id'], row['imdb_id'], row['tmdb_id'],
                             row['anilist_id'], row['mal_id'])
            # skip if nothing missing among the keys we care about
            need = [k for k in _ID_KEYS if not ids.get(k)]
            if not need:
                return
            try:
                import anime_data
                found = anime_data.resolve(
                    title=row['title'], year=row['year'], movie=(table == 'movies'),
                    tvdb_id=ids.get('tvdb_id'), imdb_id=ids.get('imdb_id'),
                    tmdb_id=ids.get('tmdb_id'), anilist_id=ids.get('anilist_id'),
                    mal_id=ids.get('mal_id'))
            except Exception:
                found = None
            if not found:
                return
            before = {k: row[k] for k in _ID_KEYS}
            _attach(con, table, row, {
                'tvdb_id': found.get('tvdb_id'),
                'imdb_id': found.get('imdb_id'),
                'tmdb_id': found.get('tmdb_id'),
                'anilist_id': found.get('anilist_id'),
                'mal_id': found.get('mal_id'),
            }, year=found.get('year'))
            fresh = con.execute('SELECT * FROM %s WHERE id=?' % table, (row['id'],)).fetchone()
            sources = found.get('sources') or {}
            row_changed = False
            for key in _ID_KEYS:
                if before.get(key) or not fresh[key]:
                    continue
                row_changed = True
                filled += 1
                _record_id_source(con, media, row['id'], key, fresh[key],
                                  sources.get(key) or 'offline')
            if row_changed:
                changed += 1

        for row in con.execute(sql_shows):
            _apply('shows', 'show', row)
        for row in con.execute(sql_movies):
            _apply('movies', 'movie', row)
    result = {'scanned': scanned, 'changed': changed, 'filled': filled}
    _save_fill_stats('local', result)
    return result


def id_sources_for(media, media_id):
    """Return {field: source} for a show or movie row."""
    with db() as con:
        rows = con.execute(
            'SELECT field, source, value FROM id_sources WHERE media=? AND media_id=?',
            (media, media_id)).fetchall()
    return {r['field']: {'source': r['source'], 'value': r['value']} for r in rows}


def resolve_anime(title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
                  anilist_id=None, mal_id=None, anidb_id=None, movie=False):
    """Local anime title and id match. None when the cache is missing or a source is off."""
    try:
        import anime_data
        return anime_data.resolve(
            title=title, year=year, tvdb_id=tvdb_id, imdb_id=imdb_id, tmdb_id=tmdb_id,
            anilist_id=anilist_id, mal_id=mal_id, anidb_id=anidb_id, movie=movie)
    except Exception:
        return None


def _caller_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
                episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id):
    series = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    episode = _media_ids(episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    return series, episode


def _has_name(title, series):
    return bool(_txt(title) or _known(series))



def _mirror_unified_mark(_con=None, **info):
    """Parse Nightshift-style mark into unified media watch state (single DB file).
    _con: write through the caller's open connection (no commit here; the caller owns the transaction)."""
    import unified
    from helpers import nightshift as ns
    parsed = ns.parse_mark(info)
    if _con is not None:
        ns.apply_to_unified(_con, parsed, source=info.get('source') or 'local')
        return
    con = unified.open_db(db_path())
    try:
        ns.apply_to_unified(con, parsed, source=info.get('source') or 'local')
        con.commit()
    finally:
        con.close()



def mark_watched(title=None, year=None, season=None, episode=None, tvdb_id=None,
                 imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None, watched=True, source=None,
                 played_at=None, episode_title=None, aired=None,
                 episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
                 episode_anilist_id=None, episode_mal_id=None,
                 notify=True, runtime=None, remaining=None, strict=False, con=None):
    """Add an episode to watch history (season+episode given) or a movie as watched/unwatched.
    Any of TVDB, IMDb, TMDB, AniList or MAL identifies the same show, movie or episode file.
    runtime and remaining are seconds, used to resume playback.
    """
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    is_ep = (season is not None and episode is not None) or _known(ep_ids)
    if not _has_name(title, series) and not _known(ep_ids):
        return {'ok': False, 'error': 'need a title or an id'}
    # Local anime fill already runs inside _show_id/_movie_id. Optional one-shot
    # TVDB network fill for missing TVDB/TMDb before resolve (neg-cache aware).
    try:
        if not series.get('tvdb_id') or not series.get('tmdb_id'):
            if con is not None:
                con.commit()        # enrich_on_mark opens its own connection; release our write first
            series = enrich_on_mark(
                title=title, year=year, movie=not is_ep, **{
                    k: series.get(k) for k in _ID_KEYS})
    except Exception:
        pass
    ts = played_at or _now()
    watched = bool(watched)
    runtime, remaining = _secs(runtime), _secs(remaining)
    shared = con
    with _use(shared) as con:
        if is_ep:
            sid, season, episode, why = _slot(con, title, year, series, season, episode, ep_ids, True, strict)
            if why:
                return {'ok': False, 'error': why}
            if not sid or season is None or episode is None:
                return {'ok': False, 'error': 'need a season and episode'}
            _write_episode(con, sid, season, episode, ep_ids, episode_title, aired,
                           'watch' if watched else 'unwatch', ts, runtime, remaining)
            s = con.execute('SELECT * FROM shows WHERE id=?', (sid,)).fetchone()
            row = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
            seq = _log_change(con, 'episode', s['title'], s['year'], s['tvdb_id'], s['imdb_id'],
                              s['tmdb_id'], season, episode, watched, source, runtime,
                              remaining if watched else None, s['anilist_id'], s['mal_id'],
                              _episode_ids_of(row))
        else:
            mid = _movie_id(con, title, year, **series)
            if watched:
                con.execute(
                    'UPDATE movies SET watched=1, play_count=play_count+1, last_watched=?,'
                    ' runtime=COALESCE(?, runtime), remaining=COALESCE(?, remaining) WHERE id=?',
                    (ts, runtime, remaining, mid))
            else:
                con.execute(
                    'UPDATE movies SET watched=0, play_count=0, last_watched=NULL, remaining=NULL,'
                    ' runtime=COALESCE(?, runtime) WHERE id=?', (runtime, mid))
            m = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
            seq = _log_change(con, 'movie', m['title'], m['year'], m['tvdb_id'], m['imdb_id'],
                              m['tmdb_id'], None, None, watched, source, runtime,
                              remaining if watched else None, m['anilist_id'], m['mal_id'])
    # Single-store mirror: same event into unified media (Nightshift/provider helpers share this).
    try:
        _mirror_unified_mark(
            _con=shared, title=title, year=year, season=season, episode=episode,
            tvdb_id=tvdb_id, tmdb_id=tmdb_id, imdb_id=imdb_id,
            anilist_id=anilist_id, mal_id=mal_id,
            episode_tvdb_id=episode_tvdb_id, episode_tmdb_id=episode_tmdb_id,
            watched=watched, source=source, played_at=ts,
            runtime=runtime, remaining=remaining,
        )
    except Exception:
        pass
    if notify:
        _notify('changed', {'seq': seq, 'source': source})
    return {'ok': True, 'seq': seq}


def mark_unwatched(**kw):
    kw['watched'] = False
    return mark_watched(**kw)


def save_progress(title=None, year=None, season=None, episode=None, tvdb_id=None,
                  imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None, source=None,
                  episode_title=None, aired=None, episode_tvdb_id=None, episode_imdb_id=None,
                  episode_tmdb_id=None, episode_anilist_id=None, episode_mal_id=None,
                  runtime=None, remaining=None, notify=True):
    """Store runtime and time remaining without changing the watched flag or play count.
    Both values are seconds. Used when playback stops before it counts as watched.
    """
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    is_ep = (season is not None and episode is not None) or _known(ep_ids)
    if not _has_name(title, series) and not _known(ep_ids):
        return {'ok': False, 'error': 'need a title or an id'}
    runtime, remaining = _secs(runtime), _secs(remaining)
    if runtime is None and remaining is None:
        return {'ok': False, 'error': 'need a runtime or time remaining'}
    if runtime is not None and remaining is not None and remaining > runtime:
        remaining = runtime
    with db() as con:
        if is_ep:
            sid, season, episode = _resolve_episode(con, title, year, series, season, episode, ep_ids)
            if not sid or season is None or episode is None:
                return {'ok': False, 'error': 'need a season and episode'}
            _write_episode(con, sid, season, episode, ep_ids, episode_title, aired,
                           'progress', None, runtime, remaining)
            s = con.execute('SELECT * FROM shows WHERE id=?', (sid,)).fetchone()
            row = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
            seq = _log_change(con, 'episode', s['title'], s['year'], s['tvdb_id'], s['imdb_id'],
                              s['tmdb_id'], season, episode, row['watched'], source,
                              row['runtime'], row['remaining'], s['anilist_id'], s['mal_id'],
                              _episode_ids_of(row))
        else:
            mid = _movie_id(con, title, year, **series)
            con.execute(
                'UPDATE movies SET runtime=COALESCE(?, runtime), remaining=COALESCE(?, remaining) WHERE id=?',
                (runtime, remaining, mid))
            m = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
            seq = _log_change(con, 'movie', m['title'], m['year'], m['tvdb_id'], m['imdb_id'],
                              m['tmdb_id'], None, None, m['watched'], source, m['runtime'], m['remaining'],
                              m['anilist_id'], m['mal_id'])
    if notify:
        _notify('changed', {'seq': seq, 'source': source})
    return {'ok': True, 'seq': seq, 'runtime': runtime, 'remaining': remaining}


def _resume_dict(row):
    if not row:
        return None
    runtime, remaining = row['runtime'], row['remaining']
    position = None
    if runtime is not None and remaining is not None and remaining <= runtime:
        position = runtime - remaining
    return {'runtime': runtime, 'remaining': remaining, 'position': position,
            'watched': bool(row['watched'])}


def get_resume(season=None, episode=None, tvdb_id=None, title=None, year=None,
               imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None,
               episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
               episode_anilist_id=None, episode_mal_id=None):
    """Runtime, time remaining, and resume position in seconds. None if unknown."""
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    with db() as con:
        if (season is not None and episode is not None) or _known(ep_ids):
            sid, season, episode = _resolve_episode(con, title, year, series, season, episode, ep_ids, create=False)
            if not sid or season is None or episode is None:
                return None
            row = con.execute(
                'SELECT runtime, remaining, watched FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
        else:
            mid = _movie_id(con, title, year, create=False, **series)
            if not mid:
                return None
            row = con.execute('SELECT runtime, remaining, watched FROM movies WHERE id=?', (mid,)).fetchone()
    return _resume_dict(row)



def clear_progress(title=None, year=None, season=None, episode=None, tvdb_id=None,
                   imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None, source=None,
                   episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
                   episode_anilist_id=None, episode_mal_id=None, notify=True):
    """Clear resume seek (remaining) without changing watched state."""
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    is_ep = (season is not None and episode is not None) or _known(ep_ids)
    with db() as con:
        if is_ep:
            sid, season, episode = _resolve_episode(
                con, title, year, series, season, episode, ep_ids, create=False)
            if not sid or season is None or episode is None:
                return {'ok': False, 'error': 'not found'}
            con.execute(
                'UPDATE episodes SET remaining=NULL WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode))
            s = con.execute('SELECT * FROM shows WHERE id=?', (sid,)).fetchone()
            row = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
            seq = _log_change(con, 'episode', s['title'], s['year'], s['tvdb_id'], s['imdb_id'],
                              s['tmdb_id'], season, episode, row['watched'], source,
                              row['runtime'], None, s['anilist_id'], s['mal_id'],
                              _episode_ids_of(row))
        else:
            mid = _movie_id(con, title, year, create=False, **series)
            if not mid:
                return {'ok': False, 'error': 'not found'}
            con.execute('UPDATE movies SET remaining=NULL WHERE id=?', (mid,))
            m = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
            seq = _log_change(con, 'movie', m['title'], m['year'], m['tvdb_id'], m['imdb_id'],
                              m['tmdb_id'], None, None, m['watched'], source, m['runtime'], None,
                              m['anilist_id'], m['mal_id'])
    if notify:
        _notify('changed', {'seq': seq, 'source': source})
    return {'ok': True, 'seq': seq}


def watched_episodes(tvdb_id=None, title=None, year=None, imdb_id=None, tmdb_id=None,
                     anilist_id=None, mal_id=None):
    """-> {season: [episode, ...]} of watched episodes for one show (sorted)."""
    with db() as con:
        sid = _show_id(con, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, create=False)
        out = {}
        if sid:
            for r in con.execute('SELECT season,episode FROM episodes WHERE show_id=? AND watched=1'
                                 ' ORDER BY season,episode', (sid,)):
                out.setdefault(r['season'], []).append(r['episode'])
        return out


def is_watched(season=None, episode=None, tvdb_id=None, title=None, year=None,
               imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None,
               episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
               episode_anilist_id=None, episode_mal_id=None):
    """Episode check when season+episode or an episode id is given, otherwise a movie check.
    Reads unified media first (single store); falls back to legacy tables if needed."""
    return _watched_reason(
        season=season, episode=episode, tvdb_id=tvdb_id, title=title, year=year,
        imdb_id=imdb_id, tmdb_id=tmdb_id, anilist_id=anilist_id, mal_id=mal_id,
        episode_tvdb_id=episode_tvdb_id, episode_imdb_id=episode_imdb_id,
        episode_tmdb_id=episode_tmdb_id, episode_anilist_id=episode_anilist_id,
        episode_mal_id=episode_mal_id)[0]


def _slot(con, title, year, series, season, episode, ep_ids, create, strict):
    """(sid, season, episode, why) for one episode. Stored ids can be wrong, so with strict (imports) an id match counts
    only when it is this show and this season and episode. Any other match is refused, and why says what it matched.
    Without strict the match is used as before."""
    if strict and season is not None and episode is not None and _known(ep_ids):
        hit = _lookup(con, 'episodes', ep_ids)
        if hit is not None:
            want = _show_id(con, title, year, create=False, **series)
            if want is None or hit['show_id'] != want:
                return None, season, episode, 'episode id matched a row of another show'
            if (hit['season'], hit['episode']) != (season, episode):
                return None, season, episode, 'matched a different episode (S%sE%s), not S%sE%s' % (
                    hit['season'], hit['episode'], season, episode)
            return hit['show_id'], season, episode, None
    sid, s, e = _resolve_episode(con, title, year, series, season, episode, ep_ids, create=create)
    if strict and sid is not None and season is not None and episode is not None:
        want = _show_id(con, title, year, create=False, **series)
        if want is not None and want != sid:
            return None, season, episode, 'matched another show (id %s)' % sid
        if (s, e) != (season, episode):
            return None, season, episode, 'matched a different episode (S%sE%s), not S%sE%s' % (s, e, season, episode)
    return sid, s, e, None


def _watched_reason(season=None, episode=None, tvdb_id=None, title=None, year=None,
                    imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None,
                    episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
                    episode_anilist_id=None, episode_mal_id=None, strict=False, con=None):
    """(watched, where). where is 'unified' or 'legacy': the store that says the row is watched. Else (False, None)."""
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    try:
        import unified
        with _use(con) as con:
            unified.ensure(con)
            if (season is not None and episode is not None) or _known(ep_ids):
                if unified.is_watched_row(
                        con, kind='episode',
                        tvdb_id=ep_ids.get('tvdb_id') or series.get('tvdb_id'),
                        tmdb_id=ep_ids.get('tmdb_id') or series.get('tmdb_id'),
                        imdb_id=series.get('imdb_id'),
                        anilist_id=series.get('anilist_id'), mal_id=series.get('mal_id'),
                        season=season, number=episode,
                        show_tmdb_id=series.get('tmdb_id'), show_tvdb_id=series.get('tvdb_id')):
                    return True, 'unified'
            else:
                if unified.is_watched_row(
                        con, kind='movie',
                        tvdb_id=series.get('tvdb_id'), tmdb_id=series.get('tmdb_id'),
                        imdb_id=series.get('imdb_id'), anilist_id=series.get('anilist_id'),
                        mal_id=series.get('mal_id')):
                    return True, 'unified'
    except Exception:
        pass
    with _use(con) as con:
        if (season is not None and episode is not None) or _known(ep_ids):
            sid, season, episode, why = _slot(con, title, year, series, season, episode, ep_ids, False, strict)
            if not sid or season is None or episode is None:
                return False, None
            row = con.execute('SELECT watched FROM episodes WHERE show_id=? AND season=? AND episode=?',
                              (sid, season, episode)).fetchone()
            return ((True, 'legacy') if (row and row['watched']) else (False, None))
        mid = _movie_id(con, title, year, create=False, **series)
        if not mid:
            return False, None
        row = con.execute('SELECT watched FROM movies WHERE id=?', (mid,)).fetchone()
        return ((True, 'legacy') if (row and row['watched']) else (False, None))


def watched_episode_rows():
    """Every watched episode in the legacy store, with its show's TMDb and TVDB ids and the last watched time."""
    with db() as con:
        rows = con.execute(
            'SELECT s.tmdb_id AS show_tmdb_id, s.tvdb_id AS show_tvdb_id, s.title AS show_title, '
            's.year AS year, e.season AS season, e.episode AS episode, e.tmdb_id AS episode_tmdb_id, '
            'e.tvdb_id AS episode_tvdb_id, e.last_watched AS last_watched '
            'FROM episodes e JOIN shows s ON s.id = e.show_id WHERE e.watched = 1 '
            'ORDER BY e.last_watched DESC').fetchall()
    return [dict(r) for r in rows]


def store_counts():
    """Watched episode and movie counts in both stores (legacy tables and unified media), for the import log."""
    out = {'legacy_episodes': 0, 'legacy_movies': 0, 'unified_episodes': None, 'unified_movies': None}
    try:
        c = counts()
        out['legacy_episodes'], out['legacy_movies'] = c['episodes'], c['movies']
    except Exception:
        pass
    try:
        import unified
        with db() as con:
            unified.ensure(con)
            out['unified_episodes'] = con.execute(
                "SELECT COUNT(*) FROM media WHERE kind = 'episode' AND watched = 1").fetchone()[0]
            out['unified_movies'] = con.execute(
                "SELECT COUNT(*) FROM media WHERE kind = 'movie' AND watched = 1").fetchone()[0]
    except Exception:
        pass
    return out



def watched_movies():
    with db() as con:
        return [dict(r) for r in con.execute(
            'SELECT title,year,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,play_count,last_watched,'
            ' runtime,remaining FROM movies WHERE watched=1 ORDER BY lower(title)')]


def watched_show_ids():
    """Every show with at least one watched episode: tvdb / tmdb / imdb ids, title and year. Lets other add-ons
    fill their own show-level counts from WatchVault."""
    with db() as con:
        rows = con.execute(
            'SELECT s.tvdb_id, s.tmdb_id, s.imdb_id, s.title, s.year FROM shows s '
            'WHERE EXISTS (SELECT 1 FROM episodes e WHERE e.show_id = s.id AND e.watched = 1) '
            'ORDER BY lower(s.title)').fetchall()
    return [dict(r) for r in rows]


def last_seq():
    with db() as con:
        return con.execute('SELECT COALESCE(MAX(seq),0) FROM changes').fetchone()[0]


def get_changes(since=0, limit=2000, exclude_source=None):
    with db() as con:
        rows = [dict(r) for r in con.execute(
            'SELECT * FROM changes WHERE seq>? ORDER BY seq LIMIT ?', (_int(since) or 0, limit))]
    if exclude_source:
        rows = [r for r in rows if r['source'] != exclude_source]
    return rows


def _full_marker(seq):
    return {'seq': seq, 'ts': _now(), 'kind': 'full', 'title': None, 'year': None,
            'tvdb_id': None, 'imdb_id': None, 'tmdb_id': None, 'anilist_id': None, 'mal_id': None,
            'season': None, 'episode': None, 'watched': None, 'source': None,
            'runtime': None, 'remaining': None, 'ep_tvdb_id': None, 'ep_imdb_id': None,
            'ep_tmdb_id': None, 'ep_anilist_id': None, 'ep_mal_id': None}


def pull_changes(addon_id, ack=True):
    """Everything that changed since this add-on last pulled (its own changes
    excluded).  A row with kind == 'full' means: do a full resync with
    get_clean_list().  A new source (ack_seq below 0), a wiped add-on, a gap in
    the change log, or a full wipe of watch history returns that one marker.
    """
    with db() as con:
        src = con.execute('SELECT * FROM sources WHERE addon_id=?', (addon_id,)).fetchone()
        ack_seq = src['ack_seq'] if src else 0
        max_seq = con.execute('SELECT COALESCE(MAX(seq),0) FROM changes').fetchone()[0]
        needs_full = bool(src) and ack_seq < 0
        if not needs_full:
            min_seq = con.execute('SELECT MIN(seq) FROM changes').fetchone()[0]
            if ack_seq > max_seq:
                needs_full = True
            elif min_seq is not None and ack_seq >= 0 and min_seq > ack_seq + 1:
                needs_full = True
            elif con.execute("SELECT 1 FROM changes WHERE seq>? AND kind='full' LIMIT 1",
                             (ack_seq,)).fetchone():
                needs_full = True
        if needs_full:
            if ack and src:
                con.execute('UPDATE sources SET ack_seq=? WHERE addon_id=?', (max_seq, addon_id))
            return [_full_marker(max_seq)]
        rows = [dict(r) for r in con.execute(
            'SELECT * FROM changes WHERE seq>? ORDER BY seq', (ack_seq,))]
        if ack and src and rows:
            con.execute('UPDATE sources SET ack_seq=? WHERE addon_id=?', (rows[-1]['seq'], addon_id))
    return [r for r in rows if r['source'] != addon_id]


# --------------------------------------------------------------------- sources
def add_source(addon_id, name=None):
    with db() as con:
        seq = con.execute('SELECT COALESCE(MAX(seq),0) FROM changes').fetchone()[0]
        # ack_seq -1: this source has never pulled, so the next pull is a full sync
        con.execute('INSERT OR IGNORE INTO sources(addon_id,name,enabled,ack_seq,added) VALUES(?,?,1,-1,?)',
                    (addon_id, name or addon_id, _now()))
        con.execute('UPDATE sources SET enabled=1, name=COALESCE(?,name) WHERE addon_id=?', (name, addon_id))
    return seq


def toggle_source(addon_id):
    with db() as con:
        row = con.execute('SELECT enabled FROM sources WHERE addon_id=?', (addon_id,)).fetchone()
        if not row:
            return False
        con.execute('UPDATE sources SET enabled=? WHERE addon_id=?', (0 if row['enabled'] else 1, addon_id))
        return True


def remove_source(addon_id):
    with db() as con:
        con.execute('DELETE FROM sources WHERE addon_id=?', (addon_id,))


def set_source_enabled(addon_id, enabled):
    with db() as con:
        con.execute('UPDATE sources SET enabled=? WHERE addon_id=?', (int(bool(enabled)), addon_id))


def get_sources():
    with db() as con:
        return [dict(r) for r in con.execute('SELECT addon_id,name,enabled,added FROM sources ORDER BY lower(name)')]


def get_source(addon_id):
    if not addon_id:
        return None
    with db() as con:
        r = con.execute('SELECT addon_id,name,enabled,added FROM sources WHERE addon_id=?', (addon_id,)).fetchone()
        return dict(r) if r else None


# ------------------------------------------------------------- clean list/dump
def _dump(con, watched_only=False, compact=False, include_movies=True):
    shows = []
    for s in sorted(con.execute('SELECT * FROM shows'), key=lambda r: (_sort_title(r['title']), r['year'] or 0)):
        q = 'SELECT * FROM episodes WHERE show_id=?'
        if watched_only:
            q += ' AND watched=1'
        eps = list(con.execute(q + ' ORDER BY season, episode', (s['id'],)))  # season 0 (specials) first
        if watched_only and not eps:
            continue
        if compact:
            ep_out = ['S%02dE%02d' % (e['season'], e['episode']) for e in eps]
        else:
            ep_out = [{'season': e['season'], 'episode': e['episode'], 'title': e['title'],
                       'title_original': _col(e, 'title_original'), 'aired': e['aired'], 'tvdb_id': _col(e, 'tvdb_id'), 'imdb_id': _col(e, 'imdb_id'),
                       'tmdb_id': _col(e, 'tmdb_id'), 'anilist_id': _col(e, 'anilist_id'),
                       'mal_id': _col(e, 'mal_id'), 'watched': bool(e['watched']),
                       'play_count': e['play_count'], 'last_watched': e['last_watched'],
                       'runtime': _col(e, 'runtime'), 'remaining': _col(e, 'remaining'),
                       'is_movie': bool(_col(e, 'is_movie')), 'episode_type': _col(e, 'episode_type'),
                       'movie_tvdb_id': _col(e, 'movie_tvdb_id')} for e in eps]
        shows.append({'title': s['title'], 'year': s['year'], 'tvdb_id': s['tvdb_id'],
                      'imdb_id': s['imdb_id'], 'tmdb_id': s['tmdb_id'],
                      'anilist_id': _col(s, 'anilist_id'), 'mal_id': _col(s, 'mal_id'),
                      'episodes': ep_out})
    movies = []
    if include_movies:
        q = 'SELECT * FROM movies' + (' WHERE watched=1' if watched_only else '')
        for m in sorted(con.execute(q), key=lambda r: (_sort_title(r['title']), r['year'] or 0)):
            movies.append({'title': m['title'], 'year': m['year'], 'tvdb_id': m['tvdb_id'],
                           'imdb_id': m['imdb_id'], 'tmdb_id': m['tmdb_id'],
                           'anilist_id': _col(m, 'anilist_id'), 'mal_id': _col(m, 'mal_id'),
                           'watched': bool(m['watched']), 'play_count': m['play_count'],
                           'last_watched': m['last_watched'],
                           'runtime': _col(m, 'runtime'), 'remaining': _col(m, 'remaining')})
    sources = [{'addon_id': r['addon_id'], 'name': r['name'], 'enabled': bool(r['enabled'])}
               for r in con.execute('SELECT * FROM sources ORDER BY lower(name)')]
    return {'format': FORMAT, 'version': FORMAT_VERSION, 'exported': _now(),
            'shows': shows, 'movies': movies, 'sources': sources}


def get_clean_list(watched_only=False, compact=False, include_movies=True):
    """Sorted list: show name, year, tvdb id, episodes (season 0 specials first,
    then season 1, 2 ... each in aired/episode order).  compact=True gives
    episodes as 'S01E02' strings.  This is what helper scripts sync from."""
    if watched_only:
        try:
            import unified
            with db() as con:
                unified.ensure(con)
                payload = unified.watched_for_providers(con)
            if payload.get('shows') or payload.get('movies'):
                if compact:
                    shows = []
                    for s in payload.get('shows') or []:
                        eps = []
                        for season in s.get('seasons') or []:
                            for e in season.get('episodes') or []:
                                sn, en = season.get('number'), e.get('number')
                                if sn is not None and en is not None:
                                    eps.append('S%02dE%02d' % (int(sn), int(en)))
                        shows.append({
                            'title': s.get('title'), 'year': s.get('year'),
                            'tvdb_id': (s.get('ids') or {}).get('tvdb'),
                            'tmdb_id': (s.get('ids') or {}).get('tmdb'),
                            'imdb_id': (s.get('ids') or {}).get('imdb'),
                            'episodes': sorted(eps),
                        })
                    movies = []
                    if include_movies:
                        for mrow in payload.get('movies') or []:
                            movies.append({
                                'title': mrow.get('title'), 'year': mrow.get('year'),
                                'tvdb_id': (mrow.get('ids') or {}).get('tvdb'),
                                'tmdb_id': (mrow.get('ids') or {}).get('tmdb'),
                                'imdb_id': (mrow.get('ids') or {}).get('imdb'),
                            })
                    return {'shows': shows, 'movies': movies}
                shows = []
                for s in payload.get('shows') or []:
                    shows.append({
                        'title': s.get('title'), 'year': s.get('year'),
                        'tvdb_id': (s.get('ids') or {}).get('tvdb'),
                        'tmdb_id': (s.get('ids') or {}).get('tmdb'),
                        'imdb_id': (s.get('ids') or {}).get('imdb'),
                        'seasons': s.get('seasons') or [],
                    })
                return {'shows': shows, 'movies': (payload.get('movies') or []) if include_movies else []}
        except Exception:
            pass

    with db() as con:
        return _dump(con, watched_only, compact, include_movies)


def _parse_ep(e):
    if isinstance(e, str):
        m = re.match(r'^\s*s(\d+)\s*e(\d+)\s*$', e, re.I)
        if not m:
            return None
        return {'season': int(m.group(1)), 'episode': int(m.group(2)), 'watched': True}
    if isinstance(e, dict) and _int(e.get('season')) is not None and _int(e.get('episode')) is not None:
        return e
    return None


def _merge(con, data, replace=False):
    if not isinstance(data, dict):
        raise ValueError('not a WatchVault file')
    if 'shows' not in data and 'movies' not in data:
        raise ValueError('not a WatchVault file (no "shows" or "movies")')
    if 'shows' in data and not isinstance(data.get('shows'), list):
        raise ValueError('not a WatchVault file ("shows" must be a list)')
    if 'movies' in data and not isinstance(data.get('movies'), list):
        raise ValueError('not a WatchVault file ("movies" must be a list)')
    if replace:
        con.execute('DELETE FROM episodes')
        con.execute('DELETE FROM shows')
        con.execute('DELETE FROM movies')
    n_eps = n_movies = 0
    for s in data.get('shows') or []:
        if not isinstance(s, dict):
            continue
        if not (_txt(s.get('title')) or _known(_media_ids(
                s.get('tvdb_id'), s.get('imdb_id'), s.get('tmdb_id'), s.get('anilist_id'), s.get('mal_id')))):
            continue
        sid = _show_id(con, s.get('title'), s.get('year'), s.get('tvdb_id'), s.get('imdb_id'),
                       s.get('tmdb_id'), anilist_id=s.get('anilist_id'), mal_id=s.get('mal_id'))
        for raw in s.get('episodes') or []:
            e = _parse_ep(raw)
            if not e:
                continue
            if isinstance(raw, dict):
                w = 1 if raw.get('watched') else 0
            else:
                w = 1
            pc = _int(e.get('play_count')) or (1 if w else 0)
            ep_ids = _media_ids(e.get('tvdb_id'), e.get('imdb_id'), e.get('tmdb_id'),
                                e.get('anilist_id'), e.get('mal_id'))
            runtime, remaining = _secs(e.get('runtime')), _secs(e.get('remaining'))
            _write_episode(con, sid, int(e['season']), int(e['episode']), ep_ids, e.get('title'),
                           e.get('aired'), 'progress', None, runtime, remaining)
            con.execute(
                'UPDATE episodes SET watched=MAX(watched,?),'
                ' play_count=MAX(play_count,?),'
                ' last_watched=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>last_watched)'
                '  THEN ? ELSE last_watched END,'
                ' runtime=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched)'
                '  THEN COALESCE(?, runtime) ELSE COALESCE(runtime, ?) END,'
                ' remaining=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched)'
                '  THEN COALESCE(?, remaining) ELSE COALESCE(remaining, ?) END'
                ' WHERE show_id=? AND season=? AND episode=?',
                (w, pc, _txt(e.get('last_watched')) if w else None,
                 _txt(e.get('last_watched')) if w else None, _txt(e.get('last_watched')) if w else None,
                 _txt(e.get('last_watched')) if w else None, _txt(e.get('last_watched')) if w else None,
                 runtime, runtime,
                 _txt(e.get('last_watched')) if w else None, _txt(e.get('last_watched')) if w else None,
                 remaining, remaining, sid, int(e['season']), int(e['episode'])))
            n_eps += 1
    for m in data.get('movies') or []:
        if not isinstance(m, dict) or not (_txt(m.get('title')) or _known(_media_ids(
                m.get('tvdb_id'), m.get('imdb_id'), m.get('tmdb_id'), m.get('anilist_id'), m.get('mal_id')))):
            continue
        mid = _movie_id(con, m.get('title'), m.get('year'), m.get('tvdb_id'), m.get('imdb_id'),
                        m.get('tmdb_id'), anilist_id=m.get('anilist_id'), mal_id=m.get('mal_id'))
        w = 1 if m.get('watched', True) else 0
        pc = _int(m.get('play_count')) or (1 if w else 0)
        runtime, remaining = _secs(m.get('runtime')), _secs(m.get('remaining'))
        con.execute(
            'UPDATE movies SET watched=MAX(watched,?), play_count=MAX(play_count,?),'
            ' last_watched=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>last_watched) THEN ? ELSE last_watched END,'
            ' runtime=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched) THEN COALESCE(?, runtime) ELSE COALESCE(runtime, ?) END,'
            ' remaining=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched) THEN COALESCE(?, remaining) ELSE COALESCE(remaining, ?) END'
            ' WHERE id=?',
            (w, pc, _txt(m.get('last_watched')), _txt(m.get('last_watched')), _txt(m.get('last_watched')),
             _txt(m.get('last_watched')), _txt(m.get('last_watched')), runtime, runtime,
             _txt(m.get('last_watched')), _txt(m.get('last_watched')), remaining, remaining, mid))
        n_movies += 1
    for src in data.get('sources') or []:
        if isinstance(src, dict) and _txt(src.get('addon_id')):
            con.execute('INSERT OR IGNORE INTO sources(addon_id,name,enabled,ack_seq,added) VALUES(?,?,?,0,?)',
                        (src['addon_id'], src.get('name') or src['addon_id'],
                         1 if src.get('enabled', True) else 0, _now()))
    _log_change(con, 'full')
    return {'episodes': n_eps, 'movies': n_movies}


def import_dict(data, replace=False):
    with db() as con:
        res = _merge(con, data, replace)
    _notify('changed', {'full': True})
    return res


# ---------------------------------------------------------- export / import
def export_json(path, watched_only=False):
    data = get_clean_list(watched_only=watched_only)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)
    return {'shows': len(data['shows']), 'movies': len(data['movies'])}


def import_json(path, replace=False):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return import_dict(data, replace)


def export_db(path):
    src = connect()
    try:
        if os.path.exists(path):
            os.remove(path)
        dst = sqlite3.connect(path)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def import_db(path, replace=False):
    raw = sqlite3.connect(path)
    raw.row_factory = sqlite3.Row
    try:
        tables = {r[0] for r in raw.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'shows', 'episodes', 'movies'} <= tables:
            raise ValueError('not a WatchVault database file')
        data = _dump(raw)
    finally:
        raw.close()
    return import_dict(data, replace)


def counts():
    with db() as con:
        return {
            'shows': con.execute('SELECT COUNT(*) FROM shows').fetchone()[0],
            'episodes': con.execute('SELECT COUNT(*) FROM episodes WHERE watched=1').fetchone()[0],
            'movies': con.execute('SELECT COUNT(*) FROM movies WHERE watched=1').fetchone()[0],
        }


def db_info():
    """Shows, every episode row, and the database file size in bytes."""
    path = db_path()
    size = os.path.getsize(path) if os.path.exists(path) else 0
    with db() as con:
        return {
            'shows': con.execute('SELECT COUNT(*) FROM shows').fetchone()[0],
            'episodes': con.execute('SELECT COUNT(*) FROM episodes').fetchone()[0],
            'watched_episodes': con.execute('SELECT COUNT(*) FROM episodes WHERE watched=1').fetchone()[0],
            'movies': con.execute('SELECT COUNT(*) FROM movies').fetchone()[0],
            'bytes': size,
        }


def purge_all():
    """Delete every show, episode and movie. Registered video add-ons stay."""
    with db() as con:
        con.execute('DELETE FROM episodes')
        con.execute('DELETE FROM shows')
        con.execute('DELETE FROM movies')
        _log_change(con, 'full')
    _notify('changed', {'full': True})
    return db_info()


def delete_show(show_id):
    with db() as con:
        con.execute('DELETE FROM shows WHERE id=?', (show_id,))
        _log_change(con, 'full')


def delete_movie(movie_id):
    with db() as con:
        con.execute('DELETE FROM movies WHERE id=?', (movie_id,))
        _log_change(con, 'full')


# ------------------------------------------------------- helper for add-ons
def announce(**info):
    """Call right before playback from a plugin so WatchVault knows exactly what
    is playing: title, year, season, episode, tvdb_id, imdb_id, tmdb_id, source."""
    try:
        import xbmcgui
        info['ts'] = time.time()
        xbmcgui.Window(10000).setProperty('watchvault.announce', json.dumps(info))
    except Exception:
        pass
