# -*- coding: utf-8 -*-
import time

import xbmc
import xbmcaddon
import xbmcgui

_notice = None


def _addon_path():
    return xbmcaddon.Addon().getAddonInfo('path')


class FullscreenText(xbmcgui.WindowXML):
    """Full-screen text window (modal); Back closes it."""

    def onInit(self):
        self.getControl(90).setLabel(self._heading)
        self.getControl(100).setText(self._body)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.close()


class NoticeWindow(xbmcgui.WindowXML):
    """Non-modal notice (shown with show(), so nothing blocks)."""

    def onInit(self):
        self.getControl(90).setLabel(self._heading)
        self.getControl(100).setText(self._body)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.close()

    def update(self, heading, body):
        try:
            self.getControl(90).setLabel(heading)
            self.getControl(100).setText(body)
        except Exception as e:
            xbmc.log('[WatchVault] notice update failed: %s' % e, xbmc.LOGWARNING)


def modal_open():
    """True while Kodi has a modal dialog on screen (for example the add-on settings)."""
    return xbmcgui.getCurrentWindowDialogId() != 9999


def close_modal_settings(timeout=5.0):
    """Send Back, the same as pressing it, and wait until no modal dialog is open."""
    if not modal_open():
        return True
    xbmc.executebuiltin('Action(Back)')
    end = time.time() + timeout
    while modal_open() and time.time() < end:
        xbmc.sleep(200)
    return not modal_open()


def show_fullscreen_text(heading, body):
    xbmc.log('[WatchVault diag] showing fullscreen text', xbmc.LOGWARNING)
    try:
        win = FullscreenText('watchvault_fullscreen.xml', _addon_path(), 'Default', '1080i')
    except Exception as e:
        xbmc.log('[WatchVault diag] full-screen window unavailable, using dialog: %s' % e, xbmc.LOGWARNING)
        xbmcgui.Dialog().textviewer(heading, body)
        return
    win._heading = heading
    win._body = body
    try:
        win.doModal()
    finally:
        del win


def show_notice(heading, body):
    global _notice
    close_notice()
    win = NoticeWindow('watchvault_notice.xml', _addon_path(), 'Default', '1080i')
    win._heading = heading
    win._body = body
    win.show()
    _notice = win


def update_notice(heading, body):
    if _notice is not None:
        _notice.update(heading, body)


def close_notice():
    global _notice
    if _notice is not None:
        try:
            _notice.close()
        except Exception:
            pass
        _notice = None
