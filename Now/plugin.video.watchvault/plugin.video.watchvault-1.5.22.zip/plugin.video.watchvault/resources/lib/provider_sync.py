# -*- coding: utf-8 -*-
"""Push WatchVault watched history to optional remote providers.

Nightshift stays on WatchVault / Nightshift watched mode. When the user enables a
provider here and supplies credentials, WatchVault pushes *its* watched rows out
on a schedule (and optionally right after a mark).

Providers with a working push path today:
  - MDBList (API key)

Scaffolded (settings only / returns not_configured until tokens exist):
  - Trakt, Simkl, PunchPlay
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request

import watchvault as wv

SOURCE = 'plugin.video.watchvault'


def _addon():
    try:
        import xbmcaddon
        return xbmcaddon.Addon()
    except Exception:
        return None


def _setting(name, default=''):
    ad = _addon()
    if not ad:
        return default
    try:
        return (ad.getSettingString(name) or default).strip() or default
    except Exception:
        try:
            return str(ad.getSetting(name) or default)
        except Exception:
            return default


def _setting_bool(name, default=False):
    ad = _addon()
    if not ad:
        return default
    try:
        return bool(ad.getSettingBool(name))
    except Exception:
        return default


def _setting_int(name, default=0):
    ad = _addon()
    if not ad:
        return default
    try:
        return int(ad.getSettingInt(name))
    except Exception:
        return default



def _state_path():
    import os
    return os.path.join(wv.data_dir(), 'provider_sync_state.json')


def _load_state():
    import os
    path = _state_path()
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _save_state(state):
    import os
    path = _state_path()
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, path)


def get_sync_cursor(provider='global'):
    return int((_load_state().get('cursors') or {}).get(provider) or 0)


def set_sync_cursor(provider, seq):
    state = _load_state()
    cursors = state.setdefault('cursors', {})
    cursors[provider] = int(seq or 0)
    state['last_run'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    _save_state(state)


def provider_sync_enabled():
    """False = WatchVault-only (no remote provider push)."""
    return _setting_bool('provider_sync_enabled', False)


def sync_interval_seconds():
    """5 minutes .. 12 hours (settings store minutes)."""
    minutes = _setting_int('provider_sync_minutes', 60)
    minutes = max(5, min(12 * 60, minutes or 60))
    return minutes * 60


def _http_json(method, url, headers=None, body=None, timeout=30):
    headers = dict(headers or {})
    headers.setdefault('Accept', 'application/json')
    headers.setdefault('User-Agent', 'WatchVault-ProviderSync')
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8')
            return r.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            err = e.read().decode('utf-8')
            payload = json.loads(err) if err else {'error': str(e)}
        except Exception:
            payload = {'error': str(e)}
        return e.code, payload
    except Exception as e:
        return 0, {'error': str(e)}


def watched_payload():
    """Build provider-friendly watched structure from the local DB.

    Returns:
      {
        'shows': [
          {'ids': {'tmdb':..,'tvdb':..,'imdb':..}, 'title':.., 'year':..,
           'seasons': [{'number': 1, 'episodes': [{'number': 1}, ...]}]}
        ],
        'movies': [{'ids': {...}, 'title':.., 'year':..}]
      }
    """
    shows_out = []
    movies_out = []
    with wv.db() as con:
        shows = list(con.execute(
            'SELECT id, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id FROM shows'))
        for s in shows:
            eps = list(con.execute(
                'SELECT season, episode FROM episodes WHERE show_id=? AND watched=1 '
                'ORDER BY season, episode', (s['id'],)))
            if not eps:
                continue
            ids = _pack_ids(s)
            # MDBList/Trakt/Simkl resolve shows via tmdb/tvdb/imdb (not anilist/mal alone)
            if not any(ids.get(k) for k in ('tmdb', 'tvdb', 'imdb')):
                continue
            by_season = {}
            for e in eps:
                by_season.setdefault(int(e['season']), []).append({'number': int(e['episode'])})
            seasons = [{'number': sn, 'episodes': by_season[sn]} for sn in sorted(by_season)]
            shows_out.append({
                'ids': ids,
                'title': s['title'],
                'year': s['year'],
                'seasons': seasons,
            })
        for m in con.execute(
                'SELECT title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id FROM movies WHERE watched=1'):
            ids = _pack_ids(m)
            if not any(ids.get(k) for k in ('tmdb', 'tvdb', 'imdb')):
                continue
            movies_out.append({'ids': ids, 'title': m['title'], 'year': m['year']})
    return {'shows': shows_out, 'movies': movies_out}




def changes_delta(since_seq=0, limit=2000):
    """Incremental add/remove sets from the change log (not a full library dump).

    Returns:
      {
        'since': int, 'until': int, 'full': bool,
        'add_shows': [... same shape as watched_payload shows ...],
        'remove_shows': [...],
        'add_movies': [...],
        'remove_movies': [...],
      }
    """
    since_seq = int(since_seq or 0)
    max_seq = wv.last_seq()
    # Same gap rule as pull_changes: change log is capped (~5000 rows). If the
    # oldest remaining seq is newer than cursor+1, we already lost history —
    # force a full provider sync instead of silently skipping missed events.
    full_marker = {
        'since': since_seq, 'until': max_seq, 'full': True,
        'add_shows': [], 'remove_shows': [], 'add_movies': [], 'remove_movies': [],
    }
    if since_seq > max_seq:
        return full_marker
    try:
        with wv.db() as con:
            min_row = con.execute('SELECT MIN(seq) FROM changes').fetchone()
        min_seq = min_row[0] if min_row else None
    except Exception:
        min_seq = None
    if since_seq > 0 and min_seq is not None and min_seq > since_seq + 1:
        return full_marker
    rows = wv.get_changes(since=since_seq, limit=limit)
    # Explicit wipe / full marker in the window → full-sync
    if any(r.get('kind') == 'full' for r in rows):
        return full_marker
    # Collapse to latest state per media key
    ep_state = {}  # (tvdb,tmdb,imdb,anilist,mal,season,episode) -> watched bool + meta
    movie_state = {}
    for r in rows:
        kind = r.get('kind')
        if kind not in ('episode', 'movie'):
            continue
        ids = {
            'tvdb': r.get('tvdb_id'),
            'tmdb': r.get('tmdb_id'),
            'imdb': r.get('imdb_id'),
            'anilist': r.get('anilist_id'),
            'mal': r.get('mal_id'),
        }
        # drop empty
        ids = {k: v for k, v in ids.items() if v not in (None, '', 0)}
        if not any(ids.get(k) for k in ('tvdb', 'tmdb', 'imdb')):
            continue
        watched = r.get('watched')
        if watched is None:
            continue
        watched = bool(int(watched))
        meta = {
            'ids': ids,
            'title': r.get('title'),
            'year': r.get('year'),
        }
        if kind == 'episode':
            s, e = r.get('season'), r.get('episode')
            if s is None or e is None:
                continue
            key = (ids.get('tvdb'), ids.get('tmdb'), ids.get('imdb'), int(s), int(e))
            ep_state[key] = (watched, meta, int(s), int(e))
        else:
            key = (ids.get('tvdb'), ids.get('tmdb'), ids.get('imdb'))
            movie_state[key] = (watched, meta)

    def _fold_eps(want_watched):
        by_show = {}
        for key, (watched, meta, s, e) in ep_state.items():
            if watched != want_watched:
                continue
            idkey = tuple(sorted((meta['ids'] or {}).items()))
            slot = by_show.setdefault(idkey, {
                'ids': meta['ids'], 'title': meta.get('title'), 'year': meta.get('year'),
                'seasons': {},
            })
            slot['seasons'].setdefault(s, []).append({'number': e})
        out = []
        for slot in by_show.values():
            seasons = [{'number': sn, 'episodes': sorted(eps, key=lambda x: x['number'])}
                       for sn, eps in sorted(slot['seasons'].items())]
            out.append({
                'ids': slot['ids'], 'title': slot['title'], 'year': slot['year'],
                'seasons': seasons,
            })
        return out

    add_movies, remove_movies = [], []
    for key, (watched, meta) in movie_state.items():
        row = {'ids': meta['ids'], 'title': meta.get('title'), 'year': meta.get('year')}
        (add_movies if watched else remove_movies).append(row)

    until = max([since_seq] + [r.get('seq') or 0 for r in rows] + [0])
    return {
        'since': since_seq,
        'until': max(until, max_seq) if not rows else until,
        'full': False,
        'add_shows': _fold_eps(True),
        'remove_shows': _fold_eps(False),
        'add_movies': add_movies,
        'remove_movies': remove_movies,
    }


def _pack_ids(row):
    """All ids we store locally (TVDB first, then TMDb/IMDb/AniList/MAL)."""
    ids = {}
    if row['tvdb_id']:
        ids['tvdb'] = int(row['tvdb_id'])
    if row['tmdb_id']:
        ids['tmdb'] = int(row['tmdb_id'])
    if row['imdb_id']:
        ids['imdb'] = row['imdb_id']
    if row['anilist_id']:
        ids['anilist'] = int(row['anilist_id'])
    if row['mal_id']:
        ids['mal'] = int(row['mal_id'])
    return ids


def _provider_ids(ids, provider='mdblist'):
    """Ids accepted by each remote history API.

    Order is always TVDB first, then TMDb, then IMDb (when present together).
    MDBList (tested): tvdb, tmdb, imdb each work alone; mal/anilist alone do not.
    Trakt/Simkl: same three keys.
    PunchPlay history paths are TMDb-based; tvdb/imdb still help local matching.
    """
    ids = ids or {}
    out = {}
    for key in ('tvdb', 'tmdb', 'imdb'):  # TVDB first when sent together
        if ids.get(key):
            out[key] = ids[key]
    return out


# ----- MDBList -----

def _mdblist_client_id():
    return (_setting('mdblist_client_id') or '').strip()


def _mdblist_token():
    """OAuth access token only. MDBList rejects API keys as Bearer; query ?apikey= is not used."""
    return (_setting('mdblist_token') or '').strip()


def _mdblist_headers():
    token = _mdblist_token()
    if not token:
        return None
    return {
        'Authorization': 'Bearer %s' % token,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'User-Agent': 'WatchVault-ProviderSync',
    }


def _mdblist_refresh_token():
    refresh = (_setting('mdblist_refresh_token') or '').strip()
    client = _mdblist_client_id()
    if not refresh or not client:
        return False
    status, res = _http_json(
        'POST', 'https://api.mdblist.com/oauth/token/',
        body=None,
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
    )
    # form body
    import urllib.request
    data = urllib.parse.urlencode({
        'grant_type': 'refresh_token',
        'refresh_token': refresh,
        'client_id': client,
    }).encode('utf-8')
    req = urllib.request.Request(
        'https://api.mdblist.com/oauth/token/',
        data=data,
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json',
                 'User-Agent': 'WatchVault-ProviderSync'},
        method='POST')
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode('utf-8'))
    except Exception:
        return False
    access = (res or {}).get('access_token')
    if not access:
        return False
    _set_setting('mdblist_token', access)
    if res.get('refresh_token'):
        _set_setting('mdblist_refresh_token', res['refresh_token'])
    return True


def _mdblist_request(method, path, body=None, _retried=False):
    headers = _mdblist_headers()
    if not headers:
        return 0, {'error': 'no_token'}
    url = 'https://api.mdblist.com/' + path.lstrip('/')
    status, res = _http_json(method, url, headers=headers, body=body)
    if status == 401 and not _retried and _mdblist_refresh_token():
        return _mdblist_request(method, path, body=body, _retried=True)
    return status, res


def _mdblist_body_from_shows_movies(shows, movies):
    body = {'shows': [], 'movies': []}
    for show in shows or []:
        entry_ids = _provider_ids(show.get('ids'), 'mdblist')
        if not entry_ids:
            continue
        body['shows'].append({'ids': entry_ids, 'seasons': show.get('seasons') or []})
    for movie in movies or []:
        entry_ids = _provider_ids(movie.get('ids'), 'mdblist')
        if not entry_ids:
            continue
        body['movies'].append({'ids': entry_ids})
    return body


def _mdblist_post_chunks(path, body):
    """POST body in show batches of 20. path is sync/watched or sync/watched/remove."""
    updated = {'movies': 0, 'episodes': 0, 'shows': 0, 'seasons': 0}
    removed = {'movies': 0, 'episodes': 0, 'shows': 0, 'seasons': 0}
    errors = []
    shows = body.get('shows') or []
    movies = body.get('movies') or []
    for i in range(0, max(len(shows), 1) if shows else 0, 20) if shows else []:
        pass
    for i in range(0, len(shows), 20):
        chunk = {'shows': shows[i:i + 20], 'movies': []}
        status, res = _mdblist_request('POST', path, body=chunk)
        if status != 200:
            errors.append({'status': status, 'body': res, 'path': path})
            continue
        for bag_name, bag in (('updated', updated), ('removed', removed)):
            u = (res or {}).get(bag_name) or {}
            for k in bag:
                bag[k] += int(u.get(k) or 0)
    if movies:
        status, res = _mdblist_request('POST', path, body={'shows': [], 'movies': movies})
        if status != 200:
            errors.append({'status': status, 'body': res, 'path': path})
        else:
            for bag_name, bag in (('updated', updated), ('removed', removed)):
                u = (res or {}).get(bag_name) or {}
                for k in bag:
                    bag[k] += int(u.get(k) or 0)
    return {'updated': updated, 'removed': removed, 'errors': errors}


def mdblist_push(payload=None, delta=None, full=False):
    if not _setting_bool('mdblist_sync_enabled', False):
        return {'ok': False, 'provider': 'mdblist', 'error': 'disabled'}
    if not _mdblist_token():
        return {'ok': False, 'provider': 'mdblist', 'error': 'no_token'}

    # Full snapshot path
    if full or payload is not None and delta is None:
        payload = payload or watched_payload()
        body = _mdblist_body_from_shows_movies(payload.get('shows'), payload.get('movies'))
        if not body['shows'] and not body['movies']:
            return {'ok': True, 'provider': 'mdblist', 'mode': 'full', 'skipped': 'empty'}
        result = _mdblist_post_chunks('sync/watched', body)
        return {
            'ok': not result['errors'],
            'provider': 'mdblist',
            'mode': 'full',
            'updated': result['updated'],
            'errors': result['errors'] or None,
            'shows': len(body['shows']),
            'movies': len(body['movies']),
        }

    # Incremental: adds + removes
    delta = delta or {}
    add_body = _mdblist_body_from_shows_movies(delta.get('add_shows'), delta.get('add_movies'))
    rem_body = _mdblist_body_from_shows_movies(delta.get('remove_shows'), delta.get('remove_movies'))
    results = {'updated': {}, 'removed': {}, 'errors': []}
    if add_body['shows'] or add_body['movies']:
        r = _mdblist_post_chunks('sync/watched', add_body)
        results['updated'] = r['updated']
        results['errors'].extend(r['errors'])
    if rem_body['shows'] or rem_body['movies']:
        r = _mdblist_post_chunks('sync/watched/remove', rem_body)
        results['removed'] = r['removed']
        results['errors'].extend(r['errors'])
    return {
        'ok': not results['errors'],
        'provider': 'mdblist',
        'mode': 'incremental',
        'updated': results['updated'],
        'removed': results['removed'],
        'errors': results['errors'] or None,
        'add_shows': len(add_body['shows']),
        'remove_shows': len(rem_body['shows']),
        'add_movies': len(add_body['movies']),
        'remove_movies': len(rem_body['movies']),
    }


def mdblist_device_start():
    client = _mdblist_client_id()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    # form-encoded device authorization (MDBList OAuth)
    data = urllib.parse.urlencode({'client_id': client, 'scope': 'write'}).encode('utf-8')
    req = urllib.request.Request(
        'https://api.mdblist.com/oauth/device-authorization/',
        data=data,
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json',
                 'User-Agent': 'WatchVault-ProviderSync'},
        method='POST')
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            res = json.loads(e.read().decode('utf-8'))
        except Exception:
            res = {'error': str(e)}
        return {'ok': False, 'status': e.code, 'error': res}
    except Exception as e:
        return {'ok': False, 'error': str(e)}
    if not isinstance(res, dict) or not res.get('device_code'):
        return {'ok': False, 'error': res}
    res['ok'] = True
    return res


def mdblist_device_poll(device_code, client_id=None):
    client = (client_id or _mdblist_client_id()).strip()
    data = urllib.parse.urlencode({
        'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
        'device_code': device_code,
        'client_id': client,
    }).encode('utf-8')
    req = urllib.request.Request(
        'https://api.mdblist.com/oauth/token/',
        data=data,
        headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json',
                 'User-Agent': 'WatchVault-ProviderSync'},
        method='POST')
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            res = json.loads(e.read().decode('utf-8'))
        except Exception:
            res = {'error': str(e)}
        return {'ok': False, 'status': e.code, 'error': res}
    except Exception as e:
        return {'ok': False, 'error': str(e)}
    access = (res or {}).get('access_token')
    if not access:
        return {'ok': False, 'error': res}
    _store_login_token('mdblist_token', access)
    if res.get('refresh_token'):
        _store_login_token('mdblist_refresh_token', res['refresh_token'])
    return {'ok': True, 'token_saved': True}


# ----- Trakt / Simkl / PunchPlay (credentials + structure; push when configured) -----

def _history_body_from_shows_movies(shows, movies):
    """Trakt/Simkl shared history JSON shape."""
    body = {'shows': [], 'movies': []}
    for show in shows or []:
        ids = _provider_ids(show.get('ids'), 'trakt')
        if not ids:
            continue
        body['shows'].append({'ids': ids, 'seasons': show.get('seasons') or []})
    for movie in movies or []:
        ids = _provider_ids(movie.get('ids'), 'trakt')
        if not ids:
            continue
        body['movies'].append({'ids': ids})
    return body


def trakt_push(payload=None, delta=None, full=False):
    token = (_setting('trakt_token') or '').strip()
    client = (_setting('trakt_client_id') or '').strip()
    if not _setting_bool('trakt_sync_enabled', False):
        return {'ok': False, 'provider': 'trakt', 'error': 'disabled'}
    if not token or not client:
        return {'ok': False, 'provider': 'trakt', 'error': 'not_configured'}
    headers = {
        'Authorization': 'Bearer %s' % token,
        'trakt-api-version': '2',
        'trakt-api-key': client,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    def _post(path, shows, movies):
        body = _history_body_from_shows_movies(shows, movies)
        if not body['shows'] and not body['movies']:
            return {'ok': True, 'empty': True, 'status': 0}
        status, res = _http_json('POST', 'https://api.trakt.tv/' + path, headers=headers, body=body)
        ok = status in (200, 201)
        # 0 added/deleted with empty not_found is still ok (already in desired state)
        if status in (200, 201) and isinstance(res, dict):
            not_found = res.get('not_found') or {}
            if any(not_found.get(k) for k in ('movies', 'shows', 'seasons', 'episodes')):
                ok = False
        return {'ok': ok, 'status': status, 'result': res, 'body_counts': {
            'shows': len(body['shows']), 'movies': len(body['movies'])}}

    if full or (payload is not None and delta is None):
        payload = payload or watched_payload()
        r = _post('sync/history', payload.get('shows'), payload.get('movies'))
        return {'ok': r['ok'], 'provider': 'trakt', 'mode': 'full', **r}

    delta = delta or {}
    add = _post('sync/history', delta.get('add_shows'), delta.get('add_movies'))
    rem = _post('sync/history/remove', delta.get('remove_shows'), delta.get('remove_movies'))
    return {
        'ok': add.get('ok', True) and rem.get('ok', True),
        'provider': 'trakt',
        'mode': 'incremental',
        'add': add,
        'remove': rem,
    }


def simkl_push(payload=None, delta=None, full=False):
    token = (_setting('simkl_token') or '').strip()
    client = (_setting('simkl_client_id') or '').strip()
    if not _setting_bool('simkl_sync_enabled', False):
        return {'ok': False, 'provider': 'simkl', 'error': 'disabled'}
    if not token or not client:
        return {'ok': False, 'provider': 'simkl', 'error': 'not_configured'}
    headers = {
        'Authorization': 'Bearer %s' % token,
        'simkl-api-key': client,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    def _post(path, shows, movies):
        body = _history_body_from_shows_movies(shows, movies)
        if not body['shows'] and not body['movies']:
            return {'ok': True, 'empty': True, 'status': 0}
        status, res = _http_json('POST', 'https://api.simkl.com/' + path, headers=headers, body=body)
        return {'ok': status in (200, 201), 'status': status, 'result': res}

    if full or (payload is not None and delta is None):
        payload = payload or watched_payload()
        r = _post('sync/history', payload.get('shows'), payload.get('movies'))
        return {'ok': r['ok'], 'provider': 'simkl', 'mode': 'full', **r}

    delta = delta or {}
    add = _post('sync/history', delta.get('add_shows'), delta.get('add_movies'))
    rem = _post('sync/history/remove', delta.get('remove_shows'), delta.get('remove_movies'))
    return {
        'ok': add.get('ok', True) and rem.get('ok', True),
        'provider': 'simkl',
        'mode': 'incremental',
        'add': add,
        'remove': rem,
    }


def _punchplay_title_id(ids):
    """Routable PunchPlay title id (docs: TMDB | imdb tt | tvdb:N | mal:N).

    Preference: TVDB first, then TMDb, then MAL, then IMDb.
    AniList is not a documented PunchPlay title id.
    """
    ids = ids or {}
    if ids.get('tvdb'):
        return 'tvdb:%s' % int(ids['tvdb'])
    if ids.get('tmdb'):
        return str(int(ids['tmdb']))
    if ids.get('mal'):
        return 'mal:%s' % int(ids['mal'])
    if ids.get('imdb'):
        return str(ids['imdb'])
    return None


def _punchplay_headers():
    token = (_setting('punchplay_token') or '').strip()
    if not token:
        return None
    return {
        'Authorization': 'Bearer %s' % token,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'WatchVault-ProviderSync',
    }


def _punchplay_apply(shows, movies, remove=False):
    """POST watch or DELETE history for shows/movies lists."""
    headers = _punchplay_headers()
    if not headers:
        return {'ok': False, 'error': 'no_token'}
    base = 'https://punchplay.tv/api/platform/v1'
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())
    ok_n = fail_n = skip_n = 0
    errors = []
    method = 'DELETE' if remove else 'POST'
    for show in shows or []:
        tid = _punchplay_title_id(show.get('ids'))
        if not tid:
            skip_n += 1
            continue
        title = show.get('title') or 'Unknown'
        year = int(show.get('year') or 0)
        for season in show.get('seasons') or []:
            sn = int(season.get('number'))
            quoted = urllib.parse.quote(str(tid), safe=':')
            if remove:
                # DELETE season watch clears those episodes; fall back to whole-title history delete
                url = '%s/title/show/%s/season/%s/watch' % (base, quoted, sn)
                status, res = _http_json('DELETE', url, headers=headers)
                if status not in (200, 201, 204) or (isinstance(res, dict) and res.get('error')):
                    url2 = '%s/title/show/%s/history' % (base, quoted)
                    status, res = _http_json('DELETE', url2, headers=headers)
            else:
                ep_rows = []
                for ep in season.get('episodes') or []:
                    num = int(ep.get('number'))
                    ep_rows.append({
                        'episodeNumber': num,
                        'name': 'Episode %s' % num,
                        'watchedAt': watched_at,
                    })
                if not ep_rows:
                    continue
                body = {
                    'episodes': ep_rows,
                    'title': title,
                    'year': year,
                    'watchedAt': watched_at,
                }
                url = '%s/title/show/%s/season/%s/watch' % (base, quoted, sn)
                status, res = _http_json('POST', url, headers=headers, body=body)
            if status in (200, 201, 204) and not (isinstance(res, dict) and res.get('error')):
                ok_n += 1
            else:
                fail_n += 1
                errors.append({'url': url if 'url' in dir() else None, 'status': status, 'body': res})
    for movie in movies or []:
        tid = _punchplay_title_id(movie.get('ids'))
        if not tid:
            skip_n += 1
            continue
        quoted = urllib.parse.quote(str(tid), safe=':')
        url = '%s/title/movie/%s/history' % (base, quoted)
        if remove:
            status, res = _http_json('DELETE', url, headers=headers)
        else:
            body = {
                'title': movie.get('title') or 'Unknown',
                'year': int(movie.get('year') or 0),
                'watchedAt': watched_at,
            }
            status, res = _http_json('POST', url, headers=headers, body=body)
        if status in (200, 201, 204) and not (isinstance(res, dict) and res.get('error')):
            ok_n += 1
        else:
            fail_n += 1
            errors.append({'url': url, 'status': status, 'body': res})
    return {
        'ok': fail_n == 0,
        'posted': ok_n,
        'failed': fail_n,
        'skipped_no_id': skip_n,
        'errors': errors[:5] if errors else None,
        'remove': remove,
    }


def punchplay_push(payload=None, delta=None, full=False):
    if not _setting_bool('punchplay_sync_enabled', False):
        return {'ok': False, 'provider': 'punchplay', 'error': 'disabled'}
    if not (_setting('punchplay_token') or '').strip():
        return {'ok': False, 'provider': 'punchplay', 'error': 'not_configured'}

    if full or (payload is not None and delta is None):
        payload = payload or watched_payload()
        r = _punchplay_apply(payload.get('shows'), payload.get('movies'), remove=False)
        return {'ok': r.get('ok'), 'provider': 'punchplay', 'mode': 'full', **r}

    delta = delta or {}
    add = _punchplay_apply(delta.get('add_shows'), delta.get('add_movies'), remove=False)
    rem = _punchplay_apply(delta.get('remove_shows'), delta.get('remove_movies'), remove=True)
    return {
        'ok': add.get('ok', True) and rem.get('ok', True),
        'provider': 'punchplay',
        'mode': 'incremental',
        'add': add,
        'remove': rem,
    }


def punchplay_device_start():
    """POST /api/platform/v1/auth/device/code"""
    client = (_setting('punchplay_client_id') or '').strip()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    device_id = (_setting('punchplay_device_id') or '').strip()
    if not device_id:
        import uuid
        device_id = str(uuid.uuid4())
        _set_setting('punchplay_device_id', device_id)
    body = {'client_id': client, 'device_id': device_id}
    status, res = _http_json(
        'POST', 'https://punchplay.tv/api/platform/v1/auth/device/code', body=body)
    if status not in (200, 201) or not isinstance(res, dict):
        # camelCase variant some builds accept
        status, res = _http_json(
            'POST', 'https://punchplay.tv/api/platform/v1/auth/device/code',
            body={'clientId': client, 'deviceId': device_id})
    if status not in (200, 201) or not isinstance(res, dict):
        return {'ok': False, 'status': status, 'error': res}
    res['ok'] = True
    return res


def punchplay_device_poll(device_code, client_id=None):
    """POST /api/platform/v1/auth/device/token"""
    client = (client_id or _setting('punchplay_client_id') or '').strip()
    body = {'client_id': client, 'device_code': device_code}
    status, res = _http_json(
        'POST', 'https://punchplay.tv/api/platform/v1/auth/device/token', body=body)
    if status not in (200, 201) or not (isinstance(res, dict) and res.get('access_token')):
        status, res = _http_json(
            'POST', 'https://punchplay.tv/api/platform/v1/auth/device/token',
            body={'clientId': client, 'deviceCode': device_code})
    if status in (200, 201) and isinstance(res, dict) and (
            res.get('access_token') or res.get('accessToken')):
        token = res.get('access_token') or res.get('accessToken')
        refresh = res.get('refresh_token') or res.get('refreshToken')
        _store_login_token('punchplay_token', token)
        if refresh:
            _store_login_token('punchplay_refresh_token', refresh)
        return {'ok': True, 'token_saved': True}
    return {'ok': False, 'status': status, 'error': res}



def run_provider_sync(force=False):
    """Push local watched changes to enabled providers.

    Uses the change-log cursor for incremental add/remove on every provider.
    force=True or a full marker / empty cursor triggers a full watched snapshot.
    """
    if not force and not provider_sync_enabled():
        return {'ok': True, 'mode': 'watchvault_only', 'providers': []}

    max_seq = wv.last_seq()
    results = []
    providers = []
    if _setting_bool('mdblist_sync_enabled', False):
        providers.append(('mdblist', mdblist_push))
    if _setting_bool('trakt_sync_enabled', False):
        providers.append(('trakt', trakt_push))
    if _setting_bool('simkl_sync_enabled', False):
        providers.append(('simkl', simkl_push))
    if _setting_bool('punchplay_sync_enabled', False):
        providers.append(('punchplay', punchplay_push))

    for name, fn in providers:
        try:
            cursor = get_sync_cursor(name)
            delta = changes_delta(since_seq=cursor)
            need_full = force or delta.get('full') or cursor <= 0
            if need_full:
                res = fn(full=True)
            elif (delta.get('add_shows') or delta.get('remove_shows')
                  or delta.get('add_movies') or delta.get('remove_movies')):
                res = fn(delta=delta)
            else:
                res = {'ok': True, 'provider': name, 'mode': 'incremental', 'skipped': 'no_changes'}
            if res.get('ok'):
                set_sync_cursor(name, max_seq if need_full else max(cursor, int(delta.get('until') or max_seq)))
            results.append(res)
        except Exception as e:
            results.append({'ok': False, 'provider': name, 'error': str(e)})

    any_ok = any(r.get('ok') for r in results) if results else True
    out = {
        'ok': any_ok if results else True,
        'mode': 'providers' if results else 'watchvault_only',
        'max_seq': max_seq,
        'providers': results,
        'ts': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    try:
        import os
        path = os.path.join(wv.data_dir(), 'provider_sync_stats.json')
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(out, f, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass
    return out



# ----- Login / device OAuth helpers (Kodi dialogs call these) -----

class TokenSaveError(RuntimeError):
    pass


def _log_token(msg):
    try:
        import xbmc
        xbmc.log('[WatchVault login] ' + msg, xbmc.LOGERROR)
    except Exception:
        pass


def _store_login_token(name, value):
    """Save a login token and read it back. Raises TokenSaveError if it did not stick."""
    value = '' if value is None else str(value)
    ad = _addon()
    if not ad:
        _log_token('%s: add-on settings object unavailable' % name)
        raise TokenSaveError('could not save %s (add-on settings unavailable)' % name)
    try:
        ad.setSettingString(name, value)
    except Exception as e:
        _log_token('%s: setSettingString failed: %r' % (name, e))
        try:
            ad.setSetting(name, value)
        except Exception as e2:
            _log_token('%s: setSetting failed: %r' % (name, e2))
            raise TokenSaveError('could not save %s: %s' % (name, e2))
    try:
        back = ad.getSettingString(name) or ''
    except Exception as e:
        _log_token('%s: read-back failed: %r' % (name, e))
        raise TokenSaveError('could not read back %s: %s' % (name, e))
    if back.strip() != value.strip():
        _log_token('%s: read back %d chars, expected %d' % (name, len(back), len(value)))
        raise TokenSaveError('%s did not persist after login' % name)
    try:
        import xbmc
        xbmc.log('[WatchVault login] %s: saved and read back OK (%d chars)' % (name, len(back)), xbmc.LOGWARNING)
    except Exception:
        pass
    return True


def _set_setting(name, value):
    ad = _addon()
    if not ad:
        return
    try:
        ad.setSettingString(name, value if value is not None else '')
    except Exception:
        try:
            ad.setSetting(name, value if value is not None else '')
        except Exception:
            pass


def mdblist_test_key():
    if not _mdblist_token():
        return {'ok': False, 'error': 'no_token'}
    status, res = _mdblist_request('GET', 'user')
    if status != 200:
        return {'ok': False, 'status': status, 'error': res}
    return {'ok': True, 'username': (res or {}).get('username'), 'user_id': (res or {}).get('user_id')}



def trakt_device_start():
    client = (_setting('trakt_client_id') or '').strip()
    secret = (_setting('trakt_client_secret') or '').strip()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client,
    }
    status, res = _http_json(
        'POST', 'https://api.trakt.tv/oauth/device/code',
        headers=headers, body={'client_id': client})
    if status not in (200, 201) or not isinstance(res, dict):
        return {'ok': False, 'status': status, 'error': res}
    res['ok'] = True
    res['_client_id'] = client
    res['_client_secret'] = secret
    return res


def trakt_device_poll(device_code, client_id=None, client_secret=None):
    client = (client_id or _setting('trakt_client_id') or '').strip()
    secret = (client_secret or _setting('trakt_client_secret') or '').strip()
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client,
    }
    body = {
        'code': device_code,
        'client_id': client,
        'client_secret': secret,
    }
    status, res = _http_json(
        'POST', 'https://api.trakt.tv/oauth/device/token',
        headers=headers, body=body)
    if status in (200, 201) and isinstance(res, dict) and res.get('access_token'):
        _store_login_token('trakt_token', res['access_token'])
        if res.get('refresh_token'):
            _store_login_token('trakt_refresh_token', res['refresh_token'])
        return {'ok': True, 'token_saved': True}
    return {'ok': False, 'status': status, 'error': res}


def simkl_device_start():
    client = (_setting('simkl_client_id') or '').strip()
    if not client:
        return {'ok': False, 'error': 'need_client_id'}
    status, res = _http_json(
        'POST', 'https://api.simkl.com/oauth2/device',
        body={'client_id': client, 'scope': 'simkl'})
    if status not in (200, 201) or not isinstance(res, dict):
        return {'ok': False, 'status': status, 'error': res}
    res['ok'] = True
    return res


def simkl_device_poll(device_code, client_id=None):
    client = (client_id or _setting('simkl_client_id') or '').strip()
    status, res = _http_json(
        'POST', 'https://api.simkl.com/oauth2/token',
        body={
            'client_id': client,
            'device_code': device_code,
            'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
        })
    if status in (200, 201) and isinstance(res, dict) and res.get('access_token'):
        _store_login_token('simkl_token', res['access_token'])
        if res.get('refresh_token'):
            _store_login_token('simkl_refresh_token', res['refresh_token'])
        return {'ok': True, 'token_saved': True}
    return {'ok': False, 'status': status, 'error': res}


def punchplay_save_tokens(access_token, refresh_token=None):
    access_token = (access_token or '').strip()
    if not access_token:
        return {'ok': False, 'error': 'empty_token'}
    _store_login_token('punchplay_token', access_token)
    if refresh_token:
        _store_login_token('punchplay_refresh_token', refresh_token.strip())
    return {'ok': True}
