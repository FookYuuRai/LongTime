# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import json
import re
import sys
import traceback
from urllib.parse import parse_qsl, urlencode

try:
    import AutoCompletion
    AC_IMPORT_ERROR = ''
except Exception as _exc:   # script.module.autocompletion missing or broken: say so in the log instead of failing silently
    AutoCompletion = None
    AC_IMPORT_ERROR = str(_exc)

ADDON = xbmcaddon.Addon()
ADDON_VERSION = ADDON.getAddonInfo('version')


def get_kodi_json(method, params):
    query_params = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    json_query = xbmc.executeJSONRPC(json.dumps(query_params))

    return json.loads(json_query)


def get_raw_query(args):
    """The skin sends id unencoded (e.g. 'Tom & Jerry'), so take everything
    after 'id=' up to '&limit=' as the search text."""
    match = re.search(r"(?:^|&)id=(.*?)(?=&limit=|$)", args)
    return match.group(1) if match else ""


def start_info_actions(infos, params):
    listitems = []
    for info in infos:
        if info == 'autocomplete':
            text = params.get("id", "")
            xbmc.log(f"autocompletion: request '{text}' limit {params.get('limit', 10)}", xbmc.LOGINFO)
            xbmc.log(f"autocompletion: all params {params}", xbmc.LOGINFO)
            if AutoCompletion is None:
                xbmc.log(f"autocompletion: script.module.autocompletion not importable: {AC_IMPORT_ERROR}", xbmc.LOGERROR)
            else:
                try:
                    listitems = AutoCompletion.get_autocomplete_items(text, params.get("limit", 10))
                except Exception:
                    xbmc.log("autocompletion: lookup failed:\n" + traceback.format_exc(), xbmc.LOGERROR)
                    listitems = []
                xbmc.log(f"autocompletion: {len(listitems or [])} suggestion(s) for '{text}'", xbmc.LOGINFO)
        elif info == 'selectautocomplete':
            xbmc.log(f"autocompletion: selected '{params.get('id')}'", xbmc.LOGINFO)
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.sleep(500)
            get_kodi_json(
                method="Input.SendText",
                params={"text": params.get("id"), "done": False},
            )
            xbmc.executebuiltin('ActivateWindowAndFocus(virtualkeyboard,300,0)')

        xbmc.log(f"autocompletion: passing {len(listitems or [])} item(s) to skin, handle={params.get('handle')!r}", xbmc.LOGINFO)
        try:
            pass_list_to_skin(
                data=listitems,
                handle=params.get("handle", ""),
                limit=params.get("limit", 20),
            )
        except Exception:
            xbmc.log("autocompletion: display failed:\n" + traceback.format_exc(), xbmc.LOGERROR)


def pass_list_to_skin(data=[], handle=None, limit=False):
    if data and limit and int(limit) < len(data):
        data = data[: int(limit)]

    if handle and data:
        items = create_listitems(data)
        ok = xbmcplugin.addDirectoryItems(
            handle=handle,
            items=[(i.getProperty("path"), i, False) for i in items],
            totalItems=len(items),
        )
        xbmc.log(f"autocompletion: addDirectoryItems submitted {len(items)} item(s), success={ok}", xbmc.LOGINFO)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
    else:
        xbmc.log(f"autocompletion: nothing to display (handle={handle!r}, items={len(data or [])})", xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(handle)


def create_listitems(data=None):
    if not data:
        return []
    itemlist = []
    for count, result in enumerate(data):
        xbmc.log(f"autocompletion: item {count}: label={result.get('label')!r} search_string={result.get('search_string')!r}", xbmc.LOGINFO)
        listitem = xbmcgui.ListItem(str(count))
        for key, value in result.items():
            if not value:
                continue
            if key.lower() in ["label"]:
                listitem.setLabel(value)
            elif key.lower() in ["search_string"]:
                path = "plugin://plugin.program.autocompletion.next/?" + urlencode({"info": "selectautocomplete", "id": value})
                listitem.setPath(path=path)
                listitem.setProperty('path', path)
        listitem.setProperty("index", str(count))
        listitem.setProperty("isPlayable", "false")
        itemlist.append(listitem)
    return itemlist


if __name__ == "__main__":
    xbmc.log(f"version {ADDON_VERSION} started", xbmc.LOGINFO)
    args = sys.argv[2][1:]
    handle = int(sys.argv[1])
    infos = []
    params = {"handle": handle}
    params.update(dict(parse_qsl(args, keep_blank_values=True)))
    if params.get("info") == "autocomplete":
        params["id"] = get_raw_query(args)

    if "info" in params:
        infos.append(params['info'])

    if infos:
        start_info_actions(infos, params)

xbmc.log('finished')
