# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

from abc import ABC, abstractmethod
from urllib.parse import quote_plus
import os
import time
import hashlib
import requests
import json

import xbmc
import xbmcaddon
import xbmcvfs

SCRIPT_ID = "script.module.autocompletion"
SCRIPT_ADDON = xbmcaddon.Addon(SCRIPT_ID)
PLUGIN_ID = "plugin.program.autocompletion"
PLUGIN_ADDON = xbmcaddon.Addon(PLUGIN_ID)
SETTING = PLUGIN_ADDON.getSetting
ADDON_PATH = xbmcvfs.translatePath(SCRIPT_ADDON.getAddonInfo("path"))
ADDON_ID = SCRIPT_ADDON.getAddonInfo("id")
ADDON_DATA_PATH = xbmcvfs.translatePath(SCRIPT_ADDON.getAddonInfo("profile"))


def get_autocomplete_items(search_str, limit=10, provider=None):
    """
    get dict list with autocomplete
    """
    if xbmc.getCondVisibility("System.HasHiddenInput"):
        log("lookup skipped: System.HasHiddenInput is true (password/hidden input)")
        return []

    setting = SETTING("autocomplete_provider").lower()

    if setting == "youtube":
        provider = GoogleProvider(youtube=True, limit=limit)
    elif setting == "google":
        provider = GoogleProvider(limit=limit)
    elif setting == "bing":
        provider = BingProvider(limit=limit)
    elif setting == "tmdb":
        provider = TmdbProvider(limit=limit)
    else:
        provider = LocalDictProvider(limit=limit)
    provider.limit = limit
    log(f"lookup start: provider={provider.__class__.__name__} setting={setting!r} query={search_str!r} limit={limit}")
    results = provider.get_predictions(search_str)
    log(f"lookup done: {len(results)} suggestion(s) for {search_str!r}")
    return results


def prep_search_str(text):
    for char in text:
        if 1488 <= ord(char) <= 1514:
            return text[::-1]
    return text


class BaseProvider(ABC):

    HEADERS = {'User-agent': 'Mozilla/5.0'}

    def __init__(self, *args, **kwargs):
        self.limit = kwargs.get("limit", 10)
        self.language = SETTING("autocomplete_lang")

    @abstractmethod
    def build_url(self, query):
        pass

    def get_predictions(self, search_str):
        if not search_str:
            return []
        limit = max(0, int(self.limit))
        if not limit:
            return []
        items = []
        result = self.fetch_data(search_str)
        for item in result:
            if not isinstance(item, str) or not item.strip():
                continue
            items.append({"label": item, "search_string": prep_search_str(item)})
            if len(items) >= limit:
                break
        return items

    def get_prediction_listitems(self, search_str):
        yield from self.get_predictions(search_str)

    def fetch_data(self, search_str):
        url = self.build_url(quote_plus(search_str))
        full_url = self.BASE_URL.format(endpoint=url)
        log(f"{self.FOLDER}: request url={full_url}")
        result = get_JSON_response(url=full_url, headers=self.HEADERS, folder=self.FOLDER)
        log(f"{self.FOLDER}: parsed response type={type(result).__name__} "
            f"size={len(result) if isinstance(result, (list, dict)) else 'n/a'}")
        processed = self.process_result(result)
        log(f"{self.FOLDER}: {len(processed)} title(s) after process_result")
        return processed

    def process_result(self, result):
        if not result or len(result) <= 1:
            return []
        else:
            return result[1] if isinstance(result[1], list) else result


class GoogleProvider(BaseProvider):

    BASE_URL = "http://clients1.google.com/complete/{endpoint}"
    FOLDER = "Google"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.youtube = kwargs.get("youtube", False)

    def build_url(self, query):
        url = f"search?hl={self.language}&q={query}&json=t&client=serp"
        if self.youtube:
            url += "&ds=yt"
        return url


class BingProvider(BaseProvider):

    BASE_URL = "http://api.bing.com/osjson.aspx?{endpoint}"
    FOLDER = "Bing"

    def __init__(self, *args, **kwargs):
        super(BingProvider, self).__init__(*args, **kwargs)

    def build_url(self, query):
        url = f"query={query}"
        return url


class TmdbProvider(BaseProvider):

    BASE_URL = "https://www.themoviedb.org/search/multi?{endpoint}"
    FOLDER = "TMDB"
    HEADERS = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
    }

    def build_url(self, query):
        # BaseProvider.fetch_data has already encoded the query.
        language = quote_plus(self.language or "en-US")
        return f"query={query}&language={language}"

    def process_result(self, result):
        if not isinstance(result, dict):
            log(f"TMDB: expected JSON object, got {type(result).__name__}; no titles")
            return []
        results = result.get("results")
        if not isinstance(results, list):
            log(f"TMDB: JSON has no 'results' list (keys={list(result.keys())[:10]}); no titles")
            return []
        skipped = {}

        titles = []
        seen = set()
        for item in results:
            if not isinstance(item, dict):
                continue
            media_type = item.get("media_type")
            if media_type == "movie":
                title = item.get("title") or item.get("original_title")
            elif media_type in ("tv", "person"):
                title = item.get("name") or item.get("original_name")
            else:
                skipped[str(media_type)] = skipped.get(str(media_type), 0) + 1
                continue
            if not isinstance(title, str):
                continue
            title = title.strip()
            key = title.casefold()
            if not title or key in seen:
                continue
            seen.add(key)
            titles.append(title)
        log(f"TMDB: {len(results)} raw result(s), {len(titles)} unique title(s), skipped media types={skipped}")
        return titles


class LocalDictProvider(BaseProvider):
    def __init__(self, *args, **kwargs):
        super(LocalDictProvider, self).__init__(*args, **kwargs)
        local = SETTING("autocomplete_lang_local")
        if local:
            self.language = local
        else:
            self.language = "en"

    def build_url(self, query):
        return super().build_url(query)

    def fetch_data(self, search_str):
        k = search_str.rfind(" ")
        if k >= 0:
            search_str = search_str[k + 1 :]

        path = os.path.join(ADDON_PATH, "resources", "data", f"common_{self.language}.txt")
        suggestions = []

        with xbmcvfs.File(path) as f:
            for line in f.read().split('\n'):
                if not line.startswith(search_str) or len(line) <= 2:
                    continue
                suggestions.append(line)
                if len(suggestions) >= int(self.limit):
                    break

        return suggestions


def get_JSON_response(url="", cache_days=7.0, folder=False, headers=False):
    """
    get JSON response for *url, makes use of file cache.
    """
    now = time.time()
    hashed_url = hashlib.md5(url.encode("utf-8")).hexdigest()
    cache_path = xbmcvfs.translatePath(os.path.join(ADDON_DATA_PATH, folder) if folder else ADDON_DATA_PATH)
    path = os.path.join(cache_path, f"{hashed_url}.txt")
    cache_seconds = int(cache_days * 86400)
    results = []

    if xbmcvfs.exists(path) and ((now - os.path.getmtime(path)) < cache_seconds):
        results = read_from_file(path)
        log(f"loaded file for {url}. time: {float(time.time() - now)}")
    else:
        log(f"cache miss for {url} -> fetching")
        response = get_http(url, headers)
        try:
            results = json.loads(response)
            log(f"download {url}. time: {float(time.time() - now)}")
            try:
                save_to_file(results, hashed_url, cache_path)
            except Exception as exc:
                log(f"Could not save JSON cache: {exc}")
        except Exception as exc:
            body = response or ""
            log(f"Exception: could not parse JSON from {url} ({exc!r}). body length={len(body)}, "
                f"first 300 chars={body[:300]!r}. Trying cache fallback")
            results = read_from_file(path)

    return results


def get_http(url, headers):
    """
    fetches data from *url, returns it as a string
    """
    succeed = 0
    monitor = xbmc.Monitor()
    while (succeed < 2) and (not monitor.abortRequested()):
        try:
            response = requests.get(url, headers=headers or {}, timeout=(5, 15))
            log(f"get_http: HTTP {response.status_code} content-type={response.headers.get('Content-Type')!r} "
                f"bytes={len(response.content)} final_url={response.url}")
            response.raise_for_status()
            return response.text
        except requests.RequestException as exc:
            log(f"get_http: could not get data from {url}: {exc}")
            monitor.waitForAbort(1)
            succeed += 1
    return None


def read_from_file(path="", raw=False):
    """
    return data from file with *path
    """
    if not xbmcvfs.exists(path):
        return []

    try:
        with xbmcvfs.File(path) as f:
            log(f"opened textfile {path}.")
            if raw:
                return f.read()
            else:
                return json.loads(f.read())
    except Exception:
        log(f"failed to load textfile: {path}")
        return []


def log(txt):
    message = f"{ADDON_ID}: {txt}"
    xbmc.log(msg=message, level=xbmc.LOGINFO)


def save_to_file(content, filename, path=""):
    """
    dump json and save to *filename in *path
    """
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

    text_file_path = os.path.join(path, f"{filename}.txt")
    now = time.time()

    with xbmcvfs.File(text_file_path, "w") as text_file:
        text_file.write(json.dumps(content, ensure_ascii=False))

    log(f"saved textfile {text_file_path}. Time: {float(time.time() - now)}")
    return True
