# -*- coding: utf-8 -*-
"""Buttons of the NIGHTSHIFT ambience settings: add, show and remove music folders.
RunScript(script.service.nightshift.ambience,add|show|remove|clear|rescan|convert|tracks_on|tracks_off)"""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import audioconvert
from musicfolders import android_mediastore
import musicfolders
from tracks import BUILTIN_TRACKS

TITLE = 'NIGHTSHIFT ambience'


def tell_service(message):
	"""JSON-RPC notification the ambience service listens for: it rescans the folders at once instead of polling."""
	try:
		import json
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
			'params': {'sender': 'script.service.nightshift.ambience', 'message': message, 'data': {}}}))
	except Exception as error:
		xbmc.log('[NIGHTSHIFT ambience] could not notify the service: %s' % error, xbmc.LOGINFO)


def notify(text):
	xbmcgui.Dialog().notification(TITLE, text, xbmcgui.NOTIFICATION_INFO, 4000, False)


def add():
	dialog = xbmcgui.Dialog()
	pick = dialog.select('Add a music folder', ['Browse for a folder...', 'Type or paste a folder path...'])
	if pick < 0:
		return
	if pick == 0:
		path = dialog.browse(0, 'Choose a folder with music (it is searched with the folders inside it)', 'music', '', False, False, '')
	else:
		path = dialog.input('Folder path (for example /storage/emulated/0/Music or smb://nas/music)', type=xbmcgui.INPUT_ALPHANUM)
	path = (path or '').strip()
	if not path:
		return
	folders = musicfolders.load()
	if path in folders:
		notify('That folder is already in the list')
		return
	found = musicfolders.scan(path)
	visible = bool(found)
	if not visible:
		try:
			visible = bool(xbmcvfs.exists(path if path.endswith(('/', '\\')) else path + '/'))
		except Exception:
			visible = False
	if not visible:
		if not dialog.yesno(TITLE, 'Kodi could not list this folder or find indexed audio in it right now:\n%s\n\nAdd it anyway?' % path):
			return
	folders.append(path)
	if musicfolders.save(folders):
		tell_service('rescan')
		notify('Added: %d track(s) found' % len(found))
		if not found:
			xbmcgui.Dialog().ok(TITLE, NO_SONGS_HELP)
		try:
			audioconvert.offer_after_add(path)
		except Exception as error:      # the conversion offer must never undo adding a folder
			xbmc.log('[NIGHTSHIFT ambience] conversion offer skipped: %s' % error, xbmc.LOGINFO)
	else:
		notify('The folder could not be saved')


NO_SONGS_HELP = ('0 songs found.\n\nKodi cannot read songs in that folder with media-only access. To copy them in: turn ON "All files access" '
	'for Kodi in Android Settings > Apps > Kodi > Permissions, run Import songs, then set the permission back to media access only.\n\n'
	'The songs are copied into the add-on folder, which Kodi can always read.')


def import_songs():
	"""Copy songs from any folder Kodi can open (USB, network share, a source) into the add-on's own music folder through Kodi's VFS.
	That folder needs no storage permission, so these songs always play."""
	dialog = xbmcgui.Dialog()
	path = dialog.browse(0, 'Choose the folder with the songs to copy in', 'music', '', False, False, '')
	path = (path or '').strip()
	if not path:
		return
	target = musicfolders.own_folder()
	sources = musicfolders.scan(path)
	copied = failed = 0
	if not sources:
		xbmcgui.Dialog().ok(TITLE, NO_SONGS_HELP)
		return
	for source in sources:
		name = source.replace('\\', '/').rsplit('/', 1)[-1]
		destination = os.path.join(target, name)
		if xbmcvfs.exists(destination):
			continue
		try:
			if xbmcvfs.copy(source, destination):
				copied += 1
			else:
				failed += 1
		except Exception:
			failed += 1
	tell_service('rescan')
	notify('Copied %d song(s) into the add-on folder%s' % (copied, (', %d could not be read' % failed) if failed else ''))


def show():
	folders = musicfolders.load()
	if not folders:
		xbmcgui.Dialog().ok(TITLE, 'No extra music folders yet.\nUse "Add a music folder" to add songs to the built-in tracks.')
		return
	lines = ['Add-on music folder (always readable, filled by Import songs):', musicfolders.own_folder(), '']
	lines += ['Extra music folders (played after the built-in tracks):', '']
	total = 0
	for folder in folders:
		count = len(musicfolders.scan(folder))
		total += count
		lines.append('%s\n    %d track(s)' % (folder, count))
	lines += ['', 'Total: %d extra track(s)' % total]
	xbmcgui.Dialog().textviewer(TITLE, '\n'.join(lines))


def remove():
	folders = musicfolders.load()
	if not folders:
		notify('No extra music folders to remove')
		return
	picked = xbmcgui.Dialog().multiselect('Remove which folders?', folders)
	if not picked:
		return
	keep = [f for i, f in enumerate(folders) if i not in picked]
	if musicfolders.save(keep):
		notify('Removed %d folder(s)' % len(picked))


def clear():
	if musicfolders.load() and xbmcgui.Dialog().yesno(TITLE, 'Remove all extra music folders?'):
		musicfolders.save([])
		notify('All extra folders removed')


def rescan():
	"""Ask Android's MediaStore and Kodi again for every added folder, then tell the service to rebuild its playlist."""
	android_mediastore.clear_cache()
	total = sum(len(musicfolders.scan(folder)) for folder in musicfolders.load())
	tell_service('rescan')
	notify('Rescanned: %d extra track(s) found' % total)
	if total == 0 and musicfolders.load():
		xbmcgui.Dialog().ok(TITLE, NO_SONGS_HELP.replace('run Import songs', 'run Import songs (or copy them to the add-on music folder)'))


def convert():
	"""Convert the music of the added folders to Opus 96 kbps with the libffmpeg inside this add-on."""
	audioconvert.run()


def set_all_tracks(value):
	addon = xbmcaddon.Addon()
	for setting_id, _file, _label in BUILTIN_TRACKS:
		addon.setSettingBool(setting_id, value)
	notify('All built-in tracks are %s' % ('on' if value else 'off'))


def tracks_on():
	set_all_tracks(True)


def tracks_off():
	set_all_tracks(False)


if __name__ == '__main__':
	action = sys.argv[1] if len(sys.argv) > 1 else 'add'
	{'add': add, 'show': show, 'rescan': rescan, 'import': import_songs, 'remove': remove, 'clear': clear, 'convert': convert, 'tracks_on': tracks_on, 'tracks_off': tracks_off}.get(action, add)()
