# -*- coding: utf-8 -*-
"""Converts the music of the added folders to Opus 96 kbps with the libffmpeg that ships inside this add-on (lib/).

Target format: Opus 96 kbps when the bundled libffmpeg can encode it (libopus), otherwise MP3 (libmp3lame), otherwise AAC in an .m4a file,
which Kodi plays everywhere. Files that already are in the target family are left alone.

A file is only replaced after the new file was written, read back and checked (same channels and sample rate,
same length). Only then is the original deleted, and only if the setting asks for it.
"""
import json
import os
import shutil
import sys
import tempfile
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import musicfolders

TITLE = 'NIGHTSHIFT ambience'
BITRATE = 128000
OPUS_BITRATE = 96000                    # libopus 96 kbps for stereo and mono (the default target)
BITRATE_SLACK = 4000                      # an MP3 up to 132 kbps counts as "128 kbps" (VBR averages wobble)
LEDGER = 'convert_kept.json'              # files that were looked at and deliberately left as they are
MAX_INPUT_BYTES = 250 * 1024 * 1024      # a whole file is decoded in memory: larger files are skipped, not risked
LENGTH_TOLERANCE = 0.02                   # the converted file may differ by 2 % (+ one frame) from the original
PART = '.part'                            # not an audio extension, so a half-written file is never played


def log(msg, level=xbmc.LOGINFO):
	xbmc.log('[NIGHTSHIFT ambience] convert: %s' % msg, level)


class Target(object):
	def __init__(self, codec, ext, fmt, label, keep, bitrate=None, max_channels=None):
		self.codec, self.ext, self.fmt, self.label = codec, ext, fmt, label
		self.keep = keep          # extensions that are already fine and stay as they are
		self.bitrate = BITRATE if bitrate is None else bitrate   # bits per second per channel pair
		self.max_channels = max_channels                         # None: no limit of the codec used here

	def __repr__(self):
		return '%s %dk (%s)' % (self.label, self.bitrate // 1000, self.ext)


# ---------------------------------------------------------------------------------------------------------------
# loading libffmpeg
# ---------------------------------------------------------------------------------------------------------------
_FF = None
_FF_ERROR = None


def _lib_dir():
	return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'lib')


def _exec_dirs():
	"""Folders a shared library can be loaded from when the add-on folder itself does not allow it (Android keeps add-ons on a no-exec volume)."""
	dirs = []
	for key in ('KODI_TEMP', 'TMPDIR', 'KODI_BIN_HOME', 'HOME'):
		if os.environ.get(key):
			dirs.append(os.environ[key])
	try:
		with open('/proc/self/cmdline', 'rb') as handle:
			package = handle.read().split(b'\0')[0].decode('utf-8', 'ignore')
		if package and '/' not in package:
			dirs += ['/data/data/%s/cache' % package, '/data/user/0/%s/cache' % package, '/data/data/%s/files' % package]
	except Exception:
		pass
	try:
		dirs.append(tempfile.gettempdir())
	except Exception:                  # Android: no /tmp at all
		pass
	try:
		import xbmcvfs
		for special in ('special://temp/', 'special://profile/addon_data/script.service.nightshift.ambience/'):
			dirs.append(xbmcvfs.translatePath(special))
	except Exception:
		pass
	seen, out = set(), []
	for d in dirs:
		if d and d not in seen and os.path.isdir(d):
			seen.add(d); out.append(d)
	return out


def load_ffaudio():
	"""(module, None) when libffmpeg loads, (None, reason) when it does not."""
	global _FF, _FF_ERROR
	if _FF is not None:
		return _FF, None
	lib = _lib_dir()
	if lib not in sys.path:
		sys.path.insert(0, lib)
	try:
		import ffaudio
	except Exception as error:
		_FF_ERROR = 'The conversion module could not be loaded: %s' % error
		return None, _FF_ERROR
	reasons = []
	try:
		ffaudio._lib()
		_FF = ffaudio
		return _FF, None
	except Exception as error:
		reasons.append('%s: %s' % (lib, error))
	source = os.path.join(lib, 'libffmpeg.so')
	for folder in _exec_dirs():
		copy = os.path.join(folder, 'libffmpeg_ns.so')
		try:
			if not (os.path.isfile(copy) and os.path.getsize(copy) == os.path.getsize(source)):
				shutil.copyfile(source, copy)
				os.chmod(copy, 0o555)
			ffaudio._lib_path = lambda path=copy: path
			ffaudio._LIB = None
			ffaudio._lib()
			_FF = ffaudio
			log('libffmpeg loaded from %s' % copy)
			return _FF, None
		except Exception as error:
			reasons.append('%s: %s' % (folder, error))
			try: os.remove(copy)                  # nothing is left behind by a copy that did not work
			except OSError: pass
	_FF_ERROR = 'libffmpeg could not be loaded on this device (it is built for Android arm64).\n' + '\n'.join(reasons[:3])
	log(_FF_ERROR, xbmc.LOGWARNING)
	return None, _FF_ERROR


def pick_multi(ff):
	"""Music with more than two channels, in the order tried: Opus 96 kbps per channel pair (libopus, up to 8
	channels), then FDK-AAC LC (.m4a, constant bitrate, 128 kbps per channel pair) for more channels. The channel
	count is kept. HE-AAC is stereo and mono only, so it is not used here."""
	out = []
	try:
		if ff.can_encode('opus'):
			out.append(Target('opus', '.opus', 'ogg', 'Opus', ('.opus',), bitrate=OPUS_BITRATE, max_channels=8))
	except Exception:
		pass
	for codec in ('libfdk_aac', 'aac'):
		try:
			if ff.can_encode(codec):
				out.append(Target(codec, '.m4a', 'mp4', 'AAC', ('.m4a',)))
				break
		except Exception:
			pass
	return out


def pick_heaac(ff):
	"""HE-AAC v1 (FDK-AAC, AAC-LC + SBR) in an .m4a file: the AAC fallback for stereo and mono when the library has
	no MP3 encoder. Constant bitrate 128 kbps."""
	for codec in ('heaac', 'libfdk_aac', 'aac'):
		try:
			if ff.can_encode(codec):
				return Target(codec, '.m4a', 'mp4', 'HE-AAC' if codec == 'heaac' else 'AAC', ('.mp3', '.m4a', '.aac'))
		except Exception:
			pass
	return None


def pick_opus(ff):
	"""Opus 96 kbps in an Ogg container (.opus): the default for stereo and mono music."""
	try:
		if ff.can_encode('opus'):
			return Target('opus', '.opus', 'ogg', 'Opus', ('.opus',), bitrate=OPUS_BITRATE)
	except Exception:
		pass
	return None


def pick_target(ff):
	"""Stereo and mono: Opus 96 kbps (libopus). Without an Opus encoder: LAME MP3 (128 kbps CBR), then HE-AAC (.m4a)."""
	opus = pick_opus(ff)
	if opus is not None:
		return opus
	for codec in ('libmp3lame', 'mp3'):
		try:
			if ff.can_encode(codec):
				return Target(codec, '.mp3', 'mp3', 'MP3', ('.mp3',))
		except Exception:
			pass
	return pick_heaac(ff)


# ---------------------------------------------------------------------------------------------------------------
# MP3 bitrate (read from the file header, nothing is decoded)
# ---------------------------------------------------------------------------------------------------------------
_BR_V1 = (0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0)
_BR_V2 = (0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0)
_SR = {3: (44100, 48000, 32000), 2: (22050, 24000, 16000), 0: (11025, 12000, 8000)}


def _head(path, size=65536):
	handle = xbmcvfs.File(path)
	try:
		return bytes(handle.readBytes(size))
	finally:
		handle.close()


def mp3_bitrate(path):
	"""Bits per second of an MP3 (the average for VBR files), or 0 when it cannot be told."""
	try:
		data = _head(path, 16384)
		base = 0
		if data[:3] == b'ID3' and len(data) >= 10:
			base = 10 + ((data[6] & 0x7F) << 21 | (data[7] & 0x7F) << 14 | (data[8] & 0x7F) << 7 | (data[9] & 0x7F))
			data = _head_at(path, base, 16384)           # skip the tag (cover art can be megabytes)
		pos = 0
		while pos + 4 <= len(data):
			if data[pos] == 0xFF and (data[pos + 1] & 0xE0) == 0xE0:
				version, layer, idx = (data[pos + 1] >> 3) & 3, (data[pos + 1] >> 1) & 3, (data[pos + 2] >> 4) & 15
				rate_idx = (data[pos + 2] >> 2) & 3
				if version != 1 and layer == 1 and idx not in (0, 15) and rate_idx != 3:
					break
			pos += 1
		else:
			return 0
		mpeg1 = version == 3
		bitrate = (_BR_V1 if mpeg1 else _BR_V2)[idx] * 1000
		rate = _SR[version][rate_idx]
		mono = ((data[pos + 3] >> 6) & 3) == 3
		side = (17 if mono else 32) if mpeg1 else (9 if mono else 17)
		tag = data[pos + 4 + side: pos + 4 + side + 8]
		if tag[:4] == b'Xing' and (tag[7] & 1) and len(data) >= pos + 4 + side + 12:
			frames = int.from_bytes(data[pos + 4 + side + 8: pos + 4 + side + 12], 'big')
			seconds = frames * (1152 if mpeg1 else 576) / float(rate)
			if seconds > 0:
				return int((_size(path) - base) * 8 / seconds)
		return bitrate
	except Exception:
		return 0


def _head_at(path, offset, size=16384):
	handle = xbmcvfs.File(path)
	try:
		handle.seek(offset, 0)
		return bytes(handle.readBytes(size))
	finally:
		handle.close()


# ---------------------------------------------------------------------------------------------------------------
# finding the work
# ---------------------------------------------------------------------------------------------------------------
def _ledger_file():
	folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/')
	if not xbmcvfs.exists(folder):
		xbmcvfs.mkdirs(folder)
	return os.path.join(folder, LEDGER)


def _ledger():
	try:
		with open(_ledger_file(), encoding='utf-8') as handle:
			return json.load(handle)
	except Exception:
		return {}


def _ledger_add(path):
	data = _ledger()
	data[path] = _size(path)
	try:
		with open(_ledger_file(), 'w', encoding='utf-8') as handle:
			json.dump(data, handle)
	except Exception:
		pass


def _kept(path, ledger):
	return path in ledger and ledger[path] == _size(path)


def _needs_work(path, ext, ledger, target=None):
	if _kept(path, ledger):
		return False
	if target is not None and target.codec == 'opus' and ext == '.opus':
		return False                  # already Opus: lossy to lossy would only lose more
	if ext == '.mp3':
		rate = mp3_bitrate(path)
		return rate > BITRATE + BITRATE_SLACK
	return True


def _walk(folder, target, found, ledger, depth=0):
	if depth > musicfolders.MAX_DEPTH:
		return
	try:
		dirs, files = xbmcvfs.listdir(folder)
	except Exception:
		return
	dirs, files = [musicfolders._text(n) for n in dirs], [musicfolders._text(n) for n in files]
	taken = set(os.path.splitext(n)[0].lower() for n in files if n.lower().endswith(musicfolders.CONVERTED + (target.ext,)))
	own = set(os.path.splitext(n)[0].lower() for n in files if n.lower().endswith(target.ext))
	for name in files:
		base, ext = os.path.splitext(name)
		ext = ext.lower()
		if ext not in musicfolders.EXTENSIONS:
			continue
		if ext not in ('.mp3',) and base.lower() in taken:
			continue                      # a converted copy is already beside it
		if base.lower() in own:
			continue                      # the copy in the target format is already beside it
		path = musicfolders._join(folder, name)
		if _needs_work(path, ext, ledger, target):
			found.append(path)
	for name in dirs:
		_walk(musicfolders._join(folder, name), target, found, ledger, depth + 1)


def pending(target, folders=None):
	"""Every file in the added folders that still has to be converted: not MP3, or an MP3 above 128 kbps."""
	found = []
	ledger = _ledger()
	for folder in (musicfolders.load() if folders is None else folders):
		_walk(folder, target, found, ledger)
	return found


# ---------------------------------------------------------------------------------------------------------------
# converting one file
# ---------------------------------------------------------------------------------------------------------------
def _size(path):
	try:
		return xbmcvfs.Stat(path).st_size()
	except Exception:
		return 0


def _write(path, blob):
	handle = xbmcvfs.File(path, 'wb')
	try:
		ok = handle.write(bytearray(blob))
	finally:
		handle.close()
	return bool(ok)


def _bitrate_for(target, channels):
	"""The target's bitrate for mono and stereo (96 kbps Opus, 128 kbps MP3 / AAC); per channel pair for more channels."""
	return target.bitrate * max(1, (channels + 1) // 2)


def convert_file(ff, target, src, delete_original, multi=None):
	"""Returns (True, bytes_saved) or (False, reason). Music with more than two channels goes to Opus (up to 8 channels) or AAC with the same channel count."""
	if _size(src) > MAX_INPUT_BYTES:
		return False, 'file is too large to convert on this device'
	src_ext = os.path.splitext(src)[1].lower()
	part = None
	try:
		source = ff.decode_path(src)
		if source.samples <= 0:
			return False, 'nothing could be decoded'
		if source.channels > 2:
			chosen = next((t for t in (multi or []) if t.max_channels is None or source.channels <= t.max_channels), None)
			if chosen is None:
				return False, 'more than two channels and the library has no encoder for %d channels' % source.channels
			if src_ext in ('.m4a', '.aac', '.opus'):
				_ledger_add(src)
				return False, 'already compressed with %d channels: left as it is' % source.channels
			target = chosen
		dst = os.path.splitext(src)[0] + target.ext
		same = dst == src
		if not same and xbmcvfs.exists(dst) and _size(dst) > 0:
			return False, 'a %s with the same name already exists' % target.ext
		part = dst + PART
		blob = ff.encode_file(source.pcm, source.rate, source.channels, fmt=target.fmt, codec=target.codec, bitrate=_bitrate_for(target, source.channels))
		if not blob:
			return False, 'the encoder produced nothing'
		source_samples, source_rate, source_channels = source.samples, source.rate, source.channels
		del source
		# read the result back before anything is removed
		check = ff.decode_file(blob)
		if check.channels != source_channels or check.rate != source_rate:
			return False, 'the converted file does not match (channels / sample rate)'
		wanted = float(source_samples)
		if abs(check.samples - wanted) > wanted * LENGTH_TOLERANCE + 4096:
			return False, 'the converted file has the wrong length'
		del check
		if not _write(part, blob):
			return False, 'could not write next to the original (read-only folder?)'
		if _size(part) != len(blob):
			xbmcvfs.delete(part)
			return False, 'the file was not written completely'
		saved = _size(src) - len(blob)
		if same:
			# an MP3 above 128 kbps is replaced under its own name: the old file stays until the new one is in place
			backup = src + '.old'
			if not xbmcvfs.rename(src, backup):
				xbmcvfs.delete(part)
				return False, 'could not replace the original'
			if not xbmcvfs.rename(part, dst):
				xbmcvfs.rename(backup, src)
				xbmcvfs.delete(part)
				return False, 'could not name the new file'
			xbmcvfs.delete(backup)
			return True, saved
		if not xbmcvfs.rename(part, dst):
			xbmcvfs.delete(part)
			return False, 'could not name the new file'
	except MemoryError:
		return False, 'not enough memory for this file'
	except Exception as error:
		try:
			if part and xbmcvfs.exists(part): xbmcvfs.delete(part)
		except Exception:
			pass
		return False, str(error) or error.__class__.__name__
	if delete_original:
		if not xbmcvfs.delete(src):
			log('converted but could not remove the original: %s' % src, xbmc.LOGWARNING)
	return True, saved


# ---------------------------------------------------------------------------------------------------------------
# the button
# ---------------------------------------------------------------------------------------------------------------
def delete_originals_setting():
	try:
		return xbmcaddon.Addon().getSettingBool('convert_delete_originals')
	except Exception:
		return True


def video_is_playing():
	try:
		return xbmc.Player().isPlayingVideo()
	except Exception:
		return False


def _megabytes(n):
	return '%.1f MB' % (abs(n) / 1048576.0)


def run(files=None, ask=True):
	"""Convert the music of the added folders. files: a list to convert instead of scanning everything."""
	dialog = xbmcgui.Dialog()
	if not musicfolders.load() and files is None:
		dialog.ok(TITLE, 'No music folders added yet. Use "Add a music folder" first.')
		return
	if video_is_playing():
		dialog.ok(TITLE, 'A video is playing. Converting uses a lot of the processor and would make it stutter.\nTry again when it has finished.')
		return
	ff, problem = load_ffaudio()
	if ff is None:
		dialog.ok(TITLE, problem + '\n\nRun convert_flac_to_mp3.py (in the add-on folder) on a PC instead, or leave the files as they are: they are still played as they are.')
		return
	target = pick_target(ff)
	if target is None:
		dialog.ok(TITLE, 'The bundled libffmpeg has no Opus, MP3 or AAC encoder.')
		return
	multi = pick_multi(ff)
	todo = pending(target) if files is None else list(files)
	if not todo:
		dialog.notification(TITLE, 'Nothing to convert: every file is already in the target format or is kept as it is', xbmcgui.NOTIFICATION_INFO, 4000, False)
		return
	delete = delete_originals_setting()
	if ask:
		note = 'The originals are deleted once the new file has been checked (MP3s above 128 kbps are replaced in place).' if delete else 'The originals are kept (MP3s above 128 kbps are replaced in place).'
		extra = '' if target.label in ('Opus', 'MP3') else '\n(The bundled libffmpeg cannot encode Opus or MP3, so AAC is used; it plays the same.)'
		extra += '\nMusic with more than two channels becomes Opus (up to 8 channels, else AAC) and keeps its channels.'
		if not dialog.yesno(TITLE, 'Convert %d file(s) to %s?\n%s%s' % (len(todo), target, note, extra)):
			return
	try: os.nice(10)
	except Exception: pass
	progress = xbmcgui.DialogProgress()
	progress.create(TITLE, 'Converting...')
	monitor = xbmc.Monitor()
	done, failed, saved, reasons = 0, 0, 0, []
	started = time.time()
	for i, src in enumerate(todo):
		if progress.iscanceled() or monitor.abortRequested():
			break
		if video_is_playing():
			reasons.append('stopped: a video started playing')
			break
		progress.update(int(i * 100 / len(todo)), '%s\n%d of %d' % (os.path.basename(src), i + 1, len(todo)))
		ok, info = convert_file(ff, target, src, delete, multi)
		if ok:
			done += 1; saved += info
		else:
			failed += 1
			reasons.append('%s: %s' % (os.path.basename(src), info))
			log('%s -> %s' % (src, info), xbmc.LOGWARNING)
	progress.close()
	lines = ['Converted: %d   Failed or skipped: %d' % (done, failed)]
	if done:
		lines.append('Space %s: %s' % ('freed' if saved >= 0 else 'used', _megabytes(saved)) if delete else 'Originals kept.')
	lines.append('Time: %d s' % (time.time() - started))
	if reasons:
		lines += ['', 'Not converted:'] + reasons[:12] + (['...'] if len(reasons) > 12 else [])
	text = '\n'.join(lines)
	log(text.replace('\n', ' | '))
	if reasons:
		dialog.textviewer(TITLE, text)
	else:
		dialog.ok(TITLE, text)


def offer_after_add(folder):
	"""After a folder was added: say how many files could be converted and offer to do it."""
	ff, _problem = load_ffaudio()
	if ff is None:
		return
	target = pick_target(ff)
	if target is None:
		return
	multi = pick_multi(ff)
	todo = pending(target, [folder])
	if not todo:
		return
	note = 'The originals are deleted once each new file has been checked.' if delete_originals_setting() else 'The originals are kept.'
	if xbmcgui.Dialog().yesno(TITLE, '%d file(s) in this folder are not %s, or are MP3s above 128 kbps.\nConvert them to %s now?\n%s' % (len(todo), target.label, target, note)):
		run(files=todo, ask=False)
