# -*- coding: utf-8 -*-
"""The extra music folders of NIGHTSHIFT ambience: stored in the add-on's data folder, scanned for tracks."""
import json
import os

import xbmc
import xbmcvfs
# Android MediaStore lookup, kept inside this file: add-on updates do not always install newly added files.
_MEDIASTORE_SRC = '# -*- coding: utf-8 -*-\n"""Read indexed shared-storage audio on Android when Kodi\'s VFS cannot list it.\n\nKodi\'s Python API does not expose Android\'s ContentResolver. Android\'s\n/system/bin/content client queries MediaStore under Kodi\'s app UID and its\nexisting media permission. This module is read-only and queries audio only.\n"""\nimport os\nimport re\nimport subprocess\nimport time\n\nimport xbmc\n\n_CONTENT = \'/system/bin/content\'\n_AUDIO_URI = \'content://media/external/audio/media\'\n_ROOTS = (\'/storage/emulated/0\', \'/storage/self/primary\', \'/sdcard\', \'/mnt/sdcard\', \'/mnt/shell/emulated/0\')\n_CACHE_SECONDS = 12\n_cache = {}\n_warned = set()\n\n\ndef _log(message, level=xbmc.LOGINFO):\n    xbmc.log(\'[NIGHTSHIFT ambience MediaStore] %s\' % message, level)\n\n\ndef _relative_path(folder):\n    value = str(folder or \'\').replace(\'\\\\\', \'/\').rstrip(\'/\')\n    for root in _ROOTS:\n        root = root.rstrip(\'/\')\n        if value == root:\n            return \'\'\n        if value.startswith(root + \'/\'):\n            relative = value[len(root) + 1:].strip(\'/\')\n            return relative + \'/\' if relative else \'\'\n    return None\n\n\ndef _canonical(folder):\n    value = str(folder or \'\').replace(\'\\\\\', \'/\').rstrip(\'/\')\n    for root in _ROOTS:\n        root = root.rstrip(\'/\')\n        if value == root or value.startswith(root + \'/\'):\n            return \'/storage/emulated/0\' + value[len(root):]\n    return value\n\n\ndef audio_files(folder):\n    if not (os.path.exists(_CONTENT) or _is_android()) :\n        return None\n    relative = _relative_path(folder)\n    if relative is None or not relative:\n        return None\n    key = relative.casefold()\n    now = time.time()\n    cached = _cache.get(key)\n    if cached and now - cached[0] < _CACHE_SECONDS:\n        return list(cached[1])\n    if not os.path.exists(_CONTENT):\n        if key not in _warned:\n            _warned.add(key)\n            _log(\'Android content-query tool is not present at %s\' % _CONTENT, xbmc.LOGWARNING)\n        return None\n    lower = relative.replace("\'", "\'\'")\n    upper = (relative[:-1] + \'0\').replace("\'", "\'\'")\n    selection = "relative_path >= \'%s\' AND relative_path < \'%s\'" % (lower, upper)\n    command = [_CONTENT, \'query\', \'--uri\', _AUDIO_URI, \'--projection\', \'_data:relative_path:_display_name\', \'--where\', selection]\n    try:\n        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=18, check=False)\n    except Exception as error:\n        if key not in _warned:\n            _warned.add(key)\n            _log(\'MediaStore query could not run for %s: %s\' % (folder, error), xbmc.LOGWARNING)\n        return None\n    stdout = result.stdout.decode(\'utf-8\', \'replace\') if isinstance(result.stdout, bytes) else (result.stdout or \'\')\n    stderr = result.stderr.decode(\'utf-8\', \'replace\') if isinstance(result.stderr, bytes) else (result.stderr or \'\')\n    if result.returncode:\n        if key not in _warned:\n            _warned.add(key)\n            _log(\'MediaStore query failed for %s (exit %s): %s\' % (folder, result.returncode, stderr.strip()[:400]), xbmc.LOGWARNING)\n        return None\n    paths, seen = [], set()\n    for line in stdout.splitlines():\n        row = re.match(r\'^\\s*Row:\\s*\\d+\\s+(.*)$\', line)\n        if not row:\n            continue\n        fields = row.group(1)\n        data_match = re.search(r\'(?:^|\\s)_data=(.*?)(?=\\s+relative_path=|$)\', fields)\n        relative_match = re.search(r\'(?:^|\\s)relative_path=(.*?)(?=\\s+_display_name=|$)\', fields)\n        name_match = re.search(r\'(?:^|\\s)_display_name=(.*)$\', fields)\n        path = data_match.group(1).strip() if data_match else \'\'\n        if not path or path.lower() in (\'null\', \'(null)\') or not path.startswith(\'/\'):\n            relative_value = relative_match.group(1).strip() if relative_match else \'\'\n            display_name = name_match.group(1).strip() if name_match else \'\'\n            if not relative_value or not display_name:\n                continue\n            path = \'/storage/emulated/0/\' + relative_value.strip(\'/\') + \'/\' + display_name\n        path = os.path.normpath(path)\n        marker = path.casefold()\n        if marker not in seen:\n            seen.add(marker)\n            paths.append(path)\n    _cache[key] = (now, paths)\n    _log(\'queried %s: %d indexed audio file(s)\' % (folder, len(paths)))\n    return list(paths)\n\n\ndef _is_android():\n    try:\n        return bool(xbmc.getCondVisibility(\'System.Platform.Android\'))\n    except Exception:\n        return False\n\n\ndef listdir(folder):\n    paths = audio_files(folder)\n    if paths is None:\n        return None\n    base = _canonical(folder).rstrip(\'/\')\n    prefix = base + \'/\'\n    dirs, files = set(), set()\n    for path in paths:\n        canonical = _canonical(path)\n        if not canonical.startswith(prefix):\n            continue\n        remainder = canonical[len(prefix):]\n        if not remainder:\n            continue\n        first, separator, _tail = remainder.partition(\'/\')\n        if separator:\n            dirs.add(first)\n        else:\n            files.add(first)\n    return sorted(dirs, key=str.casefold), sorted(files, key=str.casefold)\n\n\ndef clear_cache():\n    """Forget the saved MediaStore answers so the next listing asks Android again (used by the Rescan button)."""\n    _cache.clear()\n    _warned.clear()\n'


def _load_mediastore():
	import types
	module = types.ModuleType('nightshift_android_mediastore')
	try:
		exec(compile(_MEDIASTORE_SRC, 'android_mediastore', 'exec'), module.__dict__)
		return module
	except Exception:
		class _Off:
			@staticmethod
			def listdir(folder): return None
			@staticmethod
			def clear_cache(): pass
		return _Off


android_mediastore = _load_mediastore()

CONVERTED = ('.mp3', '.m4a', '.opus')
EXTENSIONS = ('.mp3', '.flac', '.ogg', '.oga', '.opus', '.m4a', '.aac', '.wav', '.wma', '.ape', '.wv')
MAX_DEPTH = 4
MAX_TRACKS = 3000


def _file():
	folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/')
	if not xbmcvfs.exists(folder):
		xbmcvfs.mkdirs(folder)
	return os.path.join(folder, 'folders.json')


def stamp():
	"""Changes whenever the list of folders changes (the service looks at it to reload)."""
	try:
		return os.path.getmtime(_file())
	except OSError:
		return 0


def load():
	try:
		with open(_file(), encoding='utf-8') as handle:
			data = json.load(handle)
		return [str(x) for x in data if x]
	except Exception:
		return []


def save(folders):
	try:
		with open(_file(), 'w', encoding='utf-8') as handle:
			json.dump(list(folders), handle, indent=1, ensure_ascii=False)
		return True
	except Exception as error:
		xbmc.log('[NIGHTSHIFT ambience] cannot save folders: %s' % error, xbmc.LOGWARNING)
		return False


def _join(folder, name):
	if '://' not in folder and '\\' in folder:
		return folder.rstrip('\\') + '\\' + name
	return folder.rstrip('/') + '/' + name


def _text(name):
	"""File names as text (CJK, full-width brackets, etc.); bytes from some back-ends are decoded as UTF-8."""
	if isinstance(name, bytes):
		return name.decode('utf-8', 'replace')
	return name


def rpc_listdir(folder):
    """(dirs, files) from Kodi's own JSON-RPC Files.GetDirectory, or None when it cannot answer."""
    try:
        import json
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
            'params': {'directory': folder if folder.endswith(('/', '\\')) else folder + '/', 'media': 'files'}})))
        items = (reply.get('result') or {}).get('files')
        if items is None:
            return None
        dirs, files = [], []
        for item in items:
            name = os.path.basename((item.get('file') or '').rstrip('/\\')) or item.get('label') or ''
            if name:
                (dirs if item.get('filetype') == 'directory' else files).append(name)
        return dirs, files
    except Exception:
        return None


def scan(folder, depth=0, found=None):
	"""Audio files in a folder and the folders inside it (a few levels deep)."""
	found = [] if found is None else found
	if depth > MAX_DEPTH or len(found) >= MAX_TRACKS:
		return found
	# Merge Kodi VFS results with Android MediaStore. On Android with media-only
	# access, VFS directory enumeration can be empty even though the audio is
	# indexed and readable by its path.
	dirs, files = [], []
	try:
		dirs, files = xbmcvfs.listdir(folder)
	except Exception:
		pass
	rpc = rpc_listdir(folder)
	if rpc is not None:
		dirs = sorted(set(dirs) | set(rpc[0]), key=lambda x: _text(x).lower())
		files = sorted(set(files) | set(rpc[1]), key=lambda x: _text(x).lower())
	media = android_mediastore.listdir(folder)
	if media is not None:
		media_dirs, media_files = media
		dirs = sorted(set(dirs) | set(media_dirs), key=lambda x: _text(x).lower())
		files = sorted(set(files) | set(media_files), key=lambda x: _text(x).lower())
	if not dirs and not files and media is None:
		return found
	dirs, files = [_text(n) for n in dirs], [_text(n) for n in files]
	# A file is skipped when a converted copy (.mp3 / .m4a, made by the converter) with the same name sits beside it,
	# so a song never plays twice while its original is still there.
	converted = set(os.path.splitext(n)[0].lower() for n in files if n.lower().endswith(CONVERTED))
	for name in sorted(files, key=lambda x: x.lower()):
		base, ext = os.path.splitext(name)
		if ext.lower() not in CONVERTED and base.lower() in converted:
			continue
		if name.lower().endswith(EXTENSIONS):
			found.append(_join(folder, name))
			if len(found) >= MAX_TRACKS:
				return found
	for name in sorted(dirs, key=lambda x: x.lower()):
		scan(_join(folder, name), depth + 1, found)
	return found


def own_folder():
	"""The add-on's own music folder (special://profile/addon_data/...). Android always lets Kodi read it, with no storage permission:
	songs copied there (Import songs) are played with the added folders."""
	folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/music/')
	try:
		if not xbmcvfs.exists(folder):
			xbmcvfs.mkdirs(folder)
	except Exception:
		pass
	return folder


def tracks():
	"""Every track of every added folder and of the add-on's own music folder."""
	out = []
	for folder in list(load()) + [own_folder()]:
		for path in scan(folder):
			if path not in out:
				out.append(path)
	return out
