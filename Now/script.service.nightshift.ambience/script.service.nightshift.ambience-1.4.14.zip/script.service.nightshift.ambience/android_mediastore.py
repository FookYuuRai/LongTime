# -*- coding: utf-8 -*-
"""Read indexed shared-storage audio on Android when Kodi's VFS cannot list it.

Kodi's Python API does not expose Android's ContentResolver. Android's
/system/bin/content client queries MediaStore under Kodi's app UID and its
existing media permission. This module is read-only and queries audio only.
"""
import os
import re
import subprocess
import time

import xbmc

_CONTENT = '/system/bin/content'
_AUDIO_URI = 'content://media/external/audio/media'
_ROOTS = ('/storage/emulated/0', '/storage/self/primary', '/sdcard', '/mnt/sdcard', '/mnt/shell/emulated/0')
_CACHE_SECONDS = 12
_cache = {}
_warned = set()


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('[NIGHTSHIFT ambience MediaStore] %s' % message, level)


def _relative_path(folder):
    value = str(folder or '').replace('\\', '/').rstrip('/')
    for root in _ROOTS:
        root = root.rstrip('/')
        if value == root:
            return ''
        if value.startswith(root + '/'):
            relative = value[len(root) + 1:].strip('/')
            return relative + '/' if relative else ''
    return None


def _canonical(folder):
    value = str(folder or '').replace('\\', '/').rstrip('/')
    for root in _ROOTS:
        root = root.rstrip('/')
        if value == root or value.startswith(root + '/'):
            return '/storage/emulated/0' + value[len(root):]
    return value


def audio_files(folder):
    if not (os.path.exists(_CONTENT) or _is_android()) :
        return None
    relative = _relative_path(folder)
    if relative is None or not relative:
        return None
    key = relative.casefold()
    now = time.time()
    cached = _cache.get(key)
    if cached and now - cached[0] < _CACHE_SECONDS:
        return list(cached[1])
    if not os.path.exists(_CONTENT):
        if key not in _warned:
            _warned.add(key)
            _log('Android content-query tool is not present at %s' % _CONTENT, xbmc.LOGWARNING)
        return None
    lower = relative.replace("'", "''")
    upper = (relative[:-1] + '0').replace("'", "''")
    selection = "relative_path >= '%s' AND relative_path < '%s'" % (lower, upper)
    command = [_CONTENT, 'query', '--uri', _AUDIO_URI, '--projection', '_data:relative_path:_display_name', '--where', selection]
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=18, check=False)
    except Exception as error:
        if key not in _warned:
            _warned.add(key)
            _log('MediaStore query could not run for %s: %s' % (folder, error), xbmc.LOGWARNING)
        return None
    stdout = result.stdout.decode('utf-8', 'replace') if isinstance(result.stdout, bytes) else (result.stdout or '')
    stderr = result.stderr.decode('utf-8', 'replace') if isinstance(result.stderr, bytes) else (result.stderr or '')
    if result.returncode:
        if key not in _warned:
            _warned.add(key)
            _log('MediaStore query failed for %s (exit %s): %s' % (folder, result.returncode, stderr.strip()[:400]), xbmc.LOGWARNING)
        return None
    paths, seen = [], set()
    for line in stdout.splitlines():
        row = re.match(r'^\s*Row:\s*\d+\s+(.*)$', line)
        if not row:
            continue
        fields = row.group(1)
        data_match = re.search(r'(?:^|\s)_data=(.*?)(?=\s+relative_path=|$)', fields)
        relative_match = re.search(r'(?:^|\s)relative_path=(.*?)(?=\s+_display_name=|$)', fields)
        name_match = re.search(r'(?:^|\s)_display_name=(.*)$', fields)
        path = data_match.group(1).strip() if data_match else ''
        if not path or path.lower() in ('null', '(null)') or not path.startswith('/'):
            relative_value = relative_match.group(1).strip() if relative_match else ''
            display_name = name_match.group(1).strip() if name_match else ''
            if not relative_value or not display_name:
                continue
            path = '/storage/emulated/0/' + relative_value.strip('/') + '/' + display_name
        path = os.path.normpath(path)
        marker = path.casefold()
        if marker not in seen:
            seen.add(marker)
            paths.append(path)
    _cache[key] = (now, paths)
    _log('queried %s: %d indexed audio file(s)' % (folder, len(paths)))
    return list(paths)


def _is_android():
    try:
        return bool(xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def listdir(folder):
    paths = audio_files(folder)
    if paths is None:
        return None
    base = _canonical(folder).rstrip('/')
    prefix = base + '/'
    dirs, files = set(), set()
    for path in paths:
        canonical = _canonical(path)
        if not canonical.startswith(prefix):
            continue
        remainder = canonical[len(prefix):]
        if not remainder:
            continue
        first, separator, _tail = remainder.partition('/')
        if separator:
            dirs.add(first)
        else:
            files.add(first)
    return sorted(dirs, key=str.casefold), sorted(files, key=str.casefold)


def clear_cache():
    """Forget the saved MediaStore answers so the next listing asks Android again (used by the Rescan button)."""
    _cache.clear()
    _warned.clear()
