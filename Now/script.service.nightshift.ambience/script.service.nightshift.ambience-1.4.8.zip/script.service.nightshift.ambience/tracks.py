# -*- coding: utf-8 -*-
"""The built-in ambience tracks: (setting id, file in resources/audio, name shown in the settings)."""

BUILTIN_TRACKS = (
    ('track_01', '01_title_theme.opus', 'Title Theme (Koji Kondo)'),
    ('track_02', '02_blood_dragon_theme.opus', 'Blood Dragon Theme (Power Glove)'),
    ('track_03', '03_mii_plaza.opus', 'Mii Plaza (Kazumi Totaka)'),
    ('track_04', '04_character_select.opus', 'Character Select (Hirokazu Ando)'),
    ('track_05', '05_shop_channel_title.opus', 'Shop Channel Title (Kazumi Totaka)'),
    ('track_06', '06_shop_channel_07.opus', 'Shop Channel, track 07 (Kazumi Totaka)'),
    ('track_07', '07_shop_channel.opus', 'Shop Channel (Kazumi Totaka)'),
    ('track_08', '08_power_core.opus', 'Power Core (Power Glove)'),
    ('track_09', '09_resurrection.opus', 'Resurrection (Power Glove)'),
    ('track_10', '10_zeldas_theme.opus', "Zelda's Theme (Koji Kondo)"),
    ('track_11', '11_wonder_metal_mario.opus', 'Wonder - Metal Mario BGM'),
    ('track_12', '12_perfect_cell_remix.opus', 'DBZ - Perfect Cell Theme Remix'),
)
