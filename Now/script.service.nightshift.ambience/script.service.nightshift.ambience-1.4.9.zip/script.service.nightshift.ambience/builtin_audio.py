# -*- coding: utf-8 -*-
"""Download and maintain the versioned external Nightshift ambience pack.

The add-on ZIP carries the current dynamic track catalogue in tracks.py. The
actual audio files are kept outside the add-on in Kodi's add-on data folder.
A SHA-256 marker is written only after the whole current catalogue has been
verified and installed. This makes changed packs refresh even when filenames
stay the same, and lets removed tracks be cleaned up safely.
"""

import hashlib
import os
import shutil
import tempfile
import threading
import urllib.request
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

from tracks import BUILTIN_TRACKS

PACK_URL = 'https://github.com/FookYuuRai/LongTime/releases/download/ambience-audio-v1/ambience-audio-opus96.zip'
PACK_SHA256 = 'ad1ea57618c3a6096fd9643ffd422059f6f7a7a46e7a122e3f02614a31563b53'
PACK_SIZE = 19220866  # bytes; fallback for progress text when the server omits Content-Length
CHUNK = 256 * 1024
TIMEOUT = 30

AUDIO_EXTENSIONS = {
    '.mp3', '.m4a', '.opus', '.ogg', '.oga', '.aac',
    '.wav', '.wma', '.flac', '.ape', '.wv',
}

_lock = threading.Lock()
_running = False


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[NIGHTSHIFT ambience] builtin audio: %s' % msg, level)


def data_dir():
    return xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/builtin_audio/')


def _names():
    """Return the current release's dynamically generated built-in filenames."""
    names = []
    for _setting_id, name, _label in BUILTIN_TRACKS:
        if not isinstance(name, str) or not name or name in ('.', '..'):
            raise ValueError('invalid built-in audio filename in tracks.py: %r' % (name,))
        if '/' in name or '\\' in name or os.path.basename(name) != name:
            raise ValueError('built-in audio filename must be a plain filename: %r' % name)
        if os.path.splitext(name)[1].lower() not in AUDIO_EXTENSIONS:
            raise ValueError('unsupported built-in audio filename extension: %s' % name)
        names.append(name)
    if len(set(name.casefold() for name in names)) != len(names):
        raise ValueError('tracks.py contains duplicate built-in audio filenames')
    return names


def _path_for(name, folder):
    p = os.path.join(folder, name)
    return p if os.path.isfile(p) and os.path.getsize(p) > 0 else None


def path_for(name):
    """Return a track only after the entire current pack is verified and ready."""
    folder = data_dir()
    if not pack_ready(folder):
        return None
    return _path_for(name, folder)


def missing(folder=None):
    folder = folder or data_dir()
    return [name for name in _names() if _path_for(name, folder) is None]


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, 'rb') as source:
        for block in iter(lambda: source.read(CHUNK), b''):
            h.update(block)
    return h.hexdigest()


def _marker_path(folder=None):
    return os.path.join(folder or data_dir(), 'installed_pack.sha256')


def installed_sha256(folder=None):
    try:
        with open(_marker_path(folder), 'r', encoding='ascii') as marker:
            return marker.read().strip().lower()
    except (IOError, OSError):
        return ''


def pack_ready(folder=None):
    """True only after the expected SHA marker exists and every current track is complete.

    The installer extracts into staging and writes the marker last. Requiring
    both the marker and every non-empty catalogue file prevents the service
    from exposing the first files while the remaining tracks are still being
    installed, and also hides stale files while a replacement pack is pending.
    """
    expected = (PACK_SHA256 or '').strip().lower()
    if not expected or installed_sha256(folder) != expected:
        return False
    return not missing(folder)


def available_paths(folder=None):
    """Return the complete filename-to-path map, or an empty map until ready."""
    folder = folder or data_dir()
    if not pack_ready(folder):
        return {}
    return {name: _path_for(name, folder) for name in _names()}


def needs_install(folder=None):
    """True when the installed pack is stale or any current catalogue file is absent."""
    return not pack_ready(folder)


def download(url, target, progress=None):
    """Download url to target using a temporary file; target is replaced on success."""
    part = target + '.part'
    try:
        request = urllib.request.Request(
            url,
            headers={'User-Agent': 'Nightshift-Ambience'},
        )
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response, open(part, 'wb') as output:
            header_size = response.headers.get('Content-Length')
            total = int(header_size) if header_size and header_size.isdigit() else PACK_SIZE
            done = 0
            while True:
                block = response.read(CHUNK)
                if not block:
                    break
                output.write(block)
                done += len(block)
                if progress:
                    progress(done, total)
        if not os.path.isfile(part) or os.path.getsize(part) <= 0:
            raise ValueError('the downloaded ambience pack is empty')
        os.replace(part, target)
    except Exception:
        try:
            if os.path.exists(part):
                os.remove(part)
        except OSError:
            pass
        raise


def _write_marker(folder, sha256):
    marker = _marker_path(folder)
    temporary = marker + '.part'
    with open(temporary, 'w', encoding='ascii', newline='\n') as output:
        output.write(sha256.strip().lower() + '\n')
    os.replace(temporary, marker)


def unpack(pack, folder):
    """Install every filename in the current catalogue and remove obsolete pack tracks.

    All wanted files are first extracted into a temporary directory. No current
    installed audio is replaced or removed until every expected file is present
    and readable in the downloaded archive.
    """
    wanted_names = _names()
    wanted = set(wanted_names)
    if not wanted:
        raise ValueError('the current built-in track catalogue is empty')

    os.makedirs(folder, exist_ok=True)
    staging = tempfile.mkdtemp(prefix='.ambience-unpack-', dir=folder)
    extracted = set()
    try:
        with zipfile.ZipFile(pack, 'r') as archive:
            bad_member = archive.testzip()
            if bad_member:
                raise ValueError('audio pack CRC check failed at %s' % bad_member)

            for info in archive.infolist():
                name = info.filename
                if info.is_dir() or name not in wanted:
                    continue
                if '/' in name or '\\' in name or os.path.basename(name) != name:
                    continue
                if name in extracted:
                    raise ValueError('audio pack contains a duplicate track: %s' % name)
                destination = os.path.join(staging, name)
                with archive.open(info, 'r') as source, open(destination, 'wb') as output:
                    shutil.copyfileobj(source, output)
                if os.path.getsize(destination) <= 0:
                    raise ValueError('audio pack contains an empty track: %s' % name)
                extracted.add(name)

        missing_names = sorted(wanted - extracted)
        if missing_names:
            raise ValueError('audio pack is missing catalogue tracks: %s' % ', '.join(missing_names))

        # Install all verified files. If interrupted, the checksum marker remains
        # old, so the next service start retries the complete pack installation.
        for name in wanted_names:
            os.replace(os.path.join(staging, name), os.path.join(folder, name))

        # The built-in audio data directory is dedicated to pack-managed tracks.
        # Remove old audio files no longer present in the latest catalogue.
        removed = []
        for name in os.listdir(folder):
            path = os.path.join(folder, name)
            if name not in wanted and os.path.isfile(path):
                if os.path.splitext(name)[1].lower() in AUDIO_EXTENSIONS:
                    try:
                        os.remove(path)
                        removed.append(name)
                    except OSError as exc:
                        log('could not remove obsolete built-in track %s: %s' % (name, exc), xbmc.LOGWARNING)

        return removed
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def install(url=PACK_URL, sha256=PACK_SHA256, folder=None, progress=None):
    """Download, checksum, install current catalogue and record the installed pack hash."""
    folder = folder or data_dir()
    os.makedirs(folder, exist_ok=True)
    pack = os.path.join(folder, '.ambience-pack.download.zip')
    try:
        download(url, pack, progress)
        got = sha256_of(pack)
        expected = (sha256 or '').strip().lower()
        if got != expected:
            raise ValueError('pack checksum is %s, expected %s' % (got, expected))

        removed = unpack(pack, folder)
        _write_marker(folder, expected)
        if removed:
            log('removed %d obsolete built-in track(s)' % len(removed))
        return []
    finally:
        for temporary in (pack, pack + '.part'):
            try:
                if os.path.exists(temporary):
                    os.remove(temporary)
            except OSError:
                pass


def ensure_async(notify=True):
    """Refresh asynchronously when the pack SHA changes or a current track is missing."""
    global _running
    if not needs_install():
        return
    with _lock:
        if _running:
            return
        _running = True
    threading.Thread(target=_worker, args=(notify,), daemon=True).start()


def _worker(notify):
    global _running
    try:
        if notify:
            xbmcgui.Dialog().notification(
                'NIGHTSHIFT Ambience',
                'Downloading the built-in tracks',
                xbmcgui.NOTIFICATION_INFO,
                4000,
                False,
            )
        log('refreshing built-in tracks from %s' % PACK_URL)
        install()
        if notify:
            xbmcgui.Dialog().notification(
                'NIGHTSHIFT Ambience',
                'Built-in tracks updated',
                xbmcgui.NOTIFICATION_INFO,
                4000,
                False,
            )
        log('built-in tracks installed; checksum marker updated')
    except Exception as exc:
        log('could not install the built-in tracks: %s' % exc, xbmc.LOGWARNING)
        if notify:
            xbmcgui.Dialog().notification(
                'NIGHTSHIFT Ambience',
                'Built-in tracks not installed (see log)',
                xbmcgui.NOTIFICATION_WARNING,
                6000,
                False,
            )
    finally:
        with _lock:
            _running = False
