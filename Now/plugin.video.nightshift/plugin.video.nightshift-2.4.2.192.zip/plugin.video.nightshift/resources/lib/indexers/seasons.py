# -*- coding: utf-8 -*-
import sys
from modules import kodi_utils, settings
from modules.metadata import tvshow_meta, episode_groups
from modules.utils import get_datetime, adjust_premiered_date, TaskPool
from modules.watched_status import get_database, watched_info_season, get_watched_status_season, get_progress_status_season, count_aired_episodes
# logger = kodi_utils.logger

def build_season_list(params):
	def _process():
		total_aired_eps, episode_count = meta_get('total_aired_eps'), 0
		for item in season_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				overview, poster_path, air_date = item_get('overview'), item_get('poster_path'), item_get('air_date')
				season_number, aired_eps = item_get('season_number'), item_get('episode_count')
				season_special = season_number == 0
				if use_name: title = item_get('name', None) or 'Season %s' % season_number
				else: title = 'Season %s' % season_number
				if custom_order is not None: title = '%s - %s' % (show_title, title)
				poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
				thumb = poster or show_landscape or show_fanart
				try: year = air_date.split('-')[0]
				except: year = show_year or '2050'
				plot = overview or show_plot
				try: premiered = adjust_premiered_date(air_date, adjust_hours)[1]
				except: premiered = ''
				unaired = aired_eps == 0
				if unaired:
					# Must set watched/unwatched here — Specials sorts last and previously
					# leaked the prior season's counts via unset locals (e.g. S5 10 → Specials 10/37).
					progress, playcount, watched, unwatched = 0, 0, 0, aired_eps
					title = '[COLOR red][I]%s[/I][/COLOR]' % title
				elif season_special:
					title = 'Specials'
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				else:
					if season_number < total_seasons:
						episode_count += aired_eps
					else:
						# Current/latest season: count by premiered date (same as episode unaired colour).
						aired_eps = count_aired_episodes(meta, season=season_number, current_date=current_date, adjust_hours=adjust_hours)
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				visible_progress = '' if progress == 100 else progress
				url_params = build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season_number})
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': is_external})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				settings.append_external_scraper_settings_cm(cm_append, build_url)
				settings.append_theme_song_cm(cm_append, build_url, tmdb_id, season_number)
				if playcount:
					if hide_watched: continue
				elif not unaired:
						cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_season', 'action': 'mark_as_watched',
															'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number}))])
				if progress:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_season', 'action': 'mark_as_unwatched',
														'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number}))])
				set_properties({'watchedepisodes': str(watched), 'unwatchedepisodes': str(unwatched)})
				set_properties({'totalepisodes': str(aired_eps), 'watchedprogress': str(visible_progress),
								'nightshift.extras_params': extras_params, 'nightshift.options_params': options_params})
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				info_tag = listitem.getVideoInfoTag()
				info_tag.setMediaType('season'), info_tag.setTitle(title), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(show_title), info_tag.setIMDBNumber(imdb_id)
				info_tag.setSeason(season_number), info_tag.setPlot(plot), info_tag.setDuration(episode_run_time), info_tag.setPlaycount(playcount), info_tag.setGenres(genre)
				info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id, 'tvdb': str_tvdb_id})
				info_tag.setTvShowStatus(status), info_tag.setFirstAired(premiered), info_tag.setStudios(studio), info_tag.setYear(int(year))
				info_tag.setRating(0), info_tag.setVotes(0), info_tag.setMpaa(mpaa), info_tag.setCountries(country), info_tag.setTrailer(trailer)
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				listitem.setLabel(title)
				listitem.setArt({'poster': poster, 'season.poster': poster, 'fanart': show_fanart, 'clearlogo': show_clearlogo, 'landscape': show_landscape, 'thumb': thumb,
								'icon': show_landscape, 'tvshow.poster': poster, 'tvshow.clearlogo': show_clearlogo})
				listitem.addContextMenuItems(cm)
				yield (url_params, listitem, True)
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	watched_indicators, adjust_hours, hide_watched = settings.watched_indicators(), settings.date_offset(), is_external and settings.widget_hide_watched()
	current_date = get_datetime()
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	use_name = settings.use_season_name()
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, show_title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
	orig_title, status, show_plot = meta_get('original_title', ''), meta_get('status'), meta_get('plot')
	str_tmdb_id, str_tvdb_id, rating, genre = str(tmdb_id), str(tvdb_id), meta_get('rating'), meta_get('genre')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	mpaa, votes, trailer, studio, country = meta_get('mpaa'), meta_get('votes'), str(meta_get('trailer')), meta_get('studio'), meta_get('country')
	episode_run_time, season_data, total_seasons = meta_get('duration'), meta_get('season_data'), meta_get('total_seasons')
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo, show_landscape = meta_get('clearlogo') or '', meta_get('landscape') or meta_get('fanart') or ''
	custom_order = params.get('custom_order', None)
	if settings.show_specials(): season_data.sort(key=lambda i: (i['season_number'] == 0, i['season_number']))
	elif custom_order is not None: season_data = [i for i in season_data if i['season_number'] == params['season']]
	else:
		season_data = [i for i in season_data if not i['season_number'] == 0]
		season_data.sort(key=lambda k: k['season_number'])
	watched_info = watched_info_season(tmdb_id, get_database(watched_indicators))
	if watched_indicators == 2 and settings.simkl_user_active():
		from apis.simkl_api import simkl_sync_activities
		simkl_sync_activities()
		watched_info = watched_info_season(tmdb_id, get_database(watched_indicators))
	if watched_indicators == 3 and settings.mdblist_user_active():
		from apis.mdblist_api import mdblist_sync_activities
		mdblist_sync_activities()
		watched_info = watched_info_season(tmdb_id, get_database(watched_indicators))
	list_items = list(list(_process()))
	if custom_order is not None: return (list_items[0], custom_order)
	try:        # Episode Orders (TVDB: Aired / DVD / Absolute ..., TMDb groups): an entry above the seasons
		if not settings.tvdb_api_key() in (None, '', 'empty_setting') or episode_groups(tmdb_id):
			orders_item = make_listitem()
			orders_item.setLabel('[B]Episode Orders[/B]  (Aired / DVD / Absolute ...)')
			orders_info = orders_item.getVideoInfoTag()
			orders_info.setMediaType('season'), orders_info.setTitle('Episode Orders'), orders_info.setTvShowTitle(show_title), orders_info.setPlot('Browse and play this show in another order: Aired, DVD, Absolute and the others TVDB and TMDb list. Autoplay follows the order you pick.')
			orders_item.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': show_landscape or show_poster, 'icon': show_landscape or show_poster, 'clearlogo': show_clearlogo})
			list_items.insert(0, (build_url({'mode': 'build_order_list', 'tmdb_id': tmdb_id}), orders_item, True))
	except Exception: pass
	kodi_utils.add_items(handle, list_items)
	kodi_utils.set_content(handle, 'seasons')
	kodi_utils.set_category(handle, show_title)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.seasons', 'seasons', is_external)

def single_seasons(seasons_list):
	season_results = []
	threads = TaskPool().tasks(lambda x: season_results.append(build_season_list(x)), seasons_list, min(len(seasons_list), settings.max_threads()))
	[i.join() for i in threads]
	return [i for i in season_results if i]


def build_order_list(params):
	"""The orders available for a show (TVDB: Aired, DVD, Absolute ...; TMDb episode groups)."""
	from apis.tmdb_api import order_choices
	handle = int(sys.argv[1])
	make_listitem, build_url = kodi_utils.make_listitem, kodi_utils.build_url
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	poster, fanart = meta.get('poster') or '', meta.get('fanart') or kodi_utils.addon_fanart()
	items = []
	for order in order_choices(meta.get('tmdb_id'), meta.get('tvdb_id')):
		li = make_listitem()
		li.setLabel(order['name'])
		tag = li.getVideoInfoTag()
		tag.setMediaType('season'), tag.setTitle(order['name']), tag.setTvShowTitle(meta.get('title') or ''), tag.setPlot(order.get('info') or '')
		li.setArt({'poster': poster, 'fanart': fanart, 'thumb': meta.get('landscape') or poster, 'icon': meta.get('landscape') or poster})
		items.append((build_url({'mode': 'build_order_episodes', 'tmdb_id': meta.get('tmdb_id'), 'order_id': order['id'], 'order_name': order['name']}), li, True))
	if not items: kodi_utils.notification('No other orders found for this show', 3000)
	kodi_utils.add_items(handle, items)
	kodi_utils.set_content(handle, 'seasons')
	kodi_utils.set_category(handle, 'Episode Orders')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.seasons', 'seasons', kodi_utils.external())

def order_play_params(meta, entry, order_id, playback_key, extra=None):
	"""URL params that play one entry of an order (the TMDb season / episode it maps to, plus the order so Autoplay stays in it)."""
	params = {'mode': 'playback.%s' % playback_key, 'media_type': 'episode', 'tmdb_id': meta.get('tmdb_id'), 'season': entry['tmdb_season'], 'episode': entry['tmdb_episode'],
			'order_id': order_id, 'order_index': entry['index'], playback_key: playback_key}
	if entry.get('title') and not entry.get('mapped'): params['order_title'] = entry['title']
	if extra: params.update(extra)
	return params

def _order_context_menu(meta, e, order_id, watched, tmdb_id, tvdb_id, title):
	"""The same context menu as the normal episode list (Extras, Options, Play Options, sources, theme song, mark watched, clear progress),
	for an episode of an Episode Order. Watched history is keyed by the TMDb season / episode the entry plays as."""
	from modules.watched_status import get_watched_status_episode, get_bookmarks_episode
	from modules.utils import adjust_premiered_date, get_datetime
	season, episode = int(e['tmdb_season']), int(e['tmdb_episode'])
	build_url = kodi_utils.build_url
	cm = []
	cm_append = cm.append
	playcount = get_watched_status_episode(watched, (season, episode))
	try:
		aired_on = adjust_premiered_date(e.get('aired'), settings.date_offset())[0] if e.get('aired') else None
		unaired = bool(aired_on) and get_datetime() < aired_on
	except Exception: unaired = False
	cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': False}))])
	cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': meta.get('poster') or '', 'is_external': False, 'season': season, 'episode': episode}))])
	cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount, 'episode': episode}))])
	settings.append_source_shortcut_context_menus(cm_append, build_url, settings.cm_sort_order(), 'episode', tmdb_id, season, episode, playcount)
	settings.append_external_scraper_settings_cm(cm_append, build_url)
	settings.append_theme_song_cm(cm_append, build_url, tmdb_id, season)
	if not unaired:
		if playcount: cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode, 'title': title}))])
		else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode, 'title': title}))])
	try:
		if get_bookmarks_episode(str(tmdb_id), season).get(episode):
			cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'refresh': 'true'}))])
	except Exception: pass
	return cm

def build_order_episodes(params):
	"""All episodes of one order, in that order, laid out like an episode list."""
	from apis.tmdb_api import order_entries
	from modules.watched_status import watched_info_episode, get_watched_status_episode
	handle = int(sys.argv[1])
	make_listitem, build_url = kodi_utils.make_listitem, kodi_utils.build_url
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), get_datetime()) or {}
	order_id = params['order_id']
	playback_key = settings.playback_key()
	poster, fanart = meta.get('poster') or '', meta.get('fanart') or kodi_utils.addon_fanart()
	watched = watched_info_episode(meta.get('tmdb_id'))
	items = []
	for e in order_entries(order_id, meta):
		special = e.get('season') == 0
		label = ('Special %s' % e['number']) if special else ('%sx%02d' % (e['season'], e['number']))
		if e.get('group') and not special: label = '%s  %s' % (e['group'], label) if False else label
		from apis.tmdb_api import episode_title_for_skin
		title = '%s. %s' % (label, episode_title_for_skin(e) or 'Episode')
		if not e.get('mapped'): title += '  [COLOR gray](special, found by name)[/COLOR]'
		li = make_listitem()
		li.setLabel(title)
		tag = li.getVideoInfoTag()
		tag.setMediaType('episode'), tag.setTitle(title), tag.setTvShowTitle(meta.get('title') or ''), tag.setPlot(e.get('plot') or meta.get('plot') or '')
		tag.setSeason(e['tmdb_season']), tag.setEpisode(e['tmdb_episode']), tag.setFirstAired(e.get('aired') or '')
		try:
			if e.get('runtime'): tag.setDuration(int(e['runtime']) * 60)
		except Exception: pass
		try:
			if get_watched_status_episode(watched, (e['tmdb_season'], e['tmdb_episode'])): tag.setPlaycount(1)
		except Exception: pass
		thumb = e.get('thumb') or meta.get('landscape') or fanart
		from indexers.episodes import _ep_bg, episode_picture
		background = _ep_bg(thumb, fanart, False, episode_picture(e, meta.get('tmdb_id'), e['tmdb_season'], e['tmdb_episode']))
		li.setArt({'poster': poster, 'fanart': background, 'thumb': thumb, 'icon': thumb, 'landscape': thumb, 'tvshow.poster': poster})
		cm = _order_context_menu(meta, e, order_id, watched, tmdb_id=meta.get('tmdb_id'), tvdb_id=meta.get('tvdb_id'), title=title)
		try: li.addContextMenuItems(cm)
		except Exception: pass
		items.append((build_url(order_play_params(meta, e, order_id, playback_key)), li, False))
	kodi_utils.add_items(handle, items)
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, params.get('order_name') or 'Episode Order')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes', 'episodes', kodi_utils.external())
