# -*- coding: utf-8 -*-
import sys
from modules import kodi_utils, settings, watched_status as ws
from modules.metadata import tvshow_meta, episodes_meta, all_episodes_meta, history_episode_coordinates
from modules.utils import jsondate_to_datetime, adjust_premiered_date, calendar_service_local_date, make_day, airing_local_datetime, airtime_label, get_datetime, get_current_timestamp, title_key, date_difference, TaskPool
from datetime import timedelta, datetime, timezone
# logger = kodi_utils.logger


def _episode_name(item):
	"""The episode's name for the row label (Skin Settings > Episode titles: English or Japanese)."""
	from apis.tmdb_api import episode_title_for_skin
	return episode_title_for_skin(item)

def _episode_source():
	"""Skin Settings > Episode background: show (default), fanart, file, tvdb, tmdb or simkl."""
	for source in ('fanart', 'file', 'tvdb', 'tmdb', 'simkl'):
		if kodi_utils.get_visibility('String.IsEqual(Skin.String(ns_episode_bg_source),%s)' % source): return source
	return 'show'

def _clean_art(art):
    """Artwork for setArt: Kodi warns about None values, so a missing path is passed as an empty string."""
    return {k: ('' if v is None else v) for k, v in (art or {}).items()}

def _row_key(item):
    """Identity of one Recently Watched row. The packet keeps it as rw_key, so an unchanged row can reuse its packet."""
    from caches.recent_watched_cache import row_key
    return row_key(item)

def _merge_recent_plan(plan, item_list, item_list_append, make_listitem, kodi_actor, watched_db, is_external):
    """Recently Watched incremental: an unchanged row is painted from its cached packet, a changed row from the rebuild.
    Every row gets its position in the full list, so the sort that follows gives the same order as a full build."""
    rebuilt = {}
    for row in list(item_list):
        key = (row.get('row_packet') or {}).get('rw_key')
        if key and key not in rebuilt:
            rebuilt[key] = row
    del item_list[:]
    for index, key, stale in plan['slots']:
        if stale is not None:
            packet = dict(stale)
            packet['sort_order'] = index
            _paint_episode_list_packet(packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
                                       live_progress=True, log_label='recent watched incremental')
        else:
            row = rebuilt.get(key)
            if row is None:
                continue
            row['sort_order'] = index
            row['row_packet']['sort_order'] = index
            item_list_append(row)

def _tvdb_fallback_logged(item, tmdb_id, season, episode):
    """The TVDB image used when the random bag has no still. Logs what was checked and the URL it gave."""
    image = _tvdb_still(item)
    if not image:
        import os
        local = item.get('local_thumb') or ''
        if local and os.path.isfile(local):
            image = local
    try:
        kodi_utils.logger('TMDbRandomBag', 'TVDB fallback tmdb %s S%sE%s: item tvdb_image %s, tvdb id %s, absolute %s -> %s' % (
            tmdb_id, season, episode, 'present' if item.get('tvdb_image') else 'none', item.get('tvdb_id'),
            item.get('absolute_episode'), image or 'NO IMAGE (TVDB has none for this season and episode)'))
    except Exception:
        pass
    return image

def _tvdb_still(item):
    """The TVDB still for this episode: the backup when TMDb has none. With none on the item, the TVDB aired-order
    image for the same season and episode, or for its absolute number."""
    image = item.get('tvdb_image') or ''
    if image and not image.startswith('http'):
        image = 'https://artworks.thetvdb.com' + (image if image.startswith('/') else '/' + image)
    if image:
        return image
    try:
        from apis.tmdb_api import tvdb_aired_order_image
        return tvdb_aired_order_image(item.get('tvdb_id'), item.get('season'), item.get('episode'),
                                      item.get('absolute_episode')) or ''
    except Exception:
        return ''
def _absolute_for_item(item, season, episode):
    """Absolute episode number for the random-bag fallback: the item's own, else TVDB's aired-order map."""
    absolute = item.get('absolute_episode')
    if absolute not in (None, '', 0):
        return absolute
    try:
        from apis.tmdb_api import tvdb_absolute_for
        return tvdb_absolute_for(item.get('tvdb_id'), season, episode)
    except Exception:
        return None

def _still_coords(item):
    """(season, episode, absolute) for the artwork lookup when the aired order was matched to TMDb's positions, else None.
    Watch history keeps its own numbering (tmdb_season / tmdb_episode), so this never changes what is marked watched."""
    s, e, a = item.get('still_season'), item.get('still_episode'), item.get('still_absolute')
    if s is None or e is None:
        return None
    try:
        return int(s), int(e), (int(a) if a is not None else None)
    except Exception:
        return None

def _still_props(item):
    """Artwork coordinates as list properties, so the focus monitor draws the same still the row shows."""
    c = _still_coords(item)
    if not c: return {}
    return {'nightshift.still_season': str(c[0]), 'nightshift.still_episode': str(c[1]), 'nightshift.still_absolute': str(c[2] if c[2] is not None else '')}

def episode_picture(item, tmdb_id=None, season=None, episode=None):
	"""Return the episode background from the selected source. TMDb stills are downloaded once to the persistent random-bag cache;
	bag state and local image paths survive list rebuilds and Kodi restarts."""
	source = _episode_source()
	try:
		if source == 'fanart': return item.get('fanart') or ''
		if source == 'tvdb':
			_img = item.get('tvdb_image') or ''
			return _img if (not _img or _img.startswith('http')) else 'https://artworks.thetvdb.com' + (_img if _img.startswith('/') else '/' + _img)
		if source == 'simkl': return item.get('simkl_image') or ''
		if source == 'tmdb' and tmdb_id and season is not None and episode is not None:
			# Calendars never seed/advance the secret still bag.
			if item.get('calendar_source') in ('anilist', 'simkl_public') or item.get('first_aired') and item.get('anilist_id'):
				return ''
			still = _still_coords(item)
			if still: season, episode, still_abs = still
			else: still_abs = None
			from caches.tmdb_random_bag_cache import current_image, pick_next, ensure_episode_set
			# Rings view 510 advances only from the focus monitor. Other legacy episode
			# layouts retain their existing list-build shuffle behavior, now backed by
			# the same persistent local cache rather than remote still URLs.
			if kodi_utils.get_visibility('Skin.HasSetting(ns_focus_rings)'):
				return current_image(tmdb_id, season, episode) or _tvdb_still(item)
			return pick_next(tmdb_id, season, episode, item.get('title') or '', (still_abs if still_abs is not None else _absolute_for_item(item, season, episode))) or _tvdb_fallback_logged(item, tmdb_id, season, episode)
	except Exception: pass
	return ''

def _ep_bg(episode_thumb, show_fanart, thumb_hidden=False, episode_fanart=None, file_thumb_last=False):
	"""The background of an episode row. show: the show's fanart. fanart / tvdb / tmdb / simkl: the chosen picture (episode_fanart),
	then the episode's own thumbnail. file: the episode's own thumbnail. When nothing is found: a My Services / Local Folders row
	(file_thumb_last) gives '' so the video file's own thumbnail is used; other lists show the show's fanart. The spoiler setting
	(thumb_hidden) keeps the show's fanart."""
	try:
		if thumb_hidden: return show_fanart
		source = _episode_source()
		if source == 'show': return show_fanart
		if source in ('fanart', 'tvdb', 'tmdb', 'simkl'):
			for picture in (episode_fanart, episode_thumb):
				if picture: return picture
		elif episode_thumb: return episode_thumb
	except Exception: return show_fanart
	return '' if file_thumb_last else show_fanart


def _public_tv_calendar_feed():
	"""Non-anime Public TV Calendar rows.

	Source is Settings > Public TV Calendar Source (Simkl or Trakt).
	If the preferred source has no credentials / returns nothing, try the other.
	If neither works, log and return []. Anime is never mixed in here (AniList path handles that).
	"""
	preferred = settings.public_tv_calendar_source()
	order = [preferred, 'trakt' if preferred == 'simkl' else 'simkl']
	seen = set()
	errors = []
	for source in order:
		if source in seen:
			continue
		seen.add(source)
		if source == 'simkl':
			try:
				from apis.simkl_api import simkl_get_public_calendar, _client_id
				cid = _client_id()
				if not cid:
					errors.append('Simkl: no client id')
					kodi_utils.logger('PublicTVCalendar', 'Simkl client id missing — skipping Simkl CDN calendar')
					continue
				data = simkl_get_public_calendar('tv') or []
				if data:
					kodi_utils.logger('PublicTVCalendar', 'using Simkl TV CDN calendar (%d rows)' % len(data))
					return data
				errors.append('Simkl: empty calendar')
				kodi_utils.logger('PublicTVCalendar', 'Simkl TV calendar returned no rows')
			except Exception as exc:
				errors.append('Simkl: %s' % exc)
				kodi_utils.logger('PublicTVCalendar', 'Simkl TV calendar failed: %s' % exc)
		else:
			try:
				from apis.trakt_api import trakt_get_public_calendar
				from modules.settings import trakt_client
				cid = trakt_client()
				if cid in (None, 'empty_setting', '', 'API_HERE'):
					errors.append('Trakt: no client id')
					kodi_utils.logger('PublicTVCalendar', 'Trakt client id missing — skipping calendars/all/shows')
					continue
				data = trakt_get_public_calendar()
				if data is None:
					errors.append('Trakt: no client id')
					continue
				if data:
					kodi_utils.logger('PublicTVCalendar', 'using Trakt calendars/all/shows (%d rows)' % len(data))
					return data
				errors.append('Trakt: empty calendar')
				kodi_utils.logger('PublicTVCalendar', 'Trakt public calendar returned no rows')
			except Exception as exc:
				errors.append('Trakt: %s' % exc)
				kodi_utils.logger('PublicTVCalendar', 'Trakt public calendar failed: %s' % exc)
	kodi_utils.logger('PublicTVCalendar', 'no credentials or data for public TV calendar (%s)' % '; '.join(errors) if errors else 'no credentials to get calendars')
	try:
		kodi_utils.notification('No calendar credentials (set Simkl or Trakt client id)', 5000)
	except Exception:
		pass
	return []


def _anilist_calendar_feed(force=False):
	"""Build episode rows from the AniList calendar cache (not Simkl). Logs source so the Kodi log shows the path.

	Rows with a TMDb match use TMDb metadata as before. Rows with no TMDb match (title search and the TVDb bridge both
	missed) are kept with AniList data only: the calendar still lists them, but they cannot be played.
	"""
	from caches.anilist_calendar_cache import get_calendar
	kodi_utils.logger('AniListCalendar', 'feed start force=%s (AniList path; Simkl public anime is rewritten here)' % force)
	calendar_rows = get_calendar(force=force)
	data, anilist_only = [], []
	for row in calendar_rows:
		title = row.get('title_english') or row.get('title_romaji') or row.get('title_native') or ''
		airing_at = int(row['airing_at'])
		first_aired = datetime.fromtimestamp(airing_at, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
		if not row.get('tmdb_id'):
			anilist_only.append(title or str(row.get('anilist_id')))
			data.append({'media_ids': {'tmdb': 'al%s' % row['anilist_id']}, 'anilist_only': True, 'season': 1, 'episode': int(row['episode']),
				'first_aired': first_aired, 'sort_title': title, 'title': title, 'airing_at': airing_at,
				'anilist_id': row['anilist_id'], 'cover_url': row.get('cover_url') or '', 'banner_url': row.get('banner_url') or '', 'poster_url': '', 'calendar_source': 'anilist'})
			continue
		data.append({'media_ids': {'tmdb': str(row['tmdb_id'])}, 'season': 1, 'episode': int(row['episode']),
			'first_aired': first_aired, 'sort_title': title, 'title': title, 'airing_at': airing_at,
			'anilist_id': row['anilist_id'], 'calendar_source': 'anilist'})
	kodi_utils.logger('AniListCalendar', 'feed done: %d AniList rows (%d with TMDb ids, %d AniList-only, of %d raw)' % (
		len(data), len(data) - len(anilist_only), len(anilist_only), len(calendar_rows)))
	if anilist_only: kodi_utils.logger('AniListCalendar', 'AniList-only rows (no TMDb match, not playable, %d): %s' % (len(anilist_only), ' | '.join(sorted(set(anilist_only)))[:2000]))
	for sample in data[:15]:
		kodi_utils.logger('AniListCalendar', '  %s | ep %s | tmdb %s | %s' % (
			sample.get('first_aired'), sample.get('episode'), sample['media_ids']['tmdb'], sample.get('title')))
	return data


def _anilist_tmdb_episode(meta, airing_at, anilist_episode):
	"""Map an AniList airing to TMDb S/E by matching the air date, then episode number."""
	try:
		target = datetime.fromtimestamp(int(airing_at), timezone.utc).date()
		seasons = [i for i in (meta.get('season_data') or []) if int(i.get('season_number') or 0) > 0]
		if not seasons: return None, None, []
		with_dates = []
		for season_data in seasons:
			try: aired = datetime.strptime(str(season_data.get('air_date'))[:10], '%Y-%m-%d').date()
			except Exception: aired = None
			with_dates.append((aired, int(season_data.get('season_number'))))
		past = [i for i in with_dates if i[0] and i[0] <= target]
		if past: season = max(past, key=lambda i: i[0])[1]
		else:
			future = [i for i in with_dates if i[0]]
			season = min(future, key=lambda i: abs((i[0] - target).days))[1] if future else int(seasons[0].get('season_number') or 1)
		rows = episodes_meta(season, meta, use_tvdb_first=False, include_simkl_images=False) or []
		date_rows = []
		for item in rows:
			try:
				date = datetime.strptime(str(item.get('premiered') or '')[:10], '%Y-%m-%d').date()
				date_rows.append((abs((date - target).days), item))
			except Exception: pass
		if date_rows:
			distance, closest = min(date_rows, key=lambda i: i[0])
			if distance <= 4: return int(closest.get('season') or season), int(closest.get('episode') or 0), rows
		try:
			numbered = next((i for i in rows if int(i.get('episode') or 0) == int(anilist_episode)), None)
			if numbered: return int(numbered.get('season') or season), int(numbered.get('episode') or 0), rows
		except Exception: pass
		if date_rows and distance <= 14:
			return int(closest.get('season') or season), int(closest.get('episode') or 0), rows
		return None, None, rows
	except Exception as exc:
		try: kodi_utils.logger('AniListCalendar', 'TMDb episode number mapping failed: %s' % exc)
		except: pass
		return None, None, []


def _calendar_episode_date(service_first_aired, tmdb_premiered, adjust_hours):
	"""Use Trakt/MDBList/Simkl/PunchPlay air date for calendar label + sort (not TMDb premiered).

	Do not invent TMDb 20:00 / apply date_offset() here — that can push service calendar
	days one day ahead. Date-only events keep their calendar day; ISO timestamps
	use the user UTC (+/-) setting only.
	"""
	if service_first_aired:
		d, day = calendar_service_local_date(service_first_aired)
		if d is not None:
			return d, day
	return adjust_premiered_date(tmdb_premiered, adjust_hours)

def _nextep_indicator_watchlist(indicators=None):
	"""Never-started shows from a Watched Status Provider service watchlist (empty for NIGHTSHIFT)."""
	if indicators is None: indicators = settings.watched_indicators()
	try:
		if indicators == 1:
			from apis.trakt_api import trakt_watchlist
			data = trakt_watchlist('tvshow', '') or []
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 2:
			from apis.simkl_api import simkl_plantowatch
			data = (simkl_plantowatch('shows') or []) + (simkl_plantowatch('anime') or [])
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 3:
			from apis.mdblist_api import mdblist_watchlist_media_ids
			return mdblist_watchlist_media_ids('shows')
		if indicators == 4:
			from apis.punchplay_api import punchplay_watchlist
			data = (punchplay_watchlist('shows') or []) + (punchplay_watchlist('anime') or [])
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
	except: pass
	return []

_CLEAR_PROGRESS_LABEL = '[B]Clear Progress[/B]'

def _cm_sync_clear_progress(cm, packet, has_progress):
	"""Keep Clear Progress in line with live resume (cached Next Episodes CM can be stale)."""
	cm = [i for i in (cm or []) if not (isinstance(i, (list, tuple)) and i and i[0] == _CLEAR_PROGRESS_LABEL)]
	if not has_progress:
		return cm
	url = kodi_utils.build_url({
		'mode': 'watched_status.erase_bookmark', 'media_type': 'episode',
		'tmdb_id': packet['tmdb_id'], 'season': packet['season'], 'episode': packet['episode'],
		'refresh': 'true'
	})
	item = (_CLEAR_PROGRESS_LABEL, 'RunPlugin(%s)' % url)
	insert_at = len(cm)
	for idx, entry in enumerate(cm):
		if isinstance(entry, (list, tuple)) and entry and entry[0] in ('[B]Mark Watched[/B]', '[B]Mark Unwatched[/B]'):
			insert_at = idx + 1
	cm.insert(insert_at, item)
	return cm

def _anilist_only_listitem(pk, make_listitem):
	"""ListItem for an AniList-only calendar row (no TMDb match). Built from the stored packet fields only."""
	listitem = make_listitem()
	listitem.setLabel(pk['label'])
	tag = listitem.getVideoInfoTag()
	tag.setMediaType('episode'), tag.setTitle(pk['title']), tag.setTvShowTitle(pk['title']), tag.setSeason(1), tag.setEpisode(pk['episode']), tag.setFirstAired(pk['first_aired'])
	listitem.setArt(_clean_art(pk['art']))
	return listitem

def _paint_anilist_only(packet, item_list_append, make_listitem):
	item_list_append({'list_items': (packet['url'], _anilist_only_listitem(packet, make_listitem), False), 'first_aired': packet['first_aired'],
					'name': packet['name'], 'unaired': packet['unaired'], 'sort_order': packet['sort_order'], 'unwatched': False, 'row_packet': packet})

def _paint_episode_list_packet(packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
								live_progress=True, log_label='episode list cache'):
	"""Paint a cached row packet into item_list. Re-reads live WatchedProgress when requested."""
	if packet.get('kind') == 'anilist_only':
		return _paint_anilist_only(packet, item_list_append, make_listitem)
	try:
		listitem = make_listitem()
		set_properties = listitem.setProperties
		info_tag = listitem.getVideoInfoTag()
		info_tag.setMediaType('episode'), info_tag.setOriginalTitle(packet['orig_title']), info_tag.setTitle(packet['display_title'])
		info_tag.setGenres(packet['genre'] or [])
		if not packet.get('omit_tvshowtitle'): info_tag.setTvShowTitle(packet['tvshowtitle'])
		info_tag.setPlaycount(packet['playcount']), info_tag.setPlot(packet['plot'] or ''), info_tag.setFirstAired(packet['premiered'] or '')
		if not (packet.get('omit_season_episode') or packet.get('display_format') == 2):
			info_tag.setSeason(packet['season']), info_tag.setEpisode(packet['episode'])
		info_tag.setDuration(packet['duration']), info_tag.setIMDBNumber(packet['imdb_id'] or '')
		info_tag.setUniqueIDs({'imdb': packet['imdb_id'] or '', 'tmdb': str(packet['tmdb_id']), 'tvdb': str(packet['tvdb_id'])})
		info_tag.setCountries(packet.get('country') or []), info_tag.setTrailer(packet['trailer']), info_tag.setTvShowStatus(packet['show_status'])
		studio = packet.get('studio')
		if isinstance(studio, tuple): studio = list(studio)
		elif not studio: studio = []
		info_tag.setStudios(studio), info_tag.setWriters(packet.get('writer')), info_tag.setDirectors(packet.get('director'))
		info_tag.setYear(int(packet['year'])), info_tag.setRating(0), info_tag.setVotes(0), info_tag.setMpaa(packet.get('mpaa'))
		info_tag.setCast([kodi_actor(name=i['name'], role=i['role'], thumbnail=i['thumbnail']) for i in (packet.get('cast') or [])])
		ws.clear_listitem_kodi_resume(info_tag)
		try: listitem.setContentLookup(False)
		except: pass
		listitem.setLabel(packet['display'])
		listitem.setArt(_clean_art(packet.get('art') or {}))
		props = dict(packet.get('properties') or {})
		props.pop('WatchedProgress', None)
		if props: set_properties(props)
		_prog = None
		if live_progress:
			try:
				_bm = ws.get_bookmarks_episode(packet['tmdb_id'], packet['season'], watched_db)
				_prog = ws.get_progress_status_episode(_bm, packet['episode'])
				if _prog and not packet.get('unaired'):
					ws.apply_listitem_progress(info_tag, set_properties, _prog, packet.get('duration') or 0, is_external)
			except: pass
		cm = _cm_sync_clear_progress(packet.get('cm') or [], packet, bool(_prog) and not packet.get('unaired'))
		packet['cm'] = cm
		listitem.addContextMenuItems(cm)
		item_list_append({'list_items': (packet['play_params'], listitem, False), 'first_aired': packet.get('first_aired'),
						'name': packet.get('name'), 'unaired': packet.get('unaired'), 'last_played': packet.get('last_played'),
						'sort_order': packet.get('sort_order'), 'unwatched': packet.get('unwatched'),
						'row_packet': packet})
	except Exception as e:
		try: kodi_utils.logger('NIGHTSHIFT', '%s paint failed: %s' % (log_label, e))
		except: pass

def build_episode_list(params):
	# Preload TMDb still bags for this show (not calendars).
	try:
		from caches.tmdb_random_bag_cache import preload_show_episode_stills
		_preload_tmdb = params.get('tmdb_id')
		if _preload_tmdb:
			preload_show_episode_stills(_preload_tmdb, seasons=[params['season']] if params.get('season') not in (None, '', 'all') else None)
	except Exception:
		pass
	def service_dates(season_no):
		# first_aired per episode from the calendar service (Trakt), the dates the calendar shows; {} when it has none
		if season_no not in service_cache:
			dates = {}
			if season_no:
				# Anime: existing AniList calendar cache/DB (same source as Public Anime Calendar).
				# Non-anime: Trakt.
				dates = {}
				if show_is_anime:
					try:
						from caches.anilist_calendar_cache import air_dates_for_tmdb, ensure_calendar_warm
						ensure_calendar_warm()
						dates = air_dates_for_tmdb(tmdb_id, season_no, meta) or {}
					except Exception: dates = {}
				if not dates:
					try:
						from apis.trakt_api import trakt_season_air_dates
						dates = trakt_season_air_dates(imdb_id, season_no)
					except Exception: dates = {}
			service_cache[season_no] = dates
		return service_cache[season_no]
	def _process():
		for item in episodes_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				season, episode, ep_name = item_get('season'), item_get('episode'), _episode_name(item)
				season_special = season == 0
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
				if include_airdate: air_date, air_day = _calendar_episode_date(service_dates(season).get(episode), item_get('premiered'), adjust_hours)
				else: air_date, air_day = episode_date, None
				if air_day: premiered = air_day            # Premiered / Year / date sorting follow the calendar date too
				episode_type = item_get('episode_type') or ''
				episode_id = item_get('episode_id') or None
				history_season, history_episode = history_episode_coordinates(item, season, episode)
				playcount = ws.get_watched_status_episode(watched_info, (history_season, history_episode))
				if playcount and hide_watched: continue
				if total_seasons: progress = ws.get_progress_status_all_episode(bookmarks, season, episode)
				else: progress = ws.get_progress_status_episode(bookmarks, episode)
				thumb = (show_landscape or show_fanart) if (hide_thumb and not playcount) else (item_get('thumb', None) or show_landscape or show_fanart)
				plot = (tvshow_plot or '') if (hide_plot and not playcount) else (item_get('plot') or tvshow_plot)
				try: year = premiered.split('-')[0]
				except: year = show_year or '2050'
				duration = item_get('duration')
				if not duration:
					duration = show_duration
					item['duration'] = duration
				str_episode_zfill2 = str(episode).zfill(2)
				seas_ep = '%sx%s. ' % (season, str_episode_zfill2)
				# Air date in front of the episode, written like the calendars write it ([TODAY], [2026-10-31], ...)
				air_prefix = '[%s] ' % make_day(current_date, air_date, date_strftime, date_use_words, date_include_date) if (include_airdate and air_date) else ''
				if include_airdate and air_date: episode_date = air_date          # aired / not aired follows the calendar date too
				if not episode_date or current_date < episode_date:
					display, unaired = '[COLOR red][I]%s%s%s[/I][/COLOR]' % (air_prefix, seas_ep, ep_name), True
					item['title'] = display
				else: display, unaired = '%s%s%s' % (air_prefix, seas_ep, ep_name), False
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external,
											'season': season, 'episode': episode, 'episode_id': episode_id})
				playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
												'episode': episode, 'episode_id': episode_id})
				play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
										'episode_id': episode_id, playback_key: playback_key})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % playback_options_params)])
				settings.append_source_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'episode', tmdb_id, season, episode, playcount)
				settings.append_external_scraper_settings_cm(cm_append, build_url)
				settings.append_theme_song_cm(cm_append, build_url, tmdb_id, season)
				if not unaired:
					if playcount:
						cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': history_season, 'episode': history_episode,  'title': title}))])
					else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': history_season, 'episode': history_episode,  'title': title}))])
					if progress: cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
								'season': season, 'episode': episode, 'refresh': 'true'}))])
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				studios = list(studio) if isinstance(studio, tuple) else (studio or [])
				info_tag = listitem.getVideoInfoTag()
				info_tag.setMediaType('episode'), info_tag.setTitle(ep_name), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(title), info_tag.setGenres(genre)
				info_tag.setPlaycount(playcount), info_tag.setSeason(season), info_tag.setEpisode(episode), info_tag.setPlot(plot or '')
				info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id or ''), info_tag.setUniqueIDs({'imdb': imdb_id or '', 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
				info_tag.setFirstAired(premiered or ''), info_tag.setTvShowStatus(show_status or '')
				info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setDirectors(item_get('director'))
				info_tag.setYear(int(year)), info_tag.setRating(0), info_tag.setVotes(0), info_tag.setMpaa(mpaa)
				info_tag.setStudios(studios), info_tag.setWriters(item_get('writer'))
				full_cast = cast + (item_get('guest_stars') or [])
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
				ws.clear_listitem_kodi_resume(info_tag)
				try: listitem.setContentLookup(False)
				except: pass
				if progress and not unaired:
					ws.apply_listitem_progress(info_tag, set_properties, progress, duration, is_external)
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt(_clean_art({'poster': show_poster, 'fanart': _ep_bg(item_get('thumb', None), show_fanart, hide_thumb and not playcount, episode_picture(item, tmdb_id, (item['tmdb_season'] if item.get('tmdb_season') is not None else season), (item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode))), 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': thumb,
								'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo,
								'tvshow.landscape': show_landscape}))
				set_properties({
					'episode_type': episode_type, 'nightshift.extras_params': extras_params, 'nightshift.options_params': options_params,
					'nightshift.playback_options_params': playback_options_params,
					'nightshift.tmdb_id': str(tmdb_id), **_still_props(item), 'nightshift.tvdb_still': _tvdb_still(item), 'nightshift.tmdb_season': str((item['tmdb_season'] if item.get('tmdb_season') is not None else season)), 'nightshift.tmdb_episode': str((item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode))
					})
				yield (play_params, listitem, False)
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	hide_thumb, hide_plot = settings.hide_episode_thumb(), settings.hide_episode_plot()
	item_list = []
	append = item_list.append
	watched_indicators, adjust_hours = settings.watched_indicators(), settings.date_offset()
	current_date, hide_watched = get_datetime(), is_external and settings.widget_hide_watched()
	include_airdate = settings.episodes_include_airdate()
	service_cache = {}
	date_strftime, date_use_words, date_include_date = settings.calendar_date_label_options()
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	meta = tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, tvshow_plot, orig_title = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('plot'), meta_get('original_title')
	try:
		from modules.metadata import is_anime_check
		show_is_anime = bool(is_anime_check(meta))
	except Exception: show_is_anime = False
	title, show_year, rootname, show_duration, show_status = meta_get('title'), meta_get('year') or '2050', meta_get('rootname'), meta_get('duration'), meta_get('status')
	mpaa, trailer, genre, studio, country = meta_get('mpaa'), str(meta_get('trailer')), meta_get('genre'), meta_get('studio'), meta_get('country')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	season = params['season']
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo = meta_get('clearlogo') or ''
	show_landscape = meta_get('landscape') or meta_get('fanart') or ''
	watched_db = ws.get_database(watched_indicators)
	watched_info = ws.watched_info_episode(tmdb_id, watched_db)
	if season == 'all':
		total_seasons = meta_get('total_seasons')
		episodes_data = sorted(all_episodes_meta(meta, settings.show_specials()), key=lambda x: (x['season'], x['episode']))
		bookmarks = ws.get_bookmarks_all_episode(tmdb_id, total_seasons, watched_db)
		season_poster = show_poster
		category_name = 'Season %s' % season if total_seasons == 1 else 'Seasons 1-%s' % total_seasons
	else:
		total_seasons = None
		episodes_data = episodes_meta(season, meta)
		bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
		try:
			season_data = meta_get('season_data')
			poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
			season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
		except: season_poster = show_poster
		category_name = 'Season %s' % season
	kodi_utils.add_items(handle, list(_process()))
	kodi_utils.set_sort_method(handle, 'episodes', labelMask='%L')
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, category_name)
	# word dates (TODAY / TOMORROW / weekday) go stale overnight, so such a list is not kept on disk
	kodi_utils.end_directory(handle, cacheToDisc=False if (is_external or (include_airdate and date_use_words)) else True)
	kodi_utils.set_view_mode('view.episodes', 'episodes', is_external)

def _anime_scope(is_anime_list):
	# Anime, TV-only and unfiltered lists must never share a cache entry.
	return {True: 'anime', False: 'tv'}.get(is_anime_list, 'all')

def build_single_episode(list_type, params={}):
	category_override = None
	def _get_category_name():
		if category_override: return category_override
		try:
			cat_name = {'episode.progress': 'In Progress Episodes',
						'episode.recently_watched': 'Recently Watched Episodes',
						'episode.next_trakt': 'Next Episodes', 'episode.next_nightshift': 'Next Episodes',
						'episode.next_simkl': 'Next Episodes', 'episode.next_mdblist': 'Next Episodes', 'episode.next_punchplay': 'Next Episodes',
						'episode.trakt': {'true': 'Recently Aired Episodes', None: 'Trakt Calendar'},
						'episode.mdblist': 'MDBList Calendar', 'episode.mdblist_calendar': 'MDBList Calendar',
						'episode.mdblist_next': 'MDBList Next Up',
						'episode.punchplay': 'PunchPlay Calendar', 'episode.punchplay_calendar': 'PunchPlay Calendar',
						'episode.simkl': 'Simkl Calendar', 'episode.simkl_calendar': 'Simkl Calendar',
						'episode.simkl_public': 'Public Calendar', 'episode.simkl_public_calendar': 'Public Calendar', 'episode.anilist_public': 'Public Anime Calendar', 'episode.anilist_public_calendar': 'Public Anime Calendar'}[list_type]
			if isinstance(cat_name, dict): cat_name = cat_name[params.get('recently_aired')]
		except: cat_name = 'Episodes'
		return cat_name
	def _process_anilist_only(_position, ep_data):
		"""AniList calendar row with no TMDb match: listed from AniList data (title, poster, banner, air time). Not playable."""
		try:
			get_ = ep_data.get
			title = get_('title') or 'Unknown'
			airing_at = int(get_('airing_at') or 0)
			day = airing_local_datetime(airing_at).date()
			day_label = make_day(get_datetime(), day, calendar_date_strftime, use_words=calendar_use_words, include_date=calendar_include_date)
			clock = airtime_label(airing_at)
			if clock: day_label = '%s %s' % (day_label, clock)
			ep_no = int(get_('episode') or 0)
			poster = get_('poster_url') or get_('cover_url') or ''   # MyAnimeList poster (Jikan) first, then AniList cover
			banner = get_('banner_url') or ''
			pk = {'kind': 'anilist_only', 'title': title, 'episode': ep_no, 'label': '[%s] %s  Ep %s  [no TMDb match]' % (day_label, title, ep_no),
				'first_aired': day.isoformat(), 'name': '%s - 1x%s' % (title, ep_no), 'unaired': airing_at > get_current_timestamp(),
				'sort_order': _position, 'url': build_url(params),
				'art': {'poster': poster, 'thumb': poster, 'icon': poster, 'landscape': banner or poster, 'fanart': banner or poster or fanart_empty or ''}}
			_paint_anilist_only(pk, item_list_append, make_listitem)
		except Exception as exc:
			kodi_utils.logger('AniListCalendar', 'AniList-only row not shown: %s' % exc)
	def _process(_position, ep_data):
		if ep_data.get('anilist_only'): return _process_anilist_only(_position, ep_data)
		try:
			ep_data_get = ep_data.get
			_is_anilist = ep_data_get('calendar_source') == 'anilist'
			_row_tvdb_first = False if _is_anilist else use_tvdb_first
			meta = tvshow_meta('trakt_dict', ep_data_get('media_ids'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=None if _is_anilist else is_anime_list, use_tvdb_first=_row_tvdb_first)
			if not meta: return
			meta_get = meta.get
			cm = []
			cm_append = cm.append
			listitem = make_listitem()
			set_properties = listitem.setProperties
			orig_season, orig_episode = ep_data_get('season'), ep_data_get('episode')
			unwatched = ep_data_get('unwatched', False)
			_position = ep_data_get('custom_order', _position)
			tmdb_id, tvdb_id, imdb_id, title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
			season_data = meta_get('season_data')
			watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
			if list_type_starts_with('next'):
				last_watched_season, last_watched_episode = orig_season, orig_episode
				orig_season, orig_episode = ws.get_next(orig_season, orig_episode, watched_info, season_data, nextep_content, meta)
				# Weekly anime: stale season/show cache often stops at the last watched ep until expiry.
				if (not orig_season or not orig_episode) and meta_get('status') not in ('Ended', 'Canceled'):
					try:
						from modules.metadata import refresh_airing_show_meta
						refresh_airing_show_meta(meta_get('tmdb_id'), last_watched_season)
						meta = tvshow_meta('tmdb_id', meta_get('tmdb_id'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=is_anime_list, use_tvdb_first=use_tvdb_first)
						if not meta: return
						meta_get = meta.get
						season_data = meta_get('season_data')
						watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
						orig_season, orig_episode = ws.get_next(last_watched_season, last_watched_episode, watched_info, season_data, nextep_content, meta)
					except: pass
				if not orig_season or not orig_episode: return
				if ws.get_watched_status_episode(watched_info, (orig_season, orig_episode)): return
			if _is_anilist:
				orig_season, orig_episode, episodes_data = _anilist_tmdb_episode(meta, ep_data_get('airing_at'), orig_episode)
				if not orig_season or not orig_episode or not episodes_data: return
			else:
				episodes_data = episodes_meta(orig_season, meta, use_tvdb_first=use_tvdb_first)
			if not episodes_data: return
			item = next((i for i in episodes_data if int(i.get('episode') or 0) == int(orig_episode)), None)
			# Recent-watch rows can pre-date TVDB First or originate outside NightShift and therefore carry TMDb numbering.
			# Keep the TVDB-order match when it exists; only fall back to the same TMDb S/E when it does not.
			if not item and list_type_compare == 'recently_watched' and use_tvdb_first:
				tmdb_episode_rows = episodes_meta(orig_season, meta, use_tvdb_first=False)
				tmdb_item = next((i for i in tmdb_episode_rows if i['episode'] == orig_episode), None)
				if tmdb_item:
					episodes_data, item = tmdb_episode_rows, tmdb_item
					try: kodi_utils.logger('NIGHTSHIFT', 'Recently watched episode matched with TMDb S/E fallback: tmdb=%s S%sE%s' % (meta_get('tmdb_id'), orig_season, orig_episode))
					except: pass
			if not item: return
			item_get = item.get
			season, episode, ep_name = item_get('season'), item_get('episode'), _episode_name(item)
			if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'anilist_public_calendar', 'trakt_recently_aired'):
				episode_date, premiered = _calendar_episode_date(ep_data_get('first_aired'), item_get('premiered'), adjust_hours)
				if _is_anilist and ep_data_get('airing_at'): episode_date = airing_local_datetime(ep_data_get('airing_at')).date()   # AniList: the local day of the exact airtime
			else:
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
			episode_type = item_get('episode_type') or ''
			episode_id = item_get('episode_id') or None
			if not episode_date or current_date < episode_date:
				if list_type_starts_with('next_'):
					if not episode_date: return
					if not include_unaired: return
					if not date_difference(current_date, episode_date, 7): return
				unaired = True
			else: unaired = False
			orig_title, rootname, trailer, genre = meta_get('original_title'), meta_get('rootname'), str(meta_get('trailer')), meta_get('genre')
			genre = list(genre) if isinstance(genre, (list, tuple)) else ([genre] if genre else [])
			country = meta_get('country', [])
			country = list(country) if isinstance(country, (list, tuple)) else ([country] if country else [])
			mpaa, tvshow_plot, studio, show_status = meta_get('mpaa'), meta_get('plot'), meta_get('studio'), meta_get('status')
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			if rpdb_api_key:
				try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
				except: show_poster = meta_get('poster') or poster_empty
			else: show_poster = meta_get('poster') or poster_empty
			show_fanart = meta_get('fanart') or fanart_empty
			show_clearlogo = meta_get('clearlogo') or ''
			show_landscape = meta_get('landscape') or meta_get('fanart') or ''
			try: year = premiered.split('-')[0]
			except: year = show_year or '2050'
			try:
				poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
				season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
			except: season_poster = show_poster
			str_episode_zfill2 = str(episode).zfill(2)
			if display_format == 0: title_str = '%s - ' % title
			else: title_str = ''
			if display_format in (0, 1): seas_ep = '%sx%s. ' % (str(season), str_episode_zfill2)
			else: seas_ep = ''
			if not list_type_starts_with('next_'):
				history_season, history_episode = history_episode_coordinates(item, season, episode)
				playcount = ws.get_watched_status_episode(watched_info, (history_season, history_episode))
				if playcount and hide_watched: return
			if list_type_starts_with('next_'):
				playcount = 0
				if include_airdate:
					if episode_date: display_premiered = '[%s] ' % make_day(current_date, episode_date)
					else: display_premiered = '[UNKNOWN] '
				else: display_premiered = ''
				if unwatched: highlight_start, highlight_end = '[COLOR darkgoldenrod]', '[/COLOR]'
				elif unaired: highlight_start, highlight_end = '[COLOR red]', '[/COLOR]'
				else: highlight_start, highlight_end = '', ''
				# Title mirrors settings format without BBCode (widgets/skins that bind Title).
				display_title = '%s%s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
				display = '%s%s%s%s%s%s' % (display_premiered, title_str, highlight_start, seas_ep, ep_name, highlight_end)
			elif list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'anilist_public_calendar'):
				if not episode_date:
					display_premiered = 'UNKNOWN'
				else:
					display_premiered = make_day(
						current_date, episode_date, calendar_date_strftime,
						use_words=calendar_use_words, include_date=calendar_include_date)
				if _is_anilist and ep_data_get('airing_at') and episode_date:
					display_premiered = '%s %s' % (display_premiered, airtime_label(ep_data_get('airing_at')))   # e.g. [SATURDAY 6:00 PM]
				display = display_title = '[%s] %s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
			else: display = display_title = '%s%s%s' % (title_str, seas_ep, ep_name)
			progress_aired_eps, total_unwatched = None, None
			if unwatched_info:
				try:
					progress_aired_eps = ws.progress_aired_eps(meta)
					total_unwatched = ws.get_watched_status_tvshow(ws.watched_info_tvshow(watched_db).get(str(tmdb_id), None), progress_aired_eps)[2]
				except: progress_aired_eps, total_unwatched = None, None
				if unwatched_in_title and total_unwatched and list_type_compare != 'recently_watched':
					suffix = ' (%s)' % total_unwatched
					# Calendars: show the absolute episode number (running count across seasons) instead.
					if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'anilist_public_calendar'):
						try:
							prior_eps = sum(int(i.get('episode_count') or 0) for i in (meta_get('season_data') or []) if 0 < int(i.get('season_number') or 0) < int(season))
							suffix = ' (abs #%s)' % (prior_eps + int(episode))
						except Exception: pass
					display, display_title = display + suffix, display_title + suffix
			thumb = (show_landscape or show_fanart) if (hide_thumb and not playcount) else (item_get('thumb', None) or show_landscape or show_fanart)
			plot = (tvshow_plot or '') if (hide_plot and not playcount) else (item_get('plot') or tvshow_plot)
			duration = item_get('duration')
			if not duration:
				duration = meta_get('duration')
				item['duration'] = duration
			bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
			progress = ws.get_progress_status_episode(bookmarks, episode)
			play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
									'episode_id': episode_id, playback_key: playback_key})
			extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
			options_params = build_url({'mode': 'options_menu_choice', 'content': list_type, 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external,
										'season': season, 'episode': episode, 'episode_id': episode_id})
			playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
											'episode': episode, 'episode_id': episode_id})
			cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			# Always expose AniList force-refresh on public anime calendar rows (feeds may be absent after mode rewrite).
			if list_type_compare == 'anilist_public_calendar' or (list_type_compare == 'simkl_public_calendar' and params.get('feeds') in ('anime', 'all', None, '')):
				_refresh_params = {'mode': 'force_refresh_anilist_calendar'}
				cm_append(['force_refresh_calendar', ('[B]Force Refresh AniList Calendar[/B]', 'RunPlugin(%s)' % build_url(_refresh_params))])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % \
						build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'episode': episode, 'episode_id': episode_id}))])
			settings.append_source_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'episode', tmdb_id, season, episode, playcount)
			settings.append_external_scraper_settings_cm(cm_append, build_url)
			cm_append(['browse_seasons', ('[B]Browse Seasons[/B]', window_command % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))])
			cm_append(['browse_episodes', ('[B]Browse Episodes[/B]', window_command % build_url({'mode': 'build_order_episodes', 'tmdb_id': tmdb_id, 'order_id': 'tvdb:official', 'order_name': 'Aired Order'}))])
			# List managers stay show-scoped (watchlist/library/etc). MDBList static add/remove uses season/episode when present.
			trakt_manager_params, simkl_manager_params, punchplay_manager_params, mdblist_manager_params, tmdb_manager_params = '', '', '', '', ''
			if settings.trakt_user_active():
				trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
												'title': title, 'icon': show_poster, 'season': season, 'episode': episode, 'episode_id': episode_id})
			if settings.simkl_user_active():
				simkl_params = {'mode': 'simkl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
								'title': title, 'icon': show_poster}
				if is_anime_list is True: simkl_params['simkl_media_kind'] = 'anime'
				simkl_manager_params = build_url(simkl_params)
			if settings.punchplay_user_active():
				punchplay_manager_params = build_url({'mode': 'punchplay_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster})
			if settings.mdblist_user_active():
				mdblist_manager_params = build_url({'mode': 'mdblist_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster, 'season': season, 'episode': episode, 'episode_id': episode_id})
			if settings.tmdblist_user_active():
				tmdb_manager_params = build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'tv', 'tmdb_id': tmdb_id, 'icon': show_poster})
			personal_manager_params = build_url({'mode': 'personallists_manager_choice', 'list_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title,
												'premiered': meta_get('premiered'), 'current_time': current_time, 'icon': show_poster})
			favorites_manager_params = build_url({'mode': 'favorites_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})
			if mdblist_manager_params: cm_append(['mdblist_manager', ('[B]MDBList Manager[/B]', 'RunPlugin(%s)' % mdblist_manager_params)])
			if punchplay_manager_params: cm_append(['punchplay_manager', ('[B]PunchPlay Manager[/B]', 'RunPlugin(%s)' % punchplay_manager_params)])
			if simkl_manager_params: cm_append(['simkl_manager', ('[B]Simkl Lists Manager[/B]', 'RunPlugin(%s)' % simkl_manager_params)])
			if tmdb_manager_params: cm_append(['tmdb_manager', ('[B]TMDb Lists Manager[/B]', 'RunPlugin(%s)' % tmdb_manager_params)])
			if trakt_manager_params: cm_append(['trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params)])
			settings.append_list_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'tvshow', tmdb_id, imdb_id, tvdb_id, title, show_poster)
			cm_append(['personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params)])
			cm_append(['favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % favorites_manager_params)])
			if not unaired:
				if playcount:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
												'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': ((item['tmdb_season'] if item.get('tmdb_season') is not None else season)), 'episode': ((item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode)),  'title': title}))])
				else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
											'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': ((item['tmdb_season'] if item.get('tmdb_season') is not None else season)), 'episode': ((item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode)),  'title': title}))])
				if progress:
					cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
											'season': season, 'episode': episode, 'refresh': 'true'}))])
				if unwatched_info and total_unwatched is not None and progress_aired_eps != total_unwatched:
					set_properties({'watchedepisodes': '1', 'unwatchedepisodes': str(total_unwatched)})
			if list_type_starts_with('next_') and (season, episode) != (1, 1):
				cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id,
											'season': season, 'episode': episode, 'title': title, 'refresh': 'true'}))])
			if is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
			if custom_cm_menu:
				try:
					_keep_force = [i for i in cm if i[0] == 'force_refresh_calendar']
					cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					for _fr in _keep_force:
						if not any(x[0] == 'force_refresh_calendar' for x in cm):
							cm.append(_fr)
				except: pass
			cm = [i[1] for i in cm]
			# Legacy metacache used 1-tuples for studio; setStudios requires a list.
			if isinstance(studio, tuple): studio = list(studio)
			elif not studio: studio = []
			info_tag = listitem.getVideoInfoTag()
			info_tag.setMediaType('episode'), info_tag.setOriginalTitle(orig_title), info_tag.setTitle(display_title), info_tag.setGenres(genre)
			# Optional: widgets that bind TVShowTitle as a second line under Label.
			if not (is_external and omit_tvshowtitle_widgets):
				info_tag.setTvShowTitle(title)
			info_tag.setPlaycount(playcount), info_tag.setPlot(plot or ''), info_tag.setFirstAired(premiered or '')
			# EPISODE format always omits Season/Episode tags. Optional Omit Season/Episode
			# Tags on Widgets does the same for TITLE/SxE widget formats so Label can hold
			# the full string without skins that bind Season/Episode duplicating SxE (#201).
			if display_format != 2 and not omit_season_episode_tags:
				info_tag.setSeason(season), info_tag.setEpisode(episode)
			info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id or ''), info_tag.setUniqueIDs({'imdb': imdb_id or '', 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
			info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setTvShowStatus(show_status or '')
			info_tag.setStudios(studio), info_tag.setWriters(item_get('writer')), info_tag.setDirectors(item_get('director'))
			info_tag.setYear(int(year)), info_tag.setRating(0), info_tag.setVotes(0), info_tag.setMpaa(mpaa)
			full_cast = cast + (item_get('guest_stars') or [])
			info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
			ws.clear_listitem_kodi_resume(info_tag)
			try: listitem.setContentLookup(False)
			except: pass
			if progress and not unaired:
				ws.apply_listitem_progress(info_tag, set_properties, progress, duration, is_external)
			listitem.setLabel(display)
			listitem.addContextMenuItems(cm)
			listitem.setArt(_clean_art({'poster': show_poster, 'fanart': _ep_bg(item_get('thumb', None), show_fanart, hide_thumb and not playcount, episode_picture(item, tmdb_id, (item['tmdb_season'] if item.get('tmdb_season') is not None else season), (item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode))), 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': thumb,
							'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo,
							'tvshow.landscape': show_landscape}))
			set_properties({
				'episode_type': episode_type, 'nightshift.extras_params': extras_params, 'nightshift.options_params': options_params,
				'nightshift.playback_options_params': playback_options_params,
				'nightshift.trakt_manager_params': trakt_manager_params,
				'nightshift.simkl_manager_params': simkl_manager_params,
				'nightshift.punchplay_manager_params': punchplay_manager_params,
				'nightshift.mdblist_manager_params': mdblist_manager_params,
				'nightshift.personal_manager_params': personal_manager_params,
				'nightshift.tmdb_manager_params': tmdb_manager_params,
				'nightshift.favorites_manager_params': favorites_manager_params,
				'nightshift.tmdb_id': str(tmdb_id), **_still_props(item), 'nightshift.tvdb_still': _tvdb_still(item), 'nightshift.tmdb_season': str((item['tmdb_season'] if item.get('tmdb_season') is not None else season)), 'nightshift.tmdb_episode': str((item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode))
				})
			if unaired and list_type_starts_with('next_'):
				set_properties({'nightshift.rings.unaired': 'true', 'nightshift.rings.primary': str(display_title or '')})
			_row_packet = None
			_cacheable_row = (
				list_type_starts_with('next_')
				or list_type_compare in (
					'simkl_public_calendar', 'anilist_public_calendar', 'progress', 'recently_watched',
					'trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar',
					'punchplay_calendar', 'simkl_calendar'
				)
			)
			if _cacheable_row:
				props = {
					'episode_type': episode_type, 'nightshift.extras_params': extras_params, 'nightshift.options_params': options_params,
					'nightshift.playback_options_params': playback_options_params,
					'nightshift.tmdb_id': str(tmdb_id), **_still_props(item), 'nightshift.tvdb_still': _tvdb_still(item), 'nightshift.tmdb_season': str((item['tmdb_season'] if item.get('tmdb_season') is not None else season)), 'nightshift.tmdb_episode': str((item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode)),
					'nightshift.trakt_manager_params': trakt_manager_params,
					'nightshift.simkl_manager_params': simkl_manager_params,
					'nightshift.punchplay_manager_params': punchplay_manager_params,
					'nightshift.mdblist_manager_params': mdblist_manager_params,
					'nightshift.personal_manager_params': personal_manager_params,
					'nightshift.tmdb_manager_params': tmdb_manager_params,
					'nightshift.favorites_manager_params': favorites_manager_params
				}
				if unaired and list_type_starts_with('next_'):
					props['nightshift.rings.unaired'] = 'true'
					props['nightshift.rings.primary'] = str(display_title or '')
				if progress and not unaired: props['WatchedProgress'] = progress
				if unwatched_info and total_unwatched is not None and progress_aired_eps != total_unwatched:
					props['watchedepisodes'] = '1'
					props['unwatchedepisodes'] = str(total_unwatched)
				item.setdefault('tvdb_id', tvdb_id)
				_row_packet = {
					'rw_key': _row_key(ep_data),
					'play_params': play_params, 'display': display, 'display_title': display_title, 'cm': list(cm),
					'art': {'poster': show_poster, 'fanart': _ep_bg(item_get('thumb', None), show_fanart, hide_thumb and not playcount, episode_picture(item, tmdb_id, (item['tmdb_season'] if item.get('tmdb_season') is not None else season), (item['tmdb_episode'] if item.get('tmdb_episode') is not None else episode))), 'thumb': thumb, 'icon': thumb, 'clearlogo': show_clearlogo,
							'landscape': thumb, 'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo,
							'tvshow.landscape': show_landscape},
					'properties': props,
					'omit_tvshowtitle': bool(is_external and omit_tvshowtitle_widgets),
					'omit_season_episode': bool(display_format == 2 or omit_season_episode_tags),
					'display_format': display_format,
					'orig_title': orig_title, 'genre': genre, 'tvshowtitle': title, 'playcount': playcount, 'plot': plot,
					'premiered': premiered, 'season': season, 'episode': episode, 'duration': duration,
					'imdb_id': imdb_id, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'country': country,
					'trailer': trailer, 'show_status': show_status, 'studio': studio,
					'writer': item_get('writer'), 'director': item_get('director'), 'year': int(year),
					'rating': item_get('rating'), 'votes': item_get('votes'), 'mpaa': mpaa,
					'cast': [{'name': i['name'], 'role': i['role'], 'thumbnail': i['thumbnail']} for i in full_cast],
					'resume_secs': None,
					'unaired': unaired, 'first_aired': premiered,
					'name': '%s - %sx%s' % (title, str(season), str_episode_zfill2),
					'last_played': ep_data_get('last_played', resinsert), 'sort_order': _position,
					'unwatched': ep_data_get('unwatched')
				}
			item_list_append({'list_items': (play_params, listitem, False), 'first_aired': premiered, 'name': '%s - %sx%s' % (title, str(season), str_episode_zfill2),
							'unaired': unaired, 'last_played': ep_data_get('last_played', resinsert), 'sort_order': _position, 'unwatched': ep_data_get('unwatched'),
							'row_packet': _row_packet})
		except Exception as e:
			# Silent drops blank calendars/next-ep lists; log so meta/InfoTag failures are visible.
			try: kodi_utils.logger('NIGHTSHIFT', 'build_single_episode item failed (%s): %s' % (list_type, e))
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	is_anime_list = str(params.get('is_anime_list', '')).strip().lower() in ('1', 'true', 'yes')
	# Calendars / Next Up are not anime-filtered shelves — never pass False into meta_valid_check.
	if list_type in ('episode.trakt', 'episode.mdblist', 'episode.mdblist_next', 'episode.punchplay', 'episode.simkl', 'episode.simkl_public', 'episode.anilist_public'):
		is_anime_list = None
	elif list_type == 'episode.recently_watched':
		# Keep is_anime_list from params (Anime menu passes true; TV menu leaves false/absent).
		if not is_anime_list and settings.include_anime_tvshow():
			is_anime_list = None
	elif not is_anime_list and settings.include_anime_tvshow():
		is_anime_list = None
	item_list, airing_today, unwatched, return_results = [], [], [], False
	resinsert = ''
	item_list_append = item_list.append
	window_command = 'ActivateWindow(Videos,%s,return)' if is_external else 'Container.Update(%s)'
	_nextep_ck, _nextep_token, _nextep_busy = None, None, False
	hide_thumb, hide_plot = settings.hide_episode_thumb(), settings.hide_episode_plot()
	watched_indicators = settings.watched_indicators()
	# MDBList Lists → Next Up always uses MDBList watched history (not global Watched Status Provider).
	if list_type == 'episode.mdblist_next': watched_indicators = 3
	if list_type in ('episode.trakt', 'episode.mdblist', 'episode.punchplay', 'episode.simkl', 'episode.simkl_public', 'episode.anilist_public'):
		display_format = settings.calendar_display_format(is_external)
		calendar_date_strftime, calendar_use_words, calendar_include_date = settings.calendar_date_label_options()
		calendar_date_format = None if calendar_use_words else calendar_date_strftime
	else:
		display_format = settings.single_ep_display_format(is_external)
		calendar_date_strftime, calendar_use_words, calendar_include_date = '%Y-%m-%d', True, False
		calendar_date_format = None
	current_date, current_time, adjust_hours = get_datetime(), get_current_timestamp(), settings.date_offset()
	unwatched_info = settings.single_ep_unwatched_episodes()
	unwatched_in_title = settings.single_ep_unwatched_in_title()
	omit_tvshowtitle_widgets = settings.single_ep_widget_omit_tvshowtitle()
	omit_season_episode_tags = is_external and settings.single_ep_widget_omit_season_episode()
	hide_watched = is_external and settings.widget_hide_watched() and list_type not in ('episode.recently_watched', 'episode.anilist_public', 'episode.simkl_public')
	api_key, mpaa_region_value = settings.tmdb_api_key(), settings.mpaa_region()
	cm_sort_order, ignore_articles = settings.cm_sort_order(), settings.ignore_articles()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	watched_db = ws.get_database(watched_indicators)
	if list_type in ('episode.next', 'episode.mdblist_next'):
		ws.clear_local_bookmarks()
		try: ws._purge_negligible_progress(ws.get_database(watched_indicators))
		except: pass
		mdblist_menu_next = list_type == 'episode.mdblist_next'
		include_unwatched, include_unaired, nextep_content = settings.nextep_include_unwatched(), settings.nextep_include_unaired(), settings.nextep_method()
		sort_override = settings.parse_nextep_sort_key(params.get('nextep_sort'))
		sort_key, sort_direction = 'last_played', True   # next episodes: most recent watch first (same as the watched lists)
		include_airdate = settings.nextep_include_airdate()
		if watched_indicators in (1, 2, 3, 4):
			resformat, resinsert = '%Y-%m-%dT%H:%M:%S.%fZ', '2000-01-01T00:00:00.000Z'
			list_type = {1: 'episode.next_trakt', 2: 'episode.next_simkl', 3: 'episode.next_mdblist', 4: 'episode.next_punchplay'}[watched_indicators]
		else: resformat, resinsert, list_type = '%Y-%m-%d %H:%M:%S', '2000-01-01 00:00:00', 'episode.next_nightshift'
		if mdblist_menu_next: category_override = 'MDBList Next Up'
		elif sort_override == 'last_played': category_override = 'Next Episodes (Recently Watched)'
		elif sort_override == 'first_aired': category_override = 'Next Episodes (Airdate)'
		elif sort_override == 'name': category_override = 'Next Episodes (Title)'
		list_type_compare = list_type.split('episode.')[1]
		list_type_starts_with = list_type_compare.startswith
		# Umbrella-style: reuse built rows when watched/progress/hide (+ include-unwatched) unchanged.
		try:
			from caches import nextep_cache
			_nextep_ck = nextep_cache.cache_id(watched_indicators, mdblist_menu_next, is_anime_list, is_external, sort_key)
			_nextep_token = nextep_cache.activity_token(watched_indicators)
			if include_unwatched != 0:
				_uw_extra = []
				if include_unwatched in (1, 3):
					try: _uw_extra.extend(str(i['media_ids'].get('tmdb')) for i in (_nextep_indicator_watchlist(watched_indicators) or []) if i.get('media_ids'))
					except: pass
				if include_unwatched in (2, 3):
					try:
						from caches.favorites_cache import favorites_cache
						_uw_extra.extend(str(i['tmdb_id']) for i in (favorites_cache.get_favorites('tvshow') or []))
					except: pass
				_nextep_token = '%s|uw:%s|%s' % (_nextep_token, include_unwatched, ','.join(sorted(set(_uw_extra))))
			_cached_packets = nextep_cache.get_packets(_nextep_ck, _nextep_token)
		except:
			_nextep_ck, _nextep_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in (_cached_packets[:100] if is_anime_list is True else _cached_packets):
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='nextep cache')
			kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
			kodi_utils.set_content(handle, 'episodes')
			kodi_utils.set_category(handle, _get_category_name())
			kodi_utils.end_directory(handle, cacheToDisc=False)
			kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external, fallback_view_types=('view.episodes',))
			return
		# Cold rebuild (#203): Kodi's GetDirectory busy often dies when fullscreen closes after
		# Stop; keep an explicit spinner until rows are ready (warm cache hits skip this).
		_nextep_busy = True
		try: kodi_utils.show_busy_dialog()
		except: pass
		try:
			# Right after Stop, local watched/progress is already written — blocking Simkl/Trakt/etc.
			# sync is the main wait even with one row. Skip ~30s; monitors / later opens still sync.
			_skip_provider_refresh = False
			try: _skip_provider_refresh = kodi_utils.playback_list_sync_skip_recent()
			except: pass
			# a home-screen widget never waits for the online watched-history download (it took 10-18 s right after Kodi starts): the add-on's
			# service syncs every few minutes and refreshes the widgets, so the list is at most that old
			if is_external and not _skip_provider_refresh: _skip_provider_refresh = True
			if _skip_provider_refresh:
				try: kodi_utils.logger('NIGHTSHIFT', 'Next Episodes: skip provider sync (%s)' % ('widget' if is_external else 'recent playback'))
				except: pass
			elif watched_indicators == 3 and settings.mdblist_user_active():
				try: ws._refresh_mdblist_tvshow_watched()
				except: pass
			elif watched_indicators == 1 and settings.trakt_user_active():
				try: ws._refresh_trakt_tvshow_watched()
				except: pass
			elif watched_indicators == 2 and settings.simkl_user_active():
				try: ws._refresh_simkl_tvshow_watched()
				except: pass
			elif watched_indicators == 4 and settings.punchplay_user_active():
				try: ws._refresh_punchplay_tvshow_watched()
				except: pass
			data = ws.get_next_episodes(nextep_content, watched_indicators)
			if settings.nextep_limit_history(): data = data[:settings.nextep_limit()]
			hidden_list = set(ws.get_hidden_progress_items(watched_indicators) or [])
			if hidden_list:
				data = [i for i in data if int(i['media_ids']['tmdb']) not in hidden_list]
			if include_unwatched != 0:
				if include_unwatched in (1, 3):
					try:
						watchlist = _nextep_indicator_watchlist(watched_indicators)
						unwatched.extend([{'media_ids': i['media_ids'], 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} for i in watchlist])
					except: pass
				if include_unwatched in (2, 3):
					from caches.favorites_cache import favorites_cache
					try:
						favorites = favorites_cache.get_favorites('tvshow')
						unwatched.extend([{'media_ids': {'tmdb': int(i['tmdb_id'])}, 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} \
										for i in favorites if not int(i['tmdb_id']) in [x['media_ids']['tmdb'] for x in data]])
					except: pass
				data += unwatched
		except Exception:
			try: kodi_utils.hide_busy_dialog()
			except: pass
			_nextep_busy = False
			data = []
	elif list_type == 'episode.progress':
		ws.clear_local_bookmarks()
		data = ws.get_in_progress_episodes()
	elif list_type == 'episode.recently_watched': data = ws.get_recently_watched('episode', short_list=True)
	elif list_type == 'episode.trakt':
		from apis.trakt_api import trakt_get_my_calendar
		recently_aired = params.get('recently_aired', None)
		data = trakt_get_my_calendar(recently_aired, get_datetime())
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.trakt_recently_aired' if recently_aired else 'episode.trakt_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.mdblist':
		from apis.mdblist_api import mdblist_get_my_calendar
		data = mdblist_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.mdblist_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.punchplay':
		from apis.punchplay_api import punchplay_get_my_calendar
		data = punchplay_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.punchplay_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.simkl':
		from apis.simkl_api import simkl_get_my_calendar
		data = simkl_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.simkl_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.anilist_public':
		kodi_utils.logger('AniListCalendar', 'episode.anilist_public -> AniList calendar only (no Simkl API)')
		data = _anilist_calendar_feed(force=str(params.get('force_refresh', '')).lower() == 'true')
		list_type = 'episode.anilist_public_calendar'
		category_override = 'Public Anime Calendar'
		try: data = sorted(data, key=lambda i: (i['first_aired'], i['sort_title']))
		except: pass
	elif list_type == 'episode.simkl_public':
		feeds = params.get('feeds')
		if not feeds:
			feeds = 'all' if settings.public_calendar_include_anime() else 'tv'
		force_calendar = str(params.get('force_refresh', '')).lower() == 'true'
		if feeds == 'anime':
			kodi_utils.logger('AniListCalendar', 'episode.simkl_public feeds=anime -> AniList only (no Simkl API)')
			data = _anilist_calendar_feed(force=force_calendar)
			list_type = 'episode.anilist_public_calendar'
			category_override = 'Public Anime Calendar'
		else:
			# Non-anime public TV calendar: user-selected Simkl or Trakt (with fallback).
			# Anime stays on AniList only.
			kodi_utils.logger('PublicTVCalendar', 'episode.simkl_public feeds=%s preferred=%s' % (feeds, settings.public_tv_calendar_source()))
			data = _public_tv_calendar_feed()
			if feeds == 'all':
				kodi_utils.logger('PublicTVCalendar', 'feeds=all -> appending AniList anime calendar')
				data.extend(_anilist_calendar_feed(force=force_calendar))
			list_type = 'episode.simkl_public_calendar'
			if feeds == 'tv': category_override = 'Public TV Calendar'
			else: category_override = 'Public Calendar' 
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	else: data, return_results = sorted(params, key=lambda i: i['custom_order']), True
	list_type_compare = list_type.split('episode.')[1]
	list_type_starts_with = list_type_compare.startswith
	use_tvdb_first = list_type_compare != 'simkl_public_calendar'
	_pubcal_ck, _pubcal_token = None, None
	_progress_ck, _progress_token = None, None
	_recent_ck, _recent_token = None, None
	_pcal_ck, _pcal_token = None, None

	def _finish_cached_directory(use_calendar_sort=False):
		kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
		kodi_utils.set_content(handle, 'episodes')
		kodi_utils.set_category(handle, _get_category_name())
		if use_calendar_sort:
			kodi_utils.set_sort_method(handle, 'none', labelMask='%L')
		kodi_utils.end_directory(handle, cacheToDisc=False)
		kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external, fallback_view_types=('view.episodes',))

	# In Progress: refresh already ran in get_in_progress_episodes — then token-check.
	if list_type_compare == 'progress':
		try:
			from caches import progress_episodes_cache
			_progress_ck = progress_episodes_cache.cache_id(watched_indicators, is_external, _anime_scope(is_anime_list))
			_progress_token = progress_episodes_cache.activity_token(watched_indicators, data)
			_cached_packets = progress_episodes_cache.get_packets(_progress_ck, _progress_token)
		except:
			_progress_ck, _progress_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in (_cached_packets[:100] if is_anime_list is True else _cached_packets):
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='progress episodes cache')
			_finish_cached_directory()
			return

	# Recently Watched: data already fetched (MDBList/PunchPlay refresh inside get_recently_watched).
	if list_type_compare == 'recently_watched':
		try:
			from caches import recent_watched_cache
			_recent_ck = recent_watched_cache.cache_id(watched_indicators, is_external, short_list=True, anime_scope=_anime_scope(is_anime_list))
			_recent_token = recent_watched_cache.activity_token(watched_indicators, data)
			_cached_packets = recent_watched_cache.get_packets(_recent_ck, _recent_token)
		except:
			_recent_ck, _recent_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in (_cached_packets[:100] if is_anime_list is True else _cached_packets):
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='recent watched cache')
			_finish_cached_directory()
			return

	# Personal calendars: feed already fetched — then token-check (day in fingerprint).
	if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar'):
		try:
			from caches import personal_calendar_cache
			_pcal_ck = personal_calendar_cache.cache_id(list_type_compare, is_external)
			_pcal_token = personal_calendar_cache.activity_token(data, watched_indicators)
			_cached_packets = personal_calendar_cache.get_packets(_pcal_ck, _pcal_token)
		except:
			_pcal_ck, _pcal_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in (_cached_packets[:100] if is_anime_list is True else _cached_packets):
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='personal calendar cache')
			_finish_cached_directory(use_calendar_sort=True)
			return

	if list_type_compare in ('simkl_public_calendar', 'anilist_public_calendar') and settings.public_calendar_cache_list():
		try:
			from caches import public_calendar_cache
			_pubcal_feeds = params.get('feeds') or ('anime' if list_type_compare == 'anilist_public_calendar' else 'all')
			_pubcal_ck = public_calendar_cache.cache_id(_pubcal_feeds, is_external)
			_pubcal_token = public_calendar_cache.activity_token(data, watched_indicators)
			_cached_packets = public_calendar_cache.get_packets(_pubcal_ck, _pubcal_token)
		except:
			_pubcal_ck, _pubcal_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in (_cached_packets[:100] if is_anime_list is True else _cached_packets):
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='public calendar cache')
			_finish_cached_directory(use_calendar_sort=True)
			return
	try:
		process_data = data
		# Next Episodes incremental: token miss but stale packets exist — rebuild dirty shows only.
		if list_type_starts_with('next_') and _nextep_ck:
			try:
				from caches import nextep_cache
				_stale = nextep_cache.get_stale_payload(_nextep_ck)
				if _stale:
					_stale_packets = _stale.get('packets') or []
					_stale_activity = _stale.get('show_activity') or {}
					_cur_activity = nextep_cache.show_activity(watched_indicators)
					_stale_by_tmdb = {}
					for _p in _stale_packets:
						try: _stale_by_tmdb[str(_p['tmdb_id'])] = _p
						except: pass
					dirty_data, clean_ok = [], True
					for _item in data:
						try: _tmdb = str(_item['media_ids']['tmdb'])
						except:
							dirty_data.append(_item)
							continue
						_stale_p = _stale_by_tmdb.get(_tmdb)
						if not _stale_p or _stale_activity.get(_tmdb) != _cur_activity.get(_tmdb):
							dirty_data.append(_item)
						else:
							try:
								_paint_episode_list_packet(
									_stale_p, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
									live_progress=True, log_label='nextep incremental')
							except:
								clean_ok = False
								break
					if clean_ok:
						process_data = dirty_data
					else:
						del item_list[:]
						process_data = data
			except:
				del item_list[:]
				process_data = data
		_rw_plan = None
		if list_type_compare == 'recently_watched' and _recent_ck and not return_results:
			try:
				from caches import recent_watched_cache as _rwc
				_rw_plan = _rwc.plan_incremental(_recent_ck, data)
			except Exception:
				_rw_plan = None
			if _rw_plan:
				process_data = _rw_plan['dirty']
				del item_list[:]
		if process_data:
			threads = TaskPool().tasks_enumerate(_process, process_data, min(len(process_data), settings.max_threads()))
			[i.join() for i in threads]
		if _rw_plan:
			try:
				_merge_recent_plan(_rw_plan, item_list, item_list_append, make_listitem, kodi_actor, watched_db, is_external)
			except Exception:
				del item_list[:]
				threads = TaskPool().tasks_enumerate(_process, data, min(len(data), settings.max_threads()))
				[i.join() for i in threads]
		if return_results: return [(i['list_items'], i['sort_order']) for i in item_list]
		if list_type_starts_with('next_'):
			def func(function):
				if sort_key == 'name': return title_key(function, ignore_articles)
				elif sort_key == 'last_played': return jsondate_to_datetime(function, resformat)
				else: return function
			if settings.nextep_airing_today():
				airing_today = sorted([i for i in item_list if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0)],
										key=lambda i: func(i[sort_key]), reverse=sort_direction)
				item_list = [i for i in item_list if not i in airing_today]
			else: airing_today = []
			if sort_key == 'last_played':
				unwatched = sorted([i for i in item_list if i['unwatched']], key=lambda i: title_key(i['name'], ignore_articles))
				item_list = sorted([i for i in item_list if not i['unwatched']], key=lambda i: func(i[sort_key]), reverse=sort_direction) + unwatched
			else: item_list = sorted(item_list, key=lambda i: func(i[sort_key]), reverse=sort_direction)
			item_list = airing_today + item_list
		else:
			item_list.sort(key=lambda i: i['sort_order'])
			if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'anilist_public_calendar'):
				if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'anilist_public_calendar'): reverse = settings.calendar_sort_order() == 0
				else: reverse = True
				# Strict day order (e.g. -14 ... +14, or reversed). first_aired is "premiered", already the service
				# calendar day (YYYY-MM-DD); the show title keeps rows of one day stable. No "today first" hoisting,
				# which is what mixed the dates up.
				def _day_key(i):
					d = str(i.get('first_aired') or '').split('T')[0][:10]
					return d if len(d) == 10 and d[:4].isdigit() else ('0000-00-00' if not reverse else '9999-99-99')
				item_list = sorted(item_list, key=lambda i: str(i.get('name') or '').lower())
				item_list = sorted(item_list, key=_day_key, reverse=reverse)
		# Anime history/progress/next episode menus display up to 100 valid rows. Apply after metadata filtering and sorting.
		if is_anime_list is True: item_list = item_list[:100]
		_row_packets = [i['row_packet'] for i in item_list if i.get('row_packet')]
		if list_type_starts_with('next_') and _nextep_ck:
			try:
				from caches import nextep_cache
				_nextep_token = nextep_cache.activity_token(watched_indicators)
				if include_unwatched != 0:
					_uw_extra = []
					if include_unwatched in (1, 3):
						try: _uw_extra.extend(str(i['media_ids'].get('tmdb')) for i in (_nextep_indicator_watchlist(watched_indicators) or []) if i.get('media_ids'))
						except: pass
					if include_unwatched in (2, 3):
						try:
							from caches.favorites_cache import favorites_cache
							_uw_extra.extend(str(i['tmdb_id']) for i in (favorites_cache.get_favorites('tvshow') or []))
						except: pass
					_nextep_token = '%s|uw:%s|%s' % (_nextep_token, include_unwatched, ','.join(sorted(set(_uw_extra))))
				if _row_packets:
					nextep_cache.set_packets(
						_nextep_ck, _nextep_token, _row_packets,
						show_activity_map=nextep_cache.show_activity(watched_indicators))
			except: pass
		if list_type_compare in ('simkl_public_calendar', 'anilist_public_calendar') and _pubcal_ck:
			try:
				from caches import public_calendar_cache
				if _row_packets: public_calendar_cache.set_packets(_pubcal_ck, _pubcal_token, _row_packets)
			except: pass
		if list_type_compare == 'progress' and _progress_ck:
			try:
				from caches import progress_episodes_cache
				if _row_packets: progress_episodes_cache.set_packets(_progress_ck, _progress_token, _row_packets)
			except: pass
		if list_type_compare == 'recently_watched' and _recent_ck:
			try:
				from caches import recent_watched_cache
				if _row_packets: recent_watched_cache.set_packets(_recent_ck, _recent_token, _row_packets)
			except: pass
		if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar') and _pcal_ck:
			try:
				from caches import personal_calendar_cache
				if _row_packets: personal_calendar_cache.set_packets(_pcal_ck, _pcal_token, _row_packets)
			except: pass
		kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
		kodi_utils.set_content(handle, 'episodes')
		kodi_utils.set_category(handle, _get_category_name())
		# Keep plugin order for calendars — Kodi "Sort by Date" was reordering vs day labels.
		if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'anilist_public_calendar', 'trakt_recently_aired'):
			kodi_utils.set_sort_method(handle, 'none', labelMask='%L')
		kodi_utils.end_directory(handle, cacheToDisc=False)
		kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external, fallback_view_types=('view.episodes',))
	finally:
		if _nextep_busy:
			try: kodi_utils.hide_busy_dialog()
			except: pass
