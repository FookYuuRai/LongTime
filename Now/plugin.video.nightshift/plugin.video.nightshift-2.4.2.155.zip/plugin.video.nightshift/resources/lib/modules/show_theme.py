# -*- coding: utf-8 -*-
"""Theme songs for TV and anime shows.

* A theme plays (and loops) while a show's season list, episode list or extras screen is open, and stops when the
  user leaves for another show, any screen that is not tied to a TMDb show, or when a video starts.
* Themes that have to be downloaded automatically are kept in <addon data>/show_audio_themes and removed after 5 days.
* The user can choose the theme by hand, for the whole show or for one season:
    - one file from the folder set in the skin settings ("Theme Songs Folder"),
    - one or more themes from the online sources (AnimeThemes, Plex, ThemerrDB) that are saved in
      <addon data>/show_theme_picks, which purges never touch,
    - no theme at all,
  and more than one theme in a rule plays in a random cycle.
* Choices are stored per show: {tmdb id: {"show": [items], "seasons": {"2": [items]}}}, where an item is
  {"path": ..., "name": ...}. A season rule wins over the show rule. An empty list means "no theme".
  The user's own files are never deleted by any purge.
"""
import json
import os
import secrets
import re
import sys
import threading
import time
from urllib.parse import parse_qsl, urlparse

import requests
import xbmc
import xbmcgui
import xbmcvfs

from modules import kodi_utils
from modules import android_mediastore

THEME_FOLDER = 'show_audio_themes'
PICKS_FOLDER = 'show_theme_picks'
KEEP_SECONDS = 5 * 24 * 3600
PURGE_EVERY = 6 * 3600
HANDOFF_STALE_SECONDS = 120     # a handoff marker that stays set this long without a live search holds the theme no more
LIVE_LOCKS = ('nightshift.sources_busy', 'nightshift.resolve_busy')
NATURAL_END_HOLD_SECONDS = 90   # the natural-end flag of a video that was followed by no next episode holds the theme this long at most
OVERRIDES_FILE = 'show_theme_overrides.json'
SKIN_FOLDER_STRING = 'theme_songs_folder'
SKIN_OFF_SETTING = 'theme_songs_off'
EXTRAS_PROPERTY = 'nightshift.theme.extras_tmdb'
PLAYING_PROPERTY = 'nightshift.theme.playing'
PLAYING_FILE_PROPERTY = 'nightshift.theme.playing.file'
WANTED_PROPERTY = 'nightshift.theme.wanted'   # set while a TMDb browse section owns the menu audio slot
AMBIENCE_FILE_PROPERTY = 'nightshift.ambience.playing.file'
AUDIO = ('.mp3', '.m4a', '.flac', '.ogg', '.oga', '.opus', '.wav', '.aac', '.wma')
LIST_MODES = ('build_season_list', 'build_episode_list')
VIDEO_NAV_WINDOW_ID = 10025  # Kodi WINDOW_VIDEO_NAV (the active plugin-container browsing window)
PLEX_URL = 'http://tvthemes.plexapp.com/%s.mp3'
ANIMETHEMES_URL = 'https://api.animethemes.moe/anime'
THEMERRDB_URL = 'https://app.lizardbyte.dev/ThemerrDB/tv_shows/themoviedb/%s.json'
YT_DLP_ZIP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'vendor', 'yt_dlp.zip')
MAX_THEME_BYTES = 30 * 1024 * 1024
CACHED_EXTENSIONS = ('.mp3', '.ogg', '.m4a', '.webm', '.opus')
TIMEOUT = 12
ANISONGDB_URL = 'https://anisongdb.com/api/mal_ids_request'
ANISONGDB_MEDIA = 'https://naedist.animemusicquiz.com/'   # AnisongDB gives the audio / video as file names on this host
BROWSE_STABLE_SECONDS = 2.0  # require the same Kodi-RPC TMDb browsing context on consecutive polls before starting audio
SERVICE_POLL_SECONDS = 1.0
_HEADERS = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) NIGHTSHIFT/Kodi', 'Accept': '*/*'}
MIN_AUDIO_BYTES = 4096
RETRY_AFTER = 600          # seconds before a download that failed on the network is tried again
LIVE_CHECK_EVERY = 600     # seconds between live checks for new themes of a show that already has saved themes
SHOW_SCOPE = 'show'


def log(msg, level=xbmc.LOGINFO):
	xbmc.log('[NIGHTSHIFT] show theme: %s' % msg, level)


# ---------------------------------------------------------------------------------------------------------------
# folders
# ---------------------------------------------------------------------------------------------------------------
def _join(folder, name):
	return os.path.join(folder, name)


def _profile():
	return kodi_utils.addon_profile() or xbmcvfs.translatePath('special://profile/addon_data/plugin.video.nightshift/')


def _ensure(folder):
	if not xbmcvfs.exists(folder):
		xbmcvfs.mkdirs(folder)
	return folder


def cache_dir():
	return _ensure(_join(_profile(), THEME_FOLDER))


def picks_dir():
	"""Themes the user picked from the online sources. Purges never touch this folder."""
	return _ensure(_join(_profile(), PICKS_FOLDER))


def _in_user_folder(path):
	"""True for anything inside the user's Theme Songs folder: those files are never deleted by any purge."""
	folder = user_folder()
	if not folder:
		return False
	try:
		root = os.path.normpath(folder).rstrip(os.sep) + os.sep
		return (os.path.normpath(path) + os.sep).startswith(root)
	except Exception:
		return False


def purge(now=None):
	"""Remove downloaded themes (and 'no theme' markers) that are older than 5 days. The user's own folder is never touched."""
	now = now or time.time()
	removed = 0
	try:
		folder = cache_dir()
		_dirs, files = xbmcvfs.listdir(folder)
		for name in files:
			path = _join(folder, name)
			try:
				age = now - os.path.getmtime(path)
			except OSError:
				continue
			if age > KEEP_SECONDS and not _in_user_folder(path):
				xbmcvfs.delete(path)
				removed += 1
	except Exception as error:
		log('purge failed: %s' % error, xbmc.LOGWARNING)
	if removed:
		log('removed %d theme file(s) older than 5 days' % removed)
	return removed


def _folder_setting():
	return (xbmc.getInfoLabel('Skin.String(%s)' % SKIN_FOLDER_STRING) or '').strip()


def user_folder():
	"""The folder chosen in the skin settings, or ''. A folder Kodi cannot test with exists() (some network / Android paths) is still used:
	whether it can be read is decided when it is listed."""
	value = _folder_setting()
	if not value:
		return ''
	if xbmcvfs.exists(value) or xbmcvfs.exists(value.rstrip('/\\') + '/'):
		return value
	try:
		xbmcvfs.listdir(value)
		return value
	except Exception:
		pass
	try:
		media = android_mediastore.listdir(value)
		if media is not None:
			return value
	except Exception:
		pass
	return ''


_ANDROID_ROOTS = ('/storage/emulated/0', '/sdcard', '/storage/self/primary', '/mnt/sdcard', '/mnt/shell/emulated/0')


def _path_aliases(where):
	"""The same Android folder under its other well-known names (/storage/emulated/0 = /sdcard = /storage/self/primary): the
	storage layer can refuse one spelling and serve another."""
	out = [where]
	for root in _ANDROID_ROOTS:
		if where == root or where.startswith(root + '/'):
			out += [r + where[len(root):] for r in _ANDROID_ROOTS if r != root]
			break
	return out


def _list_folder(where):
	"""Merge Kodi VFS, OS paths and Android MediaStore for a local audio folder."""
	all_dirs, all_files = set(), set()
	for alias in _path_aliases(where):
		for candidate in (alias, alias.rstrip('/\\') + '/'):
			try:
				dirs, files = xbmcvfs.listdir(candidate)
				all_dirs.update(str(n) for n in dirs)
				all_files.update(str(n) for n in files)
			except Exception:
				pass
		try:
			names = os.listdir(alias)
			all_dirs.update(n for n in names if os.path.isdir(os.path.join(alias, n)))
			all_files.update(n for n in names if os.path.isfile(os.path.join(alias, n)))
		except Exception:
			pass
		try:
			media = android_mediastore.listdir(alias)
			if media is not None:
				all_dirs.update(media[0])
				all_files.update(media[1])
		except Exception:
			pass
	return sorted(all_dirs, key=str.casefold), sorted(all_files, key=str.casefold)


def folder_diagnostics(where):
	"""One log line saying what Kodi and the operating system each see in a folder, so a 'no files' report shows which layer refuses."""
	parts = []
	for alias in _path_aliases(where)[:3]:
		try: kodi_exists = bool(xbmcvfs.exists(alias.rstrip('/\\') + '/'))
		except Exception: kodi_exists = 'error'
		try:
			_d, _f = xbmcvfs.listdir(alias)
			kodi_count = len(_d) + len(_f)
		except Exception as e: kodi_count = type(e).__name__
		try: os_dir, os_read = os.path.isdir(alias), os.access(alias, os.R_OK)
		except Exception: os_dir = os_read = 'error'
		try: os_count = len(os.listdir(alias))
		except Exception as e: os_count = type(e).__name__
		try:
			media = android_mediastore.listdir(alias)
			media_count = 'unavailable' if media is None else len(media[0]) + len(media[1])
		except Exception as e:
			media_count = type(e).__name__
		parts.append('%s -> kodi exists=%s entries=%s | os isdir=%s readable=%s entries=%s | MediaStore entries=%s' % (alias, kodi_exists, kodi_count, os_dir, os_read, os_count, media_count))
	return ' ;; '.join(parts)


OWN_FOLDER = 'theme_songs'


def own_folder():
	"""A theme folder inside the add-on's own data folder. Android always lets Kodi read it (no storage permission needed):
	copy music files there when the chosen Download / Music folder cannot be read."""
	try:
		return _ensure(_join(_profile(), OWN_FOLDER))
	except Exception:
		return ''


def user_themes():
	"""[(name, path)] of the audio files (mp3 m4a ogg opus flac wav aac wma) in the Theme Songs Folder of the skin settings,
	the folders inside it, and the add-on's own theme_songs folder."""
	folder = user_folder() or _folder_setting()
	found, seen = [], set()
	roots = [r for r in (folder, own_folder()) if r]
	if not folder:
		log('theme folder: no Theme Songs Folder is set in the skin settings')

	def _scan(where, depth):
		dirs, files = _list_folder(where)
		for name in files:
			path = _join(where, name)
			if name.lower().endswith(AUDIO) and path not in seen:
				seen.add(path)
				found.append((os.path.splitext(name)[0], path))
		if depth < 2:
			for name in dirs:
				_scan(_join(where, name), depth + 1)
	for root in roots:
		before = len(found)
		_scan(root, 0)
		log('theme folder %s: %d audio file(s) found' % (root, len(found) - before))
		if root == folder and len(found) == before:
			log('theme folder check: ' + folder_diagnostics(root))
			log('theme folder %s lists no audio files. MediaStore did not return indexed audio for this path; check that Android has indexed the MP3 and that Kodi has media-audio permission. The add-on data folder remains available without shared-storage permission: %s' % (root, own_folder()))
	return sorted(found, key=lambda x: x[0].lower())


def themes_enabled():
	return not xbmc.getCondVisibility('Skin.HasSetting(%s)' % SKIN_OFF_SETTING)


# ---------------------------------------------------------------------------------------------------------------
# the user's own choices per show and season
# ---------------------------------------------------------------------------------------------------------------
def _overrides_path():
	return _join(_profile(), OVERRIDES_FILE)


_overrides_cache = {'stamp': None, 'data': {}}


def _name_of(path):
	return os.path.splitext(os.path.basename(path or ''))[0] or 'Theme'


def _clean_items(value):
	"""A stored rule as a list of {'path', 'name'}. Accepts the older format (one path, or '' for no theme) too."""
	if isinstance(value, str):
		return [{'path': value, 'name': _name_of(value)}] if value else []
	if isinstance(value, list):
		items = []
		for item in value:
			if isinstance(item, dict) and item.get('path'):
				items.append({'path': item['path'], 'name': item.get('name') or _name_of(item['path'])})
		return items
	return []


def _normalize(entry):
	if isinstance(entry, str):
		return {SHOW_SCOPE: _clean_items(entry)}
	if not isinstance(entry, dict):
		return {}
	out = {}
	if SHOW_SCOPE in entry:
		out[SHOW_SCOPE] = _clean_items(entry[SHOW_SCOPE])
	seasons = {str(k): _clean_items(v) for k, v in (entry.get('seasons') or {}).items() if str(k).isdigit()}
	if seasons:
		out['seasons'] = seasons
	return out


def load_overrides():
	"""{tmdb id: normalized entry}. Read again only when the file changed (a list of 100 episodes asks once per item)."""
	path = _overrides_path()
	try:
		stamp = os.path.getmtime(path)
	except OSError:
		return {}
	if _overrides_cache['stamp'] == stamp:
		return dict(_overrides_cache['data'])
	try:
		with open(path, encoding='utf-8') as handle:
			data = json.load(handle)
		data = data if isinstance(data, dict) else {}
	except Exception:
		data = {}
	data = {str(k): _normalize(v) for k, v in data.items()}
	data = {k: v for k, v in data.items() if v}
	_overrides_cache['stamp'], _overrides_cache['data'] = stamp, data
	return dict(data)


def has_pick(tmdb_id):
	"""True when the user chose a theme (or 'none') for this show by hand, for the whole show or a season."""
	return str(tmdb_id) in load_overrides()


def save_overrides(data):
	try:
		with open(_overrides_path(), 'w', encoding='utf-8') as handle:
			json.dump(data, handle, indent=1, ensure_ascii=False)
		_overrides_cache['stamp'] = None      # file times have one-second resolution: the next read must come from the file
		return True
	except Exception as error:
		log('could not save the theme choices: %s' % error, xbmc.LOGWARNING)
		return False


def _existing(items):
	return [i for i in items if xbmcvfs.exists(i['path'])]


def rule_for(tmdb_id, season=''):
	"""The rule that applies: the season's rule if there is one, else the show's rule, else None (default theme).
	A list of {'path', 'name'}: empty means 'no theme song'. Files that were removed are left out; if none is left, the
	rule is ignored (back to the default theme)."""
	entry = load_overrides().get(str(tmdb_id))
	if not entry:
		return None
	season = str(season or '')
	if season and season in (entry.get('seasons') or {}):
		items = entry['seasons'][season]
	elif SHOW_SCOPE in entry:
		items = entry[SHOW_SCOPE]
	else:
		return None
	if not items:
		return []
	alive = _existing(items)
	return alive or None


def season_rule_exists(tmdb_id, season):
	entry = load_overrides().get(str(tmdb_id)) or {}
	return str(season) in (entry.get('seasons') or {})


def describe(tmdb_id, season=''):
	"""Short text for the chooser and the extras button: what plays for this show (or season)."""
	items = rule_for(tmdb_id, season)
	scope = ''
	if season and season_rule_exists(tmdb_id, season):
		scope = ' (season %s)' % season
	if items is None:
		return 'Default theme'
	if not items:
		return 'No theme song%s' % scope
	if len(items) == 1:
		return '%s%s' % (items[0]['name'], scope)
	return 'Random cycle of %d themes%s' % (len(items), scope)


def _set_rule(tmdb_id, scope, items):
	"""Store a rule. items None removes it (back to the default at that scope); [] is 'no theme song'."""
	data = load_overrides()
	entry = dict(data.get(str(tmdb_id), {}))
	if scope == SHOW_SCOPE:
		if items is None:
			entry.pop(SHOW_SCOPE, None)
		else:
			entry[SHOW_SCOPE] = items
	else:
		seasons = dict(entry.get('seasons') or {})
		if items is None:
			seasons.pop(str(scope), None)
		else:
			seasons[str(scope)] = items
		if seasons:
			entry['seasons'] = seasons
		else:
			entry.pop('seasons', None)
	if entry:
		data[str(tmdb_id)] = entry
	else:
		data.pop(str(tmdb_id), None)
	save_overrides(data)
	_announce_change()


def _announce_change():
	kodi_utils.set_property('nightshift.theme.changed', str(time.time()))   # the service restarts the theme at once


def _valid_season(season):
	season = str(season or '').strip()
	return season if season.isdigit() else ''


def override_dialog(params):
	"""Context menu / extras: choose the theme song for this show, or for one season of it."""
	tmdb_id = str(params.get('tmdb_id') or '')
	if not tmdb_id:
		return
	season = _valid_season(params.get('season'))
	dialog = xbmcgui.Dialog()

	scope = SHOW_SCOPE
	if season:
		picked = dialog.select('Theme song: which part of the show?', ['[B]Whole show[/B]', 'Season %s only' % season])
		if picked < 0:
			return
		scope = SHOW_SCOPE if picked == 0 else season

	heading = 'Theme song: %s' % describe(tmdb_id, '' if scope == SHOW_SCOPE else scope)
	labels = ['Use the default theme (downloaded)', 'No theme song',
			'Pick from my Theme Songs folder (one or more)', 'Browse online themes (AnisongDB, AnimeThemes, Plex, ThemerrDB)']
	picked = dialog.select(heading, labels)
	if picked < 0:
		return

	if picked == 0:
		_set_rule(tmdb_id, scope, None)
		dialog.notification('Theme song', 'Default theme restored', xbmcgui.NOTIFICATION_INFO, 2000, False)
		return
	if picked == 1:
		_set_rule(tmdb_id, scope, [])
		dialog.notification('Theme song', 'No theme song', xbmcgui.NOTIFICATION_INFO, 2000, False)
		return

	items = _pick_from_folder(dialog) if picked == 2 else _pick_online(dialog, tmdb_id)
	if not items:
		return
	_set_rule(tmdb_id, scope, items)
	summary = describe(tmdb_id, '' if scope == SHOW_SCOPE else scope)
	dialog.notification('Theme song', 'Saved: %s' % summary, xbmcgui.NOTIFICATION_INFO, 2500, False)


def _pick_from_folder(dialog):
	themes = user_themes()
	if not themes:
		dialog.ok('Theme song', 'No theme songs found in [%s].\n\nChoose a folder with music files (mp3, m4a, ogg, opus, flac, wav) under Skin Settings > Theme Songs Folder, then try again.\n\nOn Android, Kodi can only read a folder under Music, or the add-on folder: %s' % (_folder_setting() or 'no folder set', own_folder()))
		return None
	chosen = dialog.multiselect('Theme songs in your folder (one or more)', [name for name, _path in themes])
	if not chosen:
		return None
	return [{'path': themes[i][1], 'name': themes[i][0]} for i in chosen]


def _pick_online(dialog, tmdb_id):
	kodi_utils.show_busy_dialog()
	try:
		candidates = _online_candidates(tmdb_id)
	finally:
		kodi_utils.hide_busy_dialog()
	if not candidates:
		dialog.ok('Theme song', 'No online themes were found for this show (AnisongDB, AnimeThemes, Plex, ThemerrDB).\n\nThe reason of each source is in the Kodi log (NIGHTSHIFT show theme).')
		return None
	chosen = dialog.multiselect('Themes found online (one or more)', [c['label'] for c in candidates])
	if not chosen:
		return None
	items, failed = [], []
	kodi_utils.show_busy_dialog()
	try:
		folder = picks_dir()
		for i in chosen:
			candidate = candidates[i]
			path = candidate['load'](folder, _safe_stem('%s %s' % (tmdb_id, candidate['label'])))
			if path:
				items.append({'path': path, 'name': candidate['label']})
			else:
				failed.append(candidate['label'])
	finally:
		kodi_utils.hide_busy_dialog()
	if failed:
		dialog.notification('Theme song', 'Could not get %d theme(s)' % len(failed), xbmcgui.NOTIFICATION_WARNING, 3000, False)
	return items or None


def _safe_stem(text):
	return re.sub(r'[^A-Za-z0-9._-]+', '_', text).strip('_')[:90] or 'theme'


def clear_pick(params):
	"""Context menu: forget every choice made for this show (whole show and its seasons)."""
	tmdb_id = str(params.get('tmdb_id') or '')
	data = load_overrides()
	if tmdb_id and tmdb_id in data:
		data.pop(tmdb_id)
		save_overrides(data)
		_announce_change()
		xbmcgui.Dialog().notification('Theme song', 'Your choices were cleared for this show', xbmcgui.NOTIFICATION_INFO, 2500, False)
	else:
		xbmcgui.Dialog().notification('Theme song', 'No chosen theme for this show', xbmcgui.NOTIFICATION_INFO, 2500, False)


def clear_all_picks(params=None):
	"""Maintenance: forget every hand-picked theme. The files in the user's folder stay where they are."""
	data = load_overrides()
	if not data:
		xbmcgui.Dialog().notification('Theme songs', 'No chosen themes to clear', xbmcgui.NOTIFICATION_INFO, 2500, False)
		return
	if not xbmcgui.Dialog().yesno('Clear chosen theme songs', 'Forget the theme songs you picked for %d show(s)?\nYour music files are not touched.' % len(data)):
		return
	save_overrides({})
	_announce_change()
	xbmcgui.Dialog().notification('Theme songs', 'Cleared %d chosen theme(s)' % len(data), xbmcgui.NOTIFICATION_INFO, 2500, False)


def purge_all(params=None):
	"""Maintenance: delete every downloaded and picked theme and forget every chosen one."""
	if not xbmcgui.Dialog().yesno('Purge all theme songs', 'Delete all downloaded and picked theme songs and forget every theme you chose?\nThe music files in your Theme Songs folder are never deleted.'):
		return
	removed = 0
	for folder in (cache_dir(), picks_dir()):
		try:
			_dirs, files = xbmcvfs.listdir(folder)
			for name in files:
				path = _join(folder, name)
				if not _in_user_folder(path) and xbmcvfs.delete(path):
					removed += 1
		except Exception as error:
			log('purge all failed: %s' % error, xbmc.LOGWARNING)
	picks = len(load_overrides())
	save_overrides({})
	_failed_at.clear()
	_announce_change()
	xbmcgui.Dialog().notification('Theme songs', 'Removed %d file(s) and %d chosen theme(s)' % (removed, picks), xbmcgui.NOTIFICATION_INFO, 3000, False)


# ---------------------------------------------------------------------------------------------------------------
# downloading
# ---------------------------------------------------------------------------------------------------------------
_failed_at = {}
_checked_at = {}


def _cached_file(tmdb_id):
	folder = cache_dir()
	for ext in CACHED_EXTENSIONS:
		path = _join(folder, '%s%s' % (tmdb_id, ext))
		if xbmcvfs.exists(path):
			return path
	return ''


def _cached_files(tmdb_id):
	"""Every theme saved for a show by download(): <id>.<ext> (one source) or <id>_NN.<ext> (one per AnimeThemes theme)."""
	folder = cache_dir()
	try:
		_dirs, names = xbmcvfs.listdir(folder)
	except Exception:
		return []
	pattern = re.compile(r'^%s(_.+)?$' % re.escape(str(tmdb_id)))
	named, fallback = [], []
	for name in sorted(names):
		stem, ext = os.path.splitext(name)
		if ext.lower() in CACHED_EXTENSIONS and pattern.match(stem):
			# '<id>.mp3' is the fallback source (Plex / ThemerrDB): it plays only when no named theme is saved
			(fallback if stem == str(tmdb_id) else named).append(_join(folder, name))
	return named or fallback


def _saved_path(folder, stem):
	for ext in CACHED_EXTENSIONS:
		path = _join(folder, '%s%s' % (stem, ext))
		if xbmcvfs.exists(path):
			return path
	return ''


def _entry_stem(tmdb_id, label, seen):
	"""A file name made from the theme's own label, so a new theme never takes the name of a saved one."""
	base = '%s_%s' % (tmdb_id, _safe_stem(label))
	count = seen.get(base, 0)
	seen[base] = count + 1
	return base if count == 0 else '%s_%d' % (base, count + 1)


def _save_entries(tmdb_id, entries):
	"""Save every (label, link[, video]) theme once. A theme already saved is kept and not fetched again. Returns all their paths."""
	folder = cache_dir()
	seen, paths = {}, []
	if any(str(e[0]).startswith(('OP', 'ED', 'IN')) for e in entries):
		try:      # themes saved earlier under the generic 'SONG' label are replaced by the properly named ones
			for name in xbmcvfs.listdir(folder)[1]:
				if name.startswith('%s_SONG_' % tmdb_id): xbmcvfs.delete(_join(folder, name))
		except Exception:
			pass
	for entry in entries:
		label, link = entry[0], entry[1]
		video = entry[2] if len(entry) > 2 else ''
		stem = _entry_stem(tmdb_id, label, seen)
		path = _saved_path(folder, stem) or _fetch_to(folder, stem, link, _audio_ext(link), video)
		if path: paths.append(path)
	return paths


def _no_theme_marker(tmdb_id):
	return _join(cache_dir(), '%s.none' % tmdb_id)


def _strip_tags(content):
	"""An mp3 without its ID3 tags: AnisongDB audio carries a generic converter title ('AMQ mp3(c) convert') that Kodi shows instead of
	the song name. The name comes from the file name and the play item instead."""
	try:
		data = bytes(content)
		if data[:3] == b'ID3' and len(data) > 10:
			size = ((data[6] & 0x7f) << 21) | ((data[7] & 0x7f) << 14) | ((data[8] & 0x7f) << 7) | (data[9] & 0x7f)
			end = 10 + size + (10 if data[5] & 0x10 else 0)
			if 10 < end < len(data): data = data[end:]
		if len(data) > 128 and data[-128:-125] == b'TAG': data = data[:-128]
		return data
	except Exception:
		return content


def _clean_existing(path):
	"""Strip the tags off an already-saved mp3 once, in place."""
	try:
		if not path.lower().endswith('.mp3'): return
		handle = xbmcvfs.File(path)
		try: head = handle.readBytes(3)
		finally: handle.close()
		if bytes(head) != b'ID3': return
		handle = xbmcvfs.File(path)
		try: raw = handle.readBytes()
		finally: handle.close()
		clean = _strip_tags(raw)
		if clean is raw or len(clean) == len(raw): return
		_save_to(os.path.dirname(path), os.path.splitext(os.path.basename(path))[0], '.mp3', clean)
	except Exception:
		pass


def _save_to(folder, stem, ext, content):
	if ext.lower() == '.mp3': content = _strip_tags(content)
	path = _join(folder, '%s%s' % (stem, ext))
	part = path + '.part'
	handle = xbmcvfs.File(part, 'wb')
	try:
		ok = handle.write(bytearray(content))
	finally:
		handle.close()
	if ok:
		if xbmcvfs.exists(path):
			xbmcvfs.delete(path)
		if xbmcvfs.rename(part, path):
			return path
	xbmcvfs.delete(part)
	return ''

ANIMETHEMES_GRAPHQL = 'https://graphql.animethemes.moe/'
_ANIMETHEMES_QUERY = ('query ($id: [Int!]) { findAnimeByExternalSite(site: ANILIST, id: $id) { animethemes { type '
					  'animethemeentries { videos { nodes { audio { link } } } } } } }')


def _animethemes_entries(anilist_id, types=('OP',)):
	"""[(label, audio link)] of every AnimeThemes theme of the given types (OP, ED), in the order of the site. A theme
	without an audio file is left out. None when the service could not be reached."""
	try:
		response = requests.post(ANIMETHEMES_GRAPHQL,
								 json={'query': _ANIMETHEMES_QUERY, 'variables': {'id': [int(anilist_id)]}},
								 headers={'Content-Type': 'application/json'}, timeout=TIMEOUT)
		response.raise_for_status()
		found = (response.json().get('data') or {}).get('findAnimeByExternalSite') or []
	except Exception:
		return None
	themes = [theme for anime in found for theme in (anime.get('animethemes') or [])]
	entries, counts = [], {}
	for theme in themes:
		kind = theme.get('type') or 'THEME'
		if types and kind not in types:
			continue
		counts[kind] = counts.get(kind, 0) + 1
		label = '%s%d' % (kind, counts[kind])
		for entry in theme.get('animethemeentries') or []:
			link = ''
			for node in (entry.get('videos') or {}).get('nodes') or []:
				link = (node.get('audio') or {}).get('link') or ''
				if link:
					break
			if link:
				entries.append((label, link))
				break
	return entries
	for theme in themes:
		if types and theme.get('type') not in types:
			continue
		slug = theme.get('slug') or theme.get('type') or 'Theme'
		song = (theme.get('song') or {}).get('title') or ''
		label = ('%s %s' % (slug, song)).strip()
		for entry in theme.get('animethemeentries') or []:
			link = ''
			for video in entry.get('videos') or []:
				link = (video.get('audio') or {}).get('link') or ''
				if link:
					break
			if link:
				entries.append((label, link))
				break
	return entries


def _media_url(name):
	name = str(name or '').strip()
	if not name: return ''
	if name.startswith('http://') or name.startswith('https://'): return name
	return ANISONGDB_MEDIA + name.lstrip('/')

def _audio_ext(link):
	ext = os.path.splitext(urlparse(link).path)[1].lower()
	return ext if ext in CACHED_EXTENSIONS else '.mp3'

_ANISONG_KIND = {'opening': 'OP', 'ending': 'ED', 'insert': 'IN'}

def _anisongdb_post(url, body):
	response = requests.post(url, json=body, timeout=TIMEOUT)
	response.raise_for_status()
	songs = response.json() or []
	return songs if isinstance(songs, list) else []

def _norm_words(text):
	return ' '.join(re.findall(r'[a-z0-9]+', str(text or '').lower()))

def _anisongdb_entries(mal_id, song_types=('opening',), titles=()):
	"""[(label, audio link, video)] of the songs AnisongDB has for an anime: its MyAnimeList id, plus every other season of the same
	show found by name (a TMDb show is often several MAL entries: 'The Aegis of Uruk' and 'The Sword of Uruk').
	[] when there is none / no audio, None when AnisongDB could not be reached. Works without a MAL id (name search only)."""
	titles = [t for t in titles if t]
	bases = []
	for t in list(titles):
		base = re.split(r'\s*[:\u2013\u2014]\s*|\s+-\s+', str(t), 1)[0].strip()      # 'The Tower of Druaga: The Aegis of Uruk' -> 'The Tower of Druaga'
		if len(_norm_words(base)) >= 6 and base not in titles and base not in bases:
			bases.append(base)
	titles = bases + titles
	if not mal_id and not titles:
		return []
	wanted = set(song_types)
	flags = {'ignore_duplicate': False, 'opening_filter': 'opening' in wanted, 'ending_filter': 'ending' in wanted, 'insert_filter': 'insert' in wanted}
	songs, reached = [], False
	if mal_id:
		try:
			songs += _anisongdb_post(ANISONGDB_URL, dict(flags, mal_ids=[int(mal_id)]))
			reached = True
		except Exception:
			pass
	known = {str(s.get('audio')) for s in songs}
	for title in titles[:3]:
		try:
			found = _anisongdb_post(ANISONGDB_URL.replace('mal_ids_request', 'search_request'),
				dict(flags, anime_search_filter={'search': title, 'partial_match': True}, and_logic=False))
			reached = True
		except Exception:
			continue
		prefix = _norm_words(title)
		for song in found:
			names = [_norm_words(song.get('animeENName')), _norm_words(song.get('animeJPName'))]
			if str(song.get('audio')) in known or not prefix or not any(n.startswith(prefix) for n in names):
				continue                      # another show whose name merely contains this one
			known.add(str(song.get('audio')))
			songs.append(song)
	if not reached:
		return None
	entries, seen_audio = [], set()
	for song in songs:
		link = _media_url(song.get('audio'))
		video = _media_url(song.get('HQ') or song.get('MQ'))
		if not link or link in seen_audio:
			continue
		seen_audio.add(link)
		raw_type = str(song.get('songType') or '').strip().lower()
		kind = next((short for word, short in _ANISONG_KIND.items() if raw_type.startswith(word)), 'SONG')
		if kind != 'SONG' and kind not in [_ANISONG_KIND[w] for w in wanted if w in _ANISONG_KIND]:
			continue
		number = ''.join(c for c in raw_type if c.isdigit())
		if number:
			kind = '%s%s' % (kind, number)
		name = song.get('songName') or 'Theme'
		artist = song.get('songArtist') or ''
		label = '%s %s%s' % (kind, name, (' - %s' % artist) if artist else '')
		entries.append((label, link, video))
	return entries

def _themerrdb_youtube(tmdb_id):
	"""YouTube link of the show's theme in ThemerrDB: (url, reachable)."""
	try:
		response = requests.get(THEMERRDB_URL % tmdb_id, timeout=TIMEOUT)
	except Exception:
		return '', False
	if response.status_code != 200:
		return '', response.status_code < 500 and response.status_code != 429
	try:
		return str(response.json().get('youtube_theme_url') or ''), True
	except Exception:
		return '', True


class _QuietLog(object):
	def debug(self, msg): pass
	def info(self, msg): pass
	def warning(self, msg): pass
	def error(self, msg): pass


def _youtube_audio(stem, url, folder):
	"""Audio of a YouTube video through the bundled yt-dlp (no ffmpeg: the m4a/AAC stream is saved as it is). Returns the file path or ''."""
	if not os.path.isfile(YT_DLP_ZIP):
		return ''
	if YT_DLP_ZIP not in sys.path:
		sys.path.append(YT_DLP_ZIP)
	try:
		import yt_dlp
	except Exception as error:
		log('yt-dlp could not be loaded: %s' % error, xbmc.LOGWARNING)
		return ''
	options = {'format': '140/bestaudio[ext=m4a]/bestaudio', 'outtmpl': _join(folder, '%s.%%(ext)s' % stem), 'noplaylist': True, 'quiet': True,
			'no_warnings': True, 'noprogress': True, 'logger': _QuietLog(), 'cachedir': False, 'socket_timeout': TIMEOUT, 'retries': 1,
			'fragment_retries': 1, 'max_filesize': MAX_THEME_BYTES, 'nopart': False, 'updatetime': False, 'no_color': True}
	try:
		with yt_dlp.YoutubeDL(options) as ydl:
			info = ydl.extract_info(url, download=True)
		path = ((info.get('requested_downloads') or [{}])[0]).get('filepath') or ''
	except Exception as error:
		log('yt-dlp: %s' % str(error).splitlines()[0][:160], xbmc.LOGINFO)
		return ''
	if path and os.path.isfile(path) and os.path.getsize(path) >= MIN_AUDIO_BYTES:
		return path
	if path:
		xbmcvfs.delete(path)
	return ''


def _get_audio(url):
	"""(content, reachable): content is the audio bytes or None; reachable False means the network failed (try again later)."""
	try:
		response = requests.get(url, timeout=TIMEOUT)
	except Exception:
		return None, False
	if response.status_code == 200 and len(response.content) >= MIN_AUDIO_BYTES:
		return response.content, True
	if response.status_code >= 500 or response.status_code == 429:
		return None, False
	return None, True


def _fetch_to(folder, stem, url, ext, video_url=''):
	content, _ok = _get_audio(url)
	if content:
		return _save_to(folder, stem, ext, content)
	for address in (url, video_url):
		if address:
			path = _youtube_audio(stem, address, folder)
			if path:
				return path
	log('could not get a theme from %s' % url, xbmc.LOGWARNING)
	return ''

def _audio_loader(url, ext, video_url=''):
	def load(folder, stem):
		return _fetch_to(folder, stem, url, ext, video_url)
	return load


def _youtube_loader(link):
	def load(folder, stem):
		return _youtube_audio(stem, link, folder)
	return load


def _online_meta(tmdb_id):
	from modules import settings, metadata
	from modules.utils import get_datetime
	meta = metadata.tvshow_meta('tmdb_id', str(tmdb_id), settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	return meta or None


def _anilist_match(meta):
	try:
		from apis import anilist_api
		return anilist_api.anime_match(meta.get('title'), meta.get('year'), meta.get('original_title') or '') or {}
	except Exception:
		return {}


def _online_candidates(tmdb_id):
	"""Themes the user can browse, in the order of the sources: anime AnimeThemes, Plex, ThemerrDB; other shows Plex, ThemerrDB.
	Each is {'label', 'load'} where load(folder, stem) saves the audio and returns its path or ''."""
	from modules import metadata
	meta = _online_meta(tmdb_id)
	if not meta:
		return []
	candidates = []

	def anisongdb_part():
		for label, link, video in _anisongdb_entries(_anilist_match(meta).get('mal_id'), ('opening', 'ending', 'insert'), (meta.get('title'), meta.get('original_title'))) or []:
			candidates.append({'label': 'AnisongDB: %s' % label, 'load': _audio_loader(link, _audio_ext(link), video)})

	def animethemes_part():
		match = _anilist_match(meta)
		if not match.get('id'):
			return
		for label, link in _animethemes_entries(match['id'], ('OP', 'ED')) or []:
			candidates.append({'label': 'AnimeThemes: %s' % label, 'load': _audio_loader(link, _audio_ext(link))})

	def plex_part():
		tvdb_id = meta.get('tvdb_id')
		if tvdb_id in (None, '', 'None', 'empty_setting', 0, '0'):
			return
		candidates.append({'label': 'Plex theme', 'load': _audio_loader(PLEX_URL % tvdb_id, '.mp3')})

	def themerrdb_part():
		link, _ok = _themerrdb_youtube(tmdb_id)
		if link:
			candidates.append({'label': 'ThemerrDB theme', 'load': _youtube_loader(link)})

	parts = (anisongdb_part, animethemes_part, plex_part, themerrdb_part) if metadata.is_anime_check(meta) else (plex_part, themerrdb_part)
	for part in parts:
		try:
			part()
		except Exception as error:
			log('online themes: %s' % error, xbmc.LOGWARNING)
	return candidates


def download(tmdb_id):
	"""Fetch the default themes of a show and return the list of files saved (empty when there are none).
	The first source that has themes gives ALL of its themes (every opening and ending); only when it has none is the next one tried.
	Anime: AnisongDB, then AnimeThemes, then Plex, then ThemerrDB.
	Other shows: Plex, then ThemerrDB."""
	tmdb_id = str(tmdb_id)
	if time.time() - _failed_at.get(tmdb_id, 0) < RETRY_AFTER:
		return []
	from modules import metadata
	meta = _online_meta(tmdb_id)
	if not meta:
		return []
	state = {'reachable': True}
	folder = cache_dir()

	def _anisongdb():
		# every opening, ending and insert song AnisongDB has: each one is saved by its name and kept
		entries = _anisongdb_entries(_anilist_match(meta).get('mal_id'), ('opening', 'ending', 'insert'), (meta.get('title'), meta.get('original_title')))
		if entries is None:
			state['reachable'] = False
			return []
		return _save_entries(tmdb_id, entries)

	def _animethemes():
		match = _anilist_match(meta)
		if not match.get('id'):
			return []
		entries = _animethemes_entries(match['id'], ('OP', 'ED'))
		if entries is None:
			state['reachable'] = False
			return []
		return _save_entries(tmdb_id, entries)

	def _plex():
		saved = _saved_path(folder, tmdb_id)
		if saved:
			return [saved]
		tvdb_id = meta.get('tvdb_id')
		if tvdb_id in (None, '', 'None', 'empty_setting', 0, '0'):
			return []
		content, ok = _get_audio(PLEX_URL % tvdb_id)
		state['reachable'] = state['reachable'] and ok
		path = _save_to(folder, tmdb_id, '.mp3', content) if content else ''
		return [path] if path else []

	def _themerrdb():
		saved = _saved_path(folder, tmdb_id)
		if saved:
			return [saved]
		link, ok = _themerrdb_youtube(tmdb_id)
		state['reachable'] = state['reachable'] and ok
		if not link:
			return []
		path = _youtube_audio(tmdb_id, link, folder)
		if not path:
			state['reachable'] = False         # a theme exists but could not be fetched now: try again later instead of marking "no theme"
		return [path] if path else []

	sources = (_anisongdb, _animethemes, _plex, _themerrdb) if metadata.is_anime_check(meta) else (_plex, _themerrdb)
	for source in sources:
		paths = source()
		log('theme source %s for TMDb %s: %d theme(s)%s' % (source.__name__.strip('_'), tmdb_id, len(paths or []), '' if state['reachable'] else ' (could not be reached)'))
		if paths:
			return paths
	if state['reachable']:
		# nothing exists for this show: remember it for the 5 days so it is not asked again every time
		handle = xbmcvfs.File(_no_theme_marker(tmdb_id), 'wb')
		try:
			handle.write(bytearray(b'none'))
		finally:
			handle.close()
	else:
		_failed_at[tmdb_id] = time.time()
	return []


def resolve(tmdb_id, season=''):
	"""The files to play for a show (or its season), in order: [] for none.
	A theme the user chose (their folder, a picked theme) is played as it is, with no live check.
	A show that already has saved themes is checked live for themes not saved yet (at most every LIVE_CHECK_EVERY seconds);
	the saved themes are kept and the new ones are added to them."""
	items = rule_for(tmdb_id, season)
	if items is not None:
		log('themes for TMDb %s: %d from your theme folder / chosen themes (no online check)' % (tmdb_id, len(items)))
		return [i['path'] for i in items]
	tmdb_id = str(tmdb_id)
	cached = _cached_files(tmdb_id)
	if cached:
		if time.time() - _checked_at.get(tmdb_id, 0) >= LIVE_CHECK_EVERY:
			_checked_at[tmdb_id] = time.time()
			log('themes for TMDb %s: %d saved, checking online for new ones' % (tmdb_id, len(cached)))
			download(tmdb_id)
			now_saved = _cached_files(tmdb_id) or cached
			log('themes for TMDb %s: %d after the online check (%d new)' % (tmdb_id, len(now_saved), len([p for p in now_saved if p not in cached])))
			return now_saved
		log('themes for TMDb %s: %d saved (online check done less than %d minutes ago)' % (tmdb_id, len(cached), LIVE_CHECK_EVERY // 60))
		return cached
	if xbmcvfs.exists(_no_theme_marker(tmdb_id)):
		return []
	download(tmdb_id)
	return _cached_files(tmdb_id)


# ---------------------------------------------------------------------------------------------------------------
# which show (and season) is on screen
# ---------------------------------------------------------------------------------------------------------------
def key_from_folder(folder_path):
	"""'tmdb' or 'tmdb:season' when the open directory is a season list or an episode list of this add-on, else ''."""
	if not folder_path or not folder_path.startswith('plugin://plugin.video.nightshift'):
		return ''
	try:
		params = dict(parse_qsl(urlparse(folder_path).query, keep_blank_values=True))
	except Exception:
		return ''
	if params.get('mode') in LIST_MODES and params.get('tmdb_id', '').isdigit():
		tmdb_id, season = params['tmdb_id'], _valid_season(params.get('season'))
		return tmdb_id if not season else '%s:%s' % (tmdb_id, season)
	return ''


def _jsonrpc(method, params=None):
	"""Call Kodi's local JSON-RPC API. Theme playback fails closed when the GUI state cannot be verified."""
	request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
	if params is not None:
		request['params'] = params
	raw = xbmc.executeJSONRPC(json.dumps(request))
	try:
		reply = json.loads(raw or '{}')
	except Exception as error:
		raise RuntimeError('invalid JSON-RPC response for %s: %s' % (method, error))
	if not isinstance(reply, dict) or 'error' in reply or 'result' not in reply:
		raise RuntimeError('Kodi JSON-RPC did not return a result for %s' % method)
	return reply['result']


def _rpc_true(value):
	return value is True or str(value).strip().lower() in ('true', '1', 'yes')


def _same_media_path(left, right):
	left, right = str(left or '').strip().replace('\\', '/'), str(right or '').strip().replace('\\', '/')
	if not left or not right:
		return False
	try:
		return os.path.normcase(os.path.normpath(left)) == os.path.normcase(os.path.normpath(right))
	except Exception:
		return left.lower() == right.lower()


def _active_audio_files(players):
	files = []
	for item in players:
		if not isinstance(item, dict) or str(item.get('type') or '').lower() != 'audio':
			continue
		player_id = item.get('playerid')
		if player_id is None:
			continue
		try:
			info = _jsonrpc('Player.GetItem', {'playerid': player_id, 'properties': ['file']})
			path = str(((info or {}).get('item') or {}).get('file') or '')
			files.append((player_id, path))
		except Exception:
			files.append((player_id, ''))
	return files


def _rpc_browse_context(own_theme_audio=False):
	"""Return (TMDb key, reason) only when Kodi RPC confirms a real NightShift browse screen.

	The only start contexts are the NightShift season/episode folder with a numeric TMDb ID, or
	the live NightShift Extras TMDb property. Active/paused video and Kodi's video windows always
	block. The marked NightShift Ambience player is allowed to yield to a show theme; unrelated
	audio is left alone and blocks the theme.
	"""
	try:
		players = _jsonrpc('Player.GetActivePlayers')
		if not isinstance(players, list):
			return '', 'RPC active-player state unavailable'
		player_types = [str(item.get('type') or item.get('playertype') or '').lower()
					for item in players if isinstance(item, dict)]
		if 'video' in player_types:
			return '', 'Kodi RPC reports an active video player (playing or paused)'

		booleans = _jsonrpc('XBMC.GetInfoBooleans', {'booleans': [
			'Player.HasVideo', 'Window.IsActive(fullscreenvideo)', 'Window.IsActive(videoosd)', 'Window.IsVisible(videos)']})
		if not isinstance(booleans, dict):
			return '', 'RPC playback-window state unavailable'
		if any(_rpc_true(booleans.get(name)) for name in
			   ('Player.HasVideo', 'Window.IsActive(fullscreenvideo)', 'Window.IsActive(videoosd)')):
			return '', 'Kodi RPC still reports a video/player window'

		gui = _jsonrpc('GUI.GetProperties', {'properties': ['currentwindow']})
		window = (gui or {}).get('currentwindow') or {}
		window_label = str(window.get('label') or '').strip().lower()
		try:
			window_id = int(window.get('id'))
		except (TypeError, ValueError):
			window_id = -1
		if any(token in window_label for token in ('fullscreen video', 'video osd', 'player controls')):
			return '', 'Kodi RPC still reports a video window (%s)' % window_label

		labels = _jsonrpc('XBMC.GetInfoLabels', {'labels': [
			'Container.FolderPath',
			'Window(10000).Property(%s)' % EXTRAS_PROPERTY,
			'Window(10000).Property(%s)' % AMBIENCE_FILE_PROPERTY,
			'Window(10000).Property(%s)' % PLAYING_FILE_PROPERTY]})
		if not isinstance(labels, dict):
			return '', 'RPC container labels unavailable'
		extras_id = str(labels.get('Window(10000).Property(%s)' % EXTRAS_PROPERTY) or '').strip()
		folder_path = str(labels.get('Container.FolderPath') or '').strip()
		ambience_path = str(labels.get('Window(10000).Property(%s)' % AMBIENCE_FILE_PROPERTY) or '').strip()
		theme_path = str(labels.get('Window(10000).Property(%s)' % PLAYING_FILE_PROPERTY) or '').strip()
		if extras_id.isdigit():
			key, source = extras_id, 'extras'
		else:
			# Trust the Kodi Videos navigation window plus the add-on's own season/episode URL.
			# This deliberately rejects a stale Container.FolderPath on Home or a playback window.
			# currentwindow names the TOP window, which is a busy dialog for a moment whenever any audio file is opened
			# (the theme's own start, a menu ambience track changing) and a dialog while a context menu is open.
			# Window.IsActive(videos) stays true under such dialogs, so a passing dialog no longer ends the theme.
			is_video_navigation = (window_id == VIDEO_NAV_WINDOW_ID or window_label in ('videos', 'video files')
								   or _rpc_true(booleans.get('Window.IsVisible(videos)')))
			if not is_video_navigation:
				return '', 'TMDb folder is present but Kodi currentwindow is not Videos navigation (id=%s label=%s path=%s)' % (window_id, window_label, folder_path[:180])
			key, source = key_from_folder(folder_path), 'folder'
		if ':' in key:
			tmdb_id, season = key.split(':', 1)
			if not season_rule_exists(tmdb_id, season):
				key = tmdb_id
		if not key or not _valid_tmdb_key(key):
			return '', 'Kodi RPC is not in a TMDb season, episode, or Extras section (window=%s/%s path=%s extras=%s)' % (
				window_id, window_label, folder_path[:180], extras_id)

		# A menu ambience track is an expected co-tenant: the TMDb section owns the audio slot
		# and the Ambience service is signalled to stop. Never replace unrelated music.
		active_audio = _active_audio_files(players)
		ambience_audio_active = False
		for _player_id, audio_path in active_audio:
			if not audio_path:
				if own_theme_audio and theme_path:
					continue
				if ambience_path:
					# the file is still opening (a long Opus track): the ambience service has claimed the slot
					ambience_audio_active = True
					continue
				return '', 'Kodi RPC could not identify an active audio file; refusing to replace it'
			if own_theme_audio and _same_media_path(audio_path, theme_path):
				continue
			if ambience_path and (_same_media_path(audio_path, ambience_path)
								  or os.path.basename(audio_path.replace('\\', '/')) == os.path.basename(ambience_path.replace('\\', '/'))
								  or 'script.service.nightshift.ambience' in audio_path):
				# same file under another spelling of the path (Android storage aliases, URL-encoding) is still the ambience
				ambience_audio_active = True
				continue
			if not ambience_path and 'script.service.nightshift.ambience' in audio_path:
				ambience_audio_active = True      # the service's own tracks, before it has published the marker
				continue
			return '', 'Kodi RPC reports unrelated active audio; not replacing it (%s)' % os.path.basename(audio_path)

		# Close the race where a video begins while the GUI labels are being read.
		players_after = _jsonrpc('Player.GetActivePlayers')
		if not isinstance(players_after, list) or any(
				str(item.get('type') or item.get('playertype') or '').lower() == 'video'
				for item in players_after if isinstance(item, dict)):
			return '', 'video playback began while checking the TMDb browse context'
		return (key, 'Kodi RPC confirmed TMDb %s section (%s; window=%s/%s)%s' %
			    ('Extras' if source == 'extras' else 'season/episode', key, window_id, window_label or 'unknown',
			     '; exact NightShift Ambience audio is active and may be replaced' if ambience_audio_active else ''))
	except Exception as error:
		return '', 'Kodi RPC browse check failed: %s' % error


def _valid_tmdb_key(key):
	parts = str(key or '').split(':', 1)
	return bool(parts[0].isdigit() and (len(parts) == 1 or parts[1].isdigit()))


def wanted_key():
	"""Compatibility helper: resolve a currently verified TMDb browsing key through Kodi RPC."""
	key, _reason = _rpc_browse_context(False)
	return key


def _split(key):
	tmdb_id, _sep, season = key.partition(':')
	return tmdb_id, season


# ---------------------------------------------------------------------------------------------------------------
# the player (runs inside the add-on's service)
# ---------------------------------------------------------------------------------------------------------------
class _KodiPlayer(xbmc.Player):
	def __init__(self):
		xbmc.Player.__init__(self)
		self.ended = False
		self.stopped = False
		self.wake = threading.Event()

	def onAVStarted(self):
		# Wake the monitor; the RPC browse gate, not this callback, decides whether a video is active.
		self.wake.set()

	def onPlayBackEnded(self):
		self.ended = True
		self.wake.set()

	def onPlayBackStopped(self):
		self.stopped = True
		self.wake.set()


class ThemeService(object):
	def __init__(self, monitor):
		self.monitor = monitor
		self.player = _KodiPlayer()
		self.key = ''
		self.queue = []
		self.path = ''
		self.started_at = 0
		self.suppressed = ''
		self.changed = ''
		self.last_purge = 0
		self.browse_candidate = ''
		self.browse_since = 0
		self.last_gate_message = ''

	def run(self):
		log('service started; theme playback requires Kodi RPC confirmation of a TMDb browse section (Videos window or Extras)')
		while not self.monitor.abortRequested():
			self.player.wake.clear()
			try:
				self.tick()
			except Exception as error:
				log('tick failed: %s' % error, xbmc.LOGWARNING)
			self.player.wake.wait(SERVICE_POLL_SECONDS)
		self.stop()

	def ours_playing(self):
		try:
			return bool(self.path) and self.player.isPlayingAudio() and self.player.getPlayingFile() == self.path
		except Exception:
			return False

	def _stop_exact_theme_audio(self):
		"""Stop the theme by its exact published file path, even if the Python Player view is stale."""
		expected = str(self.path or kodi_utils.get_property(PLAYING_FILE_PROPERTY) or '').strip()
		if not expected:
			return False
		def normalized(value):
			value = str(value or '').replace('\\', '/')
			try:
				return os.path.normcase(os.path.normpath(value))
			except Exception:
				return value
		try:
			players = _jsonrpc('Player.GetActivePlayers')
			if not isinstance(players, list):
				return False
			stopped = False
			for item in players:
				if not isinstance(item, dict) or str(item.get('type') or '').lower() != 'audio':
					continue
				player_id = item.get('playerid')
				if player_id is None:
					continue
				info = _jsonrpc('Player.GetItem', {'playerid': player_id, 'properties': ['file']})
				playing_file = ((info or {}).get('item') or {}).get('file', '')
				if not playing_file or normalized(playing_file) != normalized(expected):
					continue
				_jsonrpc('Player.Stop', {'playerid': player_id})
				stopped = True
			if stopped:
				log('stopped exact theme audio through Kodi RPC')
			return stopped
		except Exception as error:
			log('RPC exact-theme stop failed; checking the local Player API: %s' % error, xbmc.LOGWARNING)
		return False

	def stop(self, preserve_wanted=False):
		self._bag = []
		stopped_rpc = self._stop_exact_theme_audio()
		if not stopped_rpc and self.path and self.ours_playing():
			try:
				self.player.stop()
			except Exception:
				pass
		kodi_utils.clear_property(PLAYING_PROPERTY)
		kodi_utils.clear_property(PLAYING_FILE_PROPERTY)
		self.path = ''
		self.queue = []
		if not preserve_wanted:
			kodi_utils.clear_property(WANTED_PROPERTY)

	def _hold(self, reason, preserve_wanted=False):
		show_id = ''
		if preserve_wanted:
			show_id = _split(self.key)[0] if self.key else str(kodi_utils.get_property(WANTED_PROPERTY) or '').strip()
		self.stop(preserve_wanted=bool(show_id))
		self.key = ''
		self.browse_candidate = ''
		self.browse_since = 0
		self.player.ended = self.player.stopped = False
		if show_id:
			kodi_utils.set_property(WANTED_PROPERTY, show_id)
		message = reason or 'no verified TMDb browse context'
		if message != self.last_gate_message:
			log('theme held: %s' % message, xbmc.LOGINFO)
			self.last_gate_message = message

	def _bag_key(self):
		return 'nightshift.theme.bag.%s' % _split(self.key)[0]

	def _load_bag(self):
		"""The rest of this show's shuffle cycle, kept while Kodi runs so leaving and re-entering the show carries on with the
		themes not played yet instead of shuffling again (and starting with the same one). Returns (bag, last played)."""
		try:
			saved = json.loads(kodi_utils.get_property(self._bag_key()) or '{}')
			bag = [p for p in saved.get('bag', []) if p in self.queue]
			last = saved.get('last', '')
			return bag, last
		except Exception:
			return [], ''

	def _save_bag(self, bag, last):
		try:
			kodi_utils.set_property(self._bag_key(), json.dumps({'bag': list(bag), 'last': last}))
		except Exception:
			pass

	def next_path(self):
		"""The next file to play: a no-repeat random bag over the queue, like the ambience add-on. Every theme is drawn
		once per cycle, the bag refills when it is empty, and the same theme is not played twice in a row (also across
		leaving and re-entering the show)."""
		if len(self.queue) <= 1:
			return self.queue[0] if self.queue else self.path
		if not getattr(self, '_bag', None):
			self._bag, saved_last = self._load_bag()
			if saved_last and not self.path: self.path = saved_last
		bag = self._bag
		if not bag:
			bag = self._bag = list(self.queue)
			for i in range(len(bag) - 1, 0, -1):
				j = secrets.randbelow(i + 1)
				bag[i], bag[j] = bag[j], bag[i]
		nxt = bag.pop()
		if nxt == self.path and bag:
			bag.insert(0, nxt)
			nxt = bag.pop()
		self._save_bag(bag, nxt)
		log('random bag: playing %s, %d left this cycle: %s' % (os.path.basename(nxt), len(bag), ' | '.join(os.path.basename(b) for b in bag) or '-'))
		return nxt

	def _handoff_busy(self):
		# Keep the theme stopped throughout NightShift's entire next-episode pipeline, not
		# merely while the scraper/resolve locks happen to be held. Natural-end and ready
		# markers cover the short gap before the next playback request claims resolve_busy.
		blocking = (
			'nightshift.sources_busy',
			'nightshift.resolve_busy',
			'nightshift.play_opening',
			'nightshift.nextep_pending',
			'nightshift.nextep_prep_scheduled',
			'nightshift.autoscrape_nextep_ready',
			'nightshift.nextep_handoff.visible',
			'nightshift.nextep_handoff_meta',
			'nightshift.nextep_scrape_ready',
		)
		now = time.time()
		seen = getattr(self, '_handoff_seen', None)
		if seen is None:
			seen = self._handoff_seen = {}
		active = [name for name in blocking
				  if str(kodi_utils.get_property(name) or '').strip().lower() not in ('', 'false', '0', 'none')]
		for name in list(seen):
			if name not in active:
				seen.pop(name)
		live = [name for name in active if name in LIVE_LOCKS]
		if live:
			self._handoff_names = ', '.join(live)
			return True
		fresh = []
		for name in active:
			first = seen.setdefault(name, now)
			if now - first < HANDOFF_STALE_SECONDS:
				fresh.append(name)
		if fresh:
			self._handoff_names = ', '.join(fresh)
			return True
		if active:
			self._handoff_names = ''
			if not getattr(self, '_stale_logged', False):
				self._stale_logged = True
				log('theme: ignoring stale handoff markers (set for over %d s with no live search): %s'
					% (HANDOFF_STALE_SECONDS, ', '.join(active)), xbmc.LOGINFO)
		else:
			self._stale_logged = False
		if kodi_utils.get_property('nightshift.nextep_natural_end') == 'true':
			# A video reached its end and the next episode may be on its way. The flag is only cleared when the next
			# playback is set up, so a video that was not followed by autoplay leaves it behind; it may hold the theme
			# for NATURAL_END_HOLD_SECONDS at most, not for ever (the theme stayed silent on the episode list).
			since = getattr(self, '_natural_end_since', 0) or time.time()
			self._natural_end_since = since
			return time.time() - since < NATURAL_END_HOLD_SECONDS
		self._natural_end_since = 0
		return False

	def _rpc_context(self):
		return _rpc_browse_context(self.ours_playing())

	def tick(self):
		now = time.time()
		if now - self.last_purge > PURGE_EVERY:
			self.last_purge = now
			purge(now)
		if kodi_utils.get_property('nightshift.pause_services') == 'true':
			self._hold('NightShift services are paused')
			return
		if self._handoff_busy():
			self._hold('NightShift source search/resolution/video handoff is active (%s)'
					   % (getattr(self, '_handoff_names', '') or 'natural end'), preserve_wanted=True)
			return
		if not themes_enabled():
			self._hold('show themes are disabled')
			return

		key, reason = self._rpc_context()
		if not key:
			video_still_open = ('video player' in reason.lower() or 'video/player window' in reason.lower()
							 or 'video playback began' in reason.lower())
			self._hold(reason, preserve_wanted=video_still_open)
			return
		self.last_gate_message = ''

		if key != self.browse_candidate:
			self.browse_candidate = key
			self.browse_since = now
			log('Kodi RPC detected TMDb browse context %s (%s); confirming it remains stable before starting a theme' % (key, reason))
			if self.key and self.key != key:
				self.stop()
				self.key = ''
				self.player.ended = self.player.stopped = False
				self.suppressed = ''
				self.browse_candidate = key
				self.browse_since = now
			return
		if now - self.browse_since < BROWSE_STABLE_SECONDS:
			return

		changed = kodi_utils.get_property('nightshift.theme.changed')
		force = changed != self.changed
		self.changed = changed
		if key != self.key or force:
			self.stop()
			self.key = key
			self.suppressed = ''
			self.player.ended = self.player.stopped = False
			self.begin(key)
			return
		if not key or key == self.suppressed:
			return
		if self.ours_playing():
			return
		if self.player.ended:
			self.player.ended = False
			self.play(self.next_path())
		elif self.player.stopped and now - self.started_at > 3:
			self.suppressed = key
			self.path = ''
			self.queue = []
			kodi_utils.clear_property(PLAYING_PROPERTY)
			kodi_utils.clear_property(PLAYING_FILE_PROPERTY)
			kodi_utils.clear_property(WANTED_PROPERTY)
		elif self.path and now - self.started_at > 8:
			# the track is no longer playing and Kodi reported neither an end nor a stop: it finished, so go on to the next theme of the bag
			self.play(self.next_path() if self.queue else self.path)

	def begin(self, key):
		tmdb_id, season = _split(key)
		queue = resolve(tmdb_id, season)
		if self.monitor.abortRequested():
			return
		# Resolution/download can take several seconds. Never start the file unless Kodi still
		# reports the exact same TMDb browsing section after that work has finished.
		current, reason = self._rpc_context()
		if current != key or self._handoff_busy():
			self._hold('discarded resolved theme because the Kodi browse context changed: %s' % (reason or current),
					  preserve_wanted=True)
			return
		if not queue:
			kodi_utils.clear_property(WANTED_PROPERTY)
			log('no theme file is available for TMDb %s; leaving menu ambience untouched' % tmdb_id)
			return
		self.queue = queue
		self._bag = []          # reloaded from the saved cycle in next_path()
		log('theme list for TMDb %s (%d): %s' % (tmdb_id, len(queue), ' | '.join(os.path.basename(q) for q in queue)))
		self.play(self.next_path())

	def play(self, path):
		# The show has a real resolved theme now: claim the audio slot. The Ambience service
		# stops/refrains from restarting, and Player.play replaces its specifically marked track.
		kodi_utils.set_property(WANTED_PROPERTY, _split(self.key)[0])
		current, reason = self._rpc_context()
		if self._handoff_busy() or current != self.key or not current:
			self._hold('theme start rejected by Kodi RPC browse gate: %s' % (reason or 'TMDb section changed'),
					  preserve_wanted=True)
			return
		if path.startswith(cache_dir()): _clean_existing(path)
		self.player.ended = self.player.stopped = False
		self.path = path
		self.started_at = time.time()
		kodi_utils.set_property(PLAYING_PROPERTY, _split(self.key)[0])
		kodi_utils.set_property(PLAYING_FILE_PROPERTY, path)
		try:
			name = _name_of(path)
			if name.startswith(_split(self.key)[0] + '_'): name = name[len(_split(self.key)[0]) + 1:]
			name = name.replace('_', ' ')
			item = xbmcgui.ListItem(label=name, path=path)
			tag = item.getMusicInfoTag()
			tag.setTitle(name)       # the file's own tag can be a generic converter name ('AMQ mp3(c) convert')
			tag.setArtist('')
			kodi_utils.set_property('nightshift.theme.title', name)
			self.player.play(path, item, True)
		except Exception:
			self.player.play(path, windowed=True)
		log('started show theme for TMDb %s: %s' % (_split(self.key)[0], os.path.basename(path)))
