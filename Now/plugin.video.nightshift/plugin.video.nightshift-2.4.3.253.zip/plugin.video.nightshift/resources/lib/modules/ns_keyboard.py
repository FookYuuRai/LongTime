# -*- coding: utf-8 -*-
"""Nightshift on-screen search keyboard with live title suggestions.

Used only for Nightshift search entry (search.get_key_id). If it cannot open,
search falls back to Kodi's standard keyboard so search never breaks.
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from modules.ns_autocomplete import fetch_suggestions, DEFAULT_LIMIT

ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
DEBOUNCE_SECONDS = 0.15

TITLE_ID = 100
TEXT_ID = 300
LIST_ID = 500
KEY_ID_BASE = 2000
KEY_CHARS = list('0123456789abcdefghijklmnopqrstuvwxyz-\'&:')
SPACE_ID, BACK_ID, CLEAR_ID, SEARCH_ID = 2100, 2101, 2102, 2103

ACTION_PREVIOUS_MENU = getattr(xbmcgui, 'ACTION_PREVIOUS_MENU', 10)
ACTION_NAV_BACK = getattr(xbmcgui, 'ACTION_NAV_BACK', 92)


class NightshiftKeyboard(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.result = ''
        self.heading = ''
        self._text = ''
        self._seq = 0
        self._labels = []
        self._closed = False
        self._lock = threading.Lock()
        super().__init__(*args, **kwargs)

    # ---- window lifecycle -------------------------------------------------
    def onInit(self):
        self.getControl(TITLE_ID).setLabel(self.heading or 'Search')
        self._refresh_text()
        self._publish(self._next_seq(), [])
        self.setFocusId(KEY_ID_BASE)

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self._cancel()

    def onClick(self, control_id):
        if KEY_ID_BASE <= control_id < KEY_ID_BASE + len(KEY_CHARS):
            self._set_text(self._text + KEY_CHARS[control_id - KEY_ID_BASE])
        elif control_id == SPACE_ID:
            self._set_text(self._text + ' ')
        elif control_id == BACK_ID:
            self._set_text(self._text[:-1])
        elif control_id == CLEAR_ID:
            self._set_text('')
        elif control_id == SEARCH_ID:
            self._submit()
        elif control_id == LIST_ID:
            self._insert_suggestion()

    # ---- text and suggestions ---------------------------------------------
    def _set_text(self, text):
        self._text = text
        self._refresh_text()
        self._request_suggestions(text)

    def _refresh_text(self):
        self.getControl(TEXT_ID).setLabel(self._text + '_')

    def _next_seq(self):
        with self._lock:
            self._seq += 1
            return self._seq

    def _request_suggestions(self, text):
        seq = self._next_seq()
        if not text.strip():
            self._publish(seq, [])
            return
        threading.Thread(target=self._lookup, args=(seq, text), daemon=True).start()

    def _lookup(self, seq, text):
        time.sleep(DEBOUNCE_SECONDS)       # debounce: skip lookups overtaken by typing
        if not self._is_current(seq):
            return
        labels = fetch_suggestions(text, DEFAULT_LIMIT)  # network, never on the key path
        self._publish(seq, labels)

    def _is_current(self, seq):
        with self._lock:
            return seq == self._seq and not self._closed

    def _publish(self, seq, labels):
        """Show labels only if no newer query has started (stale-result protection)."""
        with self._lock:
            if seq != self._seq or self._closed:
                return
            self._labels = labels
            control = self.getControl(LIST_ID)
            control.reset()
            for label in labels:
                control.addItem(xbmcgui.ListItem(label))

    def _insert_suggestion(self):
        position = self.getControl(LIST_ID).getSelectedPosition()
        if 0 <= position < len(self._labels):
            self._text = self._labels[position]
            self._refresh_text()
            self._publish(self._next_seq(), [])

    # ---- finishing ---------------------------------------------------------
    def _submit(self):
        self.result = self._text.strip()
        self._finish()

    def _cancel(self):
        self.result = ''
        self._finish()

    def _finish(self):
        with self._lock:
            self._closed = True
            self._seq += 1
        self.close()


def ns_keyboard_input(heading=''):
    """Return the text typed on the Nightshift keyboard, or '' if cancelled."""
    try:
        dialog = NightshiftKeyboard('ns_keyboard.xml', ADDON_PATH, 'Default', '1080i')
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] could not open, using Kodi keyboard: {exc}", xbmc.LOGWARNING)
        return xbmcgui.Dialog().input(heading)
    try:
        dialog.heading = heading
        dialog.doModal()
        return dialog.result
    finally:
        del dialog
