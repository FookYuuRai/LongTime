# -*- coding: utf-8 -*-
"""Live title suggestions for the Nightshift search keyboard.

Uses TMDb's website search (the same endpoint the TMDb site uses for its search box). No API key.
The session first loads the TMDb homepage to pick up cookies, sends browser-style headers, and retries
once with a fresh session if TMDb answers 403. Successful results are cached in memory for the session;
failures are not cached.
"""
import threading

import xbmc

HOME_URL = 'https://www.themoviedb.org/'
SEARCH_URL = 'https://www.themoviedb.org/search/multi'
BROWSER_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
              'Chrome/124.0 Safari/537.36')
HOME_HEADERS = {
    'User-Agent': BROWSER_UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}
SEARCH_HEADERS = {
    'User-Agent': BROWSER_UA,
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.9',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://www.themoviedb.org/',
}
TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 9

_cache = {}
_cache_order = []
_cache_lock = threading.Lock()
_session = None
_session_lock = threading.Lock()


def _new_session():
    """A fresh session with TMDb cookies (loaded from the homepage). Returns None if the homepage fails."""
    from modules.kodi_utils import make_session
    session = make_session('https://www.themoviedb.org')
    try:
        session.get(HOME_URL, headers=HOME_HEADERS, timeout=TIMEOUT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] TMDb homepage warm-up failed: {exc}", xbmc.LOGWARNING)
    return session


def _get_session(fresh=False):
    global _session
    with _session_lock:
        if fresh or _session is None:
            _session = _new_session()
        return _session


def _search(query):
    """Raw TMDb multi-search JSON for `query`. Raises on failure (after one retry on 403)."""
    try:
        response = _get_session().get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                                      headers=SEARCH_HEADERS, timeout=TIMEOUT)
        if response.status_code == 403:
            raise _Forbidden('403 Client Error: Forbidden')
        response.raise_for_status()
        return response.json()
    except _Forbidden:
        # TMDb refused this session: start again with new cookies and retry once.
        response = _get_session(fresh=True).get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                                                headers=SEARCH_HEADERS, timeout=TIMEOUT)
        response.raise_for_status()
        return response.json()


class _Forbidden(Exception):
    pass


def titles_from_search(data, limit=DEFAULT_LIMIT):
    """Pull unique movie, TV and person names from a TMDb multi-search response."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    titles, seen = [], set()
    for item in results:
        if not isinstance(item, dict):
            continue
        kind = item.get('media_type')
        if kind == 'movie':
            title = item.get('title') or item.get('original_title')
        elif kind in ('tv', 'person'):
            title = item.get('name') or item.get('original_name')
        else:
            continue
        if not isinstance(title, str):
            continue
        title = title.strip()
        key = title.casefold()
        if not title or key in seen:
            continue
        seen.add(key)
        titles.append(title)
        if len(titles) >= limit:
            break
    return titles


def _remember(key, titles):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = titles
        while len(_cache_order) > CACHE_LIMIT:
            _cache.pop(_cache_order.pop(0), None)


def fetch_suggestions(text, limit=DEFAULT_LIMIT):
    """Return up to `limit` title suggestions for `text`. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    key = query.casefold()
    with _cache_lock:
        if key in _cache:
            return list(_cache[key])[:limit]
    try:
        titles = titles_from_search(_search(query), DEFAULT_LIMIT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] suggestions failed for {query!r}: {exc}", xbmc.LOGWARNING)
        return []
    _remember(key, titles)
    return titles[:limit]
