"""NIGHTSHIFT modules package."""
