# -*- coding: utf-8 -*-
"""Puts the Nightshift Home menu selection back on the row the user left.

The skin records the row when the user goes into a section (Nightshift.RootIndex). It cannot restore it itself:
AlarmClock does not evaluate $INFO, so the focus call always reached Kodi with an invalid row and the list fell back
to the top. This service runs the restore with a real number, once per return to the root menu.
"""
import xbmc
import xbmcgui

HOME_WINDOW = 10000
SECTION_PROPERTY = 'Nightshift.Section'
INDEX_PROPERTY = 'Nightshift.RootIndex'
ROOT_LIST = 9000
POLL_SECONDS = 0.25


def _property(name):
	try:
		return str(xbmcgui.Window(HOME_WINDOW).getProperty(name) or '').strip()
	except Exception:
		return ''


def _number(text):
	try:
		return int(float(text))
	except (TypeError, ValueError):
		return 0


def _trace(state):
	"""One log line each time the menu state changes, so a log shows every row change and return to the root menu."""
	xbmc.log('[NIGHTSHIFT menu] %s' % ' '.join('%s=%s' % (k, v) for k, v in state.items()), xbmc.LOGINFO)


def run(monitor):
	restored = False
	last = None
	while not monitor.abortRequested():
		try:
			home_active = xbmc.getCondVisibility('Window.IsActive(home)')
			section = _property(SECTION_PROPERTY)
			index_text = _property(INDEX_PROPERTY)
			count = _number(xbmc.getInfoLabel('Container(%d).NumItems' % ROOT_LIST)) if home_active else 0
			position = _number(xbmc.getInfoLabel('Container(%d).CurrentItem' % ROOT_LIST)) if home_active else 0
			label = xbmc.getInfoLabel('Container(%d).ListItem.Label' % ROOT_LIST) if home_active else ''
			state = {'home': int(bool(home_active)), 'section': section or '-', 'root_index': index_text or '-',
					 'items': count, 'focus': position, 'focus_label': label or '-', 'restored': int(restored)}
			if state != last:
				_trace(state)
				last = state
			if not home_active or section != 'home':
				restored = False                   # a section is open, or another window is: the next return restores again
			elif not restored:
				if count > 0:
					index = _number(index_text)
					if 0 < index < count:
						xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (ROOT_LIST, index))
						_trace({'restore_to': index, 'items': count})
					restored = True
		except Exception as error:
			xbmc.log('[NIGHTSHIFT] root focus: %s' % error, xbmc.LOGWARNING)
		if monitor.waitForAbort(POLL_SECONDS):
			break
