# -*- coding: utf-8 -*-
"""Knaben (meta-search over many trackers) through its v2 JSON API:
GET <base>/v2/search?q=<query>&sf=title&o=seeders&d=desc&s=<=300&f=<offset>  ->  {"hits": [{"title","hash","magnetUrl","seeders","peers","bytes","tracker",...}]}
Zero-seeder rows are requested too (the bare 'dead' flag): a torrent can be fully cached on a debrid with nobody seeding it."""
from urllib.parse import quote_plus
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, instance_base_url, normalize_info_hash
from apis import indexer_http

KNABEN_URLS = (
	'https://api.knaben.org',
)
PAGE_SIZE = 150


def knaben_base_url():
	return instance_base_url('knaben.url', KNABEN_URLS, 'knaben.custom_url', 1) or KNABEN_URLS[0]


def knaben_search_url(query):
	base = knaben_base_url().rstrip('/')
	if not base or not query:
		return None
	return '%s/v2/search?dead&q=%s&sf=title&o=seeders&d=desc&s=%d&f=0' % (base, quote_plus(query), PAGE_SIZE)


def clear_knaben_cache():
	try:
		main_cache.delete_like('KNABEN_%')
		return True
	except Exception:
		return False


def _bases():
	chosen = knaben_base_url().rstrip('/')
	return [chosen] + [u for u in KNABEN_URLS if u.rstrip('/') != chosen]


def _row(raw):
	if not isinstance(raw, dict):
		return None
	name = (raw.get('title') or raw.get('name') or '').strip()
	if not name:
		return None
	info_hash = normalize_info_hash(raw.get('hash') or raw.get('infoHash') or '')
	if not info_hash:
		magnet = raw.get('magnetUrl') or raw.get('magnet') or ''
		if 'btih:' in magnet:
			info_hash = normalize_info_hash(magnet.split('btih:', 1)[1].split('&', 1)[0])
	if not info_hash or set(info_hash) == {'0'}:
		return None
	try: seeders = int(raw.get('seeders') or 0)
	except Exception: seeders = 0
	return {'hash': info_hash, 'name': name, 'size': bytes_to_gb(raw.get('bytes') or raw.get('size')), 'seeders': seeders}


def search(query, timeout=10, expiration=24):
	query = (query or '').strip()
	if not query:
		return []
	cache_key = 'KNABEN_%s_%s' % (knaben_base_url(), query)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	try:
		payload, _ = indexer_http.get_json('knaben', _bases(), '/v2/search?dead',
			{'q': query, 'sf': 'title', 'o': 'seeders', 'd': 'desc', 's': PAGE_SIZE, 'f': 0}, timeout)
	except Exception as e:
		logger('knaben api', '%s: %s (%s)' % (type(e).__name__, str(e)[:200], query))
		return []
	hits = payload.get('hits') if isinstance(payload, dict) else payload
	results, seen = [], set()
	for raw in (hits if isinstance(hits, list) else []):
		row = _row(raw)
		if row and row['hash'] not in seen:
			seen.add(row['hash'])
			results.append(row)
	main_cache.set(cache_key, results, expiration=expiration)
	return results
