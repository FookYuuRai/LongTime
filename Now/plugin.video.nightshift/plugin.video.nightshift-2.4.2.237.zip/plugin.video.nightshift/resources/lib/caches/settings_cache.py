# -*- coding: utf-8 -*-
import json
import re
import time
from threading import Lock
from modules import kodi_utils
from caches.base_cache import connect_database
# logger = kodi_utils.logger

VALID_EXTRAS_CONTAINER_IDS = frozenset(range(2050, 2074))
_COLOR_SETTING_RE = re.compile(r'^[0-9A-Fa-f]{6}$|^[0-9A-Fa-f]{8}$')
_EXTRAS_LIST_DEFAULT = '2050,2074,2051,2068,2067,2069,2070,2071,2072,2073,2052,2053,2054,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2074'
_MAX_PROPERTY_LEN = 8192
_SETTINGS_PROPERTIES_LOADED = 'nightshift.settings_properties_loaded'
_DEFERRED_SETUP_DONE = 'nightshift.deferred_service_setup_done'
_SETTINGS_DB_MIGRATED = 'nightshift.settings_db_migrated'
_SETTINGS_WIDGETS_MIGRATED = 'nightshift.settings_widgets_migrated'
_SETTINGS_DB_SYNCED = 'nightshift.settings_db_synced'
_SETTINGS_SYNC_FINGERPRINT = 'nightshift.settings_sync_fingerprint'
_WIDGET_REFRESH_SCHEDULED = 'nightshift.widgets_refresh_scheduled'
_SERVICE_AUTH_VISIBILITY_SETTINGS = frozenset((
	'rd.token', 'pm.token', 'ad.token', 'oc.token', 'tb.token',
	'easynews_user', 'easynews_password',
))
# Meta account auth — Home props drive Meta Accounts sync-row visibility while Settings stays open.
_META_AUTH_VISIBILITY_SETTINGS = frozenset((
	'trakt.user', 'trakt.token', 'simkl.user', 'simkl.token', 'simkl.refresh', 'simkl.client',
	'mdblist.user', 'mdblist.token', 'mdblist.client',
	'punchplay.user', 'punchplay.token', 'punchplay.client',
	'wetrakr.user', 'wetrakr.token',
))
_NEW_SETTING_VALUE_MIGRATIONS = {
	'trakt.calendar_display': 'single_ep_display',
	'trakt.calendar_display_widget': 'single_ep_display_widget',
}
_bootstrap_lock = Lock()
_DEFAULTS_LIST = None
_DEFAULTS_MAP = None

def _properties_loaded():
	return kodi_utils.get_property(_SETTINGS_PROPERTIES_LOADED) == 'true'

def _settings_schema_token():
	return '%s:%s' % (kodi_utils.addon_info('version'), len(default_settings()))

def compute_settings_sync_fingerprint():
	return _settings_schema_token()

def _sync_marker_file():
	try: return kodi_utils.translate_path(kodi_utils.addon_info('profile')) + 'settings_sync.marker'
	except Exception: return ''

def _disk_sync_current():
	"""True when the settings database was fully synced by THIS add-on version (and settings schema) in an earlier Kodi session: Kodi's Home
	properties (where the 'synced' state lives) are empty after every start, which used to force a full settings re-sync at each Kodi start."""
	try:
		path = _sync_marker_file()
		if not path: return False
		with open(path, 'r') as f: stored = f.read().strip()
		return stored == compute_settings_sync_fingerprint() and bool(settings_cache.get_all())
	except Exception:
		return False

def mark_settings_sync_complete():
	kodi_utils.set_property(_SETTINGS_SYNC_FINGERPRINT, compute_settings_sync_fingerprint())
	try:
		path = _sync_marker_file()
		if path:
			with open(path, 'w') as f: f.write(compute_settings_sync_fingerprint())
	except Exception:
		pass

def settings_sync_needed():
	if kodi_utils.get_property(_SETTINGS_DB_SYNCED) != 'true':
		if _disk_sync_current():
			kodi_utils.set_property(_SETTINGS_DB_SYNCED, 'true')
			kodi_utils.set_property(_SETTINGS_SYNC_FINGERPRINT, compute_settings_sync_fingerprint())
			return False
		return True
	stored = kodi_utils.get_property(_SETTINGS_SYNC_FINGERPRINT) or ''
	return stored != compute_settings_sync_fingerprint()

def clear_settings_boot_state(clear_deferred=True):
	kodi_utils.clear_property(_SETTINGS_SYNC_FINGERPRINT)
	kodi_utils.clear_property(_SETTINGS_DB_SYNCED)
	kodi_utils.clear_property(_SETTINGS_PROPERTIES_LOADED)
	kodi_utils.clear_property(_SETTINGS_DB_MIGRATED)
	kodi_utils.clear_property(_SETTINGS_WIDGETS_MIGRATED)
	if clear_deferred:
		kodi_utils.clear_property(_DEFERRED_SETUP_DONE)

def bootstrap_settings_needed():
	if not _properties_loaded():
		return True
	if kodi_utils.get_property(_SETTINGS_DB_MIGRATED) == 'true':
		return True
	if kodi_utils.get_property(_DEFERRED_SETUP_DONE) != 'true':
		return True
	return False

def widgets_refresh_after_migration_needed():
	return kodi_utils.get_property(_SETTINGS_WIDGETS_MIGRATED) == 'true'

def service_bootstrap_needed():
	return bootstrap_settings_needed() or widgets_refresh_after_migration_needed()

def _new_settings_affect_widgets(insert_list):
	for item in insert_list:
		setting_id = item[0]
		if setting_id.startswith('migration.'):
			continue
		return True
	return False

def _new_setting_value(setting_id, setting_default, currentsettings, had_existing_settings, fresh_install=False) -> str:
	if not had_existing_settings:
		# A genuine fresh install has nothing to migrate, but migrate_legacy_sort_settings() reads each
		# absent legacy id as its own old getter fallback, so it would write six override rows for a user
		# who has never touched a sort setting - breaking list_sort_cache's "a row means the user
		# overrode this list" invariant. Seed the sentinel as already done so it never runs here.
		#
		# fresh_install, not had_existing_settings: the caller's dict comes from get_all(), which
		# answers {} for a locked or corrupt database too. Seeding 'true' on that mistake would skip the
		# migration forever - the next healthy sync reads the sentinel, never runs it, and the obsolete
		# purge then deletes the five legacy ids and with them the only copy of the user's orderings.
		if setting_id == 'migration.unified_list_sort': return 'true' if fresh_install else setting_default
		return setting_default
	if setting_id == 'provider.internal':
		if any(currentsettings.get('provider.%s' % scraper) == 'true' for scraper in ('comet', 'torrentio', 'torz', 'nyaa', 'animetosho', 'mediafusion', 'zilean', 'piratebay', 'torrentdownloads', 'knaben')):
			return 'true'
		return setting_default
	old_setting_id = _NEW_SETTING_VALUE_MIGRATIONS.get(setting_id)
	if not old_setting_id:
		return setting_default
	return currentsettings.get(old_setting_id, setting_default)

_CREDENTIAL_STRING_SETTINGS = frozenset(('tmdb_api', 'trakt.client', 'trakt.secret', 'tmdb.lists_read_token', 'fanarttv_api', 'omdb_api', 'tvdb_api', 'tvdb_pin'))

def normalize_credential_string(value):
	if value in (None, 'empty_setting'): return ''
	return str(value).strip()

def looks_like_tmdb_v4_jwt(value):
	value = normalize_credential_string(value)
	return len(value) > 48 and value.startswith('eyJ') and value.count('.') >= 2

def property_safe_string(value):
	if value is None: return ''
	value = str(value).replace('\x00', '')
	return ''.join(c for c in value if c >= ' ' or c in '\t\n\r')[:_MAX_PROPERTY_LEN]

def _sanitize_extras_list(value, fallback=_EXTRAS_LIST_DEFAULT):
	if value in (None, '', 'noop'): return fallback
	try: ids = [int(i.strip()) for i in str(value).split(',') if i.strip()]
	except: return fallback
	valid = [i for i in ids if i in VALID_EXTRAS_CONTAINER_IDS]
	if not valid: return fallback
	return ','.join(str(i) for i in valid)

def sanitize_setting_value(setting_id, value, setting_info=None, validate_paths=True):
	if setting_info is None: setting_info = default_setting_values(setting_id)
	default = setting_info['setting_default'] if setting_info else ''
	if value is None: return default
	value = property_safe_string(value)
	if setting_id in ('extras.order', 'extras.enabled'):
		fallback = setting_info['setting_default'] if setting_info else _EXTRAS_LIST_DEFAULT
		return _sanitize_extras_list(value, fallback)
	if setting_id == 'default_addon_fanart':
		if not validate_paths: return value or default
		path = kodi_utils.translate_path(value) if value else ''
		if path and kodi_utils.path_exists(path): return value
		return kodi_utils.addon_fanart()
	if setting_id == 'addon_icon_choice':
		if not validate_paths: return value or default
		path = kodi_utils.translate_path(value) if value else ''
		if path and kodi_utils.path_exists(path): return value
		return default or 'resources/media/addon_icons/icon.png'
	if setting_id.endswith('_highlight') or setting_id in ('window_theme', 'window_theme_contrast'):
		if _COLOR_SETTING_RE.match(value): return value.upper()
		return default
	if setting_info and setting_info.get('setting_type') == 'boolean':
		if value in ('true', 'false'): return value
		return default
	if setting_id == 'watched_indicators':
		from modules.settings import watched_provider_options
		value = str(value)
		opts = watched_provider_options()
		if value in opts: return value
		if value == '1':
			from caches.settings_cache import settings_cache
			token = settings_cache.read_db_value('trakt.token')
			if token not in (None, '0', '', 'empty_setting'): return value
		if value == '2':
			from modules.settings import simkl_user_active
			if simkl_user_active(): return value
		if value == '3':
			from modules.settings import mdblist_user_active
			if mdblist_user_active(): return value
		if value == '4':
			from modules.settings import punchplay_user_active
			if punchplay_user_active(): return value
		return '0'
	if setting_id == 'recommend_service':
		from modules.settings import recommend_service_options
		value = str(value)
		opts = recommend_service_options()
		if value in opts: return value
		return '0'
	if setting_id == 'playback.subs_source':
		from modules.settings import subtitles_source_options
		value = str(value)
		opts = subtitles_source_options()
		if value in opts: return value
		if value == '2':
			return '1' if '1' in opts else '0'
		if value == '1':
			return '2' if '2' in opts else '0'
		return '0'
	if setting_id in ('stinger_alert.alert_timing', 'autoplay_alert_timing', 'autoscrape_alert_timing'):
		from modules.settings import alert_timing_options
		value = str(value)
		opts = alert_timing_options(next_episode=(setting_id != 'stinger_alert.alert_timing'))
		if value in opts: return value
		if value == '2':
			return '1' if '1' in opts else '0'
		return default if default in opts else ('1' if '1' in opts else '0')
	if setting_id == 'external_scraper.run_mode':
		value = str(value)
		opts = default_setting_values(setting_id)
		if opts and value in opts.get('settings_options', {}): return value
		return default if default in (opts or {}).get('settings_options', {}) else '1'
	if setting_id in _CREDENTIAL_STRING_SETTINGS:
		if value in (None, 'empty_setting', ''): return default if value is None else value
		return normalize_credential_string(value)
	if len(value) > _MAX_PROPERTY_LEN: return value[:_MAX_PROPERTY_LEN]
	return value

class SettingsCache:
	def __init__(self):
		self._db_cache = {}
		self._db_warmed = False

	def clear_db_cache(self):
		self._db_cache = {}
		self._db_warmed = False

	def _warm_db_cache(self):
		if self._db_warmed: return
		self._db_warmed = True
		try:
			for setting_id, setting_value in self.get_all().items():
				setting_info = default_setting_values(setting_id)
				if setting_info: setting_value = sanitize_setting_value(setting_id, setting_value, setting_info, validate_paths=False)
				else: setting_value = property_safe_string(setting_value)
				self._db_cache[setting_id] = setting_value
		except: pass

	def read_db_value(self, setting_id, validate_paths=False):
		setting_id = setting_id.replace('nightshift.', '')
		if setting_id in self._db_cache: return self._db_cache[setting_id]
		if not self._db_warmed: self._warm_db_cache()
		if setting_id in self._db_cache: return self._db_cache[setting_id]
		try:
			dbcon = connect_database('settings_db')
			row = dbcon.execute('SELECT setting_value FROM settings WHERE setting_id = ?', (setting_id,)).fetchone()
			if not row:
				self._db_cache[setting_id] = None
				return None
			setting_value = row[0]
			setting_info = default_setting_values(setting_id)
			if setting_info: setting_value = sanitize_setting_value(setting_id, setting_value, setting_info, validate_paths=validate_paths)
			else: setting_value = property_safe_string(setting_value)
			self._db_cache[setting_id] = setting_value
			return setting_value
		except:
			self._db_cache[setting_id] = None
			return None

	def get(self, setting_id):
		return self.read_db_value(setting_id)

	def remove_setting(self, setting_id):
		dbcon = connect_database('settings_db')
		dbcon.execute('DELETE FROM settings WHERE setting_id = ?', (setting_id,))

	def get_many(self, settings_list):
		try:
			dbcon = connect_database('settings_db')
			results = dict(dbcon.execute('SELECT setting_id, setting_value FROM settings WHERE setting_id in (%s)' \
										% (', '.join('?' for _ in settings_list)), settings_list).fetchall())
			return results
		except: results = {}
		return results

	def get_all(self):
		dbcon = connect_database('settings_db')
		try: all_settings = dict(dbcon.execute('SELECT setting_id, setting_value FROM settings').fetchall())
		except: all_settings = {}
		return all_settings

	def is_empty_strict(self):
		"""True only when this profile genuinely holds no settings. Raises rather than guessing.

		get_all() swallows every sqlite error and answers {}, so its empty dict cannot tell a fresh
		install from a database that is locked, corrupt or unreadable. Anything deciding "this profile
		has never been written to" has to ask a question that is allowed to fail. An absent file and an
		absent table are both genuinely empty - the service creates them on first run.
		"""
		from caches.base_cache import database_locations
		if not kodi_utils.path_exists(database_locations('settings_db')): return True
		dbcon = connect_database('settings_db')
		try: row = dbcon.execute('SELECT setting_id FROM settings LIMIT 1').fetchone()
		except Exception as error:
			if 'no such table' in str(error).lower(): return True
			raise
		return row is None

	def set(self, setting_id, setting_value=None, provider_sync=True):
		setting_id = setting_id.replace('nightshift.', '')
		prev_watched_indicators = None
		if setting_id == 'watched_indicators':
			try: prev_watched_indicators = str(self.read_db_value('watched_indicators') or '0')
			except: prev_watched_indicators = '0'
		self._db_cache.pop(setting_id, None)
		self._db_cache.pop('%s_name' % setting_id, None)
		dbcon = connect_database('settings_db')
		setting_info = default_setting_values(setting_id)
		if not setting_info: return
		setting_type, setting_default = setting_info['setting_type'], setting_info['setting_default']
		if setting_value is None: setting_value = setting_default
		setting_value = sanitize_setting_value(setting_id, setting_value, setting_info)
		instance_switch = None
		if setting_id == 'aiostreams.instance':
			old_instance = str(self.read_db_value('aiostreams.instance') or '0')
			new_instance = str(setting_value)
			if old_instance != new_instance:
				instance_switch = new_instance
				try:
					from apis.aiostreams_api import persist_active_profile
					persist_active_profile(old_instance)
				except: pass
		dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (setting_id, setting_type, setting_default, setting_value))
		if instance_switch is not None:
			try:
				from apis.aiostreams_api import apply_profile
				apply_profile(instance_switch)
			except: pass
		if _properties_loaded():
			self.set_memory_cache(setting_id, setting_value)
			if setting_id in _SERVICE_AUTH_VISIBILITY_SETTINGS:
				try:
					from modules.service_expiry import publish_settings_expiry_properties
					publish_settings_expiry_properties()
				except: pass
			if setting_id in _META_AUTH_VISIBILITY_SETTINGS:
				try:
					from modules.settings import watched_provider_options
					opts = watched_provider_options()
					current = str(self.read_db_value('watched_indicators') or '0')
					label = opts.get(current) or opts.get('0', 'NIGHTSHIFT')
					self.set_memory_cache('watched_indicators_name', label)
				except: pass
				try:
					from modules.settings import recommend_service_options
					opts = recommend_service_options()
					current = str(self.read_db_value('recommend_service') or '0')
					if current not in opts:
						current = '0'
						self.write_db('recommend_service', current)
						self.set_memory_cache('recommend_service', current)
					self.set_memory_cache('recommend_service_name', opts.get(current, opts['0']))
				except: pass
		if setting_type == 'action' and 'settings_options' in setting_info:
			name_setting_id = '%s_name' % setting_id
			if setting_id == 'watched_indicators':
				from modules.settings import watched_provider_options
				opts = watched_provider_options()
				name_setting_value = opts.get(str(setting_value)) or setting_info['settings_options'].get(str(setting_value), opts['0'])
			elif setting_id == 'recommend_service':
				from modules.settings import recommend_service_options
				opts = recommend_service_options()
				name_setting_value = opts.get(str(setting_value)) or setting_info['settings_options'].get(str(setting_value), opts['0'])
			elif setting_id == 'playback.subs_source':
				from modules.settings import subtitles_source_options
				opts = subtitles_source_options()
				name_setting_value = opts.get(str(setting_value), opts['0'])
			elif setting_id in ('stinger_alert.alert_timing', 'autoplay_alert_timing', 'autoscrape_alert_timing'):
				from modules.settings import alert_timing_options
				opts = alert_timing_options(next_episode=(setting_id != 'stinger_alert.alert_timing'))
				name_setting_value = opts.get(str(setting_value), opts.get('1', opts.get('0', '')))
			else:
				name_setting_value = setting_info['settings_options'].get(str(setting_value), setting_info['settings_options'].get(setting_value, str(setting_value)))
			if setting_id == 'aiostreams.instance':
				try:
					from apis.aiostreams_api import INSTANCE_LABELS
					name_setting_value = INSTANCE_LABELS.get(str(setting_value), name_setting_value)
				except: pass
			dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (name_setting_id, 'name', '', name_setting_value))
			if _properties_loaded(): self.set_memory_cache(name_setting_id, name_setting_value)
		if _properties_loaded() and setting_id in ('aiostreams.instance', 'aiostreams.custom_url', 'provider.aiostreams'):
			try:
				from apis.aiostreams_api import refresh_settings_properties
				refresh_settings_properties()
			except: pass
		if provider_sync and setting_id == 'watched_indicators' and str(setting_value) != str(prev_watched_indicators):
			_sync_watched_provider_on_switch(setting_value)

	def set_many(self, settings_list, load_properties=True):
		dbcon = connect_database('settings_db')
		dbcon.executemany('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', settings_list)
		if load_properties:
			for item in settings_list: self.set_memory_cache(item[0], item[3] or item[2])

	def write_db(self, setting_id, setting_value, setting_info=None):
		setting_id = setting_id.replace('nightshift.', '')
		self._db_cache.pop(setting_id, None)
		if setting_info is None: setting_info = default_setting_values(setting_id)
		if setting_info: setting_value = sanitize_setting_value(setting_id, setting_value, setting_info)
		else: setting_value = property_safe_string(setting_value)
		dbcon = connect_database('settings_db')
		if setting_info:
			dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)',
				(setting_id, setting_info['setting_type'], setting_info['setting_default'], setting_value))
		else:
			dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (setting_id, 'name', '', setting_value))

	def set_memory_cache(self, setting_id, setting_value):
		try:
			kodi_utils.set_property('nightshift.%s' % setting_id, property_safe_string(setting_value))
		except: pass

	def delete_memory_cache(self, setting_id):
		# ###FIX### bare clear_property was never imported here (NameError whenever a setting's memory cache was deleted)
		kodi_utils.clear_property('nightshift.%s' % setting_id)

	def setting_info(self, setting_id):
		d_settings = default_settings()
		return [i for i in d_settings if i['setting_id'] == setting_id][0]

	def clean_database(self):
		try:
			dbcon = connect_database('settings_db')
			dbcon.execute('VACUUM')
			return True
		except: return False

settings_cache = SettingsCache()

def set_setting(setting_id, value, provider_sync=True):
	settings_cache.set(setting_id, value, provider_sync=provider_sync)

def get_setting(setting_id, fallback=''):
	if _properties_loaded():
		prop = kodi_utils.get_property(setting_id)
		if prop not in ('', None): return prop
	value = settings_cache.read_db_value(setting_id)
	if value not in ('', None): return value
	return fallback

_APPLYING = 'nightshift.settings_applying'

def _apply_settings_properties_from_db():
	"""Publishes the settings as Home properties. The plugin and each service (NIGHTSHIFT, NIGHTSHIFT) all want this at Kodi start: when another
	one is already doing it, wait for it (at most ~25 s) instead of doing the same thing three times at once on a slow CPU."""
	try:
		started = kodi_utils.get_property(_APPLYING)
		if started and not _properties_loaded() and time.time() - float(started) < 30:
			deadline = time.time() + 25
			while time.time() < deadline and not _properties_loaded() and kodi_utils.get_property(_APPLYING):
				time.sleep(0.1)
			if _properties_loaded(): return
	except Exception:
		pass
	kodi_utils.set_property(_APPLYING, str(time.time()))
	_t0 = time.time()
	try:
		if _apply_snapshot():
			kodi_utils.logger('SettingsStartup', 'settings properties restored from the saved copy in %.2fs' % (time.time() - _t0))
			try:
				from modules.settings import refresh_external_scraper_properties
				refresh_external_scraper_properties()
			except Exception: pass
			settings_cache.clear_db_cache()
		else:
			_apply_settings_properties_now()
			kodi_utils.logger('SettingsStartup', 'settings properties rebuilt in %.2fs (no matching saved copy)' % (time.time() - _t0))
	finally:
		kodi_utils.clear_property(_APPLYING)

def _snapshot_file():
	try: return kodi_utils.translate_path(kodi_utils.addon_info('profile')) + 'settings_props.json'
	except Exception: return ''

def _snapshot_key():
	"""Changes when this add-on version, the settings schema or the CONTENT of the settings database changes (never because a service
	re-wrote the file without changing it: Android does that at every Kodi start)."""
	try:
		from caches.base_cache import content_stamp
		return '%s|%s' % (compute_settings_sync_fingerprint(), content_stamp('settings_db'))
	except Exception:
		return ''

def _apply_snapshot():
	"""Cold start: replays the property values saved by the last full publish (when nothing changed since) - no default_settings(), no
	sanitising, no database read. True when it was applied."""
	try:
		path = _snapshot_file()
		key = _snapshot_key()
		if not path or not key: return False
		with open(path, 'r', encoding='utf-8') as f: data = json.load(f)
		if data.get('key') != key: return False
		_set_home = kodi_utils.kodi_window().setProperty
		for name, value in data['props']: _set_home(name, value)
		kodi_utils.set_property(_SETTINGS_PROPERTIES_LOADED, 'true')
		return True
	except Exception:
		return False

def _save_snapshot(props):
	try:
		path = _snapshot_file()
		key = _snapshot_key()
		if not path or not key: return
		tmp = path + '.tmp'
		with open(tmp, 'w', encoding='utf-8') as f: json.dump({'key': key, 'props': props}, f)
		import os
		os.replace(tmp, path)
	except Exception:
		pass

def _apply_settings_properties_now():
	recorded = []
	real_set = kodi_utils.set_property
	def _record(name, value):
		recorded.append((name, value))
		return real_set(name, value)
	kodi_utils.set_property = _record
	try:
		_apply_settings_properties_body(recorded)
	finally:
		kodi_utils.set_property = real_set
	_save_snapshot([r for r in recorded if r[0] not in (_SETTINGS_PROPERTIES_LOADED, _APPLYING)])

def _apply_settings_properties_body(recorded):
	d_settings = default_settings()
	defaultsettings_ids = _defaultsettings_ids(d_settings)
	defaults_map = _get_defaults_map()
	currentsettings = settings_cache.get_all()
	_set_home = kodi_utils.kodi_window().setProperty
	for setting_id, value in currentsettings.items():
		if setting_id not in defaultsettings_ids: continue
		info = defaults_map.get(setting_id)
		if info: sanitized = sanitize_setting_value(setting_id, value, info, validate_paths=False)
		else: sanitized = property_safe_string(value)
		try:
			_v = property_safe_string(sanitized)
			_set_home('nightshift.%s' % setting_id, _v); recorded.append(('nightshift.%s' % setting_id, _v))     # one Home window for the whole loop (a new one per setting was most of the time)
		except: pass
		if setting_id == 'watched_indicators':
			try:
				from modules.settings import watched_provider_options
				opts = watched_provider_options()
				info = defaults_map.get(setting_id) or {}
				static_opts = info.get('settings_options', {})
				settings_cache.set_memory_cache('watched_indicators_name', opts.get(sanitized) or static_opts.get(sanitized, opts['0']))
			except: pass
		if setting_id == 'recommend_service':
			try:
				from modules.settings import recommend_service_options
				opts = recommend_service_options()
				info = defaults_map.get(setting_id) or {}
				static_opts = info.get('settings_options', {})
				settings_cache.set_memory_cache('recommend_service_name', opts.get(sanitized) or static_opts.get(sanitized, opts['0']))
			except: pass
		if setting_id == 'playback.subs_source':
			try:
				from modules.settings import subtitles_source_options
				opts = subtitles_source_options()
				settings_cache.set_memory_cache('playback.subs_source_name', opts.get(sanitized, opts['0']))
			except: pass
		if setting_id in ('stinger_alert.alert_timing', 'autoplay_alert_timing', 'autoscrape_alert_timing'):
			try:
				from modules.settings import alert_timing_options
				opts = alert_timing_options(next_episode=(setting_id != 'stinger_alert.alert_timing'))
				settings_cache.set_memory_cache('%s_name' % setting_id, opts.get(sanitized, opts.get('1', '')))
			except: pass
		elif setting_id == 'autoplay_skip_intro':
			try:
				opts = (defaults_map.get(setting_id) or {}).get('settings_options', {})
				settings_cache.set_memory_cache('%s_name' % setting_id, opts.get(sanitized, opts.get('0', '')))
			except: pass
	try:
		from apis.aiostreams_api import refresh_settings_properties
		refresh_settings_properties()
	except: pass
	try:
		from modules.settings import refresh_external_scraper_properties
		refresh_external_scraper_properties()
	except: pass
	kodi_utils.set_property(_SETTINGS_PROPERTIES_LOADED, 'true')
	settings_cache.clear_db_cache()

def get_many(settings_list):
	return settings_cache.get_many(settings_list)

def _defaultsettings_ids(d_settings):
	defaultsettings_ids = [i['setting_id'] for i in d_settings]
	defaultsettings_names = [i['setting_id'] for i in d_settings if 'settings_options' in i]
	defaultsettings_ids.extend(['%s_name' % i for i in defaultsettings_names])
	return defaultsettings_ids

_ACTIVE_KODI_PROFILE = 'nightshift.active_kodi_profile'

def sync_kodi_profile_context():
	"""Reload settings properties when the active Kodi profile changes (multi-profile / shared Trakt)."""
	try:
		current = kodi_utils.translate_path(kodi_utils.addon_info('profile'))
	except:
		return False
	if not current:
		return False
	kodi_utils.set_property('nightshift.addon_profile', current)
	previous = kodi_utils.get_property(_ACTIVE_KODI_PROFILE) or ''
	if previous != current:
		kodi_utils.set_property(_ACTIVE_KODI_PROFILE, current)
		kodi_utils.clear_property(_SETTINGS_PROPERTIES_LOADED)
		settings_cache.clear_db_cache()
		if kodi_utils.get_property(_SETTINGS_DB_SYNCED) == 'true':
			_apply_settings_properties_from_db()
		else:
			bootstrap_settings_properties(force=True)
		return True
	if not _properties_loaded():
		kodi_utils.set_property(_ACTIVE_KODI_PROFILE, current)
		if kodi_utils.get_property(_SETTINGS_DB_SYNCED) == 'true':
			_apply_settings_properties_from_db()
		else:
			bootstrap_settings_properties(force=True, startup=True)
		return True
	if not previous:
		kodi_utils.set_property(_ACTIVE_KODI_PROFILE, current)
	return False

def ensure_settings_properties_loaded():
	sync_kodi_profile_context()
	if _properties_loaded(): return False
	with _bootstrap_lock:
		if _properties_loaded(): return False
		if kodi_utils.get_property(_SETTINGS_DB_SYNCED) == 'true':
			_apply_settings_properties_from_db()
			return True
		return bootstrap_settings_properties()

def refresh_settings_manager_properties():
	"""Republish settings.db to Home props before Settings Manager opens (boolean toggles need this)."""
	settings_cache.clear_db_cache()
	_apply_settings_properties_from_db()
	try:
		from modules.settings import refresh_playback_subs_source, refresh_alert_timing_settings, refresh_external_scraper_properties
		refresh_playback_subs_source()
		refresh_alert_timing_settings()
		refresh_external_scraper_properties()
	except: pass
	try:
		from modules.service_expiry import publish_settings_expiry_properties
		publish_settings_expiry_properties()
	except: pass

def bootstrap_settings_properties(force=False, startup=False):
	db_migrated = kodi_utils.get_property(_SETTINGS_DB_MIGRATED) == 'true'
	if not force and _properties_loaded() and not db_migrated:
		return False
	with _bootstrap_lock:
		db_migrated = kodi_utils.get_property(_SETTINGS_DB_MIGRATED) == 'true'
		if not force and _properties_loaded() and not db_migrated:
			return False
		# the first start of a Kodi session (startup) or a normal bootstrap: the database was already fully synced by this version - only the
		# properties are published again (the full sync is what took 10-20 s at every Kodi start)
		disk_ok = (startup or not force) and kodi_utils.get_property(_SETTINGS_DB_SYNCED) != 'true' and _disk_sync_current()
		if force:
			kodi_utils.clear_property(_SETTINGS_PROPERTIES_LOADED)
			kodi_utils.clear_property(_SETTINGS_DB_SYNCED)
		if disk_ok:
			kodi_utils.set_property(_SETTINGS_DB_SYNCED, 'true')
			kodi_utils.set_property(_SETTINGS_SYNC_FINGERPRINT, compute_settings_sync_fingerprint())
		elif force or kodi_utils.get_property(_SETTINGS_DB_SYNCED) != 'true':
			sync_settings({'silent': 'true', 'load_properties': False, 'force': 'true'})
		else:
			kodi_utils.clear_property(_SETTINGS_PROPERTIES_LOADED)
		_apply_settings_properties_from_db()
		if db_migrated:
			kodi_utils.clear_property(_SETTINGS_DB_MIGRATED)
		return True

def schedule_widget_refresh_once(reload_skin=False):
	if kodi_utils.get_property(_WIDGET_REFRESH_SCHEDULED) == 'true': return
	kodi_utils.set_property(_WIDGET_REFRESH_SCHEDULED, 'true')
	try: kodi_utils.schedule_widget_refresh(silent=True, reload_skin=reload_skin)
	except: pass

def refresh_widgets_after_db_migration():
	if kodi_utils.get_property(_SETTINGS_WIDGETS_MIGRATED) != 'true': return
	kodi_utils.clear_property(_SETTINGS_WIDGETS_MIGRATED)
	schedule_widget_refresh_once(reload_skin=not kodi_utils.is_android())

def run_deferred_setup_if_needed():
	run_deferred_setup_background_if_needed()

def run_deferred_setup_background_if_needed():
	if kodi_utils.get_property(_DEFERRED_SETUP_DONE) == 'true': return
	kodi_utils.set_property(_DEFERRED_SETUP_DONE, 'true')
	from threading import Thread
	def _run():
		try:
			from service import run_deferred_service_setup
			run_deferred_service_setup()
		except Exception as e:
			kodi_utils.logger('run_deferred_setup_if_needed', str(e))
	Thread(target=_run, daemon=True).start()

_DIRECTORY_LISTING_MODES = frozenset((
	'build_movie_list', 'build_tvshow_list', 'build_season_list', 'build_episode_list',
	'build_in_progress_episode', 'build_recently_watched_episode', 'build_next_episode',
	'build_my_calendar', 'build_mdbl_calendar', 'build_punchplay_calendar', 'build_simkl_calendar', 'build_simkl_public_calendar', 'build_mdbl_next_up', 'build_next_episode_manager'))

# The five settings the unified-list-sort migration reads. They are no longer in default_settings(),
# so the obsolete-id purge in sync_settings() would delete them on the same pass that migrates them -
# leaving nothing to retry from if the migration fails. The purge is deferred until the sentinel says
# the migration succeeded, which happens in the same run, so they are removed on the following sync.
_LEGACY_SORT_SETTING_IDS = frozenset((
	'sort.watchlist', 'sort.collection', 'sort.simkl', 'tmdbsort.watchlist', 'tmdbsort.favorites'))

def is_directory_listing_mode(mode):
	if not mode: return False
	if mode.startswith('navigator.'): return True
	return mode in _DIRECTORY_LISTING_MODES

def should_block_bootstrap_on_entry(mode):
	"""Only block plugin entry when opening settings UI; listings read settings.db directly."""
	if mode in ('open_settings', 'sync_settings'):
		return True
	if mode and mode.startswith('settings_manager.'):
		return True
	return False

def load_settings_properties(force=False):
	bootstrap_settings_properties(force=force)
	refresh_widgets_after_db_migration()
	run_deferred_setup_if_needed()

def reload_after_settings_restore(imported_db_keys=()):
	"""Reload caches after a settings backup import without stopping the addon service."""
	clear_settings_boot_state(clear_deferred=True)
	kodi_utils.clear_property(_WIDGET_REFRESH_SCHEDULED)
	settings_cache.clear_db_cache()
	imported = set(imported_db_keys or ())
	if not imported or 'navigator_db' in imported:
		try:
			from caches.navigator_cache import navigator_cache
			for list_name in navigator_cache.main_menus:
				navigator_cache.delete_memory_cache(list_name, 'default')
				navigator_cache.delete_memory_cache(list_name, 'edited')
		except: pass
	try:
		sync_settings({'silent': 'true', 'load_properties': False})
	except Exception as e:
		kodi_utils.logger('reload_after_settings_restore', 'sync: %s' % e)
	try:
		kodi_utils.ensure_addon_xml_from_settings(force=True)
	except Exception as e:
		kodi_utils.logger('reload_after_settings_restore', 'addon_xml: %s' % e)
	from threading import Thread
	def _bootstrap():
		try:
			bootstrap_settings_properties(force=True)
			run_deferred_setup_background_if_needed()
			schedule_widget_refresh_once(reload_skin=False)
		except Exception as e:
			kodi_utils.logger('reload_after_settings_restore', 'bootstrap: %s' % e)
	Thread(target=_bootstrap, daemon=True).start()

def sync_settings(params={}):
	silent = params.get('silent', 'true') == 'true'
	force = params.get('force', False) == 'true'
	if 'load_properties' in params:
		load_properties = params.get('load_properties', True) == 'true'
	else:
		# AM Lite and boot service sync update settings.db only; full property reload is for Remake Settings Cache.
		load_properties = not silent
	if not force and not load_properties and not settings_sync_needed():
		return 'skipped'
	migrated = False
	widgets_migrated = False
	insert_list = []
	insert_list_append = insert_list.append
	currentsettings = settings_cache.get_all()
	# Redundant by design: the obsolete purge below defers the legacy sort ids until the migration has
	# recorded success, so currentsettings still holds them when the migration runs. This pre-purge
	# snapshot is the second line of defence if that deferral is ever removed - keep both.
	legacy_sort_settings = {k: v for k, v in currentsettings.items() if k.startswith('sort.') or k.startswith('tmdbsort.')}
	had_existing_settings = bool(currentsettings)
	# Only a database that answers "no rows" without erroring is a fresh install. A failure here is
	# treated as "not fresh", which defers the sort migration to the next sync instead of cancelling
	# it: the sentinel stays 'false' and the obsolete purge keeps holding the legacy ids back.
	fresh_install = False
	if not had_existing_settings:
		try: fresh_install = settings_cache.is_empty_strict()
		except Exception as error:
			kodi_utils.logger('sync_settings', 'settings db not readable, deferring sort migration: %s' % error)
	d_settings = default_settings()
	defaultsettings_ids = _defaultsettings_ids(d_settings)
	defaults_map = {i['setting_id']: i for i in d_settings}
	try:
		c_settings = currentsettings.items()
		# Keep the legacy sort ids alive until the migration below has actually recorded success,
		# otherwise a failed run purges the only copy of the user's per-list orderings.
		defer_legacy_sort = currentsettings.get('migration.unified_list_sort') != 'true'
		obsoletesettings_ids = [k for k, v in c_settings
			if not k in defaultsettings_ids and not (defer_legacy_sort and k in _LEGACY_SORT_SETTING_IDS)]
		if obsoletesettings_ids:
			for item in obsoletesettings_ids: settings_cache.remove_setting(item)
			migrated = True
			currentsettings = settings_cache.get_all()
	except: pass
	_setting_migrations = (
		('external.cache_check', 'rd.cache_check'),
		('external.include_uncached_torbox', 'tb.include_uncached'),
		('external.include_uncached_offcloud', 'oc.include_uncached'),
	)
	for old_id, new_id in _setting_migrations:
		if old_id not in currentsettings: continue
		if new_id not in currentsettings:
			value = currentsettings[old_id]
			settings_cache.write_db(new_id, value, defaults_map.get(new_id))
			currentsettings[new_id] = value
			if load_properties: settings_cache.set_memory_cache(new_id, value)
		settings_cache.remove_setting(old_id)
		currentsettings.pop(old_id, None)
		migrated = True
	_alert_timing_migrations = (
		('stinger_alert.use_chapters', 'stinger_alert.alert_timing'),
		('autoplay_use_chapters', 'autoplay_alert_timing'),
		('autoscrape_use_chapters', 'autoscrape_alert_timing'),
	)
	for old_id, new_id in _alert_timing_migrations:
		if old_id not in currentsettings: continue
		new_val = '1' if str(currentsettings[old_id]).lower() == 'true' else '0'
		settings_cache.write_db(new_id, new_val, defaults_map.get(new_id))
		currentsettings[new_id] = new_val
		if load_properties: settings_cache.set_memory_cache(new_id, new_val)
		settings_cache.remove_setting(old_id)
		currentsettings.pop(old_id, None)
		migrated = True
	if had_existing_settings and currentsettings.get('migration.cache_check_pm_oc_tb_v129e') != 'true':
		for cache_key in ('pm.cache_check', 'oc.cache_check', 'tb.cache_check'):
			if currentsettings.get(cache_key) == 'true': continue
			settings_cache.write_db(cache_key, 'true', defaults_map.get(cache_key))
			currentsettings[cache_key] = 'true'
			if load_properties: settings_cache.set_memory_cache(cache_key, 'true')
			migrated = True
		settings_cache.write_db('migration.cache_check_pm_oc_tb_v129e', 'true', defaults_map.get('migration.cache_check_pm_oc_tb_v129e'))
		currentsettings['migration.cache_check_pm_oc_tb_v129e'] = 'true'
		if load_properties: settings_cache.set_memory_cache('migration.cache_check_pm_oc_tb_v129e', 'true')
	if had_existing_settings and currentsettings.get('migration.ad_cache_check_removed_v173') != 'true':
		if currentsettings.get('ad.cache_check') == 'true':
			settings_cache.write_db('ad.cache_check', 'false', defaults_map.get('ad.cache_check'))
			currentsettings['ad.cache_check'] = 'false'
			if load_properties: settings_cache.set_memory_cache('ad.cache_check', 'false')
			migrated = True
		settings_cache.write_db('migration.ad_cache_check_removed_v173', 'true', defaults_map.get('migration.ad_cache_check_removed_v173'))
		currentsettings['migration.ad_cache_check_removed_v173'] = 'true'
		if load_properties: settings_cache.set_memory_cache('migration.ad_cache_check_removed_v173', 'true')
	if currentsettings:
		from modules.settings import migrate_force_refresh_calendar_cm_for_upgrade, migrate_simkl_context_menu_for_upgrade, migrate_mdblist_context_menu_for_upgrade, migrate_punchplay_context_menu_for_upgrade, migrate_cm_manager_order_for_upgrade, migrate_external_scraper_context_menu_for_upgrade, migrate_theme_song_context_menu_for_upgrade, migrate_extras_theme_chooser_top_for_upgrade, migrate_extras_theme_chooser_after_plot_for_upgrade
		if migrate_force_refresh_calendar_cm_for_upgrade(had_existing_settings): migrated = True
		if migrate_simkl_context_menu_for_upgrade(had_existing_settings): migrated = True
		if migrate_mdblist_context_menu_for_upgrade(had_existing_settings): migrated = True
		if migrate_punchplay_context_menu_for_upgrade(had_existing_settings): migrated = True
		if migrate_external_scraper_context_menu_for_upgrade(had_existing_settings): migrated = True
		if migrate_theme_song_context_menu_for_upgrade(had_existing_settings): migrated = True
		if migrate_extras_theme_chooser_top_for_upgrade(): migrated = True
		if migrate_extras_theme_chooser_after_plot_for_upgrade(): migrated = True
		if migrate_cm_manager_order_for_upgrade(): migrated = True
		if currentsettings.get('migration.my_content_nav_mode_v136') != 'true':
			try:
				from caches.navigator_cache import migrate_my_content_nav_mode
				if migrate_my_content_nav_mode(): migrated = True
			except: pass
			settings_cache.write_db('migration.my_content_nav_mode_v136', 'true', defaults_map.get('migration.my_content_nav_mode_v136'))
			currentsettings['migration.my_content_nav_mode_v136'] = 'true'
			if load_properties: settings_cache.set_memory_cache('migration.my_content_nav_mode_v136', 'true')
		if currentsettings.get('migration.unified_list_sort') != 'true':
			# Only record the migration as done when it did not raise. The obsolete purge above
			# holds back the five legacy sort ids while this sentinel is unset, so a failed run
			# leaves both the sentinel and the source values in place and the next sync retries
			# for real. They are purged on that following sync, once the sentinel is 'true'.
			sort_migration_ok = True
			try:
				from modules.list_sort import run_sort_migration
				def _write_sort_setting(setting_id, value):
					settings_cache.write_db(setting_id, value, defaults_map.get(setting_id))
					currentsettings[setting_id] = value
					if load_properties: settings_cache.set_memory_cache(setting_id, value)
				if run_sort_migration(legacy_sort_settings, _write_sort_setting): migrated = True
				try:
					# The _strict getters raise instead of returning {} on a locked database or a corrupt
					# row. Their swallowing siblings, which the UI uses, would report "nothing stored"
					# and let the sentinel be written over preferences that were never read.
					from caches.trakt_cache import get_all_lists_custom_sort_strict
					from caches.tmdb_lists import tmdb_lists_cache
					from caches.list_sort_cache import set_override
					from modules.list_sort import migrate_legacy_stores
					from caches.personal_lists_cache import personal_lists_cache
					personal_rows = personal_lists_cache.get_all_sort_orders()
					store_overrides = migrate_legacy_stores(get_all_lists_custom_sort_strict(), personal_rows, tmdb_lists_cache.get_sort_orders_strict())
					failed = [scope for scope, spec_string in store_overrides.items() if not set_override(scope, spec_string)]
					if store_overrides: migrated = True
					if failed:
						sort_migration_ok = False
						kodi_utils.logger('sync_settings', 'legacy sort store migration: could not persist %s' % ', '.join(sorted(failed)))
				except Exception as e:
					# Swallowing this would write the sentinel on a run that saved nothing, and the per-list
					# Trakt, personal and TMDb preferences are deleted with the legacy ids on the next sync.
					# Fold it into the outer flag instead so the sentinel stays unset and the next sync retries.
					sort_migration_ok = False
					kodi_utils.logger('sync_settings', 'legacy sort store migration: %s' % e)
			except Exception as e:
				# Deliberately catches an ImportError on modules.list_sort too: the sentinel stays false, so a
				# genuinely broken install retries and logs on every sync rather than once. Do not narrow this.
				sort_migration_ok = False
				migrated = True # a partial run may already have written the mediatype defaults
				kodi_utils.logger('sync_settings', 'unified list sort migration: %s' % e)
			if sort_migration_ok:
				settings_cache.write_db('migration.unified_list_sort', 'true', defaults_map.get('migration.unified_list_sort'))
				currentsettings['migration.unified_list_sort'] = 'true'
				if load_properties: settings_cache.set_memory_cache('migration.unified_list_sort', 'true')
		for setting_id, value in list(currentsettings.items()):
			if setting_id not in defaults_map: continue
			sanitized = sanitize_setting_value(setting_id, value, defaults_map[setting_id], validate_paths=False)
			if sanitized != value:
				sanitized = sanitize_setting_value(setting_id, value, defaults_map[setting_id], validate_paths=True)
				settings_cache.write_db(setting_id, sanitized, defaults_map[setting_id])
				currentsettings[setting_id] = sanitized
				migrated = True
			if load_properties:
				settings_cache.set_memory_cache(setting_id, sanitized)
	for item in d_settings:
		setting_id = item['setting_id']
		if setting_id in currentsettings:
			continue
		setting_type = item['setting_type']
		setting_default = item['setting_default']
		setting_value = _new_setting_value(setting_id, setting_default, currentsettings, had_existing_settings, fresh_install)
		if setting_type == 'action' and 'settings_options' in item:
			if setting_id == 'aiostreams.instance':
				try:
					from apis.aiostreams_api import INSTANCE_LABELS
					name_default = INSTANCE_LABELS.get(setting_default, item['settings_options'][setting_default])
				except (ImportError, KeyError):
					name_default = item['settings_options'][setting_default]
				name_value = name_default
			else:
				name_default = item['settings_options'][setting_default]
				name_value = item['settings_options'].get(setting_value, name_default)
			insert_list_append(('%s_name' % setting_id, 'name', name_default, name_value))
		insert_list_append((setting_id, setting_type, setting_default, setting_value))
	if insert_list:
		settings_cache.set_many(insert_list, load_properties=load_properties)
		migrated = True
		if _new_settings_affect_widgets(insert_list):
			widgets_migrated = True
	if had_existing_settings:
		from modules.settings import migrate_external_scraper_slots_for_upgrade, migrate_external_scraper_run_mode_for_upgrade
		if migrate_external_scraper_slots_for_upgrade(had_existing_settings): migrated = True
		if migrate_external_scraper_run_mode_for_upgrade(had_existing_settings): migrated = True
	if migrated and had_existing_settings:
		kodi_utils.set_property(_SETTINGS_DB_MIGRATED, 'true')
	if widgets_migrated and had_existing_settings:
		kodi_utils.set_property(_SETTINGS_WIDGETS_MIGRATED, 'true')
	if load_properties:
		settings_cache.clean_database()
		bootstrap_settings_properties(force=True)
		run_deferred_setup_if_needed()
		kodi_utils.set_property(_SETTINGS_DB_SYNCED, 'true')
		mark_settings_sync_complete()
	else:
		kodi_utils.set_property(_SETTINGS_DB_SYNCED, 'true')
		mark_settings_sync_complete()
		settings_cache.clear_db_cache()
		if _properties_loaded():
			_apply_settings_properties_from_db()
	if not silent: kodi_utils.notification('Settings Cache Remade')
	return 'synced'

def set_default(setting_ids):
	if not isinstance(setting_ids, list): setting_ids = [setting_ids]
	if not kodi_utils.confirm_dialog(text='Are You Sure?', ok_label='Yes', cancel_label='No', default_control=11): return
	for setting_id in setting_ids:
		try: set_setting(setting_id, default_setting_values(setting_id)['setting_default'])
		except: pass

def set_boolean(params):
	boolean_dict = {'true': 'false', 'false': 'true'}
	setting = params['setting_id']
	set_setting(setting, boolean_dict[get_setting('nightshift.%s' % setting)])
	if setting.startswith('external_scraper.slot') and setting.endswith('.enabled'):
		try:
			from modules.settings import refresh_external_scraper_properties
			refresh_external_scraper_properties()
		except: pass

def set_string(params):
	setting_id = params['setting_id']
	current_value = get_setting('nightshift.%s' % setting_id)
	current_value = current_value.replace('empty_setting', '').replace('API_HERE', '')
	new_value = kodi_utils.kodi_dialog().input('', defaultt=current_value)
	if not new_value and not kodi_utils.confirm_dialog(text='Enter Blank Value?', ok_label='Yes', cancel_label='Re-Enter Value', default_control=11):
		return set_string(params)
	if setting_id in _CREDENTIAL_STRING_SETTINGS:
		new_value = normalize_credential_string(new_value)
	if setting_id == 'tmdb_api' and new_value and looks_like_tmdb_v4_jwt(new_value):
		kodi_utils.ok_dialog(heading='Wrong key type', text='This is a TMDb v4 Read Access Token (JWT), not the v3 API Key.[CR]Use TMDb Lists → Read Access Token for v4 tokens.')
		return set_string(params)
	if setting_id == 'playback.submaker_manifest' and new_value:
		new_value = new_value.strip()
	set_setting(setting_id, new_value or 'empty_setting')
	if setting_id in ('aiostreams.username', 'aiostreams.password', 'aiostreams.custom_url'):
		try:
			from apis.aiostreams_api import persist_active_profile
			persist_active_profile()
		except: pass
	if setting_id in ('playback.submaker_manifest', 'playback.opensubs_username', 'playback.opensubs_password'):
		try:
			refresh_settings_manager_properties()
		except: pass

def set_numeric(params):
	setting_id = params['setting_id']
	setting_values = default_setting_values(setting_id)
	values_get = setting_values.get
	min_value, max_value = int(values_get('min_value', '0')), int(values_get('max_value', '100000000000000'))
	negative_included = any((n < 0 for n in [min_value, max_value]))
	if negative_included:
		multiplier_values = [('Positive(+)', 1), ('Negative(-)', -1)]
		list_items = [{'line1': item[0]} for item in multiplier_values]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true', 'heading': 'Will this be a positive or negative number?'}
		multiplier = kodi_utils.select_dialog(multiplier_values, **kwargs)
	else: multiplier = None
	new_value = kodi_utils.kodi_dialog().input('Range [B]%s - %s[/B].' % (min_value, max_value), type=1)
	if not new_value: return
	if multiplier: new_value = str(int(float(new_value) * multiplier[1]))
	if int(new_value) < min_value or int(new_value) > max_value:
		kodi_utils.ok_dialog(text='Please Choose Between the Range [B]%s - %s[/B].' % (min_value, max_value))
		return set_numeric(params)
	set_setting(setting_id, new_value)

def set_path(params):
	setting_id = params['setting_id']
	browse_mode = int(default_setting_values(setting_id)['browse_mode'])
	current = get_setting('nightshift.%s' % setting_id)
	if browse_mode == 0:
		force_defaultt = setting_id == 'import_export_directory'
		new_value = kodi_utils.browse_directory(current, heading='Choose folder', use_defaultt=True, force_defaultt=force_defaultt)
	else:
		result = kodi_utils.kodi_dialog().browse(browse_mode, 'Choose file', '', defaultt=current or None)
		new_value = result if result and str(result).strip() else None
	if not new_value:
		return
	if browse_mode == 0:
		# Under addon_data → special://; OS-wide folders stay absolute.
		new_value = kodi_utils.portable_addon_data_path(new_value)
	set_setting(setting_id, new_value)
	if setting_id == 'import_export_directory':
		try:
			from modules import settings
			settings.ensure_import_export_directory()
		except:
			pass

def set_from_list(params):
	setting_id = params['setting_id']
	if setting_id == 'aiostreams.instance':
		from apis.aiostreams_api import instance_picker_list
		settings_list = instance_picker_list()
	elif setting_id == 'watched_indicators':
		from modules.settings import watched_provider_options
		settings_options = watched_provider_options().items()
		settings_list = [(v, k) for k, v in settings_options]
		settings_list.sort(key=lambda item: item[0].lower())
	elif setting_id == 'recommend_service':
		from modules.settings import recommend_service_options
		settings_options = recommend_service_options().items()
		settings_list = [(v, k) for k, v in settings_options]
		settings_list.sort(key=lambda item: item[0].lower())
	elif setting_id == 'playback.subs_source':
		from modules.settings import subtitles_source_options
		settings_options = subtitles_source_options().items()
		settings_list = [(v, k) for k, v in settings_options]
	elif setting_id in ('stinger_alert.alert_timing', 'autoplay_alert_timing', 'autoscrape_alert_timing'):
		from modules.settings import alert_timing_options
		settings_options = alert_timing_options(next_episode=(setting_id != 'stinger_alert.alert_timing')).items()
		settings_list = [(v, k) for k, v in settings_options]
		settings_list.sort(key=lambda item: item[0].lower())
	else:
		settings_options = default_setting_values(setting_id)['settings_options'].items()
		settings_list = [(v, k) for k, v in settings_options]
		if setting_id == 'external_scraper.run_mode':
			_mode_order = ('1', '2', '3', '0')
			settings_list.sort(key=lambda item: _mode_order.index(item[1]) if item[1] in _mode_order else 99)
	new_value = kodi_utils.select_dialog(settings_list, **{'items': json.dumps([{'line1': item[0]} for item in settings_list]), 'narrow_window': 'true'})
	if not new_value: return
	setting_value = new_value[1]
	if setting_id == 'external_scraper.run_mode' and setting_value != '1':
		mode_opts = dict(default_setting_values(setting_id)['settings_options'])
		mode_label = mode_opts.get(setting_value, '')
		current = str(get_setting('nightshift.external_scraper.run_mode', '1'))
		warning_text = (
			'Many indexers are volunteer-run community resources. '
			'[B]%s[/B] can query the same indexers multiple times. [B]Series (Fallback by Slot Order)[/B] is the recommended default.[CR][CR]'
			'Please scrape responsibly.' % mode_label
		)
		if current == '1':
			confirmed = kodi_utils.confirm_dialog(
				heading='Search Mode',
				text=warning_text,
				ok_label='Continue',
				cancel_label='Cancel',
				default_control=11,
			)
			if confirmed is None or not confirmed:
				return
		else:
			confirmed = kodi_utils.confirm_dialog(
				heading='Search Mode',
				text=warning_text,
				ok_label='Series (Fallback)',
				cancel_label='Continue',
				default_control=10,
			)
			if confirmed is None:
				return
			if confirmed:
				set_setting('external_scraper.run_mode', '1')
				try:
					settings_cache.set_memory_cache('external_scraper.run_mode', '1')
					settings_cache.set_memory_cache('external_scraper.run_mode_name', mode_opts.get('1', ''))
				except:
					pass
				return
	set_setting(setting_id, setting_value)
	# Force Home property label so Settings Manager does not keep showing the raw key (e.g. "0").
	try:
		info = default_setting_values(setting_id) or {}
		opts = info.get('settings_options') or {}
		label = opts.get(str(setting_value), str(setting_value))
		settings_cache.set_memory_cache(setting_id, str(setting_value))
		settings_cache.set_memory_cache('%s_name' % setting_id, label)
		from modules import kodi_utils as _ku
		_ku.set_property('nightshift.%s' % setting_id, str(setting_value))
		_ku.set_property('nightshift.%s_name' % setting_id, label)
	except Exception:
		pass
	if setting_id in ('tmdb_random_bag_retention', 'tmdb_random_bag_size_limit'):
		try:
			from caches.tmdb_random_bag_cache import purge_expired_and_over_limit
			purge_expired_and_over_limit(force=True)
		except Exception: pass
	if setting_id == 'external_scraper.run_mode':
		try:
			mode_opts = dict(default_setting_values(setting_id)['settings_options'])
			settings_cache.set_memory_cache(setting_id, str(setting_value))
			settings_cache.set_memory_cache('%s_name' % setting_id, mode_opts.get(str(setting_value), ''))
		except:
			pass
	# watched_indicators sync is queued from SettingsCache.set (own plugin invoker; force if empty).

def set_source_folder_path(params):
	setting_id = params['setting_id']
	current_setting = get_setting('nightshift.%s' % setting_id)
	if current_setting not in (None, 'None', ''):
		if kodi_utils.confirm_dialog(text='Enter Blank Value?', ok_label='Yes', cancel_label='Re-Enter Value', default_control=11):
			return set_setting(setting_id, 'None')
	return set_path(params)

def restore_setting_default(params):
	silent = params.get('silent', 'false') == 'true'
	if not silent and not kodi_utils.confirm_dialog(): return
	try:
		setting_id = params['setting_id']
		setting_default = default_setting_values(setting_id)['setting_default']
		set_setting(setting_id, setting_default)
	except:
		if not silent: kodi_utils.ok_dialog(text='Error restoring default setting')

# Accounts / API keys / external scraper slots kept by Default NIGHTSHIFT Settings.
_PRESERVE_SETTING_IDS = frozenset((
	# Meta accounts + OAuth
	'trakt.user', 'trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt.client', 'trakt.secret',
	'simkl.user', 'simkl.token', 'simkl.refresh', 'simkl.client',
	'mdblist.user', 'mdblist.token', 'mdblist.client', 'mdblist.refresh',
	'punchplay.user', 'punchplay.token', 'punchplay.client', 'punchplay.refresh', 'punchplay.expires', 'punchplay.device_id',
	'wetrakr.user', 'wetrakr.token',
	'tmdb.token', 'tmdb.username', 'tmdb.account_id', 'tmdb.session_id', 'tmdb.account_session_id', 'tmdb.lists_read_token',
	# API keys
	'tmdb_api', 'fanarttv_api', 'omdb_api', 'tvdb_api', 'tvdb_pin', 'rpdb_api',
	# Debrid auth (not enable/priority/cache toggles)
	'rd.token', 'rd.refresh', 'rd.client_id', 'rd.secret', 'rd.account_id',
	'pm.token', 'pm.account_id',
	'ad.token', 'ad.account_id',
	'oc.token', 'oc.account_id',
	'tb.token',
	# Direct source accounts
	'easynews_user', 'easynews_password',
	'aiostreams.username', 'aiostreams.password', 'aiostreams.custom_url', 'aiostreams.profiles', 'aiostreams.instance',
	# NZB indexer accounts (slots)
	'nzb1.enabled', 'nzb1.label', 'nzb1.url', 'nzb1.key',
	'nzb2.enabled', 'nzb2.label', 'nzb2.url', 'nzb2.key',
	'nzb3.enabled', 'nzb3.label', 'nzb3.url', 'nzb3.key',
	'nzb4.enabled', 'nzb4.label', 'nzb4.url', 'nzb4.key',
	'nzb5.enabled', 'nzb5.label', 'nzb5.url', 'nzb5.key',
	'nzb6.enabled', 'nzb6.label', 'nzb6.url', 'nzb6.key',
	'nzb7.enabled', 'nzb7.label', 'nzb7.url', 'nzb7.key',
	'nzb8.enabled', 'nzb8.label', 'nzb8.url', 'nzb8.key',
	'nzb9.enabled', 'nzb9.label', 'nzb9.url', 'nzb9.key',
	'nzb10.enabled', 'nzb10.label', 'nzb10.url', 'nzb10.key',
	'nzb11.enabled', 'nzb11.label', 'nzb11.url', 'nzb11.key',
	'nzb12.enabled', 'nzb12.label', 'nzb12.url', 'nzb12.key',
	'nzb13.enabled', 'nzb13.label', 'nzb13.url', 'nzb13.key',
	'nzb14.enabled', 'nzb14.label', 'nzb14.url', 'nzb14.key',
	'nzb15.enabled', 'nzb15.label', 'nzb15.url', 'nzb15.key',
	'nzb16.enabled', 'nzb16.label', 'nzb16.url', 'nzb16.key',
	'nzb17.enabled', 'nzb17.label', 'nzb17.url', 'nzb17.key',
	'nzb18.enabled', 'nzb18.label', 'nzb18.url', 'nzb18.key',
	'nzb19.enabled', 'nzb19.label', 'nzb19.url', 'nzb19.key',
	'nzb20.enabled', 'nzb20.label', 'nzb20.url', 'nzb20.key',
	'nzb21.enabled', 'nzb21.label', 'nzb21.url', 'nzb21.key',
	'nzb22.enabled', 'nzb22.label', 'nzb22.url', 'nzb22.key',
	'nzb23.enabled', 'nzb23.label', 'nzb23.url', 'nzb23.key',
	'nzb24.enabled', 'nzb24.label', 'nzb24.url', 'nzb24.key',
	'nzb25.enabled', 'nzb25.label', 'nzb25.url', 'nzb25.key',
	# Direct Usenet (NNTP) providers
	'usenet1.enabled', 'usenet1.host', 'usenet1.port', 'usenet1.ssl', 'usenet1.user', 'usenet1.password',
	'usenet2.enabled', 'usenet2.host', 'usenet2.port', 'usenet2.ssl', 'usenet2.user', 'usenet2.password',
	'usenet3.enabled', 'usenet3.host', 'usenet3.port', 'usenet3.ssl', 'usenet3.user', 'usenet3.password',
	'usenet4.enabled', 'usenet4.host', 'usenet4.port', 'usenet4.ssl', 'usenet4.user', 'usenet4.password',
	'usenet5.enabled', 'usenet5.host', 'usenet5.port', 'usenet5.ssl', 'usenet5.user', 'usenet5.password',
	'usenet6.enabled', 'usenet6.host', 'usenet6.port', 'usenet6.ssl', 'usenet6.user', 'usenet6.password',
	'usenet7.enabled', 'usenet7.host', 'usenet7.port', 'usenet7.ssl', 'usenet7.user', 'usenet7.password',
	'usenet8.enabled', 'usenet8.host', 'usenet8.port', 'usenet8.ssl', 'usenet8.user', 'usenet8.password',
	'usenet9.enabled', 'usenet9.host', 'usenet9.port', 'usenet9.ssl', 'usenet9.user', 'usenet9.password',
	'usenet10.enabled', 'usenet10.host', 'usenet10.port', 'usenet10.ssl', 'usenet10.user', 'usenet10.password',
	'usenet11.enabled', 'usenet11.host', 'usenet11.port', 'usenet11.ssl', 'usenet11.user', 'usenet11.password',
	'usenet12.enabled', 'usenet12.host', 'usenet12.port', 'usenet12.ssl', 'usenet12.user', 'usenet12.password',
	'usenet13.enabled', 'usenet13.host', 'usenet13.port', 'usenet13.ssl', 'usenet13.user', 'usenet13.password',
	'usenet14.enabled', 'usenet14.host', 'usenet14.port', 'usenet14.ssl', 'usenet14.user', 'usenet14.password',
	'usenet15.enabled', 'usenet15.host', 'usenet15.port', 'usenet15.ssl', 'usenet15.user', 'usenet15.password',
	'usenet16.enabled', 'usenet16.host', 'usenet16.port', 'usenet16.ssl', 'usenet16.user', 'usenet16.password',
	'usenet17.enabled', 'usenet17.host', 'usenet17.port', 'usenet17.ssl', 'usenet17.user', 'usenet17.password',
	'usenet18.enabled', 'usenet18.host', 'usenet18.port', 'usenet18.ssl', 'usenet18.user', 'usenet18.password',
	'usenet19.enabled', 'usenet19.host', 'usenet19.port', 'usenet19.ssl', 'usenet19.user', 'usenet19.password',
	'usenet20.enabled', 'usenet20.host', 'usenet20.port', 'usenet20.ssl', 'usenet20.user', 'usenet20.password',
	'usenet21.enabled', 'usenet21.host', 'usenet21.port', 'usenet21.ssl', 'usenet21.user', 'usenet21.password',
	'usenet22.enabled', 'usenet22.host', 'usenet22.port', 'usenet22.ssl', 'usenet22.user', 'usenet22.password',
	'usenet23.enabled', 'usenet23.host', 'usenet23.port', 'usenet23.ssl', 'usenet23.user', 'usenet23.password',
	'usenet24.enabled', 'usenet24.host', 'usenet24.port', 'usenet24.ssl', 'usenet24.user', 'usenet24.password',
	'usenet25.enabled', 'usenet25.host', 'usenet25.port', 'usenet25.ssl', 'usenet25.user', 'usenet25.password',
	# Subtitles accounts / APIs
	'playback.opensubs_api_key', 'playback.opensubs_username', 'playback.opensubs_password', 'playback.opensubs_token',
	'playback.submaker_manifest',
	# Legacy single external scraper module pointers (slots covered below)
	'external_scraper.module', 'external_scraper.name',
))

def _is_preserved_setting(setting_id):
	if setting_id in _PRESERVE_SETTING_IDS:
		return True
	# External scraper slots: keep module / name / enabled only (not run_mode or other scraper prefs).
	if setting_id.startswith('external_scraper.slot') and (
			setting_id.endswith('.module') or setting_id.endswith('.name') or setting_id.endswith('.enabled')):
		return True
	return False

def _remove_addon_data_path(target):
	"""Delete a file/folder under addon_data. If locked, rename aside so a fresh path can be created.
	Returns True when the original path has no live (non-.wiped) content left."""
	from os import path as ospath
	import gc
	import os
	import shutil
	import time
	if not target:
		return True

	def _gone(path):
		try:
			if ospath.exists(path): return False
		except: pass
		try:
			if kodi_utils.path_exists(path): return False
		except: pass
		return True

	def _has_live_content(path):
		"""True if path exists as a live file, or a dir with any non-.wiped entry."""
		if _gone(path):
			return False
		base = ospath.basename(path.rstrip('/\\'))
		if base and '.wiped' in base:
			return False
		try:
			if ospath.isfile(path):
				return True
		except: pass
		try:
			if ospath.isdir(path):
				for dirpath, dirnames, filenames in os.walk(path):
					for name in list(filenames) + list(dirnames):
						if name and name not in ('.', '..') and '.wiped' not in name:
							return True
				return False
		except: pass
		# xbmcvfs-only path we could not classify — treat as live.
		return True

	def _delete_tree(path):
		# Bottom-up file delete first — more reliable than a single rmtree on Windows locks.
		try:
			if ospath.isfile(path):
				os.remove(path)
				return
			if ospath.isdir(path):
				for dirpath, dirnames, filenames in os.walk(path, topdown=False):
					for name in filenames:
						fp = ospath.join(dirpath, name)
						try: os.remove(fp)
						except Exception:
							try: kodi_utils.delete_file(fp)
							except: pass
					for name in dirnames:
						dp = ospath.join(dirpath, name)
						try: os.rmdir(dp)
						except Exception:
							try: kodi_utils.delete_folder(dp, force=True)
							except: pass
				try: os.rmdir(path)
				except Exception:
					shutil.rmtree(path, ignore_errors=True)
				return
		except Exception:
			pass
		try:
			kodi_utils.delete_folder(path, force=True)
		except:
			try: kodi_utils.delete_file(path)
			except: pass

	def _quarantine(path):
		base = path.rstrip('/\\')
		for n in range(0, 8):
			dest = '%s.wiped' % base if n == 0 else '%s.wiped%d' % (base, n)
			if ospath.exists(dest) or kodi_utils.path_exists(dest):
				continue
			try:
				os.rename(base, dest)
				return not _has_live_content(path)
			except Exception:
				try:
					kodi_utils.rename_file(base, dest)
					return not _has_live_content(path)
				except Exception:
					pass
		# Folder rename blocked by an open file — quarantine children, then retry the folder.
		if ospath.isdir(base):
			try:
				for name in os.listdir(base):
					if not name or '.wiped' in name:
						continue
					child = ospath.join(base, name)
					if not _has_live_content(child):
						continue
					_delete_tree(child)
					if not _has_live_content(child):
						continue
					cbase = child.rstrip('/\\')
					for n in range(0, 8):
						cdest = '%s.wiped' % cbase if n == 0 else '%s.wiped%d' % (cbase, n)
						if ospath.exists(cdest):
							continue
						try:
							os.rename(cbase, cdest)
							break
						except Exception:
							pass
			except Exception:
				pass
			_delete_tree(base)
			if not _has_live_content(path):
				return True
			for n in range(0, 8):
				dest = '%s.wiped' % base if n == 0 else '%s.wiped%d' % (base, n)
				if ospath.exists(dest):
					continue
				try:
					os.rename(base, dest)
					return not _has_live_content(path)
				except Exception:
					pass
		return not _has_live_content(path)

	if not _has_live_content(target):
		return True
	gc.collect()
	for _ in range(3):
		_delete_tree(target)
		if not _has_live_content(target):
			return True
		time.sleep(0.2)
		gc.collect()
	# Locked by Kodi/services — move aside so make_databases can recreate the live name.
	return _quarantine(target)

def reset_settings_keep_accounts(params={}):
	"""Factory-reset settings values while keeping accounts, API keys, and external scraper slots."""
	heading = 'Default NIGHTSHIFT Settings'
	if not kodi_utils.confirm_dialog(
			heading=heading,
			text='Reset all NIGHTSHIFT settings to defaults?[CR][CR]'
				 'Keeps meta/debrid/direct accounts, API keys, subtitle logins, NZB indexer accounts, '
				 'and External Scraper slots.[CR][CR]Personal lists, caches, and watched data are not wiped.',
			ok_label='Continue', cancel_label='Cancel', default_control=11, scroll=True):
		return
	if not kodi_utils.confirm_dialog(
			heading=heading,
			text='Are you sure?[CR][CR]This cannot be undone (except by restoring a settings backup).',
			ok_label='Reset Settings', cancel_label='Cancel', default_control=11, scroll=True):
		return
	try:
		progress = kodi_utils.progress_dialog()
		progress.update('Saving accounts…', 5)
		all_settings = settings_cache.get_all()
		preserved = {sid: val for sid, val in all_settings.items() if _is_preserved_setting(sid)}
		progress.update('Clearing settings…', 20)
		dbcon = connect_database('settings_db')
		dbcon.execute('DELETE FROM settings')
		try: dbcon.commit()
		except: pass
		try: dbcon.close()
		except: pass
		settings_cache._db_cache.clear()
		clear_settings_boot_state(clear_deferred=False)
		progress.update('Rebuilding defaults…', 45)
		sync_settings({'silent': 'true', 'load_properties': 'false', 'force': 'true'})
		progress.update('Restoring accounts…', 70)
		for sid, val in preserved.items():
			try:
				info = default_setting_values(sid)
				settings_cache.write_db(sid, val, info)
			except: pass
		progress.update('Refreshing…', 90)
		clear_settings_boot_state(clear_deferred=False)
		sync_settings({'silent': 'true', 'load_properties': 'true', 'force': 'true'})
		try:
			from modules.settings import refresh_external_scraper_properties
			refresh_external_scraper_properties()
		except: pass
		try:
			from modules.service_expiry import publish_settings_expiry_properties
			publish_settings_expiry_properties()
		except: pass
		progress.close()
		kodi_utils.ok_dialog(heading=heading, text='Settings restored to defaults.[CR]Accounts and API keys were kept.', scroll=True)
	except Exception as e:
		try: progress.close()
		except: pass
		kodi_utils.logger('reset_settings_keep_accounts', str(e))
		kodi_utils.ok_dialog(heading=heading, text='Error resetting settings.[CR]%s' % e, scroll=True)

def reset_addon_data(params={}):
	"""Wipe NIGHTSHIFT addon_data and rebuild empty databases / default settings."""
	from os import path as ospath
	import gc
	heading = 'Reset NIGHTSHIFT'
	if not kodi_utils.confirm_dialog(
			heading=heading,
			text='Wipe all NIGHTSHIFT addon data and rebuild from scratch?[CR][CR]'
				 'Deletes settings, caches, watched/progress DBs, personal lists, favorites, '
				 'episode groups, navigator customisation, and any downloads stored inside NIGHTSHIFT addon data.[CR][CR]'
				 'You will need to re-authorise accounts and re-enter API keys.',
			ok_label='Continue', cancel_label='Cancel', default_control=11, scroll=True):
		return
	if not kodi_utils.confirm_dialog(
			heading=heading,
			text='Final confirmation.[CR][CR]This permanently deletes NIGHTSHIFT addon data.',
			ok_label='Wipe & Rebuild', cancel_label='Cancel', default_control=11, scroll=True):
		return
	progress = None
	paused = False
	try:
		progress = kodi_utils.progress_dialog()
		progress.update('Pausing services…', 5)
		kodi_utils.set_property('nightshift.pause_services', 'true')
		paused = True
		# Give monitors a moment to leave DB operations.
		kodi_utils.sleep(1000)
		profile = kodi_utils.addon_profile()
		if not profile:
			raise Exception('Addon profile path unavailable')
		# Drop in-process DB handles before deleting files under us.
		settings_cache.clear_db_cache()
		clear_settings_boot_state(clear_deferred=False)
		gc.collect()
		progress.update('Wiping addon data…', 20)
		folders, files = kodi_utils.list_dirs(profile)
		# Remove prior quarantine leftovers first so they do not accumulate.
		stale = [name for name in list(files) + list(folders) if name and '.wiped' in name]
		for name in stale:
			_remove_addon_data_path(ospath.join(profile, name))
		folders, files = kodi_utils.list_dirs(profile)
		targets = [ospath.join(profile, name) for name in list(files) + list(folders)
					if name not in (None, '', '.', '..') and '.wiped' not in (name or '')]
		total = max(1, len(targets))
		for idx, target in enumerate(targets):
			_remove_addon_data_path(target)
			progress.update('Wiping addon data…', 20 + int(50 * (idx + 1) / total))
		# Confirm live names are gone (empty dirs / .wiped leftovers are fine).
		remain_folders, remain_files = kodi_utils.list_dirs(profile)
		candidates = [name for name in list(remain_files) + list(remain_folders)
						if name not in (None, '', '.', '..') and '.wiped' not in (name or '')]
		live = []
		for name in candidates:
			if not _remove_addon_data_path(ospath.join(profile, name)):
				live.append(name)
		if live:
			raise Exception(
				'Some files are still locked.[CR]Close Settings / NIGHTSHIFT windows, restart Kodi, then retry.[CR][CR]%s'
				% ', '.join(sorted(live)[:8]))
		# Remove empty leftover folders (e.g. download dirs whose contents wiped).
		try:
			import os
			remain_folders, _remain_files = kodi_utils.list_dirs(profile)
			for name in remain_folders:
				if not name or name in ('.', '..'):
					continue
				path = ospath.join(profile, name)
				try:
					if ospath.isdir(path) and not os.listdir(path):
						os.rmdir(path)
				except Exception:
					try: kodi_utils.delete_folder(path, force=False)
					except: pass
		except: pass
		progress.update('Rebuilding databases…', 75)
		if not kodi_utils.path_exists(profile):
			kodi_utils.make_directories(profile)
		from caches.base_cache import make_databases, remove_old_databases
		make_databases()
		try: remove_old_databases()
		except: pass
		progress.update('Creating default settings…', 88)
		clear_settings_boot_state(clear_deferred=True)
		sync_settings({'silent': 'true', 'load_properties': 'true', 'force': 'true'})
		# Best-effort cleanup of quarantined leftovers after fresh DBs exist.
		try:
			q_folders, q_files = kodi_utils.list_dirs(profile)
			for name in list(q_files) + list(q_folders):
				if name and '.wiped' in name:
					_remove_addon_data_path(ospath.join(profile, name))
		except: pass
		progress.close()
		kodi_utils.ok_dialog(
			heading=heading,
			text='NIGHTSHIFT addon data was wiped and rebuilt.[CR][CR]'
				 'Re-authorise accounts under Meta Accounts / Torrent Sources / Direct Sources.[CR][CR]'
				 'A full Kodi restart is recommended.',
			scroll=True)
	except Exception as e:
		try:
			if progress: progress.close()
		except: pass
		kodi_utils.logger('reset_addon_data', str(e))
		kodi_utils.ok_dialog(
			heading=heading,
			text='Error wiping addon data.[CR][CR]%s' % e,
			scroll=True)
	finally:
		if paused:
			try: kodi_utils.clear_property('nightshift.pause_services')
			except: pass

def default_setting_values(setting_id):
	if 'nightshift.' in setting_id: setting_id = setting_id.replace('nightshift.', '')
	return _get_defaults_map().get(setting_id)

def _provider_watched_db_empty(provider_index):
	try:
		from modules.watched_status import get_database
		dbcon = get_database(int(provider_index))
		return dbcon.execute('SELECT 1 FROM watched LIMIT 1').fetchone() is None
	except:
		return True

def _sync_watched_provider_on_switch(provider_value):
	"""When Watched Status Provider switches to a remote service: activity-gated sync.
	Force full pull only if that provider's local watched table is empty (first enable).
	Stale-but-populated DBs catch up via activities / Phase 2. Tools > Force Sync still wipes.
	Queued as its own plugin invoker so Settings / authorise can return immediately.
	"""
	try:
		provider = int(provider_value)
	except Exception:
		return
	modes = {
		1: 'trakt.trakt_sync_activities',
		2: 'simkl.simkl_sync_activities',
		3: 'mdblist.mdblist_sync_activities',
		4: 'punchplay.punchplay_sync_activities',
	}
	mode = modes.get(provider)
	if not mode:
		return
	force = _provider_watched_db_empty(provider)
	params = {'mode': mode, 'force_update': 'true' if force else 'false'}
	if provider == 4 and force:
		params['notify'] = 'true'
	try:
		kodi_utils.run_plugin(params, block=False)
	except Exception:
		pass

def _get_defaults_map():
	global _DEFAULTS_MAP
	if _DEFAULTS_MAP is None: _DEFAULTS_MAP = {i['setting_id']: i for i in default_settings()}
	return _DEFAULTS_MAP

def default_settings():
	global _DEFAULTS_LIST
	if _DEFAULTS_LIST is not None: return _DEFAULTS_LIST
	_DEFAULTS_LIST = [
#===============================================================================#
#====================================GENERAL====================================#
#===============================================================================#
#==================== General
{'setting_id': 'auto_start_nightshift', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'addon_icon_choice', 'setting_type': 'string', 'setting_default': 'resources/media/addon_icons/icon.png'},
{'setting_id': 'default_addon_fanart', 'setting_type': 'path', 'setting_default': kodi_utils.addon_fanart(), 'browse_mode': '2'},
{'setting_id': 'limit_concurrent_threads', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'max_threads', 'setting_type': 'action', 'setting_default': '20', 'min_value': '10', 'max_value': '250'},
{'setting_id': 'related_fallback', 'setting_type': 'action', 'setting_default': 'both', 'settings_options': {'both': 'TMDb + Simkl (anime)', 'tmdb': 'TMDb only', 'simkl': 'Simkl only (anime)', 'off': 'Off'}},
{'setting_id': 'prewarm_lists', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Window Theme
{'setting_id': 'window_theme', 'setting_type': 'string', 'setting_default': 'CC1F2020'},
{'setting_id': 'window_theme_opacity', 'setting_type': 'string', 'setting_default': 'CC'},
#==================== Watched Status Provider
{'setting_id': 'watched_indicators', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'3': 'MDBList', '4': 'PunchPlay', '0': 'NIGHTSHIFT', '2': 'Simkl', '1': 'Trakt'}},
#======+============= MDBList Cache
{'setting_id': 'mdblist.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'mdblist.client', 'setting_type': 'string', 'setting_default': 'API_HERE'},
{'setting_id': 'mdblist.token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'mdblist.refresh', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'mdblist.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'mdblist.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
#======+============= PunchPlay Cache
{'setting_id': 'punchplay.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'punchplay.client', 'setting_type': 'string', 'setting_default': 'API_HERE'},
{'setting_id': 'punchplay.token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'punchplay.refresh', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'punchplay.expires', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'punchplay.device_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'punchplay.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'punchplay.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
#======+============= Simkl Cache
{'setting_id': 'simkl.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'simkl.client', 'setting_type': 'string', 'setting_default': 'API_HERE'},
{'setting_id': 'simkl.token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'simkl.refresh', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'simkl.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'simkl.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'simkl.cm_menu_migrated', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'mdblist.cm_menu_migrated', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'punchplay.cm_menu_migrated', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external_scraper.cm_menu_migrated', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'cm_manager_order_migrated', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'cm_manager_order_migrated_v2', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'cm_manager_order_migrated_v3', 'setting_type': 'boolean', 'setting_default': 'false'},
#======+============= WeTrakr (scrobble only)
{'setting_id': 'wetrakr.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'wetrakr.token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'wetrakr.scrobble', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'wetrakr.scrobble_threshold', 'setting_type': 'action', 'setting_default': '90', 'min_value': '50', 'max_value': '99'},
#======+============= Trakt Cache
{'setting_id': 'trakt.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'trakt.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== UTC Time Offset
{'setting_id': 'datetime.offset', 'setting_type': 'action', 'setting_default': '0', 'min_value': '-15', 'max_value': '15'},
#==================== Downloads
{'setting_id': 'movie_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.nightshift/Movies Downloads/', 'browse_mode': '0'},
{'setting_id': 'tvshow_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.nightshift/TV Show Downloads/', 'browse_mode': '0'},
{'setting_id': 'premium_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.nightshift/Premium Downloads/', 'browse_mode': '0'},
{'setting_id': 'image_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.nightshift/Image Downloads/', 'browse_mode': '0'},
{'setting_id': 'import_export_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.nightshift/Import Export/', 'browse_mode': '0'},
#================================================================================#
#===================================MAINTENANCE==================================#
#================================================================================#
#==================== Thumbnail Cache Maintenance
{'setting_id': 'thumbnail_cleanup_enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'thumbnail_cleanup_interval', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
    '0': 'Off', '1': 'Every Boot', '7': 'Weekly (7 Days)', '14': 'Bi-Weekly (14 Days)', '30': 'Monthly (30 Days)'}},
{'setting_id': 'thumbnail_cleanup_last_run', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'thumbnail_cleanup_last_run_name', 'setting_type': 'name', 'setting_default': 'Never'},
{'setting_id': 'tmdb_random_bag_retention', 'setting_type': 'action', 'setting_default': '7', 'settings_options': {'1': '1 Day', '7': '7 Days', '14': '14 Days'}},
{'setting_id': 'tmdb_random_bag_size_limit', 'setting_type': 'action', 'setting_default': '250', 'settings_options': {'50': '50 MB', '100': '100 MB', '250': '250 MB', '1024': '1 GB', '10240': '10 GB'}},
#================================================================================#
#====================================FEATURES====================================#
#================================================================================#
#==================== Extras
{'setting_id': 'extras.enable_extra_ratings', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'extras.enabled_ratings', 'setting_type': 'string', 'setting_default': 'Meta, Tom/Critic, Tom/User, IMDb, TMDb'},
{'setting_id': 'extras.enable_item_ratings', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'extras.enable_scrollbars', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Special Open Actions
{'setting_id': 'media_open_action_movie', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Open Extras', '2': 'Open Movie Set', '3': 'Both'}},
{'setting_id': 'media_open_action_tvshow', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Open Extras'}},
{'setting_id': 'media_open_action_skip_inprogress_movie', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'media_open_action_skip_inprogress_tvshow', 'setting_type': 'boolean', 'setting_default': 'false'},


#==================================================================================#
#====================================CONTENT=======================================#
#==================================================================================#
#==================== General
{'setting_id': 'paginate.lists', 'setting_type': 'action', 'setting_default': '3', 'settings_options': {'0': 'Off', '1': 'Within Addon Only', '2': 'Widgets Only', '3': 'Both'}},
{'setting_id': 'paginate.limit_addon', 'setting_type': 'action', 'setting_default': '100'},
{'setting_id': 'paginate.limit_widgets', 'setting_type': 'action', 'setting_default': '100'},
{'setting_id': 'paginate.jump_to', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'ignore_articles', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'recommend_service', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Recommended (TMDb)', '1': 'More Like This (IMDb)',
'3': 'Related (Trakt)'}},
{'setting_id': 'recommend_seed', 'setting_type': 'action', 'setting_default': '5', 'settings_options': {'1': 'Last Watched Only', '2': 'Last 2 Watched',
'3': 'Last 3 Watched', '4': 'Last 4 Watched', '5': 'Last 5 Watched', '6': 'Last 6 Watched', '7': 'Last 7 Watched', '8': 'Last 8 Watched',
'9': 'Last 9 Watched', '10': 'Last 10 Watched'}},
{'setting_id': 'mpaa_region', 'setting_type': 'string', 'setting_default': 'US'},
{'setting_id': 'lists_cache_duraton', 'setting_type': 'string', 'setting_default': '24'},
{'setting_id': 'tmdb.premieres_sort', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Popularity', '1': 'Newest First'}},
{'setting_id': 'tv_progress_location', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Watched', '1': 'In Progress', '2': 'Both'}},
{'setting_id': 'show_specials', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'exclude_specials_progress', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'use_season_name', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'default_all_episodes', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'If Only One Season', '2': 'Always'}},
{'setting_id': 'hide_episode_thumb', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'hide_episode_plot', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'episodes.include_airdate', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'show_loading_plot', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'include_anime_tvshow', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'show_public_calendars', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'public_calendar_include_anime', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'public_tv_calendar_source', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Simkl', '1': 'Trakt'}},
{'setting_id': 'public_calendar_removed_tv', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'public_calendar_removed_anime', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'public_calendar_max_items', 'setting_type': 'action', 'setting_default': '250', 'min_value': '0', 'max_value': '2000'},
{'setting_id': 'public_calendar_cache_list', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'anime.seasons_episode_group_fallback', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'show_unaired_watchlist', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'meta_filter', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'use_viewtypes', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'manual_viewtypes', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'view.main', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.movies', 'setting_type': 'string', 'setting_default': '500'},
{'setting_id': 'view.tvshows', 'setting_type': 'string', 'setting_default': '500'},
{'setting_id': 'view.seasons', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.episodes', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.episodes_single', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.premium', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'cloud_debug', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb_debug', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Contents Sort Order For Watched Progress
{'setting_id': 'sort.progress', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Recently Watched'}},
{'setting_id': 'sort.watched', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Recently Watched'}},
#==================== Contents Sort Order Defaults (per media type, all lists)
{'setting_id': 'sort.default.movies', 'setting_type': 'string', 'setting_default': 'title:asc'},
{'setting_id': 'sort.default.movies_name', 'setting_type': 'name', 'setting_default': 'Title (ascending)'},
{'setting_id': 'sort.default.shows', 'setting_type': 'string', 'setting_default': 'title:asc'},
{'setting_id': 'sort.default.shows_name', 'setting_type': 'name', 'setting_default': 'Title (ascending)'},
#==================== Personal Lists
{'setting_id': 'personal_list.sort_unseen_to_top', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'personal_list.highlight_unseen', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'personal_list.unseen_highlight', 'setting_type': 'string', 'setting_default': 'FF4DDBFF'},
{'setting_id': 'personal_list.show_author', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Widgets
{'setting_id': 'widget_refresh_timer', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'widget_refresh_notification', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'widget_hide_watched', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'widget_hide_watched_fill', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'widget_hide_next_page', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== RPDb Ratings Posters
{'setting_id': 'rpdb_enabled', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Movies', '2': 'TV Shows', '3': 'Both'}},
{'setting_id': 'rpdb_format', 'setting_type': 'string', 'setting_default': ''},
#==================== Context Menu
{'setting_id': 'context_menu.enabled', 'setting_type': 'string',
'setting_default': 'extras,theme_song,options,playback_options,external_scraper_settings,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,in_trakt_list,' \
'mdblist_manager,punchplay_manager,simkl_manager,tmdb_manager,trakt_manager,personal_manager,favorites_manager,mark_watched,unmark_previous_episode,force_refresh_calendar,exit,refresh,reload'},
{'setting_id': 'context_menu.order', 'setting_type': 'string',
'setting_default': 'extras,theme_song,options,playback_options,external_scraper_settings,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,in_trakt_list,' \
'mdblist_manager,punchplay_manager,simkl_manager,tmdb_manager,trakt_manager,personal_manager,favorites_manager,mark_watched,unmark_previous_episode,force_refresh_calendar,exit,refresh,reload'},


#==================================================================================#
#====================================SINGLE EPISODE LISTS==========================#
#==================================================================================#
#==================== General
{'setting_id': 'single_ep_display', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TITLE - SxE. EPISODE', '1': 'SxE. EPISODE', '2': 'EPISODE'}},
{'setting_id': 'single_ep_display_widget', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'TITLE - SxE. EPISODE', '1': 'SxE. EPISODE', '2': 'EPISODE'}},
{'setting_id': 'single_ep_widget_omit_tvshowtitle', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'single_ep_widget_omit_season_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'single_ep_unwatched_episodes', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'single_ep_unwatched_in_title', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Next Episodes
{'setting_id': 'nextep.method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Last Aired', '1': 'Last Watched'}},
{'setting_id': 'nextep.sort_type', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Recently Watched', '1': 'Airdate', '2': 'Title'}},
{'setting_id': 'nextep.sort_order', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Descending', '1': 'Ascending'}},
{'setting_id': 'nextep.limit_history', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nextep.limit', 'setting_type': 'action', 'setting_default': '100', 'min_value': '1', 'max_value': '200'},
{'setting_id': 'nextep.include_unwatched', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Watchlist', '2': 'Favorites', '3': 'Both'}},
{'setting_id': 'nextep.include_airdate', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nextep.airing_today', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nextep.include_unaired', 'setting_type': 'boolean', 'setting_default': 'false'},
#======+============= Calendars (MDBList + PunchPlay + Simkl + Trakt — shared episode-list UI)
{'setting_id': 'trakt.flatten_episodes', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'trakt.calendar_display', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TITLE - SxE. EPISODE', '1': 'SxE. EPISODE', '2': 'EPISODE'}},
{'setting_id': 'trakt.calendar_display_widget', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'TITLE - SxE. EPISODE', '1': 'SxE. EPISODE', '2': 'EPISODE'}},
{'setting_id': 'trakt.calendar_sort_order', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Descending', '1': 'Ascending'}},
{'setting_id': 'trakt.calendar_date_labels', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'Words / YYYY-MM-DD', '7': 'Words / MM-DD-YYYY', '8': 'Words / DD-MM-YYYY',
	'3': 'YYYY-MM-DD', '1': 'MM-DD-YYYY', '2': 'DD-MM-YYYY',
	'6': 'Day + YYYY-MM-DD', '4': 'Day + MM-DD-YYYY', '5': 'Day + DD-MM-YYYY'}},
{'setting_id': 'trakt.calendar_previous_days', 'setting_type': 'action', 'setting_default': '7', 'min_value': '0', 'max_value': '14'},
{'setting_id': 'trakt.calendar_future_days', 'setting_type': 'action', 'setting_default': '7', 'min_value': '0', 'max_value': '14'},


#=====================================================================================#
#====================================META ACCOUNTS====================================#
#=====================================================================================#
#==================== Trakt
#==================== Trakt
{'setting_id': 'trakt.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'trakt.client', 'setting_type': 'string', 'setting_default': 'API_HERE'},
{'setting_id': 'trakt.secret', 'setting_type': 'string', 'setting_default': 'API_HERE'},
#==================== TMDb API
{'setting_id': 'tmdb_api', 'setting_type': 'string', 'setting_default': 'API_HERE'},
#==================== TMDb Lists
{'setting_id': 'tmdb.lists_read_token', 'setting_type': 'string', 'setting_default': 'API_HERE'},
{'setting_id': 'tmdb.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.username', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== Fanart.tv
{'setting_id': 'fanarttv_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== TVDB v4 (episode orders)
{'setting_id': 'tvdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tvdb_first', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'tvdb_pin', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== OMDb
{'setting_id': 'omdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== RPDb
{'setting_id': 'rpdb_api', 'setting_type': 'string', 'setting_default': 'API_HERE'},
#==================== Google API


#=====================================================================================#
#====================================STREAMING ACCOUNTS===============================#
#=====================================================================================#
#==================== External
{'setting_id': 'provider.external', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external_scraper.name', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot1.module', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot1.name', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot1.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external_scraper.slot2.module', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot2.name', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot2.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external_scraper.slot3.module', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot3.name', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'external_scraper.slot3.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external_scraper.run_mode', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'1': 'Series (Fallback by Slot Order)', '2': 'Series (All Slots in Order)', '3': 'Primary Slot + Parallel Fallback', '0': 'Parallel (All Enabled Slots)'}},
{'setting_id': 'provider.internal', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.comet', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'comet.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'Goldy — https://comet.feels.legal',
	'1': 'Stremio.ru — https://comet.stremio.ru',
	'2': 'Midnight — https://cometfortheweebs.midnightignite.me',
	'3': 'Custom — set URL below',
}},
{'setting_id': 'comet.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'comet.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'comet.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.torrentio', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'torrentio.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'https://torrentio.strem.fun',
	'1': 'Custom — set URL below',
}},
{'setting_id': 'torrentio.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'torrentio.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'torrentio.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.torz', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'torz.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'Kuu-lection — https://stremthru.stremio.ru',
	'1': 'Munif — https://stremthru.13377001.xyz',
	'2': 'Midnight — https://stremthrufortheweebs.midnightignite.me',
	'3': 'Custom — set URL below',
}},
{'setting_id': 'torz.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'torz.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'torz.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.nyaa', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nyaa.category', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'All categories',
	'1': 'Anime (English-translated)',
	'2': 'Anime (all)',
}},
{'setting_id': 'nyaa.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nyaa.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.animetosho', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'animetosho.nzb', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'animetosho.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'animetosho.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.mediafusion', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'mediafusion.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'Midnight — https://mediafusionfortheweebs.midnightignite.me',
	'1': 'ElfHosted — https://mediafusion.elfhosted.com',
	'2': 'Custom — set URL below',
}},
{'setting_id': 'mediafusion.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'mediafusion.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'mediafusion.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.zilean', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'zilean.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'Stremio.ru — https://zilean.stremio.ru',
	'1': 'Midnight — https://zileanfortheweebs.midnightignite.me',
	'2': 'Custom — set URL below',
}},
{'setting_id': 'zilean.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'zilean.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'zilean.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.piratebay', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'piratebay.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'https://apibay.org',
	'1': 'Custom — set URL below',
}},
{'setting_id': 'piratebay.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'piratebay.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'piratebay.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.knaben', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'knaben.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'https://api.knaben.org',
	'1': 'Custom — set URL below',
}},
{'setting_id': 'knaben.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'knaben.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'knaben.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.torrentdownloads', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'torrentdownloads.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'https://www.torrentdownloads.pro',
	'1': 'Custom — set URL below',
}},
{'setting_id': 'torrentdownloads.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'torrentdownloads.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'torrentdownloads.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'migration.external_scraper_slots_v160', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'migration.cache_check_pm_oc_tb_v129e', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'migration.ad_cache_check_removed_v173', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'migration.my_content_nav_mode_v136', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'migration.unified_list_sort', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Real Debrid
{'setting_id': 'rd.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'rd.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'rd.cache_check', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'rd.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.real-debrid', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.rd_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'rd_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.rd_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.rd_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_rdcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'rd.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
{'setting_id': 'rd.alternate_base_url', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'rd.free_active_slot', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Premiumize
{'setting_id': 'pm.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'pm.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm.cache_check', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'pm.include_uncached', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.premiumize.me', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_pmcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'pm.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== All Debrid
{'setting_id': 'ad.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'ad.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'ad.cache_check', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'ad.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.alldebrid', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.ad_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'ad_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.ad_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.ad_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_adcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'ad.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== Offcloud
{'setting_id': 'oc.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'oc.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'oc.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'oc.cache_check', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'oc.include_uncached', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'store_resolved_to_cloud.offcloud', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'oc.notify_cloud_ready', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.oc_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'oc_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.oc_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.oc_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_occloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'oc.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== TorBox
{'setting_id': 'tb.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tb.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'tb.cache_check', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'tb.include_uncached', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'store_resolved_to_cloud.torbox', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'tb.notify_cloud_ready', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'provider.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'tb_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_tbcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'tb.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== EasyNews
{'setting_id': 'provider.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'services.expiry_alert_days', 'setting_type': 'action', 'setting_default': '7', 'min_value': '0', 'max_value': '90'},
{'setting_id': 'services.expiry_alert_state', 'setting_type': 'string', 'setting_default': '{}'},
{'setting_id': 'services.expiry_alert.ad', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.easynews', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.oc', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.pm', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.rd', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.tb', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.nzb', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'services.expiry_alert.usenet', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews_user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'easynews_password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'easynews.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.filter_lang', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews.exclude_adult', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews.lang_filters', 'setting_type': 'string', 'setting_default': 'eng'},
{'setting_id': 'easynews.refresh_credentials', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.lang_include_unknown', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.fallback_search', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.search_width', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Focused', '1': 'Balanced', '2': 'Broad'}},
{'setting_id': 'check.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'en.priority', 'setting_type': 'action', 'setting_default': '7', 'min_value': '1', 'max_value': '10'},
#==================== AIOStreams
{'setting_id': 'provider.aiostreams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'aiostreams.instance', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {
	'0': 'Kuu — https://aiostreams.stremio.ru',
	'1': 'Viren — https://aiostreams.viren070.me',
	'2': 'Yeb — https://aiostreams.fortheweak.cloud',
	'3': 'Midnight — https://aiostreamsfortheweebsstable.midnightignite.me',
	'4': 'Custom — set URL below',
	# '5' ElfHosted — hidden from picker (Search API disabled on public host); keep id reserved.
}},
{'setting_id': 'aiostreams.profiles', 'setting_type': 'string', 'setting_default': '{}'},
{'setting_id': 'aiostreams.custom_url', 'setting_type': 'string', 'setting_default': ''},
{'setting_id': 'aiostreams.username', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'aiostreams.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'aiostreams.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'aiostreams.preserve_order', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.aiostreams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.aiostreams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'aio.priority', 'setting_type': 'action', 'setting_default': '7', 'min_value': '1', 'max_value': '10'},
{'setting_id': 'provider.aiostreams_highlight', 'setting_type': 'string', 'setting_default': 'FF00D4FF'},
#=========+========== Folders
{'setting_id': 'provider.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'folders.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_folders_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'results.folders_ignore_filters', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'folders.priority', 'setting_type': 'action', 'setting_default': '6', 'min_value': '1', 'max_value': '10'},
#==================== NZB Indexers
{'setting_id': 'provider.nzb', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb1.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb1.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 1'},
{'setting_id': 'nzb1.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb1.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb2.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb2.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 2'},
{'setting_id': 'nzb2.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb2.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb3.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb3.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 3'},
{'setting_id': 'nzb3.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb3.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb4.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb4.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 4'},
{'setting_id': 'nzb4.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb4.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb5.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb5.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 5'},
{'setting_id': 'nzb5.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb5.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb6.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb6.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 6'},
{'setting_id': 'nzb6.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb6.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb7.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb7.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 7'},
{'setting_id': 'nzb7.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb7.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb8.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb8.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 8'},
{'setting_id': 'nzb8.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb8.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb9.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb9.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 9'},
{'setting_id': 'nzb9.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb9.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb10.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb10.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 10'},
{'setting_id': 'nzb10.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb10.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb11.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb11.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 11'},
{'setting_id': 'nzb11.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb11.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb12.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb12.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 12'},
{'setting_id': 'nzb12.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb12.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb13.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb13.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 13'},
{'setting_id': 'nzb13.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb13.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb14.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb14.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 14'},
{'setting_id': 'nzb14.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb14.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb15.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb15.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 15'},
{'setting_id': 'nzb15.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb15.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb16.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb16.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 16'},
{'setting_id': 'nzb16.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb16.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb17.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb17.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 17'},
{'setting_id': 'nzb17.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb17.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb18.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb18.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 18'},
{'setting_id': 'nzb18.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb18.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb19.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb19.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 19'},
{'setting_id': 'nzb19.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb19.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb20.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb20.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 20'},
{'setting_id': 'nzb20.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb20.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb21.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb21.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 21'},
{'setting_id': 'nzb21.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb21.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb22.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb22.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 22'},
{'setting_id': 'nzb22.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb22.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb23.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb23.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 23'},
{'setting_id': 'nzb23.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb23.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb24.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb24.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 24'},
{'setting_id': 'nzb24.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb24.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb25.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb25.label', 'setting_type': 'string', 'setting_default': 'NZB Indexer 25'},
{'setting_id': 'nzb25.url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb25.key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'nzb.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nzb.title_filter_episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nzb.fallback_search', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nzb.query_budget', 'setting_type': 'action', 'setting_default': '40', 'min_value': '1', 'max_value': '120'},
{'setting_id': 'nzb.quality_search', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'Off', '1': 'On'}},
{'setting_id': 'nzb.quality_types', 'setting_type': 'string', 'setting_default': 'epname, 2160p remux, 2160p web, 1080p remux, 1080p bd, 1080p web, 720p, hdtv, dvd'},
{'setting_id': 'nzb.results_per_type', 'setting_type': 'action', 'setting_default': '15', 'settings_options': {'5': '5', '10': '10', '15': '15', '25': '25', '50': '50'}},
{'setting_id': 'nzb.checks_per_type', 'setting_type': 'action', 'setting_default': '2', 'settings_options': {'1': '1', '2': '2', '3': '3', '5': '5', '10': '10', '15': '15'}},
{'setting_id': 'nzb.search_width', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Focused', '1': 'Balanced', '2': 'Broad'}},
{'setting_id': 'check.nzb', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.nzb', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb.priority', 'setting_type': 'action', 'setting_default': '7', 'min_value': '1', 'max_value': '10'},
{'setting_id': 'provider.nzb_highlight', 'setting_type': 'string', 'setting_default': 'FFD4A017'},
{'setting_id': 'nzb.verify_playable', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nzb.unpack_enabled', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'nzb.unpack_folder', 'setting_type': 'path', 'setting_default': '', 'browse_mode': '0'},
{'setting_id': 'nzb.unpack_prefer_local', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nzb.unpack_limit_gb', 'setting_type': 'action', 'setting_default': '100', 'min_value': '0', 'max_value': '2000'},
{'setting_id': 'nzb.check_limit', 'setting_type': 'action', 'setting_default': '15', 'min_value': '0', 'max_value': '200'},
{'setting_id': 'usenet.playback', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Auto (TorBox if cached, else direct)', '1': 'Direct Usenet (NNTP) only', '2': 'TorBox only'}},
{'setting_id': 'usenet1.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet1.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet1.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet1.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet1.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet1.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet2.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet2.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet2.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet2.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet2.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet2.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet3.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet3.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet3.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet3.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet3.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet3.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet4.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet4.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet4.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet4.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet4.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet4.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet5.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet5.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet5.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet5.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet5.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet5.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet6.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet6.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet6.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet6.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet6.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet6.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet7.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet7.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet7.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet7.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet7.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet7.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet8.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet8.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet8.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet8.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet8.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet8.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet9.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet9.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet9.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet9.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet9.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet9.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet10.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet10.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet10.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet10.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet10.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet10.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet11.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet11.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet11.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet11.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet11.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet11.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet12.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet12.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet12.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet12.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet12.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet12.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet13.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet13.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet13.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet13.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet13.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet13.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet14.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet14.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet14.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet14.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet14.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet14.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet15.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet15.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet15.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet15.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet15.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet15.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet16.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet16.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet16.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet16.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet16.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet16.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet17.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet17.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet17.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet17.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet17.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet17.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet18.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet18.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet18.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet18.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet18.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet18.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet19.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet19.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet19.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet19.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet19.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet19.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet20.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet20.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet20.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet20.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet20.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet20.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet21.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet21.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet21.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet21.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet21.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet21.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet22.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet22.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet22.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet22.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet22.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet22.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet23.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet23.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet23.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet23.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet23.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet23.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet24.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet24.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet24.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet24.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet24.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet24.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet25.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'usenet25.host', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet25.port', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '65535'},
{'setting_id': 'usenet25.ssl', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'usenet25.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'usenet25.password', 'setting_type': 'string', 'setting_default': 'empty_setting'},


#===============================================================================#
#====================================RESULTS====================================#
#===============================================================================#
#==================== Display
{'setting_id': 'results.screen_cache', 'setting_type': 'action', 'setting_default': '30', 'settings_options': {'0': 'Off', '10': '10 minutes', '30': '30 minutes', '60': '1 hour', '360': '6 hours'}},
{'setting_id': 'results.timeout', 'setting_type': 'action', 'setting_default': '20', 'min_value': '1'},
{'setting_id': 'results.list_format', 'setting_type': 'string', 'setting_default': 'List'},
{'setting_id': 'results.show_episode_title', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Rescrape
{'setting_id': 'rescrape.cache_ignored', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.cache_ignored.order', 'setting_type': 'action', 'setting_default': '0', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.imdb_year', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.imdb_year.order', 'setting_type': 'action', 'setting_default': '1', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.with_all', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.with_all.order', 'setting_type': 'action', 'setting_default': '2', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.episode_group', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.episode_group.order', 'setting_type': 'action', 'setting_default': '3', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.ignore_filters', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.ignore_filters.order', 'setting_type': 'action', 'setting_default': '4', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.full_scrape', 'setting_type': 'action', 'setting_default': '2', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.full_scrape.order', 'setting_type': 'action', 'setting_default': '5', 'min_value': '1', 'max_value': '5'},
#==================== Sorting and Filtering
{'setting_id': 'results.sort_order_display', 'setting_type': 'string', 'setting_default': 'Quality, Size, Provider'},
{'setting_id': 'results.quality_sort_order', 'setting_type': 'string', 'setting_default': '4K, 1080p, 720p, SD'},
{'setting_id': 'results.filter_size_method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Use Line Speed', '2': 'Use Size'}},
{'setting_id': 'results.line_speed', 'setting_type': 'action', 'setting_default': '25', 'min_value': '1'},
{'setting_id': 'results.movie_size_max', 'setting_type': 'action', 'setting_default': '10000', 'min_value': '1'},
{'setting_id': 'results.episode_size_max', 'setting_type': 'action', 'setting_default': '3000', 'min_value': '1'},
{'setting_id': 'results.movie_size_min', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.episode_size_min', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.size_unknown', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'results.size_sort_weighted', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.size_sort_direction', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Descending', '1': 'Ascending'}},
{'setting_id': 'results.uncached_min_seeders', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.limit_number_quality', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'results.limit_number_total', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'results.include.unknown.size', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'filter.include_prerelease', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.hevc', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.hevc.max_quality', 'setting_type': 'action', 'setting_default': '4K', 'settings_options': {'4K': '4K', '1080p': '1080p', '720p': '720p', 'SD': 'SD'}},
{'setting_id': 'filter.hevc.max_autoplay_quality', 'setting_type': 'action', 'setting_default': '4K', 'settings_options': {'4K': '4K', '1080p': '1080p', '720p': '720p', 'SD': 'SD'}},
{'setting_id': 'filter.3d', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.hdr', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.dv', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.av1', 'setting_type': 'action', 'setting_default': '0', 'settings_options':{'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.enhanced_upscaled', 'setting_type': 'action', 'setting_default': '0', 'settings_options':{'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.sort_to_top', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Source Select', '2': 'Autoplay', '3': 'Both'}},
{'setting_id': 'filter.prefer_release_groups', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Source Select', '2': 'Autoplay', '3': 'Both'}},
{'setting_id': 'filter.preferred_filters', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'filter_audio', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== Results Color Highlights
{'setting_id': 'highlight.type', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Provider', '1': 'Quality', '2': 'Single Color'}},
{'setting_id': 'provider.easynews_highlight', 'setting_type': 'string', 'setting_default': 'FF00B3B2'},
{'setting_id': 'provider.debrid_cloud_highlight', 'setting_type': 'string', 'setting_default': 'FF7A01CC'},
{'setting_id': 'provider.folders_highlight', 'setting_type': 'string', 'setting_default': 'FFB36B00'},
{'setting_id': 'provider.rd_highlight', 'setting_type': 'string', 'setting_default': 'FF3C9900'},
{'setting_id': 'provider.pm_highlight', 'setting_type': 'string', 'setting_default': 'FFFF3300'},
{'setting_id': 'provider.ad_highlight', 'setting_type': 'string', 'setting_default': 'FFE6B800'},
{'setting_id': 'provider.oc_highlight', 'setting_type': 'string', 'setting_default': 'FF5C6BC0'},
{'setting_id': 'provider.tb_highlight', 'setting_type': 'string', 'setting_default': 'FF01662A'},
{'setting_id': 'scraper_4k_highlight', 'setting_type': 'string', 'setting_default': 'FFFF00FE'},
{'setting_id': 'scraper_1080p_highlight', 'setting_type': 'string', 'setting_default': 'FFE6B800'},
{'setting_id': 'scraper_720p_highlight', 'setting_type': 'string', 'setting_default': 'FF3C9900'},
{'setting_id': 'scraper_SD_highlight', 'setting_type': 'string', 'setting_default': 'FF0166FF'},
{'setting_id': 'scraper_single_highlight', 'setting_type': 'string', 'setting_default': 'FF008EB2'},
{'setting_id': 'scraper_total_highlight', 'setting_type': 'string', 'setting_default': 'FFFFFFFF'},
{'setting_id': 'highlight.scrape_progress_colours', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'highlight.tint_focused_background', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'highlight.background_opacity', 'setting_type': 'string', 'setting_default': '66'},
{'setting_id': 'highlight.background_opacity_name', 'setting_type': 'string', 'setting_default': '40%'},


#===============================================================================#
#===================================PLAYBACK====================================#
#===============================================================================#
#==================== Playback Movies
{'setting_id': 'auto_play_movie', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results_quality_movie', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_quality_movie', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay.movie_size_max', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'auto_resume_movie', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'Always', '2': 'Autoplay Only'}},
{'setting_id': 'progress_cleared.movie', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'progress_cleared.episode', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'stinger_alert.show', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'stinger_alert.window_percentage', 'setting_type': 'action', 'setting_default': '90', 'min_value': '1', 'max_value': '99'},
{'setting_id': 'stinger_alert.alert_timing', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'Playback Percentage', '1': 'Chapter Info', '2': 'Subtitles Info'}},
#==================== Playback Episodes
{'setting_id': 'auto_play_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results_quality_episode', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_quality_episode', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay.episode_size_max', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'autoplay_next_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay_alert_method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Window', '1': 'Notification'}},
{'setting_id': 'autoplay_default_action', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Play', '1': 'Cancel', '2': 'Pause & Wait'}},
{'setting_id': 'autoplay_next_window_percentage', 'setting_type': 'action', 'setting_default': '95', 'min_value': '75', 'max_value': '99'},
{'setting_id': 'autoplay_alert_timing', 'setting_type': 'action', 'setting_default': '3', 'settings_options': {'0': 'Playback Percentage', '1': 'Chapter Info', '2': 'Subtitles Info', '3': 'IntroDB Info'}},
{'setting_id': 'autoplay_skip_intro', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '2': 'Auto', '1': 'Prompt'}},
{'setting_id': 'skip_intro_all_episodes', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'autoplay_watching_check', 'setting_type': 'action', 'setting_default': '3', 'min_value': '0', 'max_value': '5'},
{'setting_id': 'autoscrape_next_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoscrape_next_window_percentage', 'setting_type': 'action', 'setting_default': '95', 'min_value': '75', 'max_value': '99'},
{'setting_id': 'autoscrape_alert_timing', 'setting_type': 'action', 'setting_default': '3', 'settings_options': {'0': 'Playback Percentage', '1': 'Chapter Info', '2': 'Subtitles Info', '3': 'IntroDB Info'}},
{'setting_id': 'autoscrape_confirm', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'auto_resume_episode', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'Always', '2': 'Autoplay Only'}},
#==================== Playback Utilities
{'setting_id': 'playback.limit_resolve', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.show_source_filename', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews.playback_method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Retry', '2': 'No Seek', '3': 'Both'}},
{'setting_id': 'easynews.playback_method_retries', 'setting_type': 'action', 'setting_default': '1', 'min_value': '1', 'max_value': '8'},
{'setting_id': 'easynews.playback_method_limited', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.volumecheck_enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.volumecheck_percent', 'setting_type': 'action', 'setting_default': '50', 'min_value': '1', 'max_value': '100'},
{'setting_id': 'playback.auto_enable_subs', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.opensubs_api_key', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'playback.opensubs_username', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'playback.opensubs_password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'playback.subs_source', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Local Subtitles', '1': 'SubMaker', '2': 'OpenSubtitles'}},
{'setting_id': 'playback.submaker_manifest', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'playback.submaker_language', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'English', '1': 'Arabic', '2': 'Bengali',
'3': 'Bulgarian', '4': 'Chinese', '5': 'Croatian', '6': 'Czech', '7': 'Danish', '8': 'Dutch', '9': 'Finnish', '10': 'French', '11': 'German',
'12': 'Greek', '13': 'Hebrew', '14': 'Hindi', '15': 'Hungarian', '16': 'Icelandic', '17': 'Indonesian', '18': 'Italian', '19': 'Japanese',
'20': 'Korean', '21': 'Malay', '22': 'Norwegian', '23': 'Persian', '24': 'Polish', '25': 'Portuguese', '26': 'Portuguese (Brazil)', '27': 'Punjabi',
'28': 'Romanian', '29': 'Russian', '30': 'Serbian', '31': 'Slovenian', '32': 'Spanish', '33': 'Swedish', '34': 'Tagalog', '35': 'Tamil', '36': 'Telugu',
'37': 'Thai', '38': 'Turkish', '39': 'Ukrainian', '40': 'Urdu', '41': 'Vietnamese', '42': 'Forced Only (Local Subs)'}},
{'setting_id': 'playback.submaker_prefer_local', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'playback.subs_show_notifications', 'setting_type': 'boolean', 'setting_default': 'true'},


#=========================================================================================#
#======================================HIDDEN=============================================#
#=========================================================================================#
{'setting_id': 'tmdb.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.session_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.account_session_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'reuse_language_invoker', 'setting_type': 'string', 'setting_default': 'true'},
{'setting_id': 'addon_icon_choice_name', 'setting_type': 'string', 'setting_default': 'icon.png'},
{'setting_id': 'widget_refresh_timer_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'mpaa_region_display_name', 'setting_type': 'string', 'setting_default': 'United States'},
{'setting_id': 'lists_cache_duraton_display_name', 'setting_type': 'string', 'setting_default': '1 Day'},
{'setting_id': 'results.limit_number_quality_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'results.limit_number_total_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'rpdb_format_name', 'setting_type': 'string', 'setting_default': 'Default'},
{'setting_id': 'window_theme_contrast', 'setting_type': 'string', 'setting_default': 'FF4a4347'},
{'setting_id': 'window_theme_name', 'setting_type': 'string', 'setting_default': 'Dark'},
{'setting_id': 'window_theme_opacity_name', 'setting_type': 'string', 'setting_default': '20%'},
{'setting_id': 'thumbnail_cleanup_enabled_name', 'setting_type': 'string', 'setting_default': 'Enabled'},
{'setting_id': 'thumbnail_cleanup_interval_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'external_scraper.module', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'trakt.next_daily_clear', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'trakt.expires', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'trakt.refresh', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'trakt.token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'playback.opensubs_token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'tmdblist.list_sort', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'tmdblist.list_sort_name', 'setting_type': 'string', 'setting_default': 'Title'},
{'setting_id': 'personal_list.list_sort', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'personal_list.list_sort_name', 'setting_type': 'string', 'setting_default': 'Title'},
{'setting_id': 'rd.client_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'rd.refresh', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'rd.secret', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'results.sort_order', 'setting_type': 'string', 'setting_default': '1'},
{'setting_id': 'folder1.display_name', 'setting_type': 'string', 'setting_default': 'Folder 1'},
{'setting_id': 'folder1.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder1.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder2.display_name', 'setting_type': 'string', 'setting_default': 'Folder 2'},
{'setting_id': 'folder2.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder2.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder3.display_name', 'setting_type': 'string', 'setting_default': 'Folder 3'},
{'setting_id': 'folder3.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder3.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder4.display_name', 'setting_type': 'string', 'setting_default': 'Folder 4'},
{'setting_id': 'folder4.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder4.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder5.display_name', 'setting_type': 'string', 'setting_default': 'Folder 5'},
{'setting_id': 'folder5.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder5.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'extras.enabled', 'setting_type': 'string', 'setting_default': '2050,2051,2068,2067,2069,2070,2071,2072,2073,2052,2053,2054,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066'},
{'setting_id': 'extras.order', 'setting_type': 'string', 'setting_default': '2050,2074,2051,2068,2067,2069,2070,2071,2072,2073,2052,2053,2054,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2074'},
{'setting_id': 'rescrape.enabled', 'setting_type': 'string', 'setting_default': 'cache_ignored,imdb_year,with_all,episode_group,ignore_filters,full_scrape'},
{'setting_id': 'rescrape.order', 'setting_type': 'string', 'setting_default': 'cache_ignored,imdb_year,with_all,episode_group,ignore_filters,full_scrape'},
{'setting_id': 'extras.tvshow.button10', 'setting_type': 'string', 'setting_default': 'tvshow_browse'},
{'setting_id': 'extras.tvshow.button11', 'setting_type': 'string', 'setting_default': 'show_trailers'},
{'setting_id': 'extras.tvshow.button12', 'setting_type': 'string', 'setting_default': 'show_keywords'},
{'setting_id': 'extras.tvshow.button13', 'setting_type': 'string', 'setting_default': 'show_images'},
{'setting_id': 'extras.tvshow.button14', 'setting_type': 'string', 'setting_default': 'show_extrainfo'},
{'setting_id': 'extras.tvshow.button15', 'setting_type': 'string', 'setting_default': 'show_genres'},
{'setting_id': 'extras.tvshow.button16', 'setting_type': 'string', 'setting_default': 'play_nextep'},
{'setting_id': 'extras.tvshow.button17', 'setting_type': 'string', 'setting_default': 'show_options'},
{'setting_id': 'extras.movie.button10', 'setting_type': 'string', 'setting_default': 'movies_play'},
{'setting_id': 'extras.movie.button11', 'setting_type': 'string', 'setting_default': 'show_trailers'},
{'setting_id': 'extras.movie.button12', 'setting_type': 'string', 'setting_default': 'show_keywords'},
{'setting_id': 'extras.movie.button13', 'setting_type': 'string', 'setting_default': 'show_images'},
{'setting_id': 'extras.movie.button14', 'setting_type': 'string', 'setting_default': 'show_extrainfo'},
{'setting_id': 'extras.movie.button15', 'setting_type': 'string', 'setting_default': 'show_genres'},
{'setting_id': 'extras.movie.button16', 'setting_type': 'string', 'setting_default': 'show_director'},
{'setting_id': 'extras.movie.button17', 'setting_type': 'string', 'setting_default': 'show_options'},
	]
	return _DEFAULTS_LIST
