# -*- coding: utf-8 -*-
"""Write-through from Nightshift's watched status to WatchVault.

WatchVault is optional. When it is not installed the helper returns None and every call here does nothing, so Nightshift
behaves exactly as before. Nightshift stays the screen source: a mark is still written to Nightshift's own store first,
then mirrored to WatchVault so other add-ons and sync can see it.

Also mirrors in-progress resume (runtime/remaining) and can read resume back before playback.
"""
from modules import watchvault_helper as wvh

SOURCE = 'plugin.video.nightshift'


def _clean(value):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _season_num(value):
    """Season number including 0 (specials); None when not a number."""
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def mirror_episodes(action, tmdb_id, tvdb_id, pairs, title='', year=None):
    """Mirror many episode marks (a season or a whole show). pairs is a list of (season, episode). Notifications are
    suppressed per episode so a season does not fire one notification each. Returns how many were mirrored."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return 0
    done = 0
    for season, episode in pairs:
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            continue
        try:
            res = wvh.mark(title=title or None, year=_clean(year), season=s, episode=e, tvdb_id=_clean(tvdb_id),
                           tmdb_id=_clean(tmdb_id), watched=(action == 'mark_as_watched'), source=SOURCE, notify=False)
            if res and res.get('ok'):
                done += 1
        except Exception:
            pass
    return done


def episodes_watched_for(media_key):
    """(season, episode) pairs WatchVault holds as watched for a show. media_key is 'tvdb<id>' or a TMDb id."""
    key = str(media_key or '')
    if key.startswith('tvdb'):
        ids = {'tvdb_id': _clean(key[4:])}
    else:
        ids = {'tmdb_id': _clean(key)}
    if not any(ids.values()):
        return []
    try:
        data = wvh.watched_episodes(**ids) or {}
    except Exception:
        return []
    return [(int(s), int(e)) for s, eps in data.items() for e in eps]


def movie_watched(media_id):
    """True when WatchVault holds this movie (TMDb id) as watched."""
    tmdb = _clean(media_id)
    if not tmdb:
        return False
    try:
        return bool(wvh.is_watched(tmdb_id=tmdb))
    except Exception:
        return False


def shows_watched_keys():
    """Media keys of shows WatchVault holds as watched: 'tvdb<id>' when it has one, else the TMDb id."""
    keys = []
    try:
        rows = wvh.watched_show_ids() or []
    except Exception:
        return keys
    for row in rows:
        tvdb = _clean(row.get('tvdb_id'))
        tmdb = _clean(row.get('tmdb_id'))
        if tvdb:
            keys.append('tvdb%d' % tvdb)
        elif tmdb:
            keys.append(str(tmdb))
    return keys


def mirror_episode(action, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Mirror one episode mark. action is 'mark_as_watched' or 'mark_as_unwatched'."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return None
    try:
        return wvh.mark(title=title or None, year=_clean(year), season=_clean(season) if _clean(season) is not None else 0,
                        episode=_clean(episode), tvdb_id=_clean(tvdb_id), tmdb_id=_clean(tmdb_id),
                        watched=(action == 'mark_as_watched'), source=SOURCE)
    except Exception:
        return None


def mirror_movie(action, tmdb_id, title='', year=None):
    """Mirror one movie mark."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return None
    try:
        return wvh.mark(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id),
                        watched=(action == 'mark_as_watched'), source=SOURCE)
    except Exception:
        return None


def mirror_progress(media_type, tmdb_id, tvdb_id, season, episode, title, year,
                    curr_time, total_time):
    """Write resume progress into WatchVault (runtime + remaining seconds)."""
    try:
        total = float(total_time or 0)
        curr = float(curr_time or 0)
    except (TypeError, ValueError):
        return None
    if total <= 0 or curr < 0:
        return None
    if curr > total:
        curr = total
    remaining = max(0, int(round(total - curr)))
    runtime = int(round(total))
    kw = dict(
        title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id), tvdb_id=_clean(tvdb_id),
        runtime=runtime, remaining=remaining, source=SOURCE, notify=False,
    )
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        return wvh.save_progress(**kw)
    except Exception:
        return None


def resume_percent(media_type, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Resume percent (0-100) from WatchVault, or None if no usable progress."""
    kw = dict(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id), tvdb_id=_clean(tvdb_id))
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        data = wvh.get_resume(**kw)
    except Exception:
        return None
    if not data or data.get('watched'):
        return None
    runtime, remaining, position = data.get('runtime'), data.get('remaining'), data.get('position')
    try:
        if position is not None and runtime and float(runtime) > 0:
            pct = round(float(position) / float(runtime) * 100.0, 1)
        elif remaining is not None and runtime and float(runtime) > 0:
            pct = round((float(runtime) - float(remaining)) / float(runtime) * 100.0, 1)
        else:
            return None
    except (TypeError, ValueError, ZeroDivisionError):
        return None
    if pct < 1.0 or pct >= 95.0:
        return None
    return pct


def clear_progress(media_type, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Clear WatchVault remaining (seek) for this title."""
    kw = dict(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id),
              tvdb_id=_clean(tvdb_id), source=SOURCE, notify=False)
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        return wvh.clear_progress(**kw)
    except Exception:
        return None
