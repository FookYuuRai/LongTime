# -*- coding: utf-8 -*-
"""TMDb episode stills, season at a time.

Ported from tmdb_series_stills.py (the CLI helper). The old path asked TMDb for one episode's images per request. This
module asks for a season's episode list once, then fetches the images of up to 20 episodes per request through
append_to_response. A 12-episode season therefore costs 2 requests instead of 12.

Pure logic: the HTTP call is passed in as get_json(url) -> dict, so the module can be tested without network access.
"""
import urllib.parse

API_BASE = 'https://api.themoviedb.org/3'
CDN_BASE = 'https://image.tmdb.org/t/p/original'
BATCH = 20


def _url(path, api_key, extra=None):
    params = {'api_key': api_key}
    if extra:
        params.update(extra)
    return '%s/%s?%s' % (API_BASE, path, urllib.parse.urlencode(params))


def season_episode_numbers(get_json, api_key, tmdb_id, season):
    """Episode numbers of one season, from TMDb's season endpoint (one request)."""
    data = get_json(_url('tv/%s/season/%s' % (tmdb_id, int(season)), api_key)) or {}
    numbers = []
    for ep in data.get('episodes') or []:
        n = ep.get('episode_number') if isinstance(ep, dict) else None
        if isinstance(n, int):
            numbers.append(n)
    return sorted(set(numbers))


def still_file_paths(images_payload):
    """Still file paths from one episode's images payload, in TMDb's order."""
    if not isinstance(images_payload, dict):
        return []
    return [s.get('file_path') for s in (images_payload.get('stills') or [])
            if isinstance(s, dict) and s.get('file_path')]


def batched_season_images(get_json, api_key, tmdb_id, season, numbers):
    """{episode_number: [file_path, ...]} for the given episodes of one season, 20 episodes per request.
    An episode whose image payload is missing or marked failed maps to []."""
    found = {}
    numbers = list(numbers)
    for start in range(0, len(numbers), BATCH):
        chunk = numbers[start:start + BATCH]
        paths = ['season/%d/episode/%d/images' % (int(season), n) for n in chunk]
        data = get_json(_url('tv/%s' % tmdb_id, api_key, {'append_to_response': ','.join(paths)})) or {}
        for n, path in zip(chunk, paths):
            payload = data.get(path)
            if not isinstance(payload, dict) or payload.get('success') is False:
                found[n] = []
            else:
                found[n] = still_file_paths(payload)
    return found


def cdn_urls(file_paths):
    """Full CDN URLs for still file paths (original size, no key needed)."""
    return ['%s%s' % (CDN_BASE, p) for p in file_paths if p]


def season_still_urls(get_json, api_key, tmdb_id, season):
    """{episode_number: [CDN url, ...]} for every episode of one season."""
    numbers = season_episode_numbers(get_json, api_key, tmdb_id, season)
    if not numbers:
        return {}
    paths = batched_season_images(get_json, api_key, tmdb_id, season, numbers)
    return {n: cdn_urls(p) for n, p in paths.items()}
