import re
# -*- coding: utf-8 -*-
import datetime
from caches.meta_cache import cache_function
from caches.lists_cache import lists_cache_object
from modules.settings import get_meta_filter, tmdb_api_key, lists_cache_duraton
from modules.kodi_utils import make_session, remove_keys
# from modules.kodi_utils import logger

session = make_session('https://api.themoviedb.org/3')

def tmdb_dict_removals():
	return ('adult', 'backdrop_path', 'genre_ids', 'original_language', 'original_title', 'overview', 'popularity', 'vote_count', 'video', 'origin_country', 'original_name')

def no_api_key():
	from modules.kodi_utils import notification
	notification('Please set a valid TMDb API Key')
	return []

def _premieres_sort(media, movie_field='primary_release_date'):
	"""Discover sort_by and cache-key suffix. Popularity keeps the existing cache key."""
	from modules.settings import premieres_newest_first
	if not premieres_newest_first(): return '', ''
	if media == 'movie': return '&sort_by=%s.desc' % movie_field, '_newest'
	return '&sort_by=first_air_date.desc', '_newest'

def movie_details(tmdb_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,release_dates,alternative_titles,translations,' \
		'images,keywords&include_image_language=en,null' % (tmdb_id, api_key)
		return get_tmdb(url).json()
	except: return None

def tvshow_details(tmdb_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,content_ratings,alternative_titles,translations,' \
		'images,keywords&include_image_language=en,null' % (tmdb_id, api_key)
		return get_tmdb(url).json()
	except: return None

def episode_groups_data(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'episode_groups_data_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/episode_groups?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def episode_group_details(group_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'episode_groups_details_%s' % group_id
	url = 'https://api.themoviedb.org/3/tv/episode_group/%s?api_key=%s' % (group_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def movie_set_details(collection_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/collection/%s?api_key=%s&language=en' % (collection_id, api_key)
		return get_tmdb(url).json()
	except: return None

def movie_external_id(external_source, external_id, api_key):
	try:
		string = 'movie_external_id_%s_%s' % (external_source, external_id)
		url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		result = result['movie_results']
		if result: return result[0]
		else: return None
	except: return None

def tvshow_external_id(external_source, external_id, api_key):
	try:
		string = 'tvshow_external_id_%s_%s' % (external_source, external_id)
		url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		tv_results = result.get('tv_results') or []
		if tv_results: return tv_results[0]
		# Season-split anime IMDb ids often map to an episode/season, not the show record.
		for key in ('tv_episode_results', 'tv_season_results'):
			for row in result.get(key) or []:
				show_id = row.get('show_id')
				if show_id: return {'id': show_id}
		return None
	except: return None

def tmdb_movies_oscar_winners(page_no):
	from modules.meta_lists import oscar_winners
	return oscar_winners()[page_no-1]

def tmdb_network_details(network_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_network_details_%s' % network_id
	url = 'https://api.themoviedb.org/3/network/%s?api_key=%s' % (network_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_keywords_by_query(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_keywords_by_query_%s_%s' % (query, page_no)
	url = 'https://api.themoviedb.org/3/search/keyword?api_key=%s&query=%s&page=%s' % (api_key, query, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_collections_by_query(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_collections_by_query_%s_%s' % (query, page_no)
	url = 'https://api.themoviedb.org/3/search/collection?api_key=%s&language=en-US&query=%s&page=%s' % (api_key, query, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movie_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movie_keywords_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/movie/%s/keywords?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_tv_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_keywords_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/keywords?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movie_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movie_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (api_key, tmdb_id, page_no)
	return lists_cache_object(get_data, string, url, expiration=96)

def tmdb_tv_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (api_key, tmdb_id, page_no)
	return lists_cache_object(get_data, string, url, expiration=96)

def tmdb_movie_keyword_results_direct(query, page_no):
	if tmdb_api_key() in (None, 'empty_setting', ''): return no_api_key()
	try:
		results = tmdb_movie_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_tv_keyword_results_direct(query, page_no):
	if tmdb_api_key() in (None, 'empty_setting', ''): return no_api_key()
	try:
		results = tmdb_tv_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_production_companies(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_production_companies_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s?api_key=%s&language=en-US' % ('movie' if media_type == 'movie' else 'tv', tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_tv_companies(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_studio_%s_%s' % (company_id, page_no)
	# No language/keyword exclusions here (the usual lists drop anime via keyword 210024): the studio row wants everything the studio made.
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false' \
	'&with_companies=%s&first_air_date.lte=%s&page=%s' % (api_key, company_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_studio(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_studio_%s_%s' % (company_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&with_companies=%s&page=%s' % (api_key, company_id, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_resolve_title(media_type, title, year):
	"""TMDb id for a title + year (used for AniList entries, which carry no TMDb id), or None."""
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', '') or not title: return None
	from urllib.parse import quote
	movie = media_type == 'movie'
	string = 'tmdb_resolve_%s_%s_%s' % (media_type, title, year)
	url = 'https://api.themoviedb.org/3/search/%s?api_key=%s&language=en-US&query=%s&%s=%s' % ('movie' if movie else 'tv', api_key, quote(title), 'year' if movie else 'first_air_date_year', year or '')
	try: results = cache_function(get_tmdb, string, url, expiration=720).get('results') or []
	except: return None
	if not results and year:
		return tmdb_resolve_title(media_type, title, '')
	return results[0]['id'] if results else None

def tmdb_company_id(query):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_company_id_%s' % query
	from urllib.parse import quote
	url = 'https://api.themoviedb.org/3/search/company?api_key=%s&query=%s' % (api_key, quote(query))
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_media_images(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_images_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s/images?include_image_language=en,null&api_key=%s' % (media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_media_videos(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_videos_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s/videos?api_key=%s' % (media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movies_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, json=True, expiration=min(lists_cache_duraton(), 24))

def tmdb_movies_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/movie/popular?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_popular_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/movie/day?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_blockbusters(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_blockbusters_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&sort_by=revenue.desc&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_in_theaters(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_in_theaters_%s' % page_no
	url = 'https://api.themoviedb.org/3/movie/now_playing?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_movies_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=3|2|1&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_latest_releases(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	sort_q, sort_key = _premieres_sort('movie', 'release_date')
	string = 'tmdb_movies_latest_releases%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=4|5|6%s&page=%s' % (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	sort_q, sort_key = _premieres_sort('movie')
	string = 'tmdb_movies_premieres%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=1|3|2%s&page=%s' % (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_genres=%s&language=en-US&region=US&with_original_language=en&sort_by=popularity.desc&release_date.lte=%s&page=%s' \
			% (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_languages_%s_%s' % (language, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&with_original_language=%s&sort_by=popularity.desc&release_date.lte=%s&page=%s' \
			% (api_key, language, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_certifications(certification, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_certifications_%s_%s' % (certification, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en' \
	'&certification_country=US&certification=%s&sort_by=popularity.desc&release_date.lte=%s&page=%s' % (api_key, certification, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&primary_release_year=%s&page=%s' \
							% (api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&primary_release_date.gte=%s' \
			'&primary_release_date.lte=%s&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_providers_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&watch_region=US&with_watch_providers=%s&page=%s' % (api_key, provider, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_recommendations_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/movie/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (tmdb_id, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_movies_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/movie?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, query, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_companies(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_companies_%s_%s' % (company_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&with_companies=%s&page=%s' \
							% (api_key, company_id, page_no)
	return lists_cache_object(get_data, string, url, expiration=168)

def tmdb_movies_reviews(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	url = 'https://api.themoviedb.org/3/movie/%s/reviews?api_key=%s&page=%s' % (tmdb_id, api_key, page_no)
	return get_tmdb(url).json()

def tmdb_tv_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, json=True, expiration=min(lists_cache_duraton(), 24))

def tmdb_tv_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en' \
	'&without_keywords=210024&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(180, reverse=True)
	string = 'tmdb_tv_popular_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&without_keywords=210024' \
	'&include_null_first_air_dates=false&first_air_date.gte=%s' \
	'&first_air_date.lte=%s&page=%s' % (api_key, previous_date, current_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	sort_q, sort_key = _premieres_sort('tv')
	string = 'tmdb_tv_premieres%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&without_keywords=210024%s&page=%s' % (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_airing_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	expiration = min(lists_cache_duraton(), 24)
	string = 'tmdb_tv_airing_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/tv/airing_today?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024&page=%s' \
	% (api_key, page_no)
	return lists_cache_object(get_data, string, url, expiration=expiration)

def tmdb_tv_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_on_the_air_%s' % page_no
	url = 'https://api.themoviedb.org/3/tv/on_the_air?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024&page=%s' \
	% (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_tv_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&with_genres=%s&language=en-US&region=US&with_original_language=en' \
	'&include_null_first_air_dates=false&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_languages_%s_%s' % (language, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false&with_original_language=%s&first_air_date.lte=%s' \
	'&without_keywords=210024&page=%s' % (api_key, language, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_networks(network_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_networks_%s_%s' % (network_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&with_networks=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, network_id, get_current_date(), page_no)
	data = lists_cache_object(get_data, string, url)
	try: enough = len(data['results']) >= 10
	except: return data
	if enough: return data
	# Networks that mostly air non-English or anime shows (e.g. AT-X, TV Tokyo) come back empty or nearly so under the English-only / no-anime filters: retry without them.
	string = 'tmdb_tv_networks_all_%s_%s' % (network_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false' \
	'&with_networks=%s&first_air_date.lte=%s&page=%s' % (api_key, network_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_providers_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false' \
	'&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, provider, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date_year=%s&without_keywords=210024&page=%s' % (api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_aggregate_cast(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_aggregate_cast_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/aggregate_credits?api_key=%s&language=en-US' % (tmdb_id, api_key)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_recommendations_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/tv/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (tmdb_id, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_tv_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, query, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_reviews(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	url = 'https://api.themoviedb.org/3/tv/%s/reviews?api_key=%s&page=%s' % (tmdb_id, api_key, page_no)
	return get_tmdb(url).json()

def tmdb_anime_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_anime_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_popular_recent(page_no):
	from modules.meta_lists import years_tvshows
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_anime_popular_recent_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&sort_by=first_air_date.desc&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' \
							% (api_key, years_tvshows()[0]['id'], page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(93, reverse=True)
	sort_q, sort_key = _premieres_sort('tv')
	string = 'tmdb_anime_premieres%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date.gte=%s&first_air_date.lte=%s%s&page=%s' \
							% (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(93, reverse=False)
	string = 'tmdb_anime_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&first_air_date.gte=%s&first_air_date.lte=%s&sort_by=first_air_date.asc&page=%s' \
							% (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(7, reverse=False)
	string = 'tmdb_anime_on_the_air_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&air_date.gte=%s&air_date.lte=%s&page=%s' \
							% (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&with_genres=%s&include_null_first_air_dates=false&first_air_date.lte=%s&page=%s' \
							% (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_providers2_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&with_keywords=210024&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false' \
	'&first_air_date.lte=%s&page=%s' % (api_key, provider, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' % (api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date.gte=%s' \
			'&first_air_date.lte=%s&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_popular_people(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/person/popular?api_key=%s&language=en&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=48)

def tmdb_trending_people_day(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_trending_day_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/person/day?api_key=%s&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=48)

def tmdb_trending_people_week(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_trending_week_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/person/week?api_key=%s&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_people_full_info(actor_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_full_info_%s' % actor_id
	url = 'https://api.themoviedb.org/3/person/%s?api_key=%s&language=en&append_to_response=external_ids,combined_credits,images,tagged_images' % (actor_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_people_info(query, page_no=1):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_people_info_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, query, page_no)
	return cache_function(get_tmdb, string, url, expiration=4)

def season_episodes_details(tmdb_id, season_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	try:
		url = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en&append_to_response=credits' % (tmdb_id, season_no, api_key)
		return get_tmdb(url).json()
	except: return None

def get_dates(days, reverse=True):
	current_date = get_current_date(return_str=False)
	if reverse: new_date = (current_date - datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	else: new_date = (current_date + datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	return str(current_date), new_date

def get_current_date(return_str=True):
	if return_str: return str(datetime.date.today())
	else: return datetime.date.today()

def get_reviews_data(media_type, tmdb_id):
	def builder(media_type, tmdb_id):
		reviews_list, all_data = [], []
		template = '[B]%02d. %s%s[/B][CR][CR]%s'
		media_type = 'movie' if media_type in ('movie', 'movies') else 'tv'
		function = tmdb_movies_reviews if media_type  == 'movie' else tmdb_tv_reviews
		next_page, total_pages = 1, 1
		while next_page <= total_pages:
			data = function(tmdb_id, next_page)
			all_data += data['results']
			total_pages = data['total_pages']
			next_page = data['page'] + 1
		if all_data:
			for count, item in enumerate(all_data, 1):
				try:
					user = item['author'].upper()
					rating = item['author_details'].get('rating')
					if rating: rating = ' - %s/10' % str(rating).split('.')[0]
					else: rating = ''
					content = template % (count, user, rating, item['content'])
					reviews_list.append(content)
				except: pass
		return reviews_list
	string, url = 'tmdb_%s_reviews_%s' % (media_type ,tmdb_id), [media_type, tmdb_id]
	return cache_function(builder, string, url, json=False, expiration=168)

def get_data(url):
	return get_tmdb(url).json()

def get_tmdb(url):
	try: response = session.get(url, timeout=20.0)
	except: response = None
	return response

def _tmdb_json(path, **params):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return {}
	from urllib.parse import urlencode
	query = urlencode([('api_key', api_key), ('language', 'en-US')] + [(k, v) for k, v in params.items()])
	url = 'https://api.themoviedb.org/3/%s?%s' % (path, query)
	try: return cache_function(get_tmdb, 'tmdb_json_%s_%s' % (path, query.replace(api_key, '')), url, expiration=720) or {}
	except Exception: return {}

def _title_words(text):
	import re, unicodedata
	text = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode().lower()
	return [w for w in re.split(r'[^a-z0-9]+', text.replace("'", '')) if w]

def special_link_titles(media_type, title, ep_name=None, show_title=None):
	"""A special is listed on TMDb twice: as a TV 'Specials' (season 0) episode and as a movie with its own id. Given one side, the
	names of the other side, so the same file is found from either search.
	media_type 'movie': title = the movie title -> [season 0 episode titles of the show it belongs to].
	media_type 'episode': show_title + ep_name (season 0) -> [titles of the movie of the same name]. Cached; [] when nothing links."""
	out = []
	try:
		if media_type == 'movie':
			words = set(_title_words(title))
			queries, seen = [], set()
			for q in (title, str(title).split(' - ')[0], str(title).split(':')[0]):
				q = q.strip()
				if len(q) > 3 and q.lower() not in seen: seen.add(q.lower()); queries.append(q)
			for q in queries:
				for show in (_tmdb_json('search/tv', query=q).get('results') or [])[:3]:
					for ep in (_tmdb_json('tv/%s/season/0' % show['id']).get('episodes') or []):
						ew = _title_words(ep.get('name'))
						if len(ew) >= 2 and set(ew) <= words and ep.get('name') not in out:
							out.append(ep['name'])
					if out: return out
		else:
			ew = _title_words(ep_name)
			if len(ew) < 2: return out
			for q in ('%s %s' % (show_title or '', ep_name), ep_name):
				for movie in (_tmdb_json('search/movie', query=q.strip()).get('results') or [])[:5]:
					for name in (movie.get('title'), movie.get('original_title')):
						if name and set(ew) <= set(_title_words(name)) and name not in out: out.append(name)
				if out: break
	except Exception:
		pass
	return out

# ============================ Episode orders: TVDB v4 + TMDb episode groups ============================
# One list per show: Aired / DVD / Absolute / ... (TVDB, needs your TVDB API key and optional PIN) and TMDb's episode groups.
# Every order is turned into the same list of entries so browsing, playing and Autoplay's next episode all follow the chosen order.
TVDB_BASE = 'https://api4.thetvdb.com/v4'
_TVDB_TOKEN = {'token': '', 'at': 0, 'key': ''}
_TVDB_ORDERS = {}

def tvdb_login(api_key, pin=''):
	"""Bearer token for TVDB v4 (cached for this Kodi session, renewed after a day). '' when the key is refused."""
	import time
	now, same = time.time(), _TVDB_TOKEN['key'] == (api_key, pin)
	if _TVDB_TOKEN['token'] and same and now - _TVDB_TOKEN['at'] < 86400: return _TVDB_TOKEN['token']
	# a refused key or a network error is remembered for 5 minutes: every TVDB call must not post to /login again
	if not _TVDB_TOKEN['token'] and same and now - _TVDB_TOKEN['at'] < 300: return ''
	try:
		body = {'apikey': api_key}
		if pin and pin != 'empty_setting': body['pin'] = pin
		response = make_session().post(TVDB_BASE + '/login', json=body, timeout=20.0)
		token = (response.json().get('data') or {}).get('token') or ''
	except Exception: token = ''
	_TVDB_TOKEN.update({'token': token, 'at': time.time(), 'key': (api_key, pin)})
	return token

def tvdb_get(path, **params):
	from modules.settings import tvdb_api_key, tvdb_pin
	key = tvdb_api_key()
	if key in (None, '', 'empty_setting'): return {}
	token = tvdb_login(key, tvdb_pin())
	if not token: return {}
	try:
		response = make_session().get('%s/%s' % (TVDB_BASE, path), params=params, headers={'Authorization': 'Bearer %s' % token, 'Accept': 'application/json'}, timeout=20.0)
		return response.json() if response.status_code == 200 else {}
	except Exception: return {}

def tvdb_test_key():
	"""(ok, text) for the 'Test API Key' button."""
	from modules.settings import tvdb_api_key, tvdb_pin
	key = tvdb_api_key()
	if key in (None, '', 'empty_setting'): return False, 'No TVDB API key set.'
	_TVDB_TOKEN.update({'token': '', 'at': 0})
	return (True, 'TVDB accepted the key.') if tvdb_login(key, tvdb_pin()) else (False, 'TVDB refused the key (check the key and, for a subscriber key, the PIN).')

def tvdb_orders(tvdb_id):
	"""[(type, name)] of the orders TVDB has for this show, aired (official) first."""
	import time
	hit = _TVDB_ORDERS.get(str(tvdb_id))
	if hit and time.time() - hit[0] < 3600: data = hit[1]
	else:
		data = tvdb_get('series/%s/extended' % tvdb_id, meta='episodes', short='true')
		if data: _TVDB_ORDERS[str(tvdb_id)] = (time.time(), data)
	seen, out = set(), []
	for season in ((data or {}).get('data') or {}).get('seasons') or []:
		t = season.get('type') or {}
		if t.get('type') and t['type'] not in seen:
			seen.add(t['type']); out.append((t['type'], t.get('name') or t['type'].title()))
	out.sort(key=lambda o: (o[0] != 'official', o[0]))
	return out

_NON_LATIN = re.compile(r'[\u0370-\u03ff\u0400-\u04ff\u0590-\u06ff\u0e00-\u0e7f\u1100-\u11ff\u3040-\u30ff\u3100-\u312f\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af\uf900-\ufaff]')

def episode_title_for_skin(item):
	"""The episode name a list shows. Skin Settings > Episode titles: Japanese shows the name TVDB has in Japanese when there is one;
	English (the default) shows the title as it is."""
	try:
		from modules.kodi_utils import get_visibility
		if get_visibility('Skin.HasSetting(ns_jp_titles)'):
			original = item.get('original_title') or item.get('original')
			if original: return original
	except Exception: pass
	return item.get('title') or ''

def _tvdb_english_title(episode_id, name):
	"""The English title of a TVDB episode whose own name is not Latin text (Japanese, Russian, ...). Cached 30 days per episode;
	the name itself when TVDB has no English translation. Latin names are returned unchanged without a request."""
	if not _NON_LATIN.search(name or '') or episode_id in (None, '', 0): return name
	from caches.meta_cache import meta_cache
	prop = 'tvdb_eng_title_%s' % episode_id
	cached = meta_cache.get_function(prop)
	if cached is None:
		data = tvdb_get('episodes/%s/translations/eng' % episode_id)
		if not data: return name       # network / key problem: not cached, the name is shown for now
		cached = ((data.get('data') or {}).get('name') or '')
		meta_cache.set_function(prop, cached, expiration=720)
	return cached or name

def _tvdb_english_titles(entries):
	"""Puts the English title on every entry that has a non-Latin name (a few requests at a time, cached per episode)."""
	todo = [e for e in entries if _NON_LATIN.search(e.get('title') or '') and e.get('id')]
	if not todo: return entries
	from concurrent.futures import ThreadPoolExecutor
	with ThreadPoolExecutor(max_workers=8) as pool:
		for e, title in zip(todo, pool.map(lambda e: _tvdb_english_title(e['id'], e['title']), todo)): e['title'] = title or e['title']
	return entries

def tvdb_order_entries(tvdb_id, season_type):
	"""Entries of one TVDB order, in that order (seasons 1..N, then Specials)."""
	entries, page = [], 0
	while page < 12:
		data = tvdb_get('series/%s/episodes/%s' % (tvdb_id, season_type), page=page, lang='eng')
		eps = ((data or {}).get('data') or {}).get('episodes') or []
		for e in eps:
			entries.append({'id': e.get('id'), 'title': e.get('name') or '', 'original': e.get('name') or '', 'aired': e.get('aired') or '', 'season': int(e.get('seasonNumber') or 0), 'number': int(e.get('number') or 0),
							'absolute': e.get('absoluteNumber'), 'thumb': e.get('image') or '', 'plot': e.get('overview') or '', 'runtime': e.get('runtime'),
							'before_season': e.get('airsBeforeSeason'), 'before_episode': e.get('airsBeforeEpisode'), 'after_season': e.get('airsAfterSeason')})
		if not ((data or {}).get('links') or {}).get('next'): break
		page += 1
	entries = _tvdb_english_titles(entries)
	if season_type == 'absolute':
		entries.sort(key=lambda e: (e['season'] == 0, e['absolute'] or e['number'], e['season']))
	else:
		main = sorted([e for e in entries if e['season'] != 0], key=lambda e: (e['season'], e['number']))
		specials = sorted([e for e in entries if e['season'] == 0], key=lambda e: e['number'])
		# TVDB places a special where it aired: before episode N of season S, or after season S (the Aired Order list on thetvdb.com)
		slots = {}
		for sp in specials:
			pos = len(main)
			try:
				if sp.get('before_episode') and (sp.get('before_season') or sp.get('after_season')):
					season = int(sp.get('before_season') or sp.get('after_season'))
					pos = next((i for i, m in enumerate(main) if m['season'] == season and m['number'] >= int(sp['before_episode'])), None)
					if pos is None: pos = max([i + 1 for i, m in enumerate(main) if m['season'] == season] or [len(main)])
				elif sp.get('after_season') is not None:
					pos = max([i + 1 for i, m in enumerate(main) if m['season'] <= int(sp['after_season'])] or [0])
				elif sp.get('before_season') is not None:
					pos = next((i for i, m in enumerate(main) if m['season'] >= int(sp['before_season'])), len(main))
			except Exception: pos = len(main)
			slots.setdefault(pos, []).append(sp)
		entries = []
		for i, m in enumerate(main):
			entries.extend(slots.get(i, [])); entries.append(m)
		entries.extend(slots.get(len(main), []))
	return entries

def order_choices(tmdb_id, tvdb_id):
	"""[{'id','name','source'}] orders for a show: TVDB ones when a key is set, then TMDb episode groups."""
	out = []
	try:
		from modules.settings import tvdb_api_key
		if tvdb_id and tvdb_api_key() not in (None, '', 'empty_setting'):
			for t, name in tvdb_orders(tvdb_id):
				out.append({'id': 'tvdb:%s' % t, 'name': '%s (TVDB)' % ('Aired Order' if t == 'official' else name), 'source': 'tvdb'})
	except Exception: pass
	try:
		from modules.metadata import episode_groups
		for g in episode_groups(tmdb_id) or []:
			out.append({'id': 'tmdb:%s' % g['id'], 'name': '%s (TMDb)' % (g.get('name') or 'Group'), 'source': 'tmdb',
						'info': '%s episodes in %s groups' % (g.get('episode_count', ''), g.get('group_count', ''))})
	except Exception: pass
	return out

def _norm_title(text):
	return ' '.join(_title_words(text))

def order_entries(order_id, meta):
	"""The episodes of an order, in order, each with the TMDb season / episode it plays as (tmdb_season / tmdb_episode; an episode TMDb does
	not list plays as Specials with its own number and is found by its name)."""
	from modules.metadata import episodes_meta, all_episodes_meta
	source, _, key = str(order_id).partition(':')
	tmdb_eps = {}
	try:
		for e in all_episodes_meta(meta, include_specials=True): tmdb_eps[(e['season'], e['episode'])] = e
	except Exception: pass
	by_title, by_air = {}, {}
	for (s, n), e in tmdb_eps.items():
		by_title.setdefault(_norm_title(e.get('title')), (s, n))
		if e.get('premiered'): by_air.setdefault((e['premiered'], n), (s, n))
	entries = []
	if source == 'tvdb':
		entries = tvdb_order_entries(meta.get('tvdb_id'), key)
		for e in entries:
			hit = (e['season'], e['number']) if (e['season'], e['number']) in tmdb_eps and _norm_title(tmdb_eps[(e['season'], e['number'])].get('title')) == _norm_title(e['title']) else None
			hit = hit or by_title.get(_norm_title(e['title'])) or by_air.get((e['aired'], e['number']))
			if not hit and (e['season'], e['number']) in tmdb_eps and e['season'] != 0: hit = (e['season'], e['number'])
			e['tmdb_season'], e['tmdb_episode'] = hit if hit else (0, e['number'] or 1)
			e['mapped'] = bool(hit)
			if hit and meta.get('tmdb_id'): e['thumb'] = tmdb_still_map(meta.get('tmdb_id'), hit[0]).get(str(hit[1])) or e['thumb']
	elif source == 'tmdb':
		details = episode_group_details(key) or {}
		pos = 0
		for grp in sorted(details.get('groups') or [], key=lambda g: g.get('order', 0)):
			for e in sorted(grp.get('episodes') or [], key=lambda x: x.get('order', 0)):
				pos += 1
				entries.append({'title': e.get('name') or '', 'aired': e.get('air_date') or '', 'season': grp.get('order', 0), 'number': e.get('order', 0) + 1, 'absolute': pos,
								'thumb': ('https://image.tmdb.org/t/p/original%s' % e['still_path']) if e.get('still_path') else '', 'plot': e.get('overview') or '', 'runtime': e.get('runtime'),
								'tmdb_season': e.get('season_number'), 'tmdb_episode': e.get('episode_number'), 'mapped': True, 'group': grp.get('name') or ''})
	for i, e in enumerate(entries): e['index'] = i
	return entries

def order_special(entry):
	"""True for an entry that is a special in its order (season 0 there, or one TMDb has only as a Special)."""
	return bool(entry) and (entry.get('season') == 0 or entry.get('tmdb_season') == 0)

# ============================ TVDB first (seasons / episodes), TMDb as the fallback ============================
_TVDB_LOGGED = set()

def tvdb_first_enabled():
	try:
		from modules.settings import tvdb_api_key
		from caches.settings_cache import get_setting
		return get_setting('nightshift.tvdb_first', 'false') == 'true' and tvdb_api_key() not in (None, '', 'empty_setting')
	except Exception: return False

def _tvdb_log(key, text):
	if key in _TVDB_LOGGED: return
	_TVDB_LOGGED.add(key)
	try:
		from modules.kodi_utils import logger
		logger('TvdbFirst', text)
	except Exception: pass

def tvdb_all_episodes(tvdb_id):
	"""Every episode TVDB lists for a show in its aired (official) order, specials included. Cached for 6 hours; [] when TVDB has nothing."""
	from caches.meta_cache import meta_cache
	prop = 'tvdb_all_v2_%s' % tvdb_id
	data = meta_cache.get_function(prop)
	if data: return data
	data = tvdb_order_entries(tvdb_id, 'official')
	if data: meta_cache.set_function(prop, data, expiration=6)
	return data or []

def _tvdb_image(path):
	if not path: return None
	return path if str(path).startswith('http') else 'https://artworks.thetvdb.com%s' % (path if str(path).startswith('/') else '/' + str(path))

def tvdb_season_data(meta):
	"""TMDb's season_data list with TVDB's seasons: TVDB's episode counts and every season / Specials it has (TMDb's names and posters are kept)."""
	tvdb_id = meta.get('tvdb_id')
	if not tvdb_id or str(tvdb_id) in ('None', '', '0'): return None
	eps = tvdb_all_episodes(tvdb_id)
	if not eps: return None
	counts, first = {}, {}
	for e in eps:
		counts[e['season']] = counts.get(e['season'], 0) + 1
		if e.get('aired') and (e['season'] not in first or e['aired'] < first[e['season']]): first[e['season']] = e['aired']
	tmdb = {i.get('season_number'): dict(i) for i in (meta.get('season_data') or [])}
	out = []
	for number in sorted(counts):
		item = tmdb.get(number) or {'season_number': number, 'name': 'Specials' if number == 0 else 'Season %s' % number, 'overview': '', 'poster_path': None, 'air_date': first.get(number)}
		item['episode_count'] = counts[number]
		if not item.get('air_date'): item['air_date'] = first.get(number)
		out.append(item)
	return out

def tmdb_still_map(tmdb_id, season):
	"""{'episode': original-size TMDb still url} for one TMDb season, cached for 7 days. TVDB's episode images are only 400 px wide,
	TMDb's stills are the full original, so a TVDB-sourced episode keeps TVDB's data but uses this picture when TMDb has one."""
	from caches.meta_cache import meta_cache
	prop = 'tmdb_stills_%s_%s' % (tmdb_id, season)
	data = meta_cache.get_function(prop)
	if data is None:
		try: eps = (season_episodes_details(tmdb_id, int(season)) or {}).get('episodes') or []
		except Exception: eps = []
		data = {str(e['episode_number']): 'https://image.tmdb.org/t/p/original%s' % e['still_path'] for e in eps if e.get('episode_number') is not None and e.get('still_path')}
		if eps: meta_cache.set_function(prop, data, expiration=168)
	return data

def tvdb_episode_rows(meta, season):
	"""episodes_meta()-shaped rows for one season from TVDB, or None (the caller then uses TMDb)."""
	tvdb_id = meta.get('tvdb_id')
	if not tvdb_id or str(tvdb_id) in ('None', '', '0'): return None
	rows = []
	for e in tvdb_all_episodes(tvdb_id):
		if e['season'] != int(season): continue
		try: duration = int(e.get('runtime')) * 60
		except Exception: duration = 30 * 60
		rows.append({'writer': [], 'director': [], 'mediatype': 'episode', 'episode_type': '', 'episode_id': None, 'title': e.get('title') or 'Episode %s' % e['number'],
					'plot': e.get('plot') or '', 'duration': duration, 'premiered': e.get('aired') or '', 'season': e['season'], 'episode': e['number'], 'original_title': e.get('original') or '', 'rating': 0, 'votes': 0,
					'thumb': _tvdb_image(e.get('thumb')), 'guest_stars': []})
	if rows:
		stills = tmdb_still_map(meta.get('tmdb_id'), season)
		for r in rows: r['thumb'] = stills.get(str(r['episode'])) or r['thumb']
	rows.sort(key=lambda r: r['episode'])
	return rows or None
