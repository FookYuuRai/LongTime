"""Library and discovery widgets."""
