"""Online data for a title: TMDB details plus OMDb, MDBList and Trakt ratings, as properties."""
from __future__ import annotations

from typing import Dict, Optional

import xbmc

from lib.data.database.cache import CacheKey
from lib.kodi.client import log
from lib.kodi.formatters import (
    format_rating_props,
    build_common_sense_summary,
    RATING_SOURCE_NORMALIZE,
)
from lib.kodi.utilities import MULTI_VALUE_SEP


# MDBList only
_AWARD_PROPS = {
    "oscar-winner": "Awards.Oscar.Won",
    "oscar-nominated": "Awards.Oscar.Nominated",
    "best-picture-winner": "Awards.BestPicture.Won",
    "best-picture-nominated": "Awards.BestPicture.Nominated",
    "oscar-best-director-winner": "Awards.BestDirector.Won",
    "oscar-best-director-nominee": "Awards.BestDirector.Nominated",
    "golden-globe-winner": "Awards.GoldenGlobe.Won",
    "golden-globe-nominated": "Awards.GoldenGlobe.Nominated",
    "razzie-winner": "Awards.Razzie.Won",
    "razzie-nominee": "Awards.Razzie.Nominated",
    "emmy-award-winner": "Awards.Emmy.Won",
    "emmy-award-nominated": "Awards.Emmy.Nominated",
    "festival-cannes-winner": "Awards.Festival.Cannes",
    "festival-venice-winner": "Awards.Festival.Venice",
    "festival-sundance-winner": "Awards.Festival.Sundance",
    "festival-toronto-winner": "Awards.Festival.Toronto",
    "national-film-preservation-board-winner": "Awards.FilmRegistry",
    "national-film-registry": "Awards.FilmRegistry",
}

_STATUS_PROPS = {
    "tomatoes": "Tomatometer",
    "popcorn": "Popcornmeter",
    "metacritic": "Metacritic",
    "rogerebert": "RogerEbert",
}


def fetch_omdb_data(media_type: str, imdb_id: str, abort_flag=None) -> Dict[str, str]:
    """Fetch OMDb awards plus ratings (imdb/metacritic/rotten tomatoes) from the same response."""
    from lib.data.api.omdb import ApiOmdb

    props: Dict[str, str] = {}

    if not imdb_id:
        return props

    if abort_flag and abort_flag.is_requested():
        return props

    try:
        omdb = ApiOmdb()
        awards = omdb.get_awards(media_type, imdb_id, abort_flag=abort_flag)
        if awards:
            props["Awards"] = awards

    except Exception as e:
        log("Service", f"OMDb fetch error: {e}", xbmc.LOGWARNING)

    return props


def fetch_mdblist_data(
    media_type: str,
    imdb_id: str,
    tmdb_id: str,
    is_episode: bool,
    abort_flag=None
) -> Dict[str, str]:
    """Fetch MDBList data (extra info, common sense, ratings)."""
    from lib.data.api.mdblist import ApiMdblist

    props: Dict[str, str] = {}

    if not imdb_id and not tmdb_id:
        return props

    if abort_flag and abort_flag.is_requested():
        return props

    mdblist_media_type = "tvshow" if is_episode else media_type

    try:
        mdblist = ApiMdblist()
        ids = {"imdb": imdb_id, "tmdb": tmdb_id}

        extra_data = mdblist.get_extra_data(mdblist_media_type, ids, abort_flag=abort_flag)
        if abort_flag and abort_flag.is_requested():
            return props
        if extra_data:
            if "trailer" in extra_data:
                props["MDBList.Trailer"] = extra_data["trailer"]
            if "certification" in extra_data:
                props["MDBList.Certification"] = extra_data["certification"]

        cs_data = mdblist.get_common_sense_data(mdblist_media_type, ids, abort_flag=abort_flag)
        if abort_flag and abort_flag.is_requested():
            return props
        if cs_data:
            props["CommonSense.Age"] = str(cs_data["age"])
            props["CommonSense.Violence"] = str(cs_data["violence"])
            props["CommonSense.Nudity"] = str(cs_data["nudity"])
            props["CommonSense.Language"] = str(cs_data["language"])
            props["CommonSense.Drinking"] = str(cs_data["drinking"])
            props["CommonSense.Selection"] = "true" if cs_data["selection"] else "false"

            summary, reasons = build_common_sense_summary(cs_data)
            if summary:
                props["CommonSense.Summary"] = summary
                props["CommonSense.Reasons"] = reasons

        for tag in mdblist.get_award_tags(mdblist_media_type, ids, abort_flag=abort_flag):
            prop = _AWARD_PROPS.get(tag)
            if prop:
                props[prop] = "true"

    except Exception as e:
        log("Service", f"MDBList fetch error: {e}", xbmc.LOGWARNING)

    return props


def _fetch_trakt_fallback(media_type: str, imdb_id: str, tmdb_id: str, is_episode: bool,
                          abort_flag=None) -> Dict[str, str]:
    """With no Trakt Client ID: Trakt's rating as MDBList carries it, else Simkl's own rating."""
    props: Dict[str, str] = {}
    # Ratings disabled: no MDBList/Simkl rating lookups.
    return props
    ids = {"imdb": imdb_id or "", "tmdb": tmdb_id or ""}
    try:
        from lib.kodi.client import get_api_key
        if get_api_key("mdblist_api_key"):
            from lib.data.api.mdblist import ApiMdblist
            ratings = ApiMdblist().fetch_ratings(media_type, ids, abort_flag=abort_flag)
            if ratings and "trakt" in ratings:
                data = ratings["trakt"]
                props.update(format_rating_props("trakt", data["rating"], int(data["votes"])))
                return props
        from lib.data.api.simkl import ApiSimkl, simkl_client_id
        if simkl_client_id():
            ratings = ApiSimkl().fetch_ratings(media_type, ids, abort_flag=abort_flag)
            if ratings and "simkl" in ratings:
                data = ratings["simkl"]
                props.update(format_rating_props("simkl", data["rating"], int(data["votes"])))
    except Exception as e:
        log("Service", f"Trakt fallback fetch error: {e}", xbmc.LOGWARNING)
    return props


def fetch_trakt_data(
    media_type: str,
    imdb_id: str,
    tmdb_id: str,
    is_episode: bool,
    season: Optional[int],
    episode: Optional[int],
    abort_flag=None
) -> Dict[str, str]:
    """Fetch Trakt ratings and subgenres."""
    from lib.data.api.trakt import ApiTrakt

    props: Dict[str, str] = {}

    if not imdb_id and not tmdb_id:
        return props

    if abort_flag and abort_flag.is_requested():
        return props

    from lib.data.api.trakt import trakt_client_id
    if not trakt_client_id():
        return _fetch_trakt_fallback(media_type, imdb_id, tmdb_id, is_episode, abort_flag)

    try:
        trakt = ApiTrakt()
        trakt_ids: Dict[str, str] = {"imdb": imdb_id or "", "tmdb": tmdb_id or ""}
        if is_episode and season is not None and episode is not None:
            trakt_ids["season"] = str(season)
            trakt_ids["episode"] = str(episode)

        if not is_episode:
            trakt_id = imdb_id or tmdb_id
            subgenres = trakt.get_subgenres(trakt_id, media_type, abort_flag=abort_flag)
            if subgenres:
                props["Trakt.Subgenres"] = MULTI_VALUE_SEP.join(subgenres)
    except Exception as e:
        log("Service", f"Trakt fetch error: {e}", xbmc.LOGWARNING)

    return props


def fetch_all_online_data(media_type: str, imdb_id: str, tmdb_id: str,
                          abort_flag=None,
                          is_library_item: bool = True) -> Dict[str, str]:
    """Fetch TMDB details and OMDb, MDBList and Trakt ratings as one flat property dict."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from lib.data.api.tmdb import resolve_tmdb_id

    props: Dict[str, str] = {}
    is_episode = media_type == "episode"

    if abort_flag and abort_flag.is_requested():
        return props

    resolved_tmdb_id = resolve_tmdb_id(
        tmdb_id,
        imdb_id,
        "tvshow" if is_episode else media_type
    )

    if not imdb_id and not resolved_tmdb_id:
        return props

    if abort_flag and abort_flag.is_requested():
        return props

    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {}

        if resolved_tmdb_id and not is_episode:
            futures[executor.submit(
                _fetch_tmdb_full_data,
                media_type,
                resolved_tmdb_id,
                abort_flag,
                is_library_item
            )] = "tmdb"

        if imdb_id and not is_episode:
            futures[executor.submit(
                fetch_omdb_data,
                media_type,
                imdb_id,
                abort_flag
            )] = "omdb"

        if (imdb_id or resolved_tmdb_id) and not is_episode:
            futures[executor.submit(
                fetch_mdblist_data,
                media_type,
                imdb_id,
                resolved_tmdb_id or "",
                is_episode,
                abort_flag
            )] = "mdblist"

        if imdb_id or resolved_tmdb_id:
            futures[executor.submit(
                fetch_trakt_data,
                media_type,
                imdb_id,
                resolved_tmdb_id or "",
                is_episode,
                None,
                None,
                abort_flag
            )] = "trakt"

        results: Dict[str, Dict[str, str]] = {}
        for future in as_completed(futures):
            if abort_flag and abort_flag.is_requested():
                executor.shutdown(wait=False)
                return props

            source = futures[future]
            try:
                result = future.result()
                if result:
                    results[source] = result
            except Exception as e:
                log("Service", f"Online fetch error ({source}): {e}", xbmc.LOGWARNING)

    # a later source wins a shared key, so MDBList's ratings override OMDb's
    for source in ("tmdb", "omdb", "mdblist", "trakt"):
        if source in results:
            props.update(results[source])

    return props


def fetch_tmdb_online_data(
    media_type: str,
    imdb_id: str,
    tmdb_id: str,
    abort_flag=None,
    is_library_item: bool = True
) -> Dict[str, str]:
    """Fetch only TMDB data and return as property dictionary."""
    from lib.data.api.tmdb import resolve_tmdb_id

    is_episode = media_type == "episode"

    if abort_flag and abort_flag.is_requested():
        return {}

    resolved_tmdb_id = resolve_tmdb_id(
        tmdb_id, imdb_id, "tvshow" if is_episode else media_type
    )
    if not resolved_tmdb_id or is_episode:
        return {}

    return _fetch_tmdb_full_data(
        media_type, resolved_tmdb_id, abort_flag, is_library_item=is_library_item
    ) or {}


def _fetch_tmdb_full_data(media_type: str, tmdb_id: str,
                          abort_flag=None,
                          is_library_item: bool = True) -> Dict[str, str]:
    """Fetch TMDB metadata and format as a property dict via `lib.kodi.formatters`."""
    from lib.data.api.tmdb import ApiTmdb
    from lib.kodi.formatters import (
        format_rating_props,
        format_movie_props,
        format_tvshow_props,
        format_credits_props,
        format_images_props,
        format_extra_props,
    )

    props: Dict[str, str] = {}

    if abort_flag and abort_flag.is_requested():
        return props

    try:
        api = ApiTmdb()
        data = api.get_complete_data(
            media_type, int(tmdb_id), abort_flag=abort_flag, is_library_item=is_library_item
        )

        if abort_flag and abort_flag.is_requested():
            return props

        if not data:
            return props

        if media_type == "movie":
            props.update(format_movie_props(data))
        else:
            props.update(format_tvshow_props(data))

        vote_avg = data.get("vote_average")
        vote_cnt = data.get("vote_count")
        if vote_avg is not None and vote_cnt is not None:
            props.update(format_rating_props("tmdb", float(vote_avg), int(vote_cnt)))

        props.update(format_credits_props(data))
        props.update(format_images_props(data))
        props.update(format_extra_props(data))

    except Exception as e:
        log("Service", f"TMDb full fetch error: {e}", xbmc.LOGWARNING)

    return props


def get_online_ttl(media_type: str, tmdb_id: str) -> int:
    """Get the online-properties TTL from the title's cached TMDB data, 72 hours without it."""
    from lib.data.database.cache import get_title_ttl_hours

    return get_title_ttl_hours(media_type, tmdb_id) or 72


def make_cache_key(media_type: str, imdb_id: str, tmdb_id: str,
                   scope: str = '') -> Optional[CacheKey]:
    """Build a cache key on the TMDB id, the IMDb id when there is none."""
    item_id = tmdb_id or imdb_id
    return CacheKey(media_type, item_id, scope) if item_id else None


def show_scoped_props(props: Dict[str, str]) -> Dict[str, str]:
    """Move a show's ratings and rating statuses under `TVShow.`, for its episode or season."""
    statuses = set(_STATUS_PROPS.values())
    return {f"TVShow.{key}" if key.startswith("Rating.") or key in statuses else key: value
            for key, value in props.items()}
