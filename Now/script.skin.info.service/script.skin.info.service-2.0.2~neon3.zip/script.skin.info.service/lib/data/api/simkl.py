"""Simkl API client: trending lists and ratings, the last fallback when Trakt and MDBList give nothing."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional

import xbmc

from lib.data.api.client import ApiSession
from lib.data.api.source import RatingSource
from lib.kodi.client import log
from lib.kodi.settings import KodiSettings

POSTER_URL = "https://simkl.in/posters/{}_m.jpg"
FANART_URL = "https://simkl.in/fanart/{}_medium.jpg"


def simkl_client_id() -> str:
    """The user's own Simkl Client ID from settings; empty when none is set."""
    return (KodiSettings.get_string("simkl_client_id") or "").strip()


class ApiSimkl(RatingSource):
    """Simkl client; trending needs no key, ratings and id lookups need the user's Client ID."""

    BASE_URL = "https://api.simkl.com"

    def __init__(self):
        super().__init__("simkl")
        headers = {"Accept": "application/json"}
        client_id = simkl_client_id()
        if client_id:
            headers["simkl-api-key"] = client_id
        self.session = ApiSession(
            service_name="Simkl",
            base_url=self.BASE_URL,
            timeout=(5.0, 10.0),
            max_retries=2,
            backoff_factor=1.0,
            rate_limit=(10, 1.0),
            default_headers=headers,
        )

    def supports(self, media_type: str) -> bool:
        """Simkl rates movies and shows; episodes are not covered."""
        return media_type in ("movie", "tvshow")

    @staticmethod
    def _kind(media_type: str) -> str:
        return "movies" if media_type == "movie" else "tv"

    def _details(self, media_type: str, simkl_id: Any, abort_flag=None) -> Optional[dict]:
        """Full Simkl record (ids, genres, ratings, overview) for a Simkl id, cached."""
        cache_key = f"simkl_{simkl_id}"
        cached = self.get_cached_data(media_type, cache_key)
        if cached:
            return cached
        data = self.session.get(
            f"/{self._kind(media_type)}/{simkl_id}",
            params={"extended": "full"},
            abort_flag=abort_flag,
        )
        if isinstance(data, dict) and data.get("ids"):
            self.cache_data(media_type, cache_key, data)
            return data
        return None

    def _find_simkl_id(self, ids: Dict[str, str], abort_flag=None) -> Optional[str]:
        """Look a Simkl id up by IMDb, else TMDB id; needs the user's Client ID."""
        if not simkl_client_id():
            return None
        for key in ("imdb", "tmdb"):
            value = ids.get(key)
            if not value:
                continue
            params = {key: value, "client_id": simkl_client_id()}
            raw: Any = self.session.get("/search/id", params=params, abort_flag=abort_flag)
            if isinstance(raw, list) and raw:
                simkl_ids = (raw[0] or {}).get("ids") or {}
                found = simkl_ids.get("simkl_id") or simkl_ids.get("simkl")
                if found:
                    return str(found)
        return None

    def fetch_data(self, media_type: str, ids: Dict[str, str], abort_flag=None,
                   force_refresh: bool = False) -> Optional[dict]:
        """Full Simkl data for one title; None without a Client ID or a match."""
        if not self.supports(media_type):
            return None
        simkl_id = self._find_simkl_id(ids, abort_flag)
        if not simkl_id:
            return None
        return self._details(media_type, simkl_id, abort_flag)

    def fetch_ratings(self, media_type: str, ids: Dict[str, str], abort_flag=None,
                      force_refresh: bool = False) -> Optional[Dict[str, Dict[str, float]]]:
        """Simkl's own rating, 0-10, keyed 'simkl'."""
        data = self.fetch_data(media_type, ids, abort_flag, force_refresh)
        rating = (((data or {}).get("ratings") or {}).get("simkl") or {})
        if not rating.get("rating"):
            return None
        result: Dict[str, Any] = {
            "simkl": {"rating": self.normalize_rating(rating["rating"], 10),
                      "votes": float(rating.get("votes") or 0)},
            "_source": "simkl",
        }
        return result

    def get_trending(self, media_type: str, limit: int = 20, page: int = 1,
                     abort_flag=None) -> List[dict]:
        """Trending titles as normalized dicts; ids are resolved per title so the library can match."""
        raw: Any = self.session.get(
            f"/{self._kind(media_type)}/trending",
            params={"extended": "overview", "interval": "week"},
            abort_flag=abort_flag,
        )
        if not isinstance(raw, list):
            return []
        start = max(0, (page - 1) * limit)
        chunk = [r for r in raw[start:start + limit] if isinstance(r, dict)]

        def resolve(item: dict) -> dict:
            simkl_id = (item.get("ids") or {}).get("simkl_id")
            full = self._details(media_type, simkl_id, abort_flag) if simkl_id else None
            return self._normalize(item, full or {}, media_type)

        with ThreadPoolExecutor(max_workers=4) as pool:
            return list(pool.map(resolve, chunk))

    @staticmethod
    def _normalize(item: dict, full: dict, media_type: str) -> dict:
        """One normalized listitem dict, preferring the full record where there is one."""
        ids = full.get("ids") or {}
        ratings = (full.get("ratings") or item.get("ratings") or {})
        best = ratings.get("imdb") or ratings.get("simkl") or {}
        poster = full.get("poster") or item.get("poster")
        fanart = full.get("fanart") or item.get("fanart")
        premiered = (full.get("released") or full.get("first_aired")
                     or item.get("release_date") or "")
        try:
            year = int(full.get("year") or str(premiered)[:4] or 0)
        except (TypeError, ValueError):
            year = 0
        return {
            "title": full.get("title") or item.get("title", ""),
            "original_title": full.get("title") or item.get("title", ""),
            "year": year,
            "overview": full.get("overview") or item.get("overview", ""),
            "rating": best.get("rating", 0.0),
            "votes": best.get("votes", 0),
            "runtime": full.get("runtime") if isinstance(full.get("runtime"), int) else 0,
            "genres": full.get("genres") or [],
            "certification": full.get("certification", ""),
            "premiered": str(premiered)[:10] if "-" in str(premiered) else "",
            "poster": POSTER_URL.format(poster) if poster else "",
            "fanart": FANART_URL.format(fanart) if fanart else "",
            "tmdb_id": ids.get("tmdb"),
            "imdb_id": ids.get("imdb", ""),
            "media_type": media_type,
        }

    def test_connection(self) -> bool:
        """Whether the stored Client ID is accepted."""
        if not simkl_client_id():
            return False
        raw: Any = self.session.get(
            "/search/id", params={"imdb": "tt0133093", "client_id": simkl_client_id()})
        ok = isinstance(raw, list) and bool(raw)
        log("Simkl", f"Connection test {'ok' if ok else 'failed'}", xbmc.LOGDEBUG)
        return ok
