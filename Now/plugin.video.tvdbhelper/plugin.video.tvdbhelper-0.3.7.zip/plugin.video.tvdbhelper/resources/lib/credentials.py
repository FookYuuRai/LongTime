# -*- coding: utf-8 -*-
"""Strong password-based envelope for the built-in TVDB credentials.

Encryption at rest: scrypt (N=2^16, r=8, p=1) + AES-256-GCM.
The password is never stored in the add-on or Kodi settings.
"""
import base64
import hashlib
import json

# Kodi's script.module.pycryptodome 3.4.3 packages the Crypto namespace.
# Keep that as the primary import; Cryptodome is a compatibility fallback
# for separately installed pycryptodomex distributions.
_AES_IMPORT_ERRORS = []
try:
    from Crypto.Cipher import AES
except Exception as exc:
    _AES_IMPORT_ERRORS.append('Crypto: %s' % exc)
    try:
        from Cryptodome.Cipher import AES
    except Exception as fallback_exc:
        _AES_IMPORT_ERRORS.append('Cryptodome: %s' % fallback_exc)
        AES = None

_SCRYPT_N = 1 << 16
_SCRYPT_R = 8
_SCRYPT_P = 1
_SCRYPT_MAXMEM = 128 * 1024 * 1024
_AAD = b'plugin.video.tvdbhelper.credentials.v2'
_SALT = '88zGVIerpgTeweRNZ2Cr3Q=='
_NONCE = 'Fhf1Gxja0IMfMnbw'
_CIPHERTEXT = 'bFdhivPQUYm9DReCGISJWH7lFUfvN2EERSCJuvlygA8UFo3paW/BTxakoFZCnCi2Hz8YZi3oVaE7MInYn1ctSx9tG5VqPR79KT7Y81m8IfsNzJ/5uryKBkbgNQG4xIKfP7nkfdVPtpmyCP2O'
_TAG = 'LEjHU7/p6svndii1OVCjoA=='


def _unb64(value):
    return base64.b64decode(value.encode('ascii'))


def decrypt(password):
    """Return both TVDB keys; reject wrong passwords and altered payloads."""
    if not isinstance(password, str) or not password:
        raise ValueError('Unlock password is required.')
    if AES is None:
        raise RuntimeError('Could not load AES from script.module.pycryptodome. ' + '; '.join(_AES_IMPORT_ERRORS))
    try:
        key = hashlib.scrypt(
            password.encode('utf-8'), salt=_unb64(_SALT),
            n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P,
            maxmem=_SCRYPT_MAXMEM, dklen=32)
    except (AttributeError, ValueError, TypeError) as exc:
        raise RuntimeError('This Kodi build does not provide the required scrypt support.') from exc
    try:
        cipher = AES.new(key, AES.MODE_GCM, nonce=_unb64(_NONCE), mac_len=16)
        cipher.update(_AAD)
        raw = cipher.decrypt_and_verify(_unb64(_CIPHERTEXT), _unb64(_TAG))
        payload = json.loads(raw.decode('utf-8'))
        api_key = payload['api_key']
        pin_key = payload['api_key_with_pin']
    except (ValueError, KeyError, TypeError, UnicodeError):
        raise ValueError('Unlock password is incorrect or encrypted credential data was modified.')
    if not isinstance(api_key, str) or not api_key or not isinstance(pin_key, str) or not pin_key:
        raise ValueError('Encrypted credential data is incomplete.')
    return {'api_key': api_key, 'api_key_with_pin': pin_key}
