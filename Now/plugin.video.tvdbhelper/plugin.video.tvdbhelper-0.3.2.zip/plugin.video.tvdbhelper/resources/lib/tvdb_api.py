# -*- coding: utf-8 -*-
"""Minimal TheTVDB v4 client. Credentials are supplied by the add-on unlock flow."""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

API = 'https://api4.thetvdb.com/v4'
USER_AGENT = 'TVDB Helper for Kodi (plugin.video.tvdbhelper)'
SEARCH_TYPES = ('series', 'movie', 'person', 'company')
DEFAULT_ORDERS = [('official', 'Aired Order'), ('dvd', 'DVD Order'),
                  ('absolute', 'Absolute Order'), ('alternate', 'Alternate Order')]


class TVDBError(Exception):
    pass


class FileCache:
    """Small JSON cache on disk. Kodi starts a new process for every page, so memory alone is not enough."""

    def __init__(self, folder, ttl_seconds=24 * 3600):
        self.folder, self.ttl = folder, ttl_seconds

    def _path(self, key):
        safe = ''.join(c if c.isalnum() else '_' for c in key)[:120]
        return os.path.join(self.folder, safe + '.json')

    def get(self, key):
        if not self.folder: return None
        try:
            with open(self._path(key), 'r', encoding='utf-8') as f:
                stored = json.load(f)
            if time.time() - stored['ts'] > self.ttl: return None
            return stored['value']
        except (OSError, ValueError, KeyError):
            return None

    def set(self, key, value):
        if not self.folder: return
        try:
            os.makedirs(self.folder, exist_ok=True)
            with open(self._path(key), 'w', encoding='utf-8') as f:
                json.dump({'ts': time.time(), 'value': value}, f)
        except OSError:
            pass




class Client:
    def __init__(self, apikey, pin='', language='eng', country='usa', cache=None, opener=None, timeout=20):
        self.apikey, self.pin = (apikey or '').strip(), (pin or '').strip()
        if not self.apikey:
            raise TVDBError('TVDB credentials are locked. Enter the unlock password in add-on settings.')
        self.language, self.country = language or 'eng', country or 'usa'
        self.cache = cache
        self._open = opener or urllib.request.urlopen
        self.timeout = timeout
        self._token = None

    # ---- transport
    def _request(self, method, path, params=None, body=None, auth=True, _retry=True):
        url = API + path
        if params:
            url += '?' + urllib.parse.urlencode(params)
        headers = {'Accept': 'application/json', 'User-Agent': USER_AGENT}
        data = None
        if body is not None:
            data = json.dumps(body).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        if auth:
            headers['Authorization'] = 'Bearer ' + self._login()
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with self._open(req, timeout=self.timeout) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as err:
            if err.code == 401 and auth and _retry:      # token expired: log in again once
                self._token = None
                return self._request(method, path, params, body, auth, _retry=False)
            raise TVDBError('TheTVDB returned HTTP %s for %s' % (err.code, path))
        except urllib.error.URLError as err:
            raise TVDBError('Could not reach TheTVDB: %s' % err.reason)
        try:
            return json.loads(raw.decode('utf-8'))
        except ValueError:
            raise TVDBError('TheTVDB sent a response that is not JSON for %s' % path)

    def _login(self):
        if self._token: return self._token
        body = {'apikey': self.apikey}
        if self.pin: body['pin'] = self.pin
        res = self._request('POST', '/login', body=body, auth=False)
        try:
            self._token = res['data']['token']
        except (KeyError, TypeError):
            raise TVDBError('TheTVDB login failed: check the API key (and PIN, if you use one).')
        return self._token

    def _cached(self, key, fetch):
        if self.cache:
            hit = self.cache.get(key)
            if hit is not None: return hit
        value = fetch()
        if self.cache and value is not None: self.cache.set(key, value)
        return value

    def _get(self, path, params=None):
        return (self._request('GET', path, params=params) or {}).get('data')

    # ---- search: type is series, movie, person or company (see swagger /search)
    def search(self, query, kind='series', year=None, primary_type=None, company=None, limit=50):
        if kind not in SEARCH_TYPES: raise TVDBError('Unknown search type: %s' % kind)
        params = {'query': query, 'type': kind, 'limit': limit}
        if year: params['year'] = year
        if primary_type: params['primaryType'] = primary_type
        if company: params['company'] = company
        key = 'search_%s_%s_%s_%s_%s' % (kind, query, year or '', primary_type or '', company or '')
        return self._cached(key, lambda: self._get('/search', params) or [])

    # ---- series (TV shows and anime)
    def series_extended(self, series_id):
        key = 'series_%s_%s' % (series_id, self.language)
        return self._cached(key, lambda: self._get('/series/%d/extended' % int(series_id), {'meta': 'translations'}) or {})

    def season_types(self, series_id):
        """The orders TheTVDB offers for this show (Aired, DVD, Absolute, ...). Falls back to the four common ones."""
        ext = self.series_extended(series_id)
        found = []
        for st in ext.get('seasonTypes') or []:
            slug = (st.get('type') or '').lower()
            if slug and all(slug != s for s, _n in found):
                found.append((slug, st.get('name') or slug.title()))
        return found or list(DEFAULT_ORDERS)

    def episodes_page(self, series_id, season_type, page=0):
        # swagger: /series/{id}/episodes/{season-type}  and  /series/{id}/episodes/{season-type}/{lang}
        path = '/series/%d/episodes/%s' % (int(series_id), season_type)
        if self.language: path += '/' + self.language
        key = 'eps_%s_%s_%s_%s' % (series_id, season_type, page, self.language)
        return self._cached(key, lambda: self._request('GET', path, params={'page': page}) or {})

    def all_episodes(self, series_id, season_type):
        """Every episode for one order, following TheTVDB's paging (page is required by the API)."""
        out, page = [], 0
        while True:
            res = self.episodes_page(series_id, season_type, page)
            out.extend((res.get('data') or {}).get('episodes') or [])
            if not (res.get('links') or {}).get('next'): break
            page += 1
            if page > 200: break
        return out

    # ---- movies
    def movie_extended(self, movie_id):
        key = 'movie_%s_%s' % (movie_id, self.language)
        return self._cached(key, lambda: self._get('/movies/%d/extended' % int(movie_id), {'meta': 'translations'}) or {})

    # ---- people (actors, directors, ...)
    def person_extended(self, person_id):
        key = 'person_%s_%s' % (person_id, self.language)
        return self._cached(key, lambda: self._get('/people/%d/extended' % int(person_id), {'meta': 'episodes'}) or {})

    # ---- companies (studios, networks, production companies)
    def company(self, company_id):
        key = 'company_%s' % company_id
        return self._cached(key, lambda: self._get('/companies/%d' % int(company_id)) or {})

    # swagger: /series/filter and /movies/filter take no page; they return one list for a production company
    def company_series(self, company_id):
        return self._cached('cseries_%s' % company_id, lambda: self._request(
            'GET', '/series/filter', params={'company': int(company_id), 'country': self.country,
                                             'lang': self.language, 'sort': 'score'}) or {})

    def company_movies(self, company_id):
        return self._cached('cmovies_%s' % company_id, lambda: self._request(
            'GET', '/movies/filter', params={'company': int(company_id), 'country': self.country,
                                             'lang': self.language, 'sort': 'score'}) or {})


def kind_and_id(item):
    """A search result's kind and numeric id. objectID looks like 'series-81189'; fall back to id."""
    raw = item.get('objectID') or item.get('id') or ''
    kind, _, num = raw.partition('-')
    if kind not in SEARCH_TYPES or not num.isdigit():
        kind, num = item.get('type') or '', str(item.get('tvdb_id') or '')
    return kind, num


def credits_by_title(person_ext):
    """Group a person's character credits by movie or series. Returns [(kind, id, name, year, role)]."""
    out, seen = [], set()
    for ch in person_ext.get('characters') or []:
        if ch.get('movieId'):
            kind, cid, info = 'movie', ch.get('movieId'), ch.get('movie') or {}
        elif ch.get('seriesId'):
            kind, cid, info = 'series', ch.get('seriesId'), ch.get('series') or {}
        else:
            continue
        if (kind, cid) in seen: continue
        seen.add((kind, cid))
        out.append((kind, cid, info.get('name') or ch.get('name') or '?', str(info.get('year') or ''), ch.get('name') or ''))
    return out


def is_anime(item):
    genres = [g.lower() for g in (item.get('genres') or []) if isinstance(g, str)]
    return 'anime' in genres or (item.get('primary_language') or '').lower() in ('jpn', 'ja', 'japanese')


def group_seasons(episodes):
    """{season_number: [episode, ...]} with each season in episode order. Specials (season 0) sort first."""
    seasons = {}
    for ep in episodes:
        num = ep.get('seasonNumber')
        if num is None or ep.get('number') is None: continue
        seasons.setdefault(int(num), []).append(ep)
    for eps in seasons.values():
        eps.sort(key=lambda e: int(e.get('number') or 0))
    return dict(sorted(seasons.items()))


def episode_label(ep):
    return 'S%02dE%02d' % (int(ep.get('seasonNumber') or 0), int(ep.get('number') or 0))
