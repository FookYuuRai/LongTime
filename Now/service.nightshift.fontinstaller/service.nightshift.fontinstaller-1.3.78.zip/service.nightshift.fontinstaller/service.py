# -*- coding: utf-8 -*-
# NightShift font installer service; downloads one pinned public GitHub Release asset.
import hashlib
import os
import shutil
import tempfile
import time
import urllib.request
import zipfile
import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'service.nightshift.fontinstaller'
SKIN_ID = 'skin.nightshift'
PACK_URL = 'https://fookyuurai.github.io/LongTime/assets/nightshift/fontpack_combined.zip'
PACK_SHA256 = '99f85a7a2e1522446bc49bea0021df77367881f29a4b48e476c1b82a639643cc'
FONT_NAMES = ['NS_combined_base.ttf', 'NS_combined_black.ttf', 'NS_combined_blue.ttf', 'NS_combined_purple.ttf']
MAX_PACK_BYTES = 100 * 1024 * 1024
LOG_PREFIX = '[NightShift Font Installer] '

def log(message, level=xbmc.LOGINFO):
    xbmc.log(LOG_PREFIX + str(message), level)

def _download(path):
    digest = hashlib.sha256()
    size = 0
    request = urllib.request.Request(PACK_URL, headers={'User-Agent': 'NightShift-Font-Installer'})
    with urllib.request.urlopen(request, timeout=90) as response, open(path, 'wb') as target:
        while True:
            block = response.read(1024 * 1024)
            if not block:
                break
            size += len(block)
            if size > MAX_PACK_BYTES:
                raise RuntimeError('font archive exceeds safety size limit')
            target.write(block)
            digest.update(block)
    if digest.hexdigest() != PACK_SHA256:
        raise RuntimeError('font pack SHA-256 verification failed')

def _remove_stale_staging():
    # A hard kill (force stop) skips the finally cleanup, so each run first removes whatever an earlier killed run left behind.
    kodi_temp = xbmcvfs.translatePath('special://temp/')
    fonts_dir = _fonts_dir_path()
    removed = 0
    for folder in (fonts_dir, kodi_temp):
        if not folder or not os.path.isdir(folder):
            continue
        for name in os.listdir(folder):
            path = os.path.join(folder, name)
            try:
                if os.path.isdir(path) and name.startswith('.nightshift-fonts-') and folder == fonts_dir:
                    shutil.rmtree(path, ignore_errors=True)
                    removed += 1
                elif os.path.isfile(path) and name.startswith('nightshift-fonts-') and name.endswith('.zip') and folder == kodi_temp:
                    os.remove(path)
                    removed += 1
            except OSError:
                pass
    if removed:
        log('Removed %d stale font staging item(s) from an earlier interrupted run.' % removed)

def _fonts_dir_path():
    skin = xbmcaddon.Addon(SKIN_ID)
    return os.path.join(skin.getAddonInfo('path'), 'fonts')

def install():
    fonts_dir = _fonts_dir_path()
    os.makedirs(fonts_dir, exist_ok=True)
    _remove_stale_staging()
    marker = os.path.join(fonts_dir, '.nightshift-fontpack.sha256')
    if os.path.isfile(marker):
        try:
            with open(marker, 'r', encoding='ascii') as f:
                installed = f.read().strip()
            if installed == PACK_SHA256 and all(os.path.isfile(os.path.join(fonts_dir, name)) for name in FONT_NAMES):
                return False
        except Exception:
            pass

    # Android/Kodi may not provide the usual /tmp, /var/tmp, or /usr/tmp.
    # Resolve Kodi's writable temp location explicitly instead of relying on
    # Python's global tempfile search path.
    kodi_temp = xbmcvfs.translatePath('special://temp/')
    if not kodi_temp:
        raise RuntimeError('Kodi special://temp/ did not resolve to a filesystem path')
    os.makedirs(kodi_temp, exist_ok=True)

    # Keep the extraction staging directory beside the final fonts so
    # os.replace() stays on the same filesystem (atomic rename where supported).
    temp_dir = tempfile.mkdtemp(prefix='.nightshift-fonts-', dir=fonts_dir)
    archive_path = None
    try:
        fd, archive_path = tempfile.mkstemp(
            prefix='nightshift-fonts-', suffix='.zip', dir=kodi_temp
        )
        os.close(fd)

        _download(archive_path)
        with zipfile.ZipFile(archive_path, 'r') as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError('font ZIP CRC check failed at ' + bad)
            found = {}
            for info in archive.infolist():
                if info.is_dir():
                    continue
                name = info.filename.replace('\\', '/')
                parts = name.split('/')
                if name.startswith('/') or any(part in ('', '.', '..') for part in parts):
                    raise RuntimeError('unsafe path in font archive')
                base = parts[-1]
                if base in FONT_NAMES:
                    if base in found:
                        raise RuntimeError('duplicate font file: ' + base)
                    data = archive.read(info)
                    if not (data.startswith(b'\x00\x01\x00\x00') or data.startswith(b'OTTO')):
                        raise RuntimeError('invalid font header: ' + base)
                    found[base] = data
        if set(found) != set(FONT_NAMES):
            raise RuntimeError('font pack is missing one or more expected font files')
        for name, data in found.items():
            target = os.path.join(temp_dir, name)
            with open(target, 'wb') as f:
                f.write(data)
        for name in FONT_NAMES:
            os.replace(os.path.join(temp_dir, name), os.path.join(fonts_dir, name))
        marker_tmp = marker + '.tmp'
        with open(marker_tmp, 'w', encoding='ascii') as f:
            f.write(PACK_SHA256 + '\n')
        os.replace(marker_tmp, marker)
        log('Installed and verified all four external fonts.')
        return True
    finally:
        if archive_path:
            try:
                os.remove(archive_path)
            except OSError:
                pass
        try:
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass

def main():
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            if install():
                # Font files were just installed; reload the active skin to load them.
                if xbmc.getSkinDir() == SKIN_ID:
                    xbmc.executebuiltin('ReloadSkin')
            # Fonts are present (just installed, or already there): nothing more to do.
            return
        except Exception as exc:
            log('Install attempt failed: ' + str(exc), xbmc.LOGERROR)
        # Retry on later intervals if networking was unavailable at startup.
        if monitor.waitForAbort(900):
            return

if __name__ == '__main__':
    main()
