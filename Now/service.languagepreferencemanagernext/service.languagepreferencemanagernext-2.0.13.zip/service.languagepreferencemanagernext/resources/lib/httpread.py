"""
A read(n) / seek(pos) reader of an http / https file that keeps one connection open (HTTP keep-alive) and asks for
each part with a Range request on it. Kodi's own file reader opens a new connection (with the redirect and the TLS
handshake of a debrid service) for every seek, which on such a source costs most of a second per read; the sub
converter makes hundreds of small reads. Anything this reader cannot do (no Range support, a certificate it cannot
check, an expired link, a dropped connection twice in a row) is handed to the fallback reader (Kodi's), for good, so
the worst case is the speed it had before.
"""
import base64
import http.client
import os
import ssl
import time
import urllib.parse

_MAX_REDIRECTS = 5
_TIMEOUT = 30
_REDIRECTS = (301, 302, 303, 307, 308)
_BUSY = (429, 503)                  # too many connections at once: asked again after a short wait
_BUSY_TRIES = 4
_STREAM_AFTER = 1 << 20              # a read this long that is followed by the next one: the rest comes as one long answer
_STREAM_SPAN = 256 << 20
_STREAM_SKIP = 16 << 20                # a jump forward of less than this is read through on the long answer
_LOST_TRIES = 4                     # a connection reset / dropped: tried again this many times


class _Refused(IOError):
    """The server answered, but not with the part asked for (no Range support, an expired link ...)."""


def split_url(url):
    """(url without the headers, {header: value}) of a Kodi style 'url|Header=value&Header2=value2'."""
    base, _, tail = (url or '').partition('|')
    headers = {}
    for key, value in urllib.parse.parse_qsl(tail, keep_blank_values=True):
        if key:
            headers[key] = value
    return base, headers


def _context():
    cafile = None
    try:
        import xbmcvfs
        candidate = xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem')
        if os.path.isfile(candidate):
            cafile = candidate
    except Exception:
        pass
    try:
        return ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
    except Exception:
        return ssl.create_default_context()


class HttpRangeReader:
    """Reads a file over one persistent connection. fallback() gives a reader (read / seek / close) of the same file
    that is used from the first failure on; log(text) gets what happened that is worth a line."""

    max_read = 64 << 20                # one read is one request: a long read is not cut into 4 MB pieces

    def __init__(self, url, fallback=None, log=None, context=None):
        self.url, self.headers = split_url(url)
        self.fallback_factory = fallback
        self.fallback = None
        self.log = log
        self.context = context
        self.pos = 0
        self.conn = None
        self.target = None                 # (scheme, host, port, path) of the file after the redirects
        self.requests = 0
        self.connections = 0
        self.failure = None
        self.closed = False
        self.connect_time = 0.0            # seconds spent opening connections (TCP + TLS)
        self.wait_time = 0.0               # seconds from sending a request to its answer
        self.closed_by_server = 0          # answers after which the server closed the connection
        self.streaming = False             # set by enable_stream(): sequential reads are served from one long answer
        self.stream = None                 # the open long answer
        self.stream_pos = 0
        self.last_end = -1
        self.last_len = 0
        self.stream_cuts = 0               # long answers that were cut off
        self.streamed = 0                  # bytes that came from long answers
        self.busy = 0                      # answers that said 'too many connections'
        self.errors = 0                    # connections lost with an error
        self.version = None                # 'HTTP/1.1' ... and what the server said about the connection

    # ---- the connection --------------------------------------------------------------------------------------
    @staticmethod
    def _parts(url):
        parsed = urllib.parse.urlsplit(url)
        scheme = parsed.scheme.lower()
        port = parsed.port or (443 if scheme == 'https' else 80)
        path = parsed.path or '/'
        if parsed.query:
            path += '?' + parsed.query
        headers = {}
        if parsed.username is not None:
            token = '{0}:{1}'.format(urllib.parse.unquote(parsed.username), urllib.parse.unquote(parsed.password or ''))
            headers['Authorization'] = 'Basic ' + base64.b64encode(token.encode('utf-8')).decode('ascii')
        return scheme, parsed.hostname, port, path, headers

    def _connect(self):
        self._drop()
        scheme, host, port, _path = self.target[:4]
        if scheme == 'https':
            if self.context is None:
                self.context = _context()
            self.conn = http.client.HTTPSConnection(host, port, timeout=_TIMEOUT, context=self.context)
        else:
            self.conn = http.client.HTTPConnection(host, port, timeout=_TIMEOUT)
        began = time.time()
        self.conn.connect()
        self.connect_time += time.time() - began
        self.connections += 1

    def _drop(self):
        self.stream = None
        if self.conn is not None:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None

    def _request(self, start, length):
        """The `length` bytes at `start`: one Range request on the open connection."""
        scheme, host, port, path = self.target[:4]
        headers = dict(self.headers)
        headers.update(self.target[4])
        headers['Range'] = 'bytes={0}-{1}'.format(start, start + length - 1)
        headers['Connection'] = 'keep-alive'
        headers.setdefault('Accept-Encoding', 'identity')
        began = time.time()
        self.conn.request('GET', path, headers=headers)
        self.requests += 1
        response = self.conn.getresponse()
        self.wait_time += time.time() - began
        if self.version is None:
            self.version = '{0}, Connection: {1}, Keep-Alive: {2}'.format(
                'HTTP/1.1' if response.version == 11 else 'HTTP/1.0', response.getheader('Connection', '-'),
                response.getheader('Keep-Alive', '-'))
        return response

    def _resolve(self, start, length):
        """The first request: follows the redirects and pins the final address."""
        url = self.url
        extra = {}
        for _ in range(_MAX_REDIRECTS + 1):
            scheme, host, port, path, auth = self._parts(url)
            if scheme not in ('http', 'https') or not host:
                raise _Refused('not an http address')
            extra = auth or extra
            self.target = (scheme, host, port, path, extra)
            self._connect()
            response = self._request(start, length)
            if response.status in _REDIRECTS:
                location = response.getheader('Location')
                response.read()
                if not location:
                    raise _Refused('a redirect without an address')
                url = urllib.parse.urljoin(url, location)
                continue
            return response
        raise _Refused('too many redirects')

    def _fetch(self, start, length):
        busy_tries = 0
        lost_tries = 0
        while True:
            try:
                if self.target is None:
                    response = self._resolve(start, length)
                else:
                    if self.conn is None:
                        self._connect()
                    response = self._request(start, length)
                if response.status in _BUSY:
                    response.read()
                    self.busy += 1
                    self._drop()
                    if busy_tries < _BUSY_TRIES:
                        busy_tries += 1
                        self._wait(busy_tries)
                        continue
                if response.status != 206:
                    if response.status == 200 and start == 0:
                        pass                                  # a server without Range support sends the file from 0
                    else:
                        response.read()
                        raise _Refused('the server answered {0}'.format(response.status))
                data = response.read(length) if response.status == 200 else response.read()
                if response.status == 200:
                    self._drop()                              # the rest of the file is on the way: not reusable
                elif response.will_close:
                    self.closed_by_server += 1
                    self._drop()
                return data
            except (ssl.SSLError, _Refused):
                raise
            except (http.client.HTTPException, OSError):
                self.errors += 1
                self._drop()                                  # an idle connection the server closed: once more
                lost_tries += 1
                if lost_tries > _LOST_TRIES:
                    raise
                if lost_tries > 1:                            # a second loss in a row: the host is refusing, wait
                    self._wait(lost_tries - 1)

    def _wait(self, seconds):
        """A short wait that a close from another thread cuts short."""
        for _ in range(int(seconds * 10)):
            if self.closed:
                raise IOError('the reader was closed')
            time.sleep(0.1)

    # ---- the reader interface --------------------------------------------------------------------------------
    def seek(self, pos):
        if self.fallback is not None:
            self.fallback.seek(pos)
        self.pos = pos

    def read(self, n):
        if n <= 0:
            return b''
        if self.closed:
            raise IOError('the reader was closed')
        if self.fallback is None:
            try:
                data = self._streamed(n)
                if data is None:
                    data = self._fetch(self.pos, n)
                    self.last_len = len(data)
                self.pos += len(data)
                self.last_end = self.pos
                return data
            except Exception as e:
                if self.closed:                               # closed from another thread: the scan is over
                    raise IOError('the reader was closed')
                self.failure = str(e) or e.__class__.__name__
                self._drop()
                self._switch()
        return self.fallback.read(n)

    def enable_stream(self):
        """The caller reads the file from start to end (the walk): after a long read, the next read that follows it
        on is served from one long answer, which keeps the speed of the link (every new request starts slowly and
        waits for the host again)."""
        self.streaming = True

    def _streamed(self, n):
        """n bytes from the long answer, opening it when this read follows a long one; None when not streaming."""
        if not self.streaming:
            return None
        if self.stream is not None and self.pos != self.stream_pos:
            gap = self.pos - self.stream_pos
            if 0 < gap <= _STREAM_SKIP:
                left = gap                                    # a short jump forward (the walk skips a block): read over it
                while left > 0:
                    skipped = self.stream.read(min(left, 1 << 20))
                    if not skipped:
                        break
                    left -= len(skipped)
                    self.stream_pos += len(skipped)
                    self.streamed += len(skipped)
            if self.pos != self.stream_pos:
                self._drop()                                  # a jump: the rest of the answer is not wanted
                self.stream = None
        if self.stream is None:
            if not (0 <= self.pos - self.last_end <= _STREAM_SKIP and self.last_len >= _STREAM_AFTER):
                return None
            try:
                if self.conn is None and self.target is not None:
                    self._connect()
                response = self._request(self.pos, _STREAM_SPAN)
            except Exception:
                self._drop()
                return None
            if response.status != 206:
                response.read()
                self._drop()
                return None
            self.stream, self.stream_pos = response, self.pos
        try:
            data = self.stream.read(n)
        except (http.client.HTTPException, OSError):
            # the answer was cut off: nothing of this read was used, so the plain request below gets the same bytes
            # and the next sequential read opens a new long answer (not after three cuts)
            self._drop()
            self.stream_cuts += 1
            if self.stream_cuts >= 3:
                self.streaming = False
            return None
        self.stream_pos += len(data)
        self.streamed += len(data)
        if len(data) < n:                                     # the end of the answer (or of the file)
            self.stream = None
            self._drop()
        return data

    def _switch(self):
        if self.fallback_factory is None or self.closed:
            raise IOError(self.failure)
        if self.log:
            self.log('Sub converter: the keep-alive connection did not work ({0}) - Kodi reads the file instead'.format(
                self.failure))
        self.fallback = self.fallback_factory()
        self.fallback.seek(self.pos)

    def close(self):
        self.closed = True
        self._drop()
        if self.fallback is not None:
            try:
                self.fallback.close()
            except Exception:
                pass
            self.fallback = None

    def summary(self):
        text = '{0} requests on {1} connection{2}'.format(self.requests, self.connections,
                                                           '' if self.connections == 1 else 's')
        if self.requests:
            text += ' (opening a connection {0:.0f} ms, the answer {1:.0f} ms; closed by the server after an answer: ' \
                    '{2}, lost: {3}, refused as busy: {5}; the server says {4})'.format(
                        1000 * self.connect_time / max(1, self.connections), 1000 * self.wait_time / self.requests,
                        self.closed_by_server, self.errors, self.version, self.busy)
        return text
