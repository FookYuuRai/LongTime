"""
Sub converter: written to the add-on's own folder and removed again every time the service starts (that is, at every start of Kodi): clean_folder().
"""
import hashlib
import os
import time
import re
import shutil

import httpread
import subcodec

FOLDER_NAME = 'converted_subs'
_TOP = 8                                 # numpad alignment (\an8): top centre
DEFAULT_COLOR = '#FFFF00'                # yellow
_YELLOW = DEFAULT_COLOR

# the colours of the settings spinner (SubConverterColor 0..7; 8 = the hex value the user types)
COLOR_PRESETS = ('#FFFF00', '#FFFFFF', '#00FFFF', '#00FF00', '#FFA500', '#FF69B4', '#FF4040', '#87CEFA')
_HEX = re.compile(r'^#?([0-9a-f]{3}|[0-9a-f]{6})$', re.I)

_DRAWING = re.compile(r'\{[^}]*\\p[1-9]')
_OVERRIDES = re.compile(r'\{[^}]*\}')
_MARKUP = re.compile(r'<[^>]*>')
_AN = re.compile(r'\\an([1-9])')
_A_LEGACY = re.compile(r'\\a(\d{1,2})(?!\d)')
_POS = re.compile(r'\\(?:pos|move)\(\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)')

# The converted_subs directory is a per-Kodi-session working cache, never a persistent subtitle preference.
SESSION_STARTED_AT = time.time()
_SESSION_CREATED = set()

def begin_session():
    """Start a fresh per-Kodi-session cache. Existing files are stale unless this process created them."""
    global SESSION_STARTED_AT
    SESSION_STARTED_AT = time.time()
    _SESSION_CREATED.clear()
    return SESSION_STARTED_AT

def _cache_key(path):
    return os.path.normcase(os.path.abspath(path))

def cache_file_info(path):
    """Details for a generated file, including whether this process created it this Kodi session."""
    try:
        stat = os.stat(path)
    except OSError:
        return None
    return {
        'path': os.path.abspath(path),
        'size': stat.st_size,
        'mtime': stat.st_mtime,
        'mtime_text': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_mtime)),
        'created_this_session': _cache_key(path) in _SESSION_CREATED,
    }

def remove_stale_cache_file(path, log=None):
    """Remove a cache file not produced by this running Kodi session."""
    info = cache_file_info(path)
    if not info or info['created_this_session']:
        return True
    try:
        os.remove(path)
        if log:
            log('Sub converter: stale previous-session cache removed: {0} ({1} bytes, modified {2})'.format(
                info['path'], info['size'], info['mtime_text']))
        return True
    except OSError as e:
        if log:
            log('Sub converter: ERROR cannot remove stale previous-session cache {0}: {1}'.format(info['path'], e))
        return False

def _directory_snapshot(folder):
    """Short, useful inventory for startup diagnostics; does not follow directory symlinks."""
    entries = []
    try:
        with os.scandir(folder) as it:
            for entry in it:
                try:
                    stat = entry.stat(follow_symlinks=False)
                    kind = 'dir' if entry.is_dir(follow_symlinks=False) else 'file'
                    entries.append('{0} ({1}, {2} bytes, modified {3})'.format(
                        entry.name, kind, stat.st_size, time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_mtime))))
                except OSError as e:
                    entries.append('{0} (stat failed: {1})'.format(entry.name, e))
    except OSError as e:
        return ['<list failed: {0}>'.format(e)]
    return sorted(entries)


def normalize_color(text):
    """'#RRGGBB' (upper case) for a colour typed as RRGGBB, #RRGGBB, RGB or #RGB; None when it is not one."""
    match = _HEX.match(str(text or '').strip())
    if not match:
        return None
    digits = match.group(1).upper()
    if len(digits) == 3:
        digits = ''.join(c * 2 for c in digits)
    return '#' + digits


def resolve_color(choice, typed=''):
    """The color of the settings: choice = the spinner value (0..len(COLOR_PRESETS)-1 a preset, the next one the
    typed value). Returns (color, ok): ok is False when the typed value is not a color (yellow is returned then)."""
    try:
        choice = int(choice or 0)
    except (TypeError, ValueError):
        choice = 0
    if 0 <= choice < len(COLOR_PRESETS):
        return COLOR_PRESETS[choice], True
    color = normalize_color(typed)
    return (color, True) if color else (DEFAULT_COLOR, False)


# Debrid services, by the name that appears in the host of their download links; the host itself is never logged.
DEBRID_NAMES = ('real-debrid', 'realdebrid', 'alldebrid', 'premiumize', 'torbox', 'debrid-link', 'debridlink',
                'offcloud', 'put.io', 'easydebrid', 'megadebrid', 'linksnappy', 'deepbrid', 'simplydebrid')
_USENET_SEGMENTS = ('usenet', 'nzb', 'nntp')
_LOCAL_HOSTS = ('127.0.0.1', 'localhost', '::1', '[::1]')


def source_kind(path):
    """(kind, label) of where a video comes from, told by its path alone: 'usenet' (an nntp VFS, or a link whose path
    starts with usenet/ or nzb/), 'debrid' (label: the service's name, when it is one of DEBRID_NAMES), 'remote' (any
    other http / https host), 'proxy' (a local http server of another add-on), 'network' (smb, nfs, ftp ...) or 'local'.
    Nothing from the path but the service name and the scheme ends up in the label: no host, hash, file name or token."""
    text = (path or '').strip()
    if '://' not in text:
        return 'local', 'local file'
    scheme, rest = text.split('://', 1)
    scheme = scheme.lower()
    if scheme in ('nntp', 'nntps', 'nntpstream', 'nzb'):
        return 'usenet', scheme + ' stream'
    if scheme in ('http', 'https'):
        parts = rest.split('/')
        host = parts[0].rsplit('@', 1)[-1].lower()
        if host.startswith('['):
            host = host.split(']')[0] + ']'
        else:
            host = host.split(':')[0]
        segment = parts[1].lower() if len(parts) > 1 else ''
        if segment in _USENET_SEGMENTS:
            return 'usenet', 'usenet link' + (' (local proxy)' if host in _LOCAL_HOSTS else '')
        if host in _LOCAL_HOSTS:
            return 'proxy', 'local proxy'
        for name in DEBRID_NAMES:
            if name in host:
                return 'debrid', name
        return 'remote', scheme + ' host'
    if scheme in ('smb', 'nfs', 'ftp', 'ftps', 'sftp', 'dav', 'davs', 'webdav', 'webdavs', 'upnp'):
        return 'network', scheme
    return 'local', 'local file'


def plain_location(path):
    """A video location without what must not be logged or used in a file name: the headers after '|' (cookies,
    tokens), the query string and user:password@."""
    path = (path or '').split('|', 1)[0].split('?', 1)[0]
    return re.sub(r'^([a-z][a-z0-9+.-]*://)[^/@]*@', r'\1', path, flags=re.I)


def converted_folder(user_data_path):
    return os.path.join(user_data_path, FOLDER_NAME)


def clean_folder(user_data_path, log=None):
    """Delete every prior-session converted subtitle, including nested leftovers; return files removed.

    Always log the resolved path and before/after inventory. This makes a false cache hit after a Kodi restart
    traceable to the exact profile directory instead of silently treating any existing file as reusable.
    """
    folder = converted_folder(user_data_path)
    before = _directory_snapshot(folder) if os.path.isdir(folder) else []
    if not os.path.isdir(folder):
        if log:
            log('Sub converter: startup cache audit: data_dir={0!r}; cache_dir={1!r}; cache directory absent; '
                'nothing to delete'.format(os.path.abspath(user_data_path), os.path.abspath(folder)))
        _SESSION_CREATED.clear()
        return 0

    removed = 0
    failures = []
    try:
        names = os.listdir(folder)
    except OSError as e:
        names = []
        failures.append('{0}: {1}'.format(folder, e))

    for name in names:
        path = os.path.join(folder, name)
        try:
            if os.path.islink(path) or os.path.isfile(path):
                os.remove(path)
                removed += 1
            elif os.path.isdir(path):
                # Count files removed from nested folders as well; cache layout is normally flat.
                for _base, dirs, files in os.walk(path):
                    removed += len(files)
                shutil.rmtree(path)
            else:
                os.remove(path)
                removed += 1
        except OSError as e:
            failures.append('{0}: {1}'.format(path, e))

    after = _directory_snapshot(folder)
    if log:
        log('Sub converter: startup cache audit: data_dir={0!r}; cache_dir={1!r}; entries_before={2}; removed={3}; '
            'entries_after={4}; failures={5}'.format(
                os.path.abspath(user_data_path), os.path.abspath(folder),
                before if before else '[]', removed, after if after else '[]', failures if failures else '[]'))
    _SESSION_CREATED.clear()
    return removed


def _legacy_alignment(a):
    """SSA (v4) alignment code -> numpad alignment: 1-3 bottom, 5-7 top (+4), 9-11 middle (+8)."""
    if a in (1, 2, 3):
        return a
    if 5 <= a <= 7:
        return a + 2
    if 9 <= a <= 11:
        return a - 5
    return 2


def parse_header(header):
    """(PlayResX, PlayResY, {style name: numpad alignment}) of an ASS script header."""
    res_x = res_y = None
    styles = {}
    columns = None
    plus = True
    for line in (header or '').splitlines():
        line = line.strip()
        low = line.lower()
        if low.startswith('playresx:'):
            res_x = _number(line.split(':', 1)[1])
        elif low.startswith('playresy:'):
            res_y = _number(line.split(':', 1)[1])
        elif low.startswith('[v4 styles]'):
            plus = False
        elif low.startswith('[v4+ styles]'):
            plus = True
        elif low.startswith('format:') and columns is None:
            columns = [c.strip().lower() for c in line.split(':', 1)[1].split(',')]
        elif low.startswith('style:') and columns and 'alignment' in columns:
            values = [v.strip() for v in line.split(':', 1)[1].split(',')]
            if len(values) >= len(columns):
                try:
                    a = int(values[columns.index('alignment')])
                except ValueError:
                    continue
                styles[values[columns.index('name')]] = a if plus else _legacy_alignment(a)
    return res_x, res_y, styles


def _number(text):
    try:
        return float(text.strip())
    except ValueError:
        return None


def video_view(screen_w, screen_h, aspect):
    """(left, top, width, height) of the picture on the screen: it fills the screen as far as its aspect ratio
    allows (Kodi's normal zoom), centred. ASS coordinates are relative to this picture, the coordinates of a
    {\\pos} in an SRT shown by Kodi are screen pixels."""
    if not (screen_w and screen_h):
        return None
    if not aspect or aspect <= 0:
        return 0.0, 0.0, float(screen_w), float(screen_h)
    if aspect >= float(screen_w) / screen_h:
        width, height = float(screen_w), screen_w / aspect
    else:
        width, height = screen_h * aspect, float(screen_h)
    return (screen_w - width) / 2, (screen_h - height) / 2, width, height


def event_placement(raw, header_info, view=None):
    """(override tag text, positioned) for one Matroska ASS block. A line is positioned when it says where it
    goes: an alignment tag (\\an, \\a), a \\pos / \\move (its start point), or a style that is not bottom centre.
    It then keeps that place: '\\an7\\pos(x,y)' with x, y moved from the script's resolution into the picture on
    the screen (view; its alignment, as ASS does, is the anchor of the point), or just its alignment. Anything
    else is where ASS puts text by default, at the bottom, and is not positioned: it goes to the top."""
    res_x, res_y, styles = header_info
    fields = raw.split(',', 8)
    text = fields[8] if len(fields) == 9 else raw
    tags = ' '.join(_OVERRIDES.findall(text))
    style = styles.get(fields[2], 2) if len(fields) == 9 else 2
    an = None
    m = _AN.search(tags)
    if m:
        an = int(m.group(1))
    else:
        m = _A_LEGACY.search(tags)
        if m:
            an = _legacy_alignment(int(m.group(1)))
    m = _POS.search(tags)
    if m:
        left, top, width, height = view or (0.0, 0.0, 1920.0, 1080.0)
        x = left + float(m.group(1)) * width / (res_x or 384.0)
        y = top + float(m.group(2)) * height / (res_y or 288.0)
        return '\\an{0}\\pos({1},{2})'.format(an or style, int(round(x)), int(round(y))), True
    if an:
        return '\\an{0}'.format(an), True
    if style != 2:
        return '\\an{0}'.format(style), True
    return '\\an{0}'.format(_TOP), False


def ass_text(raw):
    """The plain text lines of one Matroska ASS block ("ReadOrder,Layer,Style,Name,MarginL,MarginR,MarginV,
    Effect,Text"): override tags and drawings gone, \\N / \\n line breaks, \\h a space. [] when nothing is left."""
    fields = raw.split(',', 8)
    text = fields[8] if len(fields) == 9 else raw
    if _DRAWING.search(text):
        return []                                   # vector drawing (a sign), no text
    text = _OVERRIDES.sub('', text)
    text = _MARKUP.sub('', text)
    text = text.replace('\\N', '\n').replace('\\n', '\n').replace('\\h', ' ')
    return [line.strip() for line in text.split('\n') if line.strip()]


_VTT_TAG = re.compile(r'<[^>]*>')


def vtt_cue(raw, codec=''):
    """(lines, placement tag text, positioned) of one Matroska WebVTT block: "settings\\nidentifier\\npayload". A cue
    with a line: setting says where it goes (top half: \\an8, else \\an2, kept); one without goes to the top."""
    parts = raw.replace('\r', '').split('\n', 2)
    if codec.upper().startswith('D_WEBVTT'):         # the block is only the payload (settings are in a side element)
        settings, payload = '', raw
    else:
        settings, payload = (parts[0], parts[2]) if len(parts) == 3 else ('', raw)
    text = _VTT_TAG.sub('', payload).replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
    text = text.replace('&nbsp;', ' ')
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    m = re.search(r'\bline:(-?[\d.]+)(%?)', settings)
    if m:
        value = float(m.group(1))
        if m.group(2) != '%' and value < 0:
            return lines, '\\an2', True                    # counted from the bottom
        return lines, '\\an{0}'.format(_TOP if value < 50 and m.group(2) == '%' or value == 0 else 2), True
    return lines, '\\an{0}'.format(_TOP), False


_BRACES = re.compile(r'\{[^}]*\}')
_FONT_TAG = re.compile(r'</?font\b[^>]*>', re.I)
_STYLE_TAG = re.compile(r'<(/?)([ibu])\s*>', re.I)
_ANY_TAG = re.compile(r'<[^>]*>')


def srt_cue(raw):
    """(lines, placement tag text, positioned) of one Matroska SRT block (S_TEXT/UTF8: the plain text of the cue,
    with <i> <b> <u> and sometimes {\\an8} / {\\pos(x,y)}). Italic / bold / underline are kept (closed and opened again
    on each line, so every line stands alone); a cue with an alignment or position tag keeps it, the rest goes to
    the top."""
    text = raw.replace('\r', '')
    tags = ' '.join(_BRACES.findall(text))
    text = _BRACES.sub('', text)
    text = _FONT_TAG.sub('', text)
    open_tags = []
    lines = []
    for line in text.split('\n'):
        prefix = ''.join('<{0}>'.format(t) for t in open_tags)
        for m in _STYLE_TAG.finditer(line):
            name = m.group(2).lower()
            if m.group(1):
                if name in open_tags:
                    open_tags.remove(name)
            elif name not in open_tags:
                open_tags.append(name)
        suffix = ''.join('</{0}>'.format(t) for t in reversed(open_tags))
        line = _ANY_TAG.sub(lambda m: m.group(0) if _STYLE_TAG.fullmatch(m.group(0)) else '', line)
        if line.strip() and _STYLE_TAG.sub('', line).strip():
            lines.append(prefix + line.strip() + suffix)
    an = _AN.search(tags)
    pos = _POS_FIRST.search(tags)
    if an and pos:
        return lines, '\\an{0}\\pos({1},{2})'.format(an.group(1), pos.group(1), pos.group(2)), True
    if an:
        value = int(an.group(1))
        if value in _TOP_OF:                              # a bottom line without a position goes to the top, as in ASS
            return lines, '\\an{0}'.format(_TOP_OF[value]), False
        return lines, '\\an{0}'.format(value), True
    if pos:
        return lines, '\\an7\\pos({0},{1})'.format(pos.group(1), pos.group(2)), True
    return lines, '\\an{0}'.format(_TOP), False


_TOP_OF = {1: 7, 2: 8, 3: 9}                         # bottom alignment -> the same column at the top
_AN_FIRST = re.compile(r'\\an([1-9])')
_A_FIRST = re.compile(r'\\a(\d{1,2})(?!\d)')
_POS_FIRST = re.compile(r'\\pos\(\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*\)')
_HAS_MOVE = re.compile(r'\\move\(')
_BOTTOM_FROM = 0.6                                   # a positioned line anchored below this share of the height


def _num(v):
    return ('%g' % v)


def ass_to_top(raw, header_info):
    """The Text field of one Matroska ASS block with a line that sits at the bottom moved to the top. Everything
    else (style, fonts, colours, karaoke, effects, drawings, lines placed elsewhere) is left exactly as it is.
    A bottom line is one whose alignment (\\an / \\a tag, else its style's) is 1-3 and that either has no
    \\pos or has one anchored in the lower part of the picture; a \\pos line is mirrored vertically."""
    res_x, res_y, styles = header_info
    fields = raw.split(',', 8)
    if len(fields) != 9:
        return None
    text = fields[8]
    if _DRAWING.search(text) or _HAS_MOVE.search(text):
        return text                                   # drawings and moving text keep their motion
    style = styles.get(fields[2], 2)
    an = None
    m = _AN_FIRST.search(text)
    if m:
        an = int(m.group(1))
    else:
        m = _A_FIRST.search(text)
        if m:
            an = _legacy_alignment(int(m.group(1)))
    eff = an or style
    if eff not in _TOP_OF:
        return text                                   # already middle or top
    pos = _POS_FIRST.search(text)
    if pos:
        height = res_y or 288.0
        y = float(pos.group(2))
        if y < _BOTTOM_FROM * height:
            return text                               # an anchor in the upper part: a sign, not a bottom line
        text = text[:pos.start()] + '\\pos(%s,%s)' % (pos.group(1), _num(height - y)) + text[pos.end():]
    top = _TOP_OF[eff]
    if _AN_FIRST.search(text):
        return _AN_FIRST.sub(lambda mm: '\\an%d' % top, text, count=1)
    if _A_FIRST.search(text):
        return _A_FIRST.sub(lambda mm: '\\an%d' % top, text, count=1)
    if text.startswith('{'):
        return '{\\an%d' % top + text[1:]           # into the first override block
    return '{\\an%d}' % top + text


_FS = re.compile(r'\\fs(\d+(?:\.\d+)?)')
_LINE_HEIGHT = 1.2                                   # a text line takes about this many font sizes of height


def style_metrics(header):
    """{style name: (font size, MarginV)} of an ASS script header (script units)."""
    out = {}
    columns = None
    for line in (header or '').splitlines():
        line = line.strip()
        low = line.lower()
        if low.startswith('format:') and columns is None and 'fontsize' in low:
            columns = [c.strip().lower() for c in line.split(':', 1)[1].split(',')]
        elif low.startswith('style:') and columns and 'fontsize' in columns:
            values = [v.strip() for v in line.split(':', 1)[1].split(',')]
            if len(values) >= len(columns):
                size = _number(values[columns.index('fontsize')]) or 20.0
                margin = _number(values[columns.index('marginv')]) if 'marginv' in columns else 0.0
                out[values[columns.index('name')]] = (size, margin or 0.0)
    return out


def _block_geometry(raw, info, metrics):
    """What one ASS block takes on the screen, in script units: (alignment, top of the text, lines, line height,
    layer, has \\pos) - None for a block that is not text or moves."""
    res_x, res_y, styles = info
    f = raw.split(',', 8)
    if len(f) != 9 or _HAS_MOVE.search(f[8]):
        return None
    lines = ass_text(raw)
    if not lines:
        return None
    tags = ' '.join(_OVERRIDES.findall(f[8]))
    size, style_margin = metrics.get(f[2], (20.0, 0.0))
    m = _FS.search(tags)
    if m:
        size = float(m.group(1))
    an = None
    m = _AN_FIRST.search(tags)
    if m:
        an = int(m.group(1))
    else:
        m = _A_FIRST.search(tags)
        if m:
            an = _legacy_alignment(int(m.group(1)))
    eff = an or styles.get(f[2], 2)
    pos = _POS_FIRST.search(tags)
    try:
        layer = int(f[1])
    except ValueError:
        layer = 0
    if pos:
        top = float(pos.group(2))
    else:
        try:
            margin = float(f[6])
        except ValueError:
            margin = 0.0
        top = margin if margin > 0 else style_margin
    return eff, top, len(lines), size * _LINE_HEIGHT, layer, bool(pos)


def plan_top_stacking(ordered, header, mode='ass', view=None):
    """{index in ordered: top of the text, in script units} for the lines moved to the top that share the screen time
    with a text line that is on the top already (an \\an7-9 line, a style at the top, a \\pos in the upper part): they
    are put below it, so the two do not print over each other. A moved line with nothing on top in its time is not in
    the plan and goes where it went before, as does every line that is placed elsewhere (signs, \\pos, middle).
    ordered: [(start ms, end ms, raw ASS block)] sorted. mode 'ass': the lines moved are those ass_to_top moves; mode
    'srt': those event_placement does not position."""
    info = parse_header(header)
    metrics = style_metrics(header)
    height = info[1] or 288.0
    on_top, moved = [], []
    for index, (start, end, raw) in enumerate(ordered):
        geometry = _block_geometry(raw, info, metrics)
        if geometry is None:
            continue
        eff, top, count, line_h, layer, has_pos = geometry
        f = raw.split(',', 8)
        if mode == 'ass':
            relocated = ass_to_top(raw, info) != f[8] and eff in _TOP_OF
        else:
            relocated = not event_placement(raw, info, view)[1]
        if relocated:
            moved.append((index, start, end, top, count, line_h, has_pos))
        elif eff in (7, 8, 9) and not (has_pos and top >= _BOTTOM_FROM * height):
            on_top.append((start, end, top + count * line_h))
    plan = {}
    for index, start, end, top, count, line_h, has_pos in moved:
        if has_pos:
            top = height - top                      # a bottom \pos line is mirrored to the top (ass_to_top)
        below = max([bottom for s, e, bottom in on_top if s < end and e > start] or [0.0])
        if below > top:
            plan[index] = below
    return plan


def _ass_stamp(ms):
    cs = int(round(max(0, ms) / 10.0))
    return '%d:%02d:%02d.%02d' % (cs // 360000, cs // 6000 % 60, cs // 100 % 60, cs % 100)


_DEFAULT_EVENTS = ('[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n')


def events_to_ass(events, header=''):
    """(text of an .ass file, number of lines) from [(start ms, end ms, raw ASS block text)] and the track's script
    header (CodecPrivate: script info, styles and the [Events] format line). The header, so the styles and the
    fonts they name, is kept as it is; lines at the bottom go to the top (ass_to_top)."""
    info = parse_header(header)
    head = (header or '').replace('\r\n', '\n').replace('\r', '\n').rstrip('\n') + '\n'
    if not re.search(r'^\[Events\]', head, re.M | re.I):
        head += '\n' + _DEFAULT_EVENTS
    elif not re.search(r'^Format:[^\n]*\bText\b', head.split('[Events]')[-1] if '[Events]' in head else '', re.M):
        head = head.rstrip('\n') + '\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'
    lines = []
    seen = set()
    ordered = sorted(events, key=lambda e: (e[0], e[1]))
    stack = plan_top_stacking(ordered, header, 'ass')
    for index, (start, end, raw) in enumerate(ordered):
        f = raw.split(',', 8)
        if len(f) != 9:
            continue
        text = ass_to_top(raw, info)
        key = (start, end, f[1], f[2], text)
        if text is None or key in seen:
            continue
        seen.add(key)
        margin_v = f[6]
        if index in stack:                               # a line that was moved to the top, under the text that is there already
            pos = _POS_FIRST.search(text)
            if pos:
                text = text[:pos.start()] + '\\pos(%s,%s)' % (pos.group(1), _num(round(stack[index], 1))) + text[pos.end():]
            else:
                margin_v = str(int(round(stack[index])))
        lines.append('Dialogue: %s,%s,%s,%s,%s,%s,%s,%s,%s,%s' % (
            f[1], _ass_stamp(start), _ass_stamp(end), f[2], f[3], f[4], f[5], margin_v, f[7], text))
    return head + '\n'.join(lines) + '\n', len(lines)


def _stamp(ms):
    ms = max(0, int(ms))
    return '{0:02d}:{1:02d}:{2:02d},{3:03d}'.format(ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def events_to_srt(events, header='', view=None, codec='', color=None):
    """SRT text of [(start ms, end ms, raw ASS block text)], in time order; every line has the colour (default
    yellow). A line the ASS
    file does not position is put at the top of the picture ({\\an8}); a positioned one keeps its place (its
    alignment). Identical lines shown at the same time are written once. header: the track's ASS script header."""
    info = parse_header(header)
    color = normalize_color(color) or DEFAULT_COLOR
    cues = []
    seen = set()
    ordered = sorted(events, key=lambda e: (e[0], e[1]))
    from_ass = not (subcodec.is_webvtt(codec) or subcodec.format_of_codec(codec) == 'srt')
    stack = plan_top_stacking(ordered, header, 'srt', view) if from_ass else {}
    for index, (start, end, raw) in enumerate(ordered):
        if subcodec.is_webvtt(codec):
            lines, placement, _positioned = vtt_cue(raw, codec)
        elif subcodec.format_of_codec(codec) == 'srt':
            lines, placement, _positioned = srt_cue(raw)
        else:
            lines = ass_text(raw)
            placement = None
        key = (start, end, tuple(lines))
        if not lines or key in seen:
            continue
        seen.add(key)
        if placement is None:
            placement, _positioned = event_placement(raw, info, view)
            if index in stack:                           # moved to the top, but text is on the top already: under it
                left, top, width, height = view or (0.0, 0.0, 1920.0, 1080.0)
                y = top + stack[index] * height / (info[1] or 288.0)
                an = int(_AN_FIRST.search(placement).group(1)) if _AN_FIRST.search(placement) else _TOP
                x = left + width * {7: 0.05, 8: 0.5, 9: 0.95}.get(an, 0.5)
                placement = '\\an{0}\\pos({1},{2})'.format(an, int(round(x)), int(round(y)))
        cues.append((start, end, lines, placement))
    out = []
    for i, (start, end, lines, alignment) in enumerate(cues, 1):
        body = '\n'.join('<font color="{0}">{1}</font>'.format(color, line) for line in lines)
        out.append('{0}\n{1} --> {2}\n{{{3}}}{4}\n'.format(i, _stamp(start), _stamp(end), alignment, body))
    return '\n'.join(out), len(cues)


def target_path(user_data_path, video_path, ordinal, language, view=None, ext='srt', color=None):
    """Where the converted copy of subtitle track number ordinal of video_path goes: the video's name, a short
    hash of its full path (two videos with the same name) and the track, then the language code, which is how
    Kodi reads the language of an external subtitle."""
    base = os.path.splitext(os.path.basename(plain_location(video_path).rstrip('/\\')))[0] or 'video'
    base = re.sub(r'[^\w .()\[\]-]', '_', base)[:80]
    # a new screen size or another colour, a new copy (the default colour keeps the name it always had)
    extra = '' if ext != 'srt' or not color or color == DEFAULT_COLOR else color
    tag = hashlib.md5((video_path + repr(view) + extra).encode('utf-8')).hexdigest()[:6]
    lang = re.sub(r'[^A-Za-z-]', '', language or '') or 'und'
    return os.path.join(converted_folder(user_data_path), '{0} [{1}-{2}].{3}.{4}'.format(base, tag, ordinal, lang, ext))


def scan(video_path, should_stop=None, log=None, use_cues=True, wanted=None, threads=4):
    """Reads the events of the text subtitle tracks of a Matroska file ({ordinal: {'events', 'header', 'codec'}}, see
    subcodec.matroska_subtitle_scan), None when nothing could be read. wanted: the ordinals (0 = first subtitle track)
    needed now. When the file has an index of its subtitle blocks only those tracks are read, a few hundred small
    reads, by `threads` workers at the same time (1 = one at a time); else the file is walked once and every text
    track is read in that pass, so switching to another subtitle of the video needs no second read. log() gets the
    progress: of the blocks of the index (every 25 %), or the part of the file walked, the speed and the time left
    (every 10 %). Always the whole track: the playback position does not matter."""
    try:
        import xbmcvfs
        handle = xbmcvfs.File(video_path)
    except Exception as e:
        if log:
            log('Sub converter: cannot open {0}: {1}'.format(plain_location(video_path), e))
        return None
    started = time.time()
    state = {'next': 10, 'blocks': 25}
    try:
        try:
            size = int(handle.size())
        except Exception:
            size = 0

        def progress(position):
            if not log or size <= 0:
                return
            now = time.time()
            state.setdefault('walk', (now, position))        # the walk starts here, whatever came before
            percent = int(100.0 * position / size)
            if percent < state['next']:
                return
            state['next'] = percent // 10 * 10 + 10
            began, first = state['walk']
            elapsed = now - began
            if elapsed <= 0 or position <= first:
                return
            speed = (position - first) / elapsed
            left = (size - position) / speed if speed > 0 else 0
            log('Sub converter: reading the file {0}% ({1:.0f} of {2:.0f} MB, {3:.1f} MB/s, about {4} left)'.format(
                percent, position / 1048576.0, size / 1048576.0, speed / 1048576.0,
                '{0:.0f} min'.format(left / 60) if left >= 90 else '{0:.0f} s'.format(left)))

        def on_blocks(done, total):
            if not log or total < 40:
                return
            percent = int(100.0 * done / total)
            if percent < state['blocks'] or done >= total:
                return
            state['blocks'] = percent // 25 * 25 + 25
            log('Sub converter: reading the subtitle blocks of the index {0}% ({1} of {2}, {3:.0f} s so far)'.format(
                percent, done, total, time.time() - started))

        def kodi_reader():
            return subcodec._Reader(xbmcvfs.File(video_path))

        # a debrid service or another web host: one connection per worker is kept open and asked for each part with a
        # Range request (Kodi's reader opens a new connection, with the redirect and the TLS handshake, for every seek)
        keep_alive = source_kind(video_path)[0] in ('debrid', 'remote')
        readers = []
        if keep_alive:
            # the handle was only needed for the size: while it stays open it holds one of the few connections a
            # debrid service allows
            try:
                handle.close()
            except Exception:
                pass
            handle = None

        def opener():
            if not keep_alive:
                return kodi_reader()
            reader = httpread.HttpRangeReader(video_path, kodi_reader, log)
            readers.append(reader)
            return reader

        try:
            return subcodec.matroska_subtitle_scan(opener() if keep_alive else subcodec._Reader(handle), wanted,
                                                   should_stop, progress, use_cues, log, on_blocks, opener, threads,
                                                   walk_all=True, file_size=size or None)
        finally:
            if log and readers:
                used = [r for r in readers if r.fallback is None and r.requests]
                if used:
                    log('Sub converter: kept-alive connections: {0}'.format(
                        ', '.join(r.summary() for r in used)))
            for r in readers:
                r.close()
    finally:
        try:
            handle.close()
        except Exception:
            pass


def convert(video_path, ordinal, destination, should_stop=None, log=None, view=None, color=None, scanned=None, use_cues=True,
            threads=4):
    """Write the SRT / ASS copy of embedded subtitle track number ordinal of the Matroska file video_path to
    destination. Only a file registered as created in this running Kodi session is reusable. scanned: the result of scan() for this file, when the file was
    read before (then it is not read again). Returns cues, -1 for a same-session cache hit, or 0 when nothing was written."""
    if os.path.isfile(destination) and os.path.getsize(destination) > 0:
        if _cache_key(destination) in _SESSION_CREATED:
            return -1                                # created by this running Kodi session
        # A file that predates this process is not a valid session cache. Never silently reuse it after restart.
        try:
            os.remove(destination)
            if log:
                log('Sub converter: stale cache from an earlier Kodi session removed before conversion: {0}'.format(
                    os.path.abspath(destination)))
        except OSError as e:
            if log:
                log('Sub converter: ERROR cannot remove stale cache {0}: {1}'.format(
                    os.path.abspath(destination), e))
            return 0
    if scanned is None:
        scanned = scan(video_path, should_stop, log, use_cues, {ordinal}, threads)
    track = (scanned or {}).get(ordinal)
    if not track or not track['events']:
        return 0
    events, info = track['events'], track
    if subcodec.is_ass(info.get('codec', '')) and destination.lower().endswith('.ass'):
        srt, cues = events_to_ass(events, info.get('header', ''))
    else:
        srt, cues = events_to_srt(events, info.get('header', ''), view, info.get('codec', ''), color)
    if not cues:
        return 0
    os.makedirs(os.path.dirname(destination), exist_ok=True)
    temp = destination + '.part'
    with open(temp, 'w', encoding='utf-8', newline='\n') as f:
        f.write(srt)
    os.replace(temp, destination)
    _SESSION_CREATED.add(_cache_key(destination))
    return cues
