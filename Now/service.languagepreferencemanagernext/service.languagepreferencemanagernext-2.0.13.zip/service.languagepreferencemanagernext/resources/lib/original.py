"""
The original Language Preference Manager (service.languagepreferencemanager) next to this add-on: is it enabled, and
turn it off. Both add-ons would change the subtitles of the same video. No import of Kodi modules: rpc(method, params)
is Kodi's JSON-RPC, given by the caller, so the functions can be tested outside Kodi.
"""
import os

ORIGINAL_ID = 'service.languagepreferencemanager'
ASKED = 'original_addon_asked'                      # in the data folder: the question has been asked once


def is_enabled(rpc):
    """True / False when Kodi says so, None when it cannot be told (not known to Kodi, no answer)."""
    try:
        answer = rpc('Addons.GetAddonDetails', {'addonid': ORIGINAL_ID, 'properties': ['enabled']})
        return bool(answer['result']['addon']['enabled'])
    except Exception:
        return None


def disable(rpc):
    """Turns the original off (it stays installed and can be enabled again in Add-ons). True when Kodi did it."""
    try:
        answer = rpc('Addons.SetAddonEnabled', {'addonid': ORIGINAL_ID, 'enabled': False})
        return answer.get('result') == 'OK'
    except Exception:
        return False


def was_asked(data_dir):
    return os.path.exists(os.path.join(data_dir, ASKED))


def mark_asked(data_dir):
    try:
        os.makedirs(data_dir, exist_ok=True)
        with open(os.path.join(data_dir, ASKED), 'w') as f:
            f.write('1')
    except OSError:
        pass
