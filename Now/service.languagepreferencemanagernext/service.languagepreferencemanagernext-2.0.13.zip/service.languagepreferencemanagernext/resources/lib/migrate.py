"""
Takes the settings of the original add-on (service.languagepreferencemanager) over to this one, once, so that a user who
installs the NeXt add-on keeps the settings: the values that are not the default, and the other files of the data
folder (the stored preferences). The original's folder is only read. No import of Kodi modules: the functions get
what they need, so they can be tested outside Kodi.
"""
import os
import shutil
import xml.etree.ElementTree as ET

MARKER = 'settings_taken_over'
_NOT_COPIED = ('settings.xml', 'converted_subs', MARKER)


def read_settings(path):
    """{setting id: value} of the settings of a settings.xml that the user changed (both file formats)."""
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return {}
    values = {}
    for node in root.iter('setting'):
        setting_id = node.get('id')
        if not setting_id or node.get('default') == 'true':
            continue
        values[setting_id] = node.get('value') if node.get('value') is not None else (node.text or '')
    return values


def take_over(old_dir, new_dir, known_ids, set_setting, log=None):
    """Once: the changed settings of old_dir that this add-on still has (known_ids), through set_setting(id, value),
    and the other files of old_dir that new_dir does not have. Nothing when this add-on has settings of its own
    already or when the original has no data folder. Returns (settings taken over, files copied, settings it has no
    more)."""
    marker = os.path.join(new_dir, MARKER)
    if os.path.exists(marker) or not os.path.isdir(old_dir):
        return 0, 0, []
    os.makedirs(new_dir, exist_ok=True)
    taken, copied, gone = 0, 0, []
    if not os.path.exists(os.path.join(new_dir, 'settings.xml')):
        for setting_id, value in read_settings(os.path.join(old_dir, 'settings.xml')).items():
            if setting_id in known_ids:
                set_setting(setting_id, value)
                taken += 1
            else:
                gone.append(setting_id)
        for name in os.listdir(old_dir):
            source, target = os.path.join(old_dir, name), os.path.join(new_dir, name)
            if name in _NOT_COPIED or not os.path.isfile(source) or os.path.exists(target):
                continue
            shutil.copyfile(source, target)
            copied += 1
    with open(marker, 'w') as f:
        f.write('1')
    if log:
        log('Settings of the original add-on: {0} setting(s) and {1} file(s) taken over'.format(taken, copied))
        if gone:
            log('Settings of the original add-on that this one does not have any more: {0}'.format(', '.join(sorted(gone))))
    return taken, copied, gone
