import xbmc, xbmcaddon
import re
import langutils
import subcodec
import subformat
import subconvert
import regexwords
import settingsdump
from prefparser import PrefParser
from resources.lib import kodi_utils
from logger import log, LOG_NONE, LOG_INFO, LOG_DEBUG, LOG_ERROR

# Signs & Songs part of the subtitle regex pattern ("S&S", "S + S", "S and S", "S.S"): the two s stand alone
_OLD_SS_PATTERN = r's[\s._+\-\/\\]*(?:&|\+)?[\s._+\-\/\\]*s|'
_SS_PATTERN = r'(?<![^\W\d_])s[\s._+\-\/\\]*(?:&|\+|and)?[\s._+\-\/\\]*s(?![^\W\d_])|'


# the profiles of the regex subtitle filter and the setting that holds the pattern of each
REGEX_PROFILES = ('anime & forced foreign subtitles', 'anime & foreign subtitles, not forced')
REGEX_PATTERN_SETTINGS = ('regexSubPattern', 'regexSubPatternNoForced')
REGEX_WORDS_SETTINGS = ('regexSubWords', 'regexSubWordsNoForced')               # the words the user adds to a profile
REGEX_WHOLE_WORD_SETTINGS = ('regexSubWholeWord', 'regexSubWholeWordNoForced')   # ... as whole words only, or anywhere


class settings():

    def init(self):
        addon = xbmcaddon.Addon()
        self.logLevel = addon.getSetting('log_level')

        if self.logLevel and len(self.logLevel) > 0:
            self.logLevel = int(self.logLevel)
        else:
            self.logLevel = LOG_INFO
            
        self.custom_condsub = []

        self.service_enabled = addon.getSetting('enabled') == 'true'
    
    def __init__( self ):
        self.init()
        
    def spinner_lang(self, addon, setting_id):
        """Language spinner setting -> (english name, canonical code). Empty/unknown -> ('None', 'non')."""
        name, code = langutils.from_spinner(addon.getSetting(setting_id))
        if not code:
            log(LOG_INFO, 'Language setting {0} has no valid value ({1!r}) - treated as None'.format(
                setting_id, addon.getSetting(setting_id)))
            return ('None', langutils.NON)
        return (name, code)

    SUB_CONVERTER_LANGUAGES = 10

    def read_sub_converter(self, addon):
        """Sub converter: the colour of the converted text, and the audio languages it works for (all, or up to 10
        chosen ones - 'None' entries are ignored; the defaults are Japanese, Korean and Chinese)."""
        self.sub_converter_all = addon.getSetting('subConverterAll') == 'true'
        self.sub_converter_langs = []
        for n in range(1, self.SUB_CONVERTER_LANGUAGES + 1):
            name, code = self.spinner_lang(addon, 'SubConvLang%02d' % n)
            if code != langutils.NON and code not in self.sub_converter_langs:
                self.sub_converter_langs.append(code)
        # seconds to seek back after a subtitle switch that was only noticed late (Kodi 19-21): 0 = off, else 1-10
        self.sub_converter_seekback = 0
        if addon.getSetting('subConverterSeekBack') != 'false':
            try:
                self.sub_converter_seekback = min(10, max(1, int(addon.getSetting('subConverterSeekBackSeconds') or 3)))
            except ValueError:
                self.sub_converter_seekback = 3
        # seconds after which reading a file is given up; Usenet is never limited (see prefutils)
        try:
            self.sub_converter_time_limit = min(600, max(30, int(addon.getSetting('subConverterTimeLimit') or 150)))
        except ValueError:
            self.sub_converter_time_limit = 150
        # parallel reads of the subtitle blocks the index lists (1 = one at a time): for Usenet, and for every other source
        # (a debrid service often refuses many connections at once)
        try:
            self.sub_converter_threads = min(8, max(1, int(addon.getSetting('subConverterReadThreads') or 4)))
        except ValueError:
            self.sub_converter_threads = 4
        try:
            self.sub_converter_threads_other = min(8, max(1, int(addon.getSetting('subConverterReadThreadsOther') or 2)))
        except ValueError:
            self.sub_converter_threads_other = 2
        # read only the subtitle blocks the file's index lists, when it does (else the whole file is walked)
        self.sub_converter_use_cues = addon.getSetting('subConverterUseCues') != 'false'
        typed = addon.getSetting('subConverterColorHex')
        self.sub_converter_color, valid = subconvert.resolve_color(addon.getSetting('subConverterColor'), typed)
        if not valid:
            log(LOG_INFO, 'Sub converter: {0!r} is not a colour (use RRGGBB, e.g. FF8800) - using yellow'.format(typed))
        if self.sub_converter_on:
            log(LOG_DEBUG, 'Sub converter: audio {0}, colour {1}'.format(
                'in any language' if self.sub_converter_all else ','.join(self.sub_converter_langs) or 'none chosen',
                self.sub_converter_color))
            log(LOG_DEBUG, 'Sub converter: use the index of the file: {0}'.format(self.sub_converter_use_cues))
            log(LOG_DEBUG, 'Sub converter: give up reading after {0} s (not for usenet)'.format(self.sub_converter_time_limit))
            log(LOG_DEBUG, 'Sub converter: parallel reads of the index blocks: {0} for usenet, {1} for other sources'.format(
                self.sub_converter_threads, self.sub_converter_threads_other))
            log(LOG_DEBUG, 'Sub converter: seek back after a late subtitle switch: {0}'.format(
                '{0} s'.format(self.sub_converter_seekback) if self.sub_converter_seekback else 'off'))

    def readSettings(self):
        self.readPrefs()
        self.readCustomPrefs()
        log(LOG_DEBUG,
                 '\n##### LPM Settings #####\n' \
                 'delay: {0}ms\n' \
                 'cond subs on: {1}\n' \
                 'turn subs on: {2}, turn subs off: {3}\n' \
                 'signs: {4}\n' \
                 'regex sub filter: {5}\n' \
                 'blacklisted keywords (subtitles): {6}\n' \
                 'blacklisted keywords (audio): {7}\n' \
                 'fast subtitles display (10sec latency workaround): {8}\n' \
                 'use file name: {9}, file name regex: {10}\n' \
                 'at least one pref on: {11}\n'\
                 'cond sub prefs: {12}\n' \
                 'custom cond subs prefs: {13}\n' \
                 '##### LPM Settings #####\n'
                 .format(self.delay, self.condsub_prefs_on, self.turn_subs_on, self.turn_subs_off,
                         self.ignore_signs_on,
                         '{0} (profile: {1})'.format(self.regex_sub_filter_enabled, REGEX_PROFILES[self.regex_sub_profile]),
                         ','.join(self.subtitle_keyword_blacklist),
                         ','.join(self.audio_keyword_blacklist),
                         self.fast_subs_display,
                         self.useFilename, self.filenameRegex, self.at_least_one_pref_on,
                         self.CondSubtitlePrefs, self.custom_condsub
                        )
                 )
        if not getattr(self, 'settings_remembered', False):
            self.settings_remembered = True
            settingsdump.remember()                  # what a later change is compared with

    def choices_text(self, changed=None):
        """What the settings mean together, in words, for the dump: the order of the subtitle formats, the regex
        profile and its pattern. changed: the ids that changed (only the lines they affect), None for all."""
        lines = []
        if changed is None or any(i.startswith('SubFormat') or i.startswith('CondSubFormat') for i in changed):
            order = getattr(self, 'sub_format_order', [])
            lines.append('subtitle format preference: {0}'.format(
                ' > '.join(subformat.format_label(f) for f in order) if order else 'none (the first matching track)'))
        if changed is None or any(i.startswith('regexSub') for i in changed):
            if getattr(self, 'regex_sub_filter_enabled', False):
                words = getattr(self, 'regex_sub_words', [])
                lines.append('regex subtitle filter: on, profile "{0}", pattern {1}{2}{3}'.format(
                    REGEX_PROFILES[getattr(self, 'regex_sub_profile', 0)], getattr(self, 'regex_sub_pattern', ''),
                    ', added words ({0}): {1}'.format('whole words only' if getattr(self, 'regex_sub_whole_word', True)
                                                      else 'anywhere in the name', ', '.join(words)) if words else '',
                    ', exclusion {0}'.format(self.regex_sub_exclusion_pattern)
                    if getattr(self, 'regex_sub_exclusion', None) else ''))
            else:
                lines.append('regex subtitle filter: off')
        return lines

    def dump_settings(self):
        # for bug reports: every setting in the log, whatever the log level (the 'logSettings' toggle). Written once
        # for each playback, when the preferences are matched; a changed setting is written by log_changed_settings
        if getattr(self, 'log_settings', False):
            settingsdump.write(self.choices_text())
        else:
            settingsdump.remember()

    def log_changed_settings(self):
        # the settings that changed since the last dump, and only those (the 'logSettings' toggle)
        if getattr(self, 'log_settings', False):
            settingsdump.write_changes(self.choices_text)
        else:
            settingsdump.remember()

    def readPrefs(self):
        addon = xbmcaddon.Addon()    

        self.service_enabled = addon.getSetting('enabled') == 'true'
        self.delay = int(addon.getSetting('delay'))
        self.condsub_prefs_on = addon.getSetting('enableCondSub') == 'true'
        self.cond_audio_switch = self.condsub_prefs_on and addon.getSetting('condAudioSwitch') == 'true'
        self.turn_subs_on = addon.getSetting('turnSubsOn') == 'true'
        self.turn_subs_off = addon.getSetting('turnSubsOff') == 'true'
        self.ignore_signs_on = addon.getSetting('signs') == 'true'
        self.log_settings = addon.getSetting('logSettings') == 'true'
        self.sub_converter_on = addon.getSetting('subConverter') == 'true'
        self.read_sub_converter(addon)
        self.regex_sub_filter_enabled = addon.getSetting('regexSubFilter') == 'true'
        # the profile chooses which pattern is used: each has its own, and the user can add words to either
        try:
            self.regex_sub_profile = int(addon.getSetting('regexSubProfile') or 0)
        except ValueError:
            self.regex_sub_profile = 0
        if self.regex_sub_profile not in range(len(REGEX_PROFILES)):
            self.regex_sub_profile = 0
        pattern_setting = REGEX_PATTERN_SETTINGS[self.regex_sub_profile]
        self.regex_sub_pattern = addon.getSetting(pattern_setting)
        if _OLD_SS_PATTERN in self.regex_sub_pattern:
            # the old S&S part of the pattern allowed nothing between the two s, so it matched the "ss" of
            # any title (Russian, Swiss German, Classic ...): replace it in the stored setting too
            self.regex_sub_pattern = self.regex_sub_pattern.replace(_OLD_SS_PATTERN, _SS_PATTERN)
            log(LOG_INFO, 'Regex pattern: the Signs & Songs part matched any "ss" in a title, corrected to {0}'.format(
                _SS_PATTERN))
            try:
                addon.setSetting(pattern_setting, self.regex_sub_pattern)
            except Exception as e:
                log(LOG_ERROR, 'Could not store the corrected regex pattern: {0}'.format(e))
        # the words the user adds to this profile: used in addition to the pattern, which is not changed by them
        self.regex_sub_words = regexwords.parse_words(addon.getSetting(REGEX_WORDS_SETTINGS[self.regex_sub_profile]))
        self.regex_sub_whole_word = addon.getSetting(REGEX_WHOLE_WORD_SETTINGS[self.regex_sub_profile]) != 'false'
        self.regex_sub_filter = None
        if self.regex_sub_filter_enabled:
            base = extra = None
            if self.regex_sub_pattern:
                try:
                    base = re.compile(self.regex_sub_pattern)
                except re.error as e:
                    log(LOG_ERROR, 'Invalid regex pattern: {0} - {1}'.format(self.regex_sub_pattern, str(e)))
            if self.regex_sub_words:
                extra = re.compile(regexwords.words_pattern(self.regex_sub_words, self.regex_sub_whole_word))
            if base is not None or extra is not None:
                self.regex_sub_filter = regexwords.RegexFilter(base, extra)

        # Exclusion pattern
        self.regex_sub_exclusion_enabled = addon.getSetting('regexSubExclusionEnabled') == 'true'
        self.regex_sub_exclusion_pattern = addon.getSetting('regexSubExclusion')
        if self.regex_sub_filter_enabled and self.regex_sub_exclusion_enabled and self.regex_sub_exclusion_pattern:
            try:
                self.regex_sub_exclusion = re.compile(self.regex_sub_exclusion_pattern, re.IGNORECASE)
            except re.error as e:
                log(LOG_ERROR, 'Invalid exclusion regex pattern: {0} - {1}'.format(self.regex_sub_exclusion_pattern, str(e)))
                self.regex_sub_exclusion = None
        else:
            self.regex_sub_exclusion = None

        self.subtitle_keyword_blacklist_enabled = addon.getSetting('enableSubtitleKeywordBlacklist') == 'true'
        self.subtitle_keyword_blacklist = addon.getSetting('SubtitleKeywordBlacklist')
        if self.subtitle_keyword_blacklist and self.subtitle_keyword_blacklist_enabled:
            self.subtitle_keyword_blacklist = [k for k in self.subtitle_keyword_blacklist.lower().split(',') if k.strip()]
        else:
            self.subtitle_keyword_blacklist = []
        self.audio_keyword_blacklist_enabled = addon.getSetting('enableAudioKeywordBlacklist') == 'true'
        self.audio_keyword_blacklist = addon.getSetting('AudioKeywordBlacklist')
        if self.audio_keyword_blacklist and self.audio_keyword_blacklist_enabled:
            self.audio_keyword_blacklist = [k for k in self.audio_keyword_blacklist.lower().split(',') if k.strip()]
        else:
            self.audio_keyword_blacklist = []
        self.fast_subs_display = int(addon.getSetting('FastSubsDisplay'))
        # preferred subtitle formats, best first (names of subcodec.SUBTITLE_FORMATS); [] = no preference
        self.sub_format_order = []
        # the format of each of the three slots (1st, 2nd, 3rd), None for an empty slot: a conditional rule can
        # choose one of them as its own first choice (CondSubFormat01..12)
        self.sub_format_slots = [None, None, None]
        for slot, setting in enumerate(('SubFormat1', 'SubFormat2', 'SubFormat3')):
            try:
                number = int(addon.getSetting(setting) or 0)
            except ValueError:
                number = 0
            if 1 <= number <= len(subcodec.SUBTITLE_FORMATS):
                self.sub_format_slots[slot] = subcodec.SUBTITLE_FORMATS[number - 1]
                if subcodec.SUBTITLE_FORMATS[number - 1] not in self.sub_format_order:
                    self.sub_format_order.append(subcodec.SUBTITLE_FORMATS[number - 1])
        self.useFilename = addon.getSetting('useFilename') == 'true'
        self.filenameRegex = addon.getSetting('filenameRegex')
        if self.useFilename:
            self.reg = re.compile(self.filenameRegex, re.IGNORECASE)
            self.split = re.compile(r'[_|.|-]+', re.IGNORECASE)


        self.CondSubTag = 'false'

        # (english name, canonical code) per spinner slot - see langutils.from_spinner()
        self.CondSubtitlePrefs = [(set(), [
            self.spinner_lang(addon, 'CondAudioLang%02d' % n)
            + self.spinner_lang(addon, 'CondSubLang%02d' % n)
            + (addon.getSetting('CondSubForced%02d' % n), self.CondSubTag, self.cond_format_slot(addon, n))
            for n in range(1, 13)])]

        # These handle custom user preferences, that should be stored
        self.movieOverrides = addon.getSetting('movieOverrides') == 'true'
        self.tvShowOverrides = addon.getSetting('tvShowOverrides') == 'true'
        self.storeCustomMediaPreferences = self.movieOverrides or self.tvShowOverrides

        # the regex subtitle filter is a preference on its own (it used to be ignored here, so enabling only
        # the regex filter left the whole service idle)
        self.at_least_one_pref_on = (self.condsub_prefs_on
                                    or self.regex_sub_filter_enabled
                                    or self.sub_converter_on
                                    or self.useFilename or self.storeCustomMediaPreferences)

        log(LOG_DEBUG, 'storeCustomMediaPreferences: {0}'.format(self.storeCustomMediaPreferences))

    @staticmethod
    def cond_format_slot(addon, n):
        """The subtitle format slot conditional rule n uses first: 0 = the general order, 1..3 = the 1st / 2nd / 3rd
        preferred format of the general settings."""
        try:
            slot = int(addon.getSetting('CondSubFormat%02d' % n) or 0)
        except ValueError:
            return 0
        return slot if 0 <= slot <= 3 else 0

    def readCustomPrefs(self):
        addon = xbmcaddon.Addon()
        self.custom_condsub = []
        self.custom_condsub_prefs_on = False

        prefParser = PrefParser()
        self.custom_condsub = prefParser.parsePrefString(
            addon.getSetting('CustomCondSub'))

        if len(self.custom_condsub) >0:
            self.custom_condsub_prefs_on = True

    def is_store_user_preference_for_player(self, player):
        """
        Check if the player is playing a video and if the store user preferences is enabled for the media type of the video (e.g. movie, tv show).
        :param player: The player object
        :return: True if the player is playing a video and the store user preference is enabled for the media type, False otherwise
        """
        if not player.isPlayingVideo():
            return False

        return self.is_store_user_preference(kodi_utils.get_media_type(player))

    def is_store_user_preference(self, media_type):
        """
        Check if the user preference is supposed to be stored. That means that the custom preferences are stored for the media type.
        :param media_type:  The media type string
        :return: True if the user preference is supposed to be stored, False otherwise
        """
        if media_type is None:
            return False

        if kodi_utils.is_movie(media_type):
            log(LOG_DEBUG, 'Store user preference for movie: {0}'.format(self.movieOverrides))
            return self.movieOverrides
        elif kodi_utils.is_tv_show(media_type):
            log(LOG_DEBUG, 'Store user preference for tv show: {0}'.format(self.tvShowOverrides))
            return self.tvShowOverrides
        return False