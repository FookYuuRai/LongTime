import os, sys, re
sys.dont_write_bytecode = True      # no __pycache__ in the add-on folder: an old compiled copy can never be used again
import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import json as simplejson

__addon__ = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')
__addonPath__ = __addon__.getAddonInfo('path')
__addonResourcePath__ = xbmcvfs.translatePath(os.path.join(__addonPath__, 'resources', 'lib'))
__addonIconFile__ = xbmcvfs.translatePath(os.path.join(__addonPath__, 'icon.png'))
__user_data_path__ = xbmcvfs.translatePath("special://profile/addon_data/service.languagepreferencemanagernext/")
sys.path.insert(0, __addonResourcePath__)     # this add-on's own modules first (langcodes, logger ... are common names)
import selfcheck
selfcheck.purge_bytecode(xbmcvfs.translatePath(__addonPath__))     # bytecode of an older version, before any import

from langcodes import *
from prefsettings import settings
from prefutils import LangPref_Monitor
from prefutils import LangPrefMan_Player
from logger import log, LOG_NONE, LOG_INFO, LOG_DEBUG, LOG_ERROR
import subconvert
import migrate
import original
import settingsdump

settings = settings()



def _rpc(method, params):
    return simplejson.loads(xbmc.executeJSONRPC(simplejson.dumps(
        {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))


def original_module_enabled():
    """False only when Kodi says the original is not enabled (turned off, or not known to Kodi)."""
    return original.is_enabled(_rpc) is not False


def offer_to_disable_original(also_if_asked=False):
    """The original add-on is installed and enabled next to this one: both would change the subtitles of the same video.
    Asks once (again whenever the user asks for the installation check) whether to turn the original off."""
    if original.is_enabled(_rpc) is False:
        return False
    if original.was_asked(__user_data_path__) and not also_if_asked:
        return False
    original.mark_asked(__user_data_path__)
    if not xbmcgui.Dialog().yesno(
            __addonname__,
            'The original Language Preference Manager is installed and enabled too: both would change the subtitles '
            'of the same video. Turn the original off? (You can turn it on again in Add-ons.)'):
        log(LOG_INFO, 'The original add-on stays enabled (the user chose to keep it)')
        return False
    done = original.disable(_rpc)
    log(LOG_INFO if done else LOG_ERROR, 'The original add-on was {0}'.format('turned off' if done else 'not turned off'))
    xbmcgui.Dialog().notification(__addonname__, 'The original add-on is turned off' if done else
                                  'The original could not be turned off: do it in Add-ons',
                                  xbmcgui.NOTIFICATION_INFO if done else xbmcgui.NOTIFICATION_WARNING, 5000)
    return done


class Main:
    def __init__(self):
        self._init_vars()
        # Converted subtitles are a per-Kodi-session cache. Start a new cache generation before auditing it.
        subconvert.begin_session()
        removed = subconvert.clean_folder(__user_data_path__, lambda msg: log(LOG_INFO, msg))
        log(LOG_INFO, 'Sub converter: startup cleanup completed; {0} prior-session file(s) removed'.format(removed))
        if not settings.service_enabled:
            log(LOG_INFO, "Service not enabled")

        self._check_installation()
        self._take_over_original_settings()
        settings.readSettings()
        self._daemon()

    def _take_over_original_settings(self):
        """The first time: the settings of the original add-on become this add-on's settings (see migrate.py)."""
        try:
            old_dir = xbmcvfs.translatePath('special://profile/addon_data/' + selfcheck.ORIGINAL_ADDON_ID + '/')
            known = set(settingsdump.setting_ids(os.path.join(xbmcvfs.translatePath(__addonPath__), 'resources',
                                                              'settings.xml')))
            migrate.take_over(old_dir, __user_data_path__, known, __addon__.setSetting, lambda msg: log(LOG_INFO, msg))
        except Exception as e:
            log(LOG_ERROR, 'Could not take over the settings of the original add-on: {0}'.format(e))

    def _check_installation(self):
        """Log which code runs, and warn when another folder holds a copy of this add-on (an older version that
        is still installed next to this one: Kodi may load that one instead)."""
        path = xbmcvfs.translatePath(__addonPath__)
        code = selfcheck.fingerprint(__addonResourcePath__)
        log(LOG_INFO, 'Running version {0} from {1} (code {2})'.format(__addonversion__, path, code))
        # what this service runs, for the "Check installation" button of the settings (a script of its own)
        xbmcgui.Window(10000).setProperty(__addonid__ + '_version', __addonversion__)
        xbmcgui.Window(10000).setProperty(__addonid__ + '_code', code)
        try:
            copies = selfcheck.other_copies(path, [xbmcvfs.translatePath('special://home/addons'),
                                                   xbmcvfs.translatePath('special://xbmc/addons')])
        except Exception as e:
            log(LOG_DEBUG, 'Installation check failed: {0}'.format(e))
            return
        try:
            others = selfcheck.original_installed([xbmcvfs.translatePath('special://home/addons'),
                                                   xbmcvfs.translatePath('special://xbmc/addons')])
        except Exception:
            others = []
        if others and original_module_enabled():
            log(LOG_ERROR, 'The original {0} is installed and enabled as well ({1}): both act on the same video.'.format(
                selfcheck.ORIGINAL_ADDON_ID, others[0][1]))
            try:
                offer_to_disable_original()
            except Exception as e:
                log(LOG_ERROR, 'Could not ask about the original add-on: {0}'.format(e))
        if copies:
            where = ', '.join('{0} ({1})'.format(folder, version) for folder, version in copies)
            log(LOG_ERROR, 'Another copy of {0} is installed: {1}. Running: {2} ({3}). Delete the old folder and '
                           'restart Kodi.'.format(__addonid__, where, path, __addonversion__))
            try:
                xbmcgui.Dialog().notification(__addonname__, 'Another copy is installed: delete the old folder and '
                                              'restart Kodi', xbmcgui.NOTIFICATION_WARNING, 10000)
            except Exception:
                pass

    def _init_vars(self):
        self.Monitor = LangPref_Monitor()
        self.Player = LangPrefMan_Player()
        self.Monitor.player = self.Player          # Kodi's subtitle change notifications go to the player

    def _daemon(self):
        while not self.Monitor.abortRequested():
            self.Monitor.waitForAbort(1)


def check_installation():
    """Settings button: a dialog that says whether the installation is clean (no stale code, no second copy)."""
    path = xbmcvfs.translatePath(__addonPath__)
    window = xbmcgui.Window(10000)
    problems, info = selfcheck.check(
        path, __addonResourcePath__,
        [xbmcvfs.translatePath('special://home/addons'), xbmcvfs.translatePath('special://xbmc/addons')],
        window.getProperty(__addonid__ + '_version') or None, window.getProperty(__addonid__ + '_code') or None)
    if problems:
        text = 'Problems found:\n\n' + '\n\n'.join(problems) + '\n\n' + info
    else:
        text = 'No stale versions detected and no second copy of the add-on is installed.\n\n' + info
    log(LOG_INFO, 'Installation check: {0}'.format(text.replace('\n', ' ')))
    xbmcgui.Dialog().textviewer(__addonname__ + ' - installation check', text)
    if selfcheck.original_installed([xbmcvfs.translatePath('special://home/addons'),
                                     xbmcvfs.translatePath('special://xbmc/addons')]):
        offer_to_disable_original(also_if_asked=True)


def pick_color():
    """Settings button: a color chart for the text color of the sub converter (see colorpick.py)."""
    import colorpick
    current, _valid = subconvert.resolve_color(__addon__.getSetting('subConverterColor'),
                                               __addon__.getSetting('subConverterColorHex'))
    heading = __addon__.getLocalizedString(30649)
    labels = [__addon__.getLocalizedString(30650 + n) for n in range(len(subconvert.COLOR_PRESETS))]
    color = colorpick.choose(xbmcgui.Dialog(), heading, current, labels)
    if not color:
        return
    colorpick.store(__addon__, color)
    log(LOG_INFO, 'Sub converter: text color set to {0}'.format(color))
    xbmcgui.Dialog().notification(__addonname__, __addon__.getLocalizedString(30672).format(color),
                                  __addonIconFile__, 3000)


# Allow this to be called as a script with parameters
if len(sys.argv) > 1 and sys.argv[1] == 'show_overrides':
    from resources.lib.override_preference_dialog import *
elif len(sys.argv) > 1 and sys.argv[1] == 'check_install':
    check_installation()
elif len(sys.argv) > 1 and sys.argv[1] == 'pick_color':
    pick_color()
elif __name__ == "__main__":
    if xbmcgui.Window(10000).getProperty(__addonid__ + '_isrunning') == 'True':
        log(LOG_INFO, 'service {0} version {1} is already started. Doing nothing.'.format(__addonname__, __addonversion__))
    else:
        xbmcgui.Window(10000).setProperty(__addonid__ + '_isrunning', 'True')
        log(LOG_INFO, 'service {0} version {1} started'.format(__addonname__, __addonversion__))
        main = Main()
        xbmcgui.Window(10000).setProperty(__addonid__ + '_isrunning', 'False')
        xbmcgui.Window(10000).setProperty(__addonid__ + '_code', '')
        log(LOG_INFO, 'service {0} version {1} stopped'.format(__addonname__, __addonversion__))
