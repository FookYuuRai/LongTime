Service.LanguagePreferenceManagerNeXt
=====================================

A manager for audio and subtitle preferences
============================================

This addon provides an easy way to set your preferred audio streams and subtitle languages in Kodi.

Regional and script variants can be selected for English (US/UK), French
(Canada/France), Spanish (Latin America/Spain), Portuguese (Brazil/Portugal),
and Chinese (Simplified/Traditional). Selection prefers an exact BCP-47 tag
reported by Kodi, then recognizes common region/script labels in track names.
An exact variant ranks above an unlabelled track of the same language; an
explicitly different variant does not match. Generic language preferences
continue to match all their variants. Equally ranked tracks keep the current
selection when possible, otherwise the first eligible track is selected.

For custom audio, subtitle and conditional preferences, use `en-us`, `en-gb`,
`fr-ca`, `fr-fr`, `es-419`, `es-es`, `pt-br`, `pt-pt`, `zh-hans` or `zh-hant`.
For example, `any:fr-fr>any:eng` prefers French (France) subtitles, then English.
Existing forced/signs flags and keyword exclusions still apply.

You can select which audio tracks and subtitles to automatically activate based on your priorities, and define simple conditional rules like "if audio is xxx then activate subtitles yyy" via drop/down lists.
More advanced custom rules can be defined as well (see changelog for more on the syntax. Note that custom rules always take precedence over others).

Special language codes None(non) for subtitles and Any(any) for audio can be used in Conditional Subtitles Rules, normal or custom.
For example "fre:non>any:fre>any:eng" will disable subtitles if audio is French (except if a french forced subtitles track exists) and activate french subtitles for any other audio language. If these are not available it will try the same finding english subtitles.

Rules are re-evaluated and applied whenever you switch audio while watching (from v0.1.5).

It's now also possible to force ignore "Signs and Songs" subtitles in preferences evaluations, based on name, and/or any other subtitle tracks based on predefined keywords.
For example, most dual audio Anime provides english and japanese audio and two english subtitles. Dialogue subtitles with all the dialogue to go with the japanese audio and Song/Sign subtitles which only translate song lyrics and signs you see on screen to be used with the english audio stream. Previously the addon just picked the first subtitles with the correct language which weren't always the correct ones.

An option allows you to store forced preferences per Movie / TVshow (from v1.0.6). When you manually change audio and/or subtitle tracks during play, this will be saved as an overriding preference, taking precedence over all other rules for the next opening of the Movie, or the next episode of the TVshow (Thx a lot to SgtJalau!)

Special Thanks
==============

- @ace20022 and @scott967 for initial development

- @cyberden for making this addon ready for Kodi Matrix

- @fpatrick for fixing an issue with language mapping

- @KnappeGEIL for ideas how to ignore 'Signs and Songs' subtitles

- @SgtJalau for the complete feature to store specific/overriding preferences per Movie / TVshow

- @Hugs11 for the complete support of regional and script languages variant (BCP47)

## Language codes (2.0)
Everywhere a language code can be typed (custom preferences, Original audio list) you can use 2-letter (`en`, `ja`, `de`), 3-letter (`eng`, `jpn`, `ger` or `deu`) codes, or BCP47-style tags (`pt-BR`); they are all treated as the same language. Kodi 22 reports 2-letter codes for streams, older Kodi versions 3-letter ones - both are matched.

## Selection priority
Stored media preferences (`Store preferences`: the audio/subtitle tracks you chose manually for a movie or episode) rank above everything else and are the only thing that outranks the regex filter. What a stored preference applied is never changed by the rules below; if only part of it fits the file (e.g. its subtitle language is missing), only the other part falls through to them.

Subtitles (initial run):
1. Regex subtitle filter (if enabled) - nothing below can override a regex match
2. Conditional subtitle preferences (if enabled) - used when the regex found nothing (they follow the audio track, also when you change it later)
3. Normal subtitle preferences rank below the conditional rules and are skipped when the regex filter matched
4. Subtitle tag in the file name (`Use filename`, e.g. `.subtitle-2`) - lowest preference, only if nothing above selected a track
5. Default subtitle, else the first valid one - when nothing above selected a track (only with the regex filter or conditional subtitles enabled)

Subtitle format (settings: Subtitle format preference): among tracks that fit the language preference equally well, the first format of the list that is present wins (embedded .mkv tracks and subtitle files next to the video are recognised); the regex filter and stored preferences are not affected.

Subtitle format per conditional rule: every conditional rule can use the general order (default) or put the 1st / 2nd / 3rd preferred format first (spinner "Subtitle format for this rule"; in the custom field add -f1 / -f2 / -f3 after the subtitle language, e.g. jpn:eng-f2). The language still decides first; if the chosen format is missing the general order applies.

Forced-flag text tracks: when a format preference is set, an ASS/SRT/WebVTT track that only carries the forced/default flag (and has no "forced" in its name) can be chosen by non-forced rules. Flagged PGS/VobSub tracks and tracks named "forced" stay excluded; an unflagged track wins a tie within the same format. Without a format preference nothing changes.
- Changed: the regex subtitle filter now respects the preferred subtitle language and format. Among the tracks the regex matches, it takes the language of the conditional rule for the playing audio (else the subtitle preferences), then the best format (the rule's 1st/2nd/3rd choice or the general order); the forced/default/original flags and "forced" names do not count there. If no matching track is in a preferred language, the filter works as before (ASS first, forced tracks deferred).

Audio: audio preferences first; an audio tag in the file name (`.audiostream-1`) is only used when the audio preferences matched nothing.
