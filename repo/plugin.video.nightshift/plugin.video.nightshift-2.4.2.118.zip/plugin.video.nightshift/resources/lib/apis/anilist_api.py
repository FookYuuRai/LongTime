# -*- coding: utf-8 -*-
"""Anime extras from AniList (public GraphQL API, no key needed): English dub cast and everything a studio has made."""
import unicodedata, difflib, threading, time
from caches.meta_cache import cache_function, meta_cache
from modules.kodi_utils import make_session

session = make_session('https://graphql.anilist.co')
URL = 'https://graphql.anilist.co'
SEARCH_QUERY = '''query($s:String){Page(perPage:8){media(search:$s,type:ANIME,sort:SEARCH_MATCH){id seasonYear startDate{year} format title{romaji english native}}}}'''
DETAIL_QUERY = '''query($id:Int){Media(id:$id){studios{edges{isMain node{id name}}}
characters(sort:[ROLE,RELEVANCE],perPage:25){pageInfo{hasNextPage} edges{role node{name{full}} voiceActors(language:ENGLISH){name{full} image{large}}}}}}'''
CHARACTERS_QUERY = '''query($id:Int,$p:Int){Media(id:$id){characters(sort:[ROLE,RELEVANCE],perPage:25,page:$p){pageInfo{hasNextPage} edges{role node{name{full}} voiceActors(language:ENGLISH){name{full} image{large}}}}}}'''
MAX_CHARACTER_PAGES = 6  # 25 characters a page; 150 characters covers the English dub of nearly every show
STUDIO_FIELDS = 'pageInfo{hasNextPage} nodes{id format startDate{year} title{romaji english} coverImage{large}}'
CACHE_HOURS = 168
# AniList allows only ~30 requests a minute, and the Extras page asks for a lot at once (dub cast, studio, five producers), so every request
# goes through one lock: requests are spaced out, a 429 waits out Retry-After, and the first caller fills the cache for the others.
_net_lock = threading.Lock()
_match_lock = threading.Lock()
_studio_lock = threading.Lock()
_last_call = [0.0]

def _post(query, variables):
	with _net_lock:
		for attempt in range(4):
			wait = 0.35 - (time.time() - _last_call[0])
			if wait > 0: time.sleep(wait)
			response = session.post(URL, json={'query': query, 'variables': variables}, timeout=25)
			_last_call[0] = time.time()
			if response.status_code == 429:
				try: delay = int(response.headers.get('Retry-After', 20))
				except: delay = 20
				time.sleep(min(delay + 1, 65))
				continue
			response.raise_for_status()
			return response.json().get('data') or {}
	raise RuntimeError('AniList rate limited')

def _norm(text):
	text = unicodedata.normalize('NFKD', (text or '').replace('×', 'x').replace('&', 'and'))
	return ''.join(c for c in text.lower() if c.isalnum())

def _pick(media, names, year):
	"""Best AniList entry for a title: exact name > close name > prefix, within a year of the release."""
	wanted = [n for n in (_norm(i) for i in names) if n]
	try: year = int(year)
	except: year = None
	best, best_key = None, None
	for m in media:
		y = m.get('seasonYear') or (m.get('startDate') or {}).get('year')
		diff = abs(int(y) - year) if (year and y) else 0
		if diff > 1: continue
		titles = [t for t in (_norm(m['title'].get(k)) for k in ('english', 'romaji', 'native')) if t]
		score = 0
		for w in wanted:
			for t in titles:
				if w == t: score = max(score, 4)
				elif min(len(w), len(t)) >= 5 and (t.startswith(w) or w.startswith(t)) and abs(len(w) - len(t)) <= 12: score = max(score, 3)
				elif difflib.SequenceMatcher(None, w, t).ratio() >= 0.85: score = max(score, 2)
		if not score: continue
		key = (score, -diff)
		if best_key is None or key > best_key: best, best_key = m, key
	return best

def _match_fetch(key):
	parts = key.split('\x1f')
	year, names = parts[0], parts[1:]
	seen = {}
	for name in names:
		if not name: continue
		for m in (_post(SEARCH_QUERY, {'s': name}).get('Page') or {}).get('media') or []: seen.setdefault(m['id'], m)
	best = _pick(list(seen.values()), names, year)
	if not best: return {'none': True}
	detail = _post(DETAIL_QUERY, {'id': best['id']}).get('Media') or {}
	dub, names_seen = [], set()
	characters, page = detail.get('characters') or {}, 1
	while True:
		for edge in characters.get('edges') or []:
			for va in edge.get('voiceActors') or []:
				name = va['name']['full']
				if name in names_seen: continue
				names_seen.add(name)
				dub.append({'name': name, 'role': edge['node']['name']['full'], 'thumbnail': (va.get('image') or {}).get('large') or ''})
		if not (characters.get('pageInfo') or {}).get('hasNextPage') or page >= MAX_CHARACTER_PAGES: break
		page += 1
		try: characters = ((_post(CHARACTERS_QUERY, {'id': best['id'], 'p': page}).get('Media') or {}).get('characters')) or {}
		except Exception: break
	edges = (detail.get('studios') or {}).get('edges') or []
	main = next((e['node'] for e in edges if e['isMain']), None)
	studio = {'id': main['id'], 'name': main['name']} if main else {}
	producers = [{'id': e['node']['id'], 'name': e['node']['name']} for e in edges if not e['isMain']]
	return {'id': best['id'], 'studio': studio, 'producers': producers, 'dub_cast': dub}

def anime_match(title, year, original_title=''):
	"""{'id', 'studio': {'id', 'name'}, 'producers': [...], 'dub_cast': [...]} if AniList knows this title (so it is anime), else {}."""
	if not title: return {}
	names = [title] + ([original_title] if original_title and original_title != title else [])
	try:
		with _match_lock:
			result = cache_function(_match_fetch, 'anilist_match_v6_%s_%s_%s' % (title, original_title, year), '\x1f'.join([str(year)] + names), expiration=CACHE_HOURS, json=False)
	except: return {}
	return {} if not result or result.get('none') else result

def english_dub_cast(title, year, original_title=''):
	"""[{'name', 'role', 'thumbnail'}] for the English voice actors of an anime, or [] if it is not anime / has no dub cast."""
	return anime_match(title, year, original_title).get('dub_cast') or []

def _studio_key(studio_id):
	return 'anilist_studio_v2_%s' % studio_id

def _fetch_studios(studio_ids):
	"""{id: [titles]} for several studios at once: one request per page covers every studio that still has pages left."""
	results, active, page = {i: [] for i in studio_ids}, list(studio_ids), 1
	while active and page <= 60:
		fields = ' '.join('s%d:Studio(id:%d){media(perPage:25,page:$p,sort:POPULARITY_DESC){%s}}' % (i, i, STUDIO_FIELDS) for i in active)
		data = _post('query($p:Int){%s}' % fields, {'p': page})
		still_active = []
		for i in active:
			media = ((data.get('s%d' % i)) or {}).get('media') or {}
			for n in media.get('nodes') or []:
				title = n['title'].get('english') or n['title'].get('romaji')
				if not title: continue
				results[i].append({'id': n['id'], 'title': title, 'alt_title': n['title'].get('romaji') or '', 'format': n.get('format') or '',
									'year': (n.get('startDate') or {}).get('year') or '', 'cover': (n.get('coverImage') or {}).get('large') or ''})
			if (media.get('pageInfo') or {}).get('hasNextPage'): still_active.append(i)
		active, page = still_active, page + 1
	return results

def batch_ids(match):
	"""Studio ids worth fetching together for a matched anime: its studio and its first five producers."""
	ids = [match['studio']['id']] if match.get('studio') else []
	return ids + [p['id'] for p in (match.get('producers') or [])[:5]]

def studio_titles(studio_id, batch=()):
	"""Every AniList title (all formats) credited to a studio, most popular first. `batch` lists other studios to fetch in the same requests."""
	try:
		with _studio_lock:
			cached = meta_cache.get_function(_studio_key(studio_id))
			if cached: return cached
			wanted = [studio_id] + [i for i in batch if i != studio_id and not meta_cache.get_function(_studio_key(i))]
			fetched = _fetch_studios(wanted)
			for i, titles in fetched.items():
				if titles: meta_cache.set_function(_studio_key(i), titles, expiration=CACHE_HOURS)
			return fetched.get(studio_id) or []
	except: return []
