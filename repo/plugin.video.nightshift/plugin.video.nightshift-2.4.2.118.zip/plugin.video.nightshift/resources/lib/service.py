# -*- coding: utf-8 -*-
# Stale-copy protection: never write or use compiled Python (__pycache__), and search this add-on's own modules first.
import os, sys
sys.dont_write_bytecode = True

def _use_private_bytecode_cache():
	"""Compiled Python goes to this add-on's own folder, one per add-on VERSION (and Python checks each file's date and size too), so a
	stale copy can never load and an update starts clean - but the code is no longer recompiled from source at every cold start."""
	try:
		import xbmcvfs, xbmcaddon
		version = xbmcaddon.Addon('plugin.video.nightshift').getAddonInfo('version')
		base = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.nightshift/pycache/')
		path = os.path.join(base, version)
		os.makedirs(path, exist_ok=True)
		sys.pycache_prefix = path
		sys.dont_write_bytecode = False
	except Exception:
		sys.dont_write_bytecode = True
_use_private_bytecode_cache()
_LIB = os.path.dirname(os.path.abspath(__file__))
while _LIB in sys.path: sys.path.remove(_LIB)
sys.path.insert(0, _LIB)


def _purge_compiled():
	"""Delete every __pycache__ left in this add-on by an older version, so an old compiled copy can never be loaded."""
	try:
		root = os.path.dirname(os.path.dirname(_LIB))
		for folder, dirs, _files in os.walk(root):
			# art/skin folders never hold Python; skipping them avoids walking thousands of image files at every start
			dirs[:] = [d for d in dirs if d not in ('media', 'skins', 'language', 'fonts')]
			if '__pycache__' in dirs:
				import shutil
				shutil.rmtree(os.path.join(folder, '__pycache__'), ignore_errors=True)
				dirs.remove('__pycache__')
	except Exception:
		pass
_purge_compiled()


def _precompile_and_tidy():
	"""Background, at Kodi start: compile the add-on once into the per-version cache (the first menu open is then not a cold compile) and delete the caches of older versions."""
	try:
		if sys.dont_write_bytecode or not getattr(sys, 'pycache_prefix', None): return
		import shutil, compileall
		parent = os.path.dirname(sys.pycache_prefix)
		for old in os.listdir(parent):
			if os.path.join(parent, old) != sys.pycache_prefix: shutil.rmtree(os.path.join(parent, old), ignore_errors=True)
		compileall.compile_dir(_LIB, maxlevels=10, quiet=2, force=False)
	except Exception:
		pass
from xbmc import Monitor
import os
import json
from time import time
from threading import Thread
Thread(target=_precompile_and_tidy, daemon=True).start()
from caches.settings_cache import get_setting, sync_settings, set_setting
from modules import kodi_utils

pause_services_prop = 'nightshift.pause_services'
current_skin_prop = 'nightshift.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorised) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'

def _start_daemon(target):
	Thread(target=target, daemon=True).start()

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('NIGHTSHIFT', 'SetAddonConstants Service Starting')
		try:
			from caches import watching_cache
			watching_cache.purge()
		except Exception as e: kodi_utils.logger('NIGHTSHIFT', 'Currently watching cache purge failed: %s' % e)
		import random
		new_version = kodi_utils.addon_info('version')
		prev_version = kodi_utils.get_property('nightshift.addon_version')
		stamp = kodi_utils.translate_path(os.path.join(kodi_utils.addon_info('profile'), 'installed_build.txt'))
		try: stamped = open(stamp).read().strip()
		except Exception: stamped = ''
		if stamped != new_version:
			# first start after an install / update (also when Kodi itself was restarted in between): drop everything left by older builds
			try:
				from modules import stale_cleanup
				stale_cleanup.run(kodi_utils.addon_info('path'), stamped or prev_version, new_version)
				os.makedirs(os.path.dirname(stamp), exist_ok=True)
				open(stamp, 'w').write(new_version)
			except Exception as e: kodi_utils.logger('NIGHTSHIFT', 'StaleCleanup failed: %s' % e)
		if prev_version and prev_version != new_version:
			try:
				from caches.settings_cache import clear_settings_boot_state
				clear_settings_boot_state(clear_deferred=True)
			except: pass
			kodi_utils.clear_addon_xml_sync_version()
			kodi_utils.logger('NIGHTSHIFT', 'SetAddonConstants - version %s -> %s' % (prev_version, new_version))
		try:
			from modules import artwork
			artwork.startup_flip()
		except Exception as e: kodi_utils.logger('NIGHTSHIFT', 'NIGHTSHIFT startup style failed: %s' % e)
		try:
			if kodi_utils.current_skin() != 'skin.nightshift': kodi_utils.notification('NIGHTSHIFT needs the NIGHTSHIFT skin for its windows. Switch skin in Settings > Interface.', 8000)
		except Exception: pass
		icon_choice = get_setting('addon_icon_choice', 'resources/media/addon_icons/icon.png')
		addon_path = kodi_utils.addon_info('path')
		icon_path = kodi_utils.translate_path(os.path.join(addon_path, icon_choice))
		icon_mini = os.path.join(addon_path, 'resources', 'media', 'addon_icons', 'minis', os.path.basename(icon_path))
		addon_items = [
			('nightshift.playback_key', str(random.randint(1000, 10000))),
			('nightshift.addon_version', new_version),
			('nightshift.addon_path', addon_path),
			('nightshift.addon_profile', kodi_utils.translate_path(kodi_utils.addon_info('profile'))),
			('nightshift.addon_icon', icon_path),
			('nightshift.addon_icon_mini', icon_mini),
			('nightshift.addon_fanart', kodi_utils.addon_fanart())
					]
		for item in addon_items: kodi_utils.set_property(*item)
		kodi_utils.clear_property('nightshift.widgets_refresh_scheduled')
		kodi_utils.clear_property('nightshift.language_invoker_ready')
		kodi_utils.clear_property('nightshift.addon_xml_applied')
		kodi_utils.clear_property(kodi_utils.SHUTTING_DOWN_PROP)
		kodi_utils.reset_boot_sync_gate()
		try:
			from modules.utils import _prune_qr_cache
			_prune_qr_cache(kodi_utils.translate_path(kodi_utils.addon_info('profile')))
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('NIGHTSHIFT', 'DatabaseMaintenance Service Starting')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		return kodi_utils.logger('NIGHTSHIFT', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('NIGHTSHIFT', 'SyncSettings Service Starting')
		from caches.settings_cache import sync_settings, settings_sync_needed
		if not settings_sync_needed():
			return kodi_utils.logger('NIGHTSHIFT', 'SyncSettings Service Skipped')
		sync_settings({'load_properties': False})
		return kodi_utils.logger('NIGHTSHIFT', 'SyncSettings Service Finished')

class BootstrapSettings:
	def run(self, monitor):
		from caches.settings_cache import (
			bootstrap_settings_needed, bootstrap_settings_properties,
			refresh_widgets_after_db_migration, run_deferred_setup_background_if_needed,
			service_bootstrap_needed, widgets_refresh_after_migration_needed, _properties_loaded,
		)
		if not service_bootstrap_needed():
			return
		kodi_utils.logger('NIGHTSHIFT', 'BootstrapSettings Service Starting')
		try:
			from modules.sources import clear_orphan_nextep_play_stash
			clear_orphan_nextep_play_stash()
		except:
			pass
		if bootstrap_settings_needed() and not _properties_loaded():
			monitor.waitForAbort(2)
		if kodi_utils.service_shutting_down(monitor): return
		try:
			if bootstrap_settings_needed():
				bootstrap_settings_properties()
			if not kodi_utils.service_shutting_down(monitor) and widgets_refresh_after_migration_needed():
				refresh_widgets_after_db_migration()
			run_deferred_setup_background_if_needed()
		except Exception as e:
			kodi_utils.logger('BootstrapSettings', str(e))
		return kodi_utils.logger('NIGHTSHIFT', 'BootstrapSettings Service Finished')

_custom_windows_thread_started = False

def start_custom_windows_prepare(monitor):
	global _custom_windows_thread_started
	if _custom_windows_thread_started: return
	_custom_windows_thread_started = True
	_start_daemon(lambda: CustomWindowsPrepare().run(monitor))

def run_deferred_service_setup():
	global _custom_windows_thread_started
	kodi_utils.logger('NIGHTSHIFT', 'Deferred Service Setup Starting')
	try:
		from windows.base_window import ExtrasUtils
		ExtrasUtils().run()
	except Exception as e: kodi_utils.logger('DeferredServiceSetup', 'ExtrasUtils: %s' % e)
	return kodi_utils.logger('NIGHTSHIFT', 'Deferred Service Setup Finished')

class CustomWindowsPrepare:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'CustomWindowsPrepare Service Starting')
		from windows.base_window import FontUtils
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del player
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'CustomWindowsPrepare Service Finished')

class TraktMonitor:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(45)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				if trakt_user_active(): status = trakt_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('NIGHTSHIFT', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('NIGHTSHIFT', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('NIGHTSHIFT', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('NIGHTSHIFT', trakt_service_string % ('Success. No Changes Needed', next_update_string))
					if status in ('success', 'not needed'):
						kodi_utils.mark_boot_trakt_sync_ready()
					if status == 'success' and not kodi_utils.service_shutting_down(monitor):
						from modules.settings import provider_sync_refresh_widgets
						if provider_sync_refresh_widgets(1):
							try:
								if not kodi_utils.playback_widget_refresh_recent(): kodi_utils.run_plugin({'mode': 'kodi_refresh'})
							except Exception as exc:
								kodi_utils.logger('NIGHTSHIFT', 'Trakt widget refresh skipped: %s' % exc)
			except Exception as e: kodi_utils.logger('NIGHTSHIFT', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'TraktMonitor Service Finished')

class SimklMonitor:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'SimklMonitor Service Starting')
		from apis.simkl_api import simkl_sync_activities
		from modules.settings import simkl_user_active, simkl_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(45)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = simkl_sync_interval()
				next_update_string = 'Simkl Sync finished - Next Sync in %s minutes' % sync_interval
				if simkl_user_active(): status = simkl_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('NIGHTSHIFT', 'Simkl Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('NIGHTSHIFT', 'Simkl Sync Not Run - No Account')
				else: kodi_utils.logger('NIGHTSHIFT', 'Simkl Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					from modules.settings import provider_sync_refresh_widgets
					if provider_sync_refresh_widgets(2):
						try:
							if not kodi_utils.playback_widget_refresh_recent(): kodi_utils.run_plugin({'mode': 'kodi_refresh'})
						except Exception as exc:
							kodi_utils.logger('NIGHTSHIFT', 'Simkl widget refresh skipped: %s' % exc)
			except Exception as e: kodi_utils.logger('NIGHTSHIFT', 'Simkl Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'SimklMonitor Service Finished')

class MdblistMonitor:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'MDBListMonitor Service Starting')
		from apis.mdblist_api import mdblist_sync_activities
		from modules.settings import mdblist_user_active, mdblist_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(60)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = mdblist_sync_interval()
				next_update_string = 'MDBList Sync finished - Next Sync in %s minutes' % sync_interval
				if mdblist_user_active(): status = mdblist_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('NIGHTSHIFT', 'MDBList Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('NIGHTSHIFT', 'MDBList Sync Not Run - No Account')
				else: kodi_utils.logger('NIGHTSHIFT', 'MDBList Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					from modules.settings import provider_sync_refresh_widgets
					if provider_sync_refresh_widgets(3):
						try:
							if not kodi_utils.playback_widget_refresh_recent(): kodi_utils.run_plugin({'mode': 'kodi_refresh'})
						except Exception as exc:
							kodi_utils.logger('NIGHTSHIFT', 'MDBList widget refresh skipped: %s' % exc)
			except Exception as e: kodi_utils.logger('NIGHTSHIFT', 'MDBList Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'MDBListMonitor Service Finished')

class PunchPlayMonitor:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'PunchPlayMonitor Service Starting')
		from apis.punchplay_api import punchplay_sync_activities
		from modules.settings import punchplay_user_active, punchplay_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(55)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = punchplay_sync_interval()
				next_update_string = 'PunchPlay Sync finished - Next Sync in %s minutes' % sync_interval
				if punchplay_user_active(): status = punchplay_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('NIGHTSHIFT', 'PunchPlay Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('NIGHTSHIFT', 'PunchPlay Sync Not Run - No Account')
				else: kodi_utils.logger('NIGHTSHIFT', 'PunchPlay Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					from modules.settings import provider_sync_refresh_widgets
					if provider_sync_refresh_widgets(4):
						try:
							if not kodi_utils.playback_widget_refresh_recent(): kodi_utils.run_plugin({'mode': 'kodi_refresh'})
						except Exception as exc:
							kodi_utils.logger('NIGHTSHIFT', 'PunchPlay widget refresh skipped: %s' % exc)
			except Exception as e: kodi_utils.logger('NIGHTSHIFT', 'PunchPlay Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'PunchPlayMonitor Service Finished')

class WidgetRefresher:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'WidgetRefresher Service Starting')
		from time import time
		player = kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				if kodi_utils.service_shutting_down(monitor): continue
				offset = int(get_setting('nightshift.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('NIGHTSHIFT', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del player
		except: pass
		return kodi_utils.logger('NIGHTSHIFT', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True

		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		if kodi_utils.get_property('nightshift.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(kodi_utils.get_property('nightshift.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('nightshift.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class AutoStart:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'AutoStart Service Starting')
		from modules.settings import auto_start_nightshift
		if auto_start_nightshift() and not kodi_utils.service_shutting_down(monitor):
			try:
				from caches.settings_cache import ensure_settings_properties_loaded
				ensure_settings_properties_loaded()
			except Exception as e:
				kodi_utils.logger('AutoStart', 'bootstrap: %s' % e)
			kodi_utils.run_addon()
		return kodi_utils.logger('NIGHTSHIFT', 'AutoStart Service Finished')

class ServiceExpiryAlerts:
	def run(self, monitor):
		kodi_utils.logger('NIGHTSHIFT', 'ServiceExpiryAlerts Service Starting')
		from modules.service_expiry import run_expiry_alerts
		monitor.waitForAbort(60)
		if not monitor.abortRequested() and not kodi_utils.service_shutting_down(monitor):
			try: run_expiry_alerts()
			except Exception as e: kodi_utils.logger('ServiceExpiryAlerts', str(e))
		return kodi_utils.logger('NIGHTSHIFT', 'ServiceExpiryAlerts Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('NIGHTSHIFT', 'AddonXMLCheck Service Starting')
		try: kodi_utils.reuse_language_invoker_check()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		return kodi_utils.logger('NIGHTSHIFT', 'AddonXMLCheck Service Finished')
		
# ========== NEW SERVICE: Thumbnail Cleanup ==========

class ThumbnailCleanup:
	def run(self, monitor):
		"""Daemon service entry point — respects interval and pause conditions."""
		kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Service Starting')
		try:
			# Respect sleep/screensaver pause, same as the monitor services.
			for _ in range(30):
				if kodi_utils.service_shutting_down(monitor): return
				if kodi_utils.get_property(pause_services_prop) != 'true': break
				monitor.waitForAbort(10)

			if get_setting('nightshift.thumbnail_cleanup_enabled') != 'true':
				return kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Service Skipped (disabled)')

			interval_days = get_setting('nightshift.thumbnail_cleanup_interval', '0')
			if interval_days == '0':
				return kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Service Skipped (interval Off)')

			last_run = int(get_setting('nightshift.thumbnail_cleanup_last_run', '0') or 0)
			now = int(time())
			if last_run and interval_days != '1':  # '1' = every boot, skip the gate
				if (now - last_run) < int(interval_days) * 86400:
					return kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Service Skipped (interval not elapsed)')

			removed = self._clean_thumbnails()
			pruned = kodi_utils.prune_texture_cache()

			if removed or pruned:
				# Clear NIGHTSHIFT meta cache to force artwork URL re-fetch
				from caches.meta_cache import meta_cache
				meta_cache.delete_all()
				
				set_setting('nightshift.thumbnail_cleanup_last_run', str(now), provider_sync=False)
				kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Daemon: %s items, %s rows' % (removed, pruned))
				kodi_utils.notification('%s thumbnails cleared, %s DB rows pruned' % (removed, pruned), 5000)
				
				# Exit Kodi after notification (threaded to not block service)
				import xbmc
				from threading import Thread
				kodi_utils.logger('NIGHTSHIFT', 'Triggering Kodi exit after thumbnail cleanup')
				Thread(target=lambda: (xbmc.sleep(3000), xbmc.executebuiltin('Quit')), daemon=True).start()
		except Exception as e:
			kodi_utils.logger('ThumbnailCleanup', str(e))
		return kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Service Finished')

	def run_now(self):
		"""Manual 'Clean Now' trigger from Settings. Returns (removed, pruned)."""
		try:
			removed = self._clean_thumbnails()
			pruned = kodi_utils.prune_texture_cache()
			if removed or pruned:
				# Clear NIGHTSHIFT meta cache to force artwork URL re-fetch
				from caches.meta_cache import meta_cache
				meta_cache.delete_all()
				set_setting('nightshift.thumbnail_cleanup_last_run', str(int(time())), provider_sync=False)
				kodi_utils.logger('NIGHTSHIFT', 'ThumbnailCleanup Manual: %s items, %s rows' % (removed, pruned))
				kodi_utils.notification('%s thumbnails cleared, %s DB rows pruned' % (removed, pruned), 5000)
				
				# Exit Kodi in separate thread so return completes first
				import xbmc
				from threading import Thread
				kodi_utils.logger('NIGHTSHIFT', 'Triggering Kodi exit after manual thumbnail cleanup')
				Thread(target=lambda: (xbmc.sleep(3000), xbmc.executebuiltin('Quit')), daemon=True).start()
			
			return removed, pruned
		except Exception as e:
			kodi_utils.logger('ThumbnailCleanup', str(e))
			return None, None

	def _clean_thumbnails(self):
		import os
		import shutil
		thumbnails_dir = kodi_utils.translate_path('special://profile/Thumbnails/')
		if not kodi_utils.path_exists(thumbnails_dir):
			kodi_utils.make_directories(thumbnails_dir)
			return 0
		folders, files = kodi_utils.list_dirs(thumbnails_dir)
		removed = 0
		for filename in files:
			try:
				kodi_utils.delete_file(os.path.join(thumbnails_dir, filename))
				removed += 1
			except: pass
		for foldername in folders:
			try:
				shutil.rmtree(kodi_utils.translate_path(os.path.join(thumbnails_dir, foldername)), ignore_errors=True)
				removed += 1
			except: pass
		return removed

# ====================================================

class NightShiftMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		self.startServices()

	def startServices(self):
		try: SetAddonConstants().run()
		except Exception as e: kodi_utils.logger('SetAddonConstants', str(e))
		try: DatabaseMaintenance().run()
		except Exception as e: kodi_utils.logger('DatabaseMaintenance', str(e))
		try: SyncSettings().run()
		except Exception as e: kodi_utils.logger('SyncSettings', str(e))
		try: AddonXMLCheck().run()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		
		# ========== NEW SERVICE: ThumbnailCleanup ==========
		try:
			_start_daemon(lambda: ThumbnailCleanup().run(self))
		except Exception as e: kodi_utils.logger('ThumbnailCleanup', str(e))
		# ====================================================
		
		try:
			from caches.settings_cache import service_bootstrap_needed
			if service_bootstrap_needed():
				_start_daemon(lambda: BootstrapSettings().run(self))
		except Exception as e: kodi_utils.logger('BootstrapSettings', str(e))
		start_custom_windows_prepare(self)
		_start_daemon(lambda: TraktMonitor().run(self))
		_start_daemon(lambda: SimklMonitor().run(self))
		_start_daemon(lambda: MdblistMonitor().run(self))
		_start_daemon(lambda: PunchPlayMonitor().run(self))
		_start_daemon(lambda: WidgetRefresher().run(self))
		try:
			from modules.prewarm import run as prewarm_run
			_start_daemon(lambda: prewarm_run(self))
		except Exception as e: kodi_utils.logger('Prewarm', str(e))
		try: AutoStart().run(self)
		except Exception as e: kodi_utils.logger('AutoStart', str(e))
		_start_daemon(lambda: ServiceExpiryAlerts().run(self))
		try:
			from apis.nzb_api import purge_if_due
			_start_daemon(purge_if_due)
		except Exception as e: kodi_utils.logger('NZB', 'old NZB cleanup not started: %s' % e)

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING NIGHTSHIFT Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING NIGHTSHIFT Services Due to Device Awake')
		elif method in ('Addon.OnDisabled', 'Addon.OnUninstalled'):
			try:
				info = json.loads(data)
				if info.get('id') == 'plugin.video.nightshift':
					kodi_utils.prepare_service_shutdown()
					kodi_utils.logger('NIGHTSHIFT', 'Service shutdown - addon disabled for update or uninstall')
			except: pass

if __name__ == '__main__':
	# ----- AM Lite Trakt startup sync patch BEGIN -----
	def wait_for_am_trakt(timeout=120, max_age=180):
		import time
		import xbmc
		import xbmcaddon

		if not xbmc.getCondVisibility('System.HasAddon(script.module.acctmgr)'):
			return False

		waited = 0
		while waited < timeout:
			try:
				am = xbmcaddon.Addon('script.module.acctmgr')
				ready = am.getSetting('am_trakt_ready')
				last_prepare = am.getSetting('am_last_prepare')
				if ready == 'true' and last_prepare:
					age = int(time.time()) - int(last_prepare)
					if 0 <= age <= max_age:
						return True
			except Exception:
				pass
			xbmc.sleep(1000)
			waited += 1
		return False

	def _am_trakt_startup():
		try:
			wait_for_am_trakt()
		except Exception:
			pass

	Thread(target=_am_trakt_startup, daemon=True).start()
	# ----- AM Lite Trakt startup sync patch END -----
	kodi_utils.logger('NIGHTSHIFT', 'Main Monitor Service Starting')
	NightShiftMonitor().waitForAbort()
	kodi_utils.logger('NIGHTSHIFT', 'Main Monitor Service Finished')