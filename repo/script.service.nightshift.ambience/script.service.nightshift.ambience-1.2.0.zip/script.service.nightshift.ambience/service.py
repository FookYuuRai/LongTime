# -*- coding: utf-8 -*-
"""NIGHTSHIFT menu ambience.

Plays a quiet loop while you browse the NIGHTSHIFT menus (home screen and NIGHTSHIFT add-on lists)
and gets out of the way the moment anything real starts playing. It restarts after playback ends.
"""
import os
import xbmc
import xbmcaddon
import xbmcgui
import json
import random
import secrets
import threading
from urllib.parse import unquote

import xbmcvfs

import musicfolders
from tracks import BUILTIN_TRACKS

ADDON = xbmcaddon.Addon()
SKIN_ID = 'skin.nightshift'
NIGHTSHIFT_PLUGIN = 'plugin://plugin.video.nightshift/'
PROP = 'PlayingBackgroundMedia'     # the skin hides the now-playing bar while this is set
_RNG = random.SystemRandom()          # OS entropy (same source as the secrets module), not the Mersenne Twister
BG_DIR = 'special://skin/media/backgrounds/'
BG_PROP = 'NSBG'                      # Window(Home).Property(NSBG): the image the skin draws behind the Home menus
BG_SKIP = ('screen_bg',)              # the grid backdrop under everything is not part of the rotation
DEFAULT_VOLUME = 40                   # percent, when the skin string is empty
GRACE_POLLS = 2                      # seconds a menu may look "wrong" (e.g. while a folder loads) before we stop
RESTART_DELAY = 3                    # seconds to wait after real playback ends

def log(msg):
	xbmc.log('[NIGHTSHIFT ambience] %s' % msg, xbmc.LOGINFO)

def setting_bool(key, default=True):
	try: return xbmcaddon.Addon().getSettingBool(key)      # a fresh instance: sees a change made in the settings window
	except Exception: return default

def _norm(path):
	path = unquote(path or '').replace('\\', '/')
	return path.rstrip('/').lower()

def _same_file(a, b):
	a, b = _norm(a), _norm(b)
	return a == b or os.path.basename(a) == os.path.basename(b)

def skin_string(name):
	return (xbmc.getInfoLabel('Skin.String(%s)' % name) or '').strip()

def track_exists(path):
	"""Local, network (smb/nfs/...) or Android paths, with any characters in the name."""
	try:
		if xbmcvfs.exists(path): return True
	except Exception: pass
	try: return os.path.exists(path)
	except Exception: return False

class AmbiencePlayer(xbmc.Player):
	def __init__(self):
		super().__init__()
		self.our_path = ''
		self.real_playback = False
		self.dead = False             # set when Kodi asks the service to stop: callbacks then do nothing

	def is_ours(self):
		try:
			if not (self.isPlayingAudio() and self.our_path): return False
			return _same_file(self.getPlayingFile(), self.our_path)
		except Exception: return False

	def onPlayBackStarted(self):
		if self.dead: return
		if getattr(self, 'on_real', None) and not self.is_ours(): self.on_real()
		# Anything that is not our own track counts as real playback (video, music, a stream from the add-on...)
		if not self.is_ours(): self.real_playback = True

	def onAVStarted(self):
		if self.dead: return
		if not self.is_ours(): self.real_playback = True

	def onPlayBackStopped(self):
		if self.dead: return
		if not self.is_ours(): self.real_playback = False

	def onPlayBackEnded(self):
		if self.dead: return
		if not self.is_ours(): self.real_playback = False

class Ambience(xbmc.Monitor):
	def __init__(self):
		super().__init__()
		self.player = AmbiencePlayer()
		self.extra = []
		self.index = 0
		self.bad_polls = 0
		self.resume_at = 0
		self.ticks = 0
		self.path = ADDON.getAddonInfo('path')
		self.playlist = []
		self.folders_stamp = None
		self.last_track = ''
		self.bad_tracks = 0
		self.saved_volume = None      # the user's own volume while ambience plays quieter
		self.applied_volume = None
		self.started_at = 0

	def build_playlist(self):
		"""The built-in tracks (unless switched off) followed by the music of the folders added in the settings."""
		tracks = []
		if setting_bool('builtin', True) or not self.extra_tracks():
			tracks += self.builtin_tracks()
		tracks += self.extra_tracks()
		if setting_bool('shuffle', True): self.shuffle(tracks)
		self.playlist = tracks
		self.folders_stamp = musicfolders.stamp()
		log('%d track(s) in the rotation (%d from added folders)' % (len(tracks), len(self.extra)))

	def current_rotation(self):
		tracks = []
		if setting_bool('builtin', True) or not self.extra_tracks(): tracks += self.builtin_tracks()
		return tracks + self.extra_tracks()

	def builtin_tracks(self):
		"""The built-in files whose own switch in the settings is on."""
		return [os.path.join(self.path, 'resources', 'audio', name) for setting_id, name, _label in BUILTIN_TRACKS if setting_bool(setting_id, True)]

	def shuffle(self, tracks, avoid_first=None):
		"""Fisher-Yates with OS entropy; the first track of a new round is never the one that just played."""
		_RNG.shuffle(tracks)
		if avoid_first and len(tracks) > 1 and tracks[0] == avoid_first:
			swap = _RNG.randrange(1, len(tracks))
			tracks[0], tracks[swap] = tracks[swap], tracks[0]

	def extra_tracks(self):
		if getattr(self, '_extra_for', None) != musicfolders.stamp():
			try: self.extra = musicfolders.tracks()
			except Exception as e: log('folder scan failed: %s' % e); self.extra = []
			self._extra_for = musicfolders.stamp()
		return self.extra

	def track_path(self):
		if not self.playlist or self.folders_stamp != musicfolders.stamp(): self.build_playlist()
		if not self.playlist: return ''          # every track is switched off: nothing to play
		if self.index >= len(self.playlist):
			self.index = 0
			if setting_bool('shuffle', True): self.shuffle(self.playlist, avoid_first=self.last_track)
		return self.playlist[self.index]

	def skin_active(self):
		return xbmc.getSkinDir() == SKIN_ID

	def menus_allowed(self):
		"""True while the user is browsing NIGHTSHIFT menus."""
		if not setting_bool('enabled', True) or not self.skin_active(): return False
		if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd) | Window.IsActive(visualisation) | Window.IsActive(videobookmarks)'): return False
		if not setting_bool('nightshift_only', True): return True
		if xbmc.getCondVisibility('Window.IsActive(home)'): return True
		return (xbmc.getInfoLabel('Container.FolderPath') or '').startswith(NIGHTSHIFT_PLUGIN)

	def mark(self, on):
		try:
			win = xbmcgui.Window(10025)
			win.setProperty(PROP, 'true') if on else win.clearProperty(PROP)
		except Exception: pass

	def start(self):
		path = self.track_path()
		if not path:
			self.resume_at = 10; return           # nothing is switched on; look again in a few seconds
		self.last_track = path
		if not track_exists(path):
			log('missing track %s' % path); self.index += 1; self.bad_tracks += 1
			if self.bad_tracks > 50: self.resume_at = 30; self.bad_tracks = 0
			return
		self.apply_ambience_volume()
		self.player.our_path = path
		self.mark(True)                       # set before playback so the now-playing bar never flashes
		self.player.real_playback = False
		item = xbmcgui.ListItem(path=path)
		self.player.play(path, item, windowed=True)
		self.index += 1
		self.bad_tracks = 0
		self.started_at = 3
		log('started %s' % os.path.basename(path))

	def stop(self):
		if self.player.is_ours():
			self.player.stop(); log('stopped ambience')
		self.restore_user_volume()
		self.player.our_path = ''
		self.mark(False)


	# --- ambience-only volume -------------------------------------------------------------------------------------
	# Kodi has one master volume, so the ambience level works by swapping: the user's volume is remembered when an
	# ambience track starts, the (quieter) ambience level is applied, and the user's volume comes back the moment
	# anything else plays or the ambience stops. Video / music playback therefore always runs at the normal volume.
	def target_volume(self):
		raw = skin_string('ns_ambience_volume')
		try: return max(0, min(100, int(raw)))
		except ValueError: return DEFAULT_VOLUME

	def get_volume(self):
		try:
			data = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Application.GetProperties', 'params': {'properties': ['volume']}})))
			return int(data['result']['volume'])
		except Exception: return None

	def set_volume(self, value):
		xbmc.executebuiltin('SetVolume(%d,false)' % int(value))

	def _saved_file(self):
		folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/')
		if not xbmcvfs.exists(folder): xbmcvfs.mkdirs(folder)
		return os.path.join(folder, 'user_volume.json')

	def apply_ambience_volume(self):
		target = self.target_volume()
		current = self.get_volume()
		if current is None: return
		if self.saved_volume is None:
			if current == target: return          # already at the ambience level, nothing to swap
			self.saved_volume = current
			try:
				with open(self._saved_file(), 'w') as handle: json.dump({'volume': current}, handle)
			except Exception: pass
		elif self.applied_volume is not None and current != self.applied_volume:
			# the user turned the volume while ambience played: that is their volume now, leave it alone
			self.saved_volume = None
			self.applied_volume = None
			self.forget_saved()
			return
		if current != target:
			self.set_volume(target)
		self.applied_volume = target

	def forget_saved(self):
		try: os.remove(self._saved_file())
		except Exception: pass

	def restore_user_volume(self):
		if self.saved_volume is None: return
		value = self.saved_volume
		self.saved_volume = None
		self.applied_volume = None
		self.set_volume(value)
		self.forget_saved()
		log('volume back to %d%%' % value)

	def restore_after_crash(self):
		try:
			with open(self._saved_file()) as handle: value = int(json.load(handle)['volume'])
			self.set_volume(value); log('volume restored to %d%% (left over from an earlier session)' % value)
		except Exception: pass
		self.forget_saved()

	def watch_volume(self):
		"""The slider in the skin settings: follow it live while an ambience track plays."""
		if self.saved_volume is None and not self.player.is_ours(): return
		target = self.target_volume()
		if self.applied_volume is not None and target != self.applied_volume:
			current = self.get_volume()
			if current == self.applied_volume:
				self.set_volume(target)
				self.applied_volume = target

	# --- random Home backgrounds ------------------------------------------------------------------------------------
	def background_pool(self):
		pool = []
		try: files = xbmcvfs.listdir(BG_DIR)[1]
		except Exception: files = []
		for name in sorted(files):
			stem, ext = os.path.splitext(name)
			if ext.lower() not in ('.jpg', '.jpeg', '.png') or stem in BG_SKIP: continue
			if xbmc.getCondVisibility('Skin.HasSetting(ns_hide_bg_%s)' % stem): continue    # switched off in the skin settings
			pool.append(BG_DIR + name)
		return pool

	def pick_background(self):
		"""A new image for every menu position: secrets.choice, never the same one twice in a row."""
		pool = self.background_pool()
		home = xbmcgui.Window(10000)
		if not pool:
			home.clearProperty(BG_PROP); return
		current = home.getProperty(BG_PROP)
		choices = [p for p in pool if p != current] or pool
		home.setProperty(BG_PROP, secrets.choice(choices))

	def background_key(self):
		if xbmc.getCondVisibility('Skin.HasSetting(ns_bg_fixed)') or not xbmc.getCondVisibility('Window.IsActive(home)'):
			return None
		return '|'.join((xbmc.getInfoLabel('Window(Home).Property(Nightshift.Section)'),
			xbmc.getInfoLabel('Container(9000).CurrentItem'), xbmc.getInfoLabel('Container(9200).CurrentItem')))

	def background_loop(self):
		last = object()
		flip_path = None
		while not self.abortRequested():
			try:
				# watched-icon mix: eyes / red diamond are told apart by row parity; a secrets coin flip, re-rolled for every folder you open, decides which parity gets which
				here = xbmc.getInfoLabel('Container.FolderPath') or ''
				if here != flip_path or not xbmcgui.Window(10000).getProperty('NSWFLIP'):
					xbmcgui.Window(10000).setProperty('NSWFLIP', secrets.choice(('0', '1'))); flip_path = here
			except Exception as e: log('watched-icon flip error: %s' % e)
			try:
				if not self.skin_active(): last = object()
				else:
					key = self.background_key()
					if key is None:
						if last is not None: xbmcgui.Window(10000).clearProperty(BG_PROP)
						last = None
					elif key != last or not xbmcgui.Window(10000).getProperty(BG_PROP):
						self.pick_background(); last = key
			except Exception as e: log('background error: %s' % e)
			if self.waitForAbort(0.15): break

	def tick(self):
		playing = self.player.isPlaying()
		ours = self.player.is_ours()
		self.watch_volume()
		if playing and not ours:
			# real playback: never touch it, drop our marker, remember to restart later
			self.restore_user_volume()
			self.player.real_playback = True
			self.player.our_path = ''
			self.mark(False)
			self.resume_at = RESTART_DELAY
			self.bad_polls = 0
			return
		if self.player.real_playback and not playing:
			self.player.real_playback = False
			self.resume_at = RESTART_DELAY
		if self.resume_at > 0:
			self.resume_at -= 1
			return
		allowed = self.menus_allowed()
		if ours:
			self.bad_polls = 0 if allowed else self.bad_polls + 1
			if self.bad_polls >= GRACE_POLLS: self.stop(); self.bad_polls = 0
			return
		if not playing:
			self.mark(False)
			if not allowed: self.restore_user_volume()
			if allowed: self.start()

	def onAbortRequested(self):
		self.player.dead = True

	def onSettingsChanged(self):
		self.playlist = []            # the track list is built again (built-in on/off, shuffle, folders)
		self.index = 0
		if self.player.is_ours():
			playing = self.player.our_path
			if not self.menus_allowed() or (playing and playing not in self.current_rotation()): self.stop()   # also when its own switch was turned off

	def run(self):
		log('service started')
		self.restore_after_crash()
		self.player.on_real = self.restore_user_volume
		threading.Thread(target=self.background_loop, daemon=True).start()
		while not self.abortRequested():
			try: self.tick()
			except Exception as e: log('tick error: %s' % e)
			if self.waitForAbort(1): break
		self.player.dead = True
		# Shutting down (Kodi quitting, or the add-on being disabled while a track plays). Kodi waits for this script to
		# end, so nothing below may wait for Kodi in return (Player.stop(), JSON-RPC and window-property calls all do,
		# which froze Kodi until it killed the script). Only queued built-ins are used here; they run after we are gone.
		try:
			if self.player.our_path: xbmc.executebuiltin('PlayerControl(Stop)', False)
			if self.saved_volume is not None:
				xbmc.executebuiltin('SetVolume(%d,false)' % int(self.saved_volume), False)
				self.saved_volume = None
				self.forget_saved()
			xbmc.executebuiltin('ClearProperty(%s,10025)' % PROP, False)
		except Exception: pass
		log('service stopped')

if __name__ == '__main__':
	Ambience().run()
