# -*- coding: utf-8 -*-
"""Buttons of the NIGHTSHIFT ambience settings: add, show and remove music folders.
RunScript(script.service.nightshift.ambience,add|show|remove|clear|tracks_on|tracks_off)"""
import os
import shutil
import subprocess
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import musicfolders
from tracks import BUILTIN_TRACKS

TITLE = 'NIGHTSHIFT ambience'


def notify(text):
	xbmcgui.Dialog().notification(TITLE, text, xbmcgui.NOTIFICATION_INFO, 4000, False)


def add():
	dialog = xbmcgui.Dialog()
	pick = dialog.select('Add a music folder', ['Browse for a folder...', 'Type or paste a folder path...'])
	if pick < 0:
		return
	if pick == 0:
		path = dialog.browse(0, 'Choose a folder with music (it is searched with the folders inside it)', 'music', '', False, False, '')
	else:
		path = dialog.input('Folder path (for example /storage/emulated/0/Music or smb://nas/music)', type=xbmcgui.INPUT_ALPHANUM)
	path = (path or '').strip()
	if not path:
		return
	folders = musicfolders.load()
	if path in folders:
		notify('That folder is already in the list')
		return
	if not xbmcvfs.exists(path if path.endswith(('/', '\\')) else path + '/'):
		if not dialog.yesno(TITLE, 'Kodi cannot see this folder right now:\n%s\n\nAdd it anyway?' % path):
			return
	found = musicfolders.scan(path)
	folders.append(path)
	if musicfolders.save(folders):
		notify('Added: %d track(s) found' % len(found))
	else:
		notify('The folder could not be saved')


def show():
	folders = musicfolders.load()
	if not folders:
		xbmcgui.Dialog().ok(TITLE, 'No extra music folders yet.\nUse "Add a music folder" to add songs to the built-in tracks.')
		return
	lines = ['Extra music folders (played after the built-in tracks):', '']
	total = 0
	for folder in folders:
		count = len(musicfolders.scan(folder))
		total += count
		lines.append('%s\n    %d track(s)' % (folder, count))
	lines += ['', 'Total: %d extra track(s)' % total]
	xbmcgui.Dialog().textviewer(TITLE, '\n'.join(lines))


def remove():
	folders = musicfolders.load()
	if not folders:
		notify('No extra music folders to remove')
		return
	picked = xbmcgui.Dialog().multiselect('Remove which folders?', folders)
	if not picked:
		return
	keep = [f for i, f in enumerate(folders) if i not in picked]
	if musicfolders.save(keep):
		notify('Removed %d folder(s)' % len(picked))


def clear():
	if musicfolders.load() and xbmcgui.Dialog().yesno(TITLE, 'Remove all extra music folders?'):
		musicfolders.save([])
		notify('All extra folders removed')


def _find_ffmpeg():
	"""ffmpeg on the PATH or in the usual places (Kodi itself cannot convert audio)."""
	found = shutil.which('ffmpeg')
	if found:
		return found
	for cand in ('/usr/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/system/bin/ffmpeg', '/system/xbin/ffmpeg',
				'/data/data/com.termux/files/usr/bin/ffmpeg', '/storage/emulated/0/ffmpeg', 'C:\\ffmpeg\\bin\\ffmpeg.exe'):
		if os.path.isfile(cand):
			return cand
	return None


def _local(path):
	try:
		return xbmcvfs.translatePath(path) if path.startswith('special://') else path
	except Exception:
		return path


def _lossless_without_mp3(folder, out, depth=0):
	if depth > musicfolders.MAX_DEPTH:
		return
	try:
		dirs, files = xbmcvfs.listdir(folder)
	except Exception:
		return
	have = set(os.path.splitext(n)[0].lower() for n in files if n.lower().endswith('.mp3'))
	for n in files:
		base, ext = os.path.splitext(n)
		if ext.lower() in musicfolders.LOSSLESS and base.lower() not in have:
			out.append(musicfolders._join(folder, n))
	for d in dirs:
		_lossless_without_mp3(musicfolders._join(folder, d), out, depth + 1)


def convert():
	"""Convert every FLAC/lossless file in the added folders to an .mp3 beside it."""
	dialog = xbmcgui.Dialog()
	folders = musicfolders.load()
	if not folders:
		dialog.ok(TITLE, 'No music folders added yet. Use "Add a music folder" first.')
		return
	todo = []
	for f in folders:
		_lossless_without_mp3(f, todo)
	if not todo:
		notify('No FLAC files left to convert')
		return
	ffmpeg = _find_ffmpeg()
	if not ffmpeg:
		dialog.ok(TITLE, '%d lossless file(s) need converting, but ffmpeg is not available on this device.\n'
			'Run convert_flac_to_mp3.py (in the add-on folder) on a PC with ffmpeg, or install ffmpeg here.\n'
			'Until then, those FLAC files are still tried as they are.' % len(todo))
		return
	if not dialog.yesno(TITLE, 'Convert %d lossless file(s) to MP3 (320k)?\nThe originals are kept; ambience then uses the MP3.' % len(todo)):
		return
	progress = xbmcgui.DialogProgress()
	progress.create(TITLE, 'Converting...')
	done = failed = 0
	for i, src in enumerate(todo):
		if progress.iscanceled():
			break
		progress.update(int(i * 100 / len(todo)), os.path.basename(src))
		src_l = _local(src)
		dst_l = os.path.splitext(src_l)[0] + '.mp3'
		try:
			r = subprocess.run([ffmpeg, '-y', '-loglevel', 'error', '-i', src_l, '-vn', '-map_metadata', '0',
				'-codec:a', 'libmp3lame', '-b:a', '320k', dst_l], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
			ok = r.returncode == 0 and os.path.isfile(dst_l) and os.path.getsize(dst_l) > 0
		except Exception:
			ok = False
		if ok:
			done += 1
		else:
			failed += 1
			try:
				if os.path.isfile(dst_l): os.remove(dst_l)
			except Exception:
				pass
	progress.close()
	dialog.ok(TITLE, 'Converted: %d\nFailed: %d' % (done, failed))


def set_all_tracks(value):
	addon = xbmcaddon.Addon()
	for setting_id, _file, _label in BUILTIN_TRACKS:
		addon.setSettingBool(setting_id, value)
	notify('All built-in tracks are %s' % ('on' if value else 'off'))


def tracks_on():
	set_all_tracks(True)


def tracks_off():
	set_all_tracks(False)


if __name__ == '__main__':
	action = sys.argv[1] if len(sys.argv) > 1 else 'add'
	{'add': add, 'show': show, 'remove': remove, 'clear': clear, 'convert': convert, 'tracks_on': tracks_on, 'tracks_off': tracks_off}.get(action, add)()
