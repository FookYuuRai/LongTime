# -*- coding: utf-8 -*-
"""Write-through from Nightshift's watched status to WatchVault.

WatchVault is optional. When it is not installed the helper returns None and every call here does nothing, so Nightshift
behaves exactly as before. Nightshift stays the screen source: a mark is still written to Nightshift's own store first,
then mirrored to WatchVault so other add-ons and sync can see it.

Also mirrors in-progress resume (runtime/remaining) and can read resume back before playback.
"""
import threading
import time

from modules import watchvault_helper as wvh

SOURCE = 'plugin.video.nightshift'


def _clean(value):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _season_num(value):
    """Season number including 0 (specials); None when not a number."""
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def mirror_episodes(action, tmdb_id, tvdb_id, pairs, title='', year=None):
    """Mirror many episode marks (a season or a whole show). pairs is a list of (season, episode). Notifications are
    suppressed per episode so a season does not fire one notification each. Returns how many were mirrored."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return 0
    done = 0
    for season, episode in pairs:
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            continue
        try:
            res = wvh.mark(title=title or None, year=_clean(year), season=s, episode=e, tvdb_id=_clean(tvdb_id),
                           tmdb_id=_clean(tmdb_id), watched=(action == 'mark_as_watched'), source=SOURCE, notify=False)
            if res and res.get('ok'):
                done += 1
        except Exception:
            pass
    return done


_IDX_LOCK = threading.Lock()
_IDX = {'checked': 0.0, 'seq': None, 'tvdb': {}, 'tmdb': {}, 'last_tvdb': {}, 'last_tmdb': {},
        'tv2tm': {}, 'tm2tv': {}}


def _ts(value):
    """WatchVault time (2026-11-12T07:26:27Z) as the 'YYYY-MM-DD HH:MM:SS' text the Recently Watched lists sort on."""
    return str(value or '').replace('T', ' ').rstrip('Z')[:19]


def _watched_index():
    """Watched data from one bulk read of WatchVault: (season, episode) pairs, last watched time and the TVDB<->TMDb
    pair of every show. Re-checked at most every 2 s, and re-read only when WatchVault's change counter has moved."""
    with _IDX_LOCK:
        now = time.time()
        if now - _IDX['checked'] < 2.0:
            return _IDX
        seq = wvh.last_seq()
        _IDX['checked'] = now
        if seq is not None and seq == _IDX['seq']:
            return _IDX
        by_tvdb, by_tmdb, last_tvdb, last_tmdb, tv2tm, tm2tv = {}, {}, {}, {}, {}, {}
        for r in wvh.watched_episode_rows() or []:
            try:
                pair = (int(r.get('season')), int(r.get('episode')))
            except (TypeError, ValueError):
                continue
            tvdb, tmdb = _clean(r.get('show_tvdb_id')), _clean(r.get('show_tmdb_id'))
            ts = _ts(r.get('last_watched'))
            if tvdb:
                by_tvdb.setdefault(tvdb, set()).add(pair)
                last_tvdb[tvdb] = max(last_tvdb.get(tvdb, ''), ts)
            if tmdb:
                by_tmdb.setdefault(tmdb, set()).add(pair)
                last_tmdb[tmdb] = max(last_tmdb.get(tmdb, ''), ts)
            if tvdb and tmdb:
                tv2tm[tvdb] = tmdb
                tm2tv[tmdb] = tvdb
        _IDX.update(seq=seq, tvdb=by_tvdb, tmdb=by_tmdb, last_tvdb=last_tvdb, last_tmdb=last_tmdb,
                    tv2tm=tv2tm, tm2tv=tm2tv)
        return _IDX


def _split_key(media_key):
    key = str(media_key or '')
    if key.startswith('tvdb'):
        return 'tvdb', _clean(key[4:])
    return 'tmdb', _clean(key)


def episodes_watched_for(media_key):
    """(season, episode) pairs WatchVault holds as watched for a show. media_key is 'tvdb<id>' or a TMDb id."""
    try:
        idx = _watched_index()
        kind, ident = _split_key(media_key)
        return sorted(idx[kind].get(ident, ())) if ident else []
    except Exception:
        return []


def last_watched_for(media_key):
    """The newest watch time WatchVault holds for a show ('' when none)."""
    try:
        idx = _watched_index()
        kind, ident = _split_key(media_key)
        return idx['last_' + kind].get(ident, '') if ident else ''
    except Exception:
        return ''


def tmdb_for_tvdb(tvdb_id):
    """The TMDb id WatchVault stores for a TVDB show id, or None."""
    try:
        return _watched_index()['tv2tm'].get(_clean(tvdb_id))
    except Exception:
        return None


def tvdb_for_tmdb(tmdb_id):
    """The TVDB show id WatchVault stores for a TMDb show id, or None."""
    try:
        return _watched_index()['tm2tv'].get(_clean(tmdb_id))
    except Exception:
        return None


def movie_rows():
    """WatchVault's watched movies keyed by TMDb id text, in the Recently Watched row shape."""
    out = {}
    try:
        rows = wvh.watched_movie_rows() or []
    except Exception:
        return out
    for r in rows:
        tmdb = _clean(r.get('tmdb_id'))
        if tmdb:
            out[str(tmdb)] = {'media_id': str(tmdb), 'title': r.get('title') or '',
                              'last_played': _ts(r.get('last_watched'))}
    return out


def next_rows(nextep_content):
    """Latest WatchVault watch per show, in the Next Episodes row shape. nextep_content 0 = furthest episode,
    otherwise the most recently watched. One row per show."""
    try:
        rows = wvh.watched_episode_rows() or []
    except Exception:
        return []
    best = {}
    for r in rows:
        tmdb = _clean(r.get('show_tmdb_id'))
        try:
            s, e = int(r.get('season')), int(r.get('episode'))
        except (TypeError, ValueError):
            continue
        if not tmdb:
            continue
        ts = _ts(r.get('last_watched'))
        rank = (s, e) if nextep_content == 0 else ts
        cur = best.get(tmdb)
        if cur is None or rank > cur[0]:
            best[tmdb] = (rank, {'media_ids': {'tmdb': tmdb}, 'season': s, 'episode': e,
                                 'title': r.get('show_title') or '', 'last_played': ts})
    return [v[1] for v in best.values()]


def movie_watched(media_id):
    """True when WatchVault holds this movie (TMDb id) as watched."""
    tmdb = _clean(media_id)
    if not tmdb:
        return False
    try:
        return bool(wvh.is_watched(tmdb_id=tmdb))
    except Exception:
        return False


def shows_watched_keys():
    """Media keys of shows WatchVault holds as watched: 'tvdb<id>' when it has one, else the TMDb id."""
    keys = []
    try:
        rows = wvh.watched_show_ids() or []
    except Exception:
        return keys
    for row in rows:
        tvdb = _clean(row.get('tvdb_id'))
        tmdb = _clean(row.get('tmdb_id'))
        if tvdb:
            keys.append('tvdb%d' % tvdb)
        elif tmdb:
            keys.append(str(tmdb))
    return keys


def mirror_episode(action, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Mirror one episode mark. action is 'mark_as_watched' or 'mark_as_unwatched'."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return None
    try:
        return wvh.mark(title=title or None, year=_clean(year), season=_clean(season) if _clean(season) is not None else 0,
                        episode=_clean(episode), tvdb_id=_clean(tvdb_id), tmdb_id=_clean(tmdb_id),
                        watched=(action == 'mark_as_watched'), source=SOURCE)
    except Exception:
        return None


def mirror_movie(action, tmdb_id, title='', year=None):
    """Mirror one movie mark."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return None
    try:
        return wvh.mark(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id),
                        watched=(action == 'mark_as_watched'), source=SOURCE)
    except Exception:
        return None


def mirror_progress(media_type, tmdb_id, tvdb_id, season, episode, title, year,
                    curr_time, total_time):
    """Write resume progress into WatchVault (runtime + remaining seconds)."""
    try:
        total = float(total_time or 0)
        curr = float(curr_time or 0)
    except (TypeError, ValueError):
        return None
    if total <= 0 or curr < 0:
        return None
    if curr > total:
        curr = total
    remaining = max(0, int(round(total - curr)))
    runtime = int(round(total))
    kw = dict(
        title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id), tvdb_id=_clean(tvdb_id),
        runtime=runtime, remaining=remaining, source=SOURCE, notify=False,
    )
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        return wvh.save_progress(**kw)
    except Exception:
        return None


def resume_percent(media_type, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Resume percent (0-100) from WatchVault, or None if no usable progress."""
    kw = dict(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id), tvdb_id=_clean(tvdb_id))
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        data = wvh.get_resume(**kw)
    except Exception:
        return None
    if not data or data.get('watched'):
        return None
    runtime, remaining, position = data.get('runtime'), data.get('remaining'), data.get('position')
    try:
        if position is not None and runtime and float(runtime) > 0:
            pct = round(float(position) / float(runtime) * 100.0, 1)
        elif remaining is not None and runtime and float(runtime) > 0:
            pct = round((float(runtime) - float(remaining)) / float(runtime) * 100.0, 1)
        else:
            return None
    except (TypeError, ValueError, ZeroDivisionError):
        return None
    if pct < 1.0 or pct >= 95.0:
        return None
    return pct


def clear_progress(media_type, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Clear WatchVault remaining (seek) for this title."""
    kw = dict(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id),
              tvdb_id=_clean(tvdb_id), source=SOURCE, notify=False)
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        return wvh.clear_progress(**kw)
    except Exception:
        return None
