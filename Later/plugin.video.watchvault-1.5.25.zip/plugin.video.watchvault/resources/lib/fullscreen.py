# -*- coding: utf-8 -*-
import time

import xbmc
import xbmcaddon
import xbmcgui


class FullscreenText(xbmcgui.WindowXML):
    """Full-screen text window shipped with the add-on."""

    def onInit(self):
        self.getControl(90).setLabel(self._heading)
        self.getControl(100).setText(self._body)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.close()

    def onClick(self, controlId):
        if controlId == 200:
            self.close()


def modal_open():
    """True while Kodi has a modal dialog (e.g. add-on settings) on screen."""
    return xbmcgui.getCurrentWindowDialogId() != 9999


def show_fullscreen_text(heading, body):
    xbmc.log('[WatchVault diag] showing fullscreen text', xbmc.LOGWARNING)
    try:
        path = xbmcaddon.Addon().getAddonInfo('path')
        win = FullscreenText('watchvault_fullscreen.xml', path, 'Default', '1080i')
    except Exception as e:
        xbmc.log('[WatchVault diag] full-screen window unavailable, using dialog: %s' % e, xbmc.LOGWARNING)
        xbmcgui.Dialog().textviewer(heading, body)
        return
    win._heading = heading
    win._body = body
    try:
        win.doModal()
    finally:
        del win
