# -*- coding: utf-8 -*-
import json
import os
import sys
import time
import urllib.parse as up

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
sys.path.insert(0, os.path.join(ADDON.getAddonInfo('path'), 'resources', 'lib'))
import watchvault as wv  # noqa: E402
import fullscreen  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
PARAMS = dict(up.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ICON = os.path.join(ADDON.getAddonInfo('path'), 'icon.png')
dialog = xbmcgui.Dialog()
NAME = ADDON.getAddonInfo('name') or 'WatchVault'
xbmc.log('[WatchVault diag] invoked argv=%r' % (sys.argv,), xbmc.LOGWARNING)

_MARK_FIELDS = ('title', 'year', 'season', 'episode', 'tvdb_id', 'imdb_id', 'tmdb_id',
                'anilist_id', 'mal_id', 'source', 'played_at', 'episode_title', 'aired',
                'episode_tvdb_id', 'episode_imdb_id', 'episode_tmdb_id', 'episode_anilist_id',
                'episode_mal_id', 'runtime', 'remaining')
_ANNOUNCE_FIELDS = ('title', 'year', 'season', 'episode', 'tvdb_id', 'imdb_id', 'tmdb_id',
                    'anilist_id', 'mal_id', 'source', 'episode_title', 'aired',
                    'episode_tvdb_id', 'episode_imdb_id', 'episode_tmdb_id',
                    'episode_anilist_id', 'episode_mal_id')


def L(msg_id):
    return ADDON.getLocalizedString(msg_id)


def F(msg_id, *args):
    return L(msg_id) % args


def url(**kw):
    return BASE + '?' + up.urlencode(kw)


def tmp(name):
    return os.path.join(xbmcvfs.translatePath('special://temp/'), name)


def refresh():
    xbmc.executebuiltin('Container.Refresh')


def add(label, target, folder=True, info=None, menu=None, plot=None, playcount=None, mediatype=None):
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': ICON, 'thumb': ICON})
    tag = li.getVideoInfoTag()
    if mediatype:
        tag.setMediaType(mediatype)
    tag.setTitle(label)
    if plot:
        tag.setPlot(plot)
    if playcount is not None:
        tag.setPlaycount(playcount)
    if menu:
        li.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def _safe(err):
    text = str(err)
    key = ADDON.getSettingString('tvdb_key').strip()
    if key:
        text = text.replace(key, '')
    return text[:400]



def _id_source_plot(media, media_id, base_plot=''):
    try:
        src = wv.id_sources_for(media, media_id)
    except Exception:
        src = {}
    if not src:
        return base_plot
    parts = []
    for field in ('tvdb_id', 'tmdb_id', 'imdb_id', 'anilist_id', 'mal_id'):
        info = src.get(field)
        if info:
            parts.append('%s=%s (%s)' % (field, info.get('value'), info.get('source')))
    if not parts:
        return base_plot
    line = 'IDs: ' + ', '.join(parts)
    return (base_plot + '\n' + line) if base_plot else line

# ------------------------------------------------------------------ listings
def root():
    c = wv.counts()
    add(F(30050, c['shows'], c['episodes']), url(action='shows'))
    add(F(30051, c['movies']), url(action='movies'))
    add(F(30052, len(wv.get_sources())), url(action='sources'))
    add(L(30053), url(action='add_source'), folder=False)
    add(L(30059), url(action='complete_tvdb', ask=1), folder=False)
    add(L(30134), url(action='db_count'), folder=False)
    add(L(30131), url(action='purge_all'), folder=False)
    add(L(30153), url(action='update_anime'), folder=False)
    add(L(30173), url(action='run_sync_fill'), folder=False)
    add(L(30185), url(action='run_provider_sync'), folder=False)
    add(L(30174), url(action='fill_stats'), folder=False)
    add(L(30054), url(action='export_json'), folder=False)
    add(L(30055), url(action='import_json'), folder=False)
    add(L(30056), url(action='export_db'), folder=False)
    add(L(30057), url(action='import_db'), folder=False)
    add(L(30058), url(action='settings'), folder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def shows():
    with wv.db() as con:
        rows = list(con.execute(
            'SELECT s.*, (SELECT COUNT(*) FROM episodes e WHERE e.show_id=s.id AND e.watched=1) AS w,'
            ' (SELECT COUNT(*) FROM episodes e WHERE e.show_id=s.id) AS n FROM shows s'))
    rows.sort(key=lambda r: (wv._sort_title(r['title']), r['year'] or 0))
    for r in rows:
        label = r['title'] + (' (%d)' % r['year'] if r['year'] else '')
        plot = _id_source_plot('show', r['id'], _with_progress(F(30070, r['tvdb_id'] or L(30071), r['w'], r['n']), r))
        menu = [(L(30072), 'RunPlugin(%s)' % url(action='remove_show', id=r['id'])),
                (L(30073), 'RunPlugin(%s)' % url(action='catalog', id=r['id'])),
                (L(30074), 'RunPlugin(%s)' % url(action='complete_tvdb', show_id=r['id']))]
        add(label, url(action='seasons', id=r['id']), plot=plot, menu=menu, mediatype='tvshow')
    xbmcplugin.setContent(HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(HANDLE)


def seasons():
    sid = int(PARAMS['id'])
    with wv.db() as con:
        rows = list(con.execute(
            'SELECT season, COUNT(*) n, SUM(watched) w FROM episodes WHERE show_id=? GROUP BY season ORDER BY season', (sid,)))
    for r in rows:
        label = L(30075) if r['season'] == 0 else F(30076, r['season'])
        add(F(30077, label, r['w'] or 0, r['n']), url(action='episodes', id=sid, season=r['season']),
            mediatype='season', playcount=1 if r['w'] == r['n'] else 0)
    xbmcplugin.setContent(HANDLE, 'seasons')
    xbmcplugin.endOfDirectory(HANDLE)


def _clock(seconds):
    if seconds is None or seconds == '':
        return None
    try:
        seconds = int(seconds)
    except (TypeError, ValueError):
        return None
    hours, rem = divmod(max(0, seconds), 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return '%d:%02d:%02d' % (hours, minutes, secs)
    return '%d:%02d' % (minutes, secs)


def _id_line(row):
    names = ('tvdb_id', 'imdb_id', 'tmdb_id', 'anilist_id', 'mal_id')
    vals = []
    any_set = False
    for name in names:
        val = row[name] if name in row.keys() and row[name] else None
        if val:
            any_set = True
        vals.append(val or '-')
    if not any_set:
        return ''
    return F(30142, *vals)


def _with_progress(plot, row):
    parts = [plot] if plot else []
    extra = _id_line(row)
    if extra:
        parts.append(extra)
    runtime = row['runtime'] if 'runtime' in row.keys() else None
    remaining = row['remaining'] if 'remaining' in row.keys() else None
    clock = _clock(runtime)
    left = _clock(remaining)
    if clock:
        parts.append(F(30140, clock))
    if remaining is not None and left is not None:
        parts.append(F(30141, left))
    return '\n'.join(p for p in parts if p)


def episodes():
    sid, season = int(PARAMS['id']), int(PARAMS['season'])
    with wv.db() as con:
        rows = list(con.execute('SELECT * FROM episodes WHERE show_id=? AND season=? ORDER BY episode', (sid, season)))
    for r in rows:
        label = 'S%02dE%02d' % (r['season'], r['episode']) + (' - %s' % r['title'] if r['title'] else '')
        plot = (F(30078, r['aired']) if r['aired'] else '') + (F(30079, r['last_watched']) if r['last_watched'] else '')
        plot = _with_progress(plot, r)
        answer = L(30144) if r['is_movie'] else L(30145)
        plot = (plot + '\n' if plot else '') + F(30143, answer)
        tgt = url(action='toggle_ep', id=sid, season=r['season'], episode=r['episode'], to=0 if r['watched'] else 1)
        add(label, tgt, folder=False, plot=plot,
            playcount=r['play_count'] if r['watched'] else 0, mediatype='episode')
    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE)


def movies():
    with wv.db() as con:
        rows = list(con.execute('SELECT * FROM movies'))
    rows.sort(key=lambda r: (wv._sort_title(r['title']), r['year'] or 0))
    for r in rows:
        label = r['title'] + (' (%d)' % r['year'] if r['year'] else '')
        menu = [(L(30072), 'RunPlugin(%s)' % url(action='remove_movie', id=r['id']))]
        add(label, url(action='toggle_movie', id=r['id'], to=0 if r['watched'] else 1), folder=False,
            plot=_id_source_plot('movie', r['id'], _with_progress(F(30084, r['tvdb_id'] or L(30071)), r)),
            playcount=r['play_count'] if r['watched'] else 0,
            menu=menu, mediatype='movie')
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)




def _episode_order_name():
    order = ('official', 'default', 'absolute', 'dvd', 'alternate')
    try:
        idx = int(ADDON.getSettingInt('episode_order'))
        if 0 <= idx < len(order):
            return order[idx]
    except Exception:
        pass
    val = (ADDON.getSettingString('episode_order') or 'official').strip().lower()
    return val if val in order else 'official'

def manage_sources():
    """Select-dialog manager so settings 'Manage video add-ons' works without a Videos window."""
    while True:
        rows = list(wv.get_sources())
        if not rows:
            choice = dialog.yesno(NAME, L(30300), yeslabel=L(30053), nolabel=L(30301))
            if choice:
                add_source()
                continue
            return
        labels = []
        for s in rows:
            state = L(30082) if s.get('enabled') else L(30083)
            labels.append(F(30081, s.get('name') or s.get('addon_id'), state))
        labels.append(L(30053))  # Add…
        labels.append(L(30301))  # Done
        idx = dialog.select(L(30021), labels)
        if idx is None or idx < 0:
            return
        if idx == len(rows):  # add
            add_source()
            continue
        if idx == len(rows) + 1:  # done
            return
        src = rows[idx]
        aid = src['addon_id']
        actions = [L(30302), L(30080)]  # Toggle enable, Remove
        if src.get('enabled'):
            actions[0] = L(30303)  # Disable
        else:
            actions[0] = L(30304)  # Enable
        act = dialog.select(src.get('name') or aid, actions)
        if act == 0:
            try:
                wv.toggle_source(aid)
                dialog.notification(NAME, L(30305), ICON, 2000, False)
            except Exception as e:
                dialog.notification(NAME, _safe(e), ICON, 3000, False)
        elif act == 1:
            if dialog.yesno(NAME, F(30306, src.get('name') or aid)):
                wv.remove_source(aid)
                dialog.notification(NAME, L(30307), ICON, 2000, False)

def sources():
    for s in wv.get_sources():
        state = L(30082) if s['enabled'] else L(30083)
        label = F(30081, s['name'], state)
        menu = [(L(30080), 'RunPlugin(%s)' % url(action='remove_source', id=s['addon_id']))]
        add(label, url(action='toggle_source', id=s['addon_id']), folder=False, plot=s['addon_id'], menu=menu)
    add(L(30053), url(action='add_source'), folder=False)
    xbmcplugin.endOfDirectory(HANDLE)


# ------------------------------------------------------------------- actions
def add_source():
    req = {'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddons',
           'params': {'type': 'xbmc.addon.video', 'content': 'video', 'enabled': True,
                      'properties': ['name']}}
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except ValueError:
        res = {}
    found = (res.get('result') or {}).get('addons') or []
    have = {s['addon_id'] for s in wv.get_sources()}
    found = [a for a in found if a.get('addonid') not in have and a.get('addonid') != ADDON.getAddonInfo('id')]
    if not found:
        dialog.ok(NAME, L(30090))
        return
    found.sort(key=lambda a: (a.get('name') or '').lower())
    picked = dialog.multiselect(L(30091), [F(30092, a.get('name') or a['addonid'], a['addonid']) for a in found])
    for i in picked or []:
        wv.add_source(found[i]['addonid'], found[i].get('name'))
    if picked:
        dialog.notification(NAME, F(30093, len(picked)), ICON, 3000, False)
    refresh()


def export_file(kind):
    folder = dialog.browseSingle(3, F(30094, kind.upper()), 'files', '', False, False, '')
    if not folder:
        return
    name = 'watchvault-%s.%s' % (time.strftime('%Y%m%d-%H%M%S'), 'json' if kind == 'json' else 'db')
    t = tmp(name)
    try:
        if kind == 'json':
            wv.export_json(t)
        else:
            wv.export_db(t)
        dest = folder.rstrip('/\\') + '/' + name
        if xbmcvfs.copy(t, dest):
            dialog.ok(NAME, F(30095, dest))
        else:
            dialog.ok(NAME, L(30096))
    except Exception as e:
        dialog.ok(NAME, F(30097, _safe(e)))
    finally:
        if xbmcvfs.exists(t):
            xbmcvfs.delete(t)


def import_file(kind):
    mask = '.json' if kind == 'json' else '.db'
    src = dialog.browseSingle(1, F(30098, kind.upper()), 'files', mask, False, False, '')
    if not src:
        return
    mode = dialog.select(L(30099), [L(30100), L(30101)])
    if mode < 0:
        return
    t = tmp('watchvault-import' + mask)
    try:
        if not xbmcvfs.copy(src, t):
            dialog.ok(NAME, L(30102))
            return
        if mode == 1:
            wv.export_db(tmp('watchvault-before-import.db'))
            xbmcvfs.copy(tmp('watchvault-before-import.db'),
                         os.path.join(wv.data_dir(), 'before-import-%s.db' % time.strftime('%Y%m%d-%H%M%S')))
        res = wv.import_json(t, replace=mode == 1) if kind == 'json' else wv.import_db(t, replace=mode == 1)
        dialog.ok(NAME, F(30103, res['episodes'], res['movies']))
    except Exception as e:
        dialog.ok(NAME, F(30104, _safe(e)))
    finally:
        if xbmcvfs.exists(t):
            xbmcvfs.delete(t)
    refresh()


def catalog():
    key = ADDON.getSettingString('tvdb_key').strip()
    if not key:
        dialog.ok(NAME, L(30105))
        return
    import tvdb_catalog
    try:
        n = tvdb_catalog.fill_show(key, int(PARAMS['id']),
                                   season_type=_episode_order_name(),
                                   original_names=ADDON.getSettingBool('original_names'))
        dialog.notification(NAME, F(30106, n), ICON, 3000, False)
    except Exception as e:
        dialog.ok(NAME, F(30107, _safe(e)))
    refresh()


def complete_tvdb():
    """Text field for a TVDB series id. Entered and confirmed: purge that
    show's saved episode entries, then mark the full TVDB list watched."""
    show_id = PARAMS.get('show_id')
    entered = (PARAMS.get('tvdb_id') or '').strip()
    if not entered and not PARAMS.get('ask') and not show_id:
        entered = ADDON.getSettingString('manual_tvdb_id').strip()
    if not entered or PARAMS.get('ask') or show_id:
        default = entered
        if show_id and not default:
            try:
                with wv.db() as con:
                    row = con.execute('SELECT tvdb_id FROM shows WHERE id=?', (int(show_id),)).fetchone()
                if row and row['tvdb_id']:
                    default = str(row['tvdb_id'])
            except (TypeError, ValueError):
                default = ''
        kind = getattr(xbmcgui, 'INPUT_NUMERIC', 1)
        entered = dialog.input(L(30060), defaultt=default or '', type=kind)
        entered = (entered or '').strip()
    if not entered:
        return
    if not entered.isdigit() or int(entered) <= 0:
        dialog.ok(NAME, L(30061))
        return
    if not ADDON.getSettingString('tvdb_key').strip():
        dialog.ok(NAME, L(30062))
        return
    if not dialog.yesno(NAME, F(30063, entered)):
        return
    import tvdb_catalog
    try:
        sid = int(show_id) if show_id else None
        res = tvdb_catalog.purge_and_complete(ADDON.getSettingString('tvdb_key').strip(), int(entered), sid)
    except Exception as e:
        dialog.ok(NAME, F(30064, _safe(e)))
        return
    if not res.get('ok'):
        if res.get('error') == 'no episodes':
            dialog.ok(NAME, L(30065))
        else:
            dialog.ok(NAME, F(30064, res.get('error') or ''))
        return
    if ADDON.getSettingString('manual_tvdb_id').strip() == entered:
        ADDON.setSettingString('manual_tvdb_id', '')
    dialog.notification(NAME, F(30066, res.get('title') or entered, res.get('episodes')), ICON, 4000, False)
    refresh()


def _size(n):
    n = int(n or 0)
    if n < 1024:
        return '%s B' % n
    if n < 1024 * 1024:
        return '%.1f KB' % (n / 1024.0)
    return '%.2f MB' % (n / (1024.0 * 1024.0))




def db_count():
    info = wv.db_info()
    anime = {}
    try:
        import anime_data
        anime = anime_data.dataset_info()
    except Exception:
        anime = {}
    watch_bytes = int(info.get('bytes') or 0)
    anime_bytes = int(anime.get('anime_total_bytes') or 0)
    lines = [
        'Watch history DB',
        '  shows: %s' % info.get('shows', 0),
        '  episodes (all rows): %s' % info.get('episodes', 0),
        '  watched episodes: %s' % info.get('watched_episodes', 0),
        '  movies: %s' % info.get('movies', 0),
        '  size: %s' % _size(watch_bytes),
        '',
        'Anime ID maps (Offline + Kometa)',
        '  offline entries: %s' % anime.get('offline_entries', 0),
        '  kometa entries: %s' % anime.get('kometa_entries', 0),
        '  offline file: %s' % _size(anime.get('offline_file_bytes') or 0),
        '  kometa file: %s' % _size(anime.get('kometa_file_bytes') or 0),
        '  index.db: %s' % _size(anime.get('index_bytes') or 0),
        '  anime maps total: %s' % _size(anime_bytes),
        '',
        'Combined on disk: %s' % _size(watch_bytes + anime_bytes),
    ]
    text = '\n'.join(lines)
    heading = L(30134)
    if fullscreen.modal_open() and xbmc.getCondVisibility('Window.IsActive(addonsettings) | Window.IsActive(10140)'):
        # Settings is on screen. Close it the same way Back does, so the screen can open right away.
        xbmc.executebuiltin('Action(Back)')
        end_at = time.time() + 5
        while fullscreen.modal_open() and time.time() < end_at:
            xbmc.sleep(200)
    if fullscreen.modal_open():
        # Still blocked by another dialog: leave the text for the service to open once it closes. No notice.
        w = xbmcgui.Window(10000)
        w.setProperty('watchvault.dbcount.heading', heading)
        w.setProperty('watchvault.dbcount.text', text)
        w.setProperty('watchvault.dbcount.pending', '1')
        xbmc.log('[WatchVault diag] database count left for service (dialog still open)', xbmc.LOGWARNING)
        return
    fullscreen.show_fullscreen_text(heading, text)


def purge_all():
    if not dialog.yesno(NAME, L(30130)):
        return
    wv.purge_all()
    dialog.notification(NAME, L(30133), ICON, 3000, False)
    refresh()






def mdblist_login():
    try:
        import provider_sync
        import time as _time
        start = provider_sync.mdblist_device_start()
        if not start.get('ok'):
            dialog.ok(NAME, 'MDBList login failed: %s' % (start.get('error') or start.get('status')))
            return
        user_code = start.get('user_code')
        verify = start.get('verification_uri') or start.get('verification_url') or 'https://mdblist.com/oauth/device'
        xbmc.log('[WatchVault diag] device code popup', xbmc.LOGWARNING)
        dialog.ok(NAME, 'Open %s and enter code:\n\n%s' % (verify, user_code))
        expires = int(start.get('expires_in') or 300)
        interval = max(3, int(start.get('interval') or 5))
        deadline = _time.time() + expires
        device_code = start.get('device_code')
        while _time.time() < deadline:
            if xbmc.Monitor().waitForAbort(interval):
                return
            poll = provider_sync.mdblist_device_poll(device_code)
            if poll.get('ok'):
                dialog.notification(NAME, 'MDBList logged in as %s' % (poll.get('username') or ''), ICON, 4000, False)
                return
        dialog.notification(NAME, 'MDBList login timed out', ICON, 3000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)

def mdblist_test():
    try:
        import provider_sync
        res = provider_sync.mdblist_test_key()
        if res.get('ok'):
            dialog.notification(NAME, 'MDBList OK: %s' % (res.get('username') or res.get('user_id')), ICON, 4000, False)
        else:
            dialog.notification(NAME, 'MDBList failed: %s' % (res.get('error') or res.get('status')), ICON, 4000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)


def trakt_login():
    try:
        import provider_sync
        import time as _time
        start = provider_sync.trakt_device_start()
        if not start.get('ok'):
            dialog.ok(NAME, 'Trakt login failed: %s' % (start.get('error') or start.get('status')))
            return
        user_code = start.get('user_code')
        verify = start.get('verification_url') or 'https://trakt.tv/activate'
        xbmc.log('[WatchVault diag] device code popup', xbmc.LOGWARNING)
        dialog.ok(NAME, 'Open %s and enter code:\n\n%s' % (verify, user_code))
        expires = int(start.get('expires_in') or 600)
        interval = max(3, int(start.get('interval') or 5))
        deadline = _time.time() + expires
        device_code = start.get('device_code')
        while _time.time() < deadline:
            if xbmc.Monitor().waitForAbort(interval):
                return
            poll = provider_sync.trakt_device_poll(device_code)
            if poll.get('ok'):
                dialog.notification(NAME, 'Trakt logged in as %s' % (poll.get('username') or ''), ICON, 4000, False)
                return
            err = poll.get('error') or {}
            if isinstance(err, dict) and err.get('error') in ('access_denied', 'expired_token'):
                dialog.notification(NAME, 'Trakt login cancelled/expired', ICON, 3000, False)
                return
        dialog.notification(NAME, 'Trakt login timed out', ICON, 3000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)


def simkl_login():
    try:
        import provider_sync
        import time as _time
        start = provider_sync.simkl_device_start()
        if not start.get('ok'):
            dialog.ok(NAME, 'Simkl login failed: %s' % (start.get('error') or start.get('status')))
            return
        user_code = start.get('user_code')
        verify = start.get('verification_url') or start.get('verification_uri') or 'https://simkl.com/pin'
        xbmc.log('[WatchVault diag] device code popup', xbmc.LOGWARNING)
        dialog.ok(NAME, 'Open %s and enter code:\n\n%s' % (verify, user_code))
        expires = int(start.get('expires_in') or 900)
        interval = max(3, int(start.get('interval') or 5))
        deadline = _time.time() + expires
        device_code = start.get('device_code')
        while _time.time() < deadline:
            if xbmc.Monitor().waitForAbort(interval):
                return
            poll = provider_sync.simkl_device_poll(device_code)
            if poll.get('ok'):
                dialog.notification(NAME, 'Simkl logged in as %s' % (poll.get('username') or ''), ICON, 4000, False)
                return
            err = poll.get('error') or {}
            if isinstance(err, dict) and err.get('error') in ('access_denied', 'expired_token'):
                dialog.notification(NAME, 'Simkl login cancelled/expired', ICON, 3000, False)
                return
        dialog.notification(NAME, 'Simkl login timed out', ICON, 3000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)


def punchplay_login():
    try:
        import provider_sync
        import time as _time
        start = provider_sync.punchplay_device_start()
        if not start.get('ok'):
            dialog.ok(NAME, 'PunchPlay login failed: %s' % (start.get('error') or start.get('status')))
            return
        user_code = start.get('user_code') or start.get('userCode')
        verify = (start.get('verification_url') or start.get('verification_uri')
                  or start.get('verificationUrl') or 'https://punchplay.tv/activate')
        xbmc.log('[WatchVault diag] device code popup', xbmc.LOGWARNING)
        dialog.ok(NAME, 'Open %s and enter code:\n\n%s' % (verify, user_code))
        expires = int(start.get('expires_in') or start.get('expiresIn') or 900)
        interval = max(3, int(start.get('interval') or 5))
        deadline = _time.time() + expires
        device_code = start.get('device_code') or start.get('deviceCode')
        while _time.time() < deadline:
            if xbmc.Monitor().waitForAbort(interval):
                return
            poll = provider_sync.punchplay_device_poll(device_code)
            if poll.get('ok'):
                dialog.notification(NAME, 'PunchPlay logged in', ICON, 3000, False)
                return
        dialog.notification(NAME, 'PunchPlay login timed out', ICON, 3000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)

def run_provider_sync():
    dialog.notification(NAME, L(30185), ICON, 2000, False)
    try:
        import provider_sync
        res = provider_sync.run_provider_sync(force=True)
        msg = 'mode=%s shows=%s movies=%s' % (
            res.get('mode'), res.get('shows'), res.get('movies'))
        for p in res.get('providers') or []:
            msg += ' | %s:%s' % (p.get('provider'), 'ok' if p.get('ok') else p.get('error') or p.get('status'))
        dialog.notification(NAME, msg[:90], ICON, 5000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)

def run_sync_fill():
    dialog.notification(NAME, L(30175), ICON, 2000, False)
    try:
        local = wv.fill_local_ids(missing_anime=True)
        key = ADDON.getSettingString('tvdb_key').strip()
        limit = ADDON.getSettingInt('sync_fill_batch') or 50
        net = wv.batch_fill_network(api_key=key or None, limit=limit) if key else {'ok': False, 'error': 'no_tvdb_key'}
        msg = 'local %s / network %s' % (local, net)
        dialog.notification(NAME, msg[:80], ICON, 5000, False)
    except Exception as e:
        dialog.notification(NAME, _safe(e), ICON, 4000, False)


def fill_stats():
    stats = wv.get_fill_stats()
    lines = []
    for kind in ('local', 'network'):
        slot = stats.get(kind) or {}
        if not slot:
            lines.append('%s: (none)' % kind)
            continue
        lines.append('%s @ %s — scanned=%s changed=%s filled=%s' % (
            kind, slot.get('ts') or '?', slot.get('scanned'), slot.get('changed'), slot.get('filled')))
        if kind == 'network':
            lines.append('  remote=%s name=%s tmdb=%s misses=%s' % (
                slot.get('remote_hits'), slot.get('name_hits'), slot.get('tmdb_hits'), slot.get('misses')))
    dialog.ok(NAME, '\n'.join(lines) if lines else L(30176))

def update_anime():
    dialog.notification(NAME, L(30156), ICON, 2000, False)
    try:
        import anime_data
        result = anime_data.update(force=True)
    except Exception as e:
        dialog.ok(NAME, 'Anime dataset update failed:\n%s' % _safe(e))
        return
    try:
        wv.fill_local_ids(missing_anime=True)
    except Exception:
        pass
    lines = []
    for name in ('offline', 'kometa'):
        slot = result.get(name) or {}
        if slot.get('skipped'):
            lines.append('%s: skipped (disabled in settings)' % name)
        elif slot.get('unchanged'):
            lines.append('%s: unchanged (already up to date)' % name)
        elif slot.get('ok'):
            lines.append('%s: ok (%s entries)' % (name, slot.get('entries') or '?'))
        else:
            lines.append('%s: FAILED — %s' % (name, slot.get('error') or 'unknown'))
    # Index size is separate from watched history counts
    try:
        import anime_data
        import os
        ip = anime_data.index_path()
        if os.path.exists(ip):
            lines.append('index.db: %s KB' % (os.path.getsize(ip) // 1024))
    except Exception:
        pass
    lines.append('')
    lines.append('Note: Database count (shows/episodes) is watch history, not these anime id maps.')
    dialog.ok(NAME, '\n'.join(lines))


def route():
    a = PARAMS.get('action', '')
    if a == '':
        return root()
    if a == 'shows':
        return shows()
    if a == 'seasons':
        return seasons()
    if a == 'episodes':
        return episodes()
    if a == 'movies':
        return movies()
    if a == 'sources':
        return sources()
    if a == 'manage_sources':
        return manage_sources()
    if a == 'add_source':
        return add_source()
    if a == 'toggle_source':
        s = wv.get_source(PARAMS.get('id'))
        if s:
            wv.set_source_enabled(s['addon_id'], not s['enabled'])
        return refresh()
    if a == 'remove_source':
        if PARAMS.get('id') and dialog.yesno(NAME, F(30108, PARAMS['id'])):
            wv.remove_source(PARAMS['id'])
        return refresh()
    if a in ('export_json', 'export_db'):
        return export_file(a.split('_')[1])
    if a in ('import_json', 'import_db'):
        return import_file(a.split('_')[1])
    if a == 'settings':
        return ADDON.openSettings()
    if a == 'catalog':
        return catalog()
    if a == 'complete_tvdb':
        return complete_tvdb()
    if a == 'db_count':
        return db_count()
    if a == 'purge_all':
        return purge_all()
    if a == 'update_anime':
        return update_anime()
    if a == 'run_sync_fill':
        return run_sync_fill()
    if a == 'run_provider_sync':
        return run_provider_sync()
    if a == 'mdblist_test':
        return mdblist_test()
    if a == 'mdblist_login':
        return mdblist_login()
    if a == 'trakt_login':
        return trakt_login()
    if a == 'simkl_login':
        return simkl_login()
    if a == 'punchplay_login':
        return punchplay_login()
    if a == 'fill_stats':
        return fill_stats()
    if a == 'toggle_ep':
        try:
            sid = int(PARAMS['id'])
        except (KeyError, TypeError, ValueError):
            return refresh()
        with wv.db() as con:
            s = con.execute('SELECT * FROM shows WHERE id=?', (sid,)).fetchone()
        if not s:
            return refresh()
        wv.mark_watched(title=s['title'], year=s['year'], tvdb_id=s['tvdb_id'], season=PARAMS.get('season'),
                        episode=PARAMS.get('episode'), watched=PARAMS.get('to') == '1', source='manual')
        return refresh()
    if a == 'toggle_movie':
        try:
            mid = int(PARAMS['id'])
        except (KeyError, TypeError, ValueError):
            return refresh()
        with wv.db() as con:
            m = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
        if not m:
            return refresh()
        wv.mark_watched(title=m['title'], year=m['year'], tvdb_id=m['tvdb_id'],
                        watched=PARAMS.get('to') == '1', source='manual')
        return refresh()
    if a == 'remove_show':
        if dialog.yesno(NAME, L(30109)):
            try:
                wv.delete_show(int(PARAMS['id']))
            except (KeyError, TypeError, ValueError):
                pass
        return refresh()
    if a == 'remove_movie':
        if dialog.yesno(NAME, L(30110)):
            try:
                wv.delete_movie(int(PARAMS['id']))
            except (KeyError, TypeError, ValueError):
                pass
        return refresh()
    # calls for other add-ons that do not import the module
    if a in ('mark_watched', 'mark_unwatched'):
        kw = {k: PARAMS[k] for k in _MARK_FIELDS if k in PARAMS}
        kw['watched'] = a == 'mark_watched'
        wv.mark_watched(**kw)
        return
    if a == 'announce':
        kw = {k: PARAMS[k] for k in _ANNOUNCE_FIELDS if k in PARAMS}
        wv.announce(**kw)
        return
    if a == 'sync_now':
        wv._notify('changed', {'full': True})
        return


route()
