# -*- coding: utf-8 -*-
"""TVDB v4 client: login, the episode lists, episode orders and show names. Used by apis/tmdb_api, which keeps the
TMDb side (metadata, the show id and the fallback) and re-exports these names, so the callers do not change."""
import re
from modules.kodi_utils import make_session
from caches.meta_cache import meta_cache


TVDB_BASE = 'https://api4.thetvdb.com/v4'

_TVDB_TOKEN = {'token': '', 'at': 0, 'key': ''}

_TVDB_ORDERS = {}

def tvdb_login(api_key, pin=''):
	"""Bearer token for TVDB v4 (cached for this Kodi session, renewed after a day). '' when the key is refused."""
	import time
	now, same = time.time(), _TVDB_TOKEN['key'] == (api_key, pin)
	if _TVDB_TOKEN['token'] and same and now - _TVDB_TOKEN['at'] < 86400: return _TVDB_TOKEN['token']
	# a refused key or a network error is remembered for 5 minutes: every TVDB call must not post to /login again
	if not _TVDB_TOKEN['token'] and same and now - _TVDB_TOKEN['at'] < 300: return ''
	try:
		body = {'apikey': api_key}
		if pin and pin != 'empty_setting': body['pin'] = pin
		response = make_session().post(TVDB_BASE + '/login', json=body, timeout=20.0)
		token = (response.json().get('data') or {}).get('token') or ''
	except Exception: token = ''
	_TVDB_TOKEN.update({'token': token, 'at': time.time(), 'key': (api_key, pin)})
	return token

def tvdb_get(path, **params):
	from modules.settings import tvdb_api_key, tvdb_pin
	key = tvdb_api_key()
	if key in (None, '', 'empty_setting'): return {}
	token = tvdb_login(key, tvdb_pin())
	if not token: return {}
	try:
		response = make_session().get('%s/%s' % (TVDB_BASE, path), params=params, headers={'Authorization': 'Bearer %s' % token, 'Accept': 'application/json'}, timeout=20.0)
		return response.json() if response.status_code == 200 else {}
	except Exception: return {}

def tvdb_test_key():
	"""(ok, text) for the 'Test API Key' button."""
	from modules.settings import tvdb_api_key, tvdb_pin
	key = tvdb_api_key()
	if key in (None, '', 'empty_setting'): return False, 'No TVDB API key set.'
	_TVDB_TOKEN.update({'token': '', 'at': 0})
	return (True, 'TVDB accepted the key.') if tvdb_login(key, tvdb_pin()) else (False, 'TVDB refused the key (check the key and, for a subscriber key, the PIN).')

def tvdb_orders(tvdb_id):
	"""[(type, name)] of the orders TVDB has for this show, aired (official) first."""
	import time
	hit = _TVDB_ORDERS.get(str(tvdb_id))
	if hit and time.time() - hit[0] < 3600: data = hit[1]
	else:
		data = tvdb_get('series/%s/extended' % tvdb_id, meta='episodes', short='true')
		if data: _TVDB_ORDERS[str(tvdb_id)] = (time.time(), data)
	seen, out = set(), []
	for season in ((data or {}).get('data') or {}).get('seasons') or []:
		t = season.get('type') or {}
		if t.get('type') and t['type'] not in seen:
			seen.add(t['type']); out.append((t['type'], t.get('name') or t['type'].title()))
	out.sort(key=lambda o: (o[0] != 'official', o[0]))
	return out

_NON_LATIN = re.compile(r'[\u0370-\u03ff\u0400-\u04ff\u0590-\u06ff\u0e00-\u0e7f\u1100-\u11ff\u3040-\u30ff\u3100-\u312f\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af\uf900-\ufaff]')

def tvdb_series_names(tvdb_id):
	"""{'english', 'native', 'romaji'} for a TVDB series, the way tvdb_clean.py reads them: the English and Japanese translations, and a
	romanised alias (else the English name). Cached 7 days; {} without TVDB."""
	if tvdb_id in (None, '', 'None', '0', 0): return {}
	from caches.meta_cache import meta_cache
	prop = 'tvdb_series_names_%s' % tvdb_id
	data = meta_cache.get_function(prop)
	if data is None:
		english = (tvdb_get('series/%s/translations/eng' % tvdb_id) or {}).get('data') or {}
		native = (tvdb_get('series/%s/translations/jpn' % tvdb_id) or {}).get('data') or {}
		extended = (tvdb_get('series/%s/extended' % tvdb_id, short='true') or {}).get('data') or {}
		eng_name = english.get('name') or extended.get('name') or ''
		native_name = native.get('name') or extended.get('name') or ''
		romaji = eng_name
		for alias in extended.get('aliases') or []:
			name = alias.get('name') or ''
			if not name or not any(c.isalpha() and ord(c) < 128 for c in name): continue
			if any(x in name for x in ('ō', 'ū', 'ā', 'ē', 'ī', 'no T', ' no ')):
				romaji = name; break
			if alias.get('language') in ('eng', 'jpn') and name not in (eng_name, native_name) and name[0].isupper() and ' ' in name:
				romaji = name; break
		data = {'english': eng_name, 'native': native_name, 'romaji': romaji}
		if eng_name or native_name: meta_cache.set_function(prop, data, expiration=168)
	return data

def _tvdb_english_title(episode_id, name):
	"""The English title of a TVDB episode whose own name is not Latin text (Japanese, Russian, ...). Cached 30 days per episode;
	the name itself when TVDB has no English translation. Latin names are returned unchanged without a request."""
	if not _NON_LATIN.search(name or '') or episode_id in (None, '', 0): return name
	from caches.meta_cache import meta_cache
	prop = 'tvdb_eng_title_%s' % episode_id
	cached = meta_cache.get_function(prop)
	if cached is None:
		data = tvdb_get('episodes/%s/translations/eng' % episode_id)
		if not data: return name       # network / key problem: not cached, the name is shown for now
		cached = ((data.get('data') or {}).get('name') or '')
		meta_cache.set_function(prop, cached, expiration=720)
	return cached or name

def _tvdb_english_titles(entries):
	"""Every entry gets 'title_en' (its English title, '' when there is none) and, for a non-Latin name, 'title' becomes the English
	translation when TVDB has one. A few requests at a time, cached per episode."""
	for e in entries: e['title_en'] = '' if _NON_LATIN.search(e.get('title') or '') else (e.get('title') or '')
	todo = [e for e in entries if _NON_LATIN.search(e.get('title') or '') and e.get('id')]
	if not todo: return entries
	from concurrent.futures import ThreadPoolExecutor
	with ThreadPoolExecutor(max_workers=8) as pool:
		for e, title in zip(todo, pool.map(lambda e: _tvdb_english_title(e['id'], e['title']), todo)):
			if title:
				e['title'] = title
				e['title_en'] = '' if _NON_LATIN.search(title) else title
	return entries

def tvdb_order_entries(tvdb_id, season_type):
	"""Entries of one TVDB order, cached for six hours: TVDB is only asked when the cache is empty."""
	from caches.meta_cache import meta_cache
	key = 'tvdb_order_v1_%s_%s' % (tvdb_id, season_type)
	cached = meta_cache.get_function(key)
	if cached is not None: return cached
	entries = _tvdb_order_entries_live(tvdb_id, season_type)
	if entries: meta_cache.set_function(key, entries, expiration=6)
	return entries

def _tvdb_order_entries_live(tvdb_id, season_type):
	"""Entries of one TVDB order, in that order (seasons 1..N, then Specials)."""
	entries, page = [], 0
	while page < 12:
		data = tvdb_get('series/%s/episodes/%s/eng' % (tvdb_id, season_type), page=page)   # the language is part of the path: a lang query is ignored
		eps = ((data or {}).get('data') or {}).get('episodes') or []
		# the plain list keeps each episode's own (original, usually Japanese) name; the /eng list gives the English one
		originals = {x.get('id'): x.get('name') or '' for x in (((tvdb_get('series/%s/episodes/%s' % (tvdb_id, season_type), page=page) or {}).get('data') or {}).get('episodes') or [])}
		for e in eps:
			entries.append({'id': e.get('id'), 'title': e.get('name') or '', 'original': originals.get(e.get('id')) or e.get('name') or '', 'aired': e.get('aired') or '', 'season': int(e.get('seasonNumber') or 0), 'number': int(e.get('number') or 0),
							'absolute': e.get('absoluteNumber'), 'thumb': _tvdb_full(e.get('image')), 'tvdb_image': _tvdb_full(e.get('image')), 'plot': e.get('overview') or '', 'runtime': e.get('runtime'),
							'before_season': e.get('airsBeforeSeason'), 'before_episode': e.get('airsBeforeEpisode'), 'after_season': e.get('airsAfterSeason')})
		if not ((data or {}).get('links') or {}).get('next'): break
		page += 1
	entries = _tvdb_english_titles(entries)
	if season_type == 'absolute':
		entries.sort(key=lambda e: (e['season'] == 0, e['absolute'] or e['number'], e['season']))
	else:
		main = sorted([e for e in entries if e['season'] != 0], key=lambda e: (e['season'], e['number']))
		specials = sorted([e for e in entries if e['season'] == 0], key=lambda e: e['number'])
		# TVDB places a special where it aired: before episode N of season S, or after season S (the Aired Order list on thetvdb.com)
		slots = {}
		for sp in specials:
			pos = len(main)
			try:
				if sp.get('before_episode') and (sp.get('before_season') or sp.get('after_season')):
					season = int(sp.get('before_season') or sp.get('after_season'))
					pos = next((i for i, m in enumerate(main) if m['season'] == season and m['number'] >= int(sp['before_episode'])), None)
					if pos is None: pos = max([i + 1 for i, m in enumerate(main) if m['season'] == season] or [len(main)])
				elif sp.get('after_season') is not None:
					pos = max([i + 1 for i, m in enumerate(main) if m['season'] <= int(sp['after_season'])] or [0])
				elif sp.get('before_season') is not None:
					pos = next((i for i, m in enumerate(main) if m['season'] >= int(sp['before_season'])), len(main))
			except Exception: pos = len(main)
			slots.setdefault(pos, []).append(sp)
		entries = []
		for i, m in enumerate(main):
			entries.extend(slots.get(i, [])); entries.append(m)
		entries.extend(slots.get(len(main), []))
	return entries

def tvdb_all_episodes(tvdb_id):
	"""Every episode TVDB lists for a show in its aired (official) order, specials included. Cached for 6 hours; [] when TVDB has nothing."""
	from caches.meta_cache import meta_cache
	prop = 'tvdb_all_v6_%s' % tvdb_id
	data = meta_cache.get_function(prop)
	if data: return data
	import time
	started = time.time()
	data = tvdb_order_entries(tvdb_id, 'official')
	if data:
		meta_cache.set_function(prop, data, expiration=6)
		try:
			from modules.kodi_utils import logger
			logger('TvdbFirst', 'TVDB episode list fetched (not cached) tvdb=%s: %d episode(s) in %.2fs; cache readback %s' % (tvdb_id, len(data), time.time() - started, 'ok' if meta_cache.get_function(prop) else 'EMPTY'))
		except Exception: pass
	return data or []

def _tvdb_full(path):
	"""A TVDB artwork path as a full URL ('' when there is none)."""
	return _tvdb_image(path) or ''

def _tvdb_image(path):
	if not path: return None
	return path if str(path).startswith('http') else 'https://artworks.thetvdb.com%s' % (path if str(path).startswith('/') else '/' + str(path))

def tvdb_season_data(meta):
	"""TMDb's season_data list with TVDB's seasons: TVDB's episode counts and every season / Specials it has (TMDb's names and posters are kept)."""
	tvdb_id = meta.get('tvdb_id')
	if not tvdb_id or str(tvdb_id) in ('None', '', '0'): return None
	eps = tvdb_all_episodes(tvdb_id)
	if not eps: return None
	counts, first = {}, {}
	for e in eps:
		counts[e['season']] = counts.get(e['season'], 0) + 1
		if e.get('aired') and (e['season'] not in first or e['aired'] < first[e['season']]): first[e['season']] = e['aired']
	tmdb = {i.get('season_number'): dict(i) for i in (meta.get('season_data') or [])}
	out = []
	for number in sorted(counts):
		item = tmdb.get(number) or {'season_number': number, 'name': 'Specials' if number == 0 else 'Season %s' % number, 'overview': '', 'poster_path': None, 'air_date': first.get(number)}
		item['episode_count'] = counts[number]
		if not item.get('air_date'): item['air_date'] = first.get(number)
		out.append(item)
	return out

def tvdb_search_series(query):
	"""TVDb series search by title: [{'tvdb_id', 'name', 'year'}]. Empty when no key or no hit."""
	rows = []
	try:
		for item in (tvdb_get('search', query=query, type='series') or {}).get('data') or []:
			if item.get('tvdb_id') in (None, ''): continue
			rows.append({'tvdb_id': str(item.get('tvdb_id')), 'name': item.get('name') or '', 'year': str(item.get('year') or '')})
	except Exception: pass
	return rows

def tvdb_series_tmdb_id(tvdb_id):
	"""The TMDb id TVDb lists for this series (TVDb remoteIds, source 'TheMovieDB.com'), or ''."""
	try:
		data = (tvdb_get('series/%s/extended' % tvdb_id, short='true') or {}).get('data') or {}
		for rid in data.get('remoteIds') or []:
			if 'themoviedb' in str(rid.get('sourceName') or '').lower() or rid.get('type') == 12:
				return str(rid.get('id') or '')
	except Exception: pass
	return ''
