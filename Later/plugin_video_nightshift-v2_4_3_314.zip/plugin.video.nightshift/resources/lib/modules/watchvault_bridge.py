# -*- coding: utf-8 -*-
"""Write-through from Nightshift's watched status to WatchVault.

WatchVault is optional. When it is not installed the helper returns None and every call here does nothing, so Nightshift
behaves exactly as before. Nightshift stays the screen source: a mark is still written to Nightshift's own store first,
then mirrored to WatchVault so other add-ons and sync can see it.

Also mirrors in-progress resume (runtime/remaining) and can read resume back before playback.
"""
import threading
import time

from modules import watchvault_helper as wvh

SOURCE = 'plugin.video.nightshift'


def _clean(value):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _season_num(value):
    """Season number including 0 (specials); None when not a number."""
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def mirror_episodes(action, tmdb_id, tvdb_id, pairs, title='', year=None):
    """Mirror many episode marks (a season or a whole show). pairs is a list of (season, episode). Notifications are
    suppressed per episode so a season does not fire one notification each. Returns how many were mirrored."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return 0
    done = 0
    for season, episode in pairs:
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            continue
        try:
            res = wvh.mark(title=title or None, year=_clean(year), season=s, episode=e, tvdb_id=_clean(tvdb_id),
                           tmdb_id=_clean(tmdb_id), watched=(action == 'mark_as_watched'), source=SOURCE, notify=False)
            if res and res.get('ok'):
                done += 1
        except Exception:
            pass
    return done


_IDX_LOCK = threading.Lock()
_IDX = {'checked': 0.0, 'seq': None, 'tvdb': {}, 'tmdb': {}, 'last_tvdb': {}, 'last_tmdb': {},
        'tv2tm': {}, 'tm2tv': {}}


def _ts(value):
    """WatchVault time (2026-11-12T07:26:27Z) as the 'YYYY-MM-DD HH:MM:SS' text the Recently Watched lists sort on."""
    return str(value or '').replace('T', ' ').rstrip('Z')[:19]


def _watched_index():
    """Watched data from one bulk read of WatchVault: (season, episode) pairs, last watched time and the TVDB<->TMDb
    pair of every show. Re-checked at most every 2 s, and re-read only when WatchVault's change counter has moved."""
    with _IDX_LOCK:
        now = time.time()
        if now - _IDX['checked'] < 2.0:
            return _IDX
        seq = wvh.last_seq()
        _IDX['checked'] = now
        if seq is not None and seq == _IDX['seq']:
            return _IDX
        by_tvdb, by_tmdb, last_tvdb, last_tmdb, tv2tm, tm2tv = {}, {}, {}, {}, {}, {}
        for r in wvh.watched_episode_rows() or []:
            try:
                pair = (int(r.get('season')), int(r.get('episode')))
            except (TypeError, ValueError):
                continue
            tvdb, tmdb = _clean(r.get('show_tvdb_id')), _clean(r.get('show_tmdb_id'))
            ts = _ts(r.get('last_watched'))
            if tvdb:
                by_tvdb.setdefault(tvdb, set()).add(pair)
                last_tvdb[tvdb] = max(last_tvdb.get(tvdb, ''), ts)
            if tmdb:
                by_tmdb.setdefault(tmdb, set()).add(pair)
                last_tmdb[tmdb] = max(last_tmdb.get(tmdb, ''), ts)
            if tvdb and tmdb:
                tv2tm[tvdb] = tmdb
                tm2tv[tmdb] = tvdb
        _IDX.update(seq=seq, tvdb=by_tvdb, tmdb=by_tmdb, last_tvdb=last_tvdb, last_tmdb=last_tmdb,
                    tv2tm=tv2tm, tm2tv=tm2tv)
        return _IDX


def _split_key(media_key):
    key = str(media_key or '')
    if key.startswith('tvdb'):
        return 'tvdb', _clean(key[4:])
    return 'tmdb', _clean(key)


def episodes_watched_for(media_key):
    """(season, episode) pairs WatchVault holds as watched for a show. media_key is 'tvdb<id>' or a TMDb id. Both ids
    are tried, TVDB first, and the pairs are joined, so a key of either kind finds every watch of the show."""
    try:
        idx = _watched_index()
        kind, ident = _split_key(media_key)
        if not ident:
            return []
        tvdb = ident if kind == 'tvdb' else idx['tm2tv'].get(ident)
        tmdb = ident if kind == 'tmdb' else idx['tv2tm'].get(ident)
        pairs = set()
        if tvdb:
            pairs |= idx['tvdb'].get(tvdb, set())
        if tmdb:
            pairs |= idx['tmdb'].get(tmdb, set())
        return sorted(pairs)
    except Exception:
        return []



def last_watched_for(media_key):
    """The newest watch time WatchVault holds for a show, by either id ('' when none)."""
    try:
        idx = _watched_index()
        kind, ident = _split_key(media_key)
        if not ident:
            return ''
        tvdb = ident if kind == 'tvdb' else idx['tm2tv'].get(ident)
        tmdb = ident if kind == 'tmdb' else idx['tv2tm'].get(ident)
        return max(idx['last_tvdb'].get(tvdb, '') if tvdb else '', idx['last_tmdb'].get(tmdb, '') if tmdb else '')
    except Exception:
        return ''



def tmdb_for_tvdb(tvdb_id):
    """The TMDb id WatchVault stores for a TVDB show id, or None."""
    try:
        return _watched_index()['tv2tm'].get(_clean(tvdb_id))
    except Exception:
        return None


def tvdb_for_tmdb(tmdb_id):
    """The TVDB show id WatchVault stores for a TMDb show id, or None."""
    try:
        return _watched_index()['tm2tv'].get(_clean(tmdb_id))
    except Exception:
        return None


def movie_rows():
    """WatchVault's watched movies keyed by TMDb id text, in the Recently Watched row shape."""
    out = {}
    try:
        rows = wvh.watched_movie_rows() or []
    except Exception:
        return out
    for r in rows:
        tmdb = _clean(r.get('tmdb_id'))
        if tmdb:
            out[str(tmdb)] = {'media_id': str(tmdb), 'title': r.get('title') or '',
                              'last_played': _ts(r.get('last_watched'))}
    return out


def next_rows(nextep_content):
    """Latest WatchVault watch per show, in the Next Episodes row shape. nextep_content 0 = furthest episode,
    otherwise the most recently watched. One row per show."""
    try:
        rows = wvh.watched_episode_rows() or []
    except Exception:
        return []
    best = {}
    for r in rows:
        tmdb = _clean(r.get('show_tmdb_id'))
        try:
            s, e = int(r.get('season')), int(r.get('episode'))
        except (TypeError, ValueError):
            continue
        if not tmdb:
            continue
        ts = _ts(r.get('last_watched'))
        rank = (s, e) if nextep_content == 0 else ts
        cur = best.get(tmdb)
        if cur is None or rank > cur[0]:
            best[tmdb] = (rank, {'media_ids': {'tmdb': tmdb}, 'season': s, 'episode': e,
                                 'title': r.get('show_title') or '', 'last_played': ts})
    return [v[1] for v in best.values()]


def movie_watched(media_id):
    """True when WatchVault holds this movie (TMDb id) as watched."""
    tmdb = _clean(media_id)
    if not tmdb:
        return False
    try:
        return bool(wvh.is_watched(tmdb_id=tmdb))
    except Exception:
        return False


def shows_watched_keys():
    """Media keys of shows WatchVault holds as watched, as TMDb id text: the key every Nightshift list and metadata
    lookup uses. A TVDB key here made TMDb lookups fail and dropped WatchVault-only shows from the TV lists. A show
    without a TMDb id keeps its 'tvdb<id>' key."""
    keys = []
    try:
        rows = wvh.watched_show_ids() or []
    except Exception:
        return keys
    for row in rows:
        tvdb = _clean(row.get('tvdb_id'))
        tmdb = _clean(row.get('tmdb_id'))
        if tmdb:
            keys.append(str(tmdb))
        elif tvdb:
            keys.append('tvdb%d' % tvdb)
    return keys


def mirror_episode(action, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Mirror one episode mark. action is 'mark_as_watched' or 'mark_as_unwatched'."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return None
    try:
        return wvh.mark(title=title or None, year=_clean(year), season=_clean(season) if _clean(season) is not None else 0,
                        episode=_clean(episode), tvdb_id=_clean(tvdb_id), tmdb_id=_clean(tmdb_id),
                        watched=(action == 'mark_as_watched'), source=SOURCE)
    except Exception:
        return None


def mirror_movie(action, tmdb_id, title='', year=None):
    """Mirror one movie mark."""
    if action not in ('mark_as_watched', 'mark_as_unwatched'):
        return None
    try:
        return wvh.mark(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id),
                        watched=(action == 'mark_as_watched'), source=SOURCE)
    except Exception:
        return None


def mirror_progress(media_type, tmdb_id, tvdb_id, season, episode, title, year,
                    curr_time, total_time):
    """Write resume progress into WatchVault (runtime + remaining seconds)."""
    try:
        total = float(total_time or 0)
        curr = float(curr_time or 0)
    except (TypeError, ValueError):
        return None
    if total <= 0 or curr < 0:
        return None
    if curr > total:
        curr = total
    remaining = max(0, int(round(total - curr)))
    runtime = int(round(total))
    kw = dict(
        title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id), tvdb_id=_clean(tvdb_id),
        runtime=runtime, remaining=remaining, source=SOURCE, notify=False,
    )
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        return wvh.save_progress(**kw)
    except Exception:
        return None


def resume_percent(media_type, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Resume percent (0-100) from WatchVault, or None if no usable progress."""
    kw = dict(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id), tvdb_id=_clean(tvdb_id))
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        data = wvh.get_resume(**kw)
    except Exception:
        return None
    if not data or data.get('watched'):
        return None
    runtime, remaining, position = data.get('runtime'), data.get('remaining'), data.get('position')
    try:
        if position is not None and runtime and float(runtime) > 0:
            pct = round(float(position) / float(runtime) * 100.0, 1)
        elif remaining is not None and runtime and float(runtime) > 0:
            pct = round((float(runtime) - float(remaining)) / float(runtime) * 100.0, 1)
        else:
            return None
    except (TypeError, ValueError, ZeroDivisionError):
        return None
    if pct < 1.0 or pct >= 95.0:
        return None
    return pct


def clear_progress(media_type, tmdb_id, tvdb_id, season, episode, title='', year=None):
    """Clear WatchVault remaining (seek) for this title."""
    kw = dict(title=title or None, year=_clean(year), tmdb_id=_clean(tmdb_id),
              tvdb_id=_clean(tvdb_id), source=SOURCE, notify=False)
    if media_type == 'episode':
        s, e = _season_num(season), _clean(episode)
        if s is None or e is None:
            return None
        kw.update(season=s, episode=e)
    try:
        return wvh.clear_progress(**kw)
    except Exception:
        return None


_CACHE = {'checked': 0.0, 'seq': None}
_CACHE_LOCK = threading.Lock()


def refresh_watchvault_cache(force=False):
    """Copy WatchVault's watched and in-progress rows into Nightshift's watchvault_db, in the same tables the MDBList
    cache uses, so every Nightshift screen reads WatchVault exactly as it reads MDBList. Runs when WatchVault's change
    counter has moved (checked at most once a second). If WatchVault cannot be read right now, the copy is kept.
    Returns True when the copy was rewritten."""
    with _CACHE_LOCK:
        now = time.time()
        if not force and now - _CACHE['checked'] < 1.0:
            return False
        _CACHE['checked'] = now
        seq = wvh.last_seq()
        if seq is None:
            return False
        if not force and seq == _CACHE['seq']:
            return False
        snap = wvh.provider_snapshot()
        if not isinstance(snap, dict):
            return False
        from caches.base_cache import connect_database
        dbcon = connect_database('watchvault_db')
        dbcon.execute('CREATE TABLE IF NOT EXISTS watched (db_type text not null, media_id text not null, season integer, '
                      'episode integer, last_played text, title text, unique (db_type, media_id, season, episode))')
        dbcon.execute('CREATE TABLE IF NOT EXISTS progress (db_type text not null, media_id text not null, season integer, '
                      'episode integer, resume_point text, curr_time text, last_played text, resume_id integer, title text, '
                      'unique (db_type, media_id, season, episode))')
        dbcon.execute('BEGIN')
        try:
            dbcon.execute('DELETE FROM watched')
            dbcon.execute('DELETE FROM progress')
            dbcon.executemany('INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?)', snap.get('watched') or [])
            dbcon.executemany('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', snap.get('progress') or [])
            dbcon.execute('COMMIT')
        except Exception:
            dbcon.execute('ROLLBACK')
            raise
        _CACHE['seq'] = seq
        return True


def watched_seq():
    """WatchVault's change counter as last read. Cheap: it is re-read at most every 2 seconds."""
    try:
        return _watched_index().get('seq')
    except Exception:
        return None
