# -*- coding: utf-8 -*-
"""
NZB Indexers browser (Newznab).

Search configured NZB indexers (Tools > Settings > Direct Sources > NZB Indexers)
and act on results: send to TorBox Pro usenet (streams from TorBox Cloud once
downloaded — TorBox Pro required), stream directly from your Usenet provider (NNTP), or save
the .nzb file for an external client (SABnzbd, NZBGet).
"""
import os
import sys
import json
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import unquote
from modules import kodi_utils
from modules.utils import clean_file_name
# logger = kodi_utils.logger

def _age_days(pub_date):
	try:
		published = parsedate_to_datetime(pub_date)
		if published.tzinfo: published = published.astimezone(timezone.utc).replace(tzinfo=None)
		return max((datetime.utcnow() - published).days, 0)
	except: return None

def search_nzb(params):
	from apis.nzb_api import search_all
	handle = int(sys.argv[1])
	key_id = params.get('key_id') or params.get('query') or ''
	search_name = clean_file_name(unquote(key_id))
	try:
		files = search_all(search_name)
		nzb_file_browser(files, handle)
	except: pass
	kodi_utils.set_content(handle, kodi_utils.PREMIUM_FILES_CONTENT)
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.premium', kodi_utils.PREMIUM_FILES_CONTENT)

def nzb_file_browser(files, handle):
	def _builder():
		for count, item in enumerate(files, 1):
			try:
				item_get = item.get
				name = clean_file_name(item_get('name', 'Unknown')).upper()
				link = item_get('link', '')
				size_gb = round(float(item_get('size', 0) or 0) / 1073741824.0, 2)
				indexer = item_get('indexer', 'NZB')
				display = '%02d | [B]NZB[/B] | [B]%.2fGB[/B] | [B]%s[/B] | [I]%s[/I]' % (count, size_gb, indexer, name)
				plot_lines = []
				age = _age_days(item_get('age', ''))
				if age is not None: plot_lines.append('[B]Age:[/B] %s day%s' % (age, '' if age == 1 else 's'))
				if item_get('group'): plot_lines.append('[B]Group:[/B] %s' % item_get('group'))
				if item_get('grabs'): plot_lines.append('[B]Grabs:[/B] %s' % item_get('grabs'))
				plot_lines.append('[B]Indexer:[/B] %s' % indexer)
				action_params = {'mode': 'nzb.nzb_action', 'name': name, 'url': link, 'isFolder': 'false'}
				url = kodi_utils.build_url(action_params)
				cm = [('[B]Send to TorBox Pro[/B]', 'RunPlugin(%s)' % kodi_utils.build_url({'mode': 'nzb.send_to_torbox', 'name': name, 'url': link})),
					('[B]Download NZB File[/B]', 'RunPlugin(%s)' % kodi_utils.build_url({'mode': 'nzb.download_nzb', 'name': name, 'url': link}))]
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				kodi_utils.set_list_item_art(listitem, icon, fanart=fanart)
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot('\n'.join(plot_lines) or ' ')
				yield (url, listitem, False)
			except: pass
	icon = kodi_utils.get_icon('search')
	fanart = kodi_utils.get_addon_fanart()
	kodi_utils.add_items(handle, list(_builder()))

def nzb_action(params):
	"""Click handler for an NZB result - choose what to do with it."""
	from modules.settings import authorized_debrid_check
	from modules.settings import usenet_direct_active
	choices = []
	if usenet_direct_active(): choices.append(('Play Directly from Usenet (NNTP)', 'direct'))
	if authorized_debrid_check('tb'): choices.append(('Send to TorBox Pro (stream from Cloud when ready)', 'torbox'))
	choices.append(('Download NZB File', 'download'))
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'NZB Result', 'narrow_window': 'true'}
	choice = kodi_utils.select_dialog([item[1] for item in choices], **kwargs)
	if choice == 'direct': return play_direct(params)
	if choice == 'torbox': return send_to_torbox(params)
	if choice == 'download': return download_nzb(params)

def play_direct(params):
	"""Stream a browsed NZB result straight from the Usenet provider."""
	from apis import usenet_stream
	name, link = params.get('name', ''), params.get('url', '')
	if not link: return kodi_utils.notification('No NZB link found', 3500)
	kodi_utils.show_busy_dialog()
	try:
		local, reason = usenet_stream.open_stream(link, name or 'video.mkv')
	except Exception as e: local, reason = '', type(e).__name__
	kodi_utils.hide_busy_dialog()
	if reason and 'packed in rar' in reason.lower() and usenet_stream.unpack_ready():
		local, reason = usenet_stream.unpack_local(link, name or 'video.mkv')      # a packed release: unpacked to the local folder, then played from there
		if reason and 'cancel' in reason: return
	if reason: return kodi_utils.ok_dialog(heading='Direct Usenet', text='Cannot play this release:\n%s' % reason)
	if local.startswith(('/', 'special://', 'smb://', 'nfs://')) or ':\\' in local[:3]:
		try:
			import xbmc
			return xbmc.Player().play(local)          # a local file: no builtin (a comma or quote in the name would break its arguments)
		except Exception: pass
	kodi_utils.execute_builtin('PlayMedia(%s)' % local)

def send_to_torbox(params):
	from apis.torbox_api import TorBoxAPI
	name, link = params.get('name', ''), params.get('url', '')
	if not link: return kodi_utils.notification('No NZB link found', 3500)
	kodi_utils.show_busy_dialog()
	try: result = TorBoxAPI().add_nzb(link, name)
	except: result = None
	kodi_utils.hide_busy_dialog()
	if result and result.get('success'):
		detail = (result.get('detail') or 'Sent to TorBox Pro usenet queue').rstrip('.')
		kodi_utils.notification('TorBox: %s' % detail, 5000, kodi_utils.get_icon('torbox'))
	else:
		error = (result or {}).get('detail') or (result or {}).get('error') or 'Send failed. A TorBox Pro account (usenet) is required'
		kodi_utils.ok_dialog(heading='TorBox', text='NZB could not be added:\n%s' % error)

def download_nzb(params):
	from modules.settings import download_directory
	from modules.kodi_utils import make_session
	name, link = params.get('name', ''), params.get('url', '')
	if not link: return kodi_utils.notification('No NZB link found', 3500)
	directory = download_directory('premium')
	if not directory:
		return kodi_utils.ok_dialog(heading='NZB Download', text='Please set a Premium Files download location in Tools > Settings > Downloads first')
	filename = ''.join(c for c in (name or 'download') if c.isalnum() or c in ' ._-').strip() or 'download'
	if not filename.lower().endswith('.nzb'): filename += '.nzb'
	kodi_utils.show_busy_dialog()
	try:
		response = make_session('https://').get(link, timeout=30, allow_redirects=True)
		content = response.content if response.status_code == 200 else None
	except: content = None
	if not content:
		kodi_utils.hide_busy_dialog()
		return kodi_utils.ok_dialog(heading='NZB Download', text='Could not fetch the NZB file from the indexer')
	try:
		import xbmcvfs
		final_path = os.path.join(directory, filename)
		with xbmcvfs.File(final_path, 'w') as f: f.write(bytearray(content))
		kodi_utils.hide_busy_dialog()
		kodi_utils.notification('NZB saved: %s' % filename, 5000)
	except:
		kodi_utils.hide_busy_dialog()
		kodi_utils.ok_dialog(heading='NZB Download', text='Could not write the NZB file to:\n%s' % directory)

_NZB_INDEXER_FIELDS = ('enabled', 'label', 'url', 'key')
_USENET_FIELDS = ('enabled', 'host', 'port', 'ssl', 'user', 'password')

def _swap_slots(prefix, fields, slot, direction, count=25):
	"""Swap every setting of slot with its neighbour (up = slot-1, down = slot+1). Order = slot number."""
	from caches.settings_cache import get_setting, set_setting, refresh_settings_manager_properties
	try: slot = int(slot)
	except Exception: return False
	target = slot - 1 if direction == 'up' else slot + 1
	if slot < 1 or slot > count or target < 1 or target > count: return False
	values = {n: {f: get_setting('nightshift.%s%d.%s' % (prefix, n, f)) for f in fields} for n in (slot, target)}
	for f in fields:
		set_setting('%s%d.%s' % (prefix, slot, f), values[target][f])
		set_setting('%s%d.%s' % (prefix, target, f), values[slot][f])
	try: refresh_settings_manager_properties()
	except Exception: pass
	return True

def move_indexer(params):
	"""Settings > NZB Indexers: move an indexer slot up/down (the whole slot: name, URL, key, on/off)."""
	_swap_slots('nzb', _NZB_INDEXER_FIELDS, params.get('slot', 1), params.get('direction', 'up'))

def move_usenet(params):
	"""Settings > Direct Usenet: move a provider slot up/down. Providers are tried in slot order."""
	_swap_slots('usenet', _USENET_FIELDS, params.get('slot', 1), params.get('direction', 'up'))

def test_usenet(params):
	"""Test a direct Usenet (NNTP) provider login; finds and saves the port and SSL when the port is 0 (auto)."""
	from apis import usenet_stream
	from caches.settings_cache import set_setting
	slot = int(params.get('slot', 1))
	heading = 'Usenet Backup Provider' if slot == 2 else 'Usenet Provider %d' % slot
	server = usenet_stream.slot_server(slot)
	if not server or not server.get('user'):
		return kodi_utils.ok_dialog(heading=heading, text='Enter the server address, username and password first (Tools > Settings > Direct Sources > NZB Indexers > Direct Usenet), and switch the provider on.')
	typed_port = usenet_stream._setting('usenet%d.port' % slot, '0')
	port = int(typed_port) if typed_port.isdigit() and int(typed_port) else None
	kodi_utils.show_busy_dialog()
	try: value, reason = usenet_stream.detect(server['host'], server['user'], server['password'], port=port)
	except Exception as e: value, reason = None, type(e).__name__
	kodi_utils.hide_busy_dialog()
	found = None
	try: found = usenet_stream.parse(value) if value else None
	except: found = None
	if not reason and found:
		set_setting('usenet%d.port' % slot, str(found['port']))
		set_setting('usenet%d.ssl' % slot, 'true' if found['ssl'] else 'false')
		return kodi_utils.ok_dialog(heading=heading, text='[B]%s[/B]\nLogin works (port %s, %s)' % (found['host'], found['port'], 'SSL' if found['ssl'] else 'no SSL'))
	return kodi_utils.ok_dialog(heading=heading, text='Login failed:\n%s' % (reason[:1].upper() + reason[1:] if reason else 'No answer'))

def test_connection(params):
	from apis.nzb_api import NzbIndexerAPI
	slot = int(params.get('slot', 1))
	api = NzbIndexerAPI(slot)
	heading = api.label if api.label else 'NZB Indexer %d' % slot
	if not api.is_configured():
		return kodi_utils.ok_dialog(heading=heading, text='Please enter the URL and API key for this indexer in Tools > Settings > Direct Sources > NZB Indexers')
	kodi_utils.show_busy_dialog()
	result = api.capabilities()
	ok, reason = (api.verify_key() if result and 'error' not in result else (False, ''))
	kodi_utils.hide_busy_dialog()
	if not result or 'error' in result:
		error = (result or {}).get('error', 'No response')
		return kodi_utils.ok_dialog(heading=heading, text='Connection failed:\n%s' % error)
	if not ok:
		return kodi_utils.ok_dialog(heading=heading, text='Indexer reachable, but the API key was rejected:\n%s' % reason)
	server = result.get('server') or {}
	if isinstance(server, dict): server = server.get('@attributes', server)
	title = server.get('title') or (result.get('channel') or {}).get('title') or 'Indexer'
	kodi_utils.ok_dialog(heading=heading, text='[B]%s[/B] connected successfully' % title)
