# -*- coding: utf-8 -*-
"""Per-show Autoplay link (autoplay_db).

When Autoplay (Episodes) - or Autoscrape Next Episode - is on, the FIRST source the user picks for a
show is remembered here: the pack, cloud file/folder or direct folder it came from.  Every later episode of
that show is then looked up in that same pack / cloud folder / folder instead of running a fresh scrape
and auto-picking whatever ranks best.  Nothing is stored until the user has made a first choice, so a new
show (or a fresh Kodi install) always starts with a normal manual pick.

Row per show:  tmdb_id | media_type | title | origin (JSON) | updated (unix time)

origin = {'kind': 'pack' | 'cloud' | 'standard', 'scrape_provider': ..., 'source': ..., 'folder_key': ...,
          'name': ..., 'item': {...full pack row for kind == 'pack'...}}
  pack      -> resolve the next episode inside that pack (magnet / hash)
  cloud     -> same cloud/direct scraper, restricted to the folder the file lived in
  standard  -> the first choice was an ordinary single-file source; keep using the regular Autoplay rules

Clear one show:  Options (episode) -> Clear Autoplay      Clear everything:  Tools -> Maintenance
"""
import json
import time
from caches.base_cache import connect_database, ensure_database_tables

_DB = 'autoplay_db'
_ready = [False]


def _db():
	if not _ready[0]:
		try:
			ensure_database_tables(_DB)
			_ready[0] = True
		except Exception:
			pass
	return connect_database(_DB)


class AutoplayCache:
	def get_row(self, tmdb_id):
		try:
			row = _db().execute('SELECT tmdb_id, media_type, title, origin, updated FROM autoplay WHERE tmdb_id = ?', (str(tmdb_id),)).fetchone()
			if not row: return None
			return {'tmdb_id': row[0], 'media_type': row[1], 'title': row[2], 'origin': json.loads(row[3] or '{}'), 'updated': row[4]}
		except Exception:
			return None

	def get_origin(self, tmdb_id):
		row = self.get_row(tmdb_id)
		return (row or {}).get('origin') or None

	def set_origin(self, tmdb_id, origin, title='', media_type='episode'):
		try:
			_db().execute('INSERT OR REPLACE INTO autoplay (tmdb_id, media_type, title, origin, updated) VALUES (?, ?, ?, ?, ?)',
						(str(tmdb_id), media_type, title or '', json.dumps(origin, default=str), int(time.time())))
			return True
		except Exception:
			return False

	def clear_origin(self, tmdb_id):
		"""Remove one show's saved link. Returns True when a row was removed."""
		try:
			dbcon = _db()
			existed = dbcon.execute('SELECT 1 FROM autoplay WHERE tmdb_id = ?', (str(tmdb_id),)).fetchone() is not None
			dbcon.execute('DELETE FROM autoplay WHERE tmdb_id = ?', (str(tmdb_id),))
			return existed
		except Exception:
			return False

	def count(self):
		try: return _db().execute('SELECT COUNT(*) FROM autoplay').fetchone()[0]
		except Exception: return 0

	def clear_all(self):
		"""Purge every saved link. Returns True on success."""
		try:
			dbcon = _db()
			dbcon.execute('DELETE FROM autoplay')
			try: dbcon.execute('VACUUM')
			except Exception: pass
			return True
		except Exception:
			return False

	def describe(self, tmdb_id):
		"""Short human label for menus: 'Pack: <name>' / 'Cloud: <name>' / 'Standard autoplay' / ''."""
		origin = self.get_origin(tmdb_id)
		if not origin: return ''
		kind, name = origin.get('kind'), (origin.get('name') or '')[:60]
		if kind == 'pack': return 'Pack: %s' % name
		if kind == 'cloud': return '%s: %s' % ((origin.get('scrape_provider') or 'cloud').replace('_', ' ').upper(), name)
		return 'Standard autoplay'


autoplay_cache = AutoplayCache()
