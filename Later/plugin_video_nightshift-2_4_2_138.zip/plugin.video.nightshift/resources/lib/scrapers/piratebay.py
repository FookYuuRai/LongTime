# -*- coding: utf-8 -*-
from apis import piratebay_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, scrape_expiry, scrape_timeout
from modules.settings import piratebay_scrape_active
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'piratebay'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not piratebay_scrape_active():
				source_utils.diag_log('PIRATEBAY', 'SCRAPER DISABLED')
				return source_utils.internal_results(self.scrape_provider, self.sources)

			media_type = info.get('media_type')
			absolute_episode = info.get('absolute_episode')
			if media_type == 'episode' and absolute_episode:
				source_utils.diag_log('PIRATEBAY Init', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					info.get('season'), info.get('episode'), absolute_episode, info.get('ep_name') or ''))

			queries = name_search_queries(info)
			source_utils.diag_log('PIRATEBAY Queries', 'generated=%d queries: %s' % (len(queries), ', '.join(repr(q) for q in queries)))
			files = merge_name_searches(
				piratebay_api.search, queries, scrape_timeout(info), scrape_expiry(info))

			raw_count = len(files or [])
			self.sources = filter_and_build_sources(self.scrape_provider, files, info)
			kept = len(self.sources)
			source_utils.diag_log('PIRATEBAY Match', '%s : %s kept / %s raw' % (info.get('title', ''), kept, raw_count))
			if raw_count and not self.sources:
				source_utils.diag_log('PIRATEBAY Match', 'all raw results dropped by title/episode filter')

		except Exception as e:
			logger('piratebay scraper Exception', str(e))
			source_utils.diag_log('PIRATEBAY', 'ERROR %s' % type(e).__name__)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
