# -*- coding: utf-8 -*-
"""PirateBay through apibay's JSON endpoint:  GET <base>/q.php?q=<query>&cat=0
-> [{"id","name","info_hash","leechers","seeders","num_files","size"(bytes),"username","added","status","category","imdb"}, ...]
No hits is a single placeholder row ("No results returned", all-zero hash), which is dropped here."""
from urllib.parse import quote_plus
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, instance_base_url, normalize_info_hash
from apis import indexer_http

PIRATEBAY_URLS = (
	'https://apibay.org',
)


def piratebay_base_url():
	return instance_base_url('piratebay.url', PIRATEBAY_URLS, 'piratebay.custom_url', 1) or PIRATEBAY_URLS[0]


def piratebay_search_url(query):
	"""Kept for callers that show / test the URL: the first base that would be tried."""
	base = piratebay_base_url().rstrip('/')
	if not base or not query:
		return None
	if 'q.php' in base:
		if '%s' in base:
			return base % quote_plus(query)
		return '%s%sq=%s' % (base, '&' if '?' in base else '?', quote_plus(query))
	return '%s/q.php?q=%s&cat=0' % (base, quote_plus(query))


def clear_piratebay_cache():
	try:
		main_cache.delete_like('PIRATEBAY_%')
		return True
	except Exception:
		return False


def _bases():
	"""The chosen / custom base first, then the built-in mirrors. A custom value that already contains q.php is used as typed."""
	chosen = piratebay_base_url().rstrip('/')
	return [chosen] + [u for u in PIRATEBAY_URLS if u.rstrip('/') != chosen]


def _row(raw):
	if not isinstance(raw, dict):
		return None
	name = (raw.get('name') or '').strip()
	if not name or name.lower() == 'no results returned':
		return None
	info_hash = normalize_info_hash(raw.get('info_hash') or raw.get('infoHash') or '')
	if not info_hash or set(info_hash) == {'0'}:
		return None
	try: seeders = int(raw.get('seeders') or 0)
	except Exception: seeders = 0
	return {'hash': info_hash, 'name': name, 'size': bytes_to_gb(raw.get('size')), 'seeders': seeders}


def search(query, timeout=10, expiration=24):
	query = (query or '').strip()
	if not query:
		return []
	cache_key = 'PIRATEBAY_%s_%s' % (piratebay_base_url(), query)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	try:
		first = piratebay_base_url().rstrip('/')
		if 'q.php' in first:      # a custom full URL: use it exactly as given
			payload, _ = indexer_http.get_json('piratebay', [''], piratebay_search_url(query), timeout=timeout)
		else:
			payload, _ = indexer_http.get_json('piratebay', _bases(), '/q.php', {'q': query, 'cat': 0}, timeout)
	except Exception as e:
		logger('piratebay api', '%s: %s (%s)' % (type(e).__name__, str(e)[:200], query))
		return []
	results, seen = [], set()
	for raw in (payload if isinstance(payload, list) else []):
		row = _row(raw)
		if row and row['hash'] not in seen:
			seen.add(row['hash'])
			results.append(row)
	main_cache.set(cache_key, results, expiration=expiration)
	return results
