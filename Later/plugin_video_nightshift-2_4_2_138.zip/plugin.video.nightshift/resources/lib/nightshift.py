# -*- coding: utf-8 -*-
# Stale-copy protection: compiled Python lives in a per-version folder of this add-on (never in __pycache__ next to the code), and this add-on's own modules are searched first.
import os, sys, time
_T0 = time.time()
sys.dont_write_bytecode = True

def _use_private_bytecode_cache():
	"""Compiled Python goes to this add-on's own folder, one per add-on VERSION (and Python checks each file's date and size too), so a
	stale copy can never load and an update starts clean - but the code is no longer recompiled from source at every cold start."""
	try:
		import xbmcvfs, xbmcaddon
		version = xbmcaddon.Addon('plugin.video.nightshift').getAddonInfo('version')
		base = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.nightshift/pycache/')
		path = os.path.join(base, version)
		os.makedirs(path, exist_ok=True)
		sys.pycache_prefix = path
		sys.dont_write_bytecode = False
	except Exception:
		sys.dont_write_bytecode = True
_use_private_bytecode_cache()
_LIB = os.path.dirname(os.path.abspath(__file__))
while _LIB in sys.path: sys.path.remove(_LIB)
sys.path.insert(0, _LIB)
import sys
from urllib.parse import parse_qsl
from modules.router import routing, sys_exit_check
try:
	import modules.router as _router_module
	_router_module.IMPORT_SECONDS = time.time() - _T0
except Exception: pass
# from modules.kodi_utils import logger

routing(sys)
try:
	from modules.kodi_utils import logger as _log
	_log('MenuTiming', '%s took %.2fs [start-up: %s; rest = imports + building the list] (pycache %s)' % (sys.argv[2][1:60] if len(sys.argv) > 2 else 'main', time.time() - _T0, ', '.join(p for p in __import__('modules.router', fromlist=['PHASES']).PHASES if p != '_build'), 'on' if not sys.dont_write_bytecode else 'off'))
except Exception: pass
params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True)) if len(sys.argv) > 2 else {}
mode = params.get('mode', 'navigator.main')
if sys_exit_check(mode): sys.exit(1)
