# -*- coding: utf-8 -*-
"""Puts the Nightshift Home menu selection back on the row the user left.

The skin records the row when the user goes into a section (Nightshift.RootIndex). It cannot restore it itself:
AlarmClock does not evaluate $INFO, so the focus call always reached Kodi with an invalid row and the list fell back
to the top. This service runs the restore with a real number, once per return to the root menu.
"""
import time
import xbmc
import xbmcgui

HOME_WINDOW = 10000
SECTION_PROPERTY = 'Nightshift.Section'
INDEX_PROPERTY = 'Nightshift.RootIndex'
ROOT_LIST = 9000
POLL_SECONDS = 0.25


def _property(name):
	try:
		return str(xbmcgui.Window(HOME_WINDOW).getProperty(name) or '').strip()
	except Exception:
		return ''


def _number(text):
	try:
		return int(float(text))
	except (TypeError, ValueError):
		return 0


def _trace(state):
	"""One log line each time the menu state changes, so a log shows every row change and return to the root menu."""
	xbmc.log('[NIGHTSHIFT menu] %s' % ' '.join('%s=%s' % (k, v) for k, v in state.items()), xbmc.LOGINFO)


AMBIENCE_FILE_PROPERTY = 'nightshift.ambience.playing.file'
SECTION_LIST = 9200


def _visible(condition):
	try:
		return bool(xbmc.getCondVisibility(condition))
	except Exception:
		return False


def run(monitor):
	restored = False
	last = None
	row = 0                                    # last row (1-based) the user was on in the root menu
	home_seen = 0.0                            # last time the Nightshift Home window was in front
	guarded = False
	while not monitor.abortRequested():
		try:
			now = time.time()
			home_active = _visible('Window.IsActive(home)')
			section = _property(SECTION_PROPERTY)
			index_text = _property(INDEX_PROPERTY)
			count = _number(xbmc.getInfoLabel('Container(%d).NumItems' % ROOT_LIST)) if home_active else 0
			position = _number(xbmc.getInfoLabel('Container(%d).CurrentItem' % ROOT_LIST)) if home_active else 0
			label = xbmc.getInfoLabel('Container(%d).ListItem.Label' % ROOT_LIST) if home_active else ''
			root_focused = home_active and _visible('Control.HasFocus(%d)' % ROOT_LIST)
			sub_focused = home_active and _visible('Control.HasFocus(%d)' % SECTION_LIST)
			state = {'home': int(bool(home_active)), 'section': section or '-', 'root_index': index_text or '-',
					 'items': count, 'focus': position, 'focus_label': label or '-', 'root_focus': int(bool(root_focused)),
					 'row': row, 'restored': int(restored)}
			if state != last:
				_trace(state)
				last = state
			if home_active:
				home_seen = now
				guarded = False
				dialog = _visible('System.HasActiveModalDialog') and not _visible('Window.IsActive(busydialog)')
				if section == 'home':
					if root_focused and position > 0:
						row = position                     # remember the row the user is on
					if not restored and count > 0:
						target = row or _number(index_text)
						if 0 < target <= count:
							xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (ROOT_LIST, target - 1))
							_trace({'restore_to_row': target, 'items': count})
						restored = True
					elif restored and not root_focused and not dialog and count > 0:
						xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (ROOT_LIST, max(row, 1) - 1))
						_trace({'focus_repair': 'root', 'row': row})
				else:
					restored = False
					if not sub_focused and not dialog:
						xbmc.executebuiltin('SetFocus(%d)' % SECTION_LIST)   # a section is open: Back must reach its list
						_trace({'focus_repair': 'section', 'section': section})
			else:
				restored = False
				# Back pressed with focus lost opens the visualisation of the ambience track: go straight back to the menu
				if (not guarded and _visible('Window.IsActive(visualisation)') and now - home_seen < 3.0
						and xbmcgui.Window(HOME_WINDOW).getProperty(AMBIENCE_FILE_PROPERTY)):
					guarded = True
					if section and section != 'home':
						xbmcgui.Window(HOME_WINDOW).setProperty(SECTION_PROPERTY, 'home')
					xbmc.executebuiltin('Action(Back)')
					_trace({'visualisation_blocked': 1, 'section': section or '-'})
		except Exception as error:
			xbmc.log('[NIGHTSHIFT] root focus: %s' % error, xbmc.LOGWARNING)
		if monitor.waitForAbort(POLL_SECONDS):
			break
