# -*- coding: utf-8 -*-
"""Buttons of the NIGHTSHIFT ambience settings: add, show and remove music folders.
RunScript(script.service.nightshift.ambience,add|show|remove|clear|convert|tracks_on|tracks_off)"""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import audioconvert
import musicfolders
from tracks import BUILTIN_TRACKS

TITLE = 'NIGHTSHIFT ambience'


def notify(text):
	xbmcgui.Dialog().notification(TITLE, text, xbmcgui.NOTIFICATION_INFO, 4000, False)


def add():
	dialog = xbmcgui.Dialog()
	pick = dialog.select('Add a music folder', ['Browse for a folder...', 'Type or paste a folder path...'])
	if pick < 0:
		return
	if pick == 0:
		path = dialog.browse(0, 'Choose a folder with music (it is searched with the folders inside it)', 'music', '', False, False, '')
	else:
		path = dialog.input('Folder path (for example /storage/emulated/0/Music or smb://nas/music)', type=xbmcgui.INPUT_ALPHANUM)
	path = (path or '').strip()
	if not path:
		return
	folders = musicfolders.load()
	if path in folders:
		notify('That folder is already in the list')
		return
	if not xbmcvfs.exists(path if path.endswith(('/', '\\')) else path + '/'):
		if not dialog.yesno(TITLE, 'Kodi cannot see this folder right now:\n%s\n\nAdd it anyway?' % path):
			return
	found = musicfolders.scan(path)
	folders.append(path)
	if musicfolders.save(folders):
		notify('Added: %d track(s) found' % len(found))
		try:
			audioconvert.offer_after_add(path)
		except Exception as error:      # the conversion offer must never undo adding a folder
			xbmc.log('[NIGHTSHIFT ambience] conversion offer skipped: %s' % error, xbmc.LOGINFO)
	else:
		notify('The folder could not be saved')


def show():
	folders = musicfolders.load()
	if not folders:
		xbmcgui.Dialog().ok(TITLE, 'No extra music folders yet.\nUse "Add a music folder" to add songs to the built-in tracks.')
		return
	lines = ['Extra music folders (played after the built-in tracks):', '']
	total = 0
	for folder in folders:
		count = len(musicfolders.scan(folder))
		total += count
		lines.append('%s\n    %d track(s)' % (folder, count))
	lines += ['', 'Total: %d extra track(s)' % total]
	xbmcgui.Dialog().textviewer(TITLE, '\n'.join(lines))


def remove():
	folders = musicfolders.load()
	if not folders:
		notify('No extra music folders to remove')
		return
	picked = xbmcgui.Dialog().multiselect('Remove which folders?', folders)
	if not picked:
		return
	keep = [f for i, f in enumerate(folders) if i not in picked]
	if musicfolders.save(keep):
		notify('Removed %d folder(s)' % len(picked))


def clear():
	if musicfolders.load() and xbmcgui.Dialog().yesno(TITLE, 'Remove all extra music folders?'):
		musicfolders.save([])
		notify('All extra folders removed')


def convert():
	"""Convert the music of the added folders to Opus 96 kbps with the libffmpeg inside this add-on."""
	audioconvert.run()


def set_all_tracks(value):
	addon = xbmcaddon.Addon()
	for setting_id, _file, _label in BUILTIN_TRACKS:
		addon.setSettingBool(setting_id, value)
	notify('All built-in tracks are %s' % ('on' if value else 'off'))


def tracks_on():
	set_all_tracks(True)


def tracks_off():
	set_all_tracks(False)


if __name__ == '__main__':
	action = sys.argv[1] if len(sys.argv) > 1 else 'add'
	{'add': add, 'show': show, 'remove': remove, 'clear': clear, 'convert': convert, 'tracks_on': tracks_on, 'tracks_off': tracks_off}.get(action, add)()
