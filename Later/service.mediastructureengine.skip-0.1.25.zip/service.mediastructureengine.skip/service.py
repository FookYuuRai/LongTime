# SPDX-License-Identifier: GPL-2.0-or-later
# Based on TheIntroDB's Kodi add-on (service.py); read-only: no submissions, no usage reporting.
"""Skip intro / recap / credits / preview for whatever Kodi plays, and an interface for other add-ons (ipc.py)."""
import json
import os
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import coordinator as coordinator_mod
import fpdb
import ipc
import online
import overlay as overlay_mod
import resolver as resolver_mod
import skipper
from player import SkipPlayer

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
STR = {'intro': 32001, 'recap': 32003, 'credits': 32004, 'preview': 32005}
PURGE_DAYS = {0: 0, 1: 7, 2: 30}              # purge_after setting (index): never, 7 days, 30 days
BOOLS = ('prefer_player_buttons', 'use_theintrodb', 'use_introdb', 'use_animethemes', 'use_chapters', 'use_crossmatch', 'learn')


class Settings:
    """Settings read fresh each time, so changes apply without a restart."""

    def get(self, name):
        try:
            value = xbmcaddon.Addon(ADDON_ID).getSetting(name)
        except Exception:
            value = ADDON.getSetting(name)
        if name in BOOLS or name.startswith(('enable_', 'auto_', 'debug_')):
            return value == 'true'
        return value


def log(msg):
    xbmc.log('[MSE Skip] ' + msg, xbmc.LOGINFO)


def debug_osd(msg):
    if Settings().get('debug_osd'):
        xbmc.executebuiltin('Notification(MSE Skip, %s, 1500)' % msg)


class Monitor(xbmc.Monitor):
    def __init__(self, on_request):
        super().__init__()
        self.on_request = on_request

    def onNotification(self, sender, method, data):
        if not method.endswith('Resolve'):
            return
        try:
            media = json.loads(data)
            if isinstance(media, list):
                media = media[0]
            self.on_request(media if isinstance(media, dict) else {})
        except ValueError:
            log('bad request: %s' % data[:200])


class SkipService:
    def __init__(self):
        self.cfg = Settings()
        self.home = xbmcgui.Window(ipc.HOME)
        self.db = fpdb.Db(os.path.join(PROFILE, 'fingerprint.db'))
        self.lib = None
        try:
            import loader
            self.lib, path = loader.load_library(ADDON_PATH)
            log('loaded %s (%s)' % (path, self.lib.version()))
        except Exception as exc:
            log('fingerprints unavailable: %s' % exc)
        ids_path = os.path.join(PROFILE, 'anime_ids.json')
        self.resolver = resolver_mod.Resolver(self.db, self.lib, self.cfg, ids_path, log)
        self.coord = coordinator_mod.Coordinator(self.resolver, self._publish, log, cancelled=self._cancelled, adjust=self._adjust)
        self.player = SkipPlayer()
        self.monitor = Monitor(self._external_request)
        self.processed = {}
        self._cancel_seen = False
        self._media = {}

    # -- answers ----------------------------------------------------------------------------------------------------
    def _publish(self, key, status, segments):
        self.home.setProperty(ipc.result_property(key), ipc.encode(status, segments))

    def _style(self):
        return 'card' if str(self.cfg.get('button_style')) == '1' else 'pill'

    def _offset(self, name):
        try:
            return max(-60.0, min(60.0, float(self.cfg.get(name) or 0)))
        except (TypeError, ValueError):
            return 0.0

    def _adjust(self, segments):
        """Settings start_offset / end_offset (seconds, may be negative) added to every start and end of every source;
        credits_start_offset / credits_end_offset are added on top of those for credits (outro) segments only."""
        return adjust_segments(segments, self._offset('start_offset'), self._offset('end_offset'),
                               {'credits': (self._offset('credits_start_offset'), self._offset('credits_end_offset'))})

    def _cancelled(self):
        return self._cancel_seen

    # -- requests from other add-ons ---------------------------------------------------------------------------------
    def _external_request(self, media):
        playing_tv = self.player.playback_started and self.player.is_tv_content
        if not playing_tv and not (media.get('season') and media.get('episode')):
            log('ignored request: not an episode')
            return
        mode = 'full' if media.get('mode') == 'full' and playing_tv else 'api'
        self._request(media, mode, external=True)

    def _open_playing(self):
        path = self.player.getPlayingFile()
        return lambda: (path, xbmcvfs.File(path))

    def _request(self, media, mode, external=False):
        media = dict(media)
        for k in ('season', 'episode'):
            try:
                media[k] = int(media[k])
            except (KeyError, TypeError, ValueError):
                media[k] = None
        if not media.get('duration_s'):
            try:
                media['duration_s'] = self.player.getTotalTime() if self.player.isPlaying() else None
            except Exception:
                pass
        open_file = None
        if mode == 'full':
            try:
                open_file = self._open_playing()
            except Exception:
                mode = 'api'
        return self.coord.request(media, mode, open_file, external=external)

    # -- periodic jobs -----------------------------------------------------------------------------------------------
    def _purge_due(self):
        days = PURGE_DAYS.get(int(self.cfg.get('purge_after') or 0), 0)
        if days:
            n = self.db.purge(days)
            if n:
                log('purged %d show(s) not played for %d days' % (n, days))

    def _settings_actions(self):
        addon = xbmcaddon.Addon(ADDON_ID)
        if addon.getSetting('purge_now') == 'true':
            addon.setSetting('purge_now', 'false')
            self.db.purge_all()
            xbmcgui.Dialog().notification('MSE Skip', addon.getLocalizedString(32063), xbmcgui.NOTIFICATION_INFO, 3000)
        if addon.getSetting('show_stats') == 'true':
            addon.setSetting('show_stats', 'false')
            s = self.db.stats()
            xbmcgui.Dialog().ok('fingerprint.db', '%d shows, %d episodes, %d themes, %d results\n%.1f MB' % (
                s['shows'], s['episodes'], s['themes'], s['results'], s['bytes'] / 1e6))

    # -- playback loop -----------------------------------------------------------------------------------------------
    def run(self):
        self.coord.start()
        self._purge_due()
        log('service started')
        last_purge = 0
        current = None
        media = None
        key = None
        while not self.monitor.abortRequested():
            if self.monitor.waitForAbort(1.0):
                break
            self._settings_actions()
            last_purge += 1
            if last_purge >= 6 * 3600:
                last_purge = 0
                self._purge_due()
            if not self.player.playback_started:
                if current is not None:
                    current = None
                    self._cancel_seen = True
                    if self.lib:
                        self.lib.cancel()
                continue
            if not self.player.is_tv_content:
                continue
            filename = self.player.filename
            if not filename:
                continue
            if filename != current:                      # a new file
                current, self.processed, key = filename, {}, None
                self._cancel_seen = False
                self.coord.reset_playback()
                media = self._media = self.player.get_media_ids()
                media['duration_s'] = (media.get('duration_ms') or 0) / 1000.0 or None
                log('ids: tmdb=%s tvdb=%s imdb=%s S%sE%s' % (media.get('tmdb_id'), media.get('tvdb_id'),
                                                              media.get('imdb_id'), media.get('season'),
                                                              media.get('episode')))
                key = self._request(media, 'full') if self._anything_on() else None
            if not key:
                continue
            self._skip_loop_step(self.coord.segments(key), filename)
        self.coord.stop()
        self.db.close()
        log('service stopped')

    def _anything_on(self):
        return any(self.cfg.get('enable_' + k) for k in STR)

    def _enabled_segments(self, segments):
        out = []
        for kind in ('intro', 'recap', 'preview', 'credits'):
            if not self.cfg.get('enable_' + kind):
                continue
            for idx, seg in enumerate(segments.get(kind, [])):
                entry = dict(seg, type=kind, index=idx)
                out.append(entry)
        out.sort(key=lambda s: s['start'] if s['start'] is not None else 0)
        return out

    def _skip_loop_step(self, segments, filename):
        for idx, seg in enumerate(self._enabled_segments(segments)):
            if self._handle_segment(seg, idx, filename) == 'break':
                break

    def _bounds(self, seg):
        start, end = seg.get('start'), seg.get('end')
        if start is None and end is None:
            return None
        start = 0 if start is None else start
        next_ep = seg['type'] in ('credits', 'preview') and end is None
        if end is None:
            # open-ended segment (credits / preview run to the end of the video): its end is 10 s before the end of the file, and the setting
            # "end offset when no end was found" moves THAT time - the offsets for found ends have no stored end to be added to here
            try:
                end = self.player.getTotalTime() - 10
            except Exception:
                return None
            end += self._offset('end_not_found_offset')       # its own setting: the offsets for found ends do not apply here
            end = max(end, start + 1.0)
        return start, end, next_ep

    def _handle_segment(self, seg, idx, filename):
        bounds = self._bounds(seg)
        if bounds is None or not self.player.isPlaying():
            return None
        start, end, next_ep = bounds
        kind = seg['type']
        if self.cfg.get('prefer_player_buttons') and self.coord.is_claimed(self._media, kind):
            return None                                   # the player add-on shows its own button for this kind
        skey = '%s_%d' % (kind, idx)
        try:
            if not self.player.isPlaying():
                return None
            now = self.player.getTime()
        except RuntimeError:
            return None
        if not should_show(self.processed, skey, now, start, end):
            return None
        name = xbmcaddon.Addon(ADDON_ID).getLocalizedString(STR[kind])
        if self.cfg.get('auto_skip_' + kind):
            skipper.execute_skip(self.player, start, end, filename, kind)
            debug_osd('Auto-skipped %s (%s)' % (name, seg.get('source')))
            return None
        if next_ep:
            info = self.player.get_next_episode()
            if info:
                pressed = overlay_mod.show_skip_overlay(intro_end=end, player=self.player, monitor=self.monitor,
                                                        segment_type='next_episode', segment_index=idx,
                                                        style=self._style())
                if pressed:
                    self.player.play_next_episode(info)
                return None
        pressed = overlay_mod.show_skip_overlay(intro_end=end, player=self.player, monitor=self.monitor,
                                                segment_type=kind, segment_index=idx, style=self._style())
        if pressed:
            skipper.execute_skip(self.player, start, end, filename, kind)
            debug_osd('Skipped %s (%s)' % (name, seg.get('source')))
        return None


def adjust_segments(segments, start_off, end_off, per_kind=None):
    """Copy of the segments with the offsets added: a start is moved by start_off, an end by end_off (never before 0, a
    segment keeps at least 1 s). per_kind = {kind: (start_off, end_off)} is added on top for that kind only. A missing
    start (0) or end (to the end of the video) stays."""
    per_kind = per_kind or {}
    if not start_off and not end_off and not any(a or b for a, b in per_kind.values()):
        return segments
    out = {}
    for kind, lst in segments.items():
        k_start, k_end = per_kind.get(kind, (0.0, 0.0))
        s_off, e_off = start_off + k_start, end_off + k_end
        out[kind] = []
        for seg in lst:
            seg = dict(seg)
            if seg.get('start') is not None and seg['start'] > 0:
                seg['start'] = max(0.0, seg['start'] + s_off)
            if seg.get('end') is not None:
                seg['end'] = max(seg['end'] + e_off, (seg.get('start') or 0.0) + 1.0)
            out[kind].append(seg)
    return out


def should_show(processed, key, now, start, end, margin=0.5):
    """The skip button is shown once per entry into a segment (again after leaving it or seeking back)."""
    state = processed.setdefault(key, {'inside': False, 'shown': False, 'last': None})
    inside = start <= now < (end - margin)
    last = state['last']
    if not inside:
        state.update(inside=False, shown=False, last=now)
        return False
    if not state['inside'] or (last is not None and now + margin < last):
        state['shown'] = False
    state['inside'], state['last'] = True, now
    if state['shown']:
        return False
    state['shown'] = True
    return True


if __name__ == '__main__':
    SkipService().run()
