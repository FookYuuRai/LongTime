# -*- coding: utf-8 -*-
"""Persistent AniList airing calendar snapshot (UTC today +/- 14 days).

Normal navigation reads the current day's SQLite snapshot. A stale/missing
snapshot is rebuilt from AniList; explicit force refresh bypasses the snapshot.
A failed refresh never deletes the previous usable snapshot.
"""
import hashlib
import time
from datetime import datetime, timedelta, timezone

from caches.base_cache import connect_database, ensure_database_tables
from modules import kodi_utils

_DB = 'anilist_calendar_db'
_READY = False

QUERY = '''query AnimeCalendar($start:Int,$end:Int,$page:Int){
  Page(page:$page,perPage:50){
    pageInfo{hasNextPage currentPage}
    airingSchedules(airingAt_greater:$start,airingAt_lesser:$end,sort:TIME){
      airingAt episode
      media{id idMal title{english romaji native} countryOfOrigin season seasonYear startDate{year} coverImage{large}}
    }
  }
}'''


_MAP_REV = 3   # bump when the matching rules change: old AniList -> TMDb pairs are discarded once


def _db():
    global _READY
    if not _READY:
        ensure_database_tables(_DB)
        _READY = True
    dbcon = connect_database(_DB)
    try:
        dbcon.execute('CREATE TABLE IF NOT EXISTS anilist_map_rev (rev integer)')
        if not dbcon.execute('SELECT 1 FROM anilist_map_rev WHERE rev=?', (_MAP_REV,)).fetchone():
            dbcon.execute('DELETE FROM anilist_tmdb_map')
            dbcon.execute('DELETE FROM anilist_map_rev')
            dbcon.execute('INSERT INTO anilist_map_rev (rev) VALUES (?)', (_MAP_REV,))
            try: dbcon.commit()
            except Exception: pass
    except Exception: pass
    return dbcon


def _utc_window():
    now = datetime.now(timezone.utc)
    day = now.date()
    start = datetime.combine(day - timedelta(days=14), datetime.min.time(), tzinfo=timezone.utc)
    end = datetime.combine(day + timedelta(days=14), datetime.max.time(), tzinfo=timezone.utc).replace(microsecond=0)
    return day.isoformat(), int(start.timestamp()), int(end.timestamp())


def _fetch_live(start, end):
    from apis.anilist_api import _post
    results, page = [], 1
    while True:
        payload = _post(QUERY, {'start': int(start), 'end': int(end), 'page': page})
        page_data = payload.get('Page') or {}
        if not page_data:
            raise RuntimeError('AniList returned no Page data')
        schedule = page_data.get('airingSchedules')
        if schedule is None:
            raise RuntimeError('AniList response omitted airingSchedules')
        results.extend(schedule)
        if not (page_data.get('pageInfo') or {}).get('hasNextPage'):
            break
        page += 1
        if page > 100:
            raise RuntimeError('AniList calendar exceeded the 100-page safety limit')
    return results


def _mapping_title(media):
    title = media.get('title') or {}
    return title.get('english') or title.get('romaji') or title.get('native') or ''


import re as _re

_SEASON_BRACKET = _re.compile(r'\(\s*(\d{4}|TV)\s*\)', _re.I)
_SEASON_SUFFIX = _re.compile(r'\s+(\d+(st|nd|rd|th)\s+)?(season|cour|part|stage)\b.*$', _re.I)


def _base_title(title):
    """AniList title without its season / part / cour suffix. Returns (base, had_suffix).

    'Black Clover Season 2' -> ('Black Clover', True); 'Maomao no Hitorigoto 3rd Season' -> ('Maomao no Hitorigoto', True)
    """
    t = _SEASON_BRACKET.sub(' ', title or '').strip()
    base = _SEASON_SUFFIX.sub('', t).strip(' -:')
    if not base: return t, False
    return base, base != t


def _norm(text):
    return ''.join(c.lower() for c in (text or '') if c.isalnum())


def _title_score(search_terms, names):
    from difflib import SequenceMatcher
    score = 0
    for left in search_terms:
        lnorm = _norm(left)
        if not lnorm: continue
        for right in names:
            rnorm = _norm(right)
            if not rnorm: continue
            if lnorm == rnorm: score = max(score, 100)
            elif min(len(lnorm), len(rnorm)) >= 5 and (lnorm.startswith(rnorm) or rnorm.startswith(lnorm)): score = max(score, 85)
            else: score = max(score, int(SequenceMatcher(None, lnorm, rnorm).ratio() * 80))
    return score


# A candidate must score at least this to be used. Looser matches picked the wrong show (wrong stills and backgrounds).
MATCH_MIN_SCORE = 85


def _year_ok(candidate_year, year, had_suffix):
    """Season entries carry the season's own year, so the first-air check is skipped for them."""
    if had_suffix or not candidate_year or not year: return True
    try: return abs(int(candidate_year) - int(year)) <= 1
    except Exception: return True


def _pick_candidate(search_terms, year, had_suffix, candidates):
    """candidates: [(id, [names], year)]. Returns the best acceptable id or ''."""
    best, best_score = '', 0
    for cid, names, cyear in candidates:
        if not cid or not _year_ok(cyear, year, had_suffix): continue
        score = _title_score(search_terms, names)
        if score >= MATCH_MIN_SCORE and score > best_score:
            best, best_score = cid, score
            if score == 100: break
    return best


def _tvdb_bridge_tmdb_id(search_terms, year):
    """TMDb id for a show TMDb search missed: TVDb search by base title, then TVDb's TMDb remote id."""
    try:
        from apis.tvdb_api import tvdb_search_series, tvdb_series_tmdb_id
    except Exception:
        return ''
    base, had_suffix = _base_title(search_terms[0]) if search_terms else ('', False)
    terms = [base] if base else search_terms[:1]
    candidates, seen = [], set()
    for term in terms:
        for cand in tvdb_search_series(term) or []:
            if cand['tvdb_id'] in seen: continue
            seen.add(cand['tvdb_id'])
            candidates.append((cand['tvdb_id'], [cand['name']], cand['year']))
    chosen = _pick_candidate(terms, year, had_suffix, candidates)
    return tvdb_series_tmdb_id(chosen) if chosen else ''


def _resolve_tmdb_id(anilist_id, media):
    """Resolve a public AniList series to TMDb: title search on the base title (season suffix removed), then TVDb bridge."""
    dbcon = _db()
    try:
        row = dbcon.execute('SELECT tmdb_id, matched_at FROM anilist_tmdb_map WHERE anilist_id=?', (str(anilist_id),)).fetchone()
        now = int(time.time())
        if row:
            cached_id, matched_at = str(row[0] or ''), int(row[1] or 0)
            negative_ttl = 6 * 3600 if not cached_id else 180 * 86400
            if now - matched_at < negative_ttl:
                return cached_id
    finally:
        dbcon.close()

    tmdb_id = ''
    year = media.get('seasonYear') or (media.get('startDate') or {}).get('year')
    titles = media.get('title') or {}
    full_terms = []
    for term in (titles.get('english'), titles.get('romaji'), titles.get('native')):
        if term and term not in full_terms: full_terms.append(term)
    base, had_suffix = _base_title(full_terms[0] if full_terms else '')
    search_terms = [base] if had_suffix else full_terms[:3]
    try:
        from apis.tmdb_api import tmdb_tv_search
        candidates, seen = [], set()
        for term in search_terms[:3]:
            for page_no in (1, 2):
                result = tmdb_tv_search(term, page_no) or {}
                for c in (result.get('results') or []):
                    cid = str(c.get('id') or '')
                    if not cid or cid in seen: continue
                    seen.add(cid)
                    candidates.append((cid, [c.get('name') or '', c.get('original_name') or ''], (c.get('first_air_date') or '')[:4]))
                if any(_title_score(search_terms, names) == 100 and _year_ok(cy, year, had_suffix) for _, names, cy in candidates):
                    break
        tmdb_id = _pick_candidate(search_terms, year, had_suffix, candidates)
    except Exception as exc:
        kodi_utils.logger('AniListCalendar', 'TMDb title mapping failed for AniList %s: %s' % (anilist_id, exc))
    if not tmdb_id:
        tmdb_id = _tvdb_bridge_tmdb_id(search_terms or full_terms, year)

    dbcon = _db()
    try:
        dbcon.execute('INSERT OR REPLACE INTO anilist_tmdb_map (anilist_id,tmdb_id,matched_at,title,year) VALUES (?,?,?,?,?)',
                      (str(anilist_id), tmdb_id, int(time.time()), _mapping_title(media), year or 0))
    finally:
        dbcon.close()
    return tmdb_id


def _normalize_rows(raw_rows):
    normalized = []
    mapped = {}
    for row in raw_rows:
        media = row.get('media') or {}
        airing_at = row.get('airingAt')
        episode = row.get('episode')
        anilist_id = media.get('id')
        if not airing_at or not episode or not anilist_id:
            continue
        key = str(anilist_id)
        if key not in mapped:
            mapped[key] = _resolve_tmdb_id(key, media)
        title = media.get('title') or {}
        cover = media.get('coverImage') or {}
        try:
            airing_at = int(airing_at)
            episode = int(episode)
        except Exception:
            continue
        digest = hashlib.sha1(('%s|%s|%s' % (key, episode, airing_at)).encode('utf-8')).hexdigest()
        normalized.append({
            'airing_key': digest,
            'anilist_id': key,
            'tmdb_id': mapped[key],
            'airing_at': airing_at,
            'episode': episode,
            'title_english': title.get('english') or '',
            'title_romaji': title.get('romaji') or '',
            'title_native': title.get('native') or '',
            'country': media.get('countryOfOrigin') or '',
            'season': media.get('season') or '',
            'season_year': media.get('seasonYear') or (media.get('startDate') or {}).get('year') or 0,
            'cover_url': cover.get('large') or ''
        })
    return normalized


def _read_rows(dbcon):
    rows = dbcon.execute(
        'SELECT airing_key,anilist_id,tmdb_id,airing_at,episode,title_english,title_romaji,title_native,country,season,season_year,cover_url '
        'FROM calendar_airings ORDER BY airing_at ASC'
    ).fetchall()
    return [{
        'airing_key': r[0], 'anilist_id': r[1], 'tmdb_id': r[2], 'airing_at': int(r[3]), 'episode': int(r[4]),
        'title_english': r[5] or '', 'title_romaji': r[6] or '', 'title_native': r[7] or '',
        'country': r[8] or '', 'season': r[9] or '', 'season_year': int(r[10] or 0), 'cover_url': r[11] or ''
    } for r in rows]


def _replace_snapshot(rows, snapshot_day, start, end):
    dbcon = _db()
    try:
        dbcon.execute('BEGIN IMMEDIATE')
        dbcon.execute('DELETE FROM calendar_airings')
        dbcon.executemany(
            'INSERT INTO calendar_airings (airing_key,anilist_id,tmdb_id,airing_at,episode,title_english,title_romaji,title_native,country,season,season_year,cover_url) '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            [(r['airing_key'], r['anilist_id'], r['tmdb_id'], r['airing_at'], r['episode'], r['title_english'], r['title_romaji'],
              r['title_native'], r['country'], r['season'], r['season_year'], r['cover_url']) for r in rows]
        )
        dbcon.execute('INSERT OR REPLACE INTO calendar_snapshot (id,snapshot_day,window_start,window_end,fetched_at,row_count) VALUES (1,?,?,?,?,?)',
                      (snapshot_day, int(start), int(end), int(time.time()), len(rows)))
        dbcon.commit()
    except Exception:
        dbcon.rollback()
        raise
    finally:
        dbcon.close()



def snapshot_is_current():
    """Whether the persistent AniList snapshot matches the current UTC day."""
    snapshot_day, _start, _end = _utc_window()
    dbcon = _db()
    try:
        row = dbcon.execute('SELECT snapshot_day FROM calendar_snapshot WHERE id=1').fetchone()
        return bool(row and row[0] == snapshot_day)
    except Exception:
        return False
    finally:
        dbcon.close()


def get_calendar(force=False):
    """Return the stored AniList rows, rebuilding only if the UTC snapshot day is stale or forced."""
    snapshot_day, start, end = _utc_window()
    dbcon = _db()
    try:
        snapshot = dbcon.execute('SELECT snapshot_day,row_count FROM calendar_snapshot WHERE id=1').fetchone()
        rows = _read_rows(dbcon)
        if not force and snapshot and snapshot[0] == snapshot_day:
            kodi_utils.logger('AniListCalendar', 'snapshot hit day=%s rows=%d (no live AniList fetch)' % (snapshot_day, len(rows)))
            return rows
    finally:
        dbcon.close()

    try:
        raw = _fetch_live(start, end)
        normalized = _normalize_rows(raw)
        _replace_snapshot(normalized, snapshot_day, start, end)
        try:
            from caches import public_calendar_cache
            public_calendar_cache.invalidate()
        except Exception:
            pass
        kodi_utils.logger('AniListCalendar', 'Rebuilt AniList airing window %s (±14 days): %d entries' % (snapshot_day, len(normalized)))
        return normalized
    except Exception as exc:
        kodi_utils.logger('AniListCalendar', 'Live calendar refresh failed; preserving existing snapshot: %s' % exc)
        dbcon = _db()
        try:
            return _read_rows(dbcon)
        finally:
            dbcon.close()


def force_refresh():
    return get_calendar(force=True)


def purge_and_rebuild():
    """Delete the saved AniList airing snapshot and its database rows, then download the calendar again."""
    from modules import kodi_utils
    kodi_utils.logger('AniListCalendar', 'force refresh: purging the saved snapshot and rows, then rebuilding')
    clear_snapshot()
    return get_calendar(force=True)


def clear_snapshot():
    dbcon = _db()
    try:
        dbcon.execute('DELETE FROM calendar_airings')
        dbcon.execute('DELETE FROM calendar_snapshot')
        dbcon.commit()
    finally:
        dbcon.close()


def air_dates_for_tmdb(tmdb_id, season=None, meta=None):
    """{local_episode: ISO air date} from the existing AniList calendar snapshot DB.

    Uses calendar_airings (same rows as Public Anime Calendar). Episode numbers on AniList
    are absolute; when season + meta.season_data are provided they are mapped onto that TMDb season.
    Only airings present in the current ±14 day snapshot (and any residual DB rows) are returned —
    no extra AniList GraphQL beyond the normal calendar refresh.
    """
    from datetime import datetime, timezone
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id or tmdb_id in ('0', 'None'):
        return {}
    try:
        season = int(season) if season not in (None, '') else None
    except Exception:
        season = None
    dbcon = _db()
    try:
        rows = dbcon.execute(
            'SELECT episode, airing_at FROM calendar_airings WHERE tmdb_id=? ORDER BY episode ASC',
            (tmdb_id,)
        ).fetchall()
    finally:
        try:
            dbcon.close()
        except Exception:
            pass
    if not rows:
        return {}
    abs_map = {}
    for ep, airing_at in rows:
        try:
            ep_i, ts = int(ep), int(airing_at)
        except Exception:
            continue
        if ep_i < 1 or ts < 1:
            continue
        abs_map[ep_i] = datetime.fromtimestamp(ts, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    if not abs_map:
        return {}
    if season is None:
        return abs_map
    offset = 0
    max_local = 0
    try:
        for s in (meta or {}).get('season_data') or []:
            try:
                n = int(s.get('season_number') or 0)
                cnt = int(s.get('episode_count') or 0)
            except Exception:
                continue
            if 0 < n < season:
                offset += max(cnt, 0)
            if n == season:
                max_local = cnt
    except Exception:
        pass
    if max_local <= 0:
        max_local = max(abs_map) - offset if abs_map else 0
    out = {}
    for local in range(1, max(max_local, 1) + 1):
        abs_ep = offset + local
        if abs_ep in abs_map:
            out[local] = abs_map[abs_ep]
    if not out:
        # Single-cour / unknown season layout: treat AniList absolute as local.
        out = dict(abs_map)
    return out


def ensure_calendar_warm():
    """Touch get_calendar so the ±14 day snapshot exists before air-date lookups."""
    try:
        get_calendar(force=False)
    except Exception:
        pass
