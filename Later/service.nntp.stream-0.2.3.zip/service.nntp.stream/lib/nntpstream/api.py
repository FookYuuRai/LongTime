"""The interface other add-ons use.

    import nntpstream
    nntpstream.check(nzb, servers)                -> {'ok', 'sampled', 'missing', 'unknown', 'reason', 'name', 'size'}
    nntpstream.play_url(nzb, servers, name=None, episode={'season': 1, 'episode': 5, 'absolute': 5})  -> a URL for xbmc.Player / ListItem (nntpstream:// or http://127.0.0.1)
    nntpstream.unpack_to(nzb, servers, folder, progress=None, cancel=None) -> path of the video unpacked from a stored RAR / ZIP release
    nntpstream.stop()                             -> a film is being left: waits for articles end at once

nzb: the NZB itself (bytes / str starting with '<') or its http(s) link. servers: ['nntps://user:pass@host:563', ...] (/N = connections, else the add-on's setting)
own=False: use only the servers passed, not the ones typed in the add-on's own settings
"""
import hashlib
import os
import re
import time
import urllib.request

from . import health, nzb as nzbmod, nntp, paths, plan as planmod, settings, yenc

VERSION = '0.2.3'
_CHECKED = {}                    # token -> (time, result)
CHECK_TTL = 1800


def _nzb_bytes(nzb):
    if isinstance(nzb, bytes):
        return nzb
    text = str(nzb).strip()
    if text.startswith('<'):
        return text.encode('utf-8')
    request = urllib.request.Request(text, headers={'User-Agent': 'nntpstream/' + VERSION})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read(64 << 20)


def _servers(servers, own=True):
    settings.apply()
    listed = list(servers or []) + (settings.own_servers() if own else [])   # the source's own servers first, yours as backup
    parsed, seen = [], set()
    for value in listed:                                   # the same server listed twice (Red Light's slot and the add-on's own list) once
        server = nntp.parse_server(value) if not isinstance(value, dict) else value
        if server and (server['host'], server['port'], server['user']) not in seen:
            seen.add((server['host'], server['port'], server['user']))
            parsed.append(server)
    if not parsed:
        raise ValueError('no Usenet server')
    return parsed


def _token(data, servers, episode=None):
    key = hashlib.sha256(data).hexdigest() + '|' + '|'.join('%s:%d' % (s['host'], s['port']) for s in servers)
    if episode: key += '|ep%s' % ','.join('%s' % (episode.get(k) or 0) for k in ('season', 'episode', 'absolute'))
    return hashlib.sha256(key.encode()).hexdigest()[:32]


def safe_name(name):
    base, ext = os.path.splitext(os.path.basename(str(name or '')))
    base = re.sub(r'[^A-Za-z0-9._-]+', '.', base).strip('.')[:120] or 'film'
    ext = re.sub(r'[^A-Za-z0-9]', '', ext)[:5].lower() or 'mkv'
    return '%s.%s' % (base, ext)


def _head(servers, film):
    """First article of the film: its size, its article size and its name."""
    last = None
    for server in servers:
        conn = None
        try:
            conn = nntp.Connection(server)
            decoded = yenc.decode(conn.body(film.segments[0][2]))
            if decoded:
                return decoded
        except nntp.Missing:
            last = nntp.NntpError('the first article of the film is missing')
        except Exception as error:
            last = error
        finally:
            if conn:
                conn.close()
    raise last or nntp.NntpError('the first article of the film could not be read')


def check(nzb, servers, samples=None, own=True, episode=None):
    """Is this release there? Cheap: one NZB, one article, and STAT for the rest. Never raises."""
    try:
        data = _nzb_bytes(nzb)
        servers = _servers(servers, own)
        token = _token(data, servers, episode)
        cached = _CHECKED.get(token)
        if cached and time.time() - cached[0] < CHECK_TTL:
            return dict(cached[1])
        film = nzbmod.pick_film(nzbmod.load(data, servers), episode)
        result = health.check(servers, [s[2] for s in film.segments], samples or health.SAMPLES)
        result['name'] = film.name
        result['token'] = token
    except Exception as error:
        result = {'ok': False, 'sampled': 0, 'missing': 0, 'unknown': 0, 'reason': str(error) or type(error).__name__}
    if result.get('token'):
        _CHECKED[result['token']] = (time.time(), result)
    return dict(result)


def prepare(nzb, servers, name=None, keep=None, ahead=None, own=True, episode=None):
    """Reads the NZB, finds the film, writes the plan. -> (token, plan)."""
    data = _nzb_bytes(nzb)
    servers = _servers(servers, own)
    token = _token(data, servers, episode)
    film = nzbmod.pick_film(nzbmod.load(data, servers), episode)
    begin, first, size, found = _head(servers, film)
    plan = planmod.Plan()
    plan.size = size
    plan.name = safe_name(name or found or film.name)
    plan.servers = servers
    plan.keep, plan.ahead = keep or settings.limits()[0], ahead or settings.limits()[1]
    if not keep and not ahead:
        # a big film (a UHD remux runs at 80-120 Mbit/s) needs more of it fetched in advance than a 5 GB one
        factor = 2 if size >= 80e9 else 1.5 if size >= 40e9 else 1
        plan.keep, plan.ahead = int(plan.keep * factor), int(plan.ahead * factor)
    plan.maxconn = settings.connection_limit()
    if plan.maxconn:
        for n, s in enumerate(plan.servers):     # (the Python reader has no sharing: the first server may use all, the others a quarter)
            s['connections'] = max(1, min(s['connections'], plan.maxconn))
    plan.extents = [[0, 0, size, len(first) if len(film.segments) > 1 else size, [s[2] for s in film.segments]]]
    planmod.save(token, plan)
    paths.log('plan %s: %s, %.2f GB, %d articles, %d server(s), %s' % (token[:8], plan.name, size / 1e9,
                                                                  len(film.segments), len(servers),
                                                                  ('connections limited to %d in total' % plan.maxconn) if plan.maxconn else 'connections automatic'))
    return token, plan


def native_available():
    if os.environ.get('NNTP_NATIVE'):
        return os.environ['NNTP_NATIVE'] == '1'
    try:
        import xbmc
        return bool(xbmc.getCondVisibility('System.AddonIsEnabled(vfs.nntp)'))
    except Exception:
        return False


def _fallback_port():
    """The service's server (it must outlive the add-on that asks: a plugin ends after it has resolved its URL).
    Outside Kodi (tests) the server is started in this process."""
    try:
        import xbmcgui
        port = xbmcgui.Window(10000).getProperty('nntp.stream.port')
        if port:
            return int(port)
        raise RuntimeError('the NNTP Stream service is not running')
    except ImportError:
        from . import server
        return server.ensure_started()


def play_url(nzb, servers, name=None, native=None, own=True, episode=None):
    """A URL Kodi can play. The native add-on when it is there, else the local HTTPS server."""
    token, plan = prepare(nzb, servers, name, own=own, episode=episode)
    if native is None:
        native = native_available()
    if native:
        return 'nntpstream://%s/%s' % (token, plan.name)
    return 'http://127.0.0.1:%d/stream/%s/%s' % (_fallback_port(), token, plan.name)


def stop():
    """A film is being left: waiting reads end at once (native: the `leaving` mark; Python server: its streams)."""
    try:
        with open(os.path.join(paths.plans(), 'leaving'), 'w') as handle:
            handle.write(str(time.time()))
    except OSError:
        pass
    try:
        from . import server
        server.stop_streams()
    except Exception:
        pass


def unpack_to(nzb, servers, folder, progress=None, cancel=None, own=True):
    """Downloads a packed (stored RAR / ZIP) release and unpacks its video into `folder`. progress(done, total, bytes_per_second).
    Raises unpack.Unsupported (compressed / encrypted / 7z), unpack.Cancelled, IOError."""
    from . import unpack
    data = _nzb_bytes(nzb)
    servers = _servers(servers, own)
    mode = os.environ.get('NNTP_UNPACK_MODE') or ('vfs' if native_available() else 'download')
    if mode in ('vfs', 'http'):
        # the release is read as ONE long file through vfs.nntp (native decoder, connections shared by speed)
        if mode == 'vfs':
            url_for = lambda token, plan: 'nntpstream://%s/%s' % (token, plan.name)
            reader = unpack.VfsReader
        else:
            url_for = lambda token, plan: 'http://127.0.0.1:%d/stream/%s/%s' % (_fallback_port(), token, plan.name)
            reader = unpack.HttpReader
        try:
            return unpack.run_stream(data, servers, folder, url_for, reader, progress=progress, cancel=cancel)
        except (unpack.Unsupported, unpack.Cancelled):
            raise
        except Exception as error:
            paths.log('unpack through the stream failed (%s): downloading the volumes instead' % error)
    return unpack.run(data, servers, folder, progress=progress, cancel=cancel)
