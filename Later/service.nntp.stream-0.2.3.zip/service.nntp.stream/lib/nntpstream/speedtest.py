"""Speed test: how fast the internet line is, and how fast each Usenet server delivers with 2 / 4 / 8 / 16 connections
(real articles of the film played last, read and thrown away), so you can see whether the limit is the line, the provider,
or the number of connections."""
import os
import threading
import time

from . import nntp, paths
from . import plan as planmod

STEPS = (2, 4, 8, 16, 24, 32)
SECONDS = 7                  # per step
LINE_URLS = ('https://proof.ovh.net/files/100Mb.dat',)


def recent_plans():
    """The films played lately, newest first: [(path, plan)]."""
    folder = paths.plans()
    files = [os.path.join(folder, n) for n in os.listdir(folder) if n.endswith('.plan')]
    files.sort(key=os.path.getmtime, reverse=True)
    out = []
    for path in files:
        try:
            with open(path, encoding='utf-8') as handle:
                out.append((path, planmod.parse(handle.read())))
        except Exception:
            continue
    return out


def redlight_slots():
    """[(slot, host, enabled)] of Red Light's Usenet providers as they are set right now (in its order), or None when they cannot be read."""
    try:
        import sqlite3
        try:
            import xbmcvfs
            base = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.redlight/databases/settings.db')
        except Exception:
            base = os.environ.get('REDLIGHT_SETTINGS_DB', '')
        if not base or not os.path.isfile(base):
            return None
        con = sqlite3.connect('file:%s?mode=ro' % base, uri=True, timeout=2)
        try:
            rows = dict(con.execute("SELECT setting_id, setting_value FROM settings WHERE setting_id LIKE 'usenet%'").fetchall())
        finally:
            con.close()
        out = []
        for slot in range(1, 26):
            host = str(rows.get('usenet%d.host' % slot, '') or '')
            if host in ('', 'empty_setting'):
                continue
            host = host.split('://')[-1].split('/')[0].rsplit('@', 1)[-1].split(':')[0].strip().lower()
            if host:
                out.append((slot, host, str(rows.get('usenet%d.enabled' % slot, 'false')).lower() == 'true'))
        return out
    except Exception:
        return None


def _redlight_hosts():
    """(enabled hosts, disabled hosts), or None when Red Light's settings cannot be read."""
    slots = redlight_slots()
    if slots is None:
        return None
    on = {h for _s, h, e in slots if e}
    off = {h for _s, h, e in slots if not e} - on
    return on, off


def _mbit(nbytes, seconds):
    return nbytes * 8 / 1e6 / seconds if seconds > 0 else 0.0


def line_speed(seconds=SECONDS, streams=4, errors=None):
    """The plain internet line from this device: a few downloads at once, Mbit/s (None when it cannot be measured).
    Tries each address until one delivers; errors (a list) gets what went wrong."""
    import urllib.request
    for url in LINE_URLS:
        total, lock = [0], threading.Lock()
        stop = time.time() + seconds
        context = None
        if url.startswith('https'):
            try:
                context = nntp.tls_context()
            except Exception:
                context = None

        def run():
            try:
                request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(request, timeout=10, context=context) as response:
                    while time.time() < stop:
                        chunk = response.read(262144)
                        if not chunk:
                            break
                        with lock:
                            total[0] += len(chunk)
            except Exception as error:
                if errors is not None:
                    errors.append('%s: %s' % (url.split('/')[2], str(error)[:70]))
        started = time.time()
        threads = [threading.Thread(target=run, daemon=True) for _ in range(streams)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(seconds + 12)
        if total[0]:
            return _mbit(total[0], time.time() - started), url.split('/')[2]
    return None, None


def server_speed(server, ids, count, seconds=SECONDS, should_stop=None):
    """Reads articles on `count` connections for `seconds`. -> (Mbit/s, articles, missing, error)."""
    state = {'bytes': 0, 'n': 0, 'missing': 0, 'error': None, 'next': 0}
    lock = threading.Lock()
    stop_at = time.time() + seconds

    def worker():
        connection = None
        try:
            connection = nntp.Connection(server)
            while time.time() < stop_at and not (should_stop and should_stop()):
                with lock:
                    if state['next'] >= len(ids):
                        return
                    message_id = ids[state['next']]
                    state['next'] += 1
                try:
                    body = connection.body(message_id)
                except nntp.Missing:
                    with lock:
                        state['missing'] += 1
                    continue
                with lock:
                    state['bytes'] += len(body)
                    state['n'] += 1
        except nntp.TooMany:
            with lock:
                state['error'] = 'the provider refuses this many connections'
        except nntp.AuthError:
            with lock:
                state['error'] = 'login refused'
        except Exception as error:
            with lock:
                state['error'] = str(error)[:60]
        finally:
            if connection:
                connection.close()
    started = time.time()
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(count)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(seconds + 20)
    return _mbit(state['bytes'], time.time() - started), state['n'], state['missing'], state['error']




def _slot_names():
    slots = redlight_slots() or []
    names = {}
    for slot, host, _enabled in slots:
        names.setdefault(host, 'Server %d' % slot)
    return names


def _measure(server, label, ids, out, say, should_stop):
    """Steps through the connection counts on one server. -> entry dict (see caps), None when the server has none of these articles."""
    best = (0.0, 0)
    results = {}
    cursor = 0
    for count in STEPS:
        if should_stop and should_stop():
            out.append('stopped')
            return 'stopped'
        say('%s: %d connections...' % (label, count))
        chunk = ids[cursor:cursor + 800]
        cursor += 800
        if len(chunk) < 40:
            out.append('  (not enough articles left in the film to test more)')
            break
        speed, n, missing, error = server_speed(server, chunk, count, should_stop=should_stop)
        if error and not n:
            out.append('  %2d connections: %s' % (count, error))
            break
        if not n and missing >= 20:
            out.append('  this server has none of the articles of this film (%d asked, all missing) - not measured' % missing)
            break
        note = ', %d articles missing on this server' % missing if missing else ''
        note += ' (%s)' % error if error else ''
        out.append('  %2d connections: %5.1f Mbit/s  (%.1f per connection)%s' % (count, speed, speed / count, note))
        results[count] = speed
        if speed > best[0]:
            best = (speed, count)
        if error:
            break
    if not best[1]:
        return None
    out.append('  best: %.0f Mbit/s with %d connections' % best)
    # the fewest connections that reach 90 % of the best speed: more of them only costs the provider and the device
    enough = max(2, min((c for c, v in results.items() if v >= 0.9 * best[0]), default=best[1]))
    out.append('  this test: %d connections (the saved ceiling is the highest of the last 3 tests)' % enough)
    return {'connections': enough, 'mbit': round(best[0], 1), 'at': int(time.time()), 'steps': {str(c): round(v, 1) for c, v in results.items()}}


def _pool(plan):
    ids = [i for extent in plan.extents for i in extent[4]]
    middle = len(ids) // 3        # articles from the middle of the film, so nothing is read from a cache
    return ids[middle:] + ids[:middle]


def _covers(connection, plan, samples=8):
    """Does this server have this film? A few STATs of articles from the middle of it."""
    from . import health
    ids = _pool(plan)[:4000]
    picked = health.sample_ids(ids, samples)
    found = 0
    for message_id in picked:
        try:
            if connection.stat(message_id):
                found += 1
        except nntp.NntpError:
            raise
    return found >= max(3, int(len(picked) * 0.6))


def _enabled_servers():
    """Servers of the films played lately, one per host (the newest plan's login), only those switched on in Red Light, in Red Light's order."""
    from . import caps as _caps    # noqa
    plans = recent_plans()
    seen = {}
    for _path, plan in plans:
        for server in plan.servers:
            seen.setdefault(server['host'].lower(), server)
    slots = redlight_slots()
    if slots is None:
        return list(seen.values()), plans
    ordered = []
    for _slot, host, enabled in slots:
        if enabled and host in seen and seen[host] not in ordered:
            ordered.append(seen[host])
    ordered += [server for host, server in seen.items() if host not in {h for _s, h, _e in slots}]    # servers of the add-on's own list
    return ordered, plans


def status_lines():
    """What is known per provider and what still has to be tested."""
    from . import caps
    known = caps.entries()
    names = _slot_names()
    slots = redlight_slots()
    if slots is not None:
        hosts = []
        for _slot, host, enabled in slots:
            if enabled and host not in hosts:
                hosts.append(host)
    else:
        hosts = [s['host'].lower() for s in _enabled_servers()[0]]
    lines = ['Measured by the speed test (the connections each provider opens, and its best speed):', '']
    todo = []
    for host in hosts:
        name = names.get(host, 'Server')
        entry = known.get(host)
        if entry:
            when = time.strftime('%d %b', time.localtime(entry['at'])) if entry.get('at') else '-'
            speed = '%.0f Mbit/s' % entry['mbit'] if entry.get('mbit') else 'speed not recorded'
            tests = [str(h['connections']) for h in entry.get('history') or []]
            lines.append('  [x] %s (%s): up to %d connections, %s  [%s]%s' % (name, host, entry['connections'], speed, when,
                         ('  tests: ' + ', '.join(tests)) if len(tests) > 1 else ''))
        else:
            lines.append('  [ ] %s (%s): not measured yet' % (name, host))
            todo.append(name.replace('Server ', ''))
    lines.append('')
    if not hosts:
        lines.append('No Usenet servers are switched on in Red Light.')
    elif todo:
        lines.append('%d of %d servers measured. Still to test: %s.' % (len(hosts) - len(todo), len(hosts), ', '.join(todo)))
        lines.append('Run the speed test and choose "Measure the servers not measured yet": it finds a film each of them has, and leaves the measured ones as they are.')
    else:
        lines.append('All %d servers are measured. Nothing left to test.' % len(hosts))
    return lines


def run(progress=None, should_stop=None, with_line=True, plan=None, only_new=False):
    """-> a list of text lines with the result. only_new: just the servers not measured yet, each with a film it has."""
    from . import caps
    out = []
    say = lambda text: progress(text) if progress else None
    line = None
    if with_line:
        say('Internet line...')
        problems = []
        line, where = line_speed(errors=problems)
        out.append('Internet line (this device, %s): %s' % (where or 'no test address answered', '%.0f Mbit/s' % line if line else 'could not be measured'))
        for problem in sorted(set(problems))[:4]:
            out.append('  ' + problem)
    names = _slot_names()
    new_entries = {}
    best_all = 0.0
    if only_new:
        servers, plans = _enabled_servers()
        known = caps.entries()
        todo = [x for x in servers if x['host'].lower() not in known]
        if not plans:
            out.append('No film played yet: play an NZB once, then run this again.')
            return out
        if not todo:
            out.append('')
            out.extend(status_lines())
            return out
        out.append('')
        out.append('%d server(s) not measured yet: %s' % (len(todo), ', '.join(names.get(x['host'].lower(), x['host']) for x in todo)))
        for server in todo:
            host = server['host'].lower()
            label = '%s (%s%s)' % (names.get(host, 'Server'), server['host'], '' if server['ssl'] else ', no TLS')
            out.append('')
            out.append(label)
            say('%s: looking for a film it has...' % label)
            film = None
            try:
                connection = nntp.Connection(server)
                try:
                    for _path, candidate in plans:
                        if should_stop and should_stop():
                            out.append('stopped')
                            return out
                        if _covers(connection, candidate):
                            film = candidate
                            break
                finally:
                    connection.close()
            except Exception as error:
                out.append('  cannot reach it: %s' % str(error)[:70])
                continue
            if not film:
                out.append('  none of your recent films is on this server: play a film it has (an older or different title), then run this again')
                continue
            out.append('  film: %s (%.1f GB)' % (film.name, film.size / 1e9))
            entry = _measure(server, label, _pool(film), out, say, should_stop)
            if entry == 'stopped':
                break
            if entry:
                entry['film'] = film.name
                new_entries[host] = entry
                best_all = max(best_all, entry['mbit'])
    else:
        if plan is None:
            found = recent_plans()
            plan = found[0][1] if found else None
        if not plan:
            out.append('No film played yet: play an NZB once, then run this again to test the Usenet servers.')
            return out
        out.append('')
        out.append('Film used for the Usenet test: %s (%.1f GB, %d articles)' % (plan.name, plan.size / 1e9, sum(len(e[4]) for e in plan.extents)))
        servers = list(plan.servers)
        hosts = _redlight_hosts()
        if hosts:
            on, off = hosts
            kept = [x for x in servers if x['host'].lower() not in off]
            for x in servers:
                if x not in kept:
                    out.append('Skipped (switched off in Red Light): %s' % x['host'])
            servers = kept
        pool = _pool(plan)
        for index, server in enumerate(servers):
            host = server['host'].lower()
            label = '%s (%s%s)' % (names.get(host, 'Server %d' % (index + 1)), server['host'], '' if server['ssl'] else ', no TLS')
            out.append('')
            out.append(label)
            entry = _measure(server, label, pool, out, say, should_stop)
            if entry == 'stopped':
                break
            if entry:
                entry['film'] = plan.name
                new_entries[host] = entry
                best_all = max(best_all, entry['mbit'])
    if new_entries:
        caps.update(new_entries)
        out.append('')
        out.append('Saved: each of these providers keeps this test with its last 3, and may open up to the highest of them (the others were not changed). Switch off with "Use the speed test\'s connection counts" in the settings.')
    out.append('')
    if line and best_all:
        if best_all >= 0.85 * line:
            out.append('Verdict: the Usenet servers fill your line: the line is the limit.')
        else:
            out.append('Verdict: the line does %.0f Mbit/s but the best server tested only %.0f: the provider (speed cap, distance) is the limit, not your line.' % (line, best_all))
    out.append('')
    out.extend(status_lines())
    return out
