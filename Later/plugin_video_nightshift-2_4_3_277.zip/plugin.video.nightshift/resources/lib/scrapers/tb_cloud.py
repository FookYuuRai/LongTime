# -*- coding: utf-8 -*-
import time
from apis.torbox_api import TorBox, TorBoxAPI
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name
from caches.settings_cache import get_setting
# from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'tb_cloud'
		self.sources = []
		self.extensions = source_utils.supported_video_extensions()
		self._folder_fetch_count = 0
		self._max_folder_fetches = 10

	def results(self, info):
		source_utils.remember_request(info)
		self.sources = []
		try:
			if not enabled_debrids_check('tb'):
				return self.sources
			self.scrape_results = []
			filter_title = filter_by_name(self.scrape_provider)
			self.filter_title = filter_title
			self.media_type, title = info.get('media_type'), info.get('title')
			self.year = int(info.get('year') or 0)
			self.season, self.episode = info.get('season'), info.get('episode')
			self.absolute_episode = info.get('absolute_episode')
			self.ep_name = info.get('ep_name', '')  # Episode name for title-token override
			self.tmdb_id = info.get('tmdb_id')
			self.title = title
			self.folder_query = source_utils.clean_title(normalize(title))
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.title_queries = self._title_queries()
			self.scrape_deadline = time.time() + min(25, max(10, int(get_setting('nightshift.results.timeout', '20'))))
			
			# Log absolute episode for diagnostics (episodes only)
			if self.media_type == 'episode' and self.absolute_episode:
				source_utils.diag_log('TB Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					self.season, self.episode, self.absolute_episode, self.ep_name))
			
			for media_type in ('torrent', 'usenet', 'webdl'):
				if time.time() >= self.scrape_deadline:
					break
				items = self._cached_mylist_items(media_type)
				if items:
					self._scrape_cloud_list(media_type, items)
			# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			self._apply_title_token_recovery()
			# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			
			raw_count = len(self.scrape_results)
			skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'exception': 0}
			
			def _process():
				for item in self.scrape_results:
					try:
						if not TorBoxAPI.is_scrapeable_cloud_file(item, self.extensions):
							skipped['release_filter'] += 1
							continue
                        
						file_name = TorBoxAPI._torrent_file_label(item)
						if not file_name:
							skipped['release_filter'] += 1
							continue
						file_name_latin = normalize(file_name) or file_name
                        
						# RELEASE FILTER CHECK
						# Release filter removed: it is a Real-Debrid-only rule (applied in debrid.stamp_torrent_cache / rd_cloud).
                        
						# Use unified wrapper for cloud files (cloud-folder gating)
						if not source_utils.should_accept_file_title(
							self.title, file_name_latin, self.aliases, self.year, self.season, self.episode,
							ep_name=self.ep_name if self.media_type == 'episode' else None,
							absolute_episode=self.absolute_episode,
							in_cloud_folder=True,
							is_recovery_pass=False,
							filter_title=filter_title
						):
							skipped['title_filter'] += 1
							source_utils.diag_log('TB Match', 'file REJECT (title_filter): %r' % file_name_latin)
							continue
                        
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						file_id = TorBoxAPI._torrent_file_id(item)
						if file_id is None:
							continue
						try:
							size_bytes = int(item.get('size') or 0)
						except Exception:
							size_bytes = 0
						size = round(size_bytes / 1073741824, 2) if size_bytes else 0.0
						size_label = '%.2f GB' % size if size_bytes else 'N/A'
						file_dl = '%d,%d' % (int(item['folder_id']), int(file_id))
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name_latin))
						source_utils.diag_log('TB Match', 'file ACCEPT: %r' % file_name_latin)
						source_item = {
							'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size,
							'size_label': size_label, 'debrid': self.scrape_provider, 'extraInfo': details,
							'url_dl': file_dl, 'id': file_dl, 'downloads': False, 'direct': True,
							'source': self.scrape_provider, 'scrape_provider': self.scrape_provider,
							'folder_id': item['folder_id'],
							'cloud_media_type': item.get('cloud_media_type', 'torrent'),
						}
						yield source_item
					except Exception:
						skipped['exception'] += 1
			self.sources = list(_process())
			
			source_utils.diag_log('TB Match', '%s : %s kept / %d raw' % (title, len(self.sources), raw_count))
			if raw_count and not self.sources:
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('TB Match', 'all raw results dropped (%s)' % dropped)
			elif any(skipped.values()):
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('TB Match', 'dropped (%s)' % dropped)
		except Exception as e:
			from modules.kodi_utils import logger
			logger('torbox scraper Exception', str(e))
		finally:
			source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _cached_mylist_items(self, media_type):
		loaders = {
			'torrent': TorBox.user_cloud,
			'usenet': TorBox.user_cloud_usenet,
			'webdl': TorBox.user_cloud_webdl,
		}
		loader = loaders.get(media_type)
		if not loader:
			return []
		try:
			response = loader()
		except Exception:
			return []
		if not response or not isinstance(response, dict) or not response.get('success'):
			return []
		data = response.get('data') or []
		if isinstance(data, dict):
			data = [data]
		return data if isinstance(data, list) else []

	def _title_queries(self):
		queries = set()
		for candidate in [self.title] + list(self.aliases or []):
			if not candidate:
				continue
			for variant in (candidate, source_utils.normalize(candidate), normalize(candidate)):
				if not variant:
					continue
				query = source_utils.clean_title(variant)
				if query:
					queries.add(query)
		return queries

	def _contains_year(self, *texts):
		if not self.year:
			return False
		years = self._year_query_list()
		for text in texts:
			if not text:
				continue
			if any(str(y) in text for y in years):
				return True
		return False

	def _title_match(self, clean_file, folder_name):
		return any(q and (q in clean_file or (folder_name and q in folder_name)) for q in self.title_queries)

	def _prefilter_folder(self, folder_name, raw_folder):
		"""Pre-filter folders to determine if we should scan inside.
		
		For episodes: folder name should indicate it might contain episodes.
		"""
		if not folder_name and not raw_folder:
			return False
		if self.media_type == 'movie':
			if not self._title_match('', folder_name):
				return False
			if self.year and not self._contains_year(raw_folder):
				return False
			return True
		if self.folder_query and self.folder_query in folder_name:
			return True
		if any(q and q in folder_name for q in self.title_queries):
			return True
		if source_utils.seas_ep_filter_exact(self.season, self.episode, raw_folder):
			return True
		if self.ep_name and source_utils.episode_title_in_release(self.ep_name, normalize(raw_folder or folder_name)):
			return True
		try:
			if self.absolute_episode and int(self.absolute_episode) in set(
					source_utils.iter_bare_episode_numbers(raw_folder or '')): return True
		except Exception: pass
		return self._title_match('', folder_name)

	def _match_cloud_file(self, normalized, folder_name='', raw_file='', raw_folder='', folder_prefiltered=False, ep_name_override=False):
		"""Check if file matches with optional folder context.
		
		For episodes:
		- If folder_prefiltered=True and ep_name_override=True: use ep-title token override
		- Otherwise: apply standard matching
		
		Args:
			normalized: Normalized filename
			folder_name: Cleaned folder name
			raw_file: Raw file name
			raw_folder: Raw folder name
			folder_prefiltered: Whether folder passed pre-filter
			ep_name_override: Whether to use episode-title token override
		"""
		# Use unified wrapper that handles folder gating and title checks
		return source_utils.should_accept_file_title(
			self.title, normalized, self.aliases, self.year, self.season, self.episode,
			ep_name=self.ep_name if ep_name_override else None,
			absolute_episode=self.absolute_episode,
			in_cloud_folder=folder_prefiltered,
			is_recovery_pass=False,
			filter_title=self.filter_title
		)

	def _files_for_folder(self, folder_id, media_type, item):
		inline = item.get('files')
		if inline is not None:
			if not inline or not TorBoxAPI.folder_has_playable_videos(inline, self.extensions):
				return []
			return [f for f in TorBoxAPI.filter_browse_cloud_files(inline, self.extensions) if TorBoxAPI.is_scrapeable_cloud_file(f, self.extensions)]
		if self._folder_fetch_count >= self._max_folder_fetches:
			return []
		if time.time() >= self.scrape_deadline - 3:
			return []
		self._folder_fetch_count += 1
		request_timeout = min(8, max(3, int(self.scrape_deadline - time.time()) - 1))
		raw = TorBox.mylist_item_files(
			folder_id, media_type, fresh=False, allow_live_fallback=True, request_timeout=request_timeout,
		) or []
		if not TorBoxAPI.folder_has_playable_videos(raw, self.extensions):
			return []
		return [f for f in TorBoxAPI.filter_browse_cloud_files(raw, self.extensions) if TorBoxAPI.is_scrapeable_cloud_file(f, self.extensions)]

	def _scrape_cloud_list(self, media_type, items):
		"""Scrape cloud with folder-context awareness for loose matching.
		
		Workflow:
		1. Pre-filter folders to see if they might contain episodes
		2. For pre-filtered folders: pass folder_prefiltered=True and ep_name_override=True
		3. For non-pre-filtered: apply stricter matching
		"""
		try:
			if time.time() >= self.scrape_deadline:
				return
			append = self.scrape_results.append
			for item in items:
				if time.time() >= self.scrape_deadline:
					return
				if not TorBoxAPI._torrent_item_finished(item):
					continue
				folder_id = item.get('id') or item.get('torrent_id')
				if folder_id is None:
					continue
				raw_folder = item.get('name') or ''
				folder_name = source_utils.clean_title(normalize(raw_folder))
				folder_prefiltered = self._prefilter_folder(folder_name, raw_folder)
				if not folder_prefiltered:
					source_utils.diag_log('TB FolderGate', 'SKIP folder=%r (no title/S&E/ep-name/abs tokens)' % raw_folder)
					continue
				source_utils.diag_log('TB FolderGate', 'enter folder=%r media=%s' % (raw_folder, media_type))
				files = self._files_for_folder(folder_id, media_type, item)
				if not files:
					continue
				folder_hits = []
				for file in files:
					if time.time() >= self.scrape_deadline:
						return
					label = TorBoxAPI._torrent_file_label(file)
					normalized = normalize(label) or label
					# Pass ep_name_override=True since folder already pre-filtered
					if not self._match_cloud_file(normalized, folder_name, label, raw_folder, folder_prefiltered, ep_name_override=True):
						source_utils.diag_log('TB FolderContents', 'file REJECT folder=%r file=%r' % (raw_folder, label))
						continue
					source_utils.diag_log('TB FolderContents', 'file ACCEPT folder=%r file=%r' % (raw_folder, label))
					file_id = TorBoxAPI._torrent_file_id(file)
					if file_id is None:
						continue
					file_entry = dict(file)
					file_entry['id'] = file_id
					file_entry['folder_id'] = folder_id
					file_entry['cloud_media_type'] = media_type
					folder_hits.append(file_entry)
				if not folder_hits:
					continue
				if self.media_type == 'movie':
					folder_hits.sort(key=lambda k: int(k.get('size') or 0), reverse=True)
					append(folder_hits[0])
				else:
					for file_entry in folder_hits:
						append(file_entry)
		except Exception:
			return

	# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
	def _apply_title_token_recovery(self):
		"""Recovery pass: use title-token override to catch any missed episodes.
		
		This is a redundancy check that runs after standard matching.
		Files that passed standard matching are NOT re-processed.
		This only catches files that would have been rejected by standard matching
		but have valid episode-title tokens.
		
		For TorBox, we re-scan pre-filtered folders for episode-title token matches.
		
		Set to run only for episodes when ep_name is available.
		"""
		if self.media_type != 'episode' or not self.ep_name:
			return
		
		if time.time() >= self.scrape_deadline - 3:
			return
		
		try:
			# Track already-added files to avoid duplicates
			existing_files = {item.get('id') for item in self.scrape_results if item.get('id')}
			
			for media_type in ('torrent', 'usenet', 'webdl'):
				if time.time() >= self.scrape_deadline:
					break
                
				items = self._cached_mylist_items(media_type)
				if not items:
					continue
                
				for item in items:
					if time.time() >= self.scrape_deadline:
						break
                    
					if not TorBoxAPI._torrent_item_finished(item):
						continue
                    
					folder_id = item.get('id') or item.get('torrent_id')
					if folder_id is None:
						continue
                    
					raw_folder = item.get('name') or ''
					folder_name = source_utils.clean_title(normalize(raw_folder))
					folder_prefiltered = self._prefilter_folder(folder_name, raw_folder)
                    
					# Only re-scan pre-filtered folders
					if not folder_prefiltered:
						source_utils.diag_log('TB FolderGate', 'RECOVERY SKIP folder=%r' % raw_folder)
						continue
                    
					try:
						files = self._files_for_folder(folder_id, media_type, item)
						if not files:
							continue
                        
						for file in files:
							if time.time() >= self.scrape_deadline:
								break
                            
							label = TorBoxAPI._torrent_file_label(file)
							normalized = normalize(label) or label
							file_id = TorBoxAPI._torrent_file_id(file)
                            
							# Skip if already in results
							if file_id and file_id in existing_files:
								continue
                            
							# Try recovery pass using unified wrapper (episode-title tokens only)
							if source_utils.should_accept_file_title(
								self.title, normalized, self.aliases, self.year, self.season, self.episode,
								ep_name=self.ep_name,
								in_cloud_folder=True,
								is_recovery_pass=True,  # Recovery mode: ONLY ep-title tokens
								filter_title=False
							):
								source_utils.diag_log('TB CloudMatch', 'RECOVERY add: %r' % normalized)
								file_entry = dict(file)
								file_entry['id'] = file_id
								file_entry['folder_id'] = folder_id
								file_entry['cloud_media_type'] = media_type
								self.scrape_results.append(file_entry)
								if file_id:
									existing_files.add(file_id)
					except Exception:
						continue
		except Exception:
			pass
	# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====

	def _year_query_list(self):
		if not self.year:
			return tuple()
		return (str(self.year), str(self.year + 1), str(self.year - 1))