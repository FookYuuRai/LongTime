# -*- coding: utf-8 -*-
"""TVDB-first show ids for NightShift's own storage (local watched history, progress, themes, saved autoplay pack).

A show's storage key is 'tvdb<id>' when "Use TVDB first" is on and the show has a TVDB id; the TMDb id is the key only when
TVDB has nothing for the show.  Rows written before the switch stay under the TMDb id and are still read (a TVDB row for the same
episode wins), so no existing history is rewritten or lost.  The tmdb<->tvdb map is kept in a small table of the local watched
database so that a 'tvdb<id>' row can always be turned back into the TMDb id the rest of the add-on (metadata, widgets) works with.
Provider databases (Trakt, Simkl, MDBList, PunchPlay) keep the provider's own ids - they are never touched here.
"""
from threading import Lock
from caches.base_cache import connect_database

PREFIX = 'tvdb'
_BAD = (None, '', 'None', 'none', 'empty_setting', '0', '0000000', 0)
_lock = Lock()
_fwd, _rev = {}, {}
_loaded = [False]
_said = set()


def _log(key, text):
	if key in _said: return
	_said.add(key)
	try:
		from modules.kodi_utils import logger
		logger('TvdbFirst', text)
	except Exception: pass


def _db():
	dbcon = connect_database('watched_db')
	dbcon.execute('CREATE TABLE IF NOT EXISTS tvdb_map (tvdb_id TEXT PRIMARY KEY, tmdb_id TEXT)')
	return dbcon


def _load():
	if _loaded[0]: return
	with _lock:
		if _loaded[0]: return
		try:
			for tvdb, tmdb in _db().execute('SELECT tvdb_id, tmdb_id FROM tvdb_map').fetchall():
				_fwd[str(tmdb)], _rev[str(tvdb)] = str(tvdb), str(tmdb)
		except Exception: pass
		_loaded[0] = True


def enabled():
	try:
		from apis.tmdb_api import tvdb_first_enabled
		return tvdb_first_enabled()
	except Exception: return False


def remember(tmdb_id, tvdb_id):
	"""Store a tmdb<->tvdb pair (ignored when either side is missing)."""
	tmdb_id, tvdb_id = str(tmdb_id or ''), str(tvdb_id or '')
	if tmdb_id in _BAD or tvdb_id in _BAD: return False
	_load()
	if _fwd.get(tmdb_id) == tvdb_id and _rev.get(tvdb_id) == tmdb_id: return True
	_fwd[tmdb_id], _rev[tvdb_id] = tvdb_id, tmdb_id
	try: _db().execute('INSERT OR REPLACE INTO tvdb_map VALUES (?, ?)', (tvdb_id, tmdb_id))
	except Exception: pass
	return True


def tvdb_for(tmdb_id, fetch=False):
	"""The TVDB id of a TMDb show, or None when TVDB has nothing for it.  fetch=True may load the show's metadata (network)."""
	tmdb_id = str(tmdb_id or '')
	if tmdb_id in _BAD: return None
	_load()
	if tmdb_id in _fwd: return _fwd[tmdb_id]
	tvdb = None
	try:
		from caches.meta_cache import meta_cache
		meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id)
		if not meta and fetch:
			from modules import metadata, settings
			from modules.utils import get_datetime
			meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		if meta and not meta.get('blank_entry'): tvdb = str(meta.get('tvdb_id') or '')
	except Exception: pass
	if tvdb and tvdb not in _BAD:
		remember(tmdb_id, tvdb)
		return tvdb
	return None


def tmdb_for(tvdb_id, fetch=True):
	"""The TMDb id behind a TVDB show id (None when it cannot be resolved)."""
	tvdb_id = str(tvdb_id or '')
	if tvdb_id in _BAD: return None
	_load()
	if tvdb_id in _rev: return _rev[tvdb_id]
	tmdb = None
	try:
		from caches.meta_cache import meta_cache
		meta = meta_cache.get('tvshow', 'tvdb_id', tvdb_id)
		if meta and not meta.get('blank_entry'): tmdb = str(meta.get('tmdb_id') or '')
	except Exception: pass
	if (not tmdb or tmdb in _BAD) and fetch:
		try:
			from apis.tmdb_api import _tmdb_json
			found = (_tmdb_json('find/%s' % tvdb_id, external_source='tvdb_id') or {}).get('tv_results') or []
			if found: tmdb = str(found[0].get('id') or '')
		except Exception: pass
	if tmdb and tmdb not in _BAD:
		remember(tmdb, tvdb_id)
		return tmdb
	_log('nomap%s' % tvdb_id, 'tvdb %s has no TMDb id that can be found: its history rows are left out of TMDb-keyed lists' % tvdb_id)
	return None


def key_for_write(tmdb_id, fetch=True):
	"""Storage key for NEW data: 'tvdb<id>' when TVDB-first is on and TVDB knows the show, else the TMDb id (TVDB had nothing)."""
	tmdb_id = str(tmdb_id)
	if tmdb_id.startswith(PREFIX): return tmdb_id
	if not enabled(): return tmdb_id
	tvdb = tvdb_for(tmdb_id, fetch=fetch)
	if tvdb:
		_log('w%s' % tmdb_id, 'storage key for tmdb %s is tvdb%s' % (tmdb_id, tvdb))
		return PREFIX + tvdb
	_log('wn%s' % tmdb_id, 'tmdb %s: TVDB has no id for this show - TMDb id used as the storage key' % tmdb_id)
	return tmdb_id


def read_keys(tmdb_id):
	"""Every key a show's rows may sit under, TVDB key first (always honoured, even when the TVDB-first switch is off later)."""
	tmdb_id = str(tmdb_id)
	if tmdb_id.startswith(PREFIX):
		other = tmdb_for(tmdb_id[len(PREFIX):], fetch=False)
		return [tmdb_id] + ([other] if other else [])
	tvdb = tvdb_for(tmdb_id, fetch=False)
	return ([PREFIX + tvdb] if tvdb else []) + [tmdb_id]


def norm(media_id):
	"""A stored key as the TMDb id string the rest of the add-on uses (None when a TVDB key cannot be mapped)."""
	media_id = str(media_id)
	if not media_id.startswith(PREFIX): return media_id
	return tmdb_for(media_id[len(PREFIX):])
