# -*- coding: utf-8 -*-
"""Puts the Nightshift Home menu selection back on the row the user left.

The skin records the row when the user goes into a section (Nightshift.RootIndex). It cannot restore it itself:
AlarmClock does not evaluate $INFO, so the focus call always reached Kodi with an invalid row and the list fell back
to the top. This service runs the restore with a real number, once per return to the root menu.
"""
import time
import json
import xbmc
import xbmcgui

HOME_WINDOW = 10000
SECTION_PROPERTY = 'Nightshift.Section'
INDEX_PROPERTY = 'Nightshift.RootIndex'
ROOT_LIST = 9000
POLL_SECONDS = 0.15


def _property(name):
	try:
		return str(xbmcgui.Window(HOME_WINDOW).getProperty(name) or '').strip()
	except Exception:
		return ''


def _number(text):
	try:
		return int(float(text))
	except (TypeError, ValueError):
		return 0


def _trace(state):
	"""One log line each time the menu state changes, so a log shows every row change and return to the root menu."""
	xbmc.log('[NIGHTSHIFT menu] %s' % ' '.join('%s=%s' % (k, v) for k, v in state.items()), xbmc.LOGINFO)


AMBIENCE_FILE_PROPERTY = 'nightshift.ambience.playing.file'
SECTION_LIST = 9200


def _visible(condition):
	try:
		return bool(xbmc.getCondVisibility(condition))
	except Exception:
		return False


def run(monitor):
	restored = False
	last = None
	row = 0                                    # last row (1-based) the user was on in the root menu
	home_seen = 0.0                            # last time the Nightshift Home window was in front
	guarded = False
	while not monitor.abortRequested():
		try:
			now = time.time()
			home_active = _visible('Window.IsActive(home)')
			section = _property(SECTION_PROPERTY)
			index_text = _property(INDEX_PROPERTY)
			count = _number(xbmc.getInfoLabel('Container(%d).NumItems' % ROOT_LIST)) if home_active else 0
			position = _number(xbmc.getInfoLabel('Container(%d).CurrentItem' % ROOT_LIST)) if home_active else 0
			label = xbmc.getInfoLabel('Container(%d).ListItem.Label' % ROOT_LIST) if home_active else ''
			root_focused = home_active and _visible('Control.HasFocus(%d)' % ROOT_LIST)
			sub_focused = home_active and _visible('Control.HasFocus(%d)' % SECTION_LIST)
			state = {'home': int(bool(home_active)), 'section': section or '-', 'root_index': index_text or '-',
					 'items': count, 'focus': position, 'focus_label': label or '-', 'root_focus': int(bool(root_focused)),
					 'row': row, 'restored': int(restored)}
			if state != last:
				_trace(state)
				last = state
			if home_active:
				home_seen = now
				guarded = False
				dialog = _visible('System.HasActiveModalDialog') and not _visible('Window.IsActive(busydialog)')
				if section == 'home':
					if root_focused and position > 0:
						row = position                     # remember the row the user is on
					if not restored and count > 0:
						target = row or _number(index_text)
						if 0 < target <= count:
							xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (ROOT_LIST, target - 1))
							_trace({'restore_to_row': target, 'items': count})
						restored = True
					elif restored and not root_focused and not dialog and count > 0:
						xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (ROOT_LIST, max(row, 1) - 1))
						_trace({'focus_repair': 'root', 'row': row})
				else:
					restored = False
					if not sub_focused and not dialog:
						xbmc.executebuiltin('SetFocus(%d)' % SECTION_LIST)   # a section is open: Back must reach its list
						_trace({'focus_repair': 'section', 'section': section})
			else:
				restored = False
			# Background music (ambience / show theme) must never open the now-playing screen, from any window
			if _visible('Window.IsActive(visualisation)'):
				win = xbmcgui.Window(HOME_WINDOW)
				own = win.getProperty(AMBIENCE_FILE_PROPERTY) or win.getProperty('nightshift.theme.playing.file')
				if own and not guarded and not _visible('Player.HasVideo'):
					guarded = True
					if section and section != 'home' and now - home_seen < 3.0:
						win.setProperty(SECTION_PROPERTY, 'home')
					# Never Action(Back) here — it pops plugin history into a blank Videos window.
					# Close only the visualisation overlay when Kodi exposes it as a dialog.
					try:
						xbmc.executebuiltin('Dialog.Close(visualisation,true)')
					except Exception:
						pass
					_trace({'visualisation_blocked': 1, 'section': section or '-'})
			else:
				guarded = False
		except Exception as error:
			xbmc.log('[NIGHTSHIFT] root focus: %s' % error, xbmc.LOGWARNING)
		if monitor.waitForAbort(POLL_SECONDS):
			break



_gate_last = [None]


def _rpc_folder_path():
    """Container.FolderPath via JSON-RPC, the same source the theme service uses."""
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'XBMC.GetInfoLabels',
                                                           'params': {'labels': ['Container.FolderPath']}})))
        return str((reply.get('result') or {}).get('Container.FolderPath') or '').lower()
    except Exception:
        return ''


def _gate_trace(gates, active):
    """Log only when the watcher's gate changes, with the conditions that are not met."""
    missing = tuple(k for k, v in gates if not v)
    if missing == _gate_last[0]:
        return
    _gate_last[0] = missing
    if active:
        xbmc.log('[NIGHTSHIFT TMDb stills] focus watcher active on the rings view', xbmc.LOGINFO)
    else:
        xbmc.log('[NIGHTSHIFT TMDb stills] focus watcher idle, not met: %s' % ', '.join(missing), xbmc.LOGINFO)


def _still_trace(key, image_path):
    xbmc.log('[NIGHTSHIFT TMDb stills] tmdb %s S%sE%s -> %s' % (key[0], key[1], key[2],
             image_path or 'no still (TMDb returned none, or the download failed; see the TMDb lines above)'), xbmc.LOGINFO)


def run_tmdb_episode_focus(monitor):
    """Advance the persistent TMDb still bag only when the focused Rings row changes."""
    last_key = None
    home = xbmcgui.Window(HOME_WINDOW)
    while not monitor.abortRequested():
        try:
            gates = [('510 visible', _visible('Control.IsVisible(510)')), ('510 focused', _visible('Control.HasFocus(510)')),
                     ('ns_focus_rings on', _visible('Skin.HasSetting(ns_focus_rings)')), ('episode source is tmdb', _visible('String.IsEqual(Skin.String(ns_episode_bg_source),tmdb)'))]
            active = all(v for _k, v in gates)
            _gate_trace(gates, active)
            if active:
                # Calendars must not drive the secret still bag (season/episode/My Services only).
                folder = (_rpc_folder_path() or xbmc.getInfoLabel('Container.FolderPath') or xbmc.getInfoLabel('ListItem.FolderPath') or '').lower()
                # No stills while searching or typing (nothing is selected yet): the preload waits for an opened show.
                if any(x in folder for x in ('calendar', 'anilist_public', 'simkl_public', 'build_simkl_public', 'build_anilist_public', 'search')) or _visible('Window.IsActive(virtualkeyboard)') or xbmcgui.Window(10000).getProperty('nightshift.search.open') == '1':
                    if last_key is not None:
                        last_key = None
                        home.clearProperty('nightshift.focused_episode_still')
                        home.clearProperty('nightshift.focused_episode_still_key')
                else:
                    tmdb_id = (xbmc.getInfoLabel('Container(510).ListItem.Property(nightshift.tmdb_id)') or xbmc.getInfoLabel('ListItem.Property(nightshift.tmdb_id)')).strip()
                    season = (xbmc.getInfoLabel('Container(510).ListItem.Property(nightshift.tmdb_season)') or xbmc.getInfoLabel('ListItem.Property(nightshift.tmdb_season)')).strip()
                    episode = (xbmc.getInfoLabel('Container(510).ListItem.Property(nightshift.tmdb_episode)') or xbmc.getInfoLabel('ListItem.Property(nightshift.tmdb_episode)')).strip()
                    try:
                        key = (str(tmdb_id), int(season), int(episode)) if tmdb_id and season and episode else None
                    except Exception:
                        key = None
                    # My Services / Local Folders: resolve SxxExx + show from the filename when listitem has no TMDb props.
                    if not key:
                        try:
                            name = (xbmc.getInfoLabel('Container(510).ListItem.FileName')
                                    or xbmc.getInfoLabel('Container(510).ListItem.Label')
                                    or xbmc.getInfoLabel('ListItem.FileName')
                                    or xbmc.getInfoLabel('ListItem.Label') or '').strip()
                            folder = (xbmc.getInfoLabel('Container(510).ListItem.Property(folder)')
                                      or xbmc.getInfoLabel('ListItem.Property(folder)')
                                      or xbmc.getInfoLabel('Container(510).ListItem.Path')
                                      or xbmc.getInfoLabel('ListItem.Path') or '').strip()
                            if name:
                                from modules.sources import match_browsed
                                match = match_browsed(name, folder)
                                if match and match.get('media_type') == 'episode' and match.get('tmdb_id'):
                                    key = (str(match['tmdb_id']), int(match['season']), int(match['episode']))
                                    try:
                                        from caches.tmdb_random_bag_cache import preload_show_episode_stills
                                        preload_show_episode_stills(match['tmdb_id'])
                                    except Exception:
                                        pass
                        except Exception:
                            key = None
                    if key and key != last_key:
                        from caches.tmdb_random_bag_cache import pick_next
                        image_path = pick_next(key[0], key[1], key[2])
                        _still_trace(key, image_path)
                        # Clear first so Kodi reloads even when the bag returns the same path.
                        home.clearProperty('nightshift.focused_episode_still')
                        home.clearProperty('nightshift.focused_episode_still_key')
                        if image_path:
                            # Local paths need file:// so the skin texture loader accepts them on all platforms.
                            display = image_path
                            if display and not display.startswith(('http://', 'https://', 'image://', 'file://')):
                                display = 'file://' + display
                            home.setProperty('nightshift.focused_episode_still', display)
                            home.setProperty('nightshift.focused_episode_still_key', '%s_%s_%s_%s' % (key[0], key[1], key[2], image_path[-12:]))
                        last_key = key
                    elif not key:
                        last_key = None
                        home.clearProperty('nightshift.focused_episode_still')
                        home.clearProperty('nightshift.focused_episode_still_key')
            else:
                last_key = None
                home.clearProperty('nightshift.focused_episode_still')
                home.clearProperty('nightshift.focused_episode_still_key')
        except Exception as error:
            xbmc.log('[NIGHTSHIFT] TMDb episode focus: %s' % error, xbmc.LOGWARNING)
            last_key = None
            try: home.clearProperty('nightshift.focused_episode_still')
            except Exception: pass
        if monitor.waitForAbort(POLL_SECONDS):
            break
