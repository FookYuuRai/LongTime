# -*- coding: utf-8 -*-
import os
import re
from functools import lru_cache
import json
import base64
import time
import requests
import threading
from string import printable
from threading import Thread
from urllib.parse import unquote, unquote_plus
from caches import watching_cache
from caches.settings_cache import get_setting
from modules.metadata import episodes_meta
from modules.settings import date_offset
from modules.kodi_utils import supported_media, get_property, set_property, notification, logger
from modules.utils import adjust_premiered_date, get_datetime, jsondate_to_datetime, subtract_dates, chunks, normalize as _utils_normalize
from modules.kodi_utils import logger




# ============================ DIAGNOSTIC LOGGING =============================
# Runtime toggle: Tools > Changelog & Log Utils > "Diagnostic Logging"
# ('nightshift.cloud_debug' setting; default OFF = production-quiet).

_DEBUG_KEY = 'nightshift.cloud_debug'

def nzb_debug_enabled():
	"""The separate NZB logging switch (Changelog & Log Utils): the NZB result trace, the other-episode check and the saved-list guard."""
	try: return str(get_setting('nightshift.nzb_debug', 'false')).lower() == 'true'
	except Exception: return False

def diag_enabled():
	return str(get_setting(_DEBUG_KEY, 'false')).lower() == 'true'

# Per-thread mute used while scoring large packs (hundreds of files x several
# CloudMatch/BareEpDebug lines each would flood kodi.log). Thread-local so a
# resolve worker never silences scrapers running on other threads.
_diag_local = threading.local()

TRACE_SINK = None # set by the scrape progress dialog while it is open: receives every scraper trace line (tag, message)

def diag_log(tag, message):
	if getattr(_diag_local, 'quiet', False): return
	sink = TRACE_SINK
	if sink:
		try: sink(tag, message)
		except: pass
	if diag_enabled():
		try: logger(tag, message)
		except: pass

# ============================================================================

# ============================ RD Infringing Files Removal =============================

RELEASE_FILTER_RE = re.compile(
    r'web[\s._-]?dl|web[\s._-]?rip|web[\s._-]?dv|web[\s._-]?hdr'
    r'|bd[\s._-]?rip|hd[\s._-]?rip'
    r'|bluray[\s._-]?(?:rip|x26[45]|h[.\s_-]?264|xvid)'
    r'|(?<![a-z])dv(?![drip])|hdr(?![\s._-]?rip)'  # DV only when NOT part of DVDRip
    r'|amzn',
    re.IGNORECASE
)

RELEASE_SOURCE_RE = re.compile(r'(?:^|[.\s_-])(web|hdtv)(?:$|[.\s_-])', re.IGNORECASE)

_RELEASE_CODEC_INNER = r'(?:hevc|avc|x26[45]|xvid|h[.\s_-]?26[45]|h[.\s_-]?264)'

RELEASE_CODEC_RE = re.compile(r'(?:^|[.\s_-])' + _RELEASE_CODEC_INNER + r'(?:$|[.\s_-])', re.IGNORECASE)

def passes_release_filter(filename):
	name = filename or ''
	if RELEASE_FILTER_RE.search(name):
		return False
	if RELEASE_SOURCE_RE.search(name) and RELEASE_CODEC_RE.search(name):
		return True
	return True

def release_filter_reason(filename):
	name = filename or ''
	if RELEASE_FILTER_RE.search(name):
		m = RELEASE_FILTER_RE.search(name)
		return m.group(0)
	if RELEASE_SOURCE_RE.search(name) and RELEASE_CODEC_RE.search(name):
		codec = RELEASE_CODEC_RE.search(name)
		return 'web/hdtv+%s' % codec.group(0).strip('.-_ ')
	return None

# ============================================================================
# =================== Addon Error / Placeholder Row Filtering ================
# ============================================================================
# Stremio-style addons (Comet / Torz / Torrentio, MediaFusion) sometimes return
# placeholder stream rows — an info-hash with no real filename, and a
# description like "Invalid link" or "Invalid magnet". Kept narrow on purpose:
# broadening to bare 'error'/'fail' substrings risks eating legitimate
# releases, and a missed junk row only costs one failed resolve attempt.

#_INVALID_RELEASE_TOKENS = (
#	'invalid link', 'invalid magnet', 'invalid torrent', 'invalid hash',
#	'invalid stream', 'no streams', 'no video', 'error:', 'failed to',
#	'not cached', 'stream unavailable', 'unavailable stream',
#)

_INVALID_RELEASE_TOKENS = (
	'invalid link', 'invalid magnet', 'invalid torrent', 'invalid hash',
	'invalid stream', 'no streams', 'no video', 'error:', 'failed to',
	'stream unavailable', 'unavailable stream',
)

def is_error_release_name(name):
	"""True when the name is empty, whitespace, or a known addon error/placeholder
	text such as "Invalid magnet" / "Invalid link". Deliberately narrow — no
	hash-blob heuristic, since addons legitimately donate the info-hash as a
	display name for real, playable torrents."""
	if not name or not str(name).strip():
		return True
	text = str(name).lower()
	return any(token in text for token in _INVALID_RELEASE_TOKENS)
	
# ============================================================================
# ============================================================================

def extras():
	return ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers',
			'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')

def unwanted_tags():
	return (
'tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl', 'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li',
'www.tamilrockerrs.pl', 'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org', 'gktorrent-bz', 'gktorrent-com', 'www.torrenting.com', 'www.torrenting.org',
'www-torrenting-com', 'www-torrenting-org', 'katmoviehd.pw', 'katmoviehd-pw', 'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz',
'agusiq-torrents-pl', 'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc', 'www.movcr.tv', 'movcr-com', 'www.movcr.to', '(imax)',
'imax', 'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn', 'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ws', 'www.7movierulz.pw', 'www.8movierulz.ws', 'mkvcinemas.live', 'www.bludv.tv',
'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki', '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com', 'best-torrents-net', '1-3-3-8.com',
'ssrmovies.club', 'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx', 'www.1tamilmv.work', 'www.xbay.me', 'crazy4tv-com', '(es)')

def audio_filter_choices():
	return (
('DOLBY DIGITAL', 'DD'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), 
('DTS', 'DTS'), ('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'),
('8CH AUDIO', '8CH'), ('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'))

def audio_lang_choices():
	# Alphabetical by display name (Sort To Top / filter menu order).
	return (
('ENGLISH AUDIO', 'ENG', ('.eng.', '.english.')),
('FRENCH AUDIO', 'FRE', ('.fre.', '.french.', '.fra.', '.vff.', '.vfq.', '.truefrench.')),
('GERMAN AUDIO', 'GER', ('.ger.', '.german.', '.deu.')),
('HINDI AUDIO', 'HIN', ('.hin.', '.hindi.')),
('ITALIAN AUDIO', 'ITA', ('.ita.', '.italian.')),
('JAPANESE AUDIO', 'JPN', ('.jpn.', '.japanese.', '.jap.')),
('KOREAN AUDIO', 'KOR', ('.kor.', '.korean.')),
('PORTUGUESE AUDIO', 'POR', ('.por.', '.portuguese.', '.dublado.')),
('RUSSIAN AUDIO', 'RUS', ('.rus.', '.russian.')),
('SPANISH AUDIO', 'SPA', ('.spa.', '.spanish.', '.esp.', '.castellano.', '.latino.')))

ENG_OR_UNTAGGED_FILTER = ('ENGLISH OR UNTAGGED', 'ENG-OR-UNTAGGED')

def foreign_audio_lang_tags():
	return frozenset(tag for _, tag, _ in audio_lang_choices() if tag != 'ENG')

def matches_english_or_untagged(tags):
	# ENG tag, or no other audio-language tag (plain English rips are usually untagged).
	tag_set = set()
	for tag in tags or ():
		cleaned = str(tag).replace('[B]', '').replace('[/B]', '').strip()
		if cleaned: tag_set.add(cleaned)
	if 'ENG' in tag_set: return True
	return not tag_set.intersection(foreign_audio_lang_tags())

def audio_lang_filter_entries():
	entries = []
	for name, tag, _ in audio_lang_choices():
		entries.append((name, tag))
		if tag == 'ENG': entries.append(ENG_OR_UNTAGGED_FILTER)
	return tuple(entries)

def source_filters():
	return (
('PACK', 'PACK'), ('DOLBY VISION', '[B]D/VISION[/B]'), ('HIGH DYNAMIC RANGE (HDR)', '[B]HDR[/B]'), ('IMAX', 'IMAX'), ('HYBRID', '[B]HYBRID[/B]'), ('AV1', '[B]AV1[/B]'),
('HEVC (X265)', '[B]HEVC[/B]'), ('REMUX', 'REMUX'), ('BLURAY', 'BLURAY'), ('AI ENHANCED/UPSCALED', '[B]AI ENHANCED/UPSCALED[/B]'), ('SDR', 'SDR'), ('3D', '[B]3D[/B]'),
('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL', 'DD'),
('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('DTS', 'DTS'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'), ('8CH AUDIO', '8CH'),
('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'), ('DVD SOURCE', 'DVD'), ('WEB SOURCE', 'WEB'),
('SUBTITLES', 'SUBS'), ('MULTIPLE LANGUAGES', 'MULTI-LANG')) + audio_lang_filter_entries()

def include_exclude_filters():
	return {'hevc': 'HEVC', '3d': '3D', 'hdr': 'HDR', 'dv': 'D/VISION', 'av1': 'AV1', 'enhanced_upscaled': 'AI ENHANCED/UPSCALED', 'hybrid': 'HYBRID'}

def trailing_noise_extensions():
	# Common container/extension tails after an episode number. Curated — Kodi's
	# supported_media() list is too broad to blanket-include here.
	return ('mkv', 'mk3d', 'avi', 'mp4', 'm4v', 'm2ts', 'ts', 'mpg', 'mpeg', 'webm', 'mov', 'wmv', 'flv', 'vob', 'iso', 'm2v')

def _build_trailing_noise_tokens():
	"""Derive noise tokens from the existing filter-choice defs so tag soup after a
	bare episode number ([1080p][x265][HASH], DDP5.1, BD, FLAC, ENG, mkv, ...) doesn't
	inflate the trailing-name length and demote legitimate strong hits.
	Each source def is isolated: one failing def degrades only itself."""
	tokens = set()

	def _collect(value):
		if not isinstance(value, str): return
		cleaned = value.replace('[B]', '').replace('[/B]', '').lower()
		cleaned = re.sub(r'[^a-z0-9]+', ' ', cleaned).strip()
		if not cleaned: return
		squashed = cleaned.replace(' ', '')
		if len(squashed) >= 3: tokens.add(squashed)   # ddplus, dtshdma, dvision...
		for tok in cleaned.split():
			if len(tok) >= 2: tokens.add(tok)		  # dd, ddp5, dts, hd, ma, eng...

	def _safe(fn):
		try: return fn() or ()
		except Exception: return ()

	# Tuple-aware iteration: unpacks whatever shape each def returns without
	# assuming fixed indices (handles (name, tag), (name, tag, [patterns]),
	# key/value pairs, and flat tuples alike)
	def _harvest(items, value_slots):
		for item in items:
			if not isinstance(item, (list, tuple)):
				_collect(item); continue
			for i in value_slots:
				if i < len(item): _collect(item[i])
			for elem in item:  # patterns nested as lists/dicts inside tuples
				if isinstance(elem, (list, tuple)):
					for sub in elem: _collect(sub)
				elif isinstance(elem, dict):
					for v in elem.values(): _collect(v)

	_harvest(_safe(audio_filter_choices), (1,))
	_harvest(_safe(audio_lang_choices), (1,))
	_harvest(_safe(source_filters), (1,))
	try:
		for v in (include_exclude_filters() or {}).values(): _collect(v)
	except Exception: pass
	for ext in trailing_noise_extensions(): _collect(ext)

	# Safety-net baseline: always present even if every def above changes shape
	_TRAILING_NOISE_TOKENS = frozenset(tokens | frozenset((
		'1080p','1080i','2160p','720p','720i','480p','10bit','8bit','multi','subs','dub','sub',
		'flac','bd','bdrip','crc','hi10','v2','mediainfo',
		# ###FIX### common release tags that counted as "trailing episode-title text" and made a bare
		# absolute number ('- 131 (WEB 1080p x264 AAC)') look like a WEAK hit that was then dropped
		'v3','v4','v5','x264','x265','h264','h265','avc','264','265','ac3','eac3','ddp','ddp5','dd5',
		'5','1','2','0','bit','dual','audio','webrip','webdl','dl','hdtv','dvdrip','uncensored','uncut',
		'remastered','batch','complete','end','final','hq','sdr','hdr10')))
	diag_log('NoiseTokens', 'FINAL total=%d | %s' % (
		len(_TRAILING_NOISE_TOKENS), ' '.join(sorted(_TRAILING_NOISE_TOKENS))))
	return _TRAILING_NOISE_TOKENS

_TRAILING_NOISE_TOKENS = _build_trailing_noise_tokens()
_TRAILING_HEX_HASH_RE = re.compile(r'^[0-9a-f]{8,}$')

# Bracketed noise: 8-char hex CRCs ([123a22b1]) and any 4-24 char bracket group
# containing BOTH a digit and a letter ([BD 1080p FLAC], [x265], [Group D]) .
# Pure-letter groups ([FLAC], [SubsPlease]) and short tags ([BD]) survive here —
# they're handled by the noise-token filter instead.
_CLOUD_BRACKET_NOISE_RE = re.compile(
	r'\[(?:[0-9a-f]{8}|(?=[^\]]{4,24}\])(?=[^\]]*\d)[^\]]*[a-z][^\]]*)\]', re.I)

def _strip_bracket_noise(text):
	try: return _CLOUD_BRACKET_NOISE_RE.sub('.', text)
	except: return text

def _trailing_name_len(rest):
	"""Alphanumeric length of trailing content, ignoring release-tag noise and containers."""
	total = 0
	for tok in re.split(r'[^a-z0-9]+', rest):
		if not tok: continue
		if tok in _TRAILING_NOISE_TOKENS or _TRAILING_HEX_HASH_RE.match(tok): continue
		total += len(tok)
	return total

# Words that name a KIND of release, not a show. An alias made only of these ("The Anime", "Anime", "The Series",
# "The Animation") matched inside any other show's name ("Monster Strike Deadverse Reloaded The Anime S01").
_GENERIC_ALIAS_WORDS = frozenset((
	'the', 'a', 'an', 'of', 'and', 'or', 'anime', 'animation', 'animated', 'animations', 'series', 'show', 'shows', 'tv',
	'movie', 'movies', 'film', 'films', 'ova', 'ovas', 'ona', 'special', 'specials', 'season', 'seasons', 'complete',
	'original', 'new', 'version', 'edition', 'collection', 'cartoon', 'serie', 'saga', 'story', 'part', 'episode',
	'episodes', 'web', 'dub', 'dubbed', 'sub', 'subbed', 'uncut', 'remastered'))

def alias_is_usable(alias):
	"""False for an alias with no distinctive word (only generic words like 'The Anime') or under 3 letters/digits.
	3-letter abbreviations (DBZ, DBS, YYH) stay."""
	try:
		text = normalize(alias or '').lower()
		if len(re.sub(r'[^a-z0-9]', '', text)) < 3: return False
		tokens = [t for t in re.split(r'[^a-z0-9]+', text) if t]
		return any(t not in _GENERIC_ALIAS_WORDS for t in tokens)
	except Exception:
		return bool(alias)

def drop_fragment_aliases(title, aliases):
	"""An alias that is just ONE word taken out of a longer main title ('Boss' for 'A Wild Last Boss Appeared!') is a different
	show's name, not an alternative title for this one. Dropped from the alias list used by every matcher."""
	try:
		tw = [t for t in re.split(r'[^a-z0-9]+', normalize(title or '').lower()) if t]
		if len(tw) < 3: return aliases
		out = []
		for a in aliases or []:
			aw = [t for t in re.split(r'[^a-z0-9]+', normalize((a.get('title') if isinstance(a, dict) else a) or '').lower()) if t]
			if len(aw) == 1 and aw[0] in tw: continue
			out.append(a)
		return out
	except Exception:
		return aliases

def get_aliases_titles(aliases):
	try: result = [__import__('html').unescape(i['title']) for i in aliases if alias_is_usable(i.get('title'))]
	except: result = []
	return result

_ALT_TITLE_COUNTRIES = ('US', 'GB', 'UK', 'JP', '')

def _alt_title_usable(title, iso_3166_1=''):
	"""Keep US/GB/UK/JP/blank alts, plus mostly-Latin names from other regions (romaji-style releases)."""
	if not title: return False
	iso = (iso_3166_1 or '').upper()
	if iso in _ALT_TITLE_COUNTRIES: return True
	try:
		normalized = normalize(title)
		letters = [c for c in normalized if c.isalpha()]
		if len(letters) < 3: return False
		# Basic Latin + Latin-1 Supplement + Latin Extended-A/B — skip CJK/Hangul/Thai/etc.
		latin = sum(1 for c in letters if ord(c) < 0x0250)
		return latin >= int(len(letters) * 0.85)
	except: return False

def filter_alternative_titles(entries, titles_key='results'):
	"""Normalize TMDb movie (titles) / TV (results) alternative_titles into a usable string list."""
	if not entries: return []
	if isinstance(entries, dict):
		alternatives = entries.get(titles_key) or entries.get('titles') or entries.get('results') or []
	else:
		alternatives = entries
	out, seen = [], set()
	for item in alternatives:
		if not isinstance(item, dict): continue
		title = item.get('title') or ''
		if not _alt_title_usable(title, item.get('iso_3166_1', '')): continue
		key = title.casefold()
		if key in seen: continue
		seen.add(key)
		out.append(title)
	return out

def padded_absolute(abs_ep, total=0):
	"""The absolute episode number zero-padded the way releases of a long show write it: 47 of a 131-episode show -> '047'
	(never narrower than 2 digits). '' when padding would not change the number."""
	try:
		abs_ep = int(abs_ep)
		width = max(2, len(str(max(int(total or 0), abs_ep))))
		width = min(width, 4)
		padded = '%0*d' % (width, abs_ep)
		return padded if padded != str(abs_ep) else ''
	except Exception:
		return ''

def folder_title_queries(title, aliases=None):
	"""Cleaned primary title + aliases for cloud folder substring gates."""
	queries, seen = [], set()
	for candidate in [title] + list(aliases or []):
		if not candidate: continue
		if candidate is not title and not alias_is_usable(candidate): continue
		query = clean_title(normalize(candidate))
		# ###FIX### degenerate-query guard — CJK aliases collapse to '', '&', '()',
		# 'xy' after ASCII normalization. A short/non-alphanumeric query matches
		# almost anything as a substring (cross-show contamination).
		if not query or len(query) < 3 or not re.search(r'[a-z0-9]', query): continue
		variants = [query]
		# 'The Tower of Druaga: The Aegis of Uruk' also names a folder 'Tower of Druaga Aegis of Uruk & Sword of Uruk': the same words without the articles
		bare = clean_title(re.sub(r'\b(?:the|a|an)\b', ' ', normalize(candidate), flags=re.I))
		if bare and bare != query and len(bare) >= 6: variants.append(bare)
		for query in variants:
			if query in seen: continue
			seen.add(query)
			queries.append(query)
	return queries

def folder_query_in_name(queries, name):
	"""Word-bounded version of the old 'query in cleaned folder name' substring gate: a folder query (collapsed title, e.g.
	'deathnote') must equal a whole run of words of the name, so 'lost' no longer matches 'Ghost Lost Girl' and
	'Spider-Man' still equals 'Spiderman'."""
	try:
		rel = _filename_tokens(normalize(__import__('html').unescape(name or '')))
		if not rel: return False
		for q in queries or []:
			if not q: continue
			for i in range(len(rel)):
				acc = ''
				for j in range(i, len(rel)):
					acc += rel[j]
					if acc == q: return True
					if len(acc) >= len(q) or not q.startswith(acc): break
	except Exception:
		return True
	return False

def folder_name_matches(folder_name, title, aliases=None):
	cleaned = clean_title(normalize(folder_name or ''))
	if not cleaned: return True
	queries = folder_title_queries(title, aliases)
	return folder_query_in_name(queries, normalize(folder_name or ''))

def episode_rescue_ok(ep_name, name, title, aliases=None):
	"""Episode-name rescue ('this folder / file carries the episode title') - only when the requested show is named too."""
	return bool(ep_name) and episode_title_in_release(ep_name, name) and show_named_in_release(title, name, aliases)

def make_alias_dict(meta, title):
	aliases = []
	alternative_titles = meta.get('alternative_titles', [])
	original_title = meta['original_title']
	cunt_codes = meta.get('country_codes', [])
	country_codes = set([i.replace('GB', 'UK') for i in cunt_codes])
	if alternative_titles: aliases = [{'title': i, 'country': ''} for i in alternative_titles if alias_is_usable(i)]
	if original_title not in alternative_titles: aliases.append({'title': original_title, 'country': ''})
	if country_codes: aliases.extend([{'title': '%s %s' % (title, i), 'country': ''} for i in country_codes])
	# TMDb's English translation + display title, and (anime, Simkl account) Simkl's romaji / English / Latin alt names.
	extra = [meta.get('english_title'), meta.get('title')]
	try:
		from modules.metadata import is_anime_check
		from modules.settings import simkl_user_active
		# Simkl anime title variants disabled (api.simkl.com reserved off; TV calendar is CDN-only).
		if False and meta.get('media_type') != 'movie' and simkl_user_active() and is_anime_check(meta=meta):
			from apis.simkl_api import simkl_anime_titles
			extra += simkl_anime_titles(meta.get('tmdb_id'), meta.get('tvdb_id'), meta.get('imdb_id'))
	except Exception:
		pass
	seen = set(str(a.get('title') or '').casefold() for a in aliases)
	seen.add(str(title or '').casefold())
	for name in extra:
		try:
			if not name or len(re.sub(r'[^a-z0-9]', '', normalize(name).lower())) < 3: continue  # 3 keeps DBZ / DBS / AoT style abbreviations
			if name.casefold() in seen or not alias_is_usable(name): continue
			seen.add(name.casefold())
			aliases.append({'title': name, 'country': ''})
		except Exception:
			continue
	return aliases

def internal_results(provider, sources):
	# every provider (torrent indexers, external, usenet, debrid cloud, folders) ends here: decode HTML entities in release names once
	try:
		_unescape = __import__('html').unescape
		for i in sources or ():
			for k in ('name', 'display_name'):
				v = i.get(k)
				if v and '&' in v and ';' in v: i[k] = _unescape(v)
	except Exception: pass
	drop_cloud_leaks(provider, sources)
	set_property('nightshift.internal_results.%s' % provider, json.dumps(sources))

def normalize(title):
	"""Same accent-fold as modules.utils.normalize (single implementation)."""
	return _utils_normalize(title)

def pack_enable_check(meta, season, episode):
	try:
		status = meta['extra_info']['status']
		if status in ('Ended', 'Canceled'): return True, True
		adjust_hours, current_date = date_offset(), get_datetime()
		episodes_data = episodes_meta(season, meta)
		unaired_episodes = [adjust_premiered_date(i['premiered'], adjust_hours)[0] for i in episodes_data]
		if None in unaired_episodes or any(i > current_date for i in unaired_episodes): return False, False
		else: return True, False
	except: pass
	return False, False

def is_unreleased(media_type, meta):
	"""True when the requested movie / episode has a known premiere date that is still in the future.
	Providers have nothing real for these, so whatever they return is mostly unrelated releases."""
	try:
		# An episode TMDb does not list yet (get_meta flags it) is not out either: its show-level premiere date is in the past.
		if media_type != 'movie' and (meta or {}).get('episode_not_listed'): return True
		premiered = (meta or {}).get('premiered')
		if not premiered: return False
		if media_type == 'movie': release_date = jsondate_to_datetime(premiered, '%Y-%m-%d', remove_time=True)
		else: release_date = adjust_premiered_date(premiered, date_offset())[0]
		return bool(release_date) and release_date > get_datetime()
	except Exception:
		return False

def clear_scrapers_cache(silent=False):
	from caches.base_cache import clear_cache
	for item in ('internal_scrapers', 'external_scrapers'): clear_cache(item, silent=True)
	if not silent: notification('Success')

def supported_video_extensions():
	supported_video_extensions = supported_media().split('|')
	return [i for i in supported_video_extensions if not i in ('','.zip','.rar','.iso')]

def seas_ep_filter(season, episode, release_title, split=False, return_match=False):
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	str_ep_plus_1, str_ep_minus_1 = str(episode+1), str(episode-1)
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	# If the name has an explicit Sxx / NxN season, it must match. Stops S12E01-E02
	# matching S01E02 via episode-only patterns like -e02 (complete show packs).
	season_tags = re.findall(r'(?:^|[.-])s(\d{1,2})[.-]?e', release_title)
	season_tags += re.findall(r'(?:^|[.-])(\d{1,2})x\d', release_title)
	if season_tags:
		requested = {str(int(season)), str_season, season_fill}
		if not any(str(int(tag)) in requested or tag in requested for tag in season_tags):
			if return_match: raise AttributeError('seas_ep season mismatch')
			return False
	string1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
	string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])'#|([s]?<<S>>[x.]<<E>>[.-])'
	string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
	string4 = r'([.-]<<S>>[.-]?<<E>>[.-])'
	string5 = r'(episode[.-]?<<E>>[.-])'
	string6 = r'([.-]e[p]?[.-]?<<E>>[.-])'
	string7 = r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|\d+x\d+).)*$)'
	string8 = r'([s]?<<S>>x<<E>>[.-])'
	string_list = []
	string_list_append = string_list.append
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str_ep_minus_1.zfill(2)).replace('<<E2>>', episode_fill))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str_ep_plus_1.zfill(2)))
	string_list_append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string4.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', str_episode))
	string_list_append(string6.replace('<<E>>', episode_fill))
	string_list_append(string7.replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	final_string = '|'.join(string_list)
	match = re.search(final_string, release_title)
	if split:
		if not match: return release_title
		return release_title.split(match.group(), 1)[1]
	if return_match: return match.group()
	return bool(match)

def seas_ep_filter_exact(season, episode, release_title):
	"""Exact S/E only — for debrid cloud files (no multi-episode pack ranges)."""
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	patterns = (
		r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])',
		r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])',
		r'([.-]<<S>>[.-]?<<E>>[.-])',
		r'(episode[.-]?<<E>>[.-])',
		r'([.-]e[p]?[.-]?<<E>>[.-])',
		r'([s]?<<S>>x<<E>>[.-])',
	)
	string_list = []
	for pattern in patterns:
		for s, e in ((season_fill, episode_fill), (str_season, episode_fill), (season_fill, str_episode), (str_season, str_episode)):
			string_list.append(pattern.replace('<<S>>', s).replace('<<E>>', e))
	return bool(re.search('|'.join(string_list), release_title))

# Cloud filename S/E tokens (left-to-right). Prefer explicit season markers.
# Covers S04E17, S4.E17, S4-E17, S4 -17, S4-17, S4.17, S4 - E17, S6x29, S6xE29, 4x17, up to S04E9999.
# (?!\d) avoids treating long hash tags like S1E123456… as episode numbers.
# Updated to support 4-digit episodes for long-running shows (e.g., One Piece S01E1000).
_CLOUD_SE_TOKEN_RE = re.compile(
	r'(?:'
	r's(\d{1,2})[.-]?e[p]?[.-]?(\d{1,4})(?!\d)'
	# S1E480, S1E9999, S1-E480, S1.e480
	r'|'
	r's(\d{1,2})x(?:e)?(\d{1,4})(?!\d)'
	# S1x480, S1x9999, S1xe480
	r'|'
	r's(\d{1,2})[.-]+(?:e[p]?[.-]*)?(\d{1,4})(?!\d)'
	# S1–E480, S1..480, S1..9999
	r'|'
	r'(\d{1,2})x(\d{1,4})(?!\d)'
	# 1x480, 1x9999
	r')'
)

# Bare episode matching: "e9999", "ep 9999", "episode9999" (up to 4 digits) or standalone numbers.
# Anime-style bare episode only when no Sxx/NxN token exists: "Show - 001 - Title", "Show - 9999.mkv".
# ###FIX### Accept spaces and brackets as valid separators on both sides of bare numbers.
# - Left: start, `.`, `-`, or space  (allows " - 01 ")
# - Right: `.`, `-`, space, `[`, `(`, or end (allows "01 [BD")
_CLOUD_BARE_EP_RE = re.compile(
	r'(?:'
	r'(?:^|[.\-\s])[eE][pP]?[.-]?(\d{1,4})(?:v\d{1,2})?(?![a-z0-9])'
	# E9999, Ep9999, EP-9999  (optional release-version suffix: Ep131v2)
	r'|'
	r'(?:^|[.\-\s])[eE][pP][iI][sS][oO][dD][eE][.-]?(\d{1,4})(?:v\d{1,2})?(?![a-z0-9])'
	# episode9999
	r'|'
	r'(?:^|[.\-\s])(\d{1,4})(?:v\d{1,2})?(?=[.\-\s\[\(]|$)'
	# .9999, -9999, 9999  (optional version suffix: '- 131v2')
	r')'
)

# Empty blocklist — all bare numbers are now accepted.
# Resolution/year filtering is handled per-scraper via context checks.
_BARE_EP_BLOCKLIST = frozenset()

def _normalize_release_title(release_title):
	"""Accent-fold FIRST, THEN strip non-alphanumeric."""
	# ###FIX### normalize() must run BEFORE re.sub to preserve accented letters
	normalized = normalize(release_title or '').lower()
	return re.sub(r'[^a-z0-9-]+', '.', normalized)

def iter_season_episode_tokens(release_title):
	"""Yield (season, episode) pairs from a release/file name, left to right.
	
	Supports 4-digit episodes for long-running shows (e.g., One Piece S01E1000).
	"""
	release_title = _normalize_release_title(release_title)
	for match in _CLOUD_SE_TOKEN_RE.finditer(release_title):
		try:
			if match.group(1) is not None:
				yield int(match.group(1)), int(match.group(2))
			elif match.group(3) is not None:
				yield int(match.group(3)), int(match.group(4))
			elif match.group(5) is not None:
				yield int(match.group(5)), int(match.group(6))
			else:
				yield int(match.group(7)), int(match.group(8))
		except Exception:
			continue

def absolute_episode_from_season_data(season_data, season, episode):
	"""Aired-order absolute episode for season-relative numbering (e.g. DBZ S09E02 → 255).
	When TMDb already uses absolute episode numbers inside a season (One Piece S23E1170), return that episode."""
	try:
		season_i, episode_i = int(season), int(episode)
	except Exception:
		return None
	if not season_data or season_i < 1 or episode_i < 1:
		return None
	try:
		cur = next((i for i in season_data if int(i.get('season_number') or -1) == season_i), None)
		ep_count = int((cur or {}).get('episode_count') or 0)
		# Absolute-style numbers inside the season (episode exceeds that season's count).
		if ep_count and episode_i > ep_count:
			return episode_i
		prior = sum(int(i.get('episode_count') or 0) for i in season_data if 0 < int(i.get('season_number') or -1) < season_i)
		return prior + episode_i
	except Exception:
		return None

_ALT_SE = {}   # (season, episode, absolute) -> {(season, episode), ...}: the other numberings of the SAME episode

def alt_season_episodes(season_data, season, episode, absolute=None):
	"""Other season/episode numberings of the requested episode, from TMDb's season layout: the true absolute number as 'S01E47'
	and the season split that starts after the earlier seasons (absolute 47 -> S04E01 when S01-S03 hold 46 episodes). Never the requested pair."""
	out = set()
	try:
		season_i, episode_i = int(season), int(episode)
		if season_i == 0: return out     # specials (season 0) have no season-layout numbering; their absolute number is not an S01 episode
		abs_i = int(absolute) if absolute not in (None, '', 0, '0') else (absolute_episode_from_season_data(season_data, season_i, episode_i) or 0)
		if abs_i > 0:
			out.add((1, abs_i))
			left = abs_i
			for sd in sorted([i for i in (season_data or []) if int(i.get('season_number') or 0) > 0], key=lambda i: int(i['season_number'])):
				cnt = int(sd.get('episode_count') or 0)
				if cnt and left <= cnt:
					out.add((int(sd['season_number']), left))
					break
				left -= cnt
		out.discard((season_i, episode_i))
	except Exception:
		pass
	return out

def register_alt_se(season, episode, absolute, pairs):
	try: _ALT_SE[(int(season), int(episode), int(absolute or 0))] = set(pairs or ())
	except Exception: pass

def _alt_pairs(season, episode, absolute=None):
	try: return _ALT_SE.get((int(season), int(episode), int(absolute or 0))) or ()
	except Exception: return ()

def alt_gate_pairs(season, episode, absolute=None):
	"""[(season, episode)] of the same episode under its OTHER numbering (TMDb S01E25 = S02E01 by the season split) for the name gates.
	The (S01, absolute) form is left out for later seasons: it would let every S01 release through for any S02 request."""
	out = []
	try:
		season_i = int(season)
		for _s, _e in sorted(_alt_pairs(season, episode, absolute)):
			if int(_s) != season_i and not (int(_s) == 1 and season_i != 1): out.append((int(_s), int(_e)))
	except Exception:
		pass
	return out

def _strip_explicit_se_tokens(release_title):
	"""Return the release name with explicit S#E# / N#N tokens blanked out.
	Lets bare-number parsing find absolute episode numbers in names like
	'Show S04 - 119.mkv' or 'Show S04E119.mkv' without misreading the season."""
	normalized = _normalize_release_title(release_title)
	last_end, parts = 0, []
	for m in _CLOUD_SE_TOKEN_RE.finditer(normalized):
		parts.append(normalized[last_end:m.start()])
		last_end = m.end()
	parts.append(normalized[last_end:])
	return '.'.join(parts)

def iter_bare_episode_numbers(release_title):
	"""Yield bare episode candidates when the name has no explicit season token.

	- Supports up to 4-digit episodes
	- Supports 'e', 'ep', 'episode' prefixes
	- No blocklist (resolution/year filtering is per-scraper via folder context)
	###FIX### Bracketed release-tag noise is stripped first, so hashes like
	[123a22b1] / [E476D313] can't surface as bare or prefixed episode numbers.
	"""
	stripped = _strip_bracket_noise(release_title)
	normalized = _normalize_release_title(stripped)
	if _CLOUD_SE_TOKEN_RE.search(normalized):
		return

	for match in _CLOUD_BARE_EP_RE.finditer(normalized):
		try:
			# Match groups: (1) E#, (2) episode#, (3) bare #
			num = int(match.group(1) or match.group(2) or match.group(3))
		except Exception:
			continue

		if num < 1:
			continue
		yield num

def iter_bare_episode_numbers_anywhere(release_title):
	"""Bare episode candidates even when explicit S#E# tokens exist (tokens stripped first).

	Fixes the absolute-episode blind spot in naming like 'Show S04 - 119.mkv' or
	'Show S04E119.mkv', where the file carries a season marker AND the aired-order
	absolute number. Junk numbers (hashes etc.) are bounded by the target-set check
	at the call site — a false candidate only matters if it equals the requested
	absolute episode.
	###FIX### Brackets are stripped BEFORE the SE-token pass, mirroring
	bare_episode_hits(): the SE stripper receives clean dot-delimited text, and
	bracket-flanked hashes can't donate junk candidates (e.g. a 4-digit CRC
	fragment reading as an absolute episode).
	"""
	stripped = _strip_explicit_se_tokens(_strip_bracket_noise(release_title))
	for match in _CLOUD_BARE_EP_RE.finditer(stripped):
		try:
			num = int(match.group(1) or match.group(2) or match.group(3))
		except Exception:
			continue
		if num < 1:
			continue
		yield num

def parse_episode_from_filename(release_title, season=None):
	"""Parse SxxExx / Sxx - ## / 1x## from a filename; prefer requested season; ignore later hash junk."""
	for s_num, e_num in iter_season_episode_tokens(release_title):
		if season is not None and int(s_num) != int(season):
			continue
		return e_num
	return None

# Max alphanumeric chars allowed after a bare episode number before it's treated
# as part of a name rather than an episode marker. Must stay >= 3 because media
# extensions (.mkv/.avi/.mp4) are exactly 3 chars.

_BARE_EP_TRAILING_LIMIT = 3

def bare_episode_hits(release_title, targets, ep_name=None, title=None, ignore_raw=False):
	notes = []
	
	def _scan(text, label):
		# ###FIX### normalize() must run FIRST (before any regex transforms)
		normalized = normalize(text or '').lower()
		normalized = re.sub(r'(?:^|[.-])season[.-]?\d{1,2}(?=[.-]|$)', '.', normalized)
		normalized = re.sub(r'(?:^|[.-])s[.-]?\d{1,2}(?=[.-]|$)', '.', normalized)
		
		if label == 'strip':
			notes.append('norm=%r' % normalized)
		
		pref, bare = set(), set()
		for match in _CLOUD_BARE_EP_RE.finditer(normalized):
			try:
				num = int(match.group(1) or match.group(2) or match.group(3))
			except Exception:
				continue
			
			if num < 1:
				continue
			
			if match.group(3) is None:
				pref.add(num)
				notes.append('%s.pref=%d' % (label, num))
			else:
				trailing = _trailing_name_len(normalized[match.end():])
				notes.append(
					'%s.bare=%d trailing=%d %s' % (
						label, num, trailing,
						'STRONG' if trailing <= _BARE_EP_TRAILING_LIMIT else 'WEAK'
					)
				)
				bare.add((num, trailing))
		
		return pref, bare
	
	# Strip bracket noise BEFORE normalization
	raw_text = _strip_bracket_noise(release_title)
	stripped_text = _strip_explicit_se_tokens(_strip_bracket_noise(release_title))
	
	try:
		p1, b1 = (set(), set()) if ignore_raw else _scan(raw_text, 'raw')
		p2, b2 = _scan(stripped_text, 'strip')
	except Exception as e:
		diag_log('BareEpDebug', 'file=%r EXCEPTION=%r -> []' % (release_title, e))
		return set()
	
	prefixed = p1 | p2
	
	if prefixed:
		hits = prefixed & targets
		per_target = ['%d=PREF-HIT' % t if t in hits else '%d=PREF-MISS' % t for t in sorted(targets)]
		
		diag_log('BareEpDebug',
			'norm=%r targets=%s -> %s | mode=PREFIXED-AUTHORITATIVE pref=%s bare-ignored=%s | %s | %s' % (
				_normalize_release_title(release_title),
				sorted(targets), sorted(hits),
				sorted(prefixed), sorted({n for n, _ in (b1 | b2)}),
				' '.join(per_target), ' '.join(notes) or '(no candidates)'
			)
		)
		return hits
	
	strong = {num for num, trailing in (b1 | b2) if trailing <= _BARE_EP_TRAILING_LIMIT}
	ep_confirms = bool(ep_name) and episode_name_in_release(ep_name, release_title, title=title)
	weak = {num for num, trailing in (b1 | b2) if trailing > _BARE_EP_TRAILING_LIMIT and ep_confirms}
	hits = (strong | weak) & targets
	
	per_target = []
	bare_nums = {n for n, _ in (b1 | b2)}
	
	for t in sorted(targets):
		if t in strong:
			per_target.append('%d=STRONG-HIT' % t)
		elif t in weak:
			per_target.append('%d=WEAK-HIT(ep-name confirmed)' % t)
		elif t in bare_nums and ep_name and not ep_confirms:
			per_target.append('%d=WEAK-DROPPED(ep_name=%r not confirmed)' % (t, ep_name))
		elif t in bare_nums:
			per_target.append('%d=DROPPED(trailing>limit, no ep_name)' % t)
		else:
			per_target.append('%d=ABSENT' % t)
	
	diag_log('BareEpDebug',
		'norm=%r targets=%s -> %s | mode=BARE ep_confirms=%r | %s | %s' % (
			_normalize_release_title(release_title),
			sorted(targets), sorted(hits), ep_confirms,
			' '.join(per_target), ' '.join(notes) or '(no candidates)'
		)
	)
	
	return hits

# Files that are not episodes (and not specials either): creditless openings / endings, PVs, CMs, trailers, menus.
_NON_EPISODE_RE = re.compile(
	r'(?<![a-z0-9])(?:ncop|nced|nc[\s._-]?(?:op|ed)\d*|creditless|textless|non[\s._-]?credit(?:ed)?|clean[\s._-]?(?:op|ed|opening|ending)\d*'
	r'|(?:op|ed)[\s._-]?\d{1,2}[a-z]?|pv[\s._-]?\d{0,2}|cm[\s._-]?\d{1,2}|trailer|teaser|bumper|menu|promo|sample)(?![a-z0-9])', re.I)
# OVA / OAD / ONA / Special / SP numbered files: 'Show - OVA 01', 'Show OVA1', 'Show - SP01', 'Show Specials - 01'
_SPECIAL_NUM_RE = re.compile(r'(?<![a-z0-9])(?:ova|oad|ona|oav|specials?|sp|recap)[\s._-]*0*(\d{1,3})(?![0-9a-z])', re.I)
_SPECIAL_WORD_RE = re.compile(r'(?<![a-z0-9])(?:ova|oad|ona|oav|specials?|recap)(?![a-z0-9])', re.I)
_SPECIAL_TRAIL_RE = re.compile(r'(?<![0-9a-z.])0*(\d{1,3})[\s._-]*(?:ova|oad|ona|oav)(?![a-z0-9])', re.I)          # '25 OVA'
_SPECIAL_JP_RE = re.compile(r'(?:特別篇|特別編|特別版|番外編|番外篇|総集編|総集篇|特典)[\s._-]*0*(\d{0,3})')       # Japanese special markers
_MOVIE_NUM_RE = re.compile(r'(?<![a-z0-9])(?:movie|film|gekijouban)[\s._-]*0*(\d{1,2})(?![0-9a-z])', re.I)         # 'Show Movie 02' is a film, not an episode
_DECIMAL_EP_RE = re.compile(r'(?:^|[\s._\-\[(]|ep?)0*(\d{1,3})\.5(?![0-9])', re.I)                                 # '06.5': a half episode (recap / special)

def special_numbers(base):
	"""Every special / OVA number a file name states ('OVA 01', 'SP02', '25 OVA', '特別篇', 'Recap 1')."""
	out = [int(m.group(1)) for m in _SPECIAL_NUM_RE.finditer(base)]
	out += [int(m.group(1)) for m in _SPECIAL_TRAIL_RE.finditer(base)]
	out += [int(m.group(1) or 1) for m in _SPECIAL_JP_RE.finditer(base)]
	return out

def is_non_episode_name(path):
	"""True for a creditless OP / ED (NCOP, NCED, Clean Opening ...), PV, CM, trailer or menu file: never an episode or a special."""
	name = str(path or '').replace('\\', '/').rsplit('/', 1)[-1]
	name = re.sub(r'\[[0-9a-f]{8}\]', ' ', name, flags=re.I)
	try: return bool(_NON_EPISODE_RE.search(name))
	except Exception: return False


# ============================ SUB-SERIES TAGS ============================
# A file name can carry its own show tag after the title: 'Ghost in the Shell (Tachikomatic Days) - S01 E01' is a short of the
# sub-series 'Tachikomatic Days', not an episode of the main show. The main show's own tags ('(S.A.C)', '(S.A.C - 2nd Gig)') are
# initials or generic words and are never treated as a sub-series.
_SERIES_TAG_RE = re.compile(r'\(([^()]{2,80})\)')
_SERIES_TAG_EPISODE_START_RE = re.compile(r'(?<![a-z0-9])s\d{1,2}[ ._-]?e\d{1,4}(?![0-9])|(?<![a-z0-9])\d{1,2}x\d{2,4}(?![0-9])', re.I)
_SERIES_TAG_NOISE = frozenset((
    'gig', 'alone', 'complex', 'stand', 'shorts', 'short', 'special', 'specials', 'ova', 'oad', 'ona', 'movie', 'movies',
    'season', 'series', 'part', 'the', 'and', 'of', 'version', 'edition', 'extras', 'bonus', 'english', 'japanese', 'dual',
    'audio', 'multi', 'subbed', 'dubbed', 'dub', 'sub', 'subs', 'uncut', 'remastered', 'repack', 'proper', 'complete',
    'extended', 'director', 'directors', 'cut', 'bluray', 'webrip', 'web', 'hdtv', 'anime', 'dvd'))
_SERIES_SUBTITLE_RE = re.compile(r'\)\s*-\s*([^()\[\]]{3,80}?)\s*(?:[,(\[]|$)')
_EP_SEASON_MARK_RE = re.compile(r'(?<![a-z0-9])(\d{1,2})(?:st|nd|rd|th)[\s._-]*(?:gig|season|series|cour|part)(?![a-z0-9])', re.I)

def _tag_words(text):
    return [w for w in re.split(r'[^a-z0-9]+', _utils_normalize(str(text or '')).lower()) if w]

def _file_series_tags(release_title):
    """Parenthetical tags written before the episode marker of a file name, as lists of words (initials and noise left out)."""
    base = str(release_title or '').replace('\\', '/').rsplit('/', 1)[-1]
    head = _SERIES_TAG_EPISODE_START_RE.split(base, 1)[0]
    out = []
    for m in _SERIES_TAG_RE.finditer(head):
        words = [w for w in _tag_words(m.group(1)) if len(w) >= 3 and w.isalpha()
                 and w not in _SERIES_TAG_NOISE and w not in _TRAILING_NOISE_TOKENS]
        if words: out.append((m.group(1), words))
    if _SERIES_TAG_RE.search(head):
        # after a series tag, a sub-title joined by a dash names the sub-series too:
        # 'Ghost in the Shell (S.A.C) - Tachikomatic Days, 3D 1 (1080p).mp4'. Only with a parenthetical tag first, so
        # 'Show - Episode Title' names are left alone.
        for m in _SERIES_SUBTITLE_RE.finditer(head):
            words = [w for w in _tag_words(m.group(1)) if len(w) >= 3 and w.isalpha()
                     and w not in _SERIES_TAG_NOISE and w not in _TRAILING_NOISE_TOKENS]
            if words: out.append((m.group(1).strip(), words))
    return out

def _ep_name_season_marker(ep_name):
    """Season number an episode title states ('2nd GIG Tachikomatic Days EP01' -> 2). None when it states none (the first season)."""
    text = str(ep_name or '')
    m = _EP_SEASON_MARK_RE.search(text)
    if m: return int(m.group(1))
    o = _ORDINAL_SEASON_RE.search(text)
    if o: return int(o.group(1)) if o.group(1) else _ORDINAL_WORDS.get((o.group(2) or '').lower())
    return None

def series_tag_reject(release_title, season, episode, title=None, aliases=None, ep_name=''):
    """Reason string when the file belongs to a different series or sub-series than the request, else None.

    - foreign tag: the file's own tag names a sub-series that neither the show title, its aliases nor the requested episode title names
      ('(Tachikomatic Days)' for a request of the main show's S01E01).
    - sub-series season: the request's episode title names this sub-series, so the file's S#E# season must be the season that title
      states ('2nd GIG Tachikomatic Days EP01' -> season 2; a title that states none is the first season).
    """
    try:
        if season is None or season == '' or not episode: return None
        tags = _file_series_tags(release_title)
        if not tags: return None
        known = set(_tag_words(title)) | set(_tag_words(ep_name))
        for a in (aliases or []):
            known |= set(_tag_words(a.get('title') if isinstance(a, dict) else a))
        ep_words = set(_tag_words(ep_name))
        se_tokens = list(iter_season_episode_tokens(release_title))
        for raw_tag, words in tags:
            if title and not all(_special_word_in(w, known) for w in words):
                return "foreign series tag (%s): not the requested show, its aliases or the episode title" % raw_tag
            if ep_words and all(w in ep_words for w in words) and se_tokens:
                marker = _ep_name_season_marker(ep_name) or 1
                if se_tokens[0][0] != marker:
                    return "sub-series %s season %d, requested season %d" % (raw_tag, se_tokens[0][0], marker)
    except Exception:
        return None
    return None

def _sub_series_slot_match(release_title, ep_name):
    """True when the file is the requested sub-series episode by its own numbering: the file's tag names the sub-series the episode
    title names, the title's season marker (none = the first season) is the file's season and the title's 'EP<n>' is its episode.
    '(Tachikomatic Days) - S02 E01' is '2nd GIG Tachikomatic Days EP01'; '(Tachikomatic Days) - S01 E01' is 'Tachikomatic Days EP01'."""
    try:
        tags = _file_series_tags(release_title)
        if not tags: return False
        ep_words = set(_tag_words(ep_name))
        if not any(all(w in ep_words for w in words) for _, words in tags): return False
        m = re.search(r'(?<![a-z0-9])(?:ep|episode)[\s._-]*0*(\d{1,3})(?![0-9a-z])', str(ep_name or ''), re.I)
        if not m: return False
        want = (_ep_name_season_marker(ep_name) or 1, int(m.group(1)))
        return any((int(s), int(e)) == want for s, e in iter_season_episode_tokens(release_title))
    except Exception:
        return False

# ============================ SPECIALS AND FILMS BY TITLE ============================
# Aired-order specials and films are named by their own title ('Ghost in the Shell 2: Innocence', 'Ghost in the Shell: Stand Alone
# Complex - Solid State Society', 'Uchikomatic Days'). The distinctive part is the subtitle after the dash or colon; words the show
# title already carries and the franchise words (the, of, Stand Alone Complex) do not count.
_SPECIAL_STOP = frozenset(('the', 'of', 'in', 'a', 'an', 'and', 'stand', 'alone', 'complex', 'sac', 's', 'c'))
_SPECIAL_EXTRA_OK = frozenset(('movie', 'film', 'the', 'of', 'a', 'an', 'dual', 'audio', 'dub', 'sub', 'subs', 'mkv', 'mp4', 'avi', 'bluray', 'web'))
_SPECIAL_SEP_RE = re.compile(r'\s+[-\u2013\u2014]\s+|:\s*')

def _special_subtitle(ep_name):
    parts = [p for p in _SPECIAL_SEP_RE.split(str(ep_name or '')) if p and p.strip()]
    return parts[-1] if parts else str(ep_name or '')

def _special_distinct_words(ep_name, title):
    title_words = set(_tag_words(title))
    return [w for w in _tag_words(_special_subtitle(ep_name)) if w not in title_words and w not in _SPECIAL_STOP and not re.fullmatch(r'(?:ep|episode)\d+', w)]

def _special_word_in(word, file_words):
    if word in file_words: return True
    return any(len(f) >= 6 and len(word) >= 6 and (word.startswith(f) or f.startswith(word)) for f in file_words)

def _special_title_only(ep_name, title):
    """True when the requested special's name carries no word of its own beyond the show title ('Ghost in the Shell' the 1995 film)."""
    try: return not _special_distinct_words(ep_name, title)
    except Exception: return False

def _special_title_match(release_title, title, ep_name):
    """A file with no S#E# token matches a season 0 request when it names the special's distinctive words. When the special's name is
    only the show title, the file must be that bare title (no other words, no episode number), so SP / OVA / sub-series files stay out."""
    try:
        # a numbered sub-series title ('Tachikomatic Days EP01') is matched by its number (S#E#, EP-NAME, SUB-SE); words alone
        # would also take 'Tachikomatic Days, Animax' and 'Tachikomatic Days, 3D 1'
        if re.search(r'(?<![a-z0-9])(?:ep|episode)[\s._-]*\d+(?![0-9])', str(ep_name or ''), re.I): return False
        base = str(release_title or '').replace('\\', '/').rsplit('/', 1)[-1]
        if list(iter_season_episode_tokens(base)): return False
        file_words = _tag_words(base)
        distinct = _special_distinct_words(ep_name, title)
        if distinct:
            return all(_special_word_in(w, file_words) for w in distinct)
        title_words = set(_tag_words(title))
        for w in file_words:
            if w in title_words or w in _SPECIAL_EXTRA_OK: continue
            if re.fullmatch(r'(?:19|20)\d\d', w) or re.fullmatch(r'\d+p', w): continue
            return False
        return bool(title_words) and all(w in file_words for w in title_words)
    except Exception:
        return False

def cloud_episode_matches_all(season, episode, file_name, absolute_episode=None, ep_name='', title=None, container=False):
	"""Returns list of match modes for cloud folder episode matching."""
	from modules.utils import normalize
	
	if season is None or season == '' or not episode:        # season 0 = the specials
		return []
	if is_non_episode_name(file_name):
		diag_log('CloudMatch', 'NON-EPISODE REJECT (NCOP / NCED / PV / trailer ...): file=%r' % file_name)
		return []
	_series_reason = series_tag_reject(file_name, season, episode, title=title, ep_name=ep_name)
	if _series_reason:
		diag_log('CloudMatch', 'SERIES-TAG REJECT: %s | file=%r' % (_series_reason, file_name))
		return []
	_base_name = str(file_name).replace('\\', '/').rsplit('/', 1)[-1]
	_special_num = special_numbers(_base_name)
	if int(season) != 0 and (_special_num or _MOVIE_NUM_RE.search(_base_name) or _DECIMAL_EP_RE.search(_base_name)) and not list(iter_season_episode_tokens(_base_name)):
		return []                       # 'Show - OVA 01', '25 OVA', 'Movie 2', '06.5' are specials / films / half episodes, not an episode of a season
	if release_has_blocked_words(file_name, title or '', None, ep_name or ''):
		diag_log('CloudMatch', 'CHECK-WORD REJECT: file=%r' % file_name)
		return []

	modes = []

	# Strip bracket noise BEFORE any pattern matching
	stripped_name = _strip_bracket_noise(file_name)
	norm_file = normalize(stripped_name).lower()
	file_lower = stripped_name.lower()

	# --- S#E# pattern match (strongest) ---
	# ###FIX### The old pattern r's%de(?:%d|%02d)' only matched an UNPADDED season
	# ('s1e5', 's10e12'), so the standard 'S01E05' never produced an S%E mode.
	# Allow zero-padded season/episode, optional separators, and the NxNN form.
	se_pattern = r'(?<![a-z0-9])(?:s0*%d[.\-_\s]?e[p]?0*%d|0*%dx0*%d)(?!\d)' % (
		int(season), int(episode), int(season), int(episode))
	if re.search(se_pattern, file_lower):
		modes.append('S%E')

	# --- Specials (season 0): 'OVA 01', 'Special 02', 'SP03' in the name, or any number in a Specials / OVA folder ---
	if int(season) == 0:
		if int(episode) in special_numbers(_base_name):
			# a named special ('Tachikomatic Days EP01') is not the file with the same number ('SP 07'): its name words must be in the file too
			_named = _special_distinct_words(ep_name, title) if ep_name else []
			if not _named or all(_special_word_in(w, set(_tag_words(_base_name))) for w in _named):
				modes.append('SPECIAL-NUM')

	# --- Check file's actual S#E# tokens FIRST ---
	file_se_tokens = list(iter_season_episode_tokens(file_name))
	file_episode_num = None
	
	for s_num, e_num in file_se_tokens:
		if s_num == int(season):
			file_episode_num = e_num
			break

	# --- ###FIX### Season-prefixed numbering WITHOUT an 'E': 'S4 - 08', 'S4-08', 'S4.08', 'S04 08' ---
	# The token regex already reads these as (season, episode), but the S%E regex above needs an 'E', so a
	# pack/folder file named just 'S4 - 08.mkv' (no show title, no E) scored nothing. Season AND episode must
	# both equal the target, so 'S4 - 08' never matches S4E18 or S5E08. No show title is required in the name.
	if 'S%E' not in modes and (int(season), int(episode)) in file_se_tokens:
		modes.append('S%E')
		diag_log('CloudMatch', 'S-DASH-E MATCH (season-prefixed, no E): file=%r S%d ep=%d' % (file_name, int(season), int(episode)))
	elif 'S%E' not in modes and re.search(
			r'(?<![a-z0-9])s0*%d[\s._-]+0*%d(?![0-9])' % (int(season), int(episode)), file_lower):
		# 'S4 08' (space-separated; the normalizer turns it into 's4.08' which the token regex also reads, kept as a safety net)
		modes.append('S%E')

	# --- sub-series numbering: '(Tachikomatic Days) - S02 E01' for '2nd GIG Tachikomatic Days EP01' ---
	if _sub_series_slot_match(file_name, ep_name):
		modes.append('SUB-SE')
		diag_log('CloudMatch', 'SUB-SERIES SLOT MATCH: file=%r ep_name=%r' % (file_name, ep_name))

	# --- the same episode under its OTHER numbering (S02E02 = S01E26 = absolute 26): any of them counts ---
	try:
		_alts = set(_alt_pairs(int(season), int(episode), int(absolute_episode or 0)))
		if _alts and 'S%E' not in modes and any((int(a), int(b)) in _alts for a, b in file_se_tokens):
			modes.append('ALT-SE')
	except Exception: pass

	# --- EP-NUM only runs when NO S#E# tokens exist ---
	if not file_se_tokens:
		try:
			ep_nums = [str(episode), str(episode).zfill(2), int(episode)]
		except Exception:
			ep_nums = [str(episode), str(episode).zfill(2)]

		for ep_n in ep_nums:
			ep_pat = r'(?:^|[.\-_])%s(?:[.\-_]|$)' % str(ep_n)
			if re.search(ep_pat, file_lower):
				if 'EP-NUM' not in modes:
					modes.append('EP-NUM')
				diag_log('CloudMatch', 'EP-NUM MATCH (no tokens): file=%r ep=%s' % (file_name, ep_n))
				break
		
		if not any(m in modes for m in ['S%E', 'S%E-alt', 'EP-NUM']):
			diag_log('CloudMatch', 'EP-NUM CHECK (no tokens): file=%r targets=[%d] modes=%s | NONE' % (file_name, int(episode), modes))
	elif file_episode_num is not None and file_episode_num != int(episode):
		diag_log('CloudMatch', 'EP-NUM BLOCKED: file has S%dE%d, requested E%d | file=%r' % (int(season), file_episode_num, int(episode), file_name))

	# --- Numbered file inside a season folder: 'S1 - Aegis of Uruk/02 - Meskia, the City in the Tower.mkv' ---
	# The file name starts with the episode number and carries a title that never equals TMDb's episode title, so the bare-number rule
	# (title text after the number counts as WEAK) drops it. The season folder (or a single-season flat pack) vouches for the number.
	if not modes:
		try:
			_parts = str(file_name).replace('\\', '/').strip('/').split('/')
			_base = _parts[-1]
			_lead = re.match(r'\s*(?:e|ep)?\s*0*(\d{1,4})(?![0-9a-z])', _base, re.I)
			if _lead and int(_lead.group(1)) == int(episode):
				_fseasons = set()
				for _d in _parts[:-1]:
					for _m in re.finditer(r'(?<![a-z0-9])(?:season|series|s)[\s._-]*0*(\d{1,2})(?![0-9])', _d, re.I): _fseasons.add(int(_m.group(1)))
					if re.search(r'(?<![a-z0-9])(?:specials?|ovas?|oads?|extras?)(?![a-z0-9])', _d, re.I): _fseasons.add(0)
				if (_fseasons and int(season) in _fseasons) or (not _fseasons and (int(season) == 1 or (absolute_episode and int(absolute_episode) == int(episode)))):
					modes.append('FOLDER-NUM')
					diag_log('CloudMatch', 'FOLDER-NUM MATCH: file=%r season-folders=%s ep=%d' % (file_name, sorted(_fseasons), int(episode)))
		except Exception:
			pass

	# --- Absolute episode match ---
	if absolute_episode and absolute_episode > 0:
		try:
			abs_i = int(absolute_episode)
		except Exception:
			abs_i = 0

		if abs_i > 0:
			_se_seasons = {s for s, _ in file_se_tokens}
			_ignore_raw = bool(file_se_tokens) and (int(season) == 0 or _se_seasons != {int(season)})
			bare_hits = bare_episode_hits(stripped_name, {abs_i}, ep_name=ep_name, title=title, ignore_raw=_ignore_raw)

			if bare_hits:
				modes.append('ABS-E')
				diag_log('CloudMatch', 'ABS-E SUCCESS: file=%r abs=%d modes=%s' % (file_name, abs_i, modes))
			else:
				diag_log('CloudMatch', 'ABS-E FAILED: file=%r abs=%d ep_name=%r' % (file_name, abs_i, ep_name))

	# --- ###FIX### Ep-name match using PROPER function call (NOT substring) ---
	if ep_name and not (int(season) == 0 and title and (_special_title_only(ep_name, title) or (not all(_special_word_in(w, set(_tag_words(file_name))) for w in _special_distinct_words(ep_name, title))))):
		# Use episode_title_in_release() which HAS Roman ordinal protection via _fuzzy_token_match
		ep_name_matches = episode_title_in_release(ep_name, stripped_name, title=title, container=container)
		if ep_name_matches and episode_numbers_conflict(file_name, season, episode, absolute_episode, title=title, ep_name=ep_name):
			diag_log('CloudMatch', 'EP-NAME BLOCKED: file has another episode number | ep_name=%r file=%r' % (ep_name, file_name))
			ep_name_matches = False

		if ep_name_matches:
			modes.append('EP-NAME')
			diag_log('CloudMatch', 'EP-NAME PROPER MATCH: ep_name=%r file=%r' % (ep_name, file_name))
		else:
			diag_log('CloudMatch', 'EP-NAME NO MATCH: ep_name=%r file=%r' % (ep_name, file_name))

	if int(season) == 0 and title and ep_name and not file_se_tokens and _special_title_match(file_name, title, ep_name):
		modes.append('SPECIAL-TITLE')
		diag_log('CloudMatch', 'SPECIAL-TITLE MATCH: ep_name=%r file=%r' % (ep_name, file_name))

	# Final log
	if modes:
		diag_log('CloudMatch', 'CLOUD-FOLDER FINAL: file=%r abs=%d modes=%s' % (file_name, absolute_episode or 0, modes))
	else:
		diag_log('CloudMatch', 'CLOUD-FOLDER REJECT: file=%r abs=%d modes=[]' % (file_name, absolute_episode or 0))

	return modes

# ============================ PACK CONTENT MATCHING ============================
# Used when a torrent/pack is resolved for ONE episode: pick the right file out of
# the pack's file list and log (diag_log) exactly what was listed and why a file won.

_PACK_EXTRAS_RE = re.compile(
	r'(?<![a-z0-9])(?:sample|trailer|featurette|bloopers?|deleted[\s._-]?scenes?|behind[\s._-]the[\s._-]scenes|making[\s._-]of|extras?)(?![a-z0-9])',
	re.I)
_PACK_FOLDER_SEASON_RE = re.compile(
	r'(?<![a-z0-9])(?:season|series|s)[\s._-]*0*(\d{1,2})(?![0-9])(?!\s*(?:-|~|to)\s*(?:season|s)?\s*\d)',
	re.I)

def _pack_file_gb(size):
	try: return float(size or 0) / 1073741824.0
	except Exception: return 0.0

def _pack_file_name(entry):
	name = entry.get('filename') or ''
	if not name:
		name = (entry.get('path') or '').replace('\\', '/').split('/')[-1]
	return name

def _pack_folder_season(entry):
	"""Season number from the nearest season-looking folder in the file's path (None if unknown)."""
	path = (entry.get('path') or '').replace('\\', '/')
	parts = [p for p in path.split('/') if p][:-1]
	for part in reversed(parts):
		match = _PACK_FOLDER_SEASON_RE.search(part)
		if match:
			try: return int(match.group(1))
			except Exception: continue
	return None

def log_pack_contents(files, label='', limit=5000):
	"""diag_log the video files a pack/folder contains (index, size, path)."""
	if not diag_enabled(): return
	try:
		files = files or []
		diag_log('PackContents', '%s files=%d' % (label, len(files)))
		for idx, entry in enumerate(files[:limit], 1):
			shown = entry.get('path') or _pack_file_name(entry)
			diag_log('PackContents', '  [%d/%d] %.2f GB  %s' % (idx, len(files), _pack_file_gb(entry.get('size')), shown))
		if len(files) > limit:
			diag_log('PackContents', '  ... %d more file(s) not listed' % (len(files) - limit))
	except Exception as e:
		diag_log('PackContents', 'log failed: %s' % type(e).__name__)

def pick_pack_episode_file(files, season, episode, absolute_episode=None, ep_name='', title=None, label='', alt_names=()):
	"""pick_pack_episode_file for the requested numbering first, then for the other numbering of the same episode (a 'Show S02' pack
	holds S02E01 where TMDb says S01E25)."""
	chosen, reason = _pick_pack_episode_file_core(files, season, episode, absolute_episode=absolute_episode, ep_name=ep_name, title=title, label=label, alt_names=alt_names)
	if chosen is None and files:
		for _s, _e in alt_gate_pairs(season, episode, absolute_episode):
			alt, alt_reason = _pick_pack_episode_file_core(files, _s, _e, absolute_episode=None, ep_name=ep_name, title=title, label=label + ' [as S%02dE%02d]' % (_s, _e), alt_names=alt_names)
			if alt is not None: return alt, alt_reason
		# season-relative bare numbers ('Season 2/Show - 01.mkv', '[Group] Show 2nd Season - 01'): the folder or the name states the season
		for _s, _e in alt_gate_pairs(season, episode, absolute_episode):
			hits = []
			for entry in files:
				try:
					name = _pack_file_name(entry)
					if _PACK_EXTRAS_RE.search(entry.get('path') or name): continue
					ordinal = _ORDINAL_SEASON_RE.search(name)
					ordinal_season = (int(ordinal.group(1)) if ordinal.group(1) else _ORDINAL_WORDS.get((ordinal.group(2) or '').lower())) if ordinal else None
					state = ordinal_season if ordinal_season else _pack_folder_season(entry)
					if state != _s: continue
					plain = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', re.sub(r'\.[A-Za-z0-9]{2,4}$', '', name))
					plain = _ORDINAL_SEASON_RE.sub(' ', plain)
					nums = [int(n) for n in re.findall(r'(?<![0-9a-zA-Z])0*(\d{1,3})(?![0-9a-zA-Z])', plain)]
					if nums and nums[-1] == _e: hits.append(entry)
				except Exception: continue
			if len(hits) == 1:
				diag_log('PackMatch', '%s season-relative number: S%02dE%02d -> %r' % (label, _s, _e, _pack_file_name(hits[0])))
				return hits[0], 'SEASON-RELATIVE'
	return chosen, reason

_SEASON_TITLES = {}
_SPECIAL_LINKS = []

def register_special_links(titles):
	"""Names of the other TMDb listing of a special (movie <-> season 0 episode) for the request in progress."""
	global _SPECIAL_LINKS
	_SPECIAL_LINKS = [str(t) for t in (titles or []) if t]

def _special_link_in_name(release_title):
	try:
		base = str(release_title or '').replace('\\', '/').rsplit('/', 1)[-1]
		words = set(re.split(r'[^a-z0-9]+', normalize(base).lower().replace("'", '')))
		for t in _SPECIAL_LINKS:
			tw = [w for w in re.split(r'[^a-z0-9]+', normalize(t).lower().replace("'", '')) if w]
			if len(tw) >= 2 and all(w in words for w in tw): return True
	except Exception: pass
	return False

def register_season_titles(season, titles):
	"""The episode titles TMDb lists for a season, so a pack that holds two numbered sets (1-12 and 1-12) can be told apart by whose file names
	match this season's titles."""
	try: _SEASON_TITLES[int(season)] = [str(t) for t in (titles or []) if t and len(str(t)) > 3]
	except Exception: pass

def _set_votes(candidates, season_i, ep_name):
	"""{directory: number of files in the candidate's directory named after one of this season's episodes (other than the requested one)}."""
	titles = [t for t in _SEASON_TITLES.get(season_i, []) if t.lower() != (ep_name or '').lower()]
	votes = {}
	if not titles: return votes
	for c in candidates:
		d = os.path.dirname(str(c['entry'].get('path') or '').replace('\\', '/'))
		if d in votes: continue
		n = 0
		for e in (c.get('siblings') or ()):
			if os.path.dirname(str(e.get('path') or '').replace('\\', '/')) != d: continue
			nm = _pack_file_name(e)
			if any(episode_title_in_release(t, nm) for t in titles): n += 1
		votes[d] = n
	return votes

def _pick_pack_episode_file_core(files, season, episode, absolute_episode=None, ep_name='', title=None, label='', alt_names=()):
	"""Choose the file for S{season}E{episode} out of a pack listing.

	files: list of dicts with 'filename' and/or 'path' (+ optional 'size', 'link').
	Returns (entry_or_None, reason). None means "no confident single match" -
	the caller should show the manual file picker instead of guessing.
	Every decision is written with diag_log (tag PackMatch).
	"""
	files = files or []
	try:
		season_i, episode_i = int(season), int(episode)
	except Exception:
		diag_log('PackMatch', '%s ABORT bad target season=%r episode=%r' % (label, season, episode))
		return None, 'BAD-TARGET'
	try: abs_i = int(absolute_episode) if absolute_episode else 0
	except Exception: abs_i = 0
	diag_log('PackMatch', '%s START files=%d target=S%02dE%02d abs=%s ep_name=%r title=%r' % (
		label, len(files), season_i, episode_i, abs_i or '-', ep_name, title))
	if not files:
		return None, 'EMPTY'

	candidates, unmatched, extras_skipped = [], [], 0
	_diag_local.quiet = True
	try:
		for entry in files:
			name = _pack_file_name(entry)
			if _PACK_EXTRAS_RE.search(entry.get('path') or name) or is_non_episode_name(entry.get('path') or name):
				extras_skipped += 1
				continue
			try:
				modes = []
				for each_name in dict.fromkeys([ep_name or ''] + [n for n in (alt_names or ()) if n]):
					try:
						for m in cloud_episode_matches_all(season_i, episode_i, name, abs_i or None, each_name, title=title, container=True):
							if m not in modes: modes.append(m)
					except Exception:
						pass
			except Exception:
				modes = []
			folder_season = _pack_folder_season(entry)
			if not modes:
				# '02 - Meskia, the City in the Tower.mkv' inside 'S1 - Aegis of Uruk': the number leads the name, the folder gives the season
				_lead = re.match(r'\s*(?:e|ep)?\s*0*(\d{1,4})(?![0-9a-z])', name, re.I)
				if _lead and int(_lead.group(1)) == episode_i and (folder_season == season_i or (folder_season is None and season_i == 1)):
					modes = ['FOLDER-NUM']
				elif _lead and folder_season is not None:
					try:
						if (folder_season, int(_lead.group(1))) in _alt_pairs(season_i, episode_i, absolute_episode or 0): modes = ['ALT-SE']
					except Exception: pass
			if modes == ['ABS-E'] and folder_season not in (None, season_i):
				modes = []      # an absolute-style number found in another season's folder
			if 'EP-NAME' in modes and folder_season not in (None, season_i) and ep_name_is_weak(ep_name):
				modes = [m for m in modes if m != 'EP-NAME']      # 'Episode 1' of another season's folder
			if 'EP-NAME' in modes and not ep_name_is_weak(ep_name) and folder_season in (None, season_i):
				score = 110 if 'S%E' in modes else 105          # the episode's own title in the file name is checked first
			elif 'SPECIAL-TITLE' in modes: score = 95
			elif 'S%E' in modes or 'SUB-SE' in modes: score = 100
			elif 'ALT-SE' in modes: score = 92
			elif 'SPECIAL-NUM' in modes: score = 90
			elif 'EP-NAME' in modes and 'ABS-E' in modes: score = 95
			elif 'EP-NAME' in modes: score = 85
			elif 'ABS-E' in modes: score = 75
			elif 'FOLDER-NUM' in modes: score = 70 if folder_season == season_i else 45
			elif 'EP-NUM' in modes:
				# bare episode number: only trustworthy when the folder season agrees
				# (or the pack has no season folders at all)
				if folder_season == season_i: score = 60
				elif folder_season is None: score = 45
				else: score = 0
			else: score = 0
			if score > 0:
				candidates.append({'entry': entry, 'name': name, 'score': score, 'modes': modes, 'folder_season': folder_season})
			else:
				unmatched.append((name, modes, folder_season))
	finally:
		_diag_local.quiet = False

	diag_log('PackMatch', '%s SCAN files=%d candidates=%d unmatched=%d extras_skipped=%d' % (
		label, len(files), len(candidates), len(unmatched), extras_skipped))
	for cand in sorted(candidates, key=lambda c: -c['score'])[:15]:
		diag_log('PackMatch', '  CANDIDATE score=%d modes=%s folder_season=%s file=%r' % (
			cand['score'], cand['modes'], cand['folder_season'], cand['name']))
	if not candidates:
		for name, modes, folder_season in unmatched[:25]:
			diag_log('PackMatch', '  NO-MATCH modes=%s folder_season=%s file=%r' % (modes or '[]', folder_season, name))
		if len(unmatched) > 25:
			diag_log('PackMatch', '  ... %d more unmatched file(s) not listed' % (len(unmatched) - 25))
		if len(files) == 1:
			diag_log('PackMatch', '%s SELECT reason=SINGLE-FILE file=%r' % (label, _pack_file_name(files[0])))
			return files[0], 'SINGLE-FILE'
		diag_log('PackMatch', '%s FAIL reason=NO-MATCH (caller should offer the manual picker)' % label)
		return None, 'NO-MATCH'

	best = max(c['score'] for c in candidates)
	if best < 90 and len(candidates) > 1 and _SEASON_TITLES.get(season_i):
		# only numbers matched (no episode title, no S#E#): two numbered sets in one pack are told apart by whose OTHER files carry this
		# season's episode titles - that set is the requested season, even when this one episode is named differently on TMDb
		for c in candidates: c['siblings'] = files
		votes = _set_votes(candidates, season_i, ep_name)
		if votes and max(votes.values()) > 0:
			top = max(votes.values())
			voted = [c for c in candidates if votes.get(os.path.dirname(str(c['entry'].get('path') or '').replace('\\', '/')), 0) == top]
			if voted and len(voted) < len(candidates):
				diag_log('PackMatch', '%s SET-VOTE: %s -> kept %d of %d file(s)' % (label, votes, len(voted), len(candidates)))
				candidates = voted
				best = max(c['score'] for c in candidates)
	tied = [c for c in candidates if c['score'] == best]
	if len(tied) > 1 and _SEASON_TITLES.get(season_i):
		# two numbered sets in one pack (1-12 and 1-12): the set whose other files carry this season's episode titles is the requested season
		for c in tied: c['siblings'] = files
		votes = _set_votes(tied, season_i, ep_name)
		if votes and max(votes.values()) > 0:
			top = max(votes.values())
			voted = [c for c in tied if votes.get(os.path.dirname(str(c['entry'].get('path') or '').replace('\\', '/')), 0) == top]
			if voted and len(voted) < len(tied):
				diag_log('PackMatch', '%s SET-VOTE: %s -> kept %d of %d tied file(s)' % (label, votes, len(voted), len(tied)))
				tied = voted
	if len(tied) > 1:
		same_season = [c for c in tied if c['folder_season'] == season_i]
		if same_season:
			tied = same_season
	if len(tied) > 1 and ep_name:
		# the episode's own title words in the file name break a tie before size does: 'Pilot Part One' beats a plain 'Pilot'
		try:
			need = set(episode_title_keep_tokens(ep_name) or ())
			if need:
				def _title_hits(c): return len(need & set(_filename_tokens(c['name'])))
				top_hits = max(_title_hits(c) for c in tied)
				kept = [c for c in tied if _title_hits(c) == top_hits]
				if len(kept) < len(tied):
					diag_log('PackMatch', '%s TITLE-WORDS: kept %d of %d tied file(s) with %d of %d episode-title word(s)' % (label, len(kept), len(tied), top_hits, len(need)))
					tied = kept
		except Exception:
			pass
	if len(tied) > 1 and best == 95 and any('SPECIAL-TITLE' in c['modes'] for c in tied):
		diag_log('PackMatch', '%s FAIL reason=AMBIGUOUS-TITLE (%d files carry the special title)' % (label, len(tied)))
		return None, 'AMBIGUOUS'
	if len(tied) > 1:
		if best >= 75:
			# duplicate copies of the same episode (e.g. 720p + 1080p encodes): take the largest
			tied.sort(key=lambda c: -float(c['entry'].get('size') or 0))
			reason = 'TIE-LARGEST(score=%d,%d files)' % (best, len(tied))
		else:
			for cand in tied[:10]:
				diag_log('PackMatch', '  AMBIGUOUS score=%d modes=%s folder_season=%s file=%r' % (
					cand['score'], cand['modes'], cand['folder_season'], cand['name']))
			diag_log('PackMatch', '%s FAIL reason=AMBIGUOUS (%d files tie at score=%d)' % (label, len(tied), best))
			return None, 'AMBIGUOUS'
	else:
		reason = 'BEST(score=%d)' % best
	chosen = tied[0]
	diag_log('PackMatch', '%s SELECT reason=%s modes=%s file=%r' % (label, reason, chosen['modes'], chosen['name']))
	return chosen['entry'], reason

# ===============================================================================

def cloud_episode_matches(season, episode, filename, absolute_episode=None, ep_name=None):
	"""Drop-in replacement preserving the old boolean contract."""
	return bool(cloud_episode_matches_all(season, episode, filename, absolute_episode, ep_name, title=None))

def cloud_episode_matches_with_title_override(season, episode, filename, absolute_episode=None, ep_name=None):
	"""Convenience wrapper for cloud scrapers doing folder-gated loose matching.
	Identical to calling cloud_episode_matches() with the ep_name parameter."""
	return cloud_episode_matches(season, episode, filename, absolute_episode, ep_name)

def episode_tokens_match(season, episode, release_title, absolute_episode=None, ep_name=None):
	"""Token (S#E# / NxN) match, or bare episode == absolute number. No folder/title context.

	###FIX### ep_name parameter (optional): forwarded to bare_episode_hits() so a
	'weak' bare hit (delimited number with >3 trailing content chars, e.g.
	'Clean Ending 1 - Hello Hello Hello') only counts when the ep_name tokens
	confirm it. Callers without ep_name keep the strict behaviour.
	"""
	try:
		season_i, episode_i = int(season), int(episode)
	except Exception:
		return False
	token_pairs = list(iter_season_episode_tokens(release_title))
	for s_num, e_num in token_pairs:
		if s_num == season_i and e_num == episode_i:
			return True
	if absolute_episode is not None:
		try:
			abs_i = int(absolute_episode)
		except Exception:
			return False
		if abs_i > 0:
			# ###FIX### bare_episode_hits(): prefixed markers authoritative, season-path
			# numbers blanked, weak bare hits require ep_name confirmation
			if bare_episode_hits(release_title, {abs_i}, ep_name): return True
			# 'Show S04E119.mkv' naming: token episode equals the absolute number
			if any(s == season_i and e == abs_i for s, e in token_pairs):
				return True
	return False

def find_season_in_release_title(release_title):
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	match = None
	regex_list = [r's(\d+)', r's\.(\d+)', r'(\d+)x', r'(\d+)\.x', r'season(\d+)', r'season\.(\d+)']
	for item in regex_list:
		try:
			match = re.search(item, release_title)
			if match:
				match = int(str(match.group(1)).lstrip('0'))
				break
		except: pass
	return match

# ============================== PACK MARKERS ==============================
# Single source of truth for the WHOLE WORDS that mark a release name as a pack.
# check_title(), should_accept_file_title() and native_torrents.pack_type_from_name()
# all use this list; add a word here and every pack decision picks it up.
# Matching is whole-word: 'eps' hits 'Eps 083 - 118' but not 'Steps' / 'Creeps'.
# Spaces inside a marker match any of ' ', '.', '_' or '-' (release names are dotted).
SEASON_PACK_MARKERS = (
	'all episodes', 'full season', 'entire season', 'season pack', 'full pack', 'complete season',
	'complete collection', 'box set', 'boxset', 'all seasons', 'all season', 'complete', 'collection',
	'seasons', 'episodes', 'eps', 'batch',
)
# Weak markers say "several episodes" but not "several seasons" (used to pick 'season' over 'show')
WEAK_PACK_MARKERS = frozenset(('eps', 'episodes', 'batch'))

_PACK_MARKER_RE = re.compile(
	r'(?<![a-z0-9])(?:%s)(?![a-z0-9])' % '|'.join(
		r'[\s._-]+'.join(re.escape(word) for word in marker.split(' '))
		for marker in sorted(SEASON_PACK_MARKERS, key=len, reverse=True)),
	re.I)
# 'Eps 083 - 118' / 'Episodes 1-24' (a range after the word is what makes 'eps' a pack)
_PACK_EPS_RANGE_RE = re.compile(
	r'(?<![a-z0-9])(?:eps?|episodes?)[\s._-]*\d{1,4}\s*(?:-|~|\bto\b)\s*\d{1,4}(?![0-9])', re.I)
# A specific episode: S01E05, s1.e5, 1x05
_EXPLICIT_EPISODE_RE = re.compile(r'(?<![a-z0-9])(?:s\d{1,3}[\s._-]?e\d{1,4}|\d{1,2}x\d{2,4})(?!\d)', re.I)

def pack_marker_hits(text):
	"""Every SEASON_PACK_MARKERS word found in text (lowercased, single-spaced)."""
	return [re.sub(r'[\s._-]+', ' ', m.group(0).lower()) for m in _PACK_MARKER_RE.finditer(text or '')]

def has_pack_marker(text):
	return bool(_PACK_MARKER_RE.search(text or ''))

def has_explicit_episode_token(text):
	return bool(_EXPLICIT_EPISODE_RE.search(text or ''))

# ===========================================================================

def release_has_blocked_words(release_title, title='', aliases=None, ep_name=''):
	"""True when the release name holds a check word (_CHECK_WORDS, whole word) that the show title, its aliases
	or the episode name do not hold themselves. Runs for every scraper and search path (check_title and
	should_accept_file_title), not only inside the episode-name match."""
	try:
		text = normalize(release_title or '').lower()
		found = {m.group('check_word').lower() for m in _CHECK_WORDS_RE.finditer(text)}
		if 'ass' in found and re.search(r'(?<![a-z0-9])(?:soft|hard)?subs?(?![a-z0-9])', text): found.discard('ass')  # the subtitle format
		if not found: return False
		own = ' '.join(normalize(x or '').lower() for x in [title, ep_name] + list(aliases or []))
		own_tokens = set(re.split(r'[^a-z0-9]+', own))
		return any(w not in own_tokens for w in found)
	except Exception:
		return False

_GENERIC_EP_WORDS = frozenset(('episode', 'ep', 'chapter', 'part', 'e'))

_TITLE_STOP_RE = re.compile(
	r'^(?:s\d+(?:e\d+(?:-?e?\d+)?)?|e\d+|ep\d+|\d+x\d+|\d+|\d+p|\d+i|season|series|episode|complete|batch|web|webdl|webrip|'
	r'bluray|bdrip|brrip|hdtv|dvdrip|x26[45]|h26[45]|hevc|avc|aac\d*|ac3|eac3|dts|remux|multi|dual|proper|repack|uhd|hdr\d*|4k|nf|amzn|dsnp)$')

def _title_in_release(title, release_title, aliases=None, ep_name=None):
	"""The REQUESTED show is the show in the file name: its title (or an alias) is the whole start of the name (after
	[group] tags) and what follows is a number / season / quality tag / the episode name - never more title words, so
	'Lost' is not 'Lost Girl'."""
	try:
		rel = _filename_tokens(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or ''))
		en = _filename_tokens(ep_name or '')
		for cand in [title] + [a for a in (aliases or []) if alias_is_usable(a)]:
			tt = _filename_tokens(cand or '')
			n = len(tt)
			if not n or rel[:n] != tt: continue
			rest = rel[n:]
			if not rest or _TITLE_STOP_RE.match(rest[0]): return True
			after = rest
			while after and after[0].isdigit(): after = after[1:]
			if en and after[:len(en)] == en: return True
	except Exception:
		pass
	return False

def _starts_with_title(title, release_title):
	"""The file name starts with the show title's words (after [group] tags). Used for specials, whose distinctive words the
	matcher has already checked: a dash subtitle after the title ('Ghost in the Shell - Uchikoma Days') is then allowed."""
	try:
		rel = _filename_tokens(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or ''))
		tt = _filename_tokens(title or '')
		return bool(tt) and rel[:len(tt)] == tt
	except Exception:
		return False

def show_named_in_release(title, release_title, aliases=None):
	"""Floor for torrent / usenet style results: the requested show's title (or a usable alias) must appear in the release
	name as a contiguous run of words, anywhere (after [group] tags, inside '(...; Alt Title)', after a site prefix). A
	file that only carries an episode NAME ('Rebirth.S01E01') or only an episode number can never prove it is this show,
	so it is dropped. 'and' / 'the' are ignored on both sides ('Welsh & Shedar' == 'Welsh Shedar')."""
	try:
		drop = ('and', 'the')
		norm = lambda text: [t for t in _filename_tokens(__import__('html').unescape(text or '')) if t not in drop]
		rel = norm(release_title)
		if not rel: return False
		for cand in [title] + [a for a in _with_article_variants(title, aliases) if alias_is_usable(a)]:
			tt = norm(cand)
			n = len(tt)
			if not n: continue
			for i in range(len(rel) - n + 1):
				if rel[i:i + n] == tt: return True
	except Exception:
		return True # never hide results because of an internal error here
	return False

# Anime indexers (nyaa) often name a release '[Group] <original/romaji series name> <show title> 01': extra words IN FRONT of
# the requested show title, and only the absolute number after it. _title_in_release() wants the title to lead, so those were
# dropped. This rule lets exactly that shape through - and nothing looser:
#   - the show title (or a usable alias) must have at least 2 distinctive words (so 'Lost' / 'Girl' can never ride it)
#   - at most 3 plain words (letters only) may precede it, none of them a spin-off / season / quality / extras word
#   - the title run must be contiguous and followed DIRECTLY by the episode number, equal to the requested absolute
#     number (or the episode number in season 1); more title words after it ('... Origins 01') keep it out
#   - an explicit S#E# for another episode, or a number that is not the requested one, rejects it
_PREFIX_TITLE_FILLER = frozenset(('and', 'the', 'of', 'a', 'an', 'no', 'wa', 'ga', 'to', 'ni', 'wo', 'in', 'on'))
_SERIES_PREFIX_BLOCK = frozenset((
	'another', 'new', 'next', 'return', 'returns', 'side', 'story', 'stories', 'gaiden', 'origin', 'origins', 'prequel', 'sequel',
	'spinoff', 'ova', 'oad', 'ona', 'oav', 'special', 'specials', 'recap', 'recaps', 'movie', 'film', 'part', 'cour', 'chapter',
	'season', 'seasons', 'series', 'episode', 'episodes', 'complete', 'batch', 'collection', 'boxset', 'extra', 'extras',
	'sample', 'trailer', 'preview', 'pv', 'cm', 'op', 'ed', 'ncop', 'nced', 'menu', 'bonus', 'making', 'behind', 'live', 'concert',
	'drama', 'manga', 'ost', 'soundtrack', 'music', 'game', 'dub', 'dubbed', 'sub', 'subbed'))
_SERIES_PREFIX_MAX_WORDS = 5
_ABS_NUMBER_TOKEN_RE = re.compile(r'^0*(\d{1,4})(?:v\d+)?$')

def title_with_series_prefix_and_abs(title, release_title, aliases, absolute_episode, season=None, episode=None):
	try:
		wanted = set()
		for value in (absolute_episode, episode if str(season) == '1' else None):
			try:
				if value and int(value) > 0: wanted.add(int(value))
			except Exception: pass
		if not wanted: return False
		rel = _filename_tokens(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or ''))
		if not rel: return False
		for cand in [title] + [a for a in (aliases or []) if alias_is_usable(a)]:
			tt = _filename_tokens(__import__('html').unescape(cand or ''))
			n = len(tt)
			if len([t for t in tt if t not in _PREFIX_TITLE_FILLER]) < 2: continue
			for start in range(0, _SERIES_PREFIX_MAX_WORDS + 5):
				if rel[start:start + n] != tt: continue
				prefix = rel[:start]
				# a stray 'and' can lead the name when a CJK title with '&' was stripped to nothing; it is not a word
				words = [t for t in prefix if t != 'and' and t not in _PREFIX_TITLE_FILLER]
				if len(words) > _SERIES_PREFIX_MAX_WORDS: continue # start == 0: the (long) title itself leads, e.g. 'Aoki Denshou Welsh & Shedar 01' with no absolute number known
				if any((not t.isalpha()) or len(t) < 2 or t in _SERIES_PREFIX_BLOCK or _TITLE_STOP_RE.match(t) for t in words): continue
				rest = rel[start + n:]
				m = _ABS_NUMBER_TOKEN_RE.match(rest[0]) if rest else None
				if not m or int(m.group(1)) not in wanted: continue
				# the number must stand alone: '01 02' / '1 2' (ranges, sequels, '2 01') are not this episode; only a resolution may follow
				if len(rest) > 1 and rest[1].isdigit() and rest[1] not in ('480', '576', '720', '1080', '2160'): continue
				tokens = list(iter_season_episode_tokens(release_title))
				if tokens and not any(int(e) in wanted for s, e in tokens): continue
				if release_has_blocked_words(release_title, title, aliases, ''): return False
				return True
	except Exception:
		pass
	return False

def ep_name_is_weak(ep_name):
	"""An episode name that names no episode by itself: a single distinctive word, or only 'Episode' / 'Episode 5'."""
	distinct = [t for t in _filename_tokens(ep_name)
		if t not in _EP_TITLE_STOPWORDS and t not in _GENERIC_EP_WORDS and not t.isdigit()]
	return len(distinct) < 2

def weak_name_blocked(ep_name, release_title, title, container=False, aliases=None):
	"""A weak episode name only counts when the show title is in the file name too - except inside a pack, folder,
	cloud folder or local folder (container), where the folder already says which show it is."""
	if container or not title or not ep_name or not ep_name_is_weak(ep_name): return False
	return not _title_in_release(title, release_title, aliases, ep_name)

def episode_numbers_conflict(release_title, season, episode, absolute_episode=None, title=None, aliases=None, ep_name=None):
	"""True when the name carries an explicit S#E# for the requested season but another episode, and no absolute
	number equal to the requested one. An episode-NAME hit must not accept such a stray episode - unless the show
	title is in the name as well (then the episode name decides, whatever the numbers say)."""
	try:
		if not season or not episode: return False
		weak = ep_name_is_weak(ep_name) if ep_name is not None else False
		if title and not weak and _title_in_release(title, release_title, aliases, ep_name): return False
		tokens = list(iter_season_episode_tokens(release_title))
		if weak:
			# 'Episode 1' / one-word names say nothing: any explicit S#E# decides, whatever the season
			if not tokens or (int(season), int(episode)) in tokens: return False
			if absolute_episode:
				try:
					if int(absolute_episode) in [e for s, e in tokens]: return False
				except Exception: pass
			return True
		same_season = [e for s, e in tokens if s == int(season)]
		if not same_season or int(episode) in same_season: return False
		if absolute_episode:
			try:
				if int(absolute_episode) in same_season: return False
			except Exception: pass
		return True
	except Exception:
		return False

def _word_in(needle, haystack):
	"""needle occurs in haystack on word boundaries (both are dot/space separated lowercase names)."""
	if not needle: return False
	return re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(needle), haystack) is not None


# ---- movies: the release must be THIS film -------------------------------------------------------------------------
# check_title() used to accept a movie when its title stood anywhere in the name, so 'Keeping Up With The Kardashians
# S15E04 The Nightmare Before Christmas' and 'Resident Evil Retribution 2012' were listed for other searches.
_MOVIE_EPISODE_TOKEN_RE = re.compile(r'^(?:s\d{1,3}(?:e\d{1,4})+|s\d{2}|\d{1,2}x\d{2,4}|e\d{2,4})$')
_MOVIE_YEAR_RE = re.compile(r'^(?:19|20)\d\d$')
_MOVIE_ARTICLES = frozenset(('the', 'a', 'an'))
_MOVIE_SKIP = frozenset(('the', 'a', 'an', 'of', 'and', 'in', 'on', 'to'))
# the first of these ends the title part of a release name (quality, source, codec, language, repack marks)
_MOVIE_JUNK_RE = re.compile(
	r'^(?:\d{3,4}p|\d{3,4}i|\d{3,4}x\d{3,4}|4k|8k|uhd|hdr\d*|dv|dovi|sdr|bluray|blu|ray|bd\w*|br\w*|web|webdl|webrip|hd\w*|dvd\w*|'
	r'cam\w*|ts|tc|telesync|x26[45]|h26[45]|hevc|avc|xvid|divx|av1|aac\d*|ac3|eac3|dts\w*|dd\w*|ddp\w*|atmos|truehd|flac|remux|'
	r'proper|repack|internal|multi|dual|subs?|subbed|dubbed|nf|amzn|dsnp|hmax|atvp|hulu|pcok|10bit|8bit|imax|hsbs|3d|'
	r'french|german|spanish|italian|truefrench|vff|vostfr|eng|english|nordic|swedish|hindi|korean|japanese|russian|'
	r'complete|1080|720|2160|480|576)$')
# words that may stand between the title and the quality tags without making it another film
_MOVIE_EDITION = frozenset((
	'extended', 'unrated', 'uncut', 'remastered', 'theatrical', 'directors', 'director', 'cut', 'special', 'edition',
	'ultimate', 'final', 'collectors', 'anniversary', 'restored', 'criterion', 'open', 'matte', 'imax', 'redux', 'rerelease',
	'version', 'alternate', 'alt', 'ending', 'collection', 'limited', 'new', 'hd', 'full', 'movie', 'film', 'rip'))


def _movie_words(text):
	text = normalize(text or '').lower().replace("'", '').replace('’', '').replace('&', ' and ')
	return [w for w in re.split(r'[^a-z0-9]+', text) if w]


def _find_words(needle, hay, skip):
	"""(start, end) of the first place `needle` (a word list) stands in `hay` as a run; with `skip` set, articles and
	little joiner words (the, of, and ...) are ignored on both sides."""
	if skip:
		keep = [i for i, w in enumerate(hay) if w not in _MOVIE_SKIP]
		hay_k = [hay[i] for i in keep]
		need = [w for w in needle if w not in _MOVIE_SKIP]
	else:
		keep, hay_k, need = list(range(len(hay))), hay, needle
	if not need:
		return None
	for i in range(len(hay_k) - len(need) + 1):
		if hay_k[i:i + len(need)] == need:
			return keep[i], keep[i + len(need) - 1] + 1
	return None


def movie_release_ok(title, release_title, aliases, year):
	"""True when the release name is THE film asked for: its title (or an alias) leads the name, there is no season /
	episode mark, and a year in the name is the film's year (a year apart is allowed). Names without a year must have
	nothing but quality tags and edition words after the title."""
	try:
		low = strip_non_ascii_and_unprintable(release_title or '').lower()
		low = re.sub(r'^\s*(?:\[[^\]]*\]|\([^)]*\))\s*', '', low)           # a leading [group] tag
		words = _movie_words(low)
		if not words:
			return False
		try:
			want = int(str(year)[:4])
		except (TypeError, ValueError):
			want = 0
		titles = [t for t in [title] + [a for a in (aliases or []) if alias_is_usable(a)] if t]
		best = None
		for t in titles:
			need = _movie_words(t)
			if not need:
				continue
			for skip in (False, True):
				span = _find_words(need, words, skip)
				if span and (best is None or span[0] < best[0]):
					best = span
				if span:
					break
		if best is None:
			return False
		start, end = best
		prefix, rest = words[:start], words[end:]
		# a season / episode mark outside the title (inside it, 'Star Wars Episode 4' is just the film's name)
		outside = prefix + rest
		for i, w in enumerate(outside):
			if _MOVIE_EPISODE_TOKEN_RE.match(w) or (w in ('season', 'episode', 'seasons', 'episodes') and i + 1 < len(outside) and outside[i + 1].isdigit()):
				return False
		# years in the name outside the title: one of them must be the film's
		years = [int(w) for w in prefix + rest if _MOVIE_YEAR_RE.match(w)]
		if years and want and not any(abs(y - want) <= 1 for y in years):
			return False
		has_year = bool(years)
		# words before the title: a short studio / possessive lead ('Tim Burtons ...') only when the year agrees
		lead = [w for w in prefix if w not in _MOVIE_ARTICLES and not _MOVIE_YEAR_RE.match(w) and not _MOVIE_JUNK_RE.match(w)]
		if lead and (not has_year or len(lead) > 3):
			return False
		# words after the title before the first year / quality tag
		extra = []
		for w in rest:
			if _MOVIE_YEAR_RE.match(w) or _MOVIE_JUNK_RE.match(w):
				break
			extra.append(w)
		if extra and not has_year and not all(w in _MOVIE_EDITION for w in extra):
			return False
		if extra and has_year and len(extra) > 4 and not all(w in _MOVIE_EDITION for w in extra):
			return False
		return True
	except Exception:
		return True


def check_title(title, release_title, aliases, year, season, episode):
	import re
	if release_has_blocked_words(release_title, title, aliases):
		return False
	# movies: the release must be this film (title leads, no episode mark, year agrees)
	if not season:
		return movie_release_ok(title, release_title, aliases, year)
	
	try:
		all_titles = [title]
		if aliases:
			all_titles += [a for a in aliases if alias_is_usable(a)]
		cleaned_titles = []
		cleaned_titles_append = cleaned_titles.append
		year = str(year)
		for i in all_titles:
			# ###FIX### Accent-fold the show title/aliases the same way the release name is
			# folded (strip_non_ascii_and_unprintable below). 'Pokémon' could never match
			# 'Pokemon ...' before, so only aliases could rescue accented titles.
			# Empty results are skipped: '' is a substring of everything.
			cleaned = normalize(i or '').lower().replace('\'', '').replace(':', '').replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, '')
			if cleaned:
				cleaned_titles_append(cleaned)
		release_title = strip_non_ascii_and_unprintable(release_title).lstrip('/ ').replace('\'', '').replace('\u2019', '').replace(' ', '.').replace('_', '.').replace(':', '.').lower()   # the title's apostrophes are dropped above: the release's must be too ("Returner's" == "Returners")
		releasetitle_startswith = release_title.startswith
		unwanted = unwanted_tags()
		# one tuple check first: nearly every name starts with none of the ~100 spam tags, so skip the loop outright
		for i in (unwanted if releasetitle_startswith(tuple(unwanted)) else ()):
			if releasetitle_startswith(i):
				i_startswith = i.startswith
				pattern = r'\%s' % i if i_startswith('[') or i_startswith('+') else r'%s' % i
				release_title = re.sub(r'^%s' % pattern, '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-:/')
		release_title = re.sub(r'^\[.*?]', '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-[](){}:/')

		# ===== PACK DETECTION BLOCK =====
		# Detect complete/whole-season packs by common patterns
		is_pack = False
		release_lower = release_title.lower()

		# Explicit "complete" marker
		if 'complete' in release_lower:
			is_pack = True

		# Multi-season patterns: seasons 1-5, s1-5, s1.s5, SEASON 1 TO 5, etc.
		# Note: plural 'seasons', dot-separated, hyphen-separated, 'to' keyword
		multi_season_patterns = [
			# season 1 to season 5, seasons 1- seasons 5
			r'seasons?\s*\d+\s*(?:[-_.~]+|to)\s*seasons?\s*\d+',

			# season 1-5, season.1.5, season 1 to 5
			r'seasons?\s*\d+\s*(?:[-_.~]+|to)\s*\d+',

			# s1-5, s1.s5, s1 to s5
			r's\d+\s*(?:[-_.~]+|to)\s*s?\d+',

			# 1-5, 1 to 5 episodes, 1-5 seasons
			r'\b(\d+)\s*(?:[-_.~]+|to)\s*(\d+)\s*(?:episodes?|seasons?)?\b',

			# all, all parts, all episodes, all seasons
			r'all(?:\s+parts?|\s+episodes?|\s+seasons?)?',

			# full season, complete set, full collection
			r'(?:full|complete)\s+(?:seasons?|(?:set|collection))',
		]

		is_pack = False

		for pattern in multi_season_patterns:
			if re.search(pattern, release_lower, re.IGNORECASE):
				is_pack = True
				break

		# Whole season pack markers (whole-word; see SEASON_PACK_MARKERS)
		if has_pack_marker(release_lower):
			is_pack = True

		# Season passed as 'pack' from caller (native_torrents.py)
		if season == 'pack':
			is_pack = True
		# ================================

		if season:
			if season == 'pack':
				hdlr = ''
			else:
				try:
					hdlr = seas_ep_filter(season, episode, release_title, return_match=True)
				except:
					return False
		else:
			hdlr = year

		if hdlr:
			release_title = release_title.split(hdlr.lower())[0]
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			# Episodes: exact show title before SxxExx (Wings must not match Behind The Wings / Super Wings).
			if season and season != 'pack':
				if not any(release_title == i for i in cleaned_titles):
					return False
			elif not any(_word_in(item, release_title) for item in cleaned_titles):
				return False
		else:
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')

			# ===== PACK RELAXATION =====
			# For packs, accept title substring match (more lenient than exact match)
			if is_pack:
				# Title must be contained somewhere in the filename (whole words: 'the.anime' is not inside 'x.the.animedia')
				if not any(_word_in(item, release_title) for item in cleaned_titles):
					return False
			else:
				if not any(_word_in(i, release_title) for i in cleaned_titles):
					return False
			# ===========================
		return True
	except Exception as e:
		try:
			logger('check_title error', '%s | %r' % (e, release_title))
		except:
			pass
		return False

_EP_TITLE_STOPWORDS = frozenset((
	'a', 'an', 'the', 'of', 'and', 'or', 'to', 'in', 'on', 'at', 'for', 'from', 'with', 'vs', 'v1', 'v2', 'v3', 'repack',
	'part', 'episode', 'season',  # ###FIX### generic in multi-part / serialized titles
))


# Blocklist words: make a "UI" setting to input through menu
_CHECK_WORDS = frozenset((
    # Original terms
    'ass', 'sex', 'anal', 'booty', 'erotic', 'porn', 'vrporn', 'dick',
    'cock', 'gay', 'faggot', 'faget', 'pussy', 'throatfuck', 'whore',
    'kinky', 'cunt', 'throat', 'deepthroat', 'slave', 'horny', 'gangbang',
    'slut', 'blowjob', 'cum', 'jizz', 'tit', 'tits', 'titties', 'jugs',
    'fuck', 'titfuck', 'fucking', 'feminized', 'tranny', 'tran', 'trans',
    'LGBT', 'transition', 'femboy', 'ladyboy', 'xxx', 'rawattack',
    'brazzers', 'brazzersexxtra', 'dpg', 'welivetogether', 'zzseries',
    'tadpolesexstudio', 'lustery', 'pyx', 'femdom', 'xrporn', 'bbc',
    'vrcosplay', 'vrcosplayx', 'parody xxx', 'touchmywife', 'slayed',
    'roccosiffredi', 'sensuallove', 'onlyfans', 'pawged', 'netgirl',
    'latinaraw', 'strippov', 'sofiemarie', 'swallowed', 'mylfsingles',
    'spankmonster', 'sexmex', 'sofiemariexxx', 'girlsoutwest', 'gloryholes',
    'gloryholesecrets', 'manyvids', 'playboyplus', 'penthousegold',
    'futaworld', 'futa', 'brownbunnies', 'snowbunny', 'snow bunny',
    'filthykings', 'filthy kings', 'elegantangel', 'digitalplayground',
    'blacked', 'blackonblondes', 'blackraw', 'blackedraw', 'atkgirlfriends',
    'sexart', 'sex art', 'wicked', 'tadpoleexstudio', 'tadpolexstudio',
    'wecometou', 'wecome2u', 'wecometoyou', 'wecum2u', 'wecumtou',
    'wecum2you', 'wecumtoyou', 'vivthomas', 'onlyexseries', 'only3xseries',

    # General adult-content terms
    'adult', 'adults only', 'adult content', 'adult video', 'adult videos',
    'adult site', 'adult sites', 'explicit', 'explicit content', 'nsfw',
    'xxx video', 'xxx videos', 'sex video', 'sex videos', 'porn video',
    'porn videos', 'porn site', 'porn sites', 'webcam sex', 'cam sex',
    'live sex', 'nude', 'nudes', 'naked', 'nudity', 'topless',
    'masturbation', 'masturbate', 'orgasm', 'orgasms', 'orgy', 'orgies',
    'fetish', 'fetishes', 'bondage', 'bdsm', 'dominatrix', 'escort',
    'escorts', 'prostitute', 'prostitution', 'hooker', 'hookers',
    'stripper', 'strippers', 'strip club', 'strip clubs', 'sex chat',
    'dirty chat', 'adult chat', 'adult dating', 'sex toy', 'sex toys',
    'dildo', 'dildos', 'vibrator', 'vibrators', 'handjob', 'hand job',
    'footjob', 'foot job', 'oral sex', 'anal sex', 'nipple', 'nipples',
    'boobs', 'breasts', 'penis', 'vagina', 'genitals', 'sexy', 'sensual',
    'hentai', 'erotica', 'erotic story', 'erotic stories',
    'adult entertainment', 'adult performer', 'adult performers',
    'adult actress', 'adult actor', 'adult studio', 'adult studios',

    # Adult websites, studios, and paid services
    'pornhub', 'xvideos', 'xhamster', 'xnxx', 'chaturbate', 'livejasmin',
    'youporn', 'redtube', 'spankbang', 'tube8', 'beeg', 'tnaflix',
    'eporner', 'motherless', 'xtube', 'porntrex', 'porn.com', 'hclips',
    'porndig', 'slutload', 'pornhd', 'drtuber', 'nuvid', 'empflix',
    'keezmovies', 'sunporno', 'xozilla', 'sexvid', 'porntube', 'porngo',
    'theporndude', 'pornone', 'pornkai', 'porntop', 'porntop.com',
    'sex.com', 'literotica', 'justforfans', 'fanvue', 'fancentro',
    'mym.fans', 'camsoda', 'myfreecams', 'flirt4free', 'bongacams',
    'stripchat', 'cam4', 'adulttime', 'naughtyamerica', 'realitykings',
    'mofos', 'twistys', 'wickedpictures', 'vixen', 'deeper', 'tushy',
    'evilangel', 'vivid', 'private', 'dorcel', 'bluehustler',

    # Adult TV channels and channel brands, including no-space variants
    'brazzers tv', 'brazzerstv',
    'playboy tv', 'playboytv',
    'playboy tv 2', 'playboytv2',
    'playboy tv en espanol', 'playboytvenespanol',
    'hustler tv', 'hustlertv',
    'hustler mature', 'hustlermature',
    'hustler hd', 'hustlerhd',
    'vivid tv', 'vividtv',
    'penthouse tv', 'penthousetv',
    'penthouse hd', 'penthousehd',
    'penthouse passion', 'penthousepassion',
    'dorcel tv', 'dorceltv',
    'blue hustler', 'bluehustler',
    'reality kings tv', 'realitykingstv',
    'reality kings television', 'realitykingstelevision',
    'rk tv', 'rktv',
    'ten', 'ten networks', 'tennetworks',
    'xtsy',
    'spice channel', 'spicechannel',
    'television x', 'televisionx',
    'pink tv', 'pinktv',
    'xxl',
    'private tv', 'privatetv',
    'nightshift tv', 'nightshifttv',
    'babes tv', 'babestv',
    'erox hd', 'eroxhd',
    'eros tv', 'erostv',
    'erosxxl',
    'passion xxx', 'passionxxx',
    'naughty tv', 'naughtytv',
    'babe station', 'babestation',
    'babestation xtreme', 'babestationxtreme',
    'maleflixxx',
    'playmen tv', 'playmentv',
    'allure channel', 'allurechannel',
    'sexy hot', 'sexyhot',
    'dusk',
    'leo tv', 'leotv',
    'smile tv', 'smiletv',
    'xmo',
    'aov adult movie channel', 'aovadultmoviechannel',
    'arouse',
    'bangu',
    'exxxtasy tv', 'exxxtasytv',
    'hot choice', 'hotchoice',
    'skin tv', 'skintv',
    'skinmax hd', 'skinmaxhd',
    'clips',
    'freaky',
    'juicy',
    'sexsee',
    'vavoom',
    'xxx action clips', 'xxxactionclips',
))


# Known episode-related patterns that are safe to ignore during check-word validation
_EPISODE_DESCRIPTOR_PATTERNS = frozenset({
	'part', 'pt', 'finale', 'final', 'extended', 'director', 'cut',
	'complete', 'collection', 'boxset', 'pack', 'season', 'episode',
	'1080p', '720p', '2160p', '4k', 'uhd', 'bluray', 'web', 'hdr', 'dv',
})

# Reuse the existing compiled regex.
_EPISODE_NUMBER_RE = _CLOUD_SE_TOKEN_RE

# Longest words first prevents a shorter check word from winning when
# another check word starts at the same position.
_CHECK_WORDS_RE = re.compile(
	r"(?<![A-Za-z0-9])"
	r"(?P<check_word>%s)"
	r"(?![A-Za-z0-9])"
	% "|".join(
		re.escape(word)
		for word in sorted(_CHECK_WORDS, key=len, reverse=True)
	),
	re.IGNORECASE,
)

def _ep_name_word_validation(title, ep_name, release_title):
	try: return _ep_name_word_validation_cached(title, ep_name, release_title)
	except TypeError: return _ep_name_word_validation_cached.__wrapped__(title, ep_name, release_title)  # unhashable argument

@lru_cache(maxsize=8192)
def _ep_name_word_validation_cached(title, ep_name, release_title):
	"""Validate check words found in a release filename."""

	if not title or not ep_name:
		# No ep_name context available; skip validation.
		return True

	title_normalized = normalize(title).lower()
	ep_name_normalized = normalize(ep_name).lower()

	release_normalized = normalize(release_title).lower()

	# Find check words only when they are complete filename words.
	words_found_in_release = {
		match.group('check_word').lower()
		for match in _CHECK_WORDS_RE.finditer(release_normalized)
	}

	if not words_found_in_release:
		return True

	# Token sets are only needed once a check word was actually found (most names hold none).
	ep_name_tokens = set(_filename_tokens(ep_name))
	title_tokens = set(_filename_tokens(title))
	release_tokens = set(_filename_tokens(release_title))

	# Build allowed token sets.
	allowed_tokens = (
		ep_name_tokens
		| title_tokens
		| _EPISODE_DESCRIPTOR_PATTERNS
		| _TRAILING_NOISE_TOKENS
	)

	# Allow season/episode tokens such as:
	# S01E0001, S1-E480, S1x480, and 1x480.
	allowed_tokens.update(
		token.lower()
		for token in release_tokens
		if _EPISODE_NUMBER_RE.fullmatch(token)
	)

	for word in words_found_in_release:
		# The check word must exist in the episode name or title metadata.
		if (
			word not in ep_name_normalized
			and word not in title_normalized
		):
			diag_log(
				'EpNameGuard',
				'CHECK WORD NOT IN METADATA: word=%r → REJECT' % word,
			)
			return False

		# Exclude the current check-word tokens from validation.
		check_word_tokens = set(_filename_tokens(word))
		other_filename_tokens = release_tokens - check_word_tokens

		# Find filename tokens not present in metadata or the allowlist.
		unmatched = {
			token
			for token in (other_filename_tokens - allowed_tokens)
			if len(token) >= 3
		}

		if unmatched:
			diag_log(
				'EpNameGuard',
				'CHECK WORD IN METADATA BUT FILE TOKENS INVALID: '
				'word=%r | invalid=%r → REJECT'
				% (word, unmatched),
			)
			return False

		diag_log(
			'EpNameGuard',
			'CHECK WORD VALIDATED + ALL TOKENS OK: word=%r → ACCEPT'
			% word,
		)

	return True

@lru_cache(maxsize=8192)
def _filename_tokens_cached(text):
	text = _utils_normalize(text or '').lower().replace('&', ' and ').replace("'", '')
	return tuple(t for t in re.split(r'[^a-z0-9]+', text) if t)

def _filename_tokens(text):
	return list(_filename_tokens_cached(text or ''))

# Roman ordinals that discriminate serialized episode titles ('Part I' vs 'Part II').
# Core range (i–xiii) kept explicitly and unconditionally — 'i' vs 'ii' is exactly
# the Part I vs Part II discriminator. Expanded range adds validated numerals
# up to ~4000 for pathological multi-part series. 'Part 1'-style digits are NOT
# kept — TMDb consistently uses romans for serialized anime arcs.

_ROMAN_VALS = {'i': 1, 'v': 5, 'x': 10, 'l': 50, 'c': 100, 'd': 500, 'm': 1000}

def _is_valid_roman(token):
	"""Well-formed subtractive roman numeral: strictly non-increasing value
	with valid subtractive pairs only (iv, ix, xl, xc, cd, cm). Rejects
	'iiii', 'vv', 'ic', 'il', 'xm', etc. Length >= 3 keeps us out of the
	junk-word collision range (mi, li, di, ci...)."""
	if len(token) < 3 or not all(c in _ROMAN_VALS for c in token): return False
	for a, b in zip(token, token[1:]):
		va, vb = _ROMAN_VALS[a], _ROMAN_VALS[b]
		if va < vb and (a not in 'ixc' or va * 10 < vb): return False  # ic, il, xm...
	return True

# Core: the discriminating range for serialized episode titles. Kept explicitly —
# 'i' vs 'ii' is exactly the Part I vs Part II discriminator, so it must never be
# subject to length filtering.
_EP_ROMAN_CORE = frozenset((
	'i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x', 'xi', 'xii', 'xiii'))

_EP_ROMAN_EXPANDED = frozenset(t for t in (
	'xiv','xv','xvi','xvii','xviii','xix','xx','xxi','xxii','xxiii','xxiv','xxv',
	'xxx','xxxix','xl','xlv','l','lv','lx','lxix','lxx','lxxx','xc','xcix',
	'c','cxcix','cc','ccc','cd','cdxcix','d','dc','cm','cmxcix','mcmxcix','mm')
	if _is_valid_roman(t))

_EP_ROMAN_ORDINALS = _EP_ROMAN_CORE | _EP_ROMAN_EXPANDED

_CAMEL_SPLIT_RE = re.compile(
	r'(?<=[a-z0-9])(?=[A-Z])'   # lower/digit -> upper   (PokeBall -> poke|ball)
	r'|(?<=[A-Za-z])(?=\d)'     # letter -> digit        (pokemon083 -> pokemon|083)
	r'|(?<=\d)(?=[A-Za-z])')    # digit -> letter        (083Poke -> 083|poke)

def episode_title_keep_tokens(ep_name):
	"""Distinctive TMDb episode-title words, or None when the name is too generic to keep a file.

	###FIX### Roman ordinals (i–xiii) are now KEPT as required tokens even though
	short. Previously they were discarded, so 'Nine Schools Competition Part I'
	token-matched siblings '…II' through '…XI' (identical kept-token subset) —
	accepting 10 wrong files per queried episode.
	Behavior:
		'Nine Schools Competition Part I'  -> ['nine','schools','competition','i']
		matches '…Nine Schools Competition I.mkv'  ✓
		rejects   '…Nine Schools Competition II…XI.mkv'  ('i' ∉ {…,'ii'})  ✓
		'Enrollment Part I'                -> ['enrollment','i'] — now PARTICIPATES
		(was None), and correctly matches only Part I. The ep-name override
		that was structurally dead for this show is resurrected — safely, because
		the roman numeral is required exactly.
	Names with 2+ ordinary content words are unaffected.
	###FIX### Added _check_words validation: if generic words like 'tomorrow'
	appear in filename but not in BOTH show title AND ep_name, reject immediately.
	"""
	if not ep_name:
		return None
	
	tokens = [t for t in _filename_tokens(ep_name)
		if t not in _EP_TITLE_STOPWORDS and not t.isdigit()
		and (len(t) >= 3 or t in _EP_ROMAN_ORDINALS)]
	
	if len(tokens) < 2:
		return None
	
	# ###NEW### Check-words validation guard
	if not _ep_name_word_validation('', ep_name, ep_name):
		return None
	
	return tokens

def _strip_punctuation(text):
    """Strip all non-alphanumeric characters (except spaces)."""
    return re.sub(r'[^\w\s]', '', text)

# Global threshold (adjustable)
FUZZY_MATCH_THRESHOLD = 1  # Change this if needed

def _is_roman_ordinal(token):
	"""Check if token is a valid Roman numeral ordinal."""
	if not token:
		return False

	token_lower = token.lower()

	# Check against existing Roman ordinal sets from source_utils
	return token_lower in (_EP_ROMAN_CORE | _EP_ROMAN_EXPANDED)

def _strip_punctuation(text):
	"""Strip all non-alphanumeric characters (except spaces)."""
	return re.sub(r'[^\w\s]', '', text)

def _fuzzy_token_match(token1, token2, max_diff=None):
	"""Check if two tokens match with up to max_diff character differences.

	Both tokens are assumed to already be normalized
	(accent-folded + punct-stripped).

	Roman ordinal tokens (i, ii, iii, iv, etc.) require exact matches
	with no fuzzy tolerance.
	"""
	if not token1 or not token2:
		return False

	# Roman ordinals require exact match - never allow fuzzy matching
	if _is_roman_ordinal(token1) or _is_roman_ordinal(token2):
		return token1 == token2
	# digits and short words are never fuzzy: 'Part 2' must not accept 'Part 3', 'hero' must not accept 'zero'
	if any(ch.isdigit() for ch in token1 + token2) or min(len(token1), len(token2)) < 5:
		return token1 == token2

	# Apply global threshold if not specified
	max_diff = (
		max_diff
		if max_diff is not None
		else FUZZY_MATCH_THRESHOLD
	)

	# Quick length check
	if abs(len(token1) - len(token2)) > max_diff:
		return False

	# Calculate edit distance (Levenshtein-ish for small diffs)
	len1, len2 = len(token1), len(token2)

	# If one is a substring of the other with a small difference, accept
	if token1 in token2 or token2 in token1:
		return abs(len1 - len2) <= max_diff

	# Character-by-character comparison
	i = j = distance = 0

	while i < len1 and j < len2:
		if token1[i] != token2[j]:
			distance += 1

			if distance > max_diff:
				return False

			# Skip in longer token
			if len1 > len2:
				i += 1
			elif len2 > len1:
				j += 1
			else:
				i += 1
				j += 1
		else:
			i += 1
			j += 1

	# Account for remaining characters
	distance += abs(len1 - i) + abs(len2 - j)

	return distance <= max_diff

def episode_title_fuzzy_in_release(
	ep_name,
	release_title,
	title=None,
	max_missing_chars=None,
):
	"""Fuzzy episode title token matching using your existing normalize().

	Uses normalize() for accent folding, then strips punctuation.

	Allows up to FUZZY_MATCH_THRESHOLD character differences per token.

	Roman ordinals (i, ii, iii, iv, etc.) require exact matches.
	"""
	if not ep_name or not release_title:
		return False

	# Use global threshold if not specified
	max_missing_chars = (
		max_missing_chars
		if max_missing_chars is not None
		else FUZZY_MATCH_THRESHOLD
	)

	# Check-words guard (existing validation)
	if title and not _ep_name_word_validation(
		title,
		ep_name,
		release_title,
	):
		diag_log(
			'CloudMatch',
			'EP-NAME FUZZY WORD GUARD REJECT: '
			'ep_name=%r filename=%r title=%r'
			% (ep_name, release_title, title),
		)
		return False

	# Get distinctive tokens from episode name
	needed_tokens = episode_title_keep_tokens(ep_name)

	if not needed_tokens:
		return False

	# Normalize both ep_name and release_title using normalize()
	norm_ep = _strip_punctuation(normalize(ep_name)).lower()
	norm_release = _strip_punctuation(normalize(release_title)).lower()

	# Tokenize
	ep_tokens = _filename_tokens(norm_ep)
	release_tokens = _filename_tokens(norm_release)

	if not ep_tokens or not release_tokens:
		return False

	# Match each needed token against release tokens with tolerance
	matched = 0

	for ep_tok in ep_tokens:
		if not ep_tok:
			continue

		found = False

		for rel_tok in release_tokens:
			if not rel_tok:
				continue

			# Try fuzzy match with Roman ordinal protection
			if _fuzzy_token_match(
				ep_tok,
				rel_tok,
				max_missing_chars,
			):
				found = True
				matched += 1
				break

		# Also try substring checks for partial matches such as
		# "Judgment" in "Judgement"
		if not found:
			for rel_tok in release_tokens:
				if ep_tok in rel_tok or rel_tok in ep_tok:
					# Roman ordinals in substring mode still require
					# exact matches
					if (
						_is_roman_ordinal(ep_tok)
						or _is_roman_ordinal(rel_tok)
					):
						if ep_tok == rel_tok:
							found = True
							matched += 1
							break
					elif (
						abs(len(ep_tok) - len(rel_tok))
						<= max_missing_chars
					):
						found = True
						matched += 1
						break

	diag_log(
		'CloudMatch',
		'EP-NAME FUZZY: ep_name=%r tokens=%d matched=%d | '
		'filename=%r'
		% (ep_name, len(ep_tokens), matched, release_title),
	)

	# Require all distinctive tokens to match
	return matched >= len(ep_tokens)


_PART_NUM_RE = re.compile(r'(?<![a-z0-9])part[\s._-]*(\d{1,3}|[ivxlc]{1,6})(?![a-z0-9])', re.I)
_PART_ROMAN = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10, 'xi': 11, 'xii': 12, 'xiii': 13, 'xiv': 14, 'xv': 15}

def _part_numbers(text):
	"""The part numbers named in a text: 'Part 2', 'Part.II', 'part-3' -> {2}, {2}, {3}."""
	out = set()
	for m in _PART_NUM_RE.finditer(str(text or '')):
		v = m.group(1).lower()
		n = int(v) if v.isdigit() else _PART_ROMAN.get(v)
		if n: out.add(n)
	return out

def part_number_conflict(ep_name, release_title):
	"""True when both names give part numbers and none of the release's parts is the episode's part (ep 'Part 2' vs 'Part 3')."""
	want, have = _part_numbers(ep_name), _part_numbers(release_title)
	return bool(want and have and not (want & have))

# Modified episode_title_in_release to use fuzzy matching as fallback
def episode_title_in_release(ep_name, release_title, title=None, container=False):
	"""Match ep_name with fuzzy tolerance as a fallback.

	Priority:
	1. Exact token match (existing)
	2. Fuzzy token match (new) - Roman ordinals still exact
	3. Contiguous blob match (existing)
	"""
	if not ep_name or not release_title:
		return False
	if weak_name_blocked(ep_name, release_title, title, container):
		diag_log('CloudMatch', 'EP-NAME WEAK NAME NEEDS SHOW TITLE: ep_name=%r filename=%r' % (ep_name, release_title))
		return False
	if part_number_conflict(ep_name, release_title):
		diag_log('CloudMatch', 'EP-NAME PART CONFLICT: ep_name=%r filename=%r' % (ep_name, release_title))
		return False

	# Check-words guard
	if title and not _ep_name_word_validation(
		title,
		ep_name,
		release_title,
	):
		diag_log(
			'CloudMatch',
			'EP-NAME WORD GUARD REJECT (entry): '
			'ep_name=%r filename=%r title=%r'
			% (ep_name, release_title, title),
		)
		return False

	# 1. Exact token matching (existing)
	needed = episode_title_keep_tokens(ep_name)

	if needed:
		hay = set(_filename_tokens(release_title))

		if all(word in hay for word in needed):
			diag_log(
				'CloudMatch',
				'EP-NAME mode=1(token) MATCH: '
				'ep_name=%r filename=%r'
				% (ep_name, release_title),
			)
			return True

	# 2. Fuzzy token matching (new)
	# Roman ordinals still require exact matches
	if episode_title_fuzzy_in_release(
		ep_name,
		release_title,
		title=title,
	):
		diag_log(
			'CloudMatch',
			'EP-NAME mode=2(fuzzy) MATCH: '
			'ep_name=%r filename=%r'
			% (ep_name, release_title),
		)
		return True

	# 3. Contiguous fallback (existing)
	result = episode_name_contiguous_in_release(
		ep_name,
		release_title,
		title=title,
		container=container,
	)

	if result:
		diag_log(
			'CloudMatch',
			'EP-NAME mode=3(contiguous) MATCH: '
			'ep_name=%r filename=%r'
			% (ep_name, release_title),
		)

	return result

def _episode_contiguous_blob(text):
	"""Accent-fold, lowercase, then strip ALL non-alphanumeric characters.

	Pokémon: Pokéball! -> 'pokemonpokeball'
	'Pokémon - 083 - Poke Ball Peril   [DarkDream].mkv' -> 'pokemon083pokeballperildarkdream'
	Both sides get identical treatment so cleanup is symmetric.
	"""
	try:
		text = normalize(text or '').lower().replace('&', ' and ')
		return re.sub(r'[^a-z0-9]', '', text)
	except Exception:
		return ''

def _episode_boundary_atoms(text):
	"""Lowercase alphanumeric atoms split at separators AND camel/digit transitions.
	'Poke Ball Peril', 'PokeBallPeril' and 'Pokemon083PokeBallPeril' all yield
	perimeter-aligned atoms, so the contiguous fallback can verify that a blob
	match begins at an atom start and ends at an atom end."""
	try:
		text = _CAMEL_SPLIT_RE.sub(' ', normalize(text or ''))
		return [t for t in re.split(r'[^a-z0-9]+', text.lower()) if t]
	except Exception:
		return []

# ------------------------------------------------------------------------------
# FALLBACK MODE 2 TUNING NOTE — don't rewrite:
# If a SHORT episode name (e.g. 'Go!', '9') ever fails to match, the culprit is
# the len(blob) < 6 guard inside episode_name_contiguous_in_release() below —
# LOOSEN that number (e.g. to 4) rather than modifying episode_name_in_release,
# should_accept_file_title, or the mode-2 boundary logic. The guard exists to
# stop short/generic TMDb titles from substring-matching unrelated files in
# the accent-folded contiguous blob, so lowering it trades recall for false-
# positive risk. The 'any(isalpha)' check alongside it stays: an all-digit
# blob (e.g. ep_name '9') must never match by number alone.
# Boundary awareness (added after Enrollment Part I–IV false positives):
# 'Enrollment Part I' -> 'enrollmentparti' no longer matches 'Enrollment Part II' (use to end inside the 'ii' atom) returning False Match
# 'Pokemon083PokeBallPeril'-style names (poke+ball+peril are whole atoms).
# ------------------------------------------------------------------------------

def episode_name_contiguous_in_release(ep_name, release_title, title=None, container=False):
	"""Fallback mode 2: accent-folded, space/symbol-free contiguous containment
	WITH boundary awareness.

	The needle blob must span whole haystack atoms: a match that starts
	mid-atom or ends mid-atom is rejected. 'Enrollment Part I' ->
	'enrollmentparti' no longer matches 'Enrollment Part II' (ends inside the
	'ii' atom) but still matches 'Pokemon083PokeBallPeril'-style names
	(poke+ball+peril are whole atoms).
	###NEW### Added check-words guard that blocks generic words from saving files.
	"""
	if not ep_name or not release_title:
		return False
	if weak_name_blocked(ep_name, release_title, title, container):
		return False
	
	# ###NEW### Check-words guard — MUST validate BEFORE contiguous matching
	if not _ep_name_word_validation(title or '', ep_name, release_title):
		diag_log('CloudMatch', 'EP-NAME CONTIGUOUS WORD GUARD REJECT: ep_name=%r filename=%r title=%r' % (ep_name, release_title, title))
		return False
	
	blob = _episode_contiguous_blob(ep_name)
	if len(blob) < 6 or not any(c.isalpha() for c in blob):
		return False
	atoms = _episode_boundary_atoms(release_title)
	hay = ''.join(atoms)
	if not hay or len(blob) > len(hay):
		return False
	starts, ends = set(), set()
	pos = 0
	for atom in atoms:
		starts.add(pos)
		pos += len(atom)
		ends.add(pos)
	start = hay.find(blob)
	while start != -1:
		end = start + len(blob)
		if start in starts and end in ends:
			return True
		start = hay.find(blob, start + 1)
	return False

def episode_name_in_release(ep_name, release_title, title=None, container=False):
	"""ep_name match, mode 1 → distinctive-token scan; mode 2 → accent-folded
	contiguous ('pokeballperil' inside 'pokemon083pokeballperil...').

	Additive fallback only — can never reject a file the original
	episode_title_in_release() accepted.
	###NEW### Added title parameter and check-words guard that blocks generic words
	from saving files via ANY ep_name matching path (token, contiguous, recovery).
	"""
	if not ep_name:
		return False
	if weak_name_blocked(ep_name, release_title, title, container):
		return False
	
	# ###NEW### Check-words guard — validates BEFORE BOTH matching modes
	if not _ep_name_word_validation(title or '', ep_name, release_title):
		diag_log('CloudMatch', 'EP-NAME WORD GUARD REJECT (entry): ep_name=%r filename=%r title=%r' % (ep_name, release_title, title))
		return False
	
	if episode_title_in_release(ep_name, release_title, title=title, container=container):
		diag_log('CloudMatch', 'EP-NAME mode=1(token) MATCH: ep_name=%r filename=%r' % (ep_name, release_title))
		return True
	result = episode_name_contiguous_in_release(ep_name, release_title, title=title, container=container)
	if result:
		diag_log('CloudMatch', 'EP-NAME mode=2(contiguous) MATCH: ep_name=%r filename=%r' % (ep_name, release_title))
	return result

_EXTRAS_RE_CACHE = {}
weak_tokens_set = ('inside', 'feature')

def has_extras_word(name, tokens=None):
	"""True when a release/file name contains an 'extras' word (sample, trailer, featurette, ...).
	###FIX### The scrapers used substring checks (`x in name.lower()`), so 'extra' rejected
	'The Extraordinary ...', 'inside' rejected 'Inside Out', 'feature' rejected 'Featured', 'sample'
	 rejected 'Sampler'. Whole-word matching keeps the real extras filtered and stops valid episodes
	from being thrown away by the first (wrong) rejection."""
	try:
		tokens = tuple(tokens if tokens is not None else extras())
		pair = _EXTRAS_RE_CACHE.get(tokens)
		if pair is None:
			def _build(toks):
				parts = [r'[\s._-]+'.join(re.escape(piece) for piece in tok.split('.')) for tok in toks if tok]
				return re.compile(r'(?<![a-z0-9])(?:%s)(?![a-z0-9])' % '|'.join(sorted(parts, key=len, reverse=True)), re.I) if parts else None
			# 'inside' / 'feature' are ordinary words in episode titles ('Inside Out', 'Feature Presentation'),
			# so they only count as extras when the name points at no specific episode.
			weak_tokens = tuple(t for t in tokens if t in ('inside', 'feature'))
			strong_tokens = tuple(t for t in tokens if t not in weak_tokens_set)
			pair = (_build(strong_tokens), _build(weak_tokens))
			_EXTRAS_RE_CACHE[tokens] = pair
		strong, weak = pair
		text = name or ''
		if strong and strong.search(text): return True
		if weak and weak.search(text) and not has_explicit_episode_token(text): return True
		return False
	except Exception:
		return any(x in (name or '').lower() for x in (tokens or ()))

_EP_NAME_ONLY_EXT = frozenset(('mkv', 'mp4', 'avi', 'm4v', 'ts', 'wmv', 'mov', 'nzb'))

def _file_is_only_ep_name(release_title, ep_name):
	"""True when, after [group] tags, the extension and number / season / quality tags are removed, the file name is
	exactly the episode name - nothing else (no extra title words)."""
	try:
		en = _filename_tokens(ep_name or '')
		if not en: return False
		rel = _filename_tokens(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or ''))
		rest = [t for t in rel if not (_TITLE_STOP_RE.match(t) or t in _EP_NAME_ONLY_EXT or t in ('ep', 'episode', 'e'))]
		return rest == en
	except Exception:
		return False

_VETO_SE_RANGE_RE = re.compile(r's0*(\d{1,2})[ ._-]?e0*(\d{1,4})\s*(?:[-~]|to|\+)\s*(?:s0*\d{1,2})?[ ._-]?e?0*(\d{1,4})', re.I)
_VETO_SEASON_RANGE_RE = re.compile(r'(?:\bseasons?[ ._-]*|\bs)0*(\d{1,2})[ ._-]*(?:[-~]|to|&|\+)[ ._-]*(?:seasons?[ ._-]*|s)?0*(\d{1,2})\b', re.I)
_VETO_SEASON_WORD_RE = re.compile(r'\bseasons?[ ._-]*0*(\d{1,2})\b', re.I)
_VETO_SEASON_ORD_RE = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)[ ._-]*season\b', re.I)
_VETO_SEASON_WORDS = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, 'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10}
_VETO_SEASON_ORDWORD_RE = re.compile(r'\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)[ ._-]*season\b', re.I)
_VETO_SEASON_ROMAN_RE = re.compile(r'\bseason[ ._-]*(ii|iii|iv|vi|vii|viii|ix|x)\b', re.I)
_VETO_ROMAN = {'ii': 2, 'iii': 3, 'iv': 4, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
_VETO_SEASON_S_RE = re.compile(r'(?<![a-z0-9])s0*(\d{1,2})(?![a-z0-9]|\s*e\d)', re.I)

_EPNAME_STOP = frozenset(('the', 'and', 'for', 'from', 'with', 'that', 'this', 'are', 'was', 'his', 'her', 'its', 'you', 'your', 'out', 'into', 'has', 'have'))
_EP_WORD_RANGE_RE = re.compile(r'(?<![a-z0-9])(?:eps?|episodes?)[\s._-]*0*(\d{1,4})[\s._]*(?:-|~|to)[\s._]*0*(\d{1,4})(?![0-9])', re.I)

def _epname_words(ep_name):
	text = re.sub(r'[^a-z0-9\s]', ' ', __import__('html').unescape(ep_name or '').lower())
	return [w for w in text.split() if len(w) >= 3 and w not in _EPNAME_STOP and not w.isdigit()]

def epname_overlap(ep_name, release_title):
	"""Share (0..1) of the episode name's distinctive words that appear in the release name."""
	words = _epname_words(ep_name)
	if not words: return 0.0
	text = ' ' + re.sub(r'[^a-z0-9]+', ' ', __import__('html').unescape(release_title or '').lower()) + ' '
	return sum(1 for w in words if (' %s ' % w) in text) / float(len(words))

def epname_overrides_number(title, aliases, release_title, ep_name):
	"""The release names the requested SHOW and (nearly) the whole episode NAME: a wrong season / episode number in it
	('S04E47' for S04E01, a different numbering of the same episode) must not reject it."""
	try:
		if len(_epname_words(ep_name)) < 3 or epname_overlap(ep_name, release_title) < 0.8: return False
		return bool(_title_in_release(title, release_title, aliases, ep_name) or show_named_in_release(title, release_title, aliases))
	except Exception:
		return False

def sequel_digit_after_title(title, release_title):
	"""'<Show> 2 01' - the show title directly followed by a lone sequel/season digit and then the episode number."""
	try:
		rel = _filename_tokens(__import__('html').unescape(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or '')))
		tt = [t for t in _filename_tokens(__import__('html').unescape(title or ''))]
		if not tt or len(rel) < len(tt) + 2: return False
		for i in range(0, min(len(rel) - len(tt) - 1, 6)):
			if rel[i:i + len(tt)] == tt:
				nxt, nxt2 = rel[i + len(tt)], rel[i + len(tt) + 1]
				return nxt.isdigit() and 2 <= int(nxt) <= 9 and len(nxt) == 1 and nxt2.isdigit()
	except Exception:
		pass
	return False

def names_season_titles(release_title, title, aliases):
	"""True when the name spells out two or more different season titles of the show ('The Aegis of Uruk & The Sword of Uruk'):
	a multi-season pack named by its season titles instead of by S#. A season title is an alias that starts with the show title."""
	try:
		name = ' %s ' % ' '.join(re.findall(r'[a-z0-9]+', normalize(release_title or '').lower()))
		show = ' '.join(re.findall(r'[a-z0-9]+', normalize(title or '').lower()))
		if not show: return False
		found = set()
		for a in aliases or []:
			text = ' '.join(re.findall(r'[a-z0-9]+', normalize(a or '').lower()))
			if not text.startswith(show): continue
			part = text[len(show):].strip()
			if len(part.split()) >= 2 and (' %s ' % part) in name: found.add(part)
		return len(found) >= 2
	except Exception:
		return False

_LOOSE_NOISE_RE = re.compile(r'\b(?:\d{3,4}p|\d{3,4}x\d{3,4}|[xh]\.?26[45]|hevc|av1|aac\d?|ac3|dts|flac|mp[34]|mkv|avi|dvd\d?|bd|bdrip|dvdrip|r[12]|ntsc|pal|v\d|dual|audio|sub|subs|raw|raws|widescreen|uncut|uncensored|batch|complete|serie|completa|usa|jpn|eng|19\d\d|20\d\d)\b', re.I)
_LOOSE_EP_RE = re.compile(r'(?<![a-z0-9])(?:ep?\.?\s?0*(\d{1,4})|(\d{1,4}))(?![a-z0-9])', re.I)
_LOOSE_DISC_RE = re.compile(r'\bS\d{1,2}[ ._-]?D\d{1,2}\b', re.I)

_ARTICLES = ('the', 'a', 'an')

def _lw(text):
	return [w for w in re.findall(r'[a-z0-9]+', normalize(text or '').lower()) if w not in _ARTICLES]

def _has_run(words, run):
	n = len(run)
	return n > 0 and any(words[i:i + n] == run for i in range(len(words) - n + 1))

def loose_title_ok(release_title, title, aliases):
	"""True when the release names this show (or the requested season's own title) as a run of words, ignoring articles and punctuation:
	'The Tower of Druaga: The Aegis of Uruk' is found in '[BBF] The Tower of Druaga - The Aegis of Uruk', 'Tower of Druaga' in
	'[Group] Tower Of Druaga [Dual Audio]', 'Aegis of Uruk' in 'Aegis of Uruk D'. A release that names only ANOTHER season's title
	('The Tower of Druaga: The Sword of Uruk') is not this season."""
	try:
		if release_has_blocked_words(release_title, title, aliases): return False
		rel = _lw(re.sub(r'\[[^\]]*\]', lambda m: ' ' + m.group(0)[1:-1] + ' ', release_title or ''))
		rel = [re.sub(r'v\d$', '', w) if len(w) > 4 else w for w in rel]     # 'URUKv2'
		full = _lw(title)
		base_raw = re.split(r'\s*[:\u2013\u2014]\s*|\s+-\s+', str(title or ''), 1)[0]
		base = _lw(base_raw)
		part = full[len(base):] if full[:len(base)] == base else []
		others = []
		for a in aliases or []:
			if not alias_is_usable(a): continue
			w = _lw(a)
			if base and w[:len(base)] == base and len(w) > len(base) and w[len(base):] != part: others.append(w[len(base):])
		has_part = len(part) >= 2 and _has_run(rel, part)
		if has_part and (len(base) < 2 or True): return True
		if len(base) >= 2 and _has_run(rel, base):
			if part and not has_part and any(len(o) >= 2 and _has_run(rel, o) for o in others): return False
			return True
		if _has_run(rel, full) and len(full) >= 2: return True
		for a in aliases or []:
			w = _lw(a)
			if len(w) >= 2 and alias_is_usable(a) and _has_run(rel, w) and not (others and part and not has_part and any(_has_run(rel, o) for o in others)): return True
	except Exception:
		pass
	return False

_SEASON_SET_CHAIN_RE = re.compile(r'(?<![a-z0-9])s(?:eason)?s?[\s._-]*0*(\d{1,2})((?:[\s._]*(?:&|\+|,|and)[\s._]*s?(?:eason)?[\s._]*0*\d{1,2})+)(?![0-9])', re.I)
_SEASON_SET_RANGE_RE = re.compile(r'(?<![a-z0-9])s(?:eason)?s?[\s._]*0*(\d{1,2})[\s._]*(?:-|~|to)[\s._]*s?(?:eason)?[\s._]*0*(\d{1,2})(?![0-9])', re.I)

def names_season_set(name):
	"""Seasons a multi-season name spells out: 'S1 & S2', 'S01+S02', 'Season 1 & 2', 'Seasons 1-2', 'S1-S3' -> {1, 2, 3}. Empty set otherwise."""
	found = set()
	try:
		text = name or ''
		for m in _SEASON_SET_CHAIN_RE.finditer(text):
			found.add(int(m.group(1)))
			found.update(int(n) for n in re.findall(r'\d{1,2}', m.group(2)))
		for m in _SEASON_SET_RANGE_RE.finditer(text):
			lo, hi = int(m.group(1)), int(m.group(2))
			if 0 < lo < hi <= 40: found.update(range(lo, hi + 1))
	except Exception:
		pass
	return {n for n in found if 0 < n < 60}

_ORDINAL_SEASON_RE = re.compile(r'(?<![a-z0-9])(?:(\d{1,2})(?:st|nd|rd|th)|(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth))[\s._-]*season(?![a-z0-9])', re.I)
_ORDINAL_WORDS = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, 'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10}

def loose_release_kind(release_title, title, aliases, season, episode, absolute_episode=None):
	"""Releases the strict S#E# rules miss. Returns 'episode' when the name is just the show (or one of its season titles) plus
	an 'Ep01' / bare number that is the requested episode, 'season' when it is a whole season with no episode number at all
	('The Tower of Druaga: The Aegis of Uruk [MP4 AAC 720p]', 'Show S01D02 DVD9' disc sets), else None."""
	try:
		name = release_title or ''
		if not name or not loose_title_ok(name, title, aliases): return None
		try: season_i = int(season)
		except Exception: season_i = 1
		if _LOOSE_DISC_RE.search(name):
			m = re.search(r'\bS(\d{1,2})', name, re.I)
			return 'season' if not m or int(m.group(1)) == season_i else None
		covered = names_season_set(name)
		if len(covered) >= 2:
			return 'season' if season_i in covered else None
		explicit_season = False
		_ord = _ORDINAL_SEASON_RE.search(name)
		if _ord:
			_n = _ord.group(1) and int(_ord.group(1)) or _ORDINAL_WORDS.get((_ord.group(2) or '').lower())
			if _n != season_i: return None
			explicit_season = True
			name = name[:_ord.start()] + ' ' + name[_ord.end():]
		if names_other_episode(name, season_i, episode or 1, absolute_episode): return None
		plain = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', name)
		plain = ' '.join(re.sub(r'[._]+', ' ', plain).split())
		plain = _LOOSE_NOISE_RE.sub(' ', plain)
		numbers = [int(a or b) for a, b in _LOOSE_EP_RE.findall(plain) if (a or b)]
		wanted = set()
		for v in (episode, absolute_episode):
			try:
				if v and int(v) > 0: wanted.add(int(v))
			except Exception: pass
		if numbers:
			if len(numbers) == 1 and numbers[0] in wanted and (numbers[0] == (int(absolute_episode) if absolute_episode not in (None, '', 0, '0') else -1) or season_i == 1 or explicit_season):
				return 'episode'
			return None
		if season_i == 1 or explicit_season or names_season_titles(name, title, aliases):
			return 'season'
	except Exception:
		pass
	return None

def names_other_episode(release_title, season, episode, absolute_episode=None):
	"""True when the name itself says it is a DIFFERENT episode / season than the requested one: an explicit S#E# (any season)
	that is neither the requested S#E# nor the requested absolute number, or a single 'Season N' / 'SN' marker that is not the
	requested season. A name that says nothing, or that covers the requested episode / season (ranges, packs), is never vetoed."""
	try:
		season_i, episode_i = int(season), int(episode)
		try: abs_i = int(absolute_episode) if absolute_episode not in (None, '', 0, '0') else 0
		except Exception: abs_i = 0
		name = release_title or ''
		if episode_range_covers(name, season_i, episode_i): return False   # 'S01E46E47E48' / 'S01E46-E48' covers it
		for m in _VETO_SE_RANGE_RE.finditer(name):
			if int(m.group(1)) == season_i and int(m.group(2)) <= episode_i <= int(m.group(3)): return False
		# 'S01.1080p' / 'S02 720p' read as episode 1080 / 720: a resolution is never an episode number
		tokens = [(s_, e_) for s_, e_ in iter_season_episode_tokens(name) if (e_ not in (480, 576, 720, 1080, 2160, 4320) and not (1900 <= e_ <= 2100)) or e_ in (episode_i, abs_i)]   # a resolution or a YEAR ('S01 2023 BDRemux') is never an episode number
		if tokens:
			if any((s_, e_) == (season_i, episode_i) for s_, e_ in tokens): return False
			if abs_i and any(e_ == abs_i for s_, e_ in tokens): return False
			alts = _alt_pairs(season_i, episode_i, abs_i)
			if alts and any(t in alts for t in tokens): return False   # 'S04E01' / 'S01E47' for the same episode (true-absolute numbering)
			return True
		for m in _EP_WORD_RANGE_RE.finditer(name):
			lo, hi = int(m.group(1)), int(m.group(2))
			if 0 < hi - lo <= 60:
				if lo <= episode_i <= hi or (abs_i and lo <= abs_i <= hi): return False
				return True   # 'Episode 08-09' / 'ep. 109-110' for another episode
		for m in _VETO_SEASON_RANGE_RE.finditer(name):
			if int(m.group(1)) <= season_i <= int(m.group(2)): return False
		# '2nd Season - 01': the ordinal names the season; the 'Season - 01' tail of it is the episode number, not a season 1 marker
		_ords = [int(m.group(1)) for m in _VETO_SEASON_ORD_RE.finditer(name)]
		if _ords and not any(0 < n < 60 and (n == season_i or n in {a[0] for a in _alt_pairs(season_i, episode_i, abs_i)}) for n in _ords) and any(0 < n < 60 for n in _ords): return True
		singles = [int(m.group(1)) for m in _VETO_SEASON_WORD_RE.finditer(name)] + [int(m.group(1)) for m in _VETO_SEASON_S_RE.finditer(name)]
		singles += [int(m.group(1)) for m in _VETO_SEASON_ORD_RE.finditer(name)]
		singles += [_VETO_SEASON_WORDS[m.group(1).lower()] for m in _VETO_SEASON_ORDWORD_RE.finditer(name)]
		singles += [_VETO_ROMAN[m.group(1).lower()] for m in _VETO_SEASON_ROMAN_RE.finditer(name)]
		singles = [n for n in singles if 0 < n < 60]
		if singles and season_i not in singles and not ({a[0] for a in _alt_pairs(season_i, episode_i, abs_i)} & set(singles)): return True
	except Exception:
		pass
	return False

_EP_RANGE_RES = (
	re.compile(r'(?<![a-z0-9])s(\d{1,2})[\s._-]*e(\d{1,4})[\s._-]*(?:-|~|to)[\s._-]*(?:s\d{1,2}[\s._-]*)?e?(\d{1,4})(?![0-9])', re.I),   # S01E46-E48 / S01E46-48
	re.compile(r'(?<![a-z0-9])s(\d{1,2})[\s._-]*((?:e\d{1,4}){2,})(?![0-9])', re.I),                                                       # S01E46E47E48
)

def episode_range_covers(release_title, season, episode):
	"""True when the name carries a multi-episode range of the requested season that includes the requested episode (S01E46-E48)."""
	try:
		season, episode = int(season), int(episode)
		text = __import__('html').unescape(release_title or '')
		m = _EP_RANGE_RES[0].search(text)
		if m and int(m.group(1)) == season and 0 < int(m.group(3)) - int(m.group(2)) <= 12:
			return int(m.group(2)) <= episode <= int(m.group(3))
		m = _EP_RANGE_RES[1].search(text)
		if m and int(m.group(1)) == season:
			nums = [int(x) for x in re.findall(r'e(\d{1,4})', m.group(2), re.I)]
			return episode in nums
	except Exception:
		pass
	return False

def _episode_any_match_raw(title, release_title, aliases, year, season, episode, ep_name='', absolute_episode=None, filter_title=True, allow_series_prefix=False):
	"""Accept a release when ANY evidence matches - S#E#, absolute number, fuzzy episode name, or the
	regular title paths - instead of stopping at the first rejection (Easynews, AIOStreams, NZB).
	A bare S#E# / absolute-number hit only counts when the REQUESTED show (its title or an alias) leads the name
	- those searches also query the episode name, so providers return other shows' 'Hometown S01E01' files. An
	episode-NAME hit keeps its own guards (a weak one-word name needs the show title in the name too).
	Applies whatever the per-scraper title-filter setting says.
	Returns (accepted, reasons)."""
	reasons = []
	try: release_title = __import__('html').unescape(release_title or '') # nyaa page source writes 'Welsh &amp; Shedar'
	except Exception: pass
	if season and episode and sequel_digit_after_title(title, release_title): return False, []
	if season and episode and names_other_episode(release_title, season, episode, absolute_episode):
		# right show AND (nearly) the whole episode name: the number in the release is just numbered differently
		if epname_overrides_number(title, aliases, release_title, ep_name): return True, ['EP-NAME-ANYNUM']
		return False, []
	try:
		if season and episode:
			show_leads = _title_in_release(title, release_title, aliases, ep_name)
			# Cheap reject first: a name that neither leads with the show nor carries the episode name can only be another show
			# (Easynews returns thousands of those; the full cloud matcher on each one took ~50 s and made the list close without it).
			if not show_leads and epname_overlap(ep_name, release_title) < 0.5:
				raise StopIteration
			modes = cloud_episode_matches_all(season, episode, release_title, absolute_episode, ep_name or '', title=title)
			# A WEAK episode name (one distinctive word, e.g. 'Hometown') is blocked above without the show title, so a bare
			# 'S01E01 Hometown 1080p' would be lost. Let it through only when the file is JUST the number + that name + tags -
			# 'Hometown Horror S01E01' / 'Hometown Flex 2020 S01E01' carry extra words and stay out.
			name_only = (not show_leads) and any(m in ('S%E', 'ABS-E') for m in modes) and _file_is_only_ep_name(release_title, ep_name)
			has_number = any(m in ('S%E', 'ABS-E') for m in modes)
			# Show title leads the name: any evidence counts. No show title in the name: the episode number AND the episode name
			# must both hit ('Beyond Dreams S02E08' / 'Show - 20 - Beyond Dreams'). A name alone ('Beyond Dreams Door 1989',
			# 'Grow Up Show S01E10 beyond the stage of dreams') or a number alone never counts.
			if show_leads or (has_number and ('EP-NAME' in modes or name_only)):
				for m in modes:
					if m == 'EP-NAME' or (m in ('S%E', 'ABS-E') and (show_leads or name_only or 'EP-NAME' in modes)): reasons.append(m)
	except StopIteration:
		pass
	except Exception:
		pass
	if reasons:
		return True, reasons
	# Same episode under another season split / true-absolute numbering ('S04E01', 'S01E47' for TMDb S01E47 / S04E01): the show must lead the name.
	try:
		alts = _alt_pairs(season, episode, absolute_episode) if (season and episode) else ()
		if alts and any(t in alts for t in iter_season_episode_tokens(release_title)) and (_title_in_release(title, release_title, aliases, ep_name) or show_named_in_release(title, release_title, aliases)):
			return True, ['S%E-ALT']
	except Exception: pass
	# A multi-episode release that includes the requested episode ('Show S01E46-E48'): the show must lead the name.
	try:
		if season and episode and episode_range_covers(release_title, season, episode) and (_title_in_release(title, release_title, aliases, ep_name) or show_named_in_release(title, release_title, aliases)):
			return True, ['S%E-RANGE']
	except Exception: pass
	# Opt-in (nyaa only): '[Group] <series name> <show title> 01' - show title + absolute number, extra words in front.
	if allow_series_prefix and season and episode and title_with_series_prefix_and_abs(title, release_title, aliases, absolute_episode, season, episode):
		return True, ['TITLE+ABS']
	# ep_name='' here: the episode-NAME-only shortcut inside should_accept_file_title must not rescue what was rejected above.
	if should_accept_file_title(title, release_title, aliases, year, season, episode, ep_name='',
								absolute_episode=absolute_episode, filter_title=filter_title):
		return True, ['title-path']
	return False, reasons

def _should_accept_file_title_core(
		title,
		release_title,
		aliases,
		year,
		season,
		episode,
		ep_name='',
		absolute_episode=None,
		in_cloud_folder=False,
		is_recovery_pass=False,
		filter_title=True,
	):
	try:
		from .utils import normalize as _normalize

		if aliases is None:
			aliases = []
		# ===== a special searched as a MOVIE: a file named after its season 0 episode is it =====
		if _SPECIAL_LINKS and not season and in_cloud_folder and _special_link_in_name(release_title) and not is_non_episode_name(release_title):
			return True
		if release_has_blocked_words(release_title, title, aliases, ep_name):
			return False
		name_conflict = episode_numbers_conflict(release_title, season, episode, absolute_episode, title=title, aliases=aliases, ep_name=ep_name)

		# ===== SPECIALS (TMDb season 0): 0 is a real season, not 'no season' =====
		if season == 0 and episode and not isinstance(season, bool):
			if ep_name and episode_name_in_release(ep_name, release_title, title=title, container=in_cloud_folder) and (in_cloud_folder or _title_in_release(title, release_title, aliases, ep_name)):
				return True
			if in_cloud_folder:
				return bool(cloud_episode_matches_all(0, episode, release_title, absolute_episode, ep_name, title=title, container=True))
			if _title_in_release(title, release_title, aliases, ep_name) and int(episode) in special_numbers(str(release_title)): return True

		# ===== PACK DETECTION (runs for all files first) =====
		# Uses release_title consistently ✅

		release_lower = release_title.lower()
		is_pack_file = False

		pack_indicators = [
			'complete',
			'all episodes',
			'full season',
			'boxset',
			'box set',
		]

		if any(token in release_lower for token in pack_indicators):
			is_pack_file = True
		elif not has_explicit_episode_token(release_lower):
			# ###FIX### The rest of SEASON_PACK_MARKERS (batch, collection, seasons, season pack,
			# all seasons, ...) never counted here, so those packs skipped the pack title shortcut.
			# Only for names that do not point at one specific episode (SxxExx / 1x05), and 'eps' /
			# 'episodes' only when followed by a range, so 'Show - Eps 5.mkv' is not a pack.
			strong = [h for h in pack_marker_hits(release_lower) if h not in ('eps', 'episodes')]
			if strong or _PACK_EPS_RANGE_RE.search(release_lower):
				is_pack_file = True

		# ###FIX### Added "to" keyword support for natural language season ranges
		# Seasons 1-23, Season 1-23, Season 1 to 23, S1-S23, S1 to S23
		if re.search(
			r'seasons?\s*\d+\s*(?:[-_.~]+\s*|\bto\b\s*)\d+',
			release_lower,
		):
			is_pack_file = True

		if re.search(
			r's\d+\s*(?:[-_.~]+\s*|\bto\b\s*)s?\d+',
			release_lower,
		):
			is_pack_file = True

		if is_pack_file:
			norm_title = _normalize(title).lower()
			norm_file = _normalize(release_title).lower()  # ← Changed from file_name

			norm_title = re.sub(r'[^a-z0-9\s]', '', norm_title)
			norm_file = re.sub(r'[^a-z0-9\s]', '', norm_file)

			for t in [title] + [a for a in aliases if alias_is_usable(a)]:
				norm_t = re.sub(
					r'[^a-z0-9\s]',
					'',
					_normalize(t).lower(),
				)

				if norm_t and re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(norm_t), norm_file):
					return True

			# ###FIX### A pack-marked name without the show title used to be rejected outright, so
			# the episode-NAME match below never got a chance. A fuzzy episode-name hit (already
			# guarded by the check-word validation inside episode_name_in_release) is enough to
			# accept it without the show title - same rule Path 1.5 applies to every other name.
			if ep_name and season and not name_conflict and episode_name_in_release(ep_name, release_title, title=title, container=True):
				return True
			# ###FIX### Do NOT stop here. A pack-marked name that failed the title / episode-name shortcut
			# may still match by S#E# or absolute number below; returning False on the first miss hid
			# those releases. Fall through and let the regular paths decide.

		# =====================================================
		# ===== PATH STEPS FOR NON-PACKS ======================
		# =====================================================

		# Path 1: Recovery Pass
		if is_recovery_pass:
			if not ep_name or not season:
				return False

			return (not name_conflict) and episode_name_in_release(
				ep_name,
				release_title,
				title=title,
				container=in_cloud_folder,
			)  # ✅

		# Path 1.5: Standalone Episode-Title Match
		# A name hit alone is not enough outside a folder/pack: it needs the show title in the name or the matching
		# S#E# / absolute number with it ('Beyond Dreams Door 1989' is not the episode 'Beyond Dreams').
		if (
			ep_name
			and season
			and not name_conflict
			and episode_name_in_release(
				ep_name,
				release_title,
				title=title,
				container=in_cloud_folder,
			)
			and (in_cloud_folder
				or _title_in_release(title, release_title, aliases, ep_name)
				or episode_tokens_match(season, episode, release_title, absolute_episode, ep_name))
		):  # ✅
			return True

		# Path 2: Cloud Folder Matching
		if in_cloud_folder:
			if not season:
				return check_title(
					title,
					release_title,
					aliases,
					year,
					season,
					episode,
				)  # ✅

			return bool(
				cloud_episode_matches_all(
					season,
					episode,
					release_title,
					absolute_episode,
					ep_name,
					title=title,
					container=True,
				)
			)  # ✅

		# Path 3: Standard Matching
		if check_title(
			title,
			release_title,
			aliases,
			year,
			season,
			episode,
		):  # ✅
			# A single episode file outside any pack / folder must be the REQUESTED show: its title (or an alias) starts
			# the name. 'Other.Show.S01E01' is not 'Show'.
			if not season or season == 'pack' or is_pack_file or _title_in_release(title, release_title, aliases, ep_name):
				return True

		# Path 4: Search Match Without Folder
		if season and season != 'pack':
			if (
				folder_name_matches(
					release_title,
					title,
					aliases,
				)
				and episode_tokens_match(
					season,
					episode,
					release_title,
					absolute_episode,
					ep_name,
				)
				and (is_pack_file or _title_in_release(title, release_title, aliases, ep_name))
			):  # ✅ Both ✅
				return True

		return False

	except Exception:
		return False

_OTHER_SHOW_SE_RE = re.compile(r'^s\d{1,2}e\d{1,4}$|^\d{1,2}x\d{1,4}$')
_OTHER_SHOW_JUNK = frozenset(('web', 'dl', 'webrip', 'webdl', 'bluray', 'blu', 'ray', 'bdrip', 'brrip', 'hdtv', 'hevc', 'avc', 'remux', 'proper', 'repack',
	'dual', 'multi', 'uhd', 'hdr', 'dvdrip', 'amzn', 'nf', 'dsnp', 'hmax', 'atvp', 'uncut', 'extended', 'internal', 'complete', 'batch', 'season', 'series',
	'episode', 'ep', 'eps', 'part', 'vol', 'special', 'ova', 'ona', 'movie', 'sub', 'subs', 'dub', 'dubbed', 'eng', 'english', 'jpn', 'raw', 'aac', 'flac'))
_OTHER_SHOW_NOT_EP = frozenset(('480', '576', '720', '1080', '2160', '4320'))

def names_other_show(title, release_title, aliases=None):
	"""True when the words in FRONT of the episode marker ('Other Show Name S01E14' / 'Other Show - 14') clearly name a DIFFERENT show:
	none of them is a word of the requested title or any alias, and they are either two or more plain words or one word of 4+ letters.
	Names that start with a tag run (WEB-DL, BluRay, ...), bare 'S01E14.mkv' / 'Episode 14' / 'DN.S01E14' style names are never touched."""
	try:
		rel = _filename_tokens(__import__('html').unescape(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or '')))
		idx, by_se = None, False
		for i, t in enumerate(rel):
			if _OTHER_SHOW_SE_RE.match(t): idx, by_se = i, True; break
		if idx is None:
			for i, t in enumerate(rel):
				if i and t.isdigit() and len(t) <= 4 and t not in _OTHER_SHOW_NOT_EP and not re.match(r'^(?:19|20)\d\d$', t): idx = i; break
		if not idx: return False
		stop = set(('and', 'the', 'a', 'an', 'of', 'to', 'in', 'on', 'no', 'wa', 'ga'))
		front = [t for t in rel[:idx] if t not in stop]
		if any(t in _OTHER_SHOW_JUNK for t in front): return False
		front = [t for t in front if t.isalpha() and len(t) > 1]
		if not front: return False
		if len(front) < 2 and len(front[0]) < 4: return False
		mine = set()
		front_join = ''.join(rel[:idx])
		for cand in [title] + [a for a in (aliases or []) if alias_is_usable(a)]:
			ctoks = [t for t in _filename_tokens(__import__('html').unescape(cand or ''))]
			mine.update(t for t in ctoks if t not in stop)
			cj = ''.join(ctoks)
			# 'DragonBallSuper.S01E47' - the title run together without separators is still this show
			if len(cj) >= 4 and (cj in front_join or (len(front_join) >= 4 and front_join in cj)): return False
		return not any(t in mine for t in front)
	except Exception:
		return False

# Your own debrid cloud / local folders are never judged here (their folders are already matched to the show); only streams that arrive from searches are
_CLOUD_LEAK_PROVIDERS = frozenset(('easynews', 'nzb', 'aiostreams'))
_OWN_LIBRARY_PROVIDERS = frozenset(('rd_cloud', 'ad_cloud', 'pm_cloud', 'oc_cloud', 'tb_cloud', 'folders'))
_request_ctx = threading.local()

def remember_request(info):
	"""Called at the start of a scraper's results(): remembers what was asked for so internal_results() can drop leaks."""
	try:
		_request_ctx.value = {'media_type': info.get('media_type'), 'title': info.get('title') or '', 'aliases': get_aliases_titles(info.get('aliases', [])),
			'season': info.get('season'), 'episode': info.get('episode'), 'absolute': info.get('absolute_episode'), 'ep_name': info.get('ep_name') or '', 'tmdb_id': info.get('tmdb_id'), 'year': info.get('year'), 'db_scrapers': list(info.get('db_scrapers') or []), 'live': bool(info.get('live_search')), 'cache_only': bool(info.get('cache_only'))}
	except Exception:
		_request_ctx.value = None

def cloud_leak(ctx, name):
	"""True when a debrid-cloud / usenet file name clearly belongs to another show or another episode / season (never for packs that cover it)."""
	try:
		if not ctx or ctx.get('media_type') != 'episode' or not ctx.get('season') or not ctx.get('episode'): return False
		title, aliases = ctx['title'], ctx['aliases']
		if names_other_episode(name, ctx['season'], ctx['episode'], ctx.get('absolute')) and not epname_overrides_number(title, aliases, name, ctx.get('ep_name') or ''): return True
		if sequel_digit_after_title(title, name): return True
		if names_other_show(title, name, aliases): return True
		if release_looks_like_pack(name) and not show_named_in_release(title, name, aliases): return True
	except Exception:
		pass
	return False

def drop_cloud_leaks(provider, sources):
	ctx = getattr(_request_ctx, 'value', None)
	if not ctx or provider not in _CLOUD_LEAK_PROVIDERS or not sources: return sources
	try:
		if get_property('fs_filterless_search') == 'true': return sources
		kept = [i for i in sources if not (cloud_leak(ctx, i.get('name') or '') or cloud_leak(ctx, i.get('display_name') or ''))]
		if len(kept) != len(sources):
			diag_log('LeakGuard', '%s: dropped %d of %d (other show / other episode)' % (provider, len(sources) - len(kept), len(sources)))
			try:
				if nzb_debug_enabled(): logger('LeakGuard', '%s: dropped %d of %d (other show / other episode); first dropped: %r' % (provider, len(sources) - len(kept), len(sources), [i.get('name') for i in sources if i not in kept][:3]))
			except Exception: pass
			sources[:] = kept
	except Exception:
		pass
	return sources

_SPECIAL_WORD_PACK_RE = re.compile(r'(?<![a-z0-9])(?:specials?|ovas?|oads?|onas?)(?![a-z0-9])', re.I)

def is_special_request(season):
	"""True for a season-0 (specials) request. A bool or no season is not a specials request."""
	return season is not None and not isinstance(season, bool) and str(season).strip() == '0'

def special_pack_ok(title, release_title, aliases, year, episode):
	"""A specials request (season 0): a release that names 'special', 'specials', 'ova', 'ovas', 'oad', 'oads', 'ona' or 'onas' is a valid pack whatever season number it
	carries (none, or a different one), as long as the requested show is named in it. The show title is removed before the
	word is looked for, so 'Special Ops' does not make every one of its releases a special."""
	if not release_title: return False
	try:
		rel = str(release_title).lower()
		for name in [title] + list(aliases or []):
			if name:
				n = str(name).lower()
				rel = rel.replace(n.replace(' ', '.'), ' ').replace(n, ' ')
		if not _SPECIAL_WORD_PACK_RE.search(rel): return False
		if release_has_blocked_words(release_title, title, aliases, ''): return False
		return bool(check_title(title, release_title, aliases, year, 'pack', episode))
	except Exception:
		return False

def _should_accept_file_title_raw(title, release_title, aliases, year, season, episode, ep_name='', absolute_episode=None,
		in_cloud_folder=False, is_recovery_pass=False, filter_title=True):
	if is_special_request(season) and special_pack_ok(title, release_title, aliases, year, episode): return True
	"""Same decision as before, plus two leak guards that apply to every caller (debrid cloud, folders, external, usenet):
	- a name that states a DIFFERENT episode / season than the requested one is rejected (packs / ranges that cover the
	  requested episode or season, and names that state nothing, are never affected);
	- a pack-marked name ('... Complete Series', 'Batch', 'Seasons 1-5') must name the requested show: another show's pack
	  can no longer ride in on an episode number or an episode name."""
	ok = _should_accept_file_title_core(title, release_title, aliases, year, season, episode, ep_name=ep_name,
		absolute_episode=absolute_episode, in_cloud_folder=in_cloud_folder, is_recovery_pass=is_recovery_pass, filter_title=filter_title)
	if not ok: return False
	if in_cloud_folder and is_non_episode_name(release_title): return False
	if in_cloud_folder:
		# debrid cloud files keep their original matching (the folder proves the show) - except a file that plainly states another
		# season / episode ('Boss.S02E02' inside a folder for S01E14), which can never be the requested episode.
		try:
			if season and season != 'pack' and episode and names_other_episode(release_title, season, episode, absolute_episode) \
					and not epname_overrides_number(title, aliases, release_title, ep_name): return False
		except Exception: pass
		return True
	try:
		if season and season != 'pack' and episode:
			if names_other_episode(release_title, season, episode, absolute_episode) and not epname_overrides_number(title, aliases, release_title, ep_name): return False
			if release_looks_like_pack(release_title) and not show_named_in_release(title, release_title, aliases): return False
			if names_other_show(title, release_title, aliases): return False
	except Exception:
		pass
	return True

_NAME_GATE_PACK_WORDS = frozenset(('complete', 'collection', 'batch', 'boxset', 'box', 'seasons', 'season', 'series', 'all', 'full', 'integral'))
_NAME_GATE_YEAR_RE = re.compile(r'^(?:19|20)\d{2}$')

def _name_gate_title_tokens(title, aliases):
	out = []
	for cand in [title] + [a for a in (aliases or []) if alias_is_usable(a)]:
		tt = _filename_tokens(cand or '')
		if tt: out.append(tt)
	return out

def _name_gate_lead(release_title, title, aliases):
	"""(release_tokens_after_leading_[group]_tags, matched_title_tokens or None) - the title must LEAD the name."""
	rel = _filename_tokens(re.sub(r'^\s*(?:[\[(][^\])]*[\])]\s*)+', '', release_title or ''))
	for tt in _name_gate_title_tokens(title, aliases):
		if rel[:len(tt)] == tt: return rel, tt
	return rel, None

def release_looks_like_pack(release_title):
	low = (release_title or '').lower()
	try:
		if any(t in low for t in ('complete', 'all episodes', 'full season', 'boxset', 'box set')): return True
		if re.search(r'seasons?\s*\d+\s*(?:[-_.~]+\s*|\bto\b\s*)\d+', low) or re.search(r's\d+\s*(?:[-_.~]+\s*|\bto\b\s*)s?\d+', low): return True
		if not has_explicit_episode_token(low):
			strong = [h for h in pack_marker_hits(low) if h not in ('eps', 'episodes')]
			if strong or _PACK_EPS_RANGE_RE.search(low): return True
	except Exception:
		pass
	return False

def external_name_ok(media_type, title, release_title, aliases=None, year=0, season=None, episode=None, ep_name='', absolute_episode=None, is_pack=None):
	"""Strict 'is this really the requested title' gate for results that arrive with no title filtering of their own.

	TV pack: check_title(...,'pack') as in native_torrents - show title or alias anywhere in the pack name; falls back to should_accept_file_title.
	TV single/bare file: the show title leads the name and the S#E#/absolute number fits, OR the episode name is in the
	  file name (should_accept_file_title rules). A bare 'S01E04.mkv' with neither is dropped.
	Movie: the title is in the name AND a year within +/-1 of the movie's year follows it, so neither
	  'Alien Resurrection 1997' nor a year-less 'Alien' is accepted for 'Alien 1979'."""
	aliases = list(aliases or [])
	if not release_title: return False
	if media_type == 'movie':
		rel, lead = _name_gate_lead(release_title, title, aliases)
		try: want = int(year or 0)
		except Exception: want = 0
		if lead: after = rel[len(lead):]
		else:
			# Title not leading the name (site prefix etc.): accept only when it appears and the year follows it.
			after = None
			for tt in _name_gate_title_tokens(title, aliases):
				n = len(tt)
				for i in range(len(rel) - n + 1):
					if rel[i:i + n] == tt: after = rel[i + n:]; break
				if after is not None: break
			if after is None: return False
		years = [int(t) for t in after if _NAME_GATE_YEAR_RE.match(t)]
		# Movies need title AND year (+/-1). Year unknown for the request -> title alone.
		if want: return any(abs(y - want) <= 1 for y in years)
		return bool(lead) and (not after or bool(_TITLE_STOP_RE.match(after[0])) or bool(years))
	if is_special_request(season) and special_pack_ok(title, release_title, aliases, year, episode): return True
	if is_pack is None: is_pack = release_looks_like_pack(release_title)
	if is_pack:
		# Same pack rule native_torrents.py uses: check_title(..., 'pack') = show title (or alias) anywhere in the pack name, no
		# episode pattern needed on the folder. should_accept_file_title covers pack names that name the episode instead.
		if check_title(title, release_title, aliases, year, 'pack', episode): return True
	return bool(should_accept_file_title(title, release_title, aliases, year, season, episode, ep_name=ep_name or '',
		absolute_episode=absolute_episode, in_cloud_folder=False, is_recovery_pass=False, filter_title=True))

def strip_non_ascii_and_unprintable(text):
	"""Accent-fold first so Filter-by-Name keeps Pokémon→Pokemon / Léon→Leon."""
	try:
		text = _utils_normalize(text)
		result = ''.join(char for char in text if char in printable)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except: pass
	return text

def release_info_format(release_title):
	try:
		release_title = url_strip(release_title)
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		title = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '.').replace('-.', '.').replace('.-', '.').replace('--', '.')
		return title
	except:
		return release_title.lower()

def clean_title(title):
	try:
		if not title: return
		title = title.lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '"').replace('&amp;', '&')
		title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title)
	except: pass
	return title

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url: url = url.split('&dn=')[1]
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		title = re.sub(r'[^a-z0-9]+', ' ', url)
		if 'http' in title: return None
		if title == '': return None
		return title
	except: return None

def get_file_info(name_info=None, url=None, default_quality='SD'):
	title = None
	if name_info: title = name_info
	elif url: title = url_strip(url)
	if not title: return 'SD', ''
	quality = get_release_quality(title) or default_quality
	info = get_info(title)
	return quality, info

def get_release_quality(release_info):
	if any(i in release_info for i in ('.scr.', 'screener', 'dvdscr', 'dvd.scr', '.r5', '.r6')):
		return 'SCR'
	if any(i in release_info for i in ('.cam.', 'camrip', 'hdcam', '.hd.cam', 'hqcam', '.hq.cam', 'cam.rip', 'dvdcam')):
		return 'CAM'
	if any(i in release_info for i in ('.tc.', '.ts.', 'tsrip', 'hdts', 'hdtc', '.hd.tc', 'dvdts', 'telesync', 'tele.sync', 'telecine', 'tele.cine')):
		return 'TELE'
	if any(i in release_info for i in ('720', '720p', '720i', 'hd720', '720hd', 'hd720p', '72o', '72op')):
		return '720p'
	if any(i in release_info for i in ('1080', '1080p', '1080i', 'hd1080', '1080hd', 'hd1080p', 'm1080p', 'fullhd', 'full.hd', '1o8o', '1o8op',
		'108o', '108op', '1o80', '1o80p')): return '1080p'
	if any(i in release_info for i in ('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd', 'hd2160', '2160hd', '2160', '2160p', '216o', '216op')):
		return '4K'
	return None

def get_info(title):
	# thanks 123Venom and gaiaaaiaai, whom I knicked most of this code from. :)
	info = []
	info_append = info.append
	if any(i in title for i in ('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')):
		info_append('[B]3D[/B]')
	if '.sdr' in title:
		info_append('SDR')
	elif any(i in title for i in ('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')):
		info_append('[B]D/VISION[/B]')
	elif any(i in title for i in ('2160p.bluray.hevc.truehd', '2160p.bluray.hevc.dts', '2160p.bluray.hevc.lpcm', '2160p.blu.ray.hevc.truehd', '2160p.blu.ray.hevc.dts',
		'2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.us.bluray.hevc.truehd', '2160p.us.bluray.hevc.dts', '.hdr.', 'hdr10', 'hdr.10', 'uhd.bluray.2160p',
		'uhd.blu.ray.2160p')):
		info_append('[B]HDR[/B]')
	elif all(i in title for i in ('2160p', 'remux')):
		info_append('[B]HDR[/B]')
	if '[B]D/VISION[/B]' in info:
		if any(i in title for i in ('.hdr.', '.hdr10.', 'hdr.10')) or 'hybrid' in title:
			info_append('[B]HDR[/B]')
		if '[B]HDR[/B]' in info:
			info_append('[B]HYBRID[/B]')
	if any(i in title for i in ('avc', 'h264', 'h.264', 'x264', 'x.264')):
		info_append('AVC')
	elif '.av1.' in title:
		info_append('[B]AV1[/B]')
	elif any(i in title for i in ('h265', 'h.265', 'hevc', 'x265', 'x.265')):
		info_append('[B]HEVC[/B]')
	elif any(i in info for i in ('[B]HDR[/B]', '[B]D/VISION[/B]')):
		info_append('[B]HEVC[/B]')
	if any(i in title for i in ('.imax.', '.(imax).', '.(.imax.).')):
		info_append('IMAX')
	elif any(i in title for i in ('.enhanced.', '.upscaled.', '.enhance.', '.upscale.', '.ai.')):
		info_append('[B]AI ENHANCED/UPSCALED[/B]')
	if '.atvp' in title:
		info_append('APPLETV+')
	elif any(i in title for i in ('xvid', '.x.vid')):
		info_append('XVID')
	elif any(i in title for i in ('divx', 'div2', 'div3', 'div4')):
		info_append('DIVX')
	if any(i in title for i in ('remux', 'bdremux')):
		info_append('REMUX')
	if any(i in title for i in ('bluray', 'blu.ray', 'bdrip', 'bd.rip')):
		info_append('BLURAY')
	elif any(i in title for i in ('dvdrip', 'dvd.rip')):
		info_append('DVD')
	elif any(i in title for i in ('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip')):
		info_append('WEB')
	elif 'hdtv' in title:
		info_append('HDTV')
	elif 'pdtv' in title:
		info_append('PDTV')
	elif any(i in title for i in ('.hdrip', '.hd.rip')):
		info_append('HDRIP')
	if 'atmos' in title:
		info_append('ATMOS')
	if any(i in title for i in ('true.hd', 'truehd')):
		info_append('TRUEHD')
	if any(i in title for i in ('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3')):
		info_append('DD+')
	elif any(i in title for i in ('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')):
		info_append('DD-EX')
	elif any(i in title for i in ('dd2.', 'dd5', 'dd7', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')):
		info_append('DD')
	if 'aac' in title:
		info_append('AAC')
	elif 'mp3' in title:
		info_append('MP3')
	elif '.flac.' in title:
		info_append('FLAC')
	elif 'opus' in title and not title.endswith('opus.'):
		info_append('OPUS')
	if any(i in title for i in ('.dts.x.', 'dtsx')):
		info_append('DTS-X')
	elif any(i in title for i in ('hd.ma', 'hdma')):
		info_append('DTS-HD MA')
	elif any(i in title for i in ('dts.hd.', 'dtshd')):
		info_append('DTS-HD')
	elif '.dts' in title:
		info_append('DTS')
	if any(i in title for i in ('ch8.', '8ch.', '7.1ch', '7.1.')):
		info_append('8CH')
	elif any(i in title for i in ('ch7.', '7ch.', '6.1ch', '6.1.')):
		info_append('7CH')
	elif any(i in title for i in ('ch6.', '6ch.', '5.1ch', '5.1.')):
		info_append('6CH')
	elif any(i in title for i in ('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo')):
		info_append('2CH')
	if '.wmv' in title:
		info_append('WMV')
	elif any(i in title for i in ('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl')):
		info_append('MPEG')
	elif '.avi' in title:
		info_append('AVI')
	elif any(i in title for i in ('.mkv', 'matroska')):
		info_append('MKV')
	# audio language tags: subtitle-adjacent codes (eng.subs, subs.eng) are subtitles, not audio
	lang_title = re.sub(r'\.(subs?|subbed)\.([a-z]{2,12})\.', '.', title)
	lang_title = re.sub(r'\.([a-z]{2,12})\.(subs?|subbed)\.', '.', lang_title)
	for _, lang_tag, lang_patterns in audio_lang_choices():
		if any(i in lang_title for i in lang_patterns):
			info_append(lang_tag)
	if any(i in title for i in ('hindi.eng', 'ara.eng', 'ces.eng', 'chi.eng', 'cze.eng', 'dan.eng', 'dut.eng', 'ell.eng', 'esl.eng', 'esp.eng', 'fin.eng', 'fra.eng',
		'fre.eng', 'frn.eng', 'gai.eng', 'ger.eng', 'gle.eng', 'gre.eng', 'gtm.eng', 'heb.eng', 'hin.eng', 'hun.eng', 'ind.eng', 'iri.eng', 'ita.eng', 'jap.eng',
		'jpn.eng', 'kor.eng', 'lat.eng', 'lebb.eng', 'lit.eng', 'nor.eng', 'pol.eng', 'por.eng', 'rus.eng', 'som.eng', 'spa.eng', 'sve.eng', 'swe.eng', 'tha.eng',
		'tur.eng', 'uae.eng', 'ukr.eng', 'vie.eng', 'zho.eng', 'dual.audio', 'multi')):
		info_append('MULTI-LANG')
	if any(i in title for i in ('1xbet', 'betwin')):
		info_append('ADS')
	if any(i in title for i in ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs', 'subbed')):
		info_append('SUBS')
	return ' | '.join(filter(None, info))

def get_cache_expiry(media_type, meta, season):
	try:
		current_date = get_datetime()
		if media_type == 'movie':
			premiered = jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True)
			difference = subtract_dates(current_date, premiered)
			if difference == 0: single_expiry = 3
			elif difference <= 7: single_expiry = 24
			elif difference <= 14: single_expiry = 48
			elif difference <= 21: single_expiry = 72
			elif difference <= 30: single_expiry = 96
			elif difference <= 60: single_expiry = 168
			else: single_expiry = 336
			season_expiry, show_expiry = 0, 0
		else:
			recently_ended = False
			extra_info = meta['extra_info']
			ended = extra_info['status'] in ('Ended', 'Canceled')
			premiered = adjust_premiered_date(meta['premiered'], date_offset())[0]
			difference = subtract_dates(current_date, premiered)
			last_episode_to_air = jsondate_to_datetime(extra_info['last_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True)
			last_ep_difference = subtract_dates(current_date, last_episode_to_air)
			if ended and last_ep_difference <= 14: recently_ended = True
			if not ended or recently_ended:
				if difference == 0: single_expiry = 3
				elif difference <= 3: single_expiry = 24
				elif difference <= 7: single_expiry = 72
				else: single_expiry = 168
				if meta['total_seasons'] == season:
					if last_ep_difference <= 7: season_expiry = 72
					else: season_expiry = 240
				else: season_expiry = 720
				show_expiry = 240
			else: single_expiry, season_expiry, show_expiry = 240, 720, 720
	except: single_expiry, season_expiry, show_expiry = 72, 72, 240
	return single_expiry, season_expiry, show_expiry

def get_external_cache_status(debrid, unchecked_hashes, data, active_debrid):
	def _process(service, hashes):
		result = []
		if service in ('mediafusion', 'torrentio'):
			if service == 'mediafusion':
				base_link, name_test = 'https://mediafusion.elfhosted.com/%s=%s' % (debrid_name, token), '⚡'
				params = json.dumps({'enable_catalogs': False, 'max_streams_per_resolution': 99, 'torrent_sorting_priority':[], 'certification_filter': ['Disable'],
										'nudity_filter': ['Disable'], 'streaming_provider': {'token': token, 'service': debrid_name,
										'only_show_cached_streams': True}}).encode('utf-8')
				headers = {'encoded_user_data': base64.b64encode(params).decode('utf-8')}
			elif service == 'torrentio':
				base_link, name_test = 'https://torrentio.strem.fun/%s=%s' % (debrid_name, token), '[RD+]'
				headers = {'User-Agent': 'Mozilla/5.0'}
			try:
				if 'tvshowtitle' in data: url = '%s%s' % (base_link, '/stream/series/%s:%s:%s.json' % (imdb_id, data['season'], data['episode']))
				else: url = '%s%s' % (base_link, '/stream/movie/%s.json' % imdb_id)
				result = requests.get(url, headers=headers, timeout=9)
				result = result.json()['streams']
				if result:
					result = [re.search(r'\b\w{40}\b', i.get('url')) for i in result if name_test in i['name']]
					result = [i.group() for i in result if i]
			except: pass
		elif service == 'dmm':
			import ctypes, random
			def get_secret():
				def calc_value_alg(t, n, const):
					temp = t ^ n
					t = ctypes.c_long((temp * const)).value
					t4 = ctypes.c_long(t << 5).value
					t5 = ctypes.c_long((t & 0xFFFFFFFF) >> 27).value
					return t4 | t5
				def slice_hash(s, n):
					half = int(len(s) // 2)
					left_s, right_s = s[:half], s[half:]
					left_n, right_n = n[:half], n[half:]
					l = ''.join(ls + ln for ls, ln in zip(left_s, left_n))
					return l + right_n[::-1] + right_s[::-1]
				def generate_hash(e):
					t = ctypes.c_long(0xDEADBEEF ^ len(e)).value
					a = 1103547991 ^ len(e)
					for ch in e:
						n = ord(ch)
						t = calc_value_alg(t, n, 2654435761)
						a = calc_value_alg(a, n, 1597334777)
					t = ctypes.c_long(t + ctypes.c_long(a * 1566083941)).value
					a = ctypes.c_long(a + ctypes.c_long(t * 2026486597)).value
					return (t ^ a) & 0xFFFFFFFF
				ran = random.randrange(10 ** 80)
				hex_str = f"{ran:064x}"[:8]
				timestamp = int(time.time())
				dmmProblemKey = f"{hex_str}-{timestamp}"
				s = generate_hash(dmmProblemKey)
				s = f"{s:x}"
				n = generate_hash("debridmediamanager.com%%fe7#td00rA3vHz%VmI-" + hex_str)
				n = f"{n:x}"
				solution = slice_hash(s, n)
				return dmmProblemKey, solution
			def fetch(hash_chunk):
				try:
					json_data = {'dmmProblemKey': dmmProblemKey, 'solution': solution, 'imdbId': imdb_id, 'hashes': hash_chunk}
					r = requests.post('https://debridmediamanager.com/api/availability/check', json=json_data, timeout=9).json()
					r = [i['hash'] for i in r['available'] if 'hash' in i]
					result_extend(r)
				except: pass
			result = []
			result_extend = result.extend
			dmmProblemKey, solution = get_secret()
			unchecked_hashes_chunks = list(chunks(unchecked_hashes, 100))
			threads = [Thread(target=fetch, args=(item,)) for item in unchecked_hashes_chunks]
			[i.start() for i in threads]
			[i.join() for i in threads]
		results.extend(result)
	try:
		results = []
		imdb_id = data['imdb']
		debrid_name, services, token = {'Real-Debrid': ('realdebrid', ['torrentio'], get_setting('nightshift.rd.token')),
									'AllDebrid': ('alldebrid', ['mediafusion'], get_setting('nightshift.ad.token'))}[debrid]
		threads = [Thread(target=_process, args=(item, unchecked_hashes)) for item in services]
		[i.start() for i in threads]
		[i.join() for i in threads]
		results = list(set(results))
	except: pass
	if debrid == 'Real-Debrid':
		try: _process('dmm', [i for i in unchecked_hashes if not i in results])
		except: pass
	return results

# ---- match cache wrappers (caches/watching_cache.py): one decision per release name per request -------------------------------------
def _match_cache_key(fn, args):
	title, release_title, aliases, year, season, episode, ep_name, absolute, flags = args
	return watching_cache.match_key(fn, title, release_title, tuple(aliases or ()), year, season, episode, ep_name, absolute, flags, tuple(sorted(_alt_pairs(season, episode, absolute) or ())) if (season and episode) else ())

_LEADING_ARTICLE_RE = re.compile(r'^(?:a|an|the)\s+', re.I)

def article_variants(title):
	"""'Returner's Magic Should Be Special' <-> 'A Returner's Magic Should Be Special': releases and TMDb disagree about a leading article."""
	try:
		t = (title or '').strip()
		if not t: return []
		if _LEADING_ARTICLE_RE.match(t):
			bare = _LEADING_ARTICLE_RE.sub('', t, count=1).strip()
			return [bare] if bare else []
		return ['A ' + t, 'The ' + t, 'An ' + t]
	except Exception:
		return []

def _with_article_variants(title, aliases):
	extra = [v for v in article_variants(title) if v not in (aliases or [])]
	return list(aliases or []) + extra

def episode_any_match(title, release_title, aliases, year, season, episode, ep_name='', absolute_episode=None, filter_title=True, allow_series_prefix=False):
	aliases = _with_article_variants(title, aliases)
	try:
		key = _match_cache_key('any', (title, release_title, aliases, year, season, episode, ep_name, absolute_episode, (bool(filter_title), bool(allow_series_prefix))))
		hit = watching_cache.match_get(key)
		if hit is not None: return hit[0], list(hit[1])
	except Exception:
		key = None
	ok, why = _episode_any_match_raw(title, release_title, aliases, year, season, episode, ep_name=ep_name, absolute_episode=absolute_episode, filter_title=filter_title, allow_series_prefix=allow_series_prefix)
	if key:
		try: watching_cache.match_put(key, ok, why)
		except Exception: pass
	return ok, why

def should_accept_file_title(title, release_title, aliases, year, season, episode, ep_name='', absolute_episode=None,
		in_cloud_folder=False, is_recovery_pass=False, filter_title=True):
	_series_reason = series_tag_reject(release_title, season, episode, title=title, aliases=aliases, ep_name=ep_name)
	if _series_reason:
		diag_log('CloudMatch', 'SERIES-TAG REJECT: %s | file=%r' % (_series_reason, release_title))
		return False
	try:
		_is_special_request = int(season) == 0 and episode not in (None, '', 0) and bool(ep_name) and bool(title)
	except Exception:
		_is_special_request = False
	if _is_special_request:
		# a special / film / OVA entry lists only the files that match it by name, not every file the show has
		# the show title, with a sub-series tag such as '(Tachikomatic Days)' left out: the tag was checked by the series guard above
		_file_name = str(release_title or '').replace('\\', '/').rsplit('/', 1)[-1]
		_untagged = re.sub(r'\([^()]*\)', ' ', _file_name)
		_base_title = re.split(r'\s*(?::|\s[-\u2013\u2014]\s)\s*', str(title or ''))[0].strip() or title
		_matched = bool(cloud_episode_matches_all(0, episode, release_title, absolute_episode, ep_name, title=title, container=True))
		# inside a folder that was already matched to the show, the folder is the show: the file's own match is enough.
		# Anywhere else the file name must start with the show's title.
		if in_cloud_folder: ok = _matched
		else: ok = _matched and any(_title_in_release(t, r, aliases, ep_name) or _starts_with_title(t, r) for t in (title, _base_title) for r in (_file_name, _untagged))
		if not ok:
			diag_log('CloudMatch', 'SPECIAL ACCEPT REJECT: ep_name=%r file=%r' % (ep_name, release_title))
		return ok
	if episode not in (None, '', 0) and season not in (None, '', 'pack') and _sub_series_slot_match(release_title, ep_name) and _title_in_release(title, release_title, aliases, ep_name):
		diag_log('CloudMatch', 'SUB-SERIES SLOT ACCEPT: %r' % release_title)
		return True
	try:
		key = _match_cache_key('accept', (title, release_title, aliases, year, season, episode, ep_name, absolute_episode, (bool(in_cloud_folder), bool(is_recovery_pass), bool(filter_title)), tuple(_SPECIAL_LINKS)))
		hit = watching_cache.match_get(key)
		if hit is not None: return hit[0]
	except Exception:
		key = None
	ok = _should_accept_file_title_raw(title, release_title, aliases, year, season, episode, ep_name=ep_name, absolute_episode=absolute_episode,
		in_cloud_folder=in_cloud_folder, is_recovery_pass=is_recovery_pass, filter_title=filter_title)
	if not ok and season and season != 'pack' and episode:
		# the same episode under its other numbering ('Show S02E01' for TMDb S01E25): cloud folders, files, folders and usenet all pass here
		for _s, _e in alt_gate_pairs(season, episode, absolute_episode):
			if _should_accept_file_title_raw(title, release_title, aliases, year, _s, _e, ep_name=ep_name, absolute_episode=None,
					in_cloud_folder=in_cloud_folder, is_recovery_pass=is_recovery_pass, filter_title=filter_title):
				ok = True
				break
			try:
				if loose_release_kind(release_title, title, aliases, _s, _e, None) == 'episode':     # '[Group] Show 2nd Season - 01'
					ok = True
					break
			except Exception: pass
	if key:
		try: watching_cache.match_put(key, ok, ())
		except Exception: pass
	return ok
