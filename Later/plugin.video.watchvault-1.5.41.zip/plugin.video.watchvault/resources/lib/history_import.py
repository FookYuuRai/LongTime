# -*- coding: utf-8 -*-
"""One-time (on demand) import of watched history into WatchVault from MDBList, Trakt, Simkl or PunchPlay.
Adds only: items WatchVault already has as watched are skipped and nothing is marked unwatched.
Each provider's watches are stored with that provider's name as the source, so the sync echo guard
never sends them back to the provider they came from."""
import threading

import xbmc

import fullscreen
import login_flow
import provider_sync as ps
import watchvault as wv

LABELS = {'mdblist': 'MDBList', 'trakt': 'Trakt', 'simkl': 'Simkl', 'punchplay': 'PunchPlay'}
_running = {'busy': False}


def _ts(value):
    """Provider dates -> WatchVault's format (UTC, 'YYYY-MM-DDTHH:MM:SSZ'); None lets WatchVault use now."""
    if not value:
        return None
    try:
        from datetime import datetime
        return datetime.strptime(str(value)[:19], '%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%dT%H:%M:%SZ')
    except Exception:
        return None


def _num(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _movie(title, year, tmdb, imdb, tvdb, played, mal=None, anilist=None):
    return {'kind': 'movie', 'title': title, 'year': year, 'tmdb_id': tmdb, 'imdb_id': imdb,
            'tvdb_id': tvdb, 'mal_id': _num(mal), 'anilist_id': _num(anilist), 'played_at': played}


def _episode(show, season, number, ep_tmdb, ep_tvdb, numbering, played, ep_title=None):
    return {'kind': 'episode', 'title': show.get('title'), 'year': show.get('year'),
            'tvdb_id': show.get('tvdb'), 'imdb_id': show.get('imdb'), 'tmdb_id': show.get('tmdb'),
            'mal_id': _num(show.get('mal')), 'anilist_id': _num(show.get('anilist')),
            'season': season, 'episode': number, 'ep_tmdb': ep_tmdb, 'ep_tvdb': ep_tvdb,
            'numbering': numbering, 'played_at': played, 'ep_title': ep_title}


def _normalize(provider, kind, row):
    """Yield normalized movie/episode records from one raw row of a provider's history."""
    if provider == 'mdblist':
        if kind == 'movie':
            m = row.get('movie') or {}
            ids = m.get('ids') or {}
            yield _movie(m.get('title'), m.get('year'), ids.get('tmdb'), ids.get('imdb'), None,
                         _ts(row.get('watched_at')))
            return
        ep = row.get('episode') or {}
        sh = ep.get('show') or {}
        show = {'title': sh.get('title'), 'year': sh.get('year'), 'tvdb': (sh.get('ids') or {}).get('tvdb'),
                'imdb': (sh.get('ids') or {}).get('imdb'), 'tmdb': (sh.get('ids') or {}).get('tmdb')}
        eids = ep.get('ids') or {}
        tv = ep.get('tvdb') if isinstance(ep.get('tvdb'), dict) else {}
        tv_ids = ep.get('tvdb_ids') if isinstance(ep.get('tvdb_ids'), dict) else {}
        # Which episode: TVDB official order when MDBList sends it, otherwise the default order.
        # Either way the watch is stored in TMDb numbering (what Nightshift's next-episode logic checks),
        # taken from the same row, so TVDB numbers are never written.
        order = 'tvdb' if (tv.get('season_number') is not None and tv.get('episode_number') is not None) else 'default'
        season, number = ep.get('season'), ep.get('number')
        rec = _episode(show, season, number, eids.get('tmdb'), tv_ids.get('episode') or eids.get('tvdb'),
                       'tmdb', _ts(row.get('last_watched_at') or row.get('watched_at')), ep.get('name'))
        rec['order'] = order
        yield rec
        return
    if provider == 'trakt':
        played = _ts(row.get('watched_at'))
        if row.get('type') == 'movie':
            m = row.get('movie') or {}
            ids = m.get('ids') or {}
            yield _movie(m.get('title'), m.get('year'), ids.get('tmdb'), ids.get('imdb'), ids.get('tvdb'), played)
        elif row.get('type') == 'episode':
            s = row.get('show') or {}
            sids = s.get('ids') or {}
            e = row.get('episode') or {}
            eids = e.get('ids') or {}
            show = {'title': s.get('title'), 'year': s.get('year'), 'tvdb': sids.get('tvdb'),
                    'imdb': sids.get('imdb'), 'tmdb': sids.get('tmdb')}
            # Trakt numbering is not verified as TMDb; the record is kept only to be skipped (never written).
            yield _episode(show, e.get('season'), e.get('number'), eids.get('tmdb'), eids.get('tvdb'),
                           'unverified', played, e.get('title'))
        return
    if provider == 'punchplay':
        played = _ts(row.get('watchedAt'))
        if row.get('type') == 'movie':
            yield _movie(row.get('title'), row.get('year'), row.get('tmdbId'), None, None, played)
        elif row.get('type') == 'episode' and row.get('showTmdbId'):
            season = row.get('sourceSeason') if row.get('sourceSeason') is not None else row.get('season')
            number = row.get('sourceEpisode') if row.get('sourceEpisode') is not None else row.get('episode')
            show = {'title': row.get('title'), 'year': row.get('year'), 'tmdb': row.get('showTmdbId')}
            yield _episode(show, season, number, row.get('tmdbId'), None, 'tmdb', played, row.get('episodeTitle'))
        return
    if provider == 'simkl':
        ids = row.get('ids') or {}
        if kind == 'movie':
            yield _movie(row.get('title'), row.get('year'), ids.get('tmdb'), ids.get('imdb'), ids.get('tvdb'),
                         _ts(row.get('last_watched_at')), ids.get('mal'), ids.get('anilist'))
            return
        show = {'title': row.get('title'), 'year': row.get('year'), 'tvdb': ids.get('tvdb'),
                'imdb': ids.get('imdb'), 'tmdb': ids.get('tmdb'), 'mal': ids.get('mal'),
                'anilist': ids.get('anilist')}
        for season in row.get('seasons') or []:
            for ep in season.get('episodes') or []:
                if not ep.get('watched_at'):
                    continue            # only episodes Simkl reports as watched
                eids = ep.get('ids') or {}
                yield _episode(show, season.get('number'), ep.get('number'), eids.get('tmdb'),
                               eids.get('tvdb') or eids.get('tvdb_id'), 'unverified',
                               _ts(ep.get('watched_at')), ep.get('title'))
        return


READERS = {'mdblist': ps.mdblist_watched_rows, 'trakt': ps.trakt_history_rows,
           'simkl': ps.simkl_watched_rows, 'punchplay': ps.punchplay_history_rows}


def _resolve_by_name(rec):
    """Unverified-numbering episodes (Trakt, Simkl) are not written: their numbers are not TMDb numbers, and
    TMDb episode numbering needs TMDb episode data that the TVDB key does not provide."""
    return None


def _apply(provider, rec, counts):
    if rec['kind'] == 'movie':
        if not (rec.get('tmdb_id') or rec.get('imdb_id')):
            counts['skipped'] += 1
            return
        kw = dict(title=rec.get('title'), year=rec.get('year'), tmdb_id=rec.get('tmdb_id'), imdb_id=rec.get('imdb_id'),
                  mal_id=rec.get('mal_id'), anilist_id=rec.get('anilist_id'))
        if wv.is_watched(**kw):
            counts['skipped'] += 1
            return
        res = wv.mark_watched(watched=True, source=provider, played_at=rec.get('played_at'), notify=False, **kw)
        counts['movies' if res and res.get('ok') is not False else 'skipped'] += 1
        return
    if rec.get('season') is None or rec.get('episode') is None or \
            not (rec.get('tvdb_id') or rec.get('imdb_id') or rec.get('tmdb_id')):
        counts['skipped'] += 1
        return
    if rec['numbering'] != 'tmdb':
        resolved = _resolve_by_name(rec)
        if resolved is None:
            counts['unverified'] += 1
            return
        rec['season'], rec['episode'] = resolved
        rec['numbering'], rec['order'] = 'tmdb', 'name'
    counts[{'tvdb': 'tvdb_order', 'name': 'by_name'}.get(rec.get('order'), 'default_order')] += 1
    kw = dict(title=rec.get('title'), year=rec.get('year'), tvdb_id=rec.get('tvdb_id'),
              imdb_id=rec.get('imdb_id'), tmdb_id=rec.get('tmdb_id'),
              mal_id=rec.get('mal_id'), anilist_id=rec.get('anilist_id'))
    ids = dict(episode_tmdb_id=rec.get('ep_tmdb'), episode_tvdb_id=rec.get('ep_tvdb'))
    if wv.is_watched(season=rec['season'], episode=rec['episode'], **dict(ids, **kw)):
        counts['skipped'] += 1
        return
    res = wv.mark_watched(season=rec['season'], episode=rec['episode'], watched=True, source=provider,
                          played_at=rec.get('played_at'), episode_title=rec.get('ep_title'),
                          notify=False, **dict(ids, **kw))
    counts['episodes' if res and res.get('ok') is not False else 'skipped'] += 1


def _progress(label, counts):
    fullscreen.update_notice(label + ' import', 'Importing watched history...\n\n'
                             'Added: %d movies, %d episodes\nAlready watched or not matched: %d\n'
                             'Order: TVDB official %d, default %d. Not verified (skipped): %d'
                             % (counts['movies'], counts['episodes'], counts['skipped'],
                                counts['tvdb_order'], counts['default_order'], counts['unverified']))


def run(provider):
    label = LABELS[provider]
    heading = label + ' import'
    counts = {'movies': 0, 'episodes': 0, 'skipped': 0, 'unverified': 0, 'tvdb_order': 0, 'default_order': 0,
              'by_name': 0}
    fullscreen.close_modal_settings()
    fullscreen.show_notice(heading, 'Starting import from %s...' % label)
    n = 0
    try:
        for kind, row in READERS[provider]():
            for rec in _normalize(provider, kind, row):
                _apply(provider, rec, counts)
            n += 1
            if n % 200 == 0:
                _progress(label, counts)
        text = ('Done. Added %d movies and %d episodes.\nAlready watched or not matched: %d.\n'
                'Order used: TVDB official %d, default %d, by episode name %d. Not verified (skipped): %d.'
                % (counts['movies'], counts['episodes'], counts['skipped'],
                   counts['tvdb_order'], counts['default_order'], counts['by_name'], counts['unverified']))
    except Exception as e:
        xbmc.log('[WatchVault import] %s stopped: %s' % (provider, e), xbmc.LOGWARNING)
        text = ('Import stopped: %s\nAdded so far: %d movies, %d episodes. Run it again later to finish.'
                % (e, counts['movies'], counts['episodes']))
    login_flow._finish(heading, text)
    _running['busy'] = False


def tick():
    """Called once a second by the service. Starts a queued import in its own thread."""
    raw = login_flow._win().getProperty('watchvault.job') or ''
    if not raw.startswith('import:') or _running['busy']:
        return
    provider = raw.split(':', 1)[1]
    login_flow._win().clearProperty('watchvault.job')
    if provider not in READERS:
        return
    _running['busy'] = True
    threading.Thread(target=run, args=(provider,), daemon=True).start()


def request(provider):
    """Called by the plugin when an import button is pressed."""
    login_flow._win().setProperty('watchvault.job', 'import:' + provider)
