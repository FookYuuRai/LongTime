# -*- coding: utf-8 -*-
import re
import json
import os
import pickle
import sys
import time
import xbmcplugin
from threading import Thread, current_thread
from windows.base_window import open_window, create_window
from caches.episode_groups_cache import episode_groups_cache
from caches.settings_cache import get_setting
from scrapers import external, folders
from modules import debrid, kodi_utils, settings, metadata, watched_status
from modules.player import NightShiftPlayer
from modules.source_utils import get_cache_expiry, make_alias_dict, include_exclude_filters, get_file_info, release_info_format, audio_lang_choices, matches_english_or_untagged
from modules.release_groups import release_group_boost
from modules.native_torrents import NATIVE_TORRENT_SCRAPERS
from modules.utils import clean_file_name, string_to_float, safe_string, remove_accents, get_datetime, append_module_to_syspath, manual_function_import
from modules.source_utils import absolute_episode_from_season_data, diag_log, diag_enabled, pick_pack_episode_file
from modules.source_utils import nzb_debug_enabled
# ###FIX### This alias was commented out, but resolve_sources()/play_file() call bare logger(...):
# NameError on the very first line of resolve_sources() (and again in its except handler) -> every
# debrid resolve returned None and playback aborted.
logger = kodi_utils.logger

PROP_SOURCES_BUSY = 'nightshift.sources_busy'
PROP_SOURCES_OWNER = 'nightshift.sources_busy_owner'
PROP_SOURCES_BUSY_AT = 'nightshift.sources_busy_at'
PROP_SOURCES_CANCELING = 'nightshift.sources_canceling'
# Live scrapes refresh the heartbeat every loop pass; anything older than this with no
# playback means the owning scrape died (e.g. Browse flow killed mid-wait) — clear it.
SOURCES_BUSY_STALE_SECONDS = 120
# Widget cancel → immediate second PlayMedia: wait this long for the prior scrape to drop
# the busy lock before toasting "Source search already running".
SOURCES_BUSY_WAIT_SECONDS = 4.0
PROP_RESOLVE_BUSY = 'nightshift.resolve_busy'
PROP_RESOLVE_OWNER = 'nightshift.resolve_busy_owner'
PROP_RESOLVE_CANCEL = 'nightshift.resolve_cancelled'
PROP_PLAY_OPENING = 'nightshift.play_opening'
PROP_BROWSE_RETURN_SOURCES = 'nightshift.browse_return_sources'
PROP_NEXTEP_SCRAPE_READY = 'nightshift.nextep_scrape_ready'
# Per-show Autoplay link (caches/autoplay_cache.py): the pack / cloud folder / direct folder the user first chose
PLAY_ORIGIN_CLOUD_SCRAPERS = ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud', 'folders')
PROP_NEXTEP_SCRAPE_KEY = 'nightshift.nextep_scrape_key'
PROP_NEXTEP_ALERT_KEY = 'nightshift.nextep_alert_key'
PROP_NEXTEP_AUTOPLAY_CANCELLED = 'nightshift.nextep_autoplay_cancelled'
PROP_NEXTEP_NATURAL_END = 'nightshift.nextep_natural_end'
PROP_AUTOSCRAPE_NEXTEP_READY = 'nightshift.autoscrape_nextep_ready'
PROP_NEXTEP_HANDOFF_META = 'nightshift.nextep_handoff_meta'
PROP_NEXTEP_HANDOFF_VISIBLE = 'nightshift.nextep_handoff.visible'
PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS = 'nightshift.random_continual_skip_attempts'
_HANDOFF_COVER = None
_HANDOFF_COVER_THREAD = None
_HANDOFF_COVER_SHOWN = False
RANDOM_CONTINUAL_MAX_SKIPS = 25
_NEXTEP_NATURAL_END_SEC = 15
_NEXTEP_AUTOPLAY_STASH = {}
_NEXTEP_PLAY_STASH_PATH = None
_NEXTEP_STASH_PLAY_IN_FLIGHT = False

def _nextep_stash_play_in_flight():
	return _NEXTEP_STASH_PLAY_IN_FLIGHT

def _set_nextep_stash_play_in_flight(active):
	global _NEXTEP_STASH_PLAY_IN_FLIGHT
	_NEXTEP_STASH_PLAY_IN_FLIGHT = bool(active)

def _nextep_play_stash_path():
	global _NEXTEP_PLAY_STASH_PATH
	if not _NEXTEP_PLAY_STASH_PATH:
		_NEXTEP_PLAY_STASH_PATH = os.path.join(kodi_utils.addon_profile(), 'nextep_play_stash.pkl')
	return _NEXTEP_PLAY_STASH_PATH

def persist_nextep_play_stash(stash):
	try:
		with open(_nextep_play_stash_path(), 'wb') as handle:
			pickle.dump(stash, handle, protocol=2)
		return True
	except Exception as exc:
		kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode stash persist failed: %s' % exc)
		return False

def consume_persisted_nextep_play_stash():
	path = _nextep_play_stash_path()
	try:
		if not os.path.isfile(path):
			return None
		with open(path, 'rb') as handle:
			stash = pickle.load(handle)
		os.remove(path)
		return stash
	except Exception as exc:
		kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode stash load failed: %s' % exc)
		try: os.remove(path)
		except: pass
		return None

def schedule_nextep_stashed_play(stash, show_busy=None):
	if not stash:
		return False
	if nextep_autoplay_cancelled() or nextep_end_play_superseded(stash.get('meta') if stash else None):
		try:
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode play: skipped schedule (superseded by user playback)')
		except:
			pass
		return False
	if _nextep_stash_play_in_flight():
		try:
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode play: skipped duplicate schedule (stash resolve in flight)')
		except:
			pass
		return False
	if not persist_nextep_play_stash(stash):
		return False
	_set_nextep_stash_play_in_flight(True)
	if show_busy is None:
		# DialogBusy is torn down when fullscreen closes; prefer the resolve modal while still playing.
		show_busy = not kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)')
	if show_busy and not kodi_utils.get_visibility('Window.IsActive(busydialognocancel)'):
		kodi_utils.show_busy_dialog()
	try:
		meta = stash.get('meta') or {}
		kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode play: scheduled resolve for %s S%02dE%02d' % (
			meta.get('title', ''), meta.get('season', 0), meta.get('episode', 0)))
	except:
		pass
	play_key = settings.playback_key()
	kodi_utils.run_plugin({'mode': 'playback.%s' % play_key, play_key: play_key, 'nextep_stash_play': 'true'})
	return True

def _nextep_stash_key(meta):
	try:
		return '%s_%s_%s' % (meta.get('tmdb_id'), int(meta.get('season')), int(meta.get('episode')))
	except:
		return None

def peek_nextep_autoplay_stash():
	key = kodi_utils.get_property(PROP_NEXTEP_SCRAPE_KEY)
	if not key: return None
	return _NEXTEP_AUTOPLAY_STASH.get(key)

def nextep_autoplay_cancelled():
	return kodi_utils.get_property(PROP_NEXTEP_AUTOPLAY_CANCELLED) == 'true'

def mark_nextep_autoplay_cancelled():
	kodi_utils.set_property(PROP_NEXTEP_AUTOPLAY_CANCELLED, 'true')
	_set_nextep_stash_play_in_flight(False)
	clear_nextep_autoplay_stash()
	clear_orphan_nextep_play_stash()
	kodi_utils.clear_property(PROP_NEXTEP_ALERT_KEY)
	kodi_utils.clear_property(PROP_AUTOSCRAPE_NEXTEP_READY)
	kodi_utils.clear_property(kodi_utils.PROP_AUTOSCRAPE_TOAST_SHOWN)
	kodi_utils.clear_property(PROP_NEXTEP_NATURAL_END)
	close_nextep_handoff_cover()

def _handoff_meta_payload(meta=None):
	meta = meta or {}
	return {
		'tmdb_id': meta.get('tmdb_id', ''),
		'title': meta.get('title', ''),
		'season': meta.get('season', 0),
		'episode': meta.get('episode', 0),
		'poster': meta.get('poster', '') or '',
		'fanart': meta.get('fanart', '') or '',
		'clearlogo': meta.get('clearlogo', '') or '',
		'ep_name': meta.get('ep_name', '') or '',
	}

def _store_handoff_meta(meta=None):
	payload = _handoff_meta_payload(meta)
	try:
		kodi_utils.set_property(PROP_NEXTEP_HANDOFF_META, json.dumps(payload))
	except Exception:
		pass
	return payload

def _load_handoff_meta():
	try:
		raw = kodi_utils.get_property(PROP_NEXTEP_HANDOFF_META)
		if raw:
			return json.loads(raw)
	except Exception:
		pass
	return {}

def _handoff_meta_matches(meta):
	if not meta:
		return False
	stored = _load_handoff_meta()
	if not stored:
		return False
	return _nextep_stash_key(stored) == _nextep_stash_key(meta)

def arm_nextep_handoff_cover(meta=None):
	global _HANDOFF_COVER
	if nextep_handoff_cancelled():
		return False
	payload = _store_handoff_meta(meta) if meta else _load_handoff_meta()
	if _HANDOFF_COVER is not None:
		return True
	if not payload:
		return False
	try:
		win = create_window(('windows.nextep_handoff', 'NextepHandoffCover'), 'nextep_handoff.xml', meta=payload)
		if not win or not hasattr(win, 'run'):
			return False
		_HANDOFF_COVER = win
		kodi_utils.logger('NIGHTSHIFT', 'Autoscrape handoff cover armed: %s S%02dE%02d' % (
			payload.get('title'), int(payload.get('season') or 0), int(payload.get('episode') or 0)))
		return True
	except Exception as e:
		try:
			kodi_utils.logger('NIGHTSHIFT', 'Autoscrape handoff cover arm failed: %s' % e)
		except Exception:
			pass
		return False

def show_nextep_handoff_cover(meta=None):
	global _HANDOFF_COVER_THREAD, _HANDOFF_COVER_SHOWN
	if _HANDOFF_COVER_SHOWN:
		return True
	if nextep_handoff_cancelled():
		close_nextep_handoff_cover()
		return False
	if not arm_nextep_handoff_cover(meta):
		return False
	try:
		_HANDOFF_COVER.show()
		_HANDOFF_COVER_SHOWN = True
		for _ in range(20):
			if kodi_utils.get_property(PROP_NEXTEP_HANDOFF_VISIBLE) == 'true':
				break
			kodi_utils.sleep(10)
		kodi_utils.logger('NIGHTSHIFT', 'Autoscrape handoff cover shown')
		return True
	except Exception as e:
		_HANDOFF_COVER_SHOWN = False
		try:
			kodi_utils.logger('NIGHTSHIFT', 'Autoscrape handoff cover show failed: %s' % e)
		except Exception:
			pass
		return False

def close_nextep_handoff_cover():
	global _HANDOFF_COVER, _HANDOFF_COVER_THREAD, _HANDOFF_COVER_SHOWN
	kodi_utils.clear_property(PROP_NEXTEP_HANDOFF_VISIBLE)
	kodi_utils.clear_property(PROP_NEXTEP_HANDOFF_META)
	win, thread = _HANDOFF_COVER, _HANDOFF_COVER_THREAD
	_HANDOFF_COVER, _HANDOFF_COVER_THREAD, _HANDOFF_COVER_SHOWN = None, None, False
	if win is None and thread is None:
		try:
			kodi_utils.close_dialog('nextep_handoff.xml')
		except Exception:
			pass
		return
	try:
		win.close()
	except Exception:
		pass
	try:
		kodi_utils.close_dialog('nextep_handoff.xml')
	except Exception:
		pass
	if thread and thread.is_alive():
		try:
			thread.join(timeout=1.0)
		except Exception:
			pass

def dismiss_nextep_handoff_cover_keep_armed():
	# Cover must not sit over playing video. If it did and the user Backs,
	# drop the overlay only — Stop should still be a handoff.
	payload = _load_handoff_meta()
	close_nextep_handoff_cover()
	if payload:
		_store_handoff_meta(payload)
		arm_nextep_handoff_cover(payload)

def nextep_handoff_cancelled():
	return nextep_autoplay_cancelled() or kodi_utils.get_property('nightshift.nextep_prep_declined') == 'true'

def cancel_pending_nextep_on_user_play(meta=None):
	pending = (
		kodi_utils.get_property('nightshift.nextep_pending') == 'true'
		or bool(kodi_utils.get_property(PROP_AUTOSCRAPE_NEXTEP_READY))
		or bool(kodi_utils.get_property(PROP_NEXTEP_HANDOFF_META))
		or kodi_utils.get_property(PROP_NEXTEP_HANDOFF_VISIBLE) == 'true'
		or peek_nextep_autoplay_stash()
	)
	if pending:
		if _handoff_meta_matches(meta):
			return False
		mark_nextep_autoplay_cancelled()
		try:
			kodi_utils.logger('NIGHTSHIFT', 'Next episode prep cancelled (user started playback)')
		except:
			pass
		if kodi_utils.get_property(PROP_RESOLVE_BUSY) == 'true':
			kodi_utils.set_property(PROP_RESOLVE_CANCEL, 'true')
		return True
	if meta:
		return cancel_nextep_if_user_target_differs(meta)
	return False

def cancel_nextep_if_user_target_differs(meta):
	stash = peek_nextep_autoplay_stash()
	if not stash:
		return False
	stash_key = _nextep_stash_key(stash.get('meta') or {})
	user_key = _nextep_stash_key(meta)
	if not stash_key or not user_key or stash_key == user_key:
		return False
	mark_nextep_autoplay_cancelled()
	try:
		kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode: cancelled (user started different title)')
	except:
		pass
	return True

def nextep_end_play_superseded(stash_meta=None):
	if nextep_autoplay_cancelled():
		return True
	if kodi_utils.get_property(PROP_RESOLVE_BUSY) == 'true':
		return True
	if kodi_utils.get_property(PROP_SOURCES_BUSY) == 'true':
		return True
	return False

def nextep_alert_handled(key):
	return bool(key) and kodi_utils.get_property(PROP_NEXTEP_ALERT_KEY) == key

def claim_nextep_alert_handled(key):
	if not key:
		return False
	if nextep_alert_handled(key):
		return False
	kodi_utils.set_property(PROP_NEXTEP_ALERT_KEY, key)
	return True

def clear_nextep_autoplay_cancelled():
	kodi_utils.clear_property(PROP_NEXTEP_AUTOPLAY_CANCELLED)

def stash_nextep_autoplay_results(results, meta, nextep_settings, params):
	if nextep_autoplay_cancelled():
		return False
	key = _nextep_stash_key(meta)
	if not key: return False
	_NEXTEP_AUTOPLAY_STASH[key] = {'results': list(results), 'meta': dict(meta), 'nextep_settings': dict(nextep_settings or {}), 'params': dict(params or {})}
	kodi_utils.set_property(PROP_NEXTEP_SCRAPE_KEY, key)
	kodi_utils.set_property(PROP_NEXTEP_SCRAPE_READY, 'true')
	kodi_utils.clear_property(PROP_NEXTEP_ALERT_KEY)
	return True

def take_nextep_autoplay_stash(clear_only=False):
	key = kodi_utils.get_property(PROP_NEXTEP_SCRAPE_KEY)
	kodi_utils.clear_property(PROP_NEXTEP_SCRAPE_READY)
	kodi_utils.clear_property(PROP_NEXTEP_SCRAPE_KEY)
	if not key: return None
	if clear_only:
		_NEXTEP_AUTOPLAY_STASH.pop(key, None)
		return None
	return _NEXTEP_AUTOPLAY_STASH.pop(key, None)

def clear_nextep_autoplay_stash():
	_NEXTEP_AUTOPLAY_STASH.clear()
	kodi_utils.clear_property(PROP_NEXTEP_SCRAPE_READY)
	kodi_utils.clear_property(PROP_NEXTEP_SCRAPE_KEY)
	kodi_utils.clear_property(PROP_NEXTEP_ALERT_KEY)

def clear_orphan_nextep_play_stash():
	try:
		path = _nextep_play_stash_path()
		if os.path.isfile(path):
			os.remove(path)
	except:
		pass
	_set_nextep_stash_play_in_flight(False)

def _without(items, exclude):
	"""`items` minus `exclude` by object identity, O(n). Same result as `i not in exclude` when `exclude` was built from `items`,
	without comparing whole result dicts against every excluded row (which grows with the square of the result count)."""
	if not exclude: return list(items)
	skip = set(id(x) for x in exclude)
	return [i for i in items if id(i) not in skip]

_VOLUME_PACK_RE = re.compile(r'\bvol(?:ume)?s?[\s._-]*\d+\s*(?:[-~_.]|to)\s*\d+|\b\d{2,4}\s*[-~]\s*\d{2,4}\s+as\s+vol', re.I)

NZB_WAIT_SECONDS = 60

class Sources():
	def __init__(self):
		self.params = {}
		self.prescrape_scrapers, self.prescrape_threads, self.prescrape_sources, self.prescrape_ran_scrapers, self.uncached_results, self.orig_results = [], [], [], set(), [], []
		self.threads, self.providers, self.sources, self.internal_scraper_names, self.remove_scrapers = [], [], [], [], ['external']
		self.clear_properties, self.filters_ignored, self.active_folders, self.resolve_dialog_made, self.episode_group_used = True, False, False, False, False
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.prescrape, self.disabled_ext_ignored = False, False
		self.ext_name, self.ext_folder = '', ''
		self.external_modules = []
		self.progress_dialog, self.progress_thread = None, None
		self.playing_filename = ''
		self._resolve_user_cancelled, self.cancel_all_playback = False, False
		self._resolved_url_sent = False
		self._resolved_url_aborted = False
		# Autoscrape nextep handoff: reuse spent PlayMedia handle — use Player.play().
		self._use_player_play = False
		# Defaults so Download File (fresh Sources()) can resolve without playback_prep.
		self.background = False
		self.play_type = ''
		self.autoplay_nextep = False
		self.autoscrape_nextep = False
		self.autoscrape = False
		self.autoplay = False
		self.random = False
		self.random_continual = False
		self.season, self.episode = '', ''
		self.media_type = ''
		self._pending_pack_browse = None
		self._pack_picker_cancelled = False
		self.meta = {}
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self._quality_length_final))
		self.filter_keys = include_exclude_filters()
		self.filter_keys.pop('hybrid')
		self.default_internal_scrapers = ('easynews', 'aiostreams', 'nzb', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud', 'folders')
		self.native_torrent_scrapers = NATIVE_TORRENT_SCRAPERS
		self.debrids = {'Real-Debrid': ('apis.real_debrid_api', 'RealDebridAPI'), 'rd_cloud': ('apis.real_debrid_api', 'RealDebridAPI'),
		'rd_browse': ('apis.real_debrid_api', 'RealDebridAPI'), 'Premiumize.me': ('apis.premiumize_api', 'PremiumizeAPI'), 'pm_cloud': ('apis.premiumize_api', 'PremiumizeAPI'),
		'pm_browse': ('apis.premiumize_api', 'PremiumizeAPI'), 'AllDebrid': ('apis.alldebrid_api', 'AllDebridAPI'), 'ad_cloud': ('apis.alldebrid_api', 'AllDebridAPI'),
		'ad_browse': ('apis.alldebrid_api', 'AllDebridAPI'), 'Offcloud': ('apis.offcloud_api', 'OffcloudAPI'), 'oc_cloud': ('apis.offcloud_api', 'OffcloudAPI'),
		'oc_browse': ('apis.offcloud_api', 'OffcloudAPI'), 'TorBox': ('apis.torbox_api', 'TorBoxAPI'), 'tb_cloud': ('apis.torbox_api', 'TorBoxAPI'),
		'tb_browse': ('apis.torbox_api', 'TorBoxAPI')}
		self.retry_actions = settings.rescrape_settings()

	def _plugin_handle(self):
		try:
			return int(sys.argv[1])
		except Exception:
			return -1

	def _dismiss_playback_failed_dialog(self):
		# setResolvedUrl(False) after a user cancel still makes Kodi flash
		# DialogConfirm ("One or more items failed to play") on widget PlayMedia.
		# Call only after scrape/results UI is already closed (avoids progress flash).
		for _ in range(6):
			try:
				if kodi_utils.get_visibility('Window.IsVisible(okdialog)'):
					kodi_utils.close_dialog('okdialog')
					try:
						kodi_utils.execute_builtin('SendClick(okdialog, 11)')
					except Exception:
						pass
					return True
			except Exception:
				pass
			kodi_utils.sleep(20)
		return False

	def _abort_plugin_resolve(self, clear_playlist=True, dismiss_failed_dialog=True):
		# Kodi 22 widget / PlayMedia paths wait on setResolvedUrl. Exiting scrape/resolve
		# without True or False leaves plugin:// "not playable" → "One or more items failed
		# to play", and a second widget click hits the sources busy lock toast.
		# User cancel: clear the playlist item, setResolvedUrl(False), then dismiss
		# DialogConfirm. Caller should close scrape/results UI before this when possible.
		if getattr(self, 'background', False):
			return False
		# Autoscrape handoff: previous episode already answered this handle — do not
		# setResolvedUrl(False) again (noop / can confuse a later waiting PlayMedia).
		if getattr(self, '_use_player_play', False):
			return False
		if getattr(self, '_resolved_url_sent', False) or getattr(self, '_resolved_url_aborted', False):
			return False
		handle = self._plugin_handle()
		if handle <= 0:
			return False
		try:
			if clear_playlist and not self._playback_already_active():
				kodi_utils.clear_video_playlist()
			# Empty ListItem (not offscreen) — some Kodi builds still toast less with this.
			listitem = kodi_utils.xbmcgui.ListItem()
			xbmcplugin.setResolvedUrl(handle, False, listitem)
			self._resolved_url_aborted = True
			self._resolved_url_sent = True
			if dismiss_failed_dialog:
				self._dismiss_playback_failed_dialog()
			return True
		except Exception:
			return False

	def _playback_already_active(self):
		if kodi_utils.playback_is_paused():
			return False
		try:
			player = kodi_utils.kodi_player()
			if player.isPlayingVideo() or player.isPlaying():
				return True
		except:
			pass
		try:
			if kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
				return True
		except:
			pass
		return False

	def _close_sources_results_window(self):
		try:
			kodi_utils.close_dialog('sources_results.xml')
			kodi_utils.sleep(200)
		except:
			pass

	def _random_playback(self):
		return any((self.random, self.random_continual, self.play_type == 'random_continual'))

	def _explicit_autoplay_request(self):
		return 'autoplay' in self.params and self.params.get('autoplay', 'false') == 'true'

	def _effective_autoplay(self):
		if not self.autoplay:
			return False
		if self._explicit_autoplay_request() or self.cloud_prescrape_autoplay or self._random_playback():
			return True
		return settings.auto_play(self.media_type)

	def playback_prep(self, params=None):
		if params: self.params = params
		params_get = self.params.get
		if params_get('nextep_stash_play') != 'true':
			if not (params_get('background', 'false') == 'true' and params_get('play_type', '') in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual')):
				clear_orphan_nextep_play_stash()
		if params_get('nextep_stash_play') != 'true' and not (
			params_get('background', 'false') == 'true'
			and params_get('play_type', '') in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual')
		):
			kodi_utils.hide_busy_dialog()
		if params_get('nextep_stash_play') == 'true':
			if _nextep_stash_play_in_flight() and not os.path.isfile(_nextep_play_stash_path()):
				try:
					kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode play: skipped duplicate stash resolve (already in flight)')
				except:
					pass
				return
			stash = consume_persisted_nextep_play_stash()
			if not stash:
				_set_nextep_stash_play_in_flight(False)
				kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode play: no persisted stash')
				return
			self.params = dict(stash.get('params') or {})
			self.params['background'] = 'false'
			self.params['nextep_stash_play'] = 'true'
			self.params['play_type'] = 'autoplay_nextep'
			self._nextep_stash_results = list(stash.get('results') or [])
			self._nextep_stash_settings = dict(stash.get('nextep_settings') or {})
			self._nextep_alert_handled = True
			params_get = self.params.get
		self.background = params_get('background', 'false') == 'true'
		self.play_type = params_get('play_type', '')
		if 'prescrape' in self.params:
			self.prescrape = params_get('prescrape') == 'true'
		else:
			self.prescrape = False
		self.random, self.random_continual = params_get('random', 'false') == 'true', params_get('random_continual', 'false') == 'true'
		if 'external_cache_check' in self.params: self.cache_check_override = params_get('external_cache_check') == 'true'
		else: self.cache_check_override = None
		if self.play_type:
			if self.play_type == 'autoplay_nextep': self.autoplay_nextep, self.autoscrape_nextep = True, False
			elif self.play_type == 'random_continual': self.autoplay_nextep, self.autoscrape_nextep = False, False
			else: self.autoplay_nextep, self.autoscrape_nextep = False, True
		else: self.autoplay_nextep, self.autoscrape_nextep = settings.autoplay_next_episode(), settings.autoscrape_next_episode()
		self.autoscrape = self.autoscrape_nextep and self.background		
		self.ignore_scrape_filters = params_get('ignore_scrape_filters', 'false') == 'true'
		self.live_search = params_get('live_search', 'false') == 'true'
		self.nextep_settings, self.disable_autoplay_next_episode = params_get('nextep_settings', {}), params_get('disable_autoplay_next_episode', 'false') == 'true'
		if getattr(self, '_nextep_stash_settings', None):
			self.nextep_settings = self._nextep_stash_settings
		self.num_episodes = params_get('num_episodes', None)
		if not self.num_episodes and isinstance(self.nextep_settings, dict):
			self.num_episodes = self.nextep_settings.get('num_episodes')
		try: _play_n = int(self.num_episodes) if self.num_episodes not in (None, '') else 0
		except: _play_n = 0
		if _play_n > 1:
			self.autoplay_nextep, self.autoscrape_nextep = True, False
			self.autoscrape = False
			if not self.play_type: self.play_type = 'autoplay_nextep'
		elif self.num_episodes not in (None, '') and _play_n <= 1:
			self.autoplay_nextep, self.autoscrape_nextep = False, False
			self.autoscrape = False
		self.disabled_ext_ignored = params_get('disabled_ext_ignored', self.disabled_ext_ignored) == 'true'
		self.folders_ignore_filters = get_setting('nightshift.results.folders_ignore_filters', 'false') == 'true'
		self.filter_size_method = int(get_setting('nightshift.results.filter_size_method', '0'))
		self.media_type, self.tmdb_id = params_get('media_type'), params_get('tmdb_id')		
		self.custom_title, self.custom_year = params_get('custom_title', None), params_get('custom_year', None)
		self.episode_group_label, self.episode_id = params_get('episode_group_label', ''), params_get('episode_id', None)
		try: self.playcount = int(params_get('playcount', 0) or 0)
		except (TypeError, ValueError): self.playcount = 0
		self.watch_count = params_get('watch_count', 1)
		if self.media_type == 'episode':
			self.season, self.episode = int(params_get('season')), int(params_get('episode'))
			self.custom_season, self.custom_episode = params_get('custom_season', None), params_get('custom_episode', None)
			self.check_episode_group()
		else: self.season, self.episode, self.custom_season, self.custom_episode = '', '', '', ''
		if 'autoplay' in self.params: self.autoplay = params_get('autoplay', 'false') == 'true'
		else: self.autoplay = settings.auto_play(self.media_type)
		if self._random_playback(): self.autoplay = True
		self.cloud_prescrape_autoplay = False
		self._playback_failed_notified = False
		self.get_meta()
		# ABSOLUTE EPISODE CALCULATION ADDED HERE
		if self.media_type == 'episode':
			try:
				abs_ep = absolute_episode_from_season_data(self.meta.get('season_data'), self.season, self.episode)
				if abs_ep:
					self.meta['absolute_episode'] = abs_ep
					kodi_utils.logger('NIGHTSHIFT', 'Absolute episode calculated: S%02dE%02d -> abs=%d' % (self.season, self.episode, abs_ep))
			except Exception as e:
				kodi_utils.logger('NIGHTSHIFT', 'Absolute episode calc failed: %s' % e)
		if not self.background and params_get('nextep_stash_play') != 'true':
			cancel_pending_nextep_on_user_play(self.meta)
		self.determine_scrapers_status()
		if not self.prescrape and not self._playback_skips_prescrape_override() and settings.prescrape_enabled(self.media_type, self.active_internal_scrapers):
			self.prescrape = True
		self.sleep_time, self.provider_sort_ranks, self.scraper_settings = 100, settings.provider_sort_ranks(), settings.scraping_settings()
		self.include_prerelease_results = settings.include_prerelease_results()
		self.limit_resolve = settings.limit_resolve()
		self.weight_size = settings.size_sort_weighted()
		self.sort_function, self.quality_filter = settings.results_sort_order(), self._quality_filter()
		self._quality_rank_order = settings.quality_sort_order()
		self._refresh_group_boost_sort()
		self.include_unknown_size = get_setting('nightshift.results.size_unknown', 'false') == 'true'
		self.make_search_info()
		if self.background and self.play_type in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual'):
			self._log_nextep_scrape_started()
			self._prefetch_nextep_segment_data()
		if self.background and self.play_type == 'random_continual' and not self.nextep_settings:
			self.nextep_settings = {'watching_check': settings.auto_nextep_settings('autoplay_nextep')['watching_check']}
		continual_skip = self.play_type == 'random_continual' and params_get('continual_skip', 'false') == 'true'
		play_n_episodes = bool(self.num_episodes) or bool(isinstance(self.nextep_settings, dict) and self.nextep_settings.get('play_n_episodes'))
		if self.background and (self.autoplay_nextep or self.play_type == 'random_continual') and self.nextep_settings \
				and not getattr(self, '_nextep_alert_handled', False) and not continual_skip and not play_n_episodes:
			if not self.still_watching_check():
				self._decline_nextep_prep('still watching')
				kodi_utils.notification('Cancel Autoplay', icon=self.meta.get('poster'))
				return
		if getattr(self, '_nextep_stash_results', None):
			try:
				kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode play: starting resolve for %s S%02dE%02d' % (
					self.meta.get('title', ''), self.season, self.episode))
			except:
				pass
			return self.play_file(self._nextep_stash_results)
		if params_get('browse_only') == 'true': return      # a file picked in My Services: everything is set up, nothing is searched for
		if self.autoscrape: self.autoscrape_nextep_handler()
		else: return self.get_sources()

	def check_episode_group(self):
		try:
			if any([self.custom_season, self.custom_episode]) or 'skip_episode_group_check' in self.params: return
			group_info = episode_groups_cache.get(self.tmdb_id)
			# Opt-in: anime with no assigned group — prefer TMDb "Seasons", else Original Air Date.
			# Does not write to episode_groups_cache — only an explicit Assign Episode Group persists.
			if not group_info and settings.anime_seasons_episode_group_fallback() and metadata.is_anime_check(tmdb_id=self.tmdb_id):
				groups = metadata.episode_groups(self.tmdb_id)
				if groups:
					group_info = metadata.preferred_episode_group(groups, prefer_name='seasons')
			if not group_info: return
			group_details = metadata.group_episode_data(metadata.group_details(group_info['id']), self.episode_id, self.season, self.episode)
			if group_details:
				self.custom_season, self.custom_episode, self.episode_group_used = group_details['season'], group_details['episode'], True
				self.episode_group_label = '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.custom_season, self.custom_episode)
		except: self.custom_season, self.custom_episode = None, None

	def determine_scrapers_status(self):
		self.active_internal_scrapers = settings.active_internal_scrapers()
		if not 'external' in self.active_internal_scrapers and self.disabled_ext_ignored: self.active_internal_scrapers.append('external')
		self.active_external = 'external' in self.active_internal_scrapers
		self.debrid_enabled = debrid.debrid_enabled()
		if self.active_external:
			if not self.debrid_enabled:
				return self.disable_external()
			self.external_modules = settings.active_external_modules()
			if not self.external_modules: return self.disable_external()
			self.ext_folder = self.external_modules[0]['module_id']
			self.ext_name = self.external_modules[0]['folder_name']

	def _any_cache_check_active(self):
		if self.cache_check_override is not None:
			return self.cache_check_override
		return settings.any_external_cache_check()

	def _playback_skips_prescrape_override(self):
		if self.disabled_ext_ignored or self.ignore_scrape_filters: return True
		if 'disabled_ext_ignored' in self.params or 'ignore_scrape_filters' in self.params: return True
		return False

	def _background_nextep_scrape(self):
		return self.background and self.play_type in ('autoplay_nextep', 'autoscrape_nextep')

	def _allow_concurrent_scrape(self):
		if self.autoscrape and self.background:
			return True
		if self.background and self.play_type == 'random_continual':
			return True
		return self._background_nextep_scrape()

	def get_sources(self):
		depth = getattr(self, '_get_sources_depth', 0)
		if depth == 0:
			try:
				from apis.nzb_api import purge_if_due
				purge_if_due()
			except Exception: pass
			allow_concurrent = self._allow_concurrent_scrape()
			self._clear_stale_resolve_busy()
			self._clear_stale_sources_busy()
			# Stale cancel from a prior resolve/nextep must not poison Download File / a new scrape.
			kodi_utils.clear_property(PROP_RESOLVE_CANCEL)
			if kodi_utils.get_property(PROP_RESOLVE_BUSY) == 'true' and not allow_concurrent:
				if not self.background:
					kodi_utils.notification('Resolve or playback in progress.', 2500)
					self._abort_plugin_resolve()
				return
			if kodi_utils.get_property(PROP_SOURCES_BUSY) == 'true' and not allow_concurrent:
				# Cancel cleanup used to hold the lock for 1–4s (progress-thread join). A quick
				# second widget click then toasted "already running". Wait briefly for release.
				self._wait_sources_busy_clear(SOURCES_BUSY_WAIT_SECONDS)
				if kodi_utils.get_property(PROP_SOURCES_BUSY) == 'true':
					if not self.background:
						kodi_utils.notification('Source search already running.', 2500)
						self._abort_plugin_resolve()
					return
			self._scrape_user_cancelled = False
			self._sources_busy_owner = str(id(self))
			kodi_utils.clear_property(PROP_SOURCES_CANCELING)
			kodi_utils.set_property(PROP_SOURCES_BUSY, 'true')
			kodi_utils.set_property(PROP_SOURCES_OWNER, self._sources_busy_owner)
			self._touch_sources_busy()
		self._get_sources_depth = depth + 1
		try:
			if depth == 0:
				self._log_prescrape_settings()
			# Per-show Autoplay link: with Autoplay (Episodes) on, later episodes come from the pack / cloud folder the
			# user first chose - checked BEFORE any scrape and ahead of every other autoplay rule.
			if depth == 0 and not getattr(self, '_origin_scrape_tried', False):
				self._origin_scrape_tried = True
				state, origin_results = self._autoplay_origin_state()
				if state == 'origin':
					self.orig_results = list(origin_results)
					if self.autoscrape: return origin_results
					if not self.background:
						self.autoplay, self.cloud_prescrape_autoplay = True, True
						self._last_cloud_autoplay_results = list(origin_results)
						self._prepare_cloud_autoplay_resolve()
						return self.play_file(origin_results)
					return self.play_source(origin_results)
				if state == 'missing':
					# Background next-episode prep: the saved pack / cloud folder has no such episode. Do not fall back to
					# another source; the user picks one when they get to that episode.
					kodi_utils.logger('PlayOrigin', 'saved pack / cloud folder has no such episode - background autoplay stands down')
					self._decline_nextep_prep('the saved pack / folder has no such episode')
					return None
				if state == 'manual':
					# Nothing saved yet (fresh Kodi / new show) or the saved link has no such episode: let the user pick.
					# Their pick becomes the show's link (see _remember_play_origin).
					self.autoplay = False
					kodi_utils.logger('PlayOrigin', 'Autoplay is on but no usable saved link for tmdb=%s - waiting for a manual pick' % self.tmdb_id)
				elif state == 'none':
					# A single-file first pick (NZB / Easynews / AIOStreams / an indexer ...): look ONLY in that source first - no requests to the others.
					self._origin_only_applied = self._restrict_to_origin_scraper()
				# Autoplay / next-episode prep: read the show's stored search results (currently-watching cache) before going out to the services.
				self._db_first_applied = self._try_db_first()
				if self._nextep_cache_only():
					shown = self._results_cache_get()
					if shown:
						self.orig_results = list(shown)
						return shown if self.autoscrape else self.play_source(shown)
					# Background next-episode prep reads the saved results / the stored searches ONLY: no request goes out. When they hold
					# no autoplay match the prep stands down; the user picks (or searches live) when they reach the episode.
					if not self._db_first_applied:
						kodi_utils.logger('NextEpCache', 'nothing stored for tmdb=%s S%s E%s - no live search in the background' % (self.tmdb_id, self.season, self.episode))
						self._decline_nextep_prep('nothing stored for this show yet')
						return None
					self._limit_to_stored_scrapers()
			if depth == 0:
				shown = self._results_cache_get()
				if shown:
					self.orig_results = list(shown)
					return shown if self.autoscrape else self.play_source(shown)
			if not self.progress_dialog and not self.background: self._make_progress_dialog()
			results = []
			self.check_prescrape_ran = False
			if self.prescrape and any(x in self.active_internal_scrapers for x in self.default_internal_scrapers):
				if self.prepare_internal_scrapers():
					results = self.collect_prescrape_results()
					self.check_prescrape_ran = bool(self.prescrape_scrapers)
					if results:
						results = self.process_results(results)
						if not self._can_continue_full_scrape(): self.prescrape = False
			if self._user_cancelled_scrape():
				return self._finish_scrape_cancel()
			if not results:
				if self.check_prescrape_ran and self._can_continue_full_scrape():
					self._kill_progress_dialog(join_timeout=1.0)
					self._reset_scrape_progress_counts()
					if not self.progress_dialog and not self.background:
						self._make_progress_dialog()
					self._refresh_results_settings()
				if not settings.auto_play(self.media_type) and not self.cloud_prescrape_autoplay and not self._random_playback() and not self._explicit_autoplay_request():
					self.autoplay = False
				self.prescrape = False
				self._release_empty_prescrape_cloud_scrapers()
				self.prepare_internal_scrapers()
				if self.active_external: self.activate_external_providers()
				elif not self.active_internal_scrapers: self._kill_progress_dialog()
				self.orig_results = self.collect_results()
				if self._user_cancelled_scrape():
					return self._finish_scrape_cancel()
				if not self.orig_results: self._kill_progress_dialog()
				self.orig_results = self._stamp_native_torrent_cache(self.orig_results)
				results = self.process_results(self.orig_results)
				if results and not self._user_cancelled_scrape(): self._results_cache_set(results)
			if self._user_cancelled_scrape():
				return self._finish_scrape_cancel()
			if not results:
				if getattr(self, '_db_first_applied', False):
					if self._nextep_cache_only():
						kodi_utils.logger('NextEpCache', 'no stored result matches Autoplay for S%s E%s - not searching live in the background' % (self.season, self.episode))
						self._decline_nextep_prep('no stored result matches Autoplay')
						return None
					asked = self._ask_stored_or_live()
					if asked is not None: return asked[0]
					return self._db_first_fallback()
				if getattr(self, '_origin_only_applied', False) and not self.background and not self.autoscrape: return self._widen_origin_search()
				return self._process_post_results()
			if self.autoscrape: return results
			else: return self.play_source(results)
		finally:
			self._get_sources_depth = max(0, getattr(self, '_get_sources_depth', 1) - 1)
			if self._get_sources_depth == 0:
				self._release_sources_busy()

	# ===================== PLAY ORIGIN (next episode from the same pack / cloud folder) =====================
	def _origin_folder_key(self, item):
		'''Identity of the folder a cloud/direct file lives in ('' when the scraper gives no folder info).'''
		try:
			folder_id = item.get('folder_id')
			if folder_id not in (None, ''): return 'id:%s' % folder_id
			if item.get('folder_path'): return 'dir:%s' % item.get('folder_path')
			for key in ('path', 'url_dl', 'id'):
				value = item.get(key)
				if isinstance(value, str) and ('/' in value or '\\' in value) and not value.lower().startswith(('http://', 'https://')):
					folder = os.path.dirname(value.replace('\\', '/'))
					if folder: return 'dir:%s' % folder
		except Exception:
			pass
		return ''

	def _autoplay_link_wanted(self):
		'''The per-show link is recorded and used when Autoplay (Episodes) is on, or Autoscrape Next Episode is.'''
		return self.media_type == 'episode' and bool(settings.auto_play('episode') or settings.autoscrape_next_episode())

	def _remember_play_origin(self, item):
		'''Called right before playback. The FIRST source played for a show becomes its Autoplay link
		(pack / cloud folder / direct folder; 'standard' for an ordinary single-file source). It is kept until the
		user runs Options -> Clear Autoplay (or Maintenance -> Clear Autoplay Cache).'''
		try:
			if not isinstance(item, dict) or not self._autoplay_link_wanted(): return
			from caches.autoplay_cache import autoplay_cache
			tmdb_id = str(self.tmdb_id)
			# A saved link that could not be used for this episode (season change, other folder name) was
			# not found, the user picked again: that pick replaces the saved link.
			if autoplay_cache.get_origin(tmdb_id) and not getattr(self, '_origin_replace', False): return
			if 'package' in item: kind = 'pack'
			elif item.get('scrape_provider') in PLAY_ORIGIN_CLOUD_SCRAPERS: kind = 'cloud'
			else: kind = 'standard'
			origin = {'kind': kind, 'scrape_provider': item.get('scrape_provider'), 'source': item.get('source'), 'name': item.get('name'),
					'folder_key': self._origin_folder_key(item) if kind == 'cloud' else ''}
			if kind == 'pack': origin['item'] = item
			origin['profile'] = self._origin_profile(item)
			saved = autoplay_cache.set_origin(tmdb_id, origin, title=(self.meta or {}).get('title') or '')
			kodi_utils.logger('PlayOrigin', 'SAVED autoplay link tmdb=%s kind=%s provider=%s folder_key=%r name=%r ok=%s' % (
				tmdb_id, kind, origin['scrape_provider'], origin['folder_key'], origin['name'], saved))
		except Exception as e:
			kodi_utils.logger('PlayOrigin', 'SAVE failed: %s: %s' % (type(e).__name__, e))

	@staticmethod
	def _origin_profile(item):
		'''What the first pick looked like: provider, quality, size and the release-name words, so a later single-file
		pick can be the closest match to it.'''
		try:
			from modules.source_utils import _filename_tokens
			profile = {'provider': item.get('debrid') or item.get('cache_provider') or item.get('scrape_provider') or '',
					'quality': item.get('quality') or '', 'size': float(item.get('size') or 0),
					'tokens': sorted(set(_filename_tokens(item.get('name') or item.get('display_name') or '')))[:60]}
			# The source itself (scraper / site / indexer) comes before the release group and tags: later episodes come from it.
			if item.get('scrape_provider'): profile['scrape_provider'] = item['scrape_provider']
			if item.get('scrape_provider') == 'nzb':
				# An NZB pick: later episodes should be NZB too, from the same indexer, the same release group, the same way (direct Usenet or TorBox).
				from modules.release_groups import group_from_name
				profile.update({'scrape_provider': 'nzb', 'group': group_from_name(item.get('name') or item.get('display_name') or '').lower(),
								'nzb_direct': bool(item.get('nzb_direct')), 'indexer': item.get('nzb_indexer') or ''})
			return profile
		except Exception:
			return {}

	@staticmethod
	def _profile_is_nzb(profile):
		return bool(profile) and (profile.get('scrape_provider') == 'nzb' or profile.get('provider') == 'nzb')

	@staticmethod
	def _nzb_indexer_copy(item, indexer):
		"""The copy of this NZB result that comes from `indexer`: the item itself, a re-pointed copy using its alternate from that
		indexer, or None."""
		if not indexer: return item
		if item.get('nzb_indexer') == indexer: return item
		for alt in item.get('nzb_alternates') or ():
			if alt.get('indexer') == indexer and alt.get('link'):
				from apis.nzb_api import nzb_link_hash
				copy = dict(item)
				copy['extraInfo'] = (item.get('extraInfo') or '').replace('Site: %s' % item.get('nzb_indexer'), 'Site: %s' % indexer)
				copy.update({'nzb_link': alt['link'], 'url_dl': alt['link'], 'nzb_hash': nzb_link_hash(alt['link']),
							'id': nzb_link_hash(alt['link']), 'nzb_indexer': indexer})
				return copy
		return None

	def _origin_matches(self, item, profile):
		"""Is this result from the same source as the show's first pick? NZB: an NZB from the same indexer. Anything else: the same
		scraper / site and the same debrid / provider (each only when it was recorded)."""
		if self._profile_is_nzb(profile):
			if item.get('scrape_provider') != 'nzb': return False
			return self._nzb_indexer_copy(item, profile.get('indexer') or '') is not None
		want_scraper = profile.get('scrape_provider') or ''
		if want_scraper and item.get('scrape_provider') != want_scraper: return False
		want = profile.get('provider') or ''
		if want and (item.get('debrid') or item.get('cache_provider') or item.get('scrape_provider') or '') != want: return False
		return bool(want_scraper or want)

	def _profile_score(self, item, profile):
		score = 0.0
		# Same source first, ahead of group / tags / quality: scraper, then (NZB) the exact indexer.
		if profile.get('scrape_provider') and item.get('scrape_provider') == profile['scrape_provider']: score += 12
		if profile.get('indexer') and self._nzb_indexer_copy(item, profile['indexer']) is not None: score += 16
		prov = (item.get('debrid') or item.get('cache_provider') or item.get('scrape_provider') or '')
		if profile.get('provider') and prov == profile['provider']: score += 4
		if self._profile_is_nzb(profile):
			# Same service (an NZB), then the same release group, then delivery: these outrank quality, size and name words.
			if item.get('scrape_provider') == 'nzb':
				score += 20
				try:
					from modules.release_groups import group_from_name
					group = group_from_name(item.get('name') or item.get('display_name') or '').lower()
					if group and group == (profile.get('group') or ''): score += 8
				except Exception:
					pass
				if 'nzb_direct' in profile and bool(item.get('nzb_direct')) == bool(profile.get('nzb_direct')): score += 1
		if profile.get('quality') and item.get('quality') == profile['quality']: score += 3
		try:
			a, b = float(profile.get('size') or 0), float(item.get('size') or 0)
			if a and b: score += 2.0 * (1.0 - min(abs(a - b) / max(a, b), 1.0))
		except Exception:
			pass
		try:
			from modules.source_utils import _filename_tokens
			mine = set(profile.get('tokens') or ())
			theirs = set(_filename_tokens(item.get('name') or item.get('display_name') or ''))
			if mine and theirs: score += 3.0 * len(mine & theirs) / len(mine | theirs)
		except Exception:
			pass
		return score

	def _apply_origin_profile(self, results):
		'''Autoplay with a remembered single-file pick: the results closest to it (same provider, quality, size and
		release-name words) come first. Other rules and filters stay as they are.'''
		try:
			if not results or not self._autoplay_link_wanted(): return results
			if not (self.autoplay or self.autoplay_nextep or self.autoscrape_nextep): return results
			from caches.autoplay_cache import autoplay_cache
			origin = autoplay_cache.get_origin(self.tmdb_id)
			profile = (origin or {}).get('profile')
			if not origin or origin.get('kind') != 'standard' or not profile: return results
			ranked = sorted(results, key=lambda i: -self._profile_score(i, profile))
			diag_log('PlayOrigin', 'single-file autoplay: best match to the first pick is %r' % (ranked[0].get('name') if ranked else None))
			return ranked
		except Exception:
			return results

	def _origin_nzb_candidates(self, results):
		'''Autoplay after a first pick that was an NZB: the NZB results that can play (cached on TorBox, or direct Usenet),
		best match first (same release group, same delivery) - they go ahead of the torrent / debrid candidates, which stay
		behind them as the fallback. [] when the first pick was not an NZB (everything else behaves as before).'''
		try:
			if not results or not self._autoplay_link_wanted(): return []
			if not (self.autoplay or self.autoplay_nextep or self.autoscrape_nextep): return []
			from caches.autoplay_cache import autoplay_cache
			origin = autoplay_cache.get_origin(self.tmdb_id)
			profile = (origin or {}).get('profile')
			if not origin or origin.get('kind') != 'standard' or not self._profile_is_nzb(profile): return []
			nzb = []
			for i in results:
				if i.get('scrape_provider') != 'nzb' or not (i.get('nzb_cached') or i.get('nzb_direct')): continue
				i = self._nzb_indexer_copy(i, profile.get('indexer') or '')       # the first pick's indexer only (a copy of the release from it)
				if i is not None: nzb.append(i)
			nzb.sort(key=lambda i: -self._profile_score(i, profile))
			diag_log('PlayOrigin', 'NZB autoplay: %d playable NZB result(s) for S%02dE%02d; best match to the first pick (group %r): %r' % (
				len(nzb), self.season, self.episode, profile.get('group') or '', nzb[0].get('name') if nzb else None))
			return nzb
		except Exception as e:
			kodi_utils.logger('PlayOrigin', 'NZB candidates failed: %s: %s' % (type(e).__name__, e))
			return []

	def _origin_front(self, queue, results):
		"""Non-NZB first pick: this show's results from the same scraper / site and debrid go to the front of the autoplay queue."""
		try:
			if not (self.autoplay or self.autoplay_nextep or self.autoscrape_nextep) or not self._autoplay_link_wanted(): return queue
			from caches.autoplay_cache import autoplay_cache
			origin = autoplay_cache.get_origin(self.tmdb_id)
			profile = (origin or {}).get('profile')
			if not origin or origin.get('kind') != 'standard' or not profile or self._profile_is_nzb(profile): return queue
			front = [i for i in queue if self._origin_matches(i, profile)]
			if front: front.sort(key=lambda i: -self._profile_score(i, profile))
			return front + [i for i in queue if i not in front] if front else queue
		except Exception:
			return queue

	def _origin_source_missing(self, results):
		'''True when autoplay has a remembered first pick (the NZB / debrid / provider the show was first played from) and nothing in these
		results comes from that same source (NZB not out yet, provider returned nothing, ...). Autoplay must NOT then play some other
		source: the user is sent to the results to choose a new match instead. Packs and cloud folders do the same in
		_autoplay_origin_state when the saved pack has no such episode.'''
		try:
			if not (self.autoplay or self.autoplay_nextep or self.autoscrape_nextep): return False
			if not self._autoplay_link_wanted(): return False
			from caches.autoplay_cache import autoplay_cache
			origin = autoplay_cache.get_origin(self.tmdb_id)
			profile = (origin or {}).get('profile')
			if not origin or origin.get('kind') != 'standard' or not profile: return False
			if self._profile_is_nzb(profile): return not self._origin_nzb_candidates(results)
			if not (profile.get('scrape_provider') or profile.get('provider')): return False
			return not any(self._origin_matches(i, profile) for i in (results or ()))
		except Exception:
			return False

	def _restrict_to_origin_scraper(self):
		'''Autoplay / next-episode prep after a single-file first pick: search just the source that pick came from. When it has nothing
		for this episode, _widen_origin_search() searches everything and shows the results (no autoplay).'''
		try:
			if self.media_type != 'episode' or self.prescrape or not self._autoplay_link_wanted(): return False
			if 'autoplay' in self.params or self._random_playback() or getattr(self, 'ignore_scrape_filters', False): return False
			if not (self.autoplay or self._background_nextep_scrape()): return False
			from caches.autoplay_cache import autoplay_cache
			origin = autoplay_cache.get_origin(self.tmdb_id)
			profile = (origin or {}).get('profile')
			if not origin or origin.get('kind') != 'standard' or not profile: return False
			prov = profile.get('scrape_provider') or ''
			if not prov or prov == 'external' or prov not in self.active_internal_scrapers: return False
			self.active_internal_scrapers = [prov]
			self.active_external, self.external_providers = False, []
			kodi_utils.logger('PlayOrigin', 'searching only the first-pick source %r for S%s E%s' % (prov, self.season, self.episode))
			return True
		except Exception:
			return False

	# ===================== RESULTS SCREEN CACHE =====================
	# The finished list (after scraping, filtering, sorting and the NZB check) of a title / episode is kept for a while, so
	# opening the same search again shows it at once - no scraping, no filtering, no check. Live Search always scrapes again
	# (and refreshes what is kept). Any change of a setting that can change the list makes a different key.
	_SKIP_SETTING = re.compile(r'token|user|pass|secret|key|client|sync|last|refresh|expir|time|date|watched|trakt|simkl|mdblist|punchplay|version|screen_cache', re.I)

	def _results_cache_key(self):
		try:
			import hashlib
			from caches.settings_cache import settings_cache
			current = settings_cache.get_all()
			signature = '|'.join('%s=%s' % (k, current[k]) for k in sorted(current) if not self._SKIP_SETTING.search(k))
			parts = [kodi_utils.addon_version(), self.media_type, str(self.tmdb_id), str(self.season), str(self.episode), str(getattr(self, 'custom_season', '')), str(getattr(self, 'custom_episode', '')),
					str(getattr(self, 'custom_year', '')), str(getattr(self, 'custom_title', '')), str(getattr(self, 'ignore_scrape_filters', False)), str(self.disabled_ext_ignored), str(bool(self.autoplay)),
					','.join(sorted(self.active_internal_scrapers)), ','.join(self.quality_filter or []), hashlib.sha1(signature.encode('utf-8')).hexdigest()]
			return 'RESULTS_' + hashlib.sha1('|'.join(parts).encode('utf-8')).hexdigest()
		except Exception:
			return ''

	def _results_cache_usable(self, write=False):
		# read: also by the background next-episode prep (it uses the saved list only); write: a user's own search only
		if not settings.results_screen_cache_minutes() or self.autoscrape and not self._nextep_cache_only() or not self.tmdb_id or self.random: return False
		if self.background: return (not write) and self._nextep_cache_only()
		return True

	@staticmethod
	def _cache_safe(value):
		"""The database keeps a value as text and reads it back with eval: anything that would not survive that (nan, inf, objects) is turned into plain data."""
		if isinstance(value, float): return value if value == value and value not in (float('inf'), float('-inf')) else 0
		if isinstance(value, (str, int, bool)) or value is None: return value
		if isinstance(value, dict): return {Sources._cache_safe(k): Sources._cache_safe(v) for k, v in value.items()}
		if isinstance(value, (list, tuple, set)): return [Sources._cache_safe(v) for v in value]
		return str(value)

	def _results_cache_get(self):
		try:
			if not self._results_cache_usable() or self.live_search or getattr(self, '_origin_only_applied', False): return None
			key = self._results_cache_key()
			if not key: return None
			from caches.main_cache import main_cache
			cached = main_cache.get(key)
			if isinstance(cached, dict): cached, uncached = cached.get('results'), cached.get('uncached') or []
			else: uncached = []
			if not isinstance(cached, list) or not cached: return None
			if 'nzb' in (self.active_internal_scrapers or []) and sum(1 for i in cached if i.get('scrape_provider') == 'nzb') == 1 and len(cached) > 1:
				if nzb_debug_enabled(): kodi_utils.logger('ResultsCache', 'saved list has only 1 NZB result while NZB is on - ignored, searching again')
				return None
			from apis import usenet_stream
			self._nzb_episode_hint()
			shown = [i for i in cached if not (i.get('scrape_provider') == 'nzb' and i.get('nzb_direct') and usenet_stream.verdict_dead(i.get('nzb_link') or ''))]
			if not shown: return None
			self.uncached_results = list(uncached)
			kodi_utils.logger('ResultsCache', 'shown from the saved results list (%d result(s), %d uncached, %d dropped as dead) - no scraping' % (len(shown), len(uncached), len(cached) - len(shown)))
			return shown
		except Exception:
			return None

	def _results_cache_set(self, results):
		try:
			if not self._results_cache_usable(write=True) or getattr(self, '_origin_only_applied', False): return
			key = self._results_cache_key()
			if not key: return
			from caches.main_cache import main_cache
			results = list(results)
			if self.live_search or getattr(self, '_live_choice', False):
				# a live search is ADDED to what is saved (the saved results that are still alive stay), then sorted again
				try:
					from apis import usenet_stream
					old = main_cache.get(key)
					if isinstance(old, dict): old = old.get('results')
					if isinstance(old, list) and old:
						def ident(i): return (i.get('scrape_provider'), i.get('id') or i.get('hash') or i.get('name'))
						seen = {ident(i) for i in results}
						kept = [i for i in old if ident(i) not in seen and not (i.get('scrape_provider') == 'nzb' and i.get('nzb_direct') and usenet_stream.verdict_dead(i.get('nzb_link') or ''))]
						results = self.sort_results(results + kept)
						kodi_utils.logger('ResultsCache', 'live search added to the saved list: %d new, %d kept' % (len(seen), len(kept)))
				except Exception as e:
					kodi_utils.logger('ResultsCache', 'could not merge with the saved list (%s) - it is replaced' % e)
			payload = {'results': self._cache_safe(results), 'uncached': self._cache_safe(list(self.uncached_results or []))}
			main_cache.set(key, payload, expiration=settings.results_screen_cache_minutes() / 60.0)
			kodi_utils.logger('ResultsCache', 'saved %d result(s) + %d uncached for %d minutes' % (len(results), len(self.uncached_results or []), settings.results_screen_cache_minutes()))
		except Exception as e:
			kodi_utils.logger('ResultsCache', 'not saved: %s' % e)

	def _try_db_first(self):
		'''Database-first pass for every search (autoplay, manual, Select Source, next-episode prep): the scrapers that already searched this
		show / title answer from the currently-watching cache - no requests to the services; the other scrapers run as usual. Matching,
		filtering and the autoplay choice then work on that. _db_first_fallback() does the regular full scrape when nothing at all is found.'''
		try:
			from caches import watching_cache
			# (a scraper set to Prescrape is no reason to skip: prescrape and full scrape use the same search info, so they answer from the database too)
			if not self.tmdb_id or getattr(self, 'live_search', False):
				watching_cache.trace(True, 'S%s E%s: live scrape of every source (%s)' % (self.season, self.episode, 'Live Search chosen' if getattr(self, 'live_search', False) else 'no TMDb id'))
				return False
			have = watching_cache.scrapers_for_show(self.tmdb_id)
			usable = [s for s in self.active_internal_scrapers if s in have]
			if not usable:
				watching_cache.trace(True, 'S%s E%s: live scrape of every source - nothing stored yet for tmdb=%s (stored for: %s | active: %s)' % (self.season, self.episode, self.tmdb_id, ', '.join(sorted(have)) or 'none', ', '.join(self.active_internal_scrapers) or 'none'))
				return False
			self.search_info['db_scrapers'] = usable
			watching_cache.trace(False, 'S%s E%s: searching the database for %s (sources not stored yet run live)' % (self.season, self.episode, ', '.join(usable)))
			return True
		except Exception:
			return False

	def _nextep_cache_only(self):
		return bool(self.background and self.play_type in ('autoplay_nextep', 'autoscrape_nextep'))

	def _limit_to_stored_scrapers(self):
		"""Cache-only: the scrapers with nothing stored for this show do not run (they would have to go out to the service)."""
		usable = list(self.search_info.get('db_scrapers') or [])
		self.search_info['cache_only'] = True
		self.active_internal_scrapers = [i for i in self.active_internal_scrapers if i in usable]
		if 'external' not in self.active_internal_scrapers:
			self.active_external, self.external_providers = False, []

	def _ask_stored_or_live(self):
		"""Autoplay found no stored match (foreground): the user chooses - pick from the stored results (no autoplay), or search live.
		Nothing there to pick from -> live. Returns None to carry on with the live search, else a 1-tuple holding the value to return."""
		try:
			if self.background or self.autoscrape or not self.autoplay or getattr(self, '_stored_pick_tried', False): return None
			self._stored_pick_tried = True
			self._kill_progress_dialog(join_timeout=1.0)
			choice = kodi_utils.confirm_dialog(heading='No stored match', ok_label='Pick from stored', cancel_label='Search live', third_label='Cancel',
				text='Nothing stored for this search matches Autoplay.[CR][CR]Pick from the stored results, or search live now (the new results are added to what is stored).')
			if choice == 10:
				self._reset_scrape_state(keep_disabled_ext_ignored=True)
				self.autoplay = False
				self._refresh_results_settings()
				self._db_first_applied = self._try_db_first()
				return (self.get_sources(),)
			if choice == 11:
				self._live_choice = True
				self.live_search = True                      # stored answers are refreshed from the services and ADDED to what is stored
				self.search_info['live_search'] = True
				return None
			self._finish_scrape_cancel()
			return (None,)
		except Exception as e:
			kodi_utils.logger('StoredOrLive', 'dialog failed (%s) - searching live' % e)
			return None

	def _db_first_fallback(self):
		'''Nothing usable in the database: the regular full scrape (first-pick source first when autoplay has one).'''
		if not getattr(self, '_db_first_applied', False): return None
		self._db_first_applied = False
		self.search_info['db_scrapers'] = []
		from caches import watching_cache
		watching_cache.trace(True, 'S%s E%s: the database has no match for this episode - regular live scrape of every source' % (self.season, self.episode))
		self._kill_progress_dialog(join_timeout=1.0)
		self._reset_scrape_state(keep_disabled_ext_ignored=True)
		self._origin_only_applied = self._restrict_to_origin_scraper()
		return self.get_sources()

	def _widen_origin_search(self):
		'''The first-pick source had no match: search every source, but do not autoplay - show the results so a new match is chosen.'''
		if not getattr(self, '_origin_only_applied', False) or self.background: return None
		self._origin_only_applied = False
		kodi_utils.logger('PlayOrigin', 'the first-pick source has no match for S%s E%s - searching all sources, no autoplay' % (self.season, self.episode))
		self._kill_progress_dialog(join_timeout=1.0)
		self._reset_scrape_state(keep_disabled_ext_ignored=True)
		self.autoplay = False
		self._origin_replace = True
		kodi_utils.notification('Your previous source has no match - pick a new one', 4500)
		return self.get_sources()

	def _origin_missing_handoff(self, results):
		if getattr(self, '_db_first_applied', False): return self._db_first_fallback()
		if getattr(self, '_origin_only_applied', False) and not self.background: return self._widen_origin_search()
		kodi_utils.logger('PlayOrigin', 'the show\'s first-pick source has nothing for S%s E%s - not playing another source; user picks from results' % (self.season, self.episode))
		if self.background:
			self._decline_nextep_prep('the source used for the previous episode is not available')
			return None
		self.autoplay = False
		self._origin_replace = True
		kodi_utils.notification('Your previous source is not available for this one - pick a new match', 4500)
		return self.display_results(results)

	def _autoplay_origin_state(self):
		'''Returns (state, results):
		  ('origin', results)  the saved pack / cloud folder has this episode -> play it, ignoring other autoplay rules
		  ('manual', None)     foreground Autoplay with nothing usable saved -> show results so the user picks
		  ('none', None)       feature not applicable -> carry on exactly as before'''
		try:
			if not self._autoplay_link_wanted(): return 'none', None
			nextep = bool(self.background and self.play_type in ('autoplay_nextep', 'autoscrape_nextep'))
			# Setting-driven foreground autoplay only: explicit requests (Select Source, Rescrape, custom values,
			# random play, filters-ignored) keep their own behaviour.
			foreground = bool(not self.background and 'autoplay' not in self.params and self.autoplay
							and not self._random_playback() and not getattr(self, 'ignore_scrape_filters', False))
			if not (nextep or foreground): return 'none', None
			from caches.autoplay_cache import autoplay_cache
			origin = autoplay_cache.get_origin(self.tmdb_id)
			if not origin: return ('manual' if foreground else 'none'), None
			if origin.get('kind') == 'standard': return 'none', None
			kodi_utils.logger('PlayOrigin', 'S%02dE%02d (%s): looking in the saved %s first: %s' % (
				self.season, self.episode, 'next episode' if nextep else 'selected episode', origin.get('kind'), origin.get('name')))
			results = self._origin_pack_results(origin) if origin.get('kind') == 'pack' else self._origin_cloud_results(origin)
			kodi_utils.logger('PlayOrigin', 'saved %s lookup -> %s' % (origin.get('kind'), '%d result(s)' % len(results) if results else 'episode not found there'))
			if results: return 'origin', results
			if foreground: self._origin_replace = True
			return ('manual' if foreground else 'missing'), None
		except Exception as e:
			kodi_utils.logger('PlayOrigin', 'EXCEPTION %s: %s - carrying on without the saved link' % (type(e).__name__, e))
			return 'none', None

	def _origin_pack_results(self, origin):
		'''Same pack: confirm it holds the next episode (no UI), then queue the original pack row.'''
		item = dict(origin.get('item') or {})
		if not item.get('hash') and not item.get('url'): return None
		provider = debrid.normalize_debrid_provider(item.get('debrid') or item.get('cache_provider') or '')
		api = debrid.import_pack_api(provider)
		if not api:
			diag_log('PlayOrigin', 'pack: unsupported provider %r' % provider)
			return None
		list_fn = getattr(api, 'parse_magnet_pack', None) or api.display_magnet_pack
		files = list_fn(item.get('url', ''), item.get('hash', ''))
		if not files:
			diag_log('PlayOrigin', 'pack: provider returned no files')
			return None
		title, season, episode, ep_name, absolute_episode = self._resolve_episode_labels()
		chosen, reason = pick_pack_episode_file(files, season, episode, absolute_episode=absolute_episode,
												ep_name=ep_name or '', title=title, label='NextEpPack')
		if not chosen:
			diag_log('PlayOrigin', 'pack: next episode not found in pack (%s)' % reason)
			return None
		item['nextep_origin'] = 'pack'
		diag_log('PlayOrigin', 'pack: next episode file=%r reason=%s' % (chosen.get('filename'), reason))
		return [item]

	def _origin_cloud_results(self, origin):
		'''Same cloud/direct scraper, restricted to the folder the previous episode was in.'''
		scraper_id = origin.get('scrape_provider')
		if scraper_id not in PLAY_ORIGIN_CLOUD_SCRAPERS: return None
		found = []
		if scraper_id == 'folders':
			self.folder_info = [i for i in self.get_folderscraper_info() if settings.source_folders_directory(self.media_type, i[1])]
			for entry in self.folder_sources():
				if origin.get('source') and entry[2] != origin.get('source'): continue
				found.extend(self._get_module('folders', entry[1]).results(self.search_info) or [])
		else:
			module = self._get_module('internal', manual_function_import('scrapers.%s' % scraper_id, 'source'))
			found.extend(module.results(self.search_info) or [])
		if not found:
			diag_log('PlayOrigin', 'cloud: %s returned nothing for the next episode' % scraper_id)
			return None
		key = origin.get('folder_key') or ''
		if key:
			same = [i for i in found if self._origin_folder_key(i) == key]
			diag_log('PlayOrigin', 'cloud: %d result(s) from %s, %d in the same folder %r' % (len(found), scraper_id, len(same), key))
			if not same: return None
			found = same
		else:
			diag_log('PlayOrigin', 'cloud: %s gives no folder info; using all %d result(s) from that scraper' % (scraper_id, len(found)))
		self.sources = list(found)
		return self.process_results(list(found))

	def collect_results(self):
		if self.prescrape_sources:
			self.sources.extend(self.prescrape_sources)
		self._quality_poll_scrapers = set()
		self.cloud_scraper_names = []
		threads_append = self.threads.append
		if self.active_external:
			prescrape_ran = getattr(self, 'prescrape_ran_scrapers', set()) or set()
			early_cloud = [i for i in self.internal_sources(cloud_early=True) if i[2] not in prescrape_ran]
			if early_cloud:
				self.cloud_scraper_names = [i[2] for i in early_cloud]
				for i in early_cloud:
					threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], False), name=i[2]))
				self.remove_scrapers.extend(i[2] for i in early_cloud)
		if self.active_folders: self.append_folder_scrapers(self.providers)
		self.providers.extend(self.internal_sources())
		if self.providers:
			for i in self.providers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], False), name=i[2]))
		if self.threads:
			[i.start() for i in self.threads]
		if self._user_cancelled_scrape():
			return []
		if self.active_external or self.background:
			if self.active_external:
				# Cloud scrapers in remove_scrapers run in parallel threads; do not poll their
				# window properties on the external progress bar (was showing TB_CLOUD etc. for the full timeout).
				external_progress_scrapers = [i for i in self.internal_scraper_names if i not in self.remove_scrapers]
				self.external_args = (self.meta, self.external_providers, self.debrid_enabled, self.cache_check_override, external_progress_scrapers,
										self.prescrape_sources, self.progress_dialog, self.disabled_ext_ignored, self.cloud_scraper_names, self.external_orchestration())
				self.activate_providers('external', external, False)
			if self._user_cancelled_scrape():
				return []
			if self.threads:
				self._wait_for_cloud_threads()
				self._absorb_internal_properties()
		elif self.active_internal_scrapers: self.scrapers_dialog()
		if self._user_cancelled_scrape():
			return []
		if self.threads:
			self._join_internal_threads(6)
			self._absorb_internal_properties()
		return self.sources

	def collect_prescrape_results(self):
		threads_append = self.prescrape_threads.append
		folder_prescrape = False
		if self.active_folders:
			if settings.check_prescrape_sources('folders', self.media_type):
				self.append_folder_scrapers(self.prescrape_scrapers)
				folder_prescrape = True
		self.prescrape_scrapers.extend(self.internal_sources(True))
		if not self.prescrape_scrapers and not folder_prescrape: return []
		for i in self.prescrape_scrapers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], True), name=i[2]))
		[i.start() for i in self.prescrape_threads]
		if self.background: [i.join() for i in self.prescrape_threads]
		else: self.scrapers_dialog()
		for i in self.prescrape_scrapers:
			scraper_name = i[2]
			if scraper_name not in self.remove_scrapers:
				self.remove_scrapers.append(scraper_name)
		if folder_prescrape and 'folders' not in self.remove_scrapers:
			self.remove_scrapers.append('folders')
		self.prescrape_ran_scrapers = {i[2] for i in self.prescrape_scrapers}
		return self.prescrape_sources

	def _leak_guard(self, results):
		"""Final universal guard for TV episodes, for every provider (torrent, external, debrid cloud, usenet, aiostreams): a result whose
		name clearly states another episode / season (S02E02 for S01E14, 'Season 2'), another show ('Other.Show.S01E14'), or is a pack
		that does not name the requested show is dropped. Packs / ranges that cover the requested episode or season, and names that say
		nothing, are untouched. Local 'folders' are the user's own files and are never filtered here. The explicit filterless search skips it."""
		try:
			info = getattr(self, 'search_info', None) or {}
			if not results or self.media_type != 'episode' or not info.get('season') or not info.get('episode'): return results
			if kodi_utils.get_property('fs_filterless_search') == 'true': return results
			from modules.source_utils import cloud_leak, get_aliases_titles, names_other_episode, epname_overrides_number
			ctx = {'media_type': 'episode', 'title': info.get('title') or '', 'aliases': get_aliases_titles(info.get('aliases') or []),
				'season': info.get('season'), 'episode': info.get('episode'), 'absolute': info.get('absolute_episode'), 'ep_name': info.get('ep_name') or ''}
			kept, verdicts = [], {}
			for i in results:
				if i.get('scrape_provider') in ('folders', 'rd_cloud', 'ad_cloud', 'pm_cloud', 'oc_cloud', 'tb_cloud'):
					# the user's own files: only a name that plainly states another season / episode is dropped
					nm = i.get('name') or i.get('display_name') or ''
					if nm and names_other_episode(nm, ctx['season'], ctx['episode'], ctx.get('absolute')) and not epname_overrides_number(ctx['title'], ctx['aliases'], nm, ctx.get('ep_name') or ''):
						diag_log('Sources', 'LeakGuard REJECT (cloud, other episode) provider=%s name=%r' % (i.get('scrape_provider'), nm))
					else: kept.append(i)
					continue
				names = [n for n in (i.get('name'), i.get('display_name')) if n]
				key = tuple(names)
				leak = verdicts.get(key)
				if leak is None: leak = verdicts[key] = any(cloud_leak(ctx, n) for n in names)
				if leak: diag_log('Sources', 'LeakGuard REJECT provider=%s name=%r' % (i.get('scrape_provider') or i.get('provider'), names[0] if names else ''))
				else: kept.append(i)
			return kept
		except Exception:
			return results

	def _unreleased_name_gate(self, results):
		"""Last line of defence for a movie / episode that is not out yet: whatever any scraper (internal, external, cloud, folder)
		returned must still be the requested title. Nothing real exists for it, so an unrelated 'Renegade Immortal episode 3' or
		'Johnny Bravo S01' must never reach the list or autoplay, whatever the per-scraper filter settings say."""
		try:
			info = getattr(self, 'search_info', None) or {}
			if not results or not info.get('unreleased'): return results
			from modules.source_utils import external_name_ok, get_aliases_titles, release_looks_like_pack
			aliases = get_aliases_titles(info.get('aliases') or [])
			kept = []
			verdicts = {}  # the same release name often comes back from several providers: judge each name once
			for i in results:
				name = i.get('name') or i.get('display_name') or ''
				if not name: ok = True
				else:
					key = (name, bool(i.get('package')))
					ok = verdicts.get(key)
					if ok is None and self.media_type != 'movie' and (i.get('package') or release_looks_like_pack(name) or _VOLUME_PACK_RE.search(name)):
						# An episode that is not out yet cannot be inside any pack (and 'vol 01-18' / '001-162' names are book / chapter
						# releases, not video): a pack can never be the answer here.
						ok = verdicts[key] = False
					if ok is None:
						ok = verdicts[key] = bool(external_name_ok(self.media_type, info.get('title'), name, aliases=aliases, year=info.get('year'),
							season=info.get('season'), episode=info.get('episode'), ep_name=info.get('ep_name') or '',
							absolute_episode=info.get('absolute_episode'), is_pack=True if i.get('package') else None))
				if ok:
					kept.append(i)
				else:
					diag_log('Sources', 'unreleased title: REJECT provider=%s name=%r' % (i.get('scrape_provider') or i.get('provider'), name))
			return kept
		except Exception:
			return results

	def process_results(self, results):
		self._nzb_trace = []
		results = self._process_results(results)
		self._log_nzb_trace(results)
		return self._check_nzb_results(results)

	def _nzb_mark(self, stage, results):
		"""Remembers how many NZB results are left after a filtering stage (logged once per search by _log_nzb_trace)."""
		try: self._nzb_trace.append((stage, sum(1 for i in results if i.get('scrape_provider') == 'nzb')))
		except Exception: pass
		return results

	def _log_nzb_trace(self, results):
		"""One log line saying where NZB results were lost, only when some were."""
		try:
			trace = getattr(self, '_nzb_trace', None) or []
			if not trace or trace[0][1] == 0 or not nzb_debug_enabled(): return
			final = sum(1 for i in results if i.get('scrape_provider') == 'nzb')
			lost, prev = [], trace[0][1]
			for stage, count in trace[1:]:
				if count < prev: lost.append('%s -%d' % (stage, prev - count))
				prev = count
			if final < prev: lost.append('end -%d' % (prev - final))
			if lost: kodi_utils.logger('NZB', 'results: %d from the scraper, %d in the list; lost at: %s' % (trace[0][1], final, ', '.join(lost)))
		except Exception: pass

	def _nzb_episode_hint(self):
		"""Tells the Usenet layer which episode this is: an NZB that is a pack of episodes is then checked / played on THAT episode's file."""
		try:
			from apis import usenet_stream
			info = getattr(self, 'search_info', None) or {}
			usenet_stream.set_episode(self.media_type, self.season, self.episode, info.get('absolute_episode'))
		except Exception:
			pass

	def _check_nzb_results(self, results):
		"""After every filter, sort and limit: dead / archive NZB results are taken out, checking only the largest few not judged yet."""
		try:
			if not results or not any(i.get('scrape_provider') == 'nzb' for i in results): return results
			self._nzb_episode_hint()
			from scrapers.nzb import check_results
			if (self.autoplay or self.autoplay_nextep or self.autoscrape_nextep) and self._autoplay_link_wanted():
				# Autoplay: only the NZB it is about to play is checked (the pack / file / group that is next); when the next pick is from
				# any other source nothing is checked at all. (Opening the results list to choose by hand checks the largest few as before.)
				wanted = self._origin_nzb_candidates(results)
				if not wanted:
					first = next((i for i in results if i.get('scrape_provider') != 'nzb' or i.get('nzb_cached') or i.get('nzb_direct')), None)
					wanted = [first] if first is not None and first.get('scrape_provider') == 'nzb' else []
				wanted = wanted[:max(1, settings.nzb_checks_per_type())]
				diag_log('NZB Match', 'Autoplay: health check on %d NZB result(s) only (%s)' % (len(wanted), 'the next pick' if wanted else 'next pick is not an NZB - none checked'))
				if not wanted: return results
				return check_results(results, only=wanted)
			return check_results(results)
		except Exception as e:
			kodi_utils.logger('NZB', 'final-list check skipped: %s' % e)
			return results

	def _process_results(self, results):
		try:
			from caches import watching_cache
			watching_cache.match_flush()
		except Exception: pass
		if not results: return results
		diag = diag_enabled()
		self._nzb_mark('scraped', results)
		results = self._unreleased_name_gate(results)
		self._nzb_mark('not-yet-aired check', results)
		if not results: return results
		results = self._leak_guard(results)
		self._nzb_mark('other-episode/show check', results)
		if not results: return results
		self._touch_sources_busy()
		results = self._stamp_native_torrent_cache(results)
		self._nzb_mark('cache check', results)
		if not results: return results
		if diag: self._diag_pack_results('after cache check', results)
		results = self.sort_results(results)
		min_seeders = settings.uncached_min_seeders()
		all_uncached_results = [i for i in results if 'Uncached' in i.get('cache_provider', '')]
		# seeders can be present but None (external scrapers); .get default only covers missing keys
		self.uncached_results = [i for i in all_uncached_results if int(i.get('seeders') or 0) >= min_seeders]
		uncached_in_main = []
		if settings.include_uncached_torbox():
			uncached_in_main.extend([i for i in self.uncached_results if 'TorBox' in i.get('cache_provider', '')])
		if settings.include_uncached_offcloud():
			uncached_in_main.extend([i for i in self.uncached_results if 'Offcloud' in i.get('cache_provider', '')])
		if settings.include_uncached_premiumize():
			uncached_in_main.extend([i for i in self.uncached_results if 'Premiumize' in i.get('cache_provider', '')])
		if uncached_in_main:
			strip_uncached = _without(all_uncached_results, uncached_in_main)
			self.uncached_results = _without(self.uncached_results, uncached_in_main)
		else:
			strip_uncached = all_uncached_results
		_pre_strip = results
		results = _without(results, strip_uncached)
		self._nzb_mark('uncached hidden', results)
		if diag: self._diag_pack_stage('uncached hidden from main list (min_seeders=%s; include_uncached premiumize/torbox/offcloud=%s/%s/%s)' % (
			min_seeders, settings.include_uncached_premiumize(), settings.include_uncached_torbox(), settings.include_uncached_offcloud()), _pre_strip, results)
		if diag: self._diag_pack_results('uncached list (shown in the Uncached view, not the main list)', self.uncached_results)
		cloud_scrapers = ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud')
		cloud_results = [i for i in results if i.get('scrape_provider') in cloud_scrapers]
		aio_preserve_results = []
		if self._aiostreams_preserve_order():
			aio_preserve_results = sorted([i for i in results if i.get('scrape_provider') == 'aiostreams'], key=lambda k: k.get('aio_order', 999999))
		filter_exempt = cloud_results + aio_preserve_results
		if self.ignore_scrape_filters: self.filters_ignored = True
		else:
			scrape_results = _without(results, filter_exempt)
			if diag: _before = scrape_results
			scrape_results = self.filter_results(scrape_results)
			self._nzb_mark('quality/size filter', scrape_results)
			if diag: self._diag_pack_stage('filter_results (quality/size; quality_filter=%s size_method=%s)' % (self.quality_filter, self.filter_size_method), _before, scrape_results)
			if diag:
				_before = scrape_results
				scrape_results = self.filter_audio(scrape_results)
				self._diag_pack_stage('filter_audio (audio/language tag filters)', _before, scrape_results)
				for file_type in self.filter_keys:
					_before = scrape_results
					scrape_results = self.special_filter(scrape_results, file_type)
					self._diag_pack_stage('special_filter[%s]' % file_type, _before, scrape_results)
			else:
				# one pass for the audio filter and every special filter instead of one list rebuild per filter
				predicates = [self._audio_filter_predicate()] + [self._special_filter_predicate(file_type) for file_type in self.filter_keys]
				predicates = [p for p in predicates if p]
				if predicates: scrape_results = [i for i in scrape_results if all(p(i) for p in predicates)]
				self._nzb_mark('audio/HDR/HEVC filters', scrape_results)
			results = scrape_results + cloud_results
			if aio_preserve_results:
				non_aio = [self._enrich_sort_fields(i) for i in results if i.get('scrape_provider') != 'aiostreams']
				non_aio.sort(key=self._results_sort_key)
				non_aio = self._sort_uncached_results(non_aio)
				aio_block = [self._enrich_sort_fields(i) for i in aio_preserve_results]
				results = self._merge_aiostreams_at_provider_rank(non_aio, aio_block)
		if self.prescrape:
			self.all_scrapers = self.active_internal_scrapers
			if self.autoplay:
				autoplay_results = self._prescrape_autoplay_candidates(results)
				if autoplay_results:
					self.cloud_prescrape_autoplay = True
					results = autoplay_results
		else:
			self.all_scrapers = list(set(self.active_internal_scrapers + self.remove_scrapers))
			kodi_utils.clear_property('fs_filterless_search')
		results = self.sort_preferred_filters(results)
		results = self.sort_first(results)
		pref_sort_ran = False
		if self._pref_sort_should_run() or any(i.get('pref_includes') for i in results):
			results = self._sort_with_pref_boost(results)
			pref_sort_ran = True
		if self.ignore_scrape_filters: return results
		combined = self._apply_result_limits(results, cloud_scrapers)
		self._nzb_mark('result limits', combined)
		if diag: self._diag_pack_stage('result limits (max per quality / max total)', results, combined)
		if diag: self._diag_pack_results('FINAL main results list', combined)
		if self._pin_scrapers_to_top_enabled():
			combined = self.sort_first(combined)
		elif not pref_sort_ran:
			combined = self.sort_results(combined)
		self._log_custom_sort_summary(combined, pref_sort_ran)
		return self._apply_origin_profile(combined)

	def _pack_diag_key(self, item):
		return (item.get('hash') or '', item.get('name') or '')

	def _diag_pack_stage(self, stage, before, after):
		'''diag_log every PACK row a filtering stage removed, so "why isn't my pack in the results?" has an answer.'''
		try:
			if not before or not diag_enabled(): return
			kept = set(self._pack_diag_key(i) for i in (after or []))
			dropped = [i for i in before if self._pack_diag_key(i) not in kept]
			if not dropped: return
			packs = [i for i in dropped if 'package' in i]
			diag_log('ResultsPack', '%s: removed %d row(s), %d of them pack(s)' % (stage, len(dropped), len(packs)))
			for i in packs:
				diag_log('ResultsPack', '  REMOVED PACK: name=%r package=%s quality=%s size=%s seeders=%s cache=%s extraInfo=%r' % (
					i.get('name'), i.get('package'), i.get('quality'), i.get('size'), i.get('seeders'), i.get('cache_provider'), i.get('extraInfo')))
			# Every other removed row too (capped), so "why is this release missing?" is answerable for anything
			others = [i for i in dropped if 'package' not in i]
			for i in others[:40]:
				diag_log('ResultsDrop', '  REMOVED: %s | name=%r quality=%s size=%s seeders=%s cache=%s scraper=%s' % (
					stage.split(' (')[0], i.get('name'), i.get('quality'), i.get('size'), i.get('seeders'), i.get('cache_provider'), i.get('scrape_provider')))
			if len(others) > 40: diag_log('ResultsDrop', '  ... %d more removed row(s) not listed' % (len(others) - 40))
		except Exception:
			pass

	def _diag_pack_results(self, stage, results):
		try:
			if not diag_enabled(): return
			packs = [i for i in (results or []) if 'package' in i]
			diag_log('ResultsPack', '%s: %d row(s), %d pack(s)' % (stage, len(results or []), len(packs)))
			for i in packs:
				diag_log('ResultsPack', '  PACK: name=%r package=%s quality=%s size=%s seeders=%s cache=%s' % (
					i.get('name'), i.get('package'), i.get('quality'), i.get('size'), i.get('seeders'), i.get('cache_provider')))
		except Exception:
			pass

	def _stamp_native_torrent_cache(self, results):
		native = [i for i in results if i.get('scrape_provider') in self.native_torrent_scrapers and i.get('hash') and not i.get('cache_provider')]
		if not native:
			return results
		return debrid.stamp_torrent_cache(
			results, getattr(self, 'debrid_enabled', None) or debrid.debrid_enabled(),
			self.cache_check_override, self._native_torrent_data(),
			background=self.background, progress_dialog=None if self.background else self.progress_dialog)

	def _native_torrent_data(self):
		info = getattr(self, 'search_info', None) or {}
		if self.media_type == 'movie':
			return {'imdb': info.get('imdb_id'), 'title': info.get('title'), 'year': info.get('year')}
		return {'imdb': info.get('imdb_id'), 'tvshowtitle': info.get('title'), 'title': info.get('ep_name'),
			'year': info.get('year'), 'season': str(info.get('season') or ''), 'episode': str(info.get('episode') or '')}

	def _log_prescrape_settings(self):
		try:
			active = self.active_internal_scrapers or []
			check_scrapers = ('easynews', 'aiostreams', 'nzb', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud', 'folders', 'external')
			check = {s: settings.check_prescrape_sources(s, self.media_type) for s in active if s in check_scrapers}
			label = '%s tmdb=%s' % (self.media_type, self.tmdb_id)
			if self.media_type == 'episode':
				abs_ep = absolute_episode_from_season_data(self.meta.get('season_data'), self.season, self.episode)
				abs_ep_str = 'abs=%s' % abs_ep if abs_ep else 'abs=None'
				label += ' S%02dE%02d %s ep_name=%r' % (self.season, self.episode, abs_ep_str, self.meta.get('ep_name') or '')
			elif self.media_type == 'movie':
				label += ' title=%r' % (self.meta.get('title') or '')
			kodi_utils.logger('ScrapePrescrape', '%s prescrape=%s enabled=%s skip_override=%s autoplay=%s background=%s check=%s active=%s' % (
				label, self.prescrape, settings.prescrape_enabled(self.media_type, active),
				self._playback_skips_prescrape_override(), self.autoplay, self.background, check, active))
		except: pass

	def _log_custom_sort_summary(self, results, pref_sort_ran):
		try:
			if not results or not self._pref_sort_should_run(): return
			prefs = settings.preferred_filters()
			scored = sum(1 for i in results if i.get('pref_includes', 0) > 0)
			top = [(i.get('quality'), i.get('pref_includes', 0), i.get('scrape_provider'), (i.get('display_name') or i.get('name') or '')[:80]) for i in results[:15]]
			kodi_utils.logger('CustomSort', '%s tmdb=%s ran=%s prefs=%s scored=%s/%s top=%s' % (
				self.media_type, self.tmdb_id, pref_sort_ran, prefs, scored, len(results), top))
		except: pass

	def sort_results(self, results):
		aio_block, other = self._split_aiostreams_preserve(results)
		if other:
			other = [self._enrich_sort_fields(i) for i in other]
			other.sort(key=self._results_sort_key)
			other = self._sort_uncached_results(other)
		if aio_block:
			aio_block = [self._enrich_sort_fields(i) for i in aio_block]
			if other: return self._merge_aiostreams_at_provider_rank(other, aio_block)
			return aio_block
		return other

	def filter_results(self, results):
		if self.folders_ignore_filters:
			folder_results = [i for i in results if i['scrape_provider'] == 'folders']
			results = _without(results, folder_results)
		else: folder_results = []
		results = [i for i in results if i['quality'] in self.quality_filter]
		if self.filter_size_method:
			min_size = string_to_float(get_setting('nightshift.results.%s_size_min' % self.media_type, '0'), '0') / 1000
			if min_size == 0.0 and not self.include_unknown_size: min_size = 0.02
			if self.filter_size_method == 1:
				duration = self.meta['duration'] or (5400 if self.media_type == 'movie' else 2400)
				max_size = ((0.125 * (0.90 * string_to_float(get_setting('results.line_speed', '25'), '25'))) * duration)/1000
			elif self.filter_size_method == 2:
				max_size = string_to_float(get_setting('nightshift.results.%s_size_max' % self.media_type, '10000'), '10000') / 1000
			# Packs are exempt: their size is a per-episode ESTIMATE (pack size / episode count), so a min/max
			# size window says nothing about them and must never hide a pack from the results.
			results = [i for i in results if i['scrape_provider'] == 'folders' or i['scrape_provider'] in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud') or 'package' in i or min_size <= i['size'] <= max_size]
		if self.autoplay:
			autoplay_max_mb = string_to_float(get_setting('nightshift.autoplay.%s_size_max' % self.media_type, '0'), '0')
			if autoplay_max_mb > 0:
				autoplay_max_size = autoplay_max_mb / 1000
				_size_exempt = ('folders', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud')
				results = [i for i in results if i['scrape_provider'] in _size_exempt or 'package' in i or not i.get('size') or i['size'] <= autoplay_max_size]
		results += folder_results
		return results

	def _audio_filter_predicate(self):
		a_filters = settings.audio_filters()
		if not a_filters: return None
		return lambda i: not any(x in i['extraInfo'] for x in a_filters)

	def filter_audio(self, results):
		keep = self._audio_filter_predicate()
		return [i for i in results if keep(i)] if keep else list(results)

	def _special_filter_predicate(self, file_type):
		"""keep(item) -> bool for one special filter (HEVC / HDR / D-Vision ...), or None when that filter is off."""
		enable_setting, key = settings.filter_status(file_type), self.filter_keys[file_type]
		if key == 'HEVC' and enable_setting == 0:
			# Absolute resolution order (not user Quality Sort Order) - "max" means exclude higher res HEVC
			hevc_max_quality = self._get_absolute_quality_rank(get_setting('nightshift.filter.hevc.%s' % ('max_autoplay_quality' if self.autoplay else 'max_quality'), '4K'))
			return lambda i: not self._extra_info_has_tag(i['extraInfo'], key) or self._get_absolute_quality_rank(i.get('quality', 'SD')) >= hevc_max_quality
		if enable_setting == 1:
			if key in ('D/VISION', 'HDR'):
				if not settings.filter_status({'D/VISION': 'hdr', 'HDR': 'dv'}[key]) == 0:
					return lambda i: not self._extra_info_has_tag(i['extraInfo'], key)
				return lambda i: not (self._extra_info_has_tag(i['extraInfo'], key) and not self._extra_info_has_tag(i['extraInfo'], 'HYBRID'))
			return lambda i: not self._extra_info_has_tag(i['extraInfo'], key)
		return None

	def special_filter(self, results, file_type):
		keep = self._special_filter_predicate(file_type)
		return [i for i in results if keep(i)] if keep else results

	def _normalize_pref_tag(self, tag):
		key = (tag or '').lower().replace('[b]', '').replace('[/b]', '').strip()
		if key in self.filter_keys: return self.filter_keys[key]
		aliases = {'d/vision': 'D/VISION', 'dolby vision': 'D/VISION', 'hdr': 'HDR', 'high dynamic range (hdr)': 'HDR', 'dolby atmos': 'ATMOS', 'atmos': 'ATMOS', 'hevc (x265)': 'HEVC', 'hevc': 'HEVC',
					'english or untagged': 'ENG-OR-UNTAGGED', 'eng-or-untagged': 'ENG-OR-UNTAGGED'}
		aliases.update({name.lower(): lang_tag for name, lang_tag, _ in audio_lang_choices()})
		return aliases.get(key, tag)

	def _parse_extra_info_tags(self, extra_info):
		tags = []
		if not extra_info: return tags
		items = extra_info if isinstance(extra_info, list) else [extra_info]
		for item in items:
			if not item: continue
			for part in str(item).split(' | '):
				part = part.replace('[B]', '').replace('[/B]', '').strip()
				if part: tags.append(part)
		return tags

	def _pref_tag_in_extra_info(self, tag, extra_info):
		if not tag or not extra_info: return False
		normalized = self._normalize_pref_tag(tag)
		for part in self._parse_extra_info_tags(extra_info):
			part_norm = self._normalize_pref_tag(part)
			if part_norm == normalized or part == tag or part == normalized: return True
		return False

	def _extra_info_has_tag(self, extra_info, tag):
		return self._pref_tag_in_extra_info(tag, extra_info)

	def _normalized_title_blob(self, item):
		parts = [item.get('name'), item.get('display_name')]
		extra = item.get('extraInfo', '')
		if extra: parts.append(' | '.join(extra) if isinstance(extra, list) else extra)
		return ' '.join(' '.join([i for i in parts if i]).lower().split())

	def _all_extra_info_tags(self, item):
		tags = []
		existing = item.get('extraInfo', '')
		if isinstance(existing, list): tags.extend(existing)
		elif existing: tags.append(existing)
		for field in ('name', 'display_name'):
			raw = item.get(field)
			if not raw: continue
			try:
				_, info = get_file_info(name_info=release_info_format(raw))
				if isinstance(info, list): tags.extend(info)
			except: pass
		return tags

	def _explicit_sdr_release(self, item):
		blob = self._normalized_title_blob(item)
		if ' sdr ' in f' {blob} ' or blob.startswith('sdr '): return True
		return 'SDR' in self._all_extra_info_tags(item)

	def _pref_tag_in_result(self, tag, item):
		normalized = self._normalize_pref_tag(tag)
		if normalized == 'ENG-OR-UNTAGGED':
			return matches_english_or_untagged(self._parse_extra_info_tags(self._all_extra_info_tags(item)))
		if self._pref_tag_in_extra_info(tag, item.get('extraInfo', '')): return True
		if self._pref_tag_in_extra_info(tag, self._all_extra_info_tags(item)): return True
		if self._explicit_sdr_release(item): return False
		blob = self._normalized_title_blob(item)
		if normalized == 'D/VISION' and any(x in blob for x in ('dolby vision', 'dolbyvision', ' dovi ', ' dv ', 'dovi', 'profile 8', 'profile8')): return True
		if normalized == 'ATMOS' and ('atmos' in blob or ('ddp' in blob and 'atmos' in blob)): return True
		if normalized == 'HDR':
			if any(x in blob.split() for x in ('hdrip', 'hd.rip')): return False
			if any(x in blob for x in ('hdr10', 'hdr10+', 'hdr10p')): return True
			return ' hdr ' in f' {blob} '
		return False

	def sort_preferred_filters(self, results):
		if self._pref_sort_should_run():
			try:
				preferences = settings.preferred_filters()
				if not preferences: return results
				preferences = [self._normalize_pref_tag(i) for i in preferences]
				pref_weights = {0: 100, 1: 50, 2: 20, 3: 10, 4: 5, 5: 2}
				return [dict(i, **{'pref_includes': sum(pref_weights.get(preferences.index(x), 0) for x in preferences if self._pref_tag_in_result(x, i))}) for i in results]
			except: pass
		return results

	def _sort_with_pref_boost(self, results):
		aio_block, other = self._split_aiostreams_preserve(results)
		if not other: return aio_block if aio_block else results
		other = [self._enrich_sort_fields(i) for i in other]
		aio_pref, aio_nonpref = [], []
		if aio_block:
			aio_block = [self._enrich_sort_fields(i) for i in aio_block]
			aio_pref = [i for i in aio_block if i.get('pref_includes', 0) > 0]
			aio_nonpref = [i for i in aio_block if i.get('pref_includes', 0) == 0]
		groups = {}
		for item in other:
			groups.setdefault(item['quality_rank'], []).append(item)
		with_pref_all = list(aio_pref)
		for quality_rank in sorted(groups.keys()):
			with_pref_all.extend([i for i in groups[quality_rank] if i.get('pref_includes', 0) > 0])
		with_pref_all.sort(key=self._pref_boost_sort_key)
		without_sorted = []
		for quality_rank in sorted(groups.keys()):
			without_pref = [i for i in groups[quality_rank] if i.get('pref_includes', 0) == 0]
			non_sdr = [i for i in without_pref if not self._explicit_sdr_release(i)]
			sdr = [i for i in without_pref if self._explicit_sdr_release(i)]
			non_sdr.sort(key=self._results_sort_key)
			sdr.sort(key=self._results_sort_key)
			without_sorted.extend(non_sdr + sdr)
		sorted_other = self._sort_uncached_results(with_pref_all + without_sorted)
		if aio_nonpref:
			return self._merge_aiostreams_at_provider_rank(sorted_other, aio_nonpref)
		return sorted_other

	def _pref_boost_sort_key(self, item):
		if item.get('scrape_provider') == 'aiostreams' and self._aiostreams_preserve_order():
			return (-item.get('pref_includes', 0), item['quality_rank'], item.get('aio_order', 999999))
		return (-item.get('pref_includes', 0),) + self._results_sort_key(item)

	def _custom_pref_sort_active(self):
		return self._pref_sort_should_run()

	def _pref_sort_should_run(self):
		if not settings.preferred_filters(): return False
		if int(get_setting('nightshift.filter.sort_to_top', '0')) == 0: return False
		return settings.sort_to_top_filter(self.autoplay)

	def _pin_scrapers_to_top_enabled(self):
		if 'folders' in self.all_scrapers and settings.sort_to_top('folders'): return True
		return any(settings.sort_to_top(p) for p in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud') if p in self.all_scrapers)

	def sort_first(self, results):
		try:
			sort_first_scrapers = []
			if 'folders' in self.all_scrapers and settings.sort_to_top('folders'): sort_first_scrapers.append('folders')
			sort_first_scrapers.extend([i for i in self.all_scrapers if i in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud') and settings.sort_to_top(i)])
			if not sort_first_scrapers: return results
			sort_first = [i for i in results if i['scrape_provider'] in sort_first_scrapers]
			sort_first.sort(key=lambda k: (self._sort_folder_to_top(k['scrape_provider']), k['quality_rank']))
			sort_last = _without(results, sort_first)
			results = sort_first + sort_last
		except: pass
		return results

	def _apply_result_limits(self, results, cloud_scrapers):
		if self.autoplay or self.ignore_scrape_filters: return results
		quality_limit = settings.limit_number_quality()
		total_limit = settings.limit_number_total()
		if not quality_limit and not total_limit: return results
		quality_counter_dict = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'SCR': 0, 'CAM': 0, 'TELE': 0}
		limit_list, non_cloud_count = [], 0
		for i in results:
			if i.get('scrape_provider') in cloud_scrapers:
				limit_list.append(i)
				continue
			if quality_limit and quality_counter_dict[i['quality']] >= quality_limit: continue
			if total_limit and non_cloud_count >= total_limit: continue
			quality_counter_dict[i['quality']] += 1
			non_cloud_count += 1
			limit_list.append(i)
		return limit_list

	def limit_quality_numbers(self, results):
		if self.autoplay or self.ignore_scrape_filters: return results
		quality_limit = settings.limit_number_quality()
		if not quality_limit: return results
		quality_counter_dict, limit_list = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'SCR': 0, 'CAM': 0, 'TELE': 0}, []
		for i in results:
			if quality_counter_dict[i['quality']] < quality_limit:
				quality_counter_dict[i['quality']] += 1
				limit_list.append(i)
		return limit_list

	def limit_quality_total(self, results):
		if self.autoplay or self.ignore_scrape_filters: return results
		total_limit = settings.limit_number_total()
		if not total_limit: return results
		return results[:total_limit]

	def prepare_internal_scrapers(self):
		if self.active_external and len(self.active_internal_scrapers) == 1:
			self.internal_scraper_names = [i for i in self.active_internal_scrapers if i != 'external']
			if self.clear_properties: self._clear_properties()
			return True
		active_internal_scrapers = [i for i in self.active_internal_scrapers if not i in self.remove_scrapers]
		if self.prescrape and not self.active_external and all([settings.check_prescrape_sources(i, self.media_type) for i in active_internal_scrapers]): return False
		if 'folders' in active_internal_scrapers:
			folder_info = self.get_folderscraper_info()
			self.folder_info = [i for i in folder_info if settings.source_folders_directory(self.media_type, i[1])]
			if self.folder_info:
				self.active_folders = True
				self.internal_scraper_names = [i for i in active_internal_scrapers if i not in ('folders', 'external')] + [i[0] for i in self.folder_info]
			else: self.internal_scraper_names = [i for i in active_internal_scrapers if i not in ('folders', 'external')]
		else:
			self.folder_info = []
			self.internal_scraper_names = [i for i in active_internal_scrapers if i != 'external']
		self.active_internal_scrapers = active_internal_scrapers
		if self.clear_properties: self._clear_properties()
		return True

	def activate_providers(self, module_type, function, prescrape):
		sources = self._get_module(module_type, function).results(self.search_info)
		if prescrape:
			if sources: self.prescrape_sources.extend(sources)
			return
		# Early cloud scrapers publish via window property only during external scrape.
		if current_thread().name in self.remove_scrapers:
			return
		if sources: self.sources.extend(sources)

	def activate_external_providers(self):
		self.external_providers = self.external_sources()
		if not self.external_providers: self.disable_external()

	def disable_external(self):
		try: self.active_internal_scrapers.remove('external')
		except: pass
		self.active_external, self.external_providers = False, []

	def internal_sources(self, prescrape=False, cloud_early=False):
		internal_ids = ('easynews', 'aiostreams', 'nzb') + NATIVE_TORRENT_SCRAPERS + ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud')
		active_sources = [i for i in self.active_internal_scrapers if i in internal_ids and i not in self.remove_scrapers]
		if not prescrape:
			prescrape_ran = getattr(self, 'prescrape_ran_scrapers', set()) or set()
			if prescrape_ran:
				active_sources = [i for i in active_sources if i not in prescrape_ran]
		if cloud_early:
			active_sources = [i for i in active_sources if settings.cloud_scrape_before_external(i)]
		else:
			active_sources = [i for i in active_sources if not (prescrape and not settings.check_prescrape_sources(i, self.media_type))]
		sourceDict = []
		for i in active_sources:
			try:
				if i == 'knaben':
					from scrapers.piratebay import knaben_source
					sourceDict.append(('internal', knaben_source, i))
				else: sourceDict.append(('internal', manual_function_import('scrapers.%s' % i, 'source'), i))
			except Exception as e: logger('InternalSources', 'could not load scraper %s: %s: %s' % (i, type(e).__name__, e))
		return sourceDict

	def _can_continue_full_scrape(self):
		if self.active_external: return True
		remaining = [i for i in self.active_internal_scrapers if i not in self.remove_scrapers]
		return bool(remaining)

	def external_module_groups(self):
		groups = []
		for mod in getattr(self, 'external_modules', None) or settings.active_external_modules():
			append_module_to_syspath('special://home/addons/%s/lib' % mod['module_id'])
			try:
				sourceDict = manual_function_import(mod['folder_name'], 'sources')(specified_folders=['torrents'], ret_all=self.disabled_ext_ignored)
			except:
				sourceDict = []
			module_label = mod.get('display_name') or mod['folder_name']
			entries = []
			for item in sourceDict or []:
				try:
					provider, module_class = item[0], item[1]
					pack = item[2] if len(item) > 2 else ''
					cache_key = settings.external_scraper_cache_key(mod['module_id'], provider)
					thread_name = '%s [%s]' % (provider, module_label)
					entries.append((thread_name, module_class, pack, cache_key, provider, mod['module_id']))
				except: pass
			if entries:
				groups.append({'module_id': mod['module_id'], 'display_name': module_label, 'entries': entries})
		return groups

	def external_orchestration(self):
		groups = self.external_module_groups()
		if len(groups) <= 1: return None
		mode = settings.external_scraper_run_mode()
		if mode == '0': return None
		if mode == '1':
			return {'groups': groups, 'max_parallel': 1, 'skip_threshold': 0, 'early_stop': True, 'primary_dedicated': False, 'mode': 'series_fallback'}
		if mode == '2':
			return {'groups': groups, 'max_parallel': 1, 'skip_threshold': 0, 'early_stop': False, 'primary_dedicated': False, 'mode': 'series_full'}
		if mode == '3':
			return {'groups': groups, 'max_parallel': max(1, len(groups) - 1), 'skip_threshold': 0, 'early_stop': False, 'primary_dedicated': True, 'mode': 'primary_parallel'}
		return None

	def external_sources(self):
		merged = []
		for group in self.external_module_groups():
			merged.extend(group['entries'])
		return merged

	def folder_sources(self):
		def import_info():
			for item in self.folder_info:
				scraper_name = item[0]
				module = manual_function_import('scrapers.folders', 'source')
				yield ('folders', (module, (item[1], scraper_name, item[2])), scraper_name)
		sourceDict = list(import_info())
		try: sourceDict = list(import_info())
		except: sourceDict = []
		return sourceDict

	def _cloud_scrapers(self):
		return ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud')

	def _prescrape_autoplay_candidates(self, results):
		autoplay_scrapers = self._cloud_scrapers() + ('easynews', 'aiostreams', 'nzb', 'folders')
		candidates = [i for i in results if i.get('scrape_provider') in autoplay_scrapers and settings.autoplay_prescrape(i['scrape_provider'])]
		playable = []
		for item in candidates:
			provider = item.get('scrape_provider')
			if provider == 'nzb' and not item.get('nzb_cached') and not item.get('nzb_direct'):
				continue
			playable.append(item)
		return playable

	def _is_cloud_result(self, item):
		return item.get('scrape_provider') in self._cloud_scrapers()

	def _external_autoplay_candidates(self, results):
		"""Global Autoplay Movie/Episode — debrid torrents (external + internal torrent scrapers), not cloud / AIO / EN / folders."""
		return [i for i in results if i.get('scrape_provider') in ('external',) + self.native_torrent_scrapers]

	def _release_empty_prescrape_cloud_scrapers(self):
		"""Let cloud scrapers run again during full scrape when prescrape found nothing."""
		if not self.check_prescrape_ran: return
		prescrape_ran = getattr(self, 'prescrape_ran_scrapers', set()) or set()
		for scraper in self._cloud_scrapers():
			if scraper in prescrape_ran:
				continue
			if scraper in self.remove_scrapers and not any(r.get('scrape_provider') == scraper for r in self.prescrape_sources):
				self.remove_scrapers.remove(scraper)

	def _prepare_cloud_autoplay_resolve(self):
		"""Leave prescrape progress UI and open a clean resolver dialog for cloud autoplay."""
		self._kill_progress_dialog(join_timeout=1.0)
		if not self.background:
			self._make_progress_dialog()
		self.resolve_dialog_made = False

	def play_source(self, results):
		if self._user_cancelled_scrape():
			return self._finish_scrape_cancel()
		self._clear_stale_resolve_busy()
		if kodi_utils.get_property(PROP_RESOLVE_BUSY) == 'true':
			try:
				kodi_utils.logger('NIGHTSHIFT', 'Play source skipped: resolve already in progress')
			except:
				pass
			self._abort_plugin_resolve()
			return
		if self.background:
			autoplay_queue = results
			if self._effective_autoplay():
				external = self._external_autoplay_candidates(results)
				if external: autoplay_queue = external
			if self._origin_source_missing(results): return self._origin_missing_handoff(results)
			nzb_first = self._origin_nzb_candidates(results)
			if nzb_first:
				# First pick was an NZB: the next episode is the best-matching NZB; the other sources stay behind it as the fallback.
				autoplay_queue = nzb_first + [i for i in autoplay_queue if i not in nzb_first]
			if not nzb_first: autoplay_queue = self._origin_front(autoplay_queue, results)
			if self.autoplay_nextep and not self.autoscrape_nextep:
				return self._stash_nextep_autoplay_play(autoplay_queue)
			return self.play_file(autoplay_queue)
		if self.autoplay and self._origin_source_missing(results): return self._origin_missing_handoff(results)
		nzb_first = self._origin_nzb_candidates(results) if self.autoplay else []
		if nzb_first:
			queue = nzb_first + [i for i in self._external_autoplay_candidates(results) if i not in nzb_first]
			self.cloud_prescrape_autoplay = True
			self._last_cloud_autoplay_results = list(queue)
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay (NZB first pick): %s NZB result(s), %s fallback(s)' % (len(nzb_first), len(queue) - len(nzb_first)))
			self._prepare_cloud_autoplay_resolve()
			return self.play_file(queue)
		prescrape_autoplay = self._prescrape_autoplay_candidates(results) if self.autoplay else []
		if prescrape_autoplay:
			self.cloud_prescrape_autoplay = True
			self._last_cloud_autoplay_results = list(prescrape_autoplay)
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay prescrape: %s hit(s) from %s' % (len(prescrape_autoplay), prescrape_autoplay[0].get('scrape_provider', '')))
			self._prepare_cloud_autoplay_resolve()
			return self.play_file(prescrape_autoplay)
		self.cloud_prescrape_autoplay = False
		if self.prescrape and any(self._is_cloud_result(i) for i in results):
			return self.display_results(results)
		if self._effective_autoplay():
			external = self._external_autoplay_candidates(results)
			if external:
				return self.play_file(self._origin_front(external, results))
			if any(self._is_cloud_result(i) for i in results):
				return self.display_results(results)
		return self.display_results(results)

	def append_folder_scrapers(self, current_list):
		current_list.extend(self.folder_sources())

	def get_folderscraper_info(self):
		folder_info = [(get_setting('nightshift.%s.display_name' % i), i, settings.source_folders_directory(self.media_type, i))
						for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
		return [i for i in folder_info if not i[0] in (None, 'None', '') and i[2]]

	def _get_active_scraper_names(self, scraper_list):
		return [i[2] for i in scraper_list]

	def _internal_wait_cap(self, threads):
		"""Seconds the scrape dialog waits for the internal scrapers. A Usenet title search asks every indexer slot, often with
		several queries, so it gets longer than the 25 s of the quick scrapers - cutting it off threw its results away."""
		return NZB_WAIT_SECONDS if any(t.name == 'nzb' for t in threads) else 25

	def scrapers_dialog(self):
		def _scraperDialog():
			monitor = kodi_utils.kodi_monitor()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
				try:
					self._touch_sources_busy()
					remaining_providers = [x.getName() for x in _threads if x.is_alive() is True]
					self._process_internal_results()
					current_progress = max((time.time() - start_time), 0)
					line1 = ', '.join(remaining_providers).upper()
					percent = int((current_progress/float(self._internal_wait_cap(_threads)))*100)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, line1, percent)
					kodi_utils.sleep(self.sleep_time)
					if len(remaining_providers) == 0: break
					if percent >= 100:
						grace_deadline = time.time() + 8
						while time.time() < grace_deadline and any(x.is_alive() for x in _threads):
							self._process_internal_results()
							kodi_utils.sleep(100)
						for thread in _threads:
							thread.join(timeout=max(0.0, grace_deadline - time.time()))
						self._absorb_internal_properties()
						break
				except:	return self._kill_progress_dialog()
		if self.prescrape: scraper_list, _threads = self.prescrape_scrapers, self.prescrape_threads
		else: scraper_list, _threads = self.providers, self.threads
		self.internal_scrapers = self._get_active_scraper_names(scraper_list)
		if not self.internal_scrapers: return
		_scraperDialog()
		try: del monitor
		except: pass

	def _wait_active_playback_end(self):
		player = kodi_utils.kodi_player()
		monitor = kodi_utils.kodi_monitor()
		# Pack Browse closes sources before the player may report isPlaying — wait briefly
		# for start so we do not immediately reopen the results list over the stream.
		for _ in range(50):
			if monitor.abortRequested():
				return
			if player.isPlayingVideo() or player.isPlaying():
				break
			kodi_utils.sleep(100)
		while player.isPlayingVideo() or player.isPlaying():
			if monitor.abortRequested():
				return
			kodi_utils.sleep(100)

	def _reclaim_sources_busy(self):
		'''Re-take scrape lock after releasing it during browse playback wait.'''
		if kodi_utils.get_property(PROP_SOURCES_BUSY) == 'true':
			return False
		self._sources_busy_owner = str(id(self))
		kodi_utils.set_property(PROP_SOURCES_BUSY, 'true')
		kodi_utils.set_property(PROP_SOURCES_OWNER, self._sources_busy_owner)
		self._touch_sources_busy()
		return True

	def display_results(self, results):
		results = self._leak_guard(results) # every path to the list goes through here, whatever produced the results
		while True:
			self._touch_sources_busy()
			window_format, window_number = settings.results_format()
			window_result = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
					window_format=window_format, window_id=window_number, results=results, meta=self.meta, sources_ref=self, episode_group_label=self.episode_group_label,
					scraper_settings=self.scraper_settings, prescrape=self.prescrape, filters_ignored=self.filters_ignored,
					uncached_results=self.uncached_results, cache_check_override=self.cache_check_override)
			if not window_result:
				# Drop busy before cleanup so a quick second widget is not toast-blocked.
				close_nextep_handoff_cover()
				self._begin_sources_cancel()
				self._kill_progress_dialog()
				self._abort_plugin_resolve()
				self._end_sources_cancel()
				return
			action, chosen_item = window_result
			if not action:
				if kodi_utils.get_property(PROP_BROWSE_RETURN_SOURCES) == 'true':
					kodi_utils.clear_property(PROP_BROWSE_RETURN_SOURCES)
					# Release busy while browsing so a hung/long wait does not block scrapes
					# with "Source search already running" until Kodi restart.
					self._release_sources_busy()
					self._wait_active_playback_end()
					if not self._reclaim_sources_busy():
						close_nextep_handoff_cover()
						self._kill_progress_dialog(join_timeout=1.0)
						self.resolve_dialog_made = False
						self._abort_plugin_resolve()
						return
					continue
				if self._playback_already_active():
					# Browse / mid-play close: do not clear the active playlist, but still
					# answer a pending widget resolve handle if one was never consumed.
					close_nextep_handoff_cover()
					self._kill_progress_dialog(join_timeout=1.0, close_overlays=False)
					self.resolve_dialog_made = False
					self._abort_plugin_resolve(clear_playlist=False)
					return
				# Drop busy before cleanup so a quick second widget is not toast-blocked.
				close_nextep_handoff_cover()
				self._begin_sources_cancel()
				self._kill_progress_dialog(join_timeout=1.0)
				self.resolve_dialog_made = False
				self._abort_plugin_resolve()
				self._end_sources_cancel()
				return
			elif action == 'play':
				kodi_utils.clear_property(PROP_RESOLVE_CANCEL)
				self._log_nextep_resolve_diag(chosen_item, phase='pick')
				self.play_file(results, chosen_item)
				return
			elif self.prescrape and action == 'perform_full_search':
				self._kill_progress_dialog(join_timeout=1.0)
				if not self.progress_dialog and not self.background:
					self._make_progress_dialog()
				# Mirror empty-prescrape → full scrape: keep remove_scrapers and prescrape_sources
				# so cloud scrapers stay finished and progress shows external/cache only.
				self.prescrape = False
				self.clear_properties = True
				self.filters_ignored = self.ignore_scrape_filters
				self.sources, self.orig_results = [], []
				self.threads, self.providers, self.prescrape_scrapers, self.prescrape_threads = [], [], [], []
				self.uncached_results, self.cloud_scraper_names = [], []
				self.active_folders, self.folder_info = False, []
				self.internal_scraper_names, self.resolve_dialog_made = [], False
				if not self.ignore_scrape_filters: kodi_utils.clear_property('fs_filterless_search')
				self._prepare_external_only_followup()
				return self.get_sources()
			elif action == 'cache_change_rescrape':
				self.cache_check_override = chosen_item == 'true'
				self._reset_scrape_state(keep_disabled_ext_ignored=True)
				return self.get_sources()

	def _get_active_scraper_names(self, scraper_list):
		return [i[2] for i in scraper_list]

	def _prepare_external_only_followup(self):
		"""External torrent follow-up: skip re-scraping internals, use current filter/sort/priority settings."""
		self.autoplay = False
		self._refresh_results_settings()
		self._exclude_internal_scrapers_for_external_only_followup()

	def _refresh_results_settings(self):
		self.provider_sort_ranks = settings.provider_sort_ranks()
		self.sort_function = settings.results_sort_order()
		self.weight_size = settings.size_sort_weighted()
		self.quality_filter = self._quality_filter()
		self._refresh_group_boost_sort()

	def _exclude_internal_scrapers_for_external_only_followup(self):
		"""Run External Scraper Search: skip all non-external scrapers; keep prescrape results in memory."""
		self.determine_scrapers_status()
		for scraper in self.active_internal_scrapers:
			if scraper != 'external' and scraper not in self.remove_scrapers:
				self.remove_scrapers.append(scraper)

	def _reset_scrape_state(self, keep_disabled_ext_ignored=False):
		self.prescrape = False
		self.clear_properties = True
		self.filters_ignored = self.ignore_scrape_filters
		self.sources, self.prescrape_sources, self.orig_results = [], [], []
		self.threads, self.providers, self.prescrape_scrapers, self.prescrape_threads = [], [], [], []
		self.prescrape_ran_scrapers = set()
		self.remove_scrapers, self.uncached_results = ['external'], []
		self.active_folders, self.folder_info = False, []
		self.internal_scraper_names, self.resolve_dialog_made = [], False
		if 'autoplay' in self.params: self.autoplay = self.params.get('autoplay') == 'true'
		else: self.autoplay = settings.auto_play(self.media_type)
		self.cloud_prescrape_autoplay = False
		try: self.search_info['db_scrapers'] = []
		except Exception: pass
		self._db_first_applied = False
		if not keep_disabled_ext_ignored:
			self.disabled_ext_ignored = self.params.get('disabled_ext_ignored', 'false') == 'true'
		if not self.ignore_scrape_filters: kodi_utils.clear_property('fs_filterless_search')
		self.determine_scrapers_status()

	def _process_post_results(self):
		self._kill_progress_dialog(join_timeout=2.0)
		# Continual random: never Ask Rescrape Actions — skip to another episode.
		# (Background preps after the first pick also can't reliably show confirms.)
		if self.random_continual and self.media_type == 'episode' and self.tmdb_id:
			return self._random_continual_skip()
		if not self.retry_actions: return self._no_results()
		next_action, next_setting, order = self.retry_actions.pop(0)
		if next_action == 'cache_ignored':
			api_err = kodi_utils.get_property('nightshift.debrid_cache_api_error')
			if api_err:
				kodi_utils.clear_property('nightshift.debrid_cache_api_error')
				try:
					kodi_utils.logger('DebridCacheRetry', 'skipped=cache_ignored reason=api_%s' % api_err)
				except: pass
				if not self.background:
					kodi_utils.notification('AllDebrid cache check unavailable (%s). Showing unchecked sources.' % api_err, 6000)
				if self.orig_results:
					for item in self.orig_results:
						raw = item.get('cache_provider', '')
						if 'Uncached' in raw:
							provider = debrid.normalize_debrid_provider(item.get('debrid') or raw.replace('Uncached ', ''))
							item['cache_provider'] = provider
							item['debrid'] = provider
					results = self.process_results(self.orig_results)
					if results:
						if self.autoscrape: return results
						return self.play_source(results)
				return self._process_post_results()
			if next_setting in (1, 2) and self.active_external and self.orig_results and self._any_cache_check_active() \
																				and debrid.debrid_cache_check_available(self.debrid_enabled):
				try:
					kodi_utils.logger('DebridCacheRetry', 'action=cache_ignored auto=%s orig=%d playable=0' % (next_setting == 1, len(self.orig_results)))
				except: pass
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry with external cache check disabled?'):
					self.threads, self.prescrape, self.cache_check_override = [], False, False
					return self.get_sources()
			return self._process_post_results()
		if next_action == 'imdb_year':
			if next_setting in (1, 2) and self.active_external and not self.orig_results and not self.meta.get('custom_year'):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With IMDb Year Data?'):
					from apis.imdb_api import imdb_year_check
					imdb_year = str(imdb_year_check(self.meta.get('imdb_id')))
					if imdb_year != self.get_search_year():
						self.meta['custom_year'] = imdb_year
						self.make_search_info()
						self.threads, self.prescrape = [], False
						return self.get_sources()
			return self._process_post_results()
		if next_action == 'with_all':
			if next_setting in (1, 2) and self.active_external:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry including disabled external torrent providers?'):
					self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
					return self.get_sources()
			return self._process_post_results()
		if next_action == 'episode_group':
			if next_setting in (1, 2) and self.media_type == 'episode':
				if next_setting == 1 \
											or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Custom Episode Group if Possible?'):
					if self.episode_group_used:
						return self._process_post_results()
					if next_setting == 2:
						from indexers.dialogs import episode_groups_choice
						try: group_id = episode_groups_choice({'meta': self.meta, 'poster': self.meta['poster']})
						except: group_id = None
					else:
						try:
							group = metadata.preferred_episode_group(metadata.episode_groups(self.tmdb_id))
							group_id = group['id'] if group else None
						except: group_id = None
					if group_id:
						try: group_details = metadata.group_episode_data(metadata.group_details(group_id), None, self.season, self.episode)
						except: group_details = None
						if group_details:
							season, episode = group_details['season'], group_details['episode']
							self.params.update({'custom_season': season, 'custom_episode': episode, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (season, episode)})
							self.threads, self.prescrape = [], False
							return self.playback_prep()
			return self._process_post_results()
		if next_action == 'ignore_filters':
			if next_setting in (1, 2) and self.orig_results and not self.background:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results. Access Filtered Results?'):
					if self.autoplay: kodi_utils.notification('Filters Ignored & Autoplay Disabled')
					self.threads, self.ignore_scrape_filters, self.disabled_ext_ignored, self.autoplay = [], True, True, False
					return self.get_sources()
			return self._process_post_results()
		return self._process_post_results()

	def _close_progress_before_modal(self):
		self._kill_progress_dialog(join_timeout=3.0, close_overlays=False)
		kodi_utils.hide_busy_dialog()
		if self.progress_thread and self.progress_thread.is_alive():
			try:
				kodi_utils.close_dialog('sources_playback.xml')
				self.progress_thread.join(timeout=2.0)
			except:
				pass
		kodi_utils.sleep(400)

	def _show_modal_message(self, heading, text, background_notification=None):
		if self.background:
			return kodi_utils.notification(background_notification or text, 5000)
		try:
			return kodi_utils.kodi_dialog().ok(heading, text)
		except Exception:
			try:
				return kodi_utils.ok_dialog(heading=heading, text=text, ok_label='OK')
			except Exception:
				return kodi_utils.notification(text, 4000, settle_ms=400)

	def _external_cache_check_active(self, provider):
		provider = debrid.normalize_debrid_provider(provider)
		if not provider:
			return True
		if self.cache_check_override is not None:
			return self.cache_check_override
		return settings.debrid_cache_check(provider)

	def _playback_failed_default_message(self):
		reasons = ['expired', 'removed']
		item = getattr(self, 'playing_item', None) or {}
		if item.get('scrape_provider') in ('external',) + self.native_torrent_scrapers:
			provider = debrid.normalize_debrid_provider(item.get('debrid') or item.get('cache_provider'))
			if provider and not self._external_cache_check_active(provider):
				reasons.append('not cached on your debrid (cache check was off)')
		reasons.append('unsupported on this device')
		return 'This link could not be played. It may be %s, or %s.' % (', '.join(reasons[:-1]), reasons[-1])

	def _show_playback_failed_dialog(self, text=None):
		if self._playback_failed_notified:
			return
		self._playback_failed_notified = True
		self._abort_plugin_resolve()
		self._close_progress_before_modal()
		message = text or self._playback_failed_default_message()
		if self.autoplay or self.background:
			return kodi_utils.notification('Playback Failed', 4000, settle_ms=400)
		return self._show_modal_message('Playback failed', message)

	def _no_results(self):
		if self.random_continual and self.media_type == 'episode' and self.tmdb_id:
			return self._random_continual_skip()
		self._abort_plugin_resolve()
		self._close_progress_before_modal()
		return self._show_no_results()

	def _show_no_results(self):
		heading = self.meta.get('rootname', '') or self.meta.get('title', '') or 'NIGHTSHIFT'
		return self._show_modal_message(heading, 'No results found.', '[B]Next Up:[/B] No Results')

	def _random_continual_skip(self):
		"""Continual random: no links — try another (capped). Unsuccessful scrapes do not advance Still Watching."""
		from modules.episode_tools import EpisodeTools
		attempts = int(kodi_utils.get_property(PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS) or 0)
		self._close_progress_before_modal()
		if attempts >= RANDOM_CONTINUAL_MAX_SKIPS:
			kodi_utils.clear_property(PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS)
			return self._show_no_results()
		kodi_utils.set_property(PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS, str(attempts + 1))
		kodi_utils.logger('NIGHTSHIFT', 'Continual random play: no results for %s S%02dE%02d, skipping to another episode' % (
			self.meta.get('title', ''), self.meta.get('season', 0), self.meta.get('episode', 0)))
		meta = metadata.tvshow_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		# Undo Still Watching increment from this failed prep so only played episodes count.
		try:
			watch_count = int(self.meta.get('watch_count', self.watch_count or 1))
		except (TypeError, ValueError):
			watch_count = 1
		if watch_count > 1: watch_count -= 1
		meta['watch_count'] = watch_count
		return EpisodeTools(meta).play_random_continual(first_run=False, from_skip=True)

	def get_search_title(self):
		search_title = self.meta.get('custom_title', None) or self.meta.get('english_title') or self.meta.get('title')
		return search_title

	def get_search_year(self):
		year = self.meta.get('custom_year', None) or self.meta.get('year')
		return year

	def get_season(self):
		season = self.meta.get('custom_season', None) or self.meta.get('season')
		try: season = int(season)
		except: season = None
		return season

	def get_episode(self):
		episode = self.meta.get("custom_episode") or self.meta.get("episode")

		try:
			return int(episode)
		except (TypeError, ValueError):
			return None

	def get_ep_name(self):
		if self.meta.get("media_type") != "episode":
			return None

		ep_name = self.meta.get("ep_name")
		ep_name = remove_accents(ep_name)
		return safe_string(ep_name)

	def _resolve_episode_labels(self):
		'''Show title + S/E for debrid magnet resolve (must match play/search_info). Includes ep_name and absolute_episode.'''
		if hasattr(self, 'search_info') and self.search_info:
			si = self.search_info
			return (
				si.get('title'),
				si.get('season'),
				si.get('episode'),
				si.get('ep_name'),
				si.get('absolute_episode')
			)
		return (
			self.get_search_title(),
			self.get_season(),
			self.get_episode(),
			self.get_ep_name(),
			self.meta.get('absolute_episode')
		)

	def _wait_for_cloud_threads(self, timeout=None):
		"""Keep the scraper progress bar alive while parallel cloud threads finish after external."""
		if not self.threads:
			return
		if timeout is None:
			timeout = min(35, max(15, int(get_setting('nightshift.results.timeout', '20')) + 10))
			if any(t.name == 'nzb' for t in self.threads): timeout = max(timeout, NZB_WAIT_SECONDS)
		start_time, deadline = time.time(), time.time() + timeout
		while time.time() < deadline:
			if self._user_cancelled_scrape():
				break
			alive = [t.getName() for t in self.threads if t.is_alive()]
			self._poll_scraper_quality_counts()
			if self.progress_dialog and alive:
				try:
					elapsed = max(time.time() - start_time, 0)
					percent = min(99, int((elapsed / 25.0) * 100))
					line1 = ', '.join(alive).upper()
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, line1, percent)
				except:
					pass
			if not alive:
				break
			self._absorb_internal_properties()
			kodi_utils.sleep(100)
		self._join_internal_threads(max(0, deadline - time.time()))
		self._absorb_internal_properties()
		self._finalize_cloud_scraper_properties()

	def _cloud_scraper_names(self):
		names = set(self.cloud_scraper_names or [])
		names.update(i for i in self.remove_scrapers if i not in ('external',))
		for thread in self.threads:
			name = thread.getName()
			if name in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud'):
				names.add(name)
		return names

	def _finalize_cloud_scraper_properties(self):
		"""Mark cloud scrapers done when the thread exited without publishing a property."""
		for scraper in self._cloud_scraper_names():
			thread = next((t for t in self.threads if t.getName() == scraper), None)
			if thread and thread.is_alive():
				continue
			win_property = kodi_utils.get_property('nightshift.internal_results.%s' % scraper)
			if win_property in ('checked', '', None):
				kodi_utils.set_property('nightshift.internal_results.%s' % scraper, 'checked')

	def _poll_scraper_quality_counts(self):
		names = list(self.cloud_scraper_names or [])
		for thread in self.threads:
			name = thread.getName()
			if name and name not in names:
				names.append(name)
		for scraper in names:
			if scraper in self._quality_poll_scrapers:
				continue
			win_property = kodi_utils.get_property('nightshift.internal_results.%s' % scraper)
			if win_property in ('checked', '', None):
				continue
			try:
				sources = json.loads(win_property)
			except:
				continue
			self._quality_poll_scrapers.add(scraper)
			self._sources_quality_count(sources)

	def _join_internal_threads(self, timeout=30):
		"""Wait for cloud/internal threads; cap wait so a stuck scraper cannot block results forever."""
		deadline = time.time() + timeout
		for thread in self.threads:
			if self._user_cancelled_scrape():
				break
			remaining = deadline - time.time()
			if remaining <= 0:
				break
			try:
				thread.join(timeout=remaining)
			except:
				pass

	def _absorb_internal_properties(self):
		"""Merge internal scraper window properties into sources (cloud may finish after external dialog)."""
		scraper_names = set(self.internal_scraper_names)
		scraper_names.update(self._cloud_scraper_names())
		existing = {i.get('id') for i in self.sources if i.get('id')}
		for scraper in scraper_names:
			if scraper in ('external',): continue
			win_property = kodi_utils.get_property('nightshift.internal_results.%s' % scraper)
			if win_property in ('checked', '', None): continue
			try: internal_sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('nightshift.internal_results.%s' % scraper, 'checked')
			for item in internal_sources:
				item_id = item.get('id')
				if item_id and item_id in existing: continue
				if item_id: existing.add(item_id)
				self.sources.append(item)

	def _process_internal_results(self):
		for i in self.internal_scrapers:
			win_property = kodi_utils.get_property('nightshift.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('nightshift.internal_results.%s' % i, 'checked')
			self._sources_quality_count(sources)
	
	def _crt_feed(self, sources):
		"""Hand every newly found source to the scrape dialog's terminal as one line (dialog types it out)."""
		try:
			dialog = getattr(self, 'progress_dialog', None)
			add = getattr(dialog, 'add_result_lines', None)
			if not add: return
			seen = self.__dict__.setdefault('_crt_seen', set())
			lines = []
			for item in sources:
				key = item.get('id') or item.get('hash') or item.get('name')
				if key in seen: continue
				seen.add(key)
				lines.append((item.get('quality', 'SD'), item.get('scrape_provider') or item.get('provider') or '', item.get('size_label', 'N/A'),
							item.get('display_name') or item.get('name') or ''))
			if lines: add(lines)
		except: pass

	def _sources_quality_count(self, sources):
		self._crt_feed(sources)
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def _quality_filter(self):
		setting = 'results_quality_%s' % self.media_type if not self.autoplay else 'autoplay_quality_%s' % self.media_type
		filter_list = settings.quality_filter(setting)
		if self.include_prerelease_results and 'SD' in filter_list: filter_list += ['SCR', 'CAM', 'TELE']
		return filter_list

	def _get_size_rank(self, item):
		if self.weight_size: return item['size'] * 2 if 'HEVC' in item['extraInfo'] else item['size']
		else: return item['size']

	def _get_absolute_quality_rank(self, quality):
		return {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}.get(quality, 5)

	def _get_quality_rank(self, quality):
		'''Sort key from Quality Sort Order (1 = first). Prerelease always after SD/configured qualities.'''
		order = getattr(self, '_quality_rank_order', None)
		if not isinstance(order, (list, tuple)):
			order = settings.quality_sort_order()
			self._quality_rank_order = order
		if quality in ('SCR', 'CAM', 'TELE'): return len(order) + 1
		try: return order.index(quality) + 1
		except ValueError: return len(order) + 1

	def _get_provider_rank(self, account_type):
		rank = self.provider_sort_ranks.get(account_type)
		return 11 if rank is None else rank

	def _aiostreams_preserve_order(self):
		return settings.aiostreams_preserve_order()

	def _refresh_group_boost_sort(self):
		self._group_boost_active = settings.prefer_release_groups(self.autoplay)
		try: self._sort_order_index = int(get_setting('nightshift.results.sort_order', '1'))
		except: self._sort_order_index = 1

	def _results_sort_key(self, item):
		base = self.sort_function(item)
		if not getattr(self, '_group_boost_active', False): return base
		boost = -int(item.get('group_boost') or 0)
		a, b, c = base
		idx = getattr(self, '_sort_order_index', 1)
		if idx in (0, 1): return (a, boost, b, c)
		if idx in (2, 4): return (a, b, boost, c)
		return (a, b, c, boost)

	def _enrich_sort_fields(self, item):
		boost = release_group_boost(item) if getattr(self, '_group_boost_active', False) else 0
		return dict(item, **{
			'provider_rank': self._get_provider_rank(item['debrid'].lower()),
			'quality_rank': self._get_quality_rank(item.get('quality', 'SD')),
			'size_rank': self._get_size_rank(item),
			'group_boost': boost})

	def _split_aiostreams_preserve(self, results):
		if not self._aiostreams_preserve_order(): return [], results
		aio = sorted([i for i in results if i.get('scrape_provider') == 'aiostreams'], key=lambda k: k.get('aio_order', 999999))
		other = [i for i in results if i.get('scrape_provider') != 'aiostreams']
		return aio, other

	def _merge_aiostreams_at_provider_rank(self, sorted_other, aio_block):
		if not aio_block: return sorted_other
		if not sorted_other: return aio_block
		aio_rank = self._get_provider_rank('aiostreams')
		other_by_quality, aio_by_quality = {}, {}
		for item in sorted_other:
			other_by_quality.setdefault(item['quality_rank'], []).append(item)
		for item in aio_block:
			aio_by_quality.setdefault(item['quality_rank'], []).append(item)
		merged = []
		for quality_rank in sorted(set(other_by_quality) | set(aio_by_quality)):
			band = other_by_quality.get(quality_rank, [])
			aio_in_band = aio_by_quality.get(quality_rank, [])
			if not aio_in_band:
				merged.extend(band)
				continue
			if not band:
				merged.extend(aio_in_band)
				continue
			insert_at = len(band)
			for idx, item in enumerate(band):
				if item['provider_rank'] > aio_rank:
					insert_at = idx
					break
			merged.extend(band[:insert_at] + aio_in_band + band[insert_at:])
		return merged

	def _sort_folder_to_top(self, provider):
		if provider == 'folders': return 0
		else: return 1

	def _sort_uncached_results(self, results):
		keep_in_sort = []
		if settings.include_uncached_torbox():
			keep_in_sort.append('TorBox')
		if settings.include_uncached_offcloud():
			keep_in_sort.append('Offcloud')
		if settings.include_uncached_premiumize():
			keep_in_sort.append('Premiumize')
		if keep_in_sort:
			defer_uncached = [i for i in results if 'Uncached' in i.get('cache_provider', '') and not any(p in i.get('cache_provider', '') for p in keep_in_sort)]
			return _without(results, defer_uncached) + defer_uncached
		uncached = [i for i in results if 'Uncached' in i.get('cache_provider', '')]
		cached = _without(results, uncached)
		return cached + uncached

	def get_meta(self):
		if self.media_type == 'movie':
			self.meta = metadata.movie_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
			if not self.meta:
				kodi_utils.logger('NIGHTSHIFT', 'get_meta: movie meta unavailable tmdb=%s' % self.tmdb_id)
				self.meta = {'tmdb_id': self.tmdb_id, 'title': '', 'year': ''}
		else:
			self.meta = {}
			try:
				show_meta = metadata.tvshow_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
				if show_meta and not show_meta.get('blank_entry'):
					self.meta = dict(show_meta)
					episodes_data = metadata.episodes_meta(self.season, show_meta)
					episode_data = next((i for i in episodes_data if int(i.get('episode') or -1) == int(self.episode)), None)
					if episode_data:
						ep_thumb = episode_data.get('thumb', None) or show_meta.get('fanart') or ''
						self.meta.update({'season': episode_data['season'], 'episode': episode_data['episode'], 'premiered': episode_data['premiered'],
										'episode_type': episode_data.get('episode_type', ''), 'ep_name': episode_data['title'], 'ep_thumb': ep_thumb,
										'plot': episode_data['plot'], 'tvshow_plot': show_meta['plot'], 'playcount': self.playcount,
										'watch_count': self.watch_count, 'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
					else:
						if episodes_data: self.meta['episode_not_listed'] = True
						kodi_utils.logger('NIGHTSHIFT', 'get_meta: episode not found in season data tmdb=%s S%02dE%02d (rows=%d)' %
										(self.tmdb_id, self.season, self.episode, len(episodes_data)))
				else:
					kodi_utils.logger('NIGHTSHIFT', 'get_meta: tvshow meta blank/missing tmdb=%s' % self.tmdb_id)
					self.meta = dict(show_meta) if show_meta else {}
			except Exception as e:
				kodi_utils.logger('NIGHTSHIFT', 'get_meta episode exception: %s' % e)
				self.meta = {}
		self.meta.update({'media_type': self.media_type, 'background': self.background, 'custom_title': self.custom_title, 'custom_year': self.custom_year})

		# ADD THIS LOG
		try:
			kodi_utils.logger('GetMeta', 'DEBUG media_type=%s ep_name=%r season=%s episode=%s' % (
				self.media_type, self.meta.get('ep_name'), self.meta.get('season'), self.meta.get('episode')))
		except: pass

	def make_search_info(self):
		title, year, ep_name = self.get_search_title(), self.get_search_year(), self.get_ep_name()
		aliases = make_alias_dict(self.meta, title)
		try:
			from modules.source_utils import drop_fragment_aliases
			aliases = drop_fragment_aliases(title, aliases)
		except Exception: pass
		expiry_times = get_cache_expiry(self.media_type, self.meta, self.season)
		season, episode = self.get_season(), self.get_episode()
		absolute_episode = None
		if self.media_type == 'episode':
			absolute_episode = self.meta.get('absolute_episode')
			if not absolute_episode:
				absolute_episode = absolute_episode_from_season_data(self.meta.get('season_data'), season, episode)
				if absolute_episode:
					self.meta['absolute_episode'] = absolute_episode
		self.search_info = {'media_type': self.media_type, 'title': title, 'year': year, 'tmdb_id': self.tmdb_id, 'imdb_id': self.meta.get('imdb_id'), 'aliases': aliases,
							'season': season, 'episode': episode, 'tvdb_id': self.meta.get('tvdb_id'), 'ep_name': ep_name, 'expiry_times': expiry_times,
							'total_seasons': self.meta.get('total_seasons', 1), 'absolute_episode': absolute_episode,
							'total_aired_eps': self.meta.get('total_aired_eps', 1), 'season_episode_count': 1}
		try:
			if self.media_type == 'episode':
				from modules.source_utils import alt_season_episodes, register_alt_se
				_alts = alt_season_episodes(self.meta.get('season_data'), season, episode, absolute_episode)
				register_alt_se(season, episode, absolute_episode, _alts)
				self.search_info['alt_se'] = sorted(_alts)
		except Exception: pass
		self.search_info['live_search'] = getattr(self, 'live_search', False)
		# Unreleased movie/episode: force the same name gate "title filter" uses (see settings.filter_by_name).
		# Set on every scrape (true OR false) so a stale value from an earlier scrape can never leak into this one.
		try:
			from modules.source_utils import is_unreleased
			unreleased = is_unreleased(self.media_type, self.meta)
			kodi_utils.set_property('fs_unreleased_title_filter', 'true' if unreleased else 'false')
			self.search_info['unreleased'] = unreleased
			if unreleased: diag_log('Sources', 'unreleased title -> strict name filter forced on')
		except Exception:
			kodi_utils.set_property('fs_unreleased_title_filter', 'false')
		if self.media_type == 'episode':
			try:
				self.search_info['season_episode_count'] = [int(x['episode_count']) for x in (self.meta.get('season_data') or []) if int(x['season_number']) == int(season)][0]
			except Exception:
				self.search_info['season_episode_count'] = 1

		# ADD THIS LOG (safe, won't break if fails)
		try:
			kodi_utils.logger('SearchInfo', 'DEBUG tmdb=%s S%02dE%02d ep_name=%r abs=%s' % (
				self.tmdb_id, season, episode, ep_name, absolute_episode))
		except: pass

	def _get_module(self, module_type, function):
		if module_type == 'external': module = function.source(*self.external_args)
		elif module_type == 'folders': module = function[0](*function[1])
		else: module = function()
		return module

	def _clear_properties(self):
		def_internal = self.default_internal_scrapers + self.native_torrent_scrapers
		for item in def_internal: kodi_utils.clear_property('nightshift.internal_results.%s' % item)
		if self.active_folders:
			for item in self.folder_info: kodi_utils.clear_property('nightshift.internal_results.%s' % item[0])

	def _release_sources_busy(self):
		if kodi_utils.get_property(PROP_SOURCES_OWNER) == getattr(self, '_sources_busy_owner', ''):
			kodi_utils.clear_property(PROP_SOURCES_BUSY)
			kodi_utils.clear_property(PROP_SOURCES_OWNER)
			kodi_utils.clear_property(PROP_SOURCES_BUSY_AT)

	def _begin_sources_cancel(self):
		"""Mark cancel + drop the scrape lock so a second widget PlayMedia can start."""
		kodi_utils.set_property(PROP_SOURCES_CANCELING, 'true')
		self._release_sources_busy()

	def _end_sources_cancel(self):
		kodi_utils.clear_property(PROP_SOURCES_CANCELING)

	def _sources_still_owns_ui(self):
		"""True if no newer scrape has claimed the busy lock (safe to force-close overlays)."""
		owner = kodi_utils.get_property(PROP_SOURCES_OWNER)
		if not owner:
			return True
		return owner == getattr(self, '_sources_busy_owner', '')

	def _wait_sources_busy_clear(self, timeout=SOURCES_BUSY_WAIT_SECONDS):
		deadline = time.time() + max(0.0, float(timeout))
		while time.time() < deadline:
			if kodi_utils.get_property(PROP_SOURCES_BUSY) != 'true':
				return True
			self._clear_stale_sources_busy()
			if kodi_utils.get_property(PROP_SOURCES_BUSY) != 'true':
				return True
			kodi_utils.sleep(50)
		return kodi_utils.get_property(PROP_SOURCES_BUSY) != 'true'

	def _touch_sources_busy(self):
		if kodi_utils.get_property(PROP_SOURCES_BUSY) == 'true':
			kodi_utils.set_property(PROP_SOURCES_BUSY_AT, str(time.time()))

	def _release_resolve_busy(self):
		if kodi_utils.get_property(PROP_RESOLVE_OWNER) == getattr(self, '_resolve_busy_owner', ''):
			kodi_utils.clear_property(PROP_RESOLVE_BUSY)
			kodi_utils.clear_property(PROP_RESOLVE_OWNER)

	def _clear_stale_resolve_busy(self):
		if kodi_utils.get_property(PROP_RESOLVE_BUSY) != 'true':
			return False
		try:
			if kodi_utils.kodi_player().isPlayingVideo():
				return False
		except:
			pass
		if kodi_utils.get_property(PROP_PLAY_OPENING) == 'true':
			return False
		kodi_utils.clear_property(PROP_RESOLVE_BUSY)
		kodi_utils.clear_property(PROP_RESOLVE_OWNER)
		kodi_utils.clear_property(PROP_RESOLVE_CANCEL)
		return True

	def _clear_stale_sources_busy(self):
		def _clear():
			kodi_utils.clear_property(PROP_SOURCES_BUSY)
			kodi_utils.clear_property(PROP_SOURCES_OWNER)
			kodi_utils.clear_property(PROP_SOURCES_BUSY_AT)
		if kodi_utils.get_property(PROP_SOURCES_BUSY) != 'true':
			return False
		# Browse closes the results window under playback while get_sources may still be
		# waiting — clear so a new scrape is not blocked until restart.
		try:
			if kodi_utils.kodi_player().isPlayingVideo():
				_clear()
				return True
		except:
			pass
		# No playback and no recent heartbeat — the owning scrape is dead (killed invoker,
		# hung Browse wait, crash before release). Never require a Kodi restart.
		try: busy_at = float(kodi_utils.get_property(PROP_SOURCES_BUSY_AT) or 0)
		except: busy_at = 0
		if time.time() - busy_at > SOURCES_BUSY_STALE_SECONDS:
			try:
				age = ('%ss' % int(time.time() - busy_at)) if busy_at else 'none'
				kodi_utils.logger('NIGHTSHIFT', 'Cleared stale sources_busy lock (heartbeat age: %s)' % age)
			except:
				pass
			_clear()
			return True
		return False

	def _claim_resolve_busy(self):
		self._resolve_busy_owner = str(id(self))
		kodi_utils.set_property(PROP_RESOLVE_BUSY, 'true')
		kodi_utils.set_property(PROP_RESOLVE_OWNER, self._resolve_busy_owner)

	def _on_scrape_dialog_cancel(self):
		# Release busy immediately so a quick second widget is not toast-blocked. Overlay
		# force-close is owner-guarded so a newer scrape's windows are not torn down.
		self._scrape_user_cancelled = True
		self._begin_sources_cancel()

	def _on_resolve_dialog_cancel(self):
		self._resolve_user_cancelled = True
		self.cancel_all_playback = True
		kodi_utils.set_property(PROP_RESOLVE_CANCEL, 'true')

	def _user_cancelled_scrape(self):
		if getattr(self, '_scrape_user_cancelled', False):
			return True
		try:
			if self.progress_dialog and self.progress_dialog.iscanceled():
				return getattr(self.progress_dialog, 'window_mode', 'scraper') == 'scraper'
		except:
			pass
		return False

	def _finish_scrape_cancel(self):
		# Drop busy first (may already be clear from _on_scrape_dialog_cancel), then close
		# UI + answer PlayMedia. Owner-guarded force-close avoids killing a newer scrape.
		self._begin_sources_cancel()
		self._kill_progress_dialog(join_timeout=2.0)
		self._abort_plugin_resolve()
		self._end_sources_cancel()
		kodi_utils.hide_busy_dialog()

	def _ensure_progress_dialog_dead(self, join_timeout=2.0):
		thread = self.progress_thread
		if thread and thread.is_alive():
			try:
				if self.progress_dialog:
					self.progress_dialog.is_canceled = True
					self.progress_dialog.close()
			except:
				pass
			try:
				thread.join(timeout=join_timeout)
			except:
				pass
		self.progress_dialog, self.progress_thread = None, None

	def _reset_scrape_progress_counts(self):
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0

	def _make_progress_dialog(self):
		self._ensure_progress_dialog_dead()
		self._reset_scrape_progress_counts()
		kodi_utils.clear_scrape_progress_ui()
		kodi_utils.sync_scrape_progress_ui(0, 0, 0, 0, 0, 0)
		self.progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=self.meta, sources_ref=self)
		self.progress_thread = Thread(target=self.progress_dialog.run)
		self.progress_thread.start()
		for _ in range(40):
			try:
				if kodi_utils.get_property('nightshift.scrape.ready') == 'true':
					break
			except:
				pass
			kodi_utils.sleep(50)

	def _prepare_resolve_ui(self):
		try:
			if self.progress_dialog:
				self.progress_dialog.reset_is_cancelled()
				self.progress_dialog.enable_resolver()
				self.resolve_dialog_made = True
		except:
			pass

	def _make_resolve_dialog(self):
		self.resolve_dialog_made = True
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resolver()

	def _make_resume_dialog(self, percent):
		if not self.progress_dialog: self._make_progress_dialog()
		kodi_utils.hide_busy_dialog()
		self.progress_dialog.enable_resume(percent)
		for _ in range(150):
			choice = self.progress_dialog.resume_choice
			if choice is not None:
				return choice
			if self._user_cancelled_resolve() or self.progress_dialog.iscanceled():
				return 'cancel'
			kodi_utils.sleep(100)
		return self.progress_dialog.resume_choice or 'resume'

	def _make_still_watching_dialog(self, check_text, heading='Still Watching?', right_align=False):
		try: action = open_window(('windows.playback_notifications', 'StillWatching'), 'playback_notifications.xml', meta=self.meta, check_text=check_text,
			heading=heading, right_align='true' if right_align else 'false')
		except: action = False
		return action

	def _user_cancelled_resolve(self):
		if kodi_utils.get_property(PROP_RESOLVE_CANCEL) == 'true':
			return True
		if getattr(self, '_resolve_user_cancelled', False) or getattr(self, 'cancel_all_playback', False):
			return True
		try:
			if self.progress_dialog and self.progress_dialog.iscanceled():
				return self.progress_dialog.window_mode in ('resolver', 'resume')
		except:
			pass
		return False

	def _wait_for_player_open(self, max_ms=8000):
		try:
			player = kodi_utils.kodi_player()
			if kodi_utils.get_property(PROP_PLAY_OPENING) != 'true':
				try:
					if not player.isPlaying():
						return
					if player.isPlayingVideo():
						kodi_utils.sleep(300)
						return
				except:
					return
			for _ in range(max(1, max_ms // 100)):
				try:
					if player.isPlayingVideo():
						kodi_utils.sleep(300)
						return
				except:
					pass
				kodi_utils.sleep(100)
			kodi_utils.sleep(400)
		except:
			pass

	def _request_player_stop(self, light=False):
		try:
			player = kodi_utils.kodi_player()
			opening = kodi_utils.get_property(PROP_PLAY_OPENING) == 'true'
			if light or opening or (player.isPlaying() and not player.isPlayingVideo()):
				kodi_utils.execute_builtin('PlayerControl(Stop)', block=False)
				return
			if player.isPlayingVideo() or kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
				if player.isPlaying():
					player.stop()
				kodi_utils.sleep(150)
			elif player.isPlaying():
				kodi_utils.execute_builtin('PlayerControl(Stop)', block=False)
				kodi_utils.sleep(100)
		except:
			pass

	def _wait_player_idle(self, max_ms=8000, light=False):
		try:
			player = kodi_utils.kodi_player()
			stable_idle = 0
			for _ in range(max(1, max_ms // 100)):
				playing = False
				try:
					playing = player.isPlaying() or player.isPlayingVideo()
				except:
					pass
				if not playing:
					stable_idle += 1
					if stable_idle >= 3:
						kodi_utils.hide_busy_dialog()
						kodi_utils.sleep(200)
						return
				else:
					stable_idle = 0
					self._request_player_stop(light=True if light else (kodi_utils.get_property(PROP_PLAY_OPENING) == 'true' or not player.isPlayingVideo()))
				kodi_utils.sleep(100)
		except:
			pass

	def _stop_active_playback(self, wait_for_open=False, light=False):
		if wait_for_open:
			self._wait_for_player_open()
		self._wait_player_idle(light=light)

	def _ensure_play_headers(self, url, item):
		if not url or not isinstance(url, str) or '|' in url:
			return url
		try:
			debrid = (item.get('debrid') or item.get('cache_provider') or '').replace('.me', '')
			if debrid in ('Premiumize', 'pm_cloud'):
				return self.debrid_importer('Premiumize.me')().add_headers_to_url(url)
			if debrid in ('TorBox', 'tb_cloud'):
				return self.debrid_importer('TorBox')().add_headers_to_url(url)
		except:
			pass
		return url

	def _finish_resolve_cancel(self):
		close_nextep_handoff_cover()
		kodi_utils.clear_property(PROP_PLAY_OPENING)
		self._release_resolve_busy()
		kodi_utils.clear_property(PROP_RESOLVE_CANCEL)
		self._request_player_stop(light=True)
		self._kill_progress_dialog(join_timeout=0.5, resolve_cancel=True)
		self._abort_plugin_resolve()
		kodi_utils.hide_busy_dialog()

	def _force_close_sources_overlay_windows(self, retries=None):
		"""Explicitly dismiss scrape/resolve/results modals (Android can ignore Dialog.Close(all) over fullscreen)."""
		# A newer widget scrape may already own the busy lock — do not tear down its UI.
		if not self._sources_still_owns_ui():
			return
		if retries is None:
			retries = 6 if kodi_utils.is_android() else 3
		# extras.xml: Play from Extras used to leave it stacked over fullscreen video.
		dialogs = ('sources_playback.xml', 'sources_results.xml', 'nextep_handoff.xml', 'extras.xml')
		for _ in range(retries):
			if not self._sources_still_owns_ui():
				return
			for name in dialogs:
				try:
					kodi_utils.close_dialog(name)
				except:
					pass
			kodi_utils.hide_busy_dialog()
			try:
				if not any(kodi_utils.get_visibility('Window.IsVisible(%s)' % name) for name in dialogs):
					break
			except:
				break
			kodi_utils.sleep(120)
		else:
			if self._sources_still_owns_ui():
				try:
					kodi_utils.close_all_dialog()
				except:
					pass
		if kodi_utils.is_android():
			try:
				if kodi_utils.kodi_player().isPlayingVideo():
					kodi_utils.execute_builtin('ActivateWindow(fullscreenvideo)', block=False)
			except:
				pass

	def _kill_progress_dialog(self, join_timeout=3.0, resolve_cancel=False, close_overlays=True):
		# close_overlays=False: caller only needs the progress dialog gone while the sources
		# results window must stay alive (e.g. Browse opens a modal over it) — the overlay
		# force-close below also kills sources_results.xml.
		try:
			if self.progress_dialog:
				self.progress_dialog.is_canceled = True
				self.progress_dialog.close()
		except:
			pass
		thread = self.progress_thread
		if thread and thread.is_alive():
			try:
				thread.join(timeout=join_timeout)
			except:
				pass
			if (thread.is_alive() and close_overlays and not resolve_cancel
					and kodi_utils.get_property(PROP_RESOLVE_BUSY) != 'true'
					and self._sources_still_owns_ui()):
				try:
					kodi_utils.close_all_dialog()
				except:
					pass
		if close_overlays:
			self._force_close_sources_overlay_windows()
		self.progress_dialog, self.progress_thread = None, None
		kodi_utils.hide_busy_dialog()

	def _resolve_sources_wait(self, item, meta=None, poll_ms=50):
		if self._user_cancelled_resolve():
			return None
		result = [None]
		def _worker():
			try:
				result[0] = self.resolve_sources(item, meta)
			except:
				result[0] = None
		worker = Thread(target=_worker, daemon=True)
		worker.start()
		while worker.is_alive():
			if self._user_cancelled_resolve():
				return None
			kodi_utils.sleep(poll_ms)
		try:
			worker.join(timeout=0.5)
		except:
			pass
		if self._user_cancelled_resolve():
			return None
		return result[0]

	def _browse_transfer_id(self, debrid_provider, debrid_files):
		if not debrid_files:
			return None
		item = debrid_files[0]
		if item.get('torrent_id') not in (None, ''):
			return item.get('torrent_id')
		if item.get('request_id') not in (None, ''):
			return item.get('request_id')
		if debrid_provider == 'TorBox':
			link = str(item.get('link', ''))
			if ',' in link:
				return link.split(',')[0]
		return None

	def _cleanup_browse_transfer(self, debrid_provider, debrid_files, is_pack):
		'''Remove temporary browse transfers when Store Resolved to Cloud does not apply.'''
		if debrid_provider not in ('TorBox', 'Offcloud'):
			return
		if settings.store_resolved_to_cloud(debrid_provider, is_pack):
			return
		transfer_id = self._browse_transfer_id(debrid_provider, debrid_files)
		if not transfer_id:
			return
		api = self.debrid_importer(debrid_provider)()
		Thread(target=api.delete_torrent, args=(transfer_id,), daemon=True).start()

	def _cleanup_offcloud_resolved_url(self, item, url):
		'''After Offcloud magnet resolve: remove the request once playback is done/failed.

		Must not run during resolve — Offcloud play URLs are request-scoped (#160).
		'''
		if not url or not item:
			return
		try:
			raw = item.get('cache_provider') or item.get('debrid') or ''
			provider = debrid.normalize_debrid_provider(raw)
		except Exception:
			provider = ''
		if provider != 'Offcloud':
			return
		if settings.store_resolved_to_cloud('Offcloud', 'package' in item):
			return
		try:
			from apis.offcloud_api import OffcloudAPI
			request_id = item.pop('_offcloud_cleanup_request_id', None)
			if not request_id:
				return
			url_request_id = OffcloudAPI.request_id_from_download_url(url)
			if url_request_id and url_request_id != request_id:
				return
			api = OffcloudAPI()
			Thread(target=api.cleanup_resolved_request, args=(request_id,), daemon=True).start()
		except Exception:
			pass

	def _cleanup_rd_resolved_url(self, item, url):
		'''After Real-Debrid magnet resolve: remove Downloads history once playback is done/failed.

		Must not run during resolve — deleting Downloads can invalidate the unrestricted CDN URL.
		Temp torrent is already removed at resolve time (POV-style).
		'''
		if not url or not item:
			return
		try:
			raw = item.get('cache_provider') or item.get('debrid') or ''
			provider = debrid.normalize_debrid_provider(raw)
		except Exception:
			provider = ''
		if provider != 'Real-Debrid':
			return
		if settings.store_resolved_to_cloud('Real-Debrid', 'package' in item):
			return
		if 'download.real-debrid.com' not in str(url) and 'real-debrid.com' not in str(url):
			return
		try:
			from apis.real_debrid_api import RealDebridAPI
			api = RealDebridAPI()
			Thread(target=api.cleanup_resolved_download, args=(None, url), daemon=True).start()
		except Exception:
			pass

	def _resolve_browse_pick_link(self, debrid_info, debrid_provider, chosen_result):
		file_link = (chosen_result.get('link') or '').strip()
		if not file_link:
			return None
		if debrid_info == 'tb_browse':
			return self.resolve_internal(debrid_info, file_link, '')
		if file_link.startswith(('http://', 'https://')):
			api = self.debrid_importer(debrid_provider)()
			if debrid_info in ('pm_browse', 'oc_browse'):
				try:
					return api.add_headers_to_url(file_link)
				except:
					return file_link
			if debrid_info == 'rd_browse':
				try:
					url = api.unrestrict_link(file_link)
					if url:
						return url
				except:
					pass
				if 'real-debrid.com' in file_link or 'download.real-debrid.com' in file_link:
					return file_link
		return self.resolve_internal(debrid_info, file_link, '')

	def _resolve_browse_pack_fallback(self, source_item, debrid_provider):
		'''Manual file picker for a pack whose episode could not be auto-matched.

		###FIX### Rewritten. The old version (a) called `Premiumize()` on an already-built
		instance (TypeError: object is not callable), (b) treated select_dialog()'s return
		value (the chosen entry) as a list index, and (c) was invoked from the resolve worker
		thread and killed the resolver dialog, which play_file() read as the user cancelling.
		It now runs on the play_file thread only (see play_file / _pending_pack_browse).
		'''
		self._pack_picker_cancelled = False
		try:
			if not source_item:
				kodi_utils.logger('BrowseFallback', 'REJECT source_item=None')
				return None
			debrid_provider = debrid.normalize_debrid_provider(debrid_provider)
			debrid_info = {'Real-Debrid': 'rd_browse', 'Premiumize.me': 'pm_browse', 'AllDebrid': 'ad_browse', 'Offcloud': 'oc_browse', 'TorBox': 'tb_browse'}.get(debrid_provider)
			title, season, episode, ep_name, absolute_episode = self._resolve_episode_labels()
			kodi_utils.logger('BrowseFallback', 'START provider=%s title=%r season=%s episode=%s ep_name=%r abs=%s' % (
				debrid_provider, title, season, episode, ep_name, absolute_episode))

			source = {'url': source_item.get('url'), 'hash': source_item.get('hash'), 'name': source_item.get('name'),
					'debrid': debrid_provider, 'cache_provider': debrid_provider}
			debrid_files = debrid.ExternalPackSource(source).browse_packs(download=False)
			if not debrid_files:
				kodi_utils.logger('BrowseFallback', 'FAIL: browse_packs returned no files')
				return None

			self._close_progress_before_modal()
			list_items = [{'line1': '%.2f GB | %s' % (float(item['size'])/1073741824, clean_file_name(item['filename']).upper())} for item in debrid_files]
			picker_heading = 'Select File: %s S%02dE%02d' % (title or 'Unknown', int(season or 0), int(episode or 0))
			# select_dialog() returns the chosen ENTRY (or None), not an index
			chosen_result = kodi_utils.select_dialog(debrid_files, items=json.dumps(list_items), heading=picker_heading, enumerate='true', wide_window='true')
			if chosen_result is None:
				kodi_utils.logger('BrowseFallback', 'USER CANCELLED file selection')
				self._pack_picker_cancelled = True
				self._cleanup_browse_transfer(debrid_provider, debrid_files, is_pack=True)
				return None
			kodi_utils.logger('BrowseFallback', 'USER SELECTED: %s' % chosen_result.get('filename', ''))

			url = self._resolve_browse_pick_link(debrid_info, debrid_provider, chosen_result)
			kodi_utils.logger('BrowseFallback', 'RESULT provider=%s success=%s' % (debrid_provider, 'Y' if url else 'N'))
			if not url:
				kodi_utils.notification('Could not resolve selected file on %s' % debrid_provider, 4500)
				self._cleanup_browse_transfer(debrid_provider, debrid_files, is_pack=True)
				return None
			# The picker closed the resolver dialog: bring it back so play_file can carry on.
			if not self.background:
				self._make_progress_dialog()
				self._prepare_resolve_ui()
			return url
		except Exception as e:
			kodi_utils.logger('BrowseFallback', 'EXCEPTION provider=%s error=%s' % (debrid_provider, type(e).__name__))
			import traceback
			try:
				kodi_utils.logger('BrowseFallback', 'TRACEBACK: %s' % traceback.format_exc())
			except: pass
			return None

	def debridPacks(self, debrid_provider, name, magnet_url, info_hash, download=False, source_item=None):
		from modules.debrid import ExternalPackSource, normalize_debrid_provider
		debrid_provider = normalize_debrid_provider(debrid_provider)
		is_pack = bool(source_item and 'package' in source_item)
		source = {'url': magnet_url, 'hash': info_hash, 'debrid': debrid_provider, 'cache_provider': debrid_provider, 'name': name}
		pack_result = ExternalPackSource(source).browse_packs(download=download)
		if not pack_result:
			if download:
				return None
			# browse_packs() already notified; do not fall back to full magnet resolve/play.
			return None
		debrid_info = {'Real-Debrid': 'rd_browse', 'Premiumize.me': 'pm_browse', 'AllDebrid': 'ad_browse', 'Offcloud': 'oc_browse', 'TorBox': 'tb_browse'}.get(debrid_provider)
		if download:
			debrid_files, _pack_api = pack_result
			return debrid_files, self.debrid_importer(debrid_info)
		debrid_files = pack_result
		self._close_progress_before_modal()
		if is_pack and len(debrid_files) == 1:
			chosen_result = debrid_files[0]
		else:
			list_items = [{'line1': '%.2f GB | %s' % (float(item['size'])/1073741824, clean_file_name(item['filename']).upper())} for item in debrid_files]
			picker_heading = 'Browse: %s' % name
			kwargs = {'items': json.dumps(list_items), 'heading': picker_heading, 'enumerate': 'true', 'wide_window': 'true'}
			chosen_result = kodi_utils.select_dialog(debrid_files, **kwargs)
		if chosen_result is None:
			self._cleanup_browse_transfer(debrid_provider, debrid_files, is_pack=is_pack)
			return None
		link = self._resolve_browse_pick_link(debrid_info, debrid_provider, chosen_result)
		if not link and is_pack:
			link = self._resolve_browse_pack_fallback(source_item, debrid_provider)
		if not link:
			kodi_utils.notification('Could not resolve selected file on %s' % debrid_provider, 4500)
			self._cleanup_browse_transfer(debrid_provider, debrid_files, is_pack=is_pack)
			return None
		link = self._ensure_play_headers(link, {'debrid': debrid_provider, 'cache_provider': debrid_provider})
		self._close_progress_before_modal()
		player = self._play_browse_file(link, source_item or {'name': name}, os.path.basename(str(chosen_result.get('filename') or '').replace('\\', '/')))
		self._cleanup_browse_transfer(debrid_provider, debrid_files, is_pack=is_pack)
		return player


	def _track_browse_playback(self):
		"""Browse / Browse Pack plays through the plain player, which writes nothing to the watched database. Follow the playback
		here and, when it reaches the watched point, mark the episode (or movie) the results were searched for - the same marking a
		normal play does - so the list shows it as watched."""
		try:
			media_type = (self.media_type or self.meta.get('media_type') or '')
			tmdb_id = self.tmdb_id or self.meta.get('tmdb_id')
			if not tmdb_id or media_type not in ('movie', 'episode'): return
			params = {'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'title': self.meta.get('title') or '', 'year': self.meta.get('year') or '',
						'tvdb_id': self.meta.get('tvdb_id') or 0, 'from_playback': 'true'}
			if media_type == 'episode': params.update({'season': self.season, 'episode': self.episode})
		except Exception:
			return
		def _run():
			try:
				import xbmc
				player, monitor = xbmc.Player(), xbmc.Monitor()
				for _ in range(120):
					if player.isPlayingVideo() or monitor.abortRequested(): break
					monitor.waitForAbort(0.5)
				best = 0.0
				while player.isPlayingVideo() and not monitor.abortRequested():
					try:
						total = player.getTotalTime()
						if total > 60: best = max(best, player.getTime() * 100.0 / total)
					except Exception: pass
					monitor.waitForAbort(2)
				if best >= settings.playback_watched_percent():
					function = watched_status.mark_movie if media_type == 'movie' else watched_status.mark_episode
					function(params)
			except Exception as e:
				kodi_utils.logger('BrowsePlayback', 'could not mark watched: %s' % e)
		Thread(target=_run, daemon=True).start()

	def _play_browse_file(self, link, source_item, filename=''):
		"""Play a file picked in Browse / Browse Pack through the full player (watched history, resume position, intro / credits
		detection, next episode), the same as a result played from the list. Falls back to the plain player only when the search
		it came from has no show / movie behind it."""
		kodi_utils.set_property('nightshift.browse_playback', 'true')
		kodi_utils.set_property(PROP_BROWSE_RETURN_SOURCES, 'true')
		full = bool(self.tmdb_id and self.media_type in ('movie', 'episode') and self.meta)
		player = NightShiftPlayer()
		player._browse_results_window = getattr(self, '_sources_results_window', None)
		if full:
			item = dict(source_item or {})
			if filename: item['name'] = filename
			self.playback_successful, self.cancel_all_playback = None, False
			self._resolve_user_cancelled = False
			self._resolved_url_sent = False
			self.playing_filename = item.get('name') or filename or ''
			self.playing_item = self._playing_item = item
			percent = self.get_playback_percent()
			if percent is None:
				kodi_utils.clear_property('nightshift.browse_playback')
				kodi_utils.clear_property(PROP_BROWSE_RETURN_SOURCES)
				return None
			self.playback_percent = percent
			try: self._remember_play_origin(item)
			except Exception: pass
			player.run(link, self)
		else:
			player.run(link, 'video')
		kodi_utils.clear_property('nightshift.browse_playback')
		if not getattr(player, 'playback_successful', False):
			kodi_utils.clear_property(PROP_BROWSE_RETURN_SOURCES)
		elif not full:
			self._track_browse_playback()
		return player

	def _cloud_browse_files(self, source_item):
		"""[(label, size, resolve_fn)] for every video file of the cloud folder a cloud result came from; [] when unsupported."""
		exts = ('.mkv', '.mp4', '.avi', '.m4v', '.mov', '.wmv', '.ts', '.m2ts', '.webm', '.flv', '.mpg', '.mpeg')
		provider = source_item.get('scrape_provider') or source_item.get('source')
		folder_id = source_item.get('folder_id')
		files = []
		if provider == 'rd_cloud' and folder_id:
			from apis.real_debrid_api import RealDebridAPI
			api = RealDebridAPI()
			if source_item.get('cache_type') == 'download':
				return files
			info = api.user_cloud_info_check(folder_id) or {}
			selected = [i for i in (info.get('files') or []) if i.get('selected') == 1]
			links = info.get('links') or []
			for idx, entry in enumerate(selected):
				if idx >= len(links): break
				path = entry.get('path') or ''
				if not path.lower().endswith(exts): continue
				files.append((path.lstrip('/'), entry.get('bytes') or 0, links[idx]))
			def resolve(link):
				return api.unrestrict_link(link)
			return [(a, b, c, resolve) for a, b, c in files]
		if provider == 'tb_cloud' and folder_id is not None:
			from apis.torbox_api import TorBoxAPI, TorBox
			media_type = source_item.get('cloud_media_type') or 'torrent'
			raw = TorBox.mylist_item_files(folder_id, media_type, fresh=True, allow_live_fallback=True, request_timeout=12) or []
			for entry in TorBoxAPI.filter_browse_cloud_files(raw, exts):
				fid = TorBoxAPI._torrent_file_id(entry)
				label = (entry.get('name') or TorBoxAPI._torrent_file_label(entry)).lstrip('/')
				files.append((label, entry.get('size') or 0, '%d,%d' % (int(folder_id), int(fid))))
			def resolve(item_id):
				return self.resolve_internal('tb_cloud', item_id, '', cloud_media_type=media_type)
			return [(a, b, c, resolve) for a, b, c in files]
		return files

	def browseCloudPack(self, source_item):
		"""Context menu 'Browse Pack' on a cloud result: list every video in that cloud folder and play the one picked."""
		try:
			files = self._cloud_browse_files(source_item)
		except Exception as e:
			diag_log('CloudBrowse', 'listing failed: %s' % e)
			files = []
		if not files:
			kodi_utils.notification('No other files found in this cloud item', 4000)
			return None
		files.sort(key=lambda f: f[0].lower())
		list_items = [{'line1': '%.2f GB | %s' % (float(f[1] or 0) / 1073741824, clean_file_name(f[0].rsplit('/', 1)[-1]).upper())} for f in files]
		self._close_progress_before_modal()
		chosen = kodi_utils.select_dialog(files, **{'items': json.dumps(list_items), 'heading': 'Browse: %s' % (source_item.get('name') or source_item.get('display_name') or ''),
			'enumerate': 'true', 'wide_window': 'true'})
		if chosen is None: return None
		link = chosen[3](chosen[2])
		if not link:
			kodi_utils.notification('Could not resolve selected file', 4500)
			return None
		link = self._ensure_play_headers(link, {'debrid': source_item.get('scrape_provider') or '', 'cache_provider': source_item.get('cache_provider') or ''})
		self._close_progress_before_modal()
		return self._play_browse_file(link, source_item, os.path.basename(str(chosen[0]).replace('\\', '/')))



	def play_file(self, results, source={}):
		# ###FIX### Removed the 'multi-season pack -> force browse UI' block that lived here: it ran a
		# throwaway browse_packs() network call, always took pack_files[0] (never the right episode),
		# stored it in an unused key, and called the undefined logger(). Packs are handled in
		# resolve_sources() (auto-match) with the manual picker as fallback.
		playable_results = [i for i in results if 'Uncached' not in i.get('cache_provider', '')]
		if not playable_results and not source:
			return self._no_results()
		if not self.background:
			self._prefetch_intro_segment_async()
		self._playback_failed_notified = False
		kodi_utils.clear_property(PROP_RESOLVE_CANCEL)
		self._resolved_url_sent = False
		self._claim_resolve_busy()
		url = None
		monitor = None
		try:
			self.playback_successful, self.cancel_all_playback = None, False
			self._resolve_user_cancelled = False
			defer_stop_for_nextep = getattr(self, '_nextep_alert_handled', False) or (self.background and (self.autoplay_nextep or self.autoscrape_nextep or self.play_type == 'random_continual' or self.random_continual))
			if not defer_stop_for_nextep:
				self._stop_active_playback()
			retry_easynews = settings.easynews_playback_method('retry')
			retry_easynews_limit = settings.easynews_playback_method_retries()
			kodi_utils.hide_busy_dialog()
			if not source: source = playable_results[0]
			self._log_nextep_resolve_diag(source, phase='play_start')
			items = [source]
			if not self.limit_resolve:
				source_index = playable_results.index(source)
				queue_tail = playable_results[source_index + 1:]
				queue_head = playable_results[:source_index]
				queue_head.reverse()
				items = [source] + queue_tail + queue_head
			processed_items = []
			processed_items_append = processed_items.append
			for count, item in enumerate(items, 1):
				resolve_item = dict(item)
				scrape_provider = item['scrape_provider']
				provider = scrape_provider
				if provider == 'external' or provider in self.native_torrent_scrapers: provider = item['debrid'].replace('.me', '')
				elif provider == 'folders': provider = item['source']
				elif provider == 'aiostreams': provider = item.get('aio_source_label') or provider
				elif provider == 'nzb': provider = 'NZB'
				provider_text = provider.upper()
				extra_info = '[B]%s[/B] | [B]%s[/B] | %s' %  (item['quality'], item['size_label'], item['extraInfo'])
				display_name = item['display_name'].upper()
				resolve_item['resolve_display'] = '%02d. [B]%s[/B][CR]%s[CR]%s' % (count, provider_text, extra_info, display_name)
				processed_items_append(resolve_item)
				# Native EN + AIOStreams EN badge rows share EasyNews Playback Method (Retry).
				en_retry = scrape_provider == 'easynews'
				if not en_retry and scrape_provider == 'aiostreams':
					try:
						from apis.aiostreams_api import is_direct_easynews_item
						en_retry = is_direct_easynews_item(item)
					except Exception:
						en_retry = False
				if en_retry and retry_easynews:
					for retry in range(1, retry_easynews_limit):
						resolve_item = dict(item)
						resolve_item['resolve_display'] = '%02d. [B]%s (RETRYx%s)[/B][CR]%s[CR]%s' % (count, provider_text, retry, extra_info, display_name)
						processed_items_append(resolve_item)
			items = list(processed_items)
			if not self.continue_resolve_check():
				self._kill_progress_dialog()
				return
			if defer_stop_for_nextep:
				if getattr(self, '_nextep_alert_handled', False) and not self.resolve_dialog_made:
					self._make_resolve_dialog()
				self._stop_active_playback(light=True)
			if not self.progress_dialog and not self.background:
				self._make_progress_dialog()
			if self._nextep_aio_en_fresh_start(source):
				self.playback_percent = 0.0
			else:
				self.playback_percent = self.get_playback_percent()
			if self.playback_percent == None:
				self._finish_resolve_cancel()
				return
			self._prepare_resolve_ui()
			if not self.resolve_dialog_made: self._make_resolve_dialog()
			if self.background: kodi_utils.sleep(1000)
			monitor = kodi_utils.kodi_monitor()
			for count, item in enumerate(items, 1):
				try:
					if self._resolve_user_cancelled or self.cancel_all_playback:
						break
					self._touch_sources_busy()
					kodi_utils.hide_busy_dialog()
					if not self.progress_dialog:
						if self._user_cancelled_resolve():
							self._resolve_user_cancelled = True
							self.cancel_all_playback = True
							break
						if not self.background:
							self._make_progress_dialog()
						if not self.progress_dialog:
							break
					if not self._user_cancelled_resolve():
						if count > 1:
							prev = items[count - 2]
							if prev.get('scrape_provider') != item.get('scrape_provider'):
								self.progress_dialog.reset_is_cancelled()
						else:
							self.progress_dialog.reset_is_cancelled()
					self.progress_dialog.update_resolver(text=item['resolve_display'])
					self.progress_dialog.busy_spinner()
					if count > 1:
						kodi_utils.sleep(200)
						try:
							del player
						except Exception:
							pass
					url, self.playback_successful = None, None
					self.playing_filename = item['name']
					self.playing_item = item
					player = NightShiftPlayer()
					try:
						if self._user_cancelled_resolve() or monitor.abortRequested():
							self._resolve_user_cancelled = True
							self.cancel_all_playback = True
							break
						self._pending_pack_browse = None
						url = self._resolve_sources_wait(item)
						if self._user_cancelled_resolve():
							self._resolve_user_cancelled = True
							self.cancel_all_playback = True
							break
						if self._resolve_user_cancelled or self.cancel_all_playback:
							break
						# ###FIX### Pack episode could not be auto-matched: show the manual file picker
						# HERE (play_file thread). Doing it inside the resolve worker closed the resolver
						# dialog while _resolve_sources_wait() was polling it, which looked like a user cancel.
						pending_pack = getattr(self, '_pending_pack_browse', None)
						if not url and pending_pack:
							self._pending_pack_browse = None
							pack_item = pending_pack.get('item') or {}
							url = self._resolve_browse_pack_fallback(
								{'url': pack_item.get('url'), 'hash': pack_item.get('hash'), 'name': pack_item.get('name'), 'package': True},
								pending_pack.get('provider'))
							if not url and getattr(self, '_pack_picker_cancelled', False):
								self._resolve_user_cancelled = True
								self.cancel_all_playback = True
								break
						if url:
							if self._user_cancelled_resolve():
								self._resolve_user_cancelled = True
								self.cancel_all_playback = True
								break
							resolve_percent = 0
							self.progress_dialog.busy_spinner('false')
							self.progress_dialog.update_resolver(percent=resolve_percent)
							kodi_utils.sleep(200)
							if self._user_cancelled_resolve():
								self._resolve_user_cancelled = True
								self.cancel_all_playback = True
								break
							kodi_utils.sleep(50)
							if self._user_cancelled_resolve():
								self._resolve_user_cancelled = True
								self.cancel_all_playback = True
								break
							url = self._ensure_play_headers(url, item)
							if self._user_cancelled_resolve():
								self._resolve_user_cancelled = True
								self.cancel_all_playback = True
								break
							if self._nextep_aio_en_fresh_start(item):
								self.playback_percent = 0.0
								self._stop_active_playback()
							elif self.background:
								self._wait_player_idle(max_ms=2000, light=True)
							self._remember_play_origin(item)
							self._playing_item = item
							player.run(url, self)
						else: continue
						if self.cancel_all_playback or self._resolve_user_cancelled:
							break
						if self.playback_successful: break
						# Next queued source — drop Kodi's native playback-failed confirm if it lingered.
						if count < len(items):
							try: kodi_utils.close_dialog('okdialog')
							except: pass
					except: pass
					finally:
						# Offcloud / RD: deferred cleanup after play/fail (must not invalidate play URL).
						self._cleanup_offcloud_resolved_url(item, url)
						self._cleanup_rd_resolved_url(item, url)
				except: pass
		except:
			self._kill_progress_dialog()
		else:
			if self.cancel_all_playback or self._resolve_user_cancelled:
				self._finish_resolve_cancel()
			elif not self.playback_successful or not url:
				kodi_utils.logger('NIGHTSHIFT', 'Resolve queue failed: success=%s url=%s dialog=%s' % (
					self.playback_successful, bool(url), bool(self.progress_dialog)))
				self.playback_failed_action()
		finally:
			if self.params.get('nextep_stash_play') == 'true':
				_set_nextep_stash_play_in_flight(False)
			self._release_resolve_busy()
			try: del monitor
			except: pass

	def get_playback_percent(self):
		if self.media_type == 'movie': percent = watched_status.get_progress_status_movie(watched_status.get_bookmarks_movie(), str(self.tmdb_id))
		elif any((self.random, self.random_continual)): return 0.0
		else: percent = watched_status.get_progress_status_episode(watched_status.get_bookmarks_episode(self.tmdb_id, self.season), self.episode)
		if not percent: return 0.0
		if self.cloud_prescrape_autoplay:
			if settings.auto_resume(self.media_type, True):
				return float(percent)
			return 0.0
		action = self.get_resume_status(percent)
		if action == 'cancel': return None
		if action == 'start_over':
			watched_status.erase_bookmark(self.media_type, self.tmdb_id, self.season, self.episode, from_playback=True)
			return 0.0
		return float(percent)

	def get_resume_status(self, percent):
		if settings.auto_resume(self.media_type, self.autoplay): return float(percent)
		choice = self._make_resume_dialog(percent)
		if self._user_cancelled_resolve() or choice in (None, 'cancel'):
			return 'cancel'
		if choice == 'start_over':
			return 'start_over'
		return float(percent)

	def playback_failed_action(self):
		if self._user_cancelled_resolve():
			return self._finish_resolve_cancel()
		if self.cloud_prescrape_autoplay:
			self._kill_progress_dialog(join_timeout=1.0)
			self.resolve_dialog_made = False
			fallback_sources = list(self.prescrape_sources) if self.prescrape_sources else list(getattr(self, '_last_cloud_autoplay_results', []) or [])
			if fallback_sources:
				self.prescrape = bool(self.prescrape_sources)
				results = self.process_results(fallback_sources)
				if results:
					self.cloud_prescrape_autoplay = False
					if self.autoplay and not self._effective_autoplay():
						self.autoplay = False
					return self.display_results(results)
			self.cloud_prescrape_autoplay = False
			if self.autoplay and not self._effective_autoplay():
				self.autoplay = False
			return self._show_playback_failed_dialog()
		if self.prescrape and self._effective_autoplay() and not self.prescrape_sources:
			# Prescrape found nothing — continue to the full scrape (e.g. external autoplay).
			self._kill_progress_dialog(join_timeout=1.0)
			self.resolve_dialog_made, self.prescrape, self.prescrape_sources = False, False, []
			return self.get_sources()
		if self.prescrape_sources:
			self._kill_progress_dialog(join_timeout=1.0)
			self.resolve_dialog_made = False
			results = self.process_results(list(self.prescrape_sources))
			if results:
				return self.display_results(results)
		if self.autoplay or self.background:
			return self._no_results()
		return self._show_playback_failed_dialog()

	def _log_nextep_scrape_started(self):
		try:
			kodi_utils.logger('NIGHTSHIFT', 'Next episode background scrape started: %s S%02dE%02d (%s)' % (
				self.meta.get('title'), self.meta.get('season'), self.meta.get('episode'), self.play_type))
		except: pass

	def _is_nextep_playback(self):
		play_type = getattr(self, 'play_type', '') or ''
		if play_type in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual'):
			return True
		if (getattr(self, 'params', None) or {}).get('nextep_stash_play') == 'true':
			return True
		if getattr(self, '_nextep_stash_results', None):
			return True
		if getattr(self, '_nextep_alert_handled', False):
			return True
		return False

	def _nextep_aio_en_fresh_start(self, item=None):
		if not self._is_nextep_playback():
			return False
		item = item or getattr(self, 'playing_item', None)
		if not item:
			return False
		try:
			from apis.aiostreams_api import is_direct_easynews_item
			return is_direct_easynews_item(item)
		except:
			return False

	def _nextep_resolve_diag_enabled(self):
		try:
			if self._is_nextep_playback():
				return True
			if getattr(self, 'background', False):
				return True
		except Exception:
			return False
		return False

	def _fmt_nextep_se(self, season, episode):
		try:
			if season in (None, '') or episode in (None, ''):
				return '-'
			return 'S%02dE%02d' % (int(season), int(episode))
		except:
			return 'S%sE%s' % (season, episode)

	def _nextep_resolve_url_id(self, url):
		if not url or not isinstance(url, str):
			return ''
		try:
			for part in url.split('/'):
				token = (part or '').split('?')[0]
				if len(token) >= 32 and '-' in token:
					return token[:36]
		except:
			pass
		return ''

	def _log_nextep_resolve_diag(self, item=None, phase='resolve', url=None, resolve_se=None):
		try:
			if not self._nextep_resolve_diag_enabled():
				return
		except Exception:
			return
		try:
			meta = getattr(self, 'meta', None) or {}
			si = getattr(self, 'search_info', None) or {}
			item = item or {}
			resolve_label = ''
			if resolve_se:
				resolve_label = self._fmt_nextep_se(resolve_se[0], resolve_se[1])
			kodi_utils.logger('NextEpResolve', '%s phase=%s play_type=%s background=%s autoplay=%s autoscrape=%s self=%s meta=%s custom=%s search_info=%s get=%s resolve=%s provider=%s hash=%s pack=%s name=%s url_id=%s' % (
				meta.get('title', ''),
				phase,
				getattr(self, 'play_type', '') or '',
				getattr(self, 'background', False),
				getattr(self, 'autoplay_nextep', False),
				getattr(self, 'autoscrape_nextep', False),
				self._fmt_nextep_se(getattr(self, 'season', ''), getattr(self, 'episode', '')),
				self._fmt_nextep_se(meta.get('season'), meta.get('episode')),
				self._fmt_nextep_se(meta.get('custom_season'), meta.get('custom_episode')),
				self._fmt_nextep_se(si.get('season'), si.get('episode')),
				self._fmt_nextep_se(self.get_season(), self.get_episode()),
				resolve_label,
				(item.get('debrid') or item.get('cache_provider') or '')[:24],
				(item.get('hash') or '')[:8],
				'package' in item,
				(item.get('display_name') or item.get('name') or '')[:72],
				self._nextep_resolve_url_id(url),
			))
		except: pass

	def _prefetch_intro_segment_async(self):
		if self.media_type != 'episode':
			return
		if not settings.skip_intro_enabled(self.play_type):
			return
		try:
			from threading import Thread
			from apis.intro_skip_api import prefetch_intro_segment, set_art
			set_art(self.meta)
			imdb_id = self.meta.get('imdb_id')
			Thread(target=prefetch_intro_segment, args=(self.tmdb_id, imdb_id, self.season, self.episode), kwargs={'tvdb_id': self.meta.get('tvdb_id'), 'title': self.meta.get('title')}, daemon=True).start()
		except: pass

	def _prefetch_nextep_segment_data(self):
		if self.media_type != 'episode':
			return
		try:
			from threading import Thread
			imdb_id = self.meta.get('imdb_id')
			tmdb_id = self.tmdb_id
			season, episode = self.season, self.episode
			self._prefetch_intro_segment_async()
			alert_key = 'autoplay_alert_timing' if self.play_type == 'autoplay_nextep' else 'autoscrape_alert_timing'
			if settings._alert_timing_mode(alert_key) == 'introdb':
				from apis.intro_skip_api import prefetch_credits_start
				Thread(target=prefetch_credits_start, args=(tmdb_id, imdb_id, season, episode), kwargs={'tvdb_id': self.meta.get('tvdb_id'), 'title': self.meta.get('title')}, daemon=True).start()
		except: pass

	def _playback_remaining_seconds(self, player, allow_stopped=False):
		try:
			if not allow_stopped and not player.isPlayingVideo(): return None
			return round(float(player.getTotalTime()) - float(player.getTime()))
		except:
			if not allow_stopped: return None
			try:
				prop = kodi_utils.get_property('nightshift.nextep_remaining')
				if prop: return int(prop)
			except: pass
			return None

	def _autoscrape_stop_notify_remaining(self, window_time):
		return max(int(window_time), settings.NEXTEP_STOP_NOTIFY_REMAINING_SEC)

	def _mark_autoscrape_nextep_ready(self):
		if getattr(self, '_autoscrape_ready_marked', False): return
		self._autoscrape_ready_marked = True
		payload = _store_handoff_meta(self.meta)
		try:
			kodi_utils.set_property(PROP_AUTOSCRAPE_NEXTEP_READY, json.dumps({
				'title': payload.get('title', ''),
				'season': payload.get('season', 0),
				'episode': payload.get('episode', 0),
				'poster': payload.get('poster', '') or '',
			}))
		except:
			kodi_utils.set_property(PROP_AUTOSCRAPE_NEXTEP_READY, 'true')
		arm_nextep_handoff_cover(self.meta)

	def _show_autoscrape_ready_notification(self):
		meta = {}
		try:
			raw = kodi_utils.get_property(PROP_AUTOSCRAPE_NEXTEP_READY)
			if raw and raw != 'true':
				meta = json.loads(raw)
		except:
			pass
		if not meta:
			meta = {'title': self.meta.get('title', ''), 'season': self.meta.get('season', 0),
				'episode': self.meta.get('episode', 0), 'poster': self.meta.get('poster', '') or ''}
		kodi_utils.clear_property(PROP_AUTOSCRAPE_NEXTEP_READY)
		kodi_utils.notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' \
				% (meta.get('title'), meta.get('season'), meta.get('episode')), 6500, meta.get('poster') or None)

	def _notify_autoscrape_ready(self, remaining, window_time):
		kodi_utils.logger('NIGHTSHIFT', 'Autoscrape next episode ready: %s S%02dE%02d remaining=%ss alert_window=%ss' % (
			self.meta.get('title'), self.meta.get('season'), self.meta.get('episode'), remaining, window_time))
		player = kodi_utils.kodi_player()
		if self._player_episode_active(player):
			self._mark_autoscrape_nextep_ready()
			return
		if getattr(self, '_autoscrape_ready_notified', False): return
		self._autoscrape_ready_notified = True
		self._mark_autoscrape_nextep_ready()
		self._show_autoscrape_ready_notification()

	def _wait_autoscrape_pop_window(self, player, window_time):
		tight = int(window_time)
		last_remaining = self._playback_remaining_seconds(player)
		while self._player_episode_active(player):
			last_remaining = self._playback_remaining_seconds(player)
			if last_remaining is None: break
			if last_remaining <= tight:
				return last_remaining, True
			kodi_utils.sleep(500)
		return last_remaining, False

	def _player_episode_active(self, player):
		try:
			return player.isPlayingVideo() or player.isPlaying()
		except:
			return False

	def _should_autoscrape_stop_notify(self, remaining, window_time):
		if remaining is None: return False
		return remaining <= self._autoscrape_stop_notify_remaining(window_time)

	def still_watching_check(self):
		watching_check = self.nextep_settings.get('watching_check', 0)
		if watching_check == 0: return True
		player = kodi_utils.kodi_player()
		# Don't prompt/count when nothing is playing (Autoplay idle + Continual Random cold-start skips).
		if not player.isPlayingVideo():
			return bool(self.background)
		watch_count = self.meta.get('watch_count')
		if watch_count is None:
			watch_count = getattr(self, 'watch_count', None) or 1
		try: watch_count = int(watch_count)
		except (TypeError, ValueError): watch_count = 1
		if watch_count == watching_check: still_watching, watch_count = self._make_still_watching_dialog('Are you still watching [B]%s[/B]?'), 0
		else: still_watching = True
		watch_count += 1
		self.meta['watch_count'] = watch_count
		return still_watching

	def _stash_nextep_autoplay_play(self, results):
		if not results:
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode scrape ready: no results for %s S%02dE%02d' % (
				self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')))
			self._decline_nextep_prep('no results')
			return
		if stash_nextep_autoplay_results(results, self.meta, self.nextep_settings, self.params):
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode scrape ready: %s S%02dE%02d (%s results)' % (
				self.meta.get('title'), self.meta.get('season'), self.meta.get('episode'), len(results)))
		else:
			kodi_utils.logger('NIGHTSHIFT', 'Autoplay next episode stash failed: %s S%02dE%02d' % (
				self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')))
			self._decline_nextep_prep('stash failed')

	def continue_resolve_check(self):
		try:
			if not self.background or self.autoscrape_nextep:
				return True
			if getattr(self, '_nextep_alert_handled', False):
				return True
			if self.play_type == 'random_continual':
				return self.random_continual_handler()
			return True
		except:
			return False

	def random_continual_handler(self):
		kodi_utils.notification('[B]Next Up:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
		player = kodi_utils.kodi_player()
		while self._player_episode_active(player): kodi_utils.sleep(100)
		self._make_resolve_dialog()
		return True

	def _decline_nextep_prep(self, reason):
		close_nextep_handoff_cover()
		try:
			player = kodi_utils.kodi_player()
			if isinstance(player, NightShiftPlayer):
				player.decline_nextep_prep(reason)
				return
		except: pass
		kodi_utils.set_property('nightshift.nextep_prep_declined', 'true')
		kodi_utils.logger('NIGHTSHIFT', 'Next episode prep declined: %s' % reason)

	def _autoscrape_playback_ended_naturally(self):
		natural = kodi_utils.get_property(PROP_NEXTEP_NATURAL_END)
		if natural == 'true':
			return True
		if natural == 'false':
			return False
		try:
			remaining = kodi_utils.get_property('nightshift.nextep_remaining')
			if remaining is not None:
				window = int((self.nextep_settings or {}).get('window_time', 0) or 0)
				threshold = max(_NEXTEP_NATURAL_END_SEC, self._autoscrape_stop_notify_remaining(window) if window else _NEXTEP_NATURAL_END_SEC)
				return int(remaining) <= threshold
		except:
			pass
		return False

	def autoscrape_nextep_handler(self):
		if settings.autoscrape_confirm():
			if not self._make_still_watching_dialog('Autoscrape Next Episode of [B]%s[/B]?', heading='Autoscrape Next Episode?', right_align=True):
				self._decline_nextep_prep('autoscrape confirm')
				return
		player = kodi_utils.kodi_player()
		if not self._player_episode_active(player):
			return
		results = self.get_sources()
		if nextep_handoff_cancelled():
			self._decline_nextep_prep('superseded')
			return
		if not results:
			kodi_utils.logger('NIGHTSHIFT', 'Autoscrape next episode: no results for %s S%02dE%02d' % (
				self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')))
			self._decline_nextep_prep('no results')
			return
		window_time = self.nextep_settings.get('window_time', 0) if self.nextep_settings else 0
		self._autoscrape_ready_notified = False
		self._autoscrape_ready_marked = False
		self._mark_autoscrape_nextep_ready()
		remaining = self._playback_remaining_seconds(player, allow_stopped=True)
		if not self._player_episode_active(player):
			if nextep_handoff_cancelled():
				self._decline_nextep_prep('superseded')
				return
			if not self._autoscrape_playback_ended_naturally():
				self._decline_nextep_prep('user stopped')
				return
			if self._should_autoscrape_stop_notify(remaining, window_time):
				self._notify_autoscrape_ready(remaining, window_time)
			else:
				kodi_utils.logger('NIGHTSHIFT', 'Autoscrape next episode ready (stopped during scrape): %s S%02dE%02d remaining=%ss alert_window=%ss' % (
					self.meta.get('title'), self.meta.get('season'), self.meta.get('episode'), remaining, window_time))
			show_nextep_handoff_cover(self.meta)
			return self._display_results_nextep_handoff(results)
		# Toast only in the alert window (same with or without Confirm) — Ready must mean
		# handoff is imminent, not merely that the background scrape finished.
		if remaining is not None and remaining <= int(window_time):
			self._notify_autoscrape_ready(remaining, window_time)
		else:
			remaining, should_notify = self._wait_autoscrape_pop_window(player, window_time)
			if should_notify:
				self._notify_autoscrape_ready(remaining, window_time)
		while self._player_episode_active(player):
			if nextep_handoff_cancelled():
				self._decline_nextep_prep('superseded')
				return
			kodi_utils.sleep(100)
		if nextep_handoff_cancelled():
			self._decline_nextep_prep('superseded')
			return
		if not self._autoscrape_playback_ended_naturally():
			self._decline_nextep_prep('user stopped')
			return
		show_nextep_handoff_cover(self.meta)
		if kodi_utils.get_property(PROP_AUTOSCRAPE_NEXTEP_READY) and kodi_utils.get_property(kodi_utils.PROP_AUTOSCRAPE_TOAST_SHOWN) != 'true':
			self._show_autoscrape_ready_notification()
		self._display_results_nextep_handoff(results)

	def _display_results_nextep_handoff(self, results):
		if nextep_handoff_cancelled():
			self._decline_nextep_prep('superseded')
			return
		if not self._autoscrape_playback_ended_naturally():
			self._decline_nextep_prep('user stopped')
			return
		# Leave background scrape mode, but keep Autoscrape nextep armed so the episode
		# the user picks from these results still monitors / preps the following episode.
		self.background = False
		self.autoscrape = False
		self.autoscrape_nextep = True
		self.play_type = 'autoscrape_nextep'
		# Same invoker as the episode that just ended: its PlayMedia handle was already
		# answered via setResolvedUrl. First pick must use Player.play() or resolve is a
		# noop and the queue only succeeds on the second source.
		self._use_player_play = True
		show_nextep_handoff_cover(self.meta)
		kodi_utils.close_dialog('notification')
		return self.display_results(results)

	def debrid_importer(self, debrid_provider):
		return manual_function_import(*self.debrids[debrid_provider])

	def _resolve_nzb_direct(self, item):
		"""Play an NZB straight from the user's Usenet provider (NNTP) through the NNTP Stream add-on.
		If this indexer's copy cannot be opened (removed, 429, error), the same release from the other indexers is tried
		in slot order before giving up."""
		try:
			from apis import usenet_stream
			self._nzb_episode_hint()
			name = item.get('name') or 'video.mkv'
			links = [item.get('nzb_link') or item.get('url_dl')]
			links += [a.get('link') for a in (item.get('nzb_alternates') or []) if a.get('link')]
			reason = ''
			for position, link in enumerate(l for l in links if l):
				if usenet_stream.verdict_dead(link):
					logger('ResolveNZB', 'direct Usenet copy %d skipped: judged dead lately' % (position + 1))
					reason = reason or 'this release is gone'
					continue
				if item.get('nzb_local_unpack'):
					local, reason = usenet_stream.unpack_local(link, name)
					if local:
						logger('ResolveNZB', 'unpacked to the local folder: %s' % local)
						return local
					logger('ResolveNZB', 'local unpack failed: %s' % reason)
					if 'cancel' in reason: return None
					continue
				local, reason = usenet_stream.open_stream(link, name)
				if not local and usenet_stream.unpack_ready() and 'packed in rar' in reason.lower():
					local, reason = usenet_stream.unpack_local(link, name)     # not known to be packed when listed (unchecked result)
					if local: return local
					if 'cancel' in reason: return None
				if not local and not usenet_stream.installed():
					logger('ResolveNZB', 'direct Usenet not available: %s' % reason)
					kodi_utils.notification('Direct Usenet: install the NNTP Stream add-on', 4000)
					return None
				if not reason:
					if position: logger('ResolveNZB', 'direct Usenet: copy %d (another indexer) opened after the first failed' % (position + 1))
					return local
				logger('ResolveNZB', 'direct Usenet copy %d failed: %s' % (position + 1, reason))
			kodi_utils.notification('Direct Usenet: %s' % reason, 5000)
			return None
		except Exception as e:
			logger('ResolveNZB', 'direct Usenet error: %s' % e)
			return None

	def resolve_sources(self, item, meta=None):
		try:
			logger('ResolveSources', 'DEBUG provider=%s media_type=%s hash=%s pack=%s title=%r season=%s episode=%s abs=%s' % (
				item.get('scrape_provider'), self.meta.get('media_type'),
				item.get('hash', '')[:20] if item.get('hash') else '',
				'package' in item, self.meta.get('title'), self.meta.get('season'), self.meta.get('episode'), self.meta.get('absolute_episode')))
			
			if self._user_cancelled_resolve():
				return None
			if meta is not None:
				self.meta = meta
			url = None
			pack = False
			scrape_provider = item.get('scrape_provider')
			
			try:
				if scrape_provider in self.default_internal_scrapers:
					if scrape_provider == 'aiostreams':
						from apis.aiostreams_api import resolve_playback_url
						url = resolve_playback_url(item)
					elif scrape_provider == 'nzb':
						url = self._resolve_nzb_direct(item) if item.get('nzb_direct') else None
						if not url and not (item.get('nzb_direct') and (settings.nzb_playback_mode() == '1' or not settings.authorized_debrid_check('tb'))):
							debrid_function = self.debrid_importer('tb_cloud')
							store_to_cloud = settings.store_resolved_to_cloud('TorBox', False)
							if self.meta['media_type'] == 'episode':
								labels = self._resolve_episode_labels()
								if isinstance(labels, (tuple, list)) and len(labels) >= 3:
									title = labels[0]
									season = labels[1]
									episode = labels[2]
								else:
									title = self.get_search_title()
									season, episode = self.get_season(), self.get_episode()
								logger('ResolveNZB', 'UNPACK provider=%s title=%r season=%s episode=%s' % (scrape_provider, title, season, episode))
							else:
								title, season, episode = self.get_search_title(), None, None
							url = debrid_function().resolve_nzb(item.get('nzb_link') or item.get('url_dl'), store_to_cloud, title, season, episode)
					else:
						url = self.resolve_internal(scrape_provider, item['id'], item['url_dl'], item.get('direct_debrid_link', False), item.get('cloud_media_type'))
				
				elif 'cache_provider' in item or item.get('debrid'):
					raw_cache = item.get('cache_provider', '')
					if str(raw_cache).startswith('Uncached '):
						logger('ResolveSources', 'UNCACHED provider=%s - returning None' % scrape_provider)
						return None
					cache_provider = debrid.normalize_debrid_provider(raw_cache or item.get('debrid'))
					
					if self.meta['media_type'] == 'episode':
						labels = self._resolve_episode_labels()
						if isinstance(labels, (tuple, list)) and len(labels) >= 3:
							title = labels[0]
							season = labels[1]
							episode = labels[2]
						else:
							title = self.get_search_title()
							season, episode = self.get_season(), self.get_episode()
						pack = 'package' in item
						logger('ResolveDebrid', 'DEBRID=%s TYPE=episode pack=%s title=%r season=%s episode=%s abs=%s' % (
							cache_provider, pack, title, season, episode, self.meta.get('absolute_episode')))
					else:
						title, season, episode = self.get_search_title(), None, None
						pack = False
					
					if cache_provider in ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'Offcloud', 'TorBox'):
						# ###FIX### Packs: auto-match the requested episode inside the pack first (same
						# path as single releases). The manual picker is only the fallback when nothing
						# matched confidently, and it is shown from play_file (not from this worker thread).
						is_episode_pack = bool(pack and self.meta.get('media_type') == 'episode')
						if is_episode_pack:
							logger('ResolveDebrid', 'PACK DETECTED - auto-matching S%s E%s abs=%s inside pack' % (
								season, episode, self.meta.get('absolute_episode')))
						# Pass full metadata for improved matching
						url = self.resolve_cached(cache_provider, item['url'], item['hash'], title, season, episode, pack, item,
						                        ep_name=self.meta.get('ep_name'),
						                        absolute_episode=self.meta.get('absolute_episode'),
						                        year=int(self.meta.get('year') or 0),
						                        aliases=self.meta.get('alternative_titles', []))
						logger('ResolveDebrid', 'RESOLVED url=%s pack=%s' % ('Y' if url else 'N', pack))
						if not url and is_episode_pack and not self.background and not self._user_cancelled_resolve():
							self._pending_pack_browse = {'item': item, 'provider': cache_provider}
							logger('ResolveDebrid', 'PACK AUTO-MATCH FAILED - deferring to manual file picker')
						
						try:
							self._log_nextep_resolve_diag(item, phase='resolved', url=url, resolve_se=(season, episode))
						except Exception:
							pass
				else:
					url = item['url']
				
			except Exception as e:
				logger('ResolveSources', 'EXCEPTION: %s - %s' % (type(e).__name__, str(e)))
			
			if self._user_cancelled_resolve():
				return None
			
			logger('ResolveSources', 'RESULT provider=%s media_type=%s final_url=%s pack=%s' % (
				scrape_provider, self.meta.get('media_type'), 'Y' if url else 'N', pack if self.meta.get('media_type') == 'episode' else 'N/A'))
			return url
			
		except Exception as e:
			logger('ResolveSources', 'TOP LEVEL EXCEPTION: %s - %s' % (type(e).__name__, str(e)))
			import traceback
			try:
				logger('ResolveSources', 'TRACEBACK: %s' % traceback.format_exc())
			except: pass
			return None

	def resolve_cached(self, debrid_provider, item_url, _hash, title, season, episode, pack, source_item=None,
	                   ep_name=None, absolute_episode=None, year=0, aliases=None):
		debrid_function = self.debrid_importer(debrid_provider)
		store_to_cloud = settings.store_resolved_to_cloud(debrid_provider, pack)
		
		try:
			api = debrid_function()
			
			if debrid_provider == 'Offcloud' and hasattr(api, 'resolve_magnet_with_cleanup'):
				result = api.resolve_magnet_with_cleanup(item_url, _hash, store_to_cloud, title, season, episode)
				if isinstance(result, (tuple, list)):
					url = result[0] if result else None
					if len(result) > 1 and source_item is not None:
						source_item['_offcloud_cleanup_request_id'] = result[1]
					elif source_item is not None:
						source_item.pop('_offcloud_cleanup_request_id', None)
				else:
					url = result
					if source_item is not None:
						source_item.pop('_offcard_cleanup_request_id', None)
			else:
				url = None
				# ###FIX### Only Premiumize's resolve_magnet() took ep_name / absolute_episode / year / aliases; passing
				# them to the others raised TypeError (swallowed below), so every Real-Debrid / AllDebrid / TorBox
				# pack failed to auto-match: autoplay died and the manual file picker opened. Packs are now matched
				# here with the same matcher the saved-pack lookup uses, and the extra arguments are only passed to
				# resolvers that accept them.
				if pack and season and debrid_provider != 'Premiumize.me':
					url = self._resolve_pack_episode(debrid_provider, item_url, _hash, title, season, episode, ep_name, absolute_episode)
				if not url:
					url = self._call_resolve_magnet(api, item_url, _hash, store_to_cloud, title, season, episode,
					                       ep_name=ep_name, absolute_episode=absolute_episode, year=year, aliases=aliases)
		except Exception as e:
			# ###FIX### was a bare `except: url = None` that hid every resolver crash
			import traceback
			kodi_utils.logger('ResolveCached', 'EXCEPTION provider=%s %s: %s | %s' % (
				debrid_provider, type(e).__name__, e, traceback.format_exc().replace('\n', ' | ')))
			url = None
		
		return url

	@staticmethod
	def _call_resolve_magnet(api, magnet_url, info_hash, store_to_cloud, title, season, episode, **extra):
		'''api.resolve_magnet() with the extra matching arguments only when its signature takes them.'''
		import inspect
		fn = api.resolve_magnet
		try:
			params = inspect.signature(fn).parameters
			if not any(p.kind == p.VAR_KEYWORD for p in params.values()):
				extra = {k: v for k, v in extra.items() if k in params}
		except (TypeError, ValueError):
			extra = {}
		return fn(magnet_url, info_hash, store_to_cloud, title, season, episode, **extra)

	def _resolve_pack_episode(self, debrid_provider, magnet_url, info_hash, title, season, episode, ep_name, absolute_episode):
		'''Pick the requested episode out of a debrid pack (pick_pack_episode_file: S#E#, absolute number, episode name)
		and resolve that file. None when nothing matches confidently (the caller then falls back / offers the picker).'''
		try:
			api = debrid.import_pack_api(debrid_provider)
			if not api: return None
			list_fn = getattr(api, 'parse_magnet_pack', None) or api.display_magnet_pack
			files = list_fn(magnet_url, info_hash)
			if not files:
				diag_log('PackResolve', '%s: pack listing empty' % debrid_provider)
				return None
			chosen, reason = pick_pack_episode_file(files, season, episode, absolute_episode=absolute_episode,
													ep_name=ep_name or '', title=title, label='Resolve-%s' % debrid_provider)
			if not chosen:
				diag_log('PackResolve', '%s: no confident match (%s)' % (debrid_provider, reason))
				return None
			debrid_info = {'Real-Debrid': 'rd_browse', 'Premiumize.me': 'pm_browse', 'AllDebrid': 'ad_browse', 'Offcloud': 'oc_browse', 'TorBox': 'tb_browse'}.get(debrid_provider)
			return self._resolve_browse_pick_link(debrid_info, debrid_provider, chosen)
		except Exception as e:
			kodi_utils.logger('PackResolve', 'EXCEPTION %s: %s' % (type(e).__name__, e))
			return None

	def resolve_internal(self, scrape_provider, item_id, url_dl, direct_debrid_link=False, cloud_media_type=None):
		url = None
		try:
			if direct_debrid_link or scrape_provider == 'folders': url = url_dl
			elif scrape_provider == 'easynews':
				from indexers.easynews import resolve_easynews
				url = resolve_easynews({'url_dl': url_dl, 'play': 'false'})
			else:
				debrid_function = self.debrid_importer(scrape_provider)
				if scrape_provider == 'tb_cloud':
					tb = debrid_function()
					media_type = cloud_media_type or 'torrent'
					if media_type == 'webdl':
						url = tb.unrestrict_webdl(item_id)
					elif media_type == 'usenet':
						url = tb.unrestrict_usenet(item_id)
					else:
						url = tb.unrestrict_link(item_id)
					url = tb.coerce_play_url(url) or url
				elif any(i in scrape_provider for i in ('rd_', 'ad_', 'tb_')):
					url = debrid_function().unrestrict_link(item_id)
				else:
					if '_cloud' in scrape_provider: item_id = debrid_function().get_item_details(item_id)['link']
					url = debrid_function().add_headers_to_url(item_id)
		except: pass
		return url

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in ('SD', 'CAM', 'TELE', 'SYNC')])

	def _quality_length_final(self, items, dummy):
		return len(items)



# ---------------------------------------------------------------------------------------------------------------
# My Services (debrid cloud, NZB, local folders): play a picked file with watched history, resume and intro / credits detection.
# The show is worked out from the folder and file name, then looked up on TMDb.
# ---------------------------------------------------------------------------------------------------------------
_BROWSE_YEAR_RE = re.compile(r'(?<![0-9])((?:19[3-9]|20[0-4])[0-9])(?![0-9])')
_BROWSE_STOP_RE = re.compile(r'(?:^|[\s._\-])(?:2160p|1080[pi]|720p|480p|4k|uhd|blu-?ray|bdrip|brrip|bdmv|web-?dl|web-?rip|hdtv|remux|x26[45]|h[.]?26[45]|hevc|avc|'
							 r'10bit|dual[ ._-]?audio|multi|complete|batch|seasons?[ ._-]*[0-9]+|s[0-9]{1,2}(?:e[0-9]{1,4})?|[0-9]{1,2}x[0-9]{2,3}|e(?:p|pisode)?[ ._-]*[0-9]{1,4})(?=$|[\s._\-])', re.I)


def _browse_clean(text):
	text = os.path.splitext(str(text or '').replace('\\', '/').rsplit('/', 1)[-1])[0] if re.search(r'[.](?:mkv|mp4|avi|m4v|mov|wmv|ts|m2ts|webm|flv|mpg|mpeg)$', str(text or ''), re.I) else str(text or '').replace('\\', '/').rstrip('/').rsplit('/', 1)[-1]
	text = re.sub(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}', ' ', text)
	text = text.replace('.', ' ').replace('_', ' ')
	year = _BROWSE_YEAR_RE.search(text)
	cut = len(text)
	for m in (_BROWSE_STOP_RE.search(' ' + text), year):
		if m:
			pos = max(0, m.start() - (1 if m is not year else 0))
			cut = min(cut, pos)
	title = re.sub(r'\s+', ' ', text[:cut]).strip(' -')
	return title, (int(year.group(1)) if year else None)


def _browse_norm(text):
	import unicodedata
	text = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode().lower().replace('&', ' and ')
	return re.sub(r'[^a-z0-9]+', ' ', text).strip()


def parse_browsed_name(name, folder=''):
	"""{'title', 'year', 'season', 'episode', 'is_episode', 'names': [...]} guessed from a file name and the folder it sits in."""
	from modules.source_utils import iter_season_episode_tokens
	leaf = str(name or '').replace('\\', '/').rsplit('/', 1)[-1]
	parents = [x for x in str(name or '').replace('\\', '/').split('/')[:-1] if x]
	folder_chain = parents[::-1] + [x for x in str(folder or '').replace('\\', '/').split('/') if x][::-1]
	season = episode = None
	for text in [leaf] + folder_chain:
		for s, e in iter_season_episode_tokens(text):
			season, episode = int(s), int(e)
			break
		if episode is not None: break
	folder_season = None
	for text in folder_chain:
		m = re.search(r'(?:^|[\s._\-\[(])(?:season|saison|staffel|s)[ ._-]*([0-9]{1,2})(?=$|[\s._\-\])])', text, re.I)
		if m:
			folder_season = int(m.group(1))
			break
	if episode is None:
		cleaned = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', os.path.splitext(leaf)[0]).replace('_', ' ')
		m = re.search(r'(?:^|[\s._\-])(?:e|ep|episode)[ ._-]*([0-9]{1,4})(?:v[0-9])?(?=$|[\s._\-])', cleaned, re.I) \
			or re.search(r'\s-\s*([0-9]{1,4})(?:v[0-9])?(?=$|[\s._\-])', cleaned)
		if m: episode = int(m.group(1))
		if episode is not None: season = folder_season
	title, year = _browse_clean(leaf)
	titles = []
	for candidate in [title] + [_browse_clean(x)[0] for x in folder_chain[:3]]:
		candidate = re.sub(r'^(?:season|saison|staffel|s)[ ._-]*[0-9]{1,2}$', '', candidate or '', flags=re.I).strip()
		if candidate and len(candidate) > 1 and candidate.lower() not in [t.lower() for t in titles]: titles.append(candidate)
	if year is None:
		for text in folder_chain[:3]:
			year = _browse_clean(text)[1]
			if year: break
	# a file named only by its number / episode title ('05.mkv'): the show title comes from the folder
	return {'titles': titles, 'year': year, 'season': season if season is not None else folder_season, 'episode': episode,
			'is_episode': episode is not None or folder_season is not None, 'leaf': leaf}


def _browse_tmdb_pick(media_type, titles, year):
	from difflib import SequenceMatcher
	from apis import tmdb_api
	search = tmdb_api.tmdb_tv_search if media_type == 'episode' else tmdb_api.tmdb_movies_search
	best, best_score = None, 0.0
	for title in titles[:3]:
		try: data = search(title.replace(' ', '+'), 1) or {}
		except Exception: data = {}
		results = data.get('results') if isinstance(data, dict) else None
		for item in (results or [])[:10]:
			names = [item.get('name') or item.get('title') or '', item.get('original_name') or item.get('original_title') or '']
			date = item.get('first_air_date') or item.get('release_date') or ''
			wanted = _browse_norm(title)
			score = max(SequenceMatcher(None, wanted, _browse_norm(n)).ratio() for n in names if n) if any(names) else 0.0
			if year and date[:4].isdigit() and abs(int(date[:4]) - int(year)) <= 1: score += 0.1
			if score > best_score: best, best_score = item.get('id'), score
	return best if best_score >= 0.75 else None


def match_browsed(name, folder=''):
	"""{'media_type', 'tmdb_id', 'season', 'episode'} for a file picked in My Services, or None when it cannot be matched."""
	info = parse_browsed_name(name, folder)
	if not info['titles']: return None
	media_type = 'episode' if info['is_episode'] else 'movie'
	tmdb_id = _browse_tmdb_pick(media_type, info['titles'], info['year'])
	if not tmdb_id and media_type == 'movie':        # no episode marks and no movie of that name: it may be a show episode named by its title
		media_type = 'episode'
		tmdb_id = _browse_tmdb_pick('episode', info['titles'], info['year'])
	if not tmdb_id: return None
	if media_type == 'movie': return {'media_type': 'movie', 'tmdb_id': str(tmdb_id), 'season': '', 'episode': ''}
	show = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	if not show or show.get('blank_entry'): return None
	season_data = [i for i in (show.get('season_data') or []) if int(i.get('season_number') or 0) > 0]
	season, episode = info['season'], info['episode']

	def _episodes(season_number):
		try: return metadata.episodes_meta(season_number, show) or []
		except Exception: return []
	if season is not None and episode is not None:
		if any(int(e.get('episode') or -1) == episode for e in _episodes(season)):
			return {'media_type': 'episode', 'tmdb_id': str(tmdb_id), 'season': str(season), 'episode': str(episode)}
	if episode is not None:
		# the release numbering is not TMDb's (S02E01 = TMDb S01E25) or the number is absolute: walk the seasons in order
		wanted_abs, count = episode, 0
		have = {int(i['season_number']): int(i.get('episode_count') or 0) for i in season_data}
		if season and season > 1 and season not in have:
			wanted_abs = sum(c for n, c in have.items() if n < season) + episode        # S02E01 of a release = the episode after TMDb's last of S01
		for item in sorted(season_data, key=lambda i: int(i.get('season_number') or 0)):
			size = int(item.get('episode_count') or 0)
			if wanted_abs <= count + size:
				return {'media_type': 'episode', 'tmdb_id': str(tmdb_id), 'season': str(int(item['season_number'])), 'episode': str(wanted_abs - count)}
			count += size
	# no usable numbers: the episode title in the file name
	leaf_norm = _browse_norm(os.path.splitext(info['leaf'])[0])
	candidates = [season] if season else [int(i['season_number']) for i in season_data]
	for season_number in candidates:
		for ep in _episodes(season_number):
			title = _browse_norm(ep.get('title'))
			if len(title) >= 6 and title in leaf_norm:
				return {'media_type': 'episode', 'tmdb_id': str(tmdb_id), 'season': str(ep.get('season')), 'episode': str(ep.get('episode'))}
	return None


def play_browsed(link, name, folder='', provider=''):
	"""Play a file picked in My Services. When the show can be worked out it plays through the full player (watched history and the
	watchlist provider, resume, intro / credits detection); otherwise through the plain player as before."""
	match = None
	try: match = match_browsed(name, folder)
	except Exception as e: kodi_utils.logger('BrowsePlay', 'match failed for %r: %s' % (name, e))
	if match:
		try:
			kodi_utils.logger('BrowsePlay', '%r in %r -> %s' % (name, folder, match))
			params = dict(match, background='false', play_type='', browse_only='true')
			source = Sources()
			source.playback_prep(params)
			item = {'name': os.path.basename(str(name or '')), 'scrape_provider': provider, 'source': provider, 'cache_provider': provider}
			if source.meta and source.tmdb_id:
				label = source.meta.get('title') or ''
				if match['media_type'] == 'episode': label = '%s S%02dE%02d' % (label, int(match['season']), int(match['episode']))
				kodi_utils.notification(label, 2500)
				return source._play_browse_file(link, item, item['name'])
		except Exception as e:
			kodi_utils.logger('BrowsePlay', 'full player not used (%s)' % e)
	player = NightShiftPlayer()
	return player.run(link, 'video')
