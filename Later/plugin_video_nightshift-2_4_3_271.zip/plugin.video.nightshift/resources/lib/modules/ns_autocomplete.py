# -*- coding: utf-8 -*-
"""Live title suggestions for the Nightshift search keyboard.

Uses TMDb's website search, one endpoint per search type: /search/multi, /search/movie, /search/tv, /search/person, /search/collection. No API key.

Header probe: TMDb may accept some request header sets and refuse others. On the first lookup the add-on
tries each header profile below against the same search, logs ACCEPTED or REJECTED for each, and uses the
first profile that returns JSON results. A profile that gets 403 is dropped and the next one is tried.
Successful results are cached in memory for the session; failures are not cached.
"""
import threading
import time

import xbmc

HOME_URL = 'https://www.themoviedb.org/'
SEARCH_BASE = 'https://www.themoviedb.org/search/%s'
SEARCH_URL = SEARCH_BASE % 'multi'
PROBE_QUERY = 'seraph'
PROBE_RETRY_SECONDS = 600

USER_FULL = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.themoviedb.org/",
    "Origin": "https://www.themoviedb.org",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}
_UA = USER_FULL["User-Agent"]

# (name, headers) - tried in this order
PROFILES = [
    ("user_full", USER_FULL),
    ("xhr_json", {
        "User-Agent": _UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
    }),
    ("xhr_json_origin", {
        "User-Agent": _UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
        "Origin": "https://www.themoviedb.org",
    }),
    ("chrome_doc_no_referer", {
        "User-Agent": _UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }),
    ("ua_only", {"User-Agent": "Mozilla/5.0"}),
    ("no_headers", {}),
]

TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 9

_cache = {}
_cache_order = []
_cache_lock = threading.Lock()
_state_lock = threading.Lock()
_chosen = {'name': None, 'headers': None}
_last_probe = [0.0]
_session = None


def _new_session(headers):
    """A fresh session that has loaded the TMDb homepage with `headers` (cookies)."""
    from modules.kodi_utils import make_session
    session = make_session('https://www.themoviedb.org')
    try:
        session.get(HOME_URL, headers=headers, timeout=TIMEOUT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] homepage warm-up failed: {exc}", xbmc.LOGWARNING)
    return session


def _try_profile(name, headers, query):
    """(accepted, reason) for one header profile against one search."""
    session = _new_session(headers)
    try:
        response = session.get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                               headers=headers, timeout=TIMEOUT)
    except Exception as exc:
        return False, f"request error: {exc}"
    code = response.status_code
    if code != 200:
        return False, f"HTTP {code}"
    try:
        data = response.json()
    except Exception:
        return False, "HTTP 200 but not JSON"
    if not isinstance(data, dict) or not isinstance(data.get('results'), list):
        return False, "HTTP 200 JSON without results"
    return True, f"HTTP 200 JSON, {len(data['results'])} results"


def probe_headers(query=PROBE_QUERY):
    """Try every profile, log ACCEPTED or REJECTED for each, and return the first accepted (name, headers)."""
    winner = None
    for name, headers in PROFILES:
        accepted, reason = _try_profile(name, headers, query)
        xbmc.log(f"[NIGHTSHIFT keyboard] header probe {name}: {'ACCEPTED' if accepted else 'REJECTED'} ({reason})",
                 xbmc.LOGINFO)
        if accepted and winner is None:
            winner = (name, headers)
            break
    if winner is None:
        xbmc.log("[NIGHTSHIFT keyboard] header probe: no header profile was accepted", xbmc.LOGWARNING)
    else:
        xbmc.log(f"[NIGHTSHIFT keyboard] header probe: using profile {winner[0]}", xbmc.LOGINFO)
    return winner


def _choose_profile():
    with _state_lock:
        if _chosen['headers'] is not None:
            return _chosen['name'], _chosen['headers']
        if time.time() - _last_probe[0] < PROBE_RETRY_SECONDS:
            return None
        _last_probe[0] = time.time()
    winner = probe_headers()
    if winner is None:
        return None
    with _state_lock:
        _chosen['name'], _chosen['headers'] = winner
    return winner


def _search(query, endpoint='multi'):
    """Raw TMDb search JSON from /search/<endpoint> (multi, movie, tv, person, collection).
    Raises if no profile is accepted or the request fails."""
    chosen = _choose_profile()
    if chosen is None:
        raise RuntimeError('no TMDb header profile accepted (see header probe log lines)')
    name, headers = chosen
    session = _new_session(headers)
    response = session.get(SEARCH_BASE % endpoint, params={'query': query, 'language': 'en-US'},
                           headers=headers, timeout=TIMEOUT)
    if response.status_code == 403:
        with _state_lock:
            _chosen['name'], _chosen['headers'] = None, None
            _last_probe[0] = 0.0
        raise RuntimeError(f"403 Client Error: Forbidden with profile {name}")
    response.raise_for_status()
    return response.json()


IMAGE_URL = 'https://image.tmdb.org/t/p/w1280%s'
MEDIA_LABEL = {'movie': 'Movie', 'tv': 'TV show', 'anime': 'Anime', 'person': 'Person', 'collection': 'Collection'}
ANIMATION_GENRE = 16

# What the person is searching for -> (kinds shown, anime filter, heading, TMDb search endpoint).
# anime filter: True = anime only, False = TV without anime, None = either.
# Endpoints: multi (keywords and every other search), movie, tv (TV and anime), person, collection.
ALL_KINDS = ('movie', 'tv', 'person')
ENDPOINT_KIND = {'movie': 'movie', 'tv': 'tv', 'person': 'person', 'collection': 'collection'}


def scope_for(media_type='', search_type='media_title'):
    """Suggestion scope for a search entry: (kinds, anime, heading, endpoint). Unknown searches use multi."""
    media_type, search_type = (media_type or ''), (search_type or 'media_title')
    if search_type == 'people':
        return ('person',), None, 'Search People', 'person'
    if search_type == 'tmdb_collection':
        return ('collection',), None, 'Search Collections', 'collection'
    if search_type == 'tmdb_keyword':
        return ALL_KINDS, None, 'Search Keywords', 'multi'
    if search_type == 'media_title':
        if media_type == 'movie':
            return ('movie',), None, 'Search Movies', 'movie'
        if media_type == 'tv_show':
            return ('tv',), False, 'Search TV Shows', 'tv'
        if media_type == 'anime':
            return ('tv',), True, 'Search Anime', 'tv'
        return ('tv',), None, 'Search TV Shows & Anime', 'tv'
    return ALL_KINDS, None, 'Search', 'multi'


def _image(path):
    return IMAGE_URL % path if isinstance(path, str) and path.startswith('/') else ''


def _is_anime(entry):
    """Best guess from the search result itself: a Japanese animation. The finished results list
    uses TMDb's anime keyword, which this search response does not carry, so this is only for suggestions."""
    genres = entry.get('genre_ids')
    japanese = entry.get('original_language') == 'ja' or 'JP' in (entry.get('origin_country') or [])
    if isinstance(genres, list):
        return ANIMATION_GENRE in genres and japanese
    return entry.get('original_language') == 'ja'


def items_from_search(data, default_kind=None):
    """Every movie, TV show, person and collection in a TMDb search response, in order, with artwork and year.
    /search/multi tags each result with media_type; /search/movie, /tv, /person and /collection do not, so
    `default_kind` names what that endpoint returns. Each item carries 'kind' and 'anime' for filtering."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    items = []
    for entry in results:
        if not isinstance(entry, dict):
            continue
        kind = entry.get('media_type') or default_kind
        if kind == 'movie':
            title, date = entry.get('title') or entry.get('original_title'), entry.get('release_date')
        elif kind == 'tv':
            title, date = entry.get('name') or entry.get('original_name'), entry.get('first_air_date')
        elif kind in ('person', 'collection'):
            title, date = entry.get('name') or entry.get('original_name'), None
        else:
            continue
        if not isinstance(title, str) or not title.strip():
            continue
        anime = kind == 'tv' and _is_anime(entry)
        items.append({
            'title': title.strip(),
            'kind': kind,
            'anime': anime,
            'media': MEDIA_LABEL['anime' if anime else kind],
            'year': date[:4] if isinstance(date, str) and date[:4].isdigit() else '',
            'backdrop': _image(entry.get('backdrop_path')),
        })
    return items


def filter_items(items, scope, limit=None):
    """Keep only what this search mode can open, drop repeated titles, stop at `limit`."""
    kinds, anime = scope[0], scope[1]
    out, seen = [], set()
    for item in items:
        if item['kind'] not in kinds:
            continue
        if anime is True and not item['anime']:
            continue
        if anime is False and item['anime']:
            continue
        key = item['title'].casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
        if limit and len(out) >= limit:
            break
    return out


def titles_from_search(data, limit=DEFAULT_LIMIT, scope=None):
    scope = scope or (ALL_KINDS, None, 'Search', 'multi')
    return [item['title'] for item in filter_items(items_from_search(data), scope, limit)]


def _remember(key, items):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = items
        while len(_cache_order) > CACHE_LIMIT:
            _cache.pop(_cache_order.pop(0), None)


def fetch_items(text, limit=DEFAULT_LIMIT, scope=None):
    """Up to `limit` result dicts (title, kind, media, year, backdrop) for `text`, limited to what `scope`
    (see scope_for) can open. The cache is per endpoint and holds the unfiltered response. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    scope = scope or (ALL_KINDS, None, 'Search', 'multi')
    endpoint = scope[3]
    key = '%s|%s' % (endpoint, query.casefold())
    with _cache_lock:
        cached = _cache.get(key)
    if cached is None:
        try:
            cached = items_from_search(_search(query, endpoint), ENDPOINT_KIND.get(endpoint))
        except Exception as exc:
            xbmc.log(f"[NIGHTSHIFT keyboard] suggestions failed for {query!r}: {exc}", xbmc.LOGWARNING)
            return []
        _remember(key, cached)
    return filter_items(cached, scope, limit)


def fetch_suggestions(text, limit=DEFAULT_LIMIT, scope=None):
    return [item['title'] for item in fetch_items(text, limit, scope)]
