# -*- coding: utf-8 -*-
"""Local anime title and id lookup.

Two optional datasets, each updated on its own:

* Anime Offline Database (titles, AniList, MAL, AniDB, and any ids in the source URLs)
* Kometa Anime-IDs (AniDB to TVDB, IMDb, TMDB, MAL, AniList)

A failed download or a file that does not validate leaves the previous copy in place.
Lookups read the local cache only.
"""
import json
import os
import re
import sqlite3
import time
import urllib.error
import urllib.request

OFFLINE_URL = 'https://github.com/cedya77/anime-offline-database/releases/download/latest/anime-offline-database.jsonl'
KOMETA_URL = 'https://raw.githubusercontent.com/Kometa-Team/Anime-IDs/master/anime_ids.json'
KOMETA_EDITS_URL = 'https://raw.githubusercontent.com/Kometa-Team/Anime-IDs/master/anime_id_edits.json'

OFFLINE_MIN = 1000
KOMETA_MIN = 100
DAY = 24 * 60 * 60

_SOURCE_RES = (
    ('anidb', re.compile(r'anidb\.net/anime/(\d+)', re.I)),
    ('anilist', re.compile(r'anilist\.co/anime/(\d+)', re.I)),
    ('mal', re.compile(r'myanimelist\.net/anime/(\d+)', re.I)),
    ('tvdb', re.compile(r'thetvdb\.com/(?:series|dereferrer/series)/(\d+)', re.I)),
    ('imdb', re.compile(r'imdb\.com/title/(tt\d+)', re.I)),
    ('tmdb_movie', re.compile(r'themoviedb\.org/movie/(\d+)', re.I)),
    ('tmdb_show', re.compile(r'themoviedb\.org/(?:tv|tvshow)/(\d+)', re.I)),
)

_INDEX = '''
CREATE TABLE offline (
  id INTEGER PRIMARY KEY,
  title TEXT,
  year INTEGER,
  kind TEXT,
  anidb INTEGER,
  anilist INTEGER,
  mal INTEGER,
  tvdb INTEGER,
  tmdb_show INTEGER,
  tmdb_movie INTEGER,
  imdb TEXT
);
CREATE TABLE titles (norm TEXT NOT NULL, anime_id INTEGER NOT NULL);
CREATE INDEX ix_titles ON titles(norm);
CREATE INDEX ix_off_anilist ON offline(anilist);
CREATE INDEX ix_off_mal ON offline(mal);
CREATE INDEX ix_off_anidb ON offline(anidb);
CREATE TABLE kometa (
  anidb INTEGER PRIMARY KEY,
  tvdb INTEGER,
  imdb TEXT,
  mal INTEGER,
  anilist INTEGER,
  tmdb_movie INTEGER,
  tmdb_show INTEGER
);
CREATE TABLE kometa_alt (
  kind TEXT NOT NULL,
  value TEXT NOT NULL,
  anidb INTEGER NOT NULL
);
CREATE INDEX ix_kalt ON kometa_alt(kind, value);
'''


def cache_dir():
    import watchvault as wv
    path = os.path.join(wv.data_dir(), 'anime')
    os.makedirs(path, exist_ok=True)
    return path


def _file(name):
    return os.path.join(cache_dir(), name)


def index_path():
    return _file('index.db')


def enabled(name):
    key = 'anime_offline' if name == 'offline' else 'anime_kometa'
    try:
        import xbmcaddon
        return bool(xbmcaddon.Addon().getSettingBool(key))
    except Exception:
        return True


def _meta():
    path = _file('meta.json')
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_meta(data):
    path = _file('meta.json')
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
    os.replace(tmp, path)


def _norm(title):
    text = re.sub(r'[^a-z0-9]+', ' ', (title or '').lower())
    return re.sub(r'\s+', ' ', text).strip()


def _ints(value):
    if value is None or value is False or value == '':
        return []
    if isinstance(value, int):
        return [value] if value else []
    return [int(part) for part in re.findall(r'\d+', str(value))]


def _imdbs(value):
    if not value:
        return []
    return re.findall(r'tt\d+', str(value), re.I)


def _source_ids(sources):
    found = {}
    for raw in sources or []:
        text = str(raw)
        for key, pattern in _SOURCE_RES:
            match = pattern.search(text)
            if match and key not in found:
                found[key] = match.group(1)
    return found


def _download(url, dest, previous):
    headers = {'User-Agent': 'WatchVault', 'Accept': 'application/json,*/*'}
    if previous.get('etag'):
        headers['If-None-Match'] = previous['etag']
    if previous.get('modified'):
        headers['If-Modified-Since'] = previous['modified']
    req = urllib.request.Request(url, headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=180)
    except urllib.error.HTTPError as exc:
        if exc.code == 304:
            return {'status': 'unchanged'}
        raise RuntimeError('download failed')
    try:
        tmp = dest + '.part'
        with resp, open(tmp, 'wb') as out:
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
        os.replace(tmp, dest)
        return {
            'status': 'ok',
            'etag': resp.headers.get('ETag') or '',
            'modified': resp.headers.get('Last-Modified') or '',
        }
    finally:
        resp.close()


def _iter_offline(path):
    with open(path, encoding='utf-8') as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
            except ValueError:
                raise ValueError('invalid offline dataset')
            if not isinstance(item, dict):
                raise ValueError('invalid offline dataset')
            if 'title' in item and isinstance(item.get('sources'), list):
                yield item


def _load_offline(con, path, minimum):
    rows = []
    titles = []
    count = 0
    next_id = 1
    for item in _iter_offline(path):
        ids = _source_ids(item.get('sources'))
        season = item.get('animeSeason') if isinstance(item.get('animeSeason'), dict) else {}
        try:
            year = int(season.get('year'))
        except (TypeError, ValueError):
            year = None
        anidb = int(ids['anidb']) if ids.get('anidb') else None
        anilist = int(ids['anilist']) if ids.get('anilist') else None
        mal = int(ids['mal']) if ids.get('mal') else None
        tvdb = int(ids['tvdb']) if ids.get('tvdb') else None
        tmdb_show = int(ids['tmdb_show']) if ids.get('tmdb_show') else None
        tmdb_movie = int(ids['tmdb_movie']) if ids.get('tmdb_movie') else None
        imdb = ids.get('imdb')
        rows.append((next_id, item.get('title'), year, item.get('type') or None,
                     anidb, anilist, mal, tvdb, tmdb_show, tmdb_movie, imdb))
        seen = set()
        for label in [item.get('title')] + list(item.get('synonyms') or []):
            norm = _norm(label)
            if norm and norm not in seen:
                seen.add(norm)
                titles.append((norm, next_id))
        next_id += 1
        count += 1
        if len(rows) >= 500:
            _flush_offline(con, rows, titles)
            rows = []
            titles = []
    _flush_offline(con, rows, titles)
    if count < minimum:
        raise ValueError('offline dataset is too small')
    return count


def _flush_offline(con, rows, titles):
    if rows:
        con.executemany(
            'INSERT INTO offline(id,title,year,kind,anidb,anilist,mal,tvdb,tmdb_show,tmdb_movie,imdb)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,?)', rows)
    if titles:
        con.executemany('INSERT INTO titles(norm,anime_id) VALUES(?,?)', titles)


def _load_kometa(con, path, edits_path, minimum):
    with open(path, encoding='utf-8') as handle:
        try:
            data = json.load(handle)
        except ValueError:
            raise ValueError('invalid kometa dataset')
    if not isinstance(data, dict):
        raise ValueError('invalid kometa dataset')
    edits = {}
    if edits_path and os.path.exists(edits_path):
        try:
            with open(edits_path, encoding='utf-8') as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                edits = loaded
        except (OSError, ValueError):
            edits = {}
    for key, patch in edits.items():
        if isinstance(patch, dict):
            row = dict(data.get(str(key)) or {})
            for field, value in patch.items():
                if value not in (None, ''):
                    row[field] = value
            data[str(key)] = row
    rows = []
    alts = []
    count = 0
    for key, item in data.items():
        if not isinstance(item, dict):
            continue
        anidb_nums = _ints(key)
        if not anidb_nums:
            continue
        anidb = anidb_nums[0]
        tvdb = _ints(item.get('tvdb_id'))
        mal = _ints(item.get('mal_id'))
        anilist = _ints(item.get('anilist_id'))
        movies = _ints(item.get('tmdb_movie_id'))
        shows = _ints(item.get('tmdb_show_id'))
        imdbs = _imdbs(item.get('imdb_id'))
        rows.append((anidb, tvdb[0] if tvdb else None, imdbs[0] if imdbs else None,
                     mal[0] if mal else None, anilist[0] if anilist else None,
                     movies[0] if movies else None, shows[0] if shows else None))
        alts.append(('anidb', str(anidb), anidb))
        for value in tvdb:
            alts.append(('tvdb', str(value), anidb))
        for value in mal:
            alts.append(('mal', str(value), anidb))
        for value in anilist:
            alts.append(('anilist', str(value), anidb))
        for value in movies:
            alts.append(('tmdb_movie', str(value), anidb))
        for value in shows:
            alts.append(('tmdb_show', str(value), anidb))
        for value in imdbs:
            alts.append(('imdb', value.lower(), anidb))
        count += 1
        if len(rows) >= 500:
            _flush_kometa(con, rows, alts)
            rows = []
            alts = []
    _flush_kometa(con, rows, alts)
    if count < minimum:
        raise ValueError('kometa dataset is too small')
    return count


def _flush_kometa(con, rows, alts):
    if rows:
        con.executemany(
            'INSERT OR REPLACE INTO kometa(anidb,tvdb,imdb,mal,anilist,tmdb_movie,tmdb_show)'
            ' VALUES(?,?,?,?,?,?,?)', rows)
    if alts:
        con.executemany('INSERT INTO kometa_alt(kind,value,anidb) VALUES(?,?,?)', alts)


def _write_index(offline_path, kometa_path, edits_path, offline_min, kometa_min):
    tmp = index_path() + '.tmp'
    if os.path.exists(tmp):
        os.remove(tmp)
    con = sqlite3.connect(tmp)
    counts = {'offline': 0, 'kometa': 0}
    try:
        con.execute('PRAGMA journal_mode=OFF')
        con.executescript(_INDEX)
        if offline_path and os.path.exists(offline_path):
            counts['offline'] = _load_offline(con, offline_path, offline_min)
        if kometa_path and os.path.exists(kometa_path):
            counts['kometa'] = _load_kometa(con, kometa_path, edits_path, kometa_min)
        con.commit()
    except Exception:
        con.close()
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    con.close()
    os.replace(tmp, index_path())
    return counts


def install(offline_text=None, kometa_obj=None, edits_obj=None):
    """Store fixture datasets and rebuild the local index. No network."""
    offline_path = _file('offline.jsonl') if offline_text is not None else (
        _file('offline.jsonl') if os.path.exists(_file('offline.jsonl')) else None)
    kometa_path = _file('kometa.json') if kometa_obj is not None else (
        _file('kometa.json') if os.path.exists(_file('kometa.json')) else None)
    edits_path = _file('kometa-edits.json') if edits_obj is not None else (
        _file('kometa-edits.json') if os.path.exists(_file('kometa-edits.json')) else None)
    if offline_text is not None:
        offline_path = _file('offline.jsonl')
        with open(offline_path, 'w', encoding='utf-8') as handle:
            handle.write(offline_text)
    if kometa_obj is not None:
        kometa_path = _file('kometa.json')
        with open(kometa_path, 'w', encoding='utf-8') as handle:
            json.dump(kometa_obj, handle)
    if edits_obj is not None:
        edits_path = _file('kometa-edits.json')
        with open(edits_path, 'w', encoding='utf-8') as handle:
            json.dump(edits_obj, handle)
    counts = _write_index(offline_path, kometa_path, edits_path, 1, 1)
    meta = _meta()
    now = time.time()
    if offline_text is not None:
        meta['offline'] = {'checked': now, 'entries': counts['offline'], 'etag': '', 'modified': ''}
    if kometa_obj is not None:
        meta['kometa'] = {'checked': now, 'entries': counts['kometa'], 'etag': '', 'modified': ''}
    _save_meta(meta)
    return counts


def _due(meta, name, force):
    if force:
        return True
    checked = (meta.get(name) or {}).get('checked') or 0
    return time.time() - float(checked) >= DAY


def _drop(path):
    try:
        os.remove(path)
    except OSError:
        pass


def update(force=False, fetch=None):
    """Download datasets that are due. One source failing does not touch the other."""
    fetch = fetch or _download
    meta = _meta()
    result = {}
    result['offline'] = _update_offline(meta, force, fetch)
    result['kometa'] = _update_kometa(meta, force, fetch)
    return result


def _update_offline(meta, force, fetch):
    if not enabled('offline'):
        return {'ok': True, 'skipped': True}
    if not _due(meta, 'offline', force):
        return {'ok': True, 'unchanged': True}
    tmp = _file('offline.jsonl.tmp')
    _drop(tmp)
    try:
        fetched = fetch(OFFLINE_URL, tmp, meta.get('offline') or {})
    except Exception:
        _drop(tmp)
        return {'ok': False, 'kept': True, 'error': 'download failed'}
    if fetched.get('status') == 'unchanged':
        slot = dict(meta.get('offline') or {})
        slot['checked'] = time.time()
        meta['offline'] = slot
        _save_meta(meta)
        return {'ok': True, 'unchanged': True}
    kometa_path = _file('kometa.json')
    edits_path = _file('kometa-edits.json')
    try:
        counts = _write_index(tmp, kometa_path if os.path.exists(kometa_path) else None,
                              edits_path if os.path.exists(edits_path) else None,
                              OFFLINE_MIN, 1 if os.path.exists(kometa_path) else 0)
    except Exception:
        _drop(tmp)
        return {'ok': False, 'kept': True, 'error': 'invalid'}
    os.replace(tmp, _file('offline.jsonl'))
    meta['offline'] = {
        'checked': time.time(), 'entries': counts['offline'],
        'etag': fetched.get('etag') or '', 'modified': fetched.get('modified') or '',
    }
    _save_meta(meta)
    return {'ok': True, 'entries': counts['offline']}


def _update_kometa(meta, force, fetch):
    if not enabled('kometa'):
        return {'ok': True, 'skipped': True}
    if not _due(meta, 'kometa', force):
        return {'ok': True, 'unchanged': True}
    tmp = _file('kometa.json.tmp')
    edits_tmp = _file('kometa-edits.json.tmp')
    _drop(tmp)
    _drop(edits_tmp)
    try:
        fetched = fetch(KOMETA_URL, tmp, meta.get('kometa') or {})
    except Exception:
        _drop(tmp)
        return {'ok': False, 'kept': True, 'error': 'download failed'}
    edits_fetched = {'status': 'missing'}
    try:
        edits_fetched = fetch(KOMETA_EDITS_URL, edits_tmp, meta.get('kometa_edits') or {})
    except Exception:
        _drop(edits_tmp)
        edits_fetched = {'status': 'kept'}
    ids_unchanged = fetched.get('status') == 'unchanged'
    edits_unchanged = edits_fetched.get('status') in ('unchanged', 'missing', 'kept')
    if ids_unchanged and edits_fetched.get('status') == 'unchanged':
        slot = dict(meta.get('kometa') or {})
        slot['checked'] = time.time()
        meta['kometa'] = slot
        _save_meta(meta)
        return {'ok': True, 'unchanged': True}
    ids_path = _file('kometa.json') if ids_unchanged else tmp
    if ids_unchanged and not os.path.exists(ids_path):
        return {'ok': False, 'kept': True, 'error': 'download failed'}
    if edits_fetched.get('status') == 'ok':
        edits_path = edits_tmp
    elif os.path.exists(_file('kometa-edits.json')):
        edits_path = _file('kometa-edits.json')
    else:
        edits_path = None
    offline_path = _file('offline.jsonl')
    try:
        counts = _write_index(
            offline_path if os.path.exists(offline_path) else None,
            ids_path, edits_path,
            1 if os.path.exists(offline_path) else 0,
            1 if ids_unchanged else KOMETA_MIN)
    except Exception:
        _drop(tmp)
        _drop(edits_tmp)
        return {'ok': False, 'kept': True, 'error': 'invalid'}
    if not ids_unchanged:
        os.replace(tmp, _file('kometa.json'))
    if edits_fetched.get('status') == 'ok':
        os.replace(edits_tmp, _file('kometa-edits.json'))
        meta['kometa_edits'] = {
            'checked': time.time(), 'etag': edits_fetched.get('etag') or '',
            'modified': edits_fetched.get('modified') or '',
        }
    meta['kometa'] = {
        'checked': time.time(), 'entries': counts['kometa'],
        'etag': (meta.get('kometa') or {}).get('etag') if ids_unchanged else (fetched.get('etag') or ''),
        'modified': (meta.get('kometa') or {}).get('modified') if ids_unchanged else (fetched.get('modified') or ''),
    }
    _save_meta(meta)
    result = {'ok': True, 'entries': counts['kometa']}
    if edits_fetched.get('status') == 'kept':
        result['edits_kept'] = True
    if edits_unchanged and ids_unchanged:
        result['unchanged'] = True
    return result


def _open():
    path = index_path()
    if not os.path.exists(path):
        return None
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    return con


def _same(left, right):
    if left is None or right is None:
        return True
    return str(left).lower() == str(right).lower()


def _alias(con, kind, left, right):
    if con is None:
        return False
    values = []
    for value in (left, right):
        text = str(value).lower() if kind == 'imdb' else str(value)
        if text not in values:
            values.append(text)
    if len(values) < 2:
        return True
    rows = list(con.execute(
        'SELECT anidb FROM kometa_alt WHERE kind=? AND value IN (?,?)',
        (kind, values[0], values[1])))
    counts = {}
    for row in rows:
        counts[row['anidb']] = counts.get(row['anidb'], 0) + 1
    return any(count >= 2 for count in counts.values())


def _compatible(found, given, con=None):
    kinds = (('tvdb_id', 'tvdb'), ('imdb_id', 'imdb'), ('tmdb_id', 'tmdb_show'),
             ('anilist_id', 'anilist'), ('mal_id', 'mal'))
    for key, kind in kinds:
        if given.get(key) and found.get(key) and not _same(given.get(key), found.get(key)):
            extra = 'tmdb_movie' if key == 'tmdb_id' else kind
            if _alias(con, kind, given.get(key), found.get(key)) or (
                    extra != kind and _alias(con, extra, given.get(key), found.get(key))):
                continue
            return False
    return True


def _pack(off, ko, movie):
    if off is None and ko is None:
        return None
    tmdb = None
    tmdb_source = None
    if movie:
        if ko and ko['tmdb_movie']:
            tmdb, tmdb_source = ko['tmdb_movie'], 'kometa'
        elif off and off['tmdb_movie']:
            tmdb, tmdb_source = off['tmdb_movie'], 'offline'
    else:
        if ko and ko['tmdb_show']:
            tmdb, tmdb_source = ko['tmdb_show'], 'kometa'
        elif off and off['tmdb_show']:
            tmdb, tmdb_source = off['tmdb_show'], 'offline'
    sources = {}

    def pick(off_key, ko_key, field):
        if ko and ko[ko_key]:
            sources[field] = 'kometa'
            return ko[ko_key]
        if off and off[off_key]:
            sources[field] = 'offline'
            return off[off_key]
        return None

    anidb = None
    if off and off['anidb']:
        anidb, sources['anidb_id'] = off['anidb'], 'offline'
    elif ko and ko['anidb']:
        anidb, sources['anidb_id'] = ko['anidb'], 'kometa'
    packed = {
        'title': off['title'] if off else None,
        'year': off['year'] if off else None,
        'anidb_id': anidb,
        'tvdb_id': pick('tvdb', 'tvdb', 'tvdb_id'),
        'imdb_id': pick('imdb', 'imdb', 'imdb_id'),
        'tmdb_id': tmdb,
        'anilist_id': pick('anilist', 'anilist', 'anilist_id'),
        'mal_id': pick('mal', 'mal', 'mal_id'),
    }
    if tmdb is not None and tmdb_source:
        sources['tmdb_id'] = tmdb_source
    if not any(packed.get(key) for key in ('tvdb_id', 'imdb_id', 'tmdb_id', 'anilist_id', 'mal_id', 'anidb_id', 'title')):
        return None
    packed['sources'] = sources
    return packed


def _kometa_row(con, anidb):
    if not anidb:
        return None
    return con.execute('SELECT * FROM kometa WHERE anidb=?', (int(anidb),)).fetchone()


def _offline_by(con, column, value):
    if value is None:
        return None
    return con.execute('SELECT * FROM offline WHERE %s=? LIMIT 1' % column, (value,)).fetchone()


def _join(con, off, use_kometa):
    ko = _kometa_row(con, off['anidb']) if use_kometa and off and off['anidb'] else None
    return off, ko


def resolve(title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
            anilist_id=None, mal_id=None, anidb_id=None, movie=False,
            use_offline=None, use_kometa=None):
    """Match a title or any known id against the local cache. No network."""
    use_offline = enabled('offline') if use_offline is None else bool(use_offline)
    use_kometa = enabled('kometa') if use_kometa is None else bool(use_kometa)
    if not use_offline and not use_kometa:
        return None
    con = _open()
    if con is None:
        return None
    try:
        given = {
            'tvdb_id': int(tvdb_id) if _ints(tvdb_id) else None,
            'imdb_id': (_imdbs(imdb_id) or [None])[0],
            'tmdb_id': int(tmdb_id) if _ints(tmdb_id) else None,
            'anilist_id': int(anilist_id) if _ints(anilist_id) else None,
            'mal_id': int(mal_id) if _ints(mal_id) else None,
        }
        anidb = int(anidb_id) if _ints(anidb_id) else None
        found = _resolve_ids(con, given, anidb, movie, use_offline, use_kometa)
        if found:
            return found
        if any(given.values()) or anidb:
            return None
        if not title or not use_offline:
            return None
        return _resolve_title(con, title, year, movie, use_kometa, given)
    finally:
        con.close()


def _resolve_ids(con, given, anidb, movie, use_offline, use_kometa):
    if use_offline:
        off = None
        if given.get('anilist_id'):
            off = _offline_by(con, 'anilist', given['anilist_id'])
        if off is None and given.get('mal_id'):
            off = _offline_by(con, 'mal', given['mal_id'])
        if off is None and anidb:
            off = _offline_by(con, 'anidb', anidb)
        if off is None and given.get('tvdb_id'):
            off = _offline_by(con, 'tvdb', given['tvdb_id'])
        if off is None and given.get('imdb_id'):
            off = con.execute('SELECT * FROM offline WHERE lower(imdb)=? LIMIT 1',
                              (given['imdb_id'].lower(),)).fetchone()
        if off is None and given.get('tmdb_id'):
            column = 'tmdb_movie' if movie else 'tmdb_show'
            off = _offline_by(con, column, given['tmdb_id'])
            if off is None:
                off = _offline_by(con, 'tmdb_movie' if column == 'tmdb_show' else 'tmdb_show', given['tmdb_id'])
        if off is not None:
            packed = _pack(*_join(con, off, use_kometa), movie)
            if packed and _compatible(packed, given, con):
                return packed
    if use_kometa:
        ko = None
        if anidb:
            ko = _kometa_row(con, anidb)
        for kind, value in (
                ('anilist', given.get('anilist_id')),
                ('mal', given.get('mal_id')),
                ('tvdb', given.get('tvdb_id')),
                ('imdb', given.get('imdb_id').lower() if given.get('imdb_id') else None),
                ('tmdb_show', None if movie else given.get('tmdb_id')),
                ('tmdb_movie', given.get('tmdb_id') if movie else given.get('tmdb_id'))):
            if ko is not None or value is None:
                continue
            alt = con.execute(
                'SELECT anidb FROM kometa_alt WHERE kind=? AND value=? LIMIT 1',
                (kind, str(value))).fetchone()
            if alt:
                ko = _kometa_row(con, alt['anidb'])
        if ko is not None:
            off = _offline_by(con, 'anidb', ko['anidb']) if use_offline else None
            packed = _pack(off, ko, movie)
            if packed and _compatible(packed, given, con):
                return packed
    return None


def _resolve_title(con, title, year, movie, use_kometa, given):
    norm = _norm(title)
    if len(norm) < 2:
        return None
    try:
        year = int(year) if year else None
    except (TypeError, ValueError):
        year = None
    rows = list(con.execute(
        'SELECT offline.* FROM titles JOIN offline ON offline.id=titles.anime_id WHERE titles.norm=?',
        (norm,)))
    if not rows:
        return None
    if year:
        dated = [row for row in rows if row['year'] == year]
        if not dated:
            return None
        rows = dated
    if movie:
        rows = [row for row in rows if row['kind'] == 'MOVIE']
    else:
        rows = [row for row in rows if row['kind'] != 'MOVIE']
    if not rows:
        return None
    ids = {row['id'] for row in rows}
    if len(ids) != 1:
        return None
    packed = _pack(*_join(con, rows[0], use_kometa), movie)
    if packed and _compatible(packed, given, con):
        return packed
    return None
