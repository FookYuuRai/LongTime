"""Program add-ons > NNTP Stream: opens the settings.
RunScript(service.nntp.stream,speedtest) runs the speed test; RunScript(service.nntp.stream,speedstatus) shows what is measured."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib'))

import xbmcaddon

ARG = sys.argv[1] if len(sys.argv) > 1 else ''

if ARG == 'speedstatus':
    import xbmcgui
    from nntpstream import speedtest
    try:
        lines = speedtest.status_lines()
    except Exception as error:
        lines = ['Could not read the measured servers: %s' % error]
    xbmcgui.Dialog().textviewer('Measured servers', '\n'.join(lines))
elif ARG == 'speedtest':
    import xbmcgui
    from nntpstream import paths, speedtest
    modes = ['Measure the servers not measured yet (finds a film each has; measured ones stay as they are)',
             'Test again with one film (replaces the saved values of the servers that have it)']
    mode = xbmcgui.Dialog().select('NNTP speed test', modes)
    if mode < 0:
        sys.exit(0)
    chosen = None
    if mode == 1:
        films = speedtest.recent_plans()
        if len(films) > 1:
            names = ['%s  (%.1f GB)' % (plan.name, plan.size / 1e9) for _path, plan in films]
            picked = xbmcgui.Dialog().select('Test with the articles of which film?', names)
            if picked < 0:
                sys.exit(0)
            chosen = films[picked][1]
        elif films:
            chosen = films[0][1]
    dialog = xbmcgui.DialogProgress()
    dialog.create('NNTP speed test', 'Starting...')
    try:
        lines = speedtest.run(progress=lambda text: dialog.update(0, text), should_stop=dialog.iscanceled,
                              plan=chosen, only_new=(mode == 0))
    except Exception as error:
        lines = ['The test failed: %s' % error]
    dialog.close()
    for line in lines:
        paths.log('speedtest: ' + line)
    xbmcgui.Dialog().textviewer('NNTP speed test', '\n'.join(lines))
else:
    xbmcaddon.Addon('service.nntp.stream').openSettings()
