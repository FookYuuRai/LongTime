"""Starts the loopback server (the fallback) and turns Kodi's Stop into nntpstream.stop().
Event driven: nothing here calls into the GUI while waiting (polling getInfoLabel deadlocked Kodi's stop)."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib'))

import xbmc
import xbmcgui

from nntpstream import api, paths, server, settings


class Watcher(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.mine = False

    def onAVStarted(self):
        try:
            name = self.getPlayingFile()
        except Exception:
            name = ''
        self.mine = name.startswith('nntpstream://') or ('127.0.0.1' in name and '/stream/' in name)

    def _left(self):
        if self.mine:
            self.mine = False
            api.stop()

    onPlayBackStopped = onPlayBackEnded = onPlayBackError = _left


def main():
    monitor = xbmc.Monitor()
    settings.apply()
    from nntpstream import plan as planmod
    planmod.prune()
    port = server.ensure_started()
    xbmcgui.Window(10000).setProperty('nntp.stream.port', str(port))
    paths.log('service started (fallback HTTPS on 127.0.0.1:%d, native vfs.nntp: %s)' % (port, api.native_available()))
    watcher = Watcher()
    monitor.waitForAbort()                       # nothing else to do: events above do the work
    xbmcgui.Window(10000).clearProperty('nntp.stream.port')
    del watcher
    server.shutdown()
    paths.log('service stopped')


if __name__ == '__main__':
    main()
