"""What the speed test found for each provider: {host: {connections, mbit, at, film, steps}}. Used when a server address has no /N."""
import json
import os

from . import paths


def _file():
    return os.path.join(paths.home(), 'server_caps.json')


def entries():
    """{host: {'connections': n, 'mbit': best speed, 'at': time, 'film': name, 'steps': {count: Mbit/s}}} (an old plain number is read too)."""
    try:
        with open(_file(), encoding='utf-8') as handle:
            data = json.load(handle)
    except Exception:
        return {}
    out = {}
    for host, value in data.items():
        try:
            if isinstance(value, dict):
                if int(value.get('connections', 0)) > 0:
                    out[str(host).lower()] = value
            elif int(value) > 0:
                out[str(host).lower()] = {'connections': int(value), 'mbit': 0, 'at': 0, 'film': '', 'steps': {}}
        except (TypeError, ValueError):
            continue
    return out


def load():
    """{host: connections}"""
    return {host: int(value['connections']) for host, value in entries().items()}


def update(new_entries):
    """Adds or replaces these providers; every other one stays exactly as it was.
    A provider remembers its last 3 tests: the saved connection count (the ceiling) is the highest of them, so a server that did
    best with 16 once and 8 another time may use up to 16 (the player lowers it again when it is not needed)."""
    data = entries()
    for host, entry in new_entries.items():
        host = str(host).lower()
        old = data.get(host)
        history = list(old.get('history') or []) if old else []
        if old and not history:
            history = [{'connections': int(old['connections']), 'mbit': old.get('mbit', 0), 'at': old.get('at', 0), 'film': old.get('film', '')}]
        history.append({'connections': int(entry['connections']), 'mbit': entry.get('mbit', 0), 'at': entry.get('at', 0), 'film': entry.get('film', '')})
        history = history[-3:]
        entry = dict(entry)
        entry['history'] = history
        entry['last'] = int(entry['connections'])
        entry['connections'] = max(int(h['connections']) for h in history)
        data[host] = entry
    try:
        with open(_file(), 'w', encoding='utf-8') as handle:
            json.dump(data, handle, indent=1, sort_keys=True)
    except Exception:
        pass


def for_host(host):
    """The saved connection count for this provider, or None."""
    try:
        from . import settings
        if not settings.use_saved_caps():
            return None
    except Exception:
        pass
    return load().get(str(host).lower())
