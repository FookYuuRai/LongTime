"""Where things live. In Kodi: the add-on's profile folder; in tests: $NNTP_HOME."""
import os

ADDON_ID = 'service.nntp.stream'


def home():
    path = os.environ.get('NNTP_HOME')
    if not path:
        try:
            import xbmcvfs
            path = xbmcvfs.translatePath('special://profile/addon_data/%s' % ADDON_ID)
        except Exception:
            path = os.path.join(os.path.expanduser('~'), '.nntpstream')
    os.makedirs(path, exist_ok=True)
    return path


def sub(name):
    path = os.path.join(home(), name)
    os.makedirs(path, exist_ok=True)
    return path


def plans():
    return sub('plans')


def certs():
    """Your own private certificates (.pem / .crt / .cer): trusted for the Usenet TLS connections."""
    return sub('certs')


def log(text):
    try:
        import xbmc
        xbmc.log('[NNTP] %s' % text, xbmc.LOGINFO)
    except Exception:
        if os.environ.get('NNTP_DEBUG'):
            print('[NNTP]', text)
