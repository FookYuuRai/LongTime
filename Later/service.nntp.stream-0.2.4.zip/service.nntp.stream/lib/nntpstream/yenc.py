"""yEnc decoding with bytes.translate (C speed) - one pass over the escaped bytes only."""
import re

_TABLE = bytes((i - 42) & 255 for i in range(256))
_PART = re.compile(rb'=ypart begin=(\d+) end=(\d+)')
_BEGIN = re.compile(rb'=ybegin ([^\r\n]*)')


def decode(body):
    """-> (begin_offset (0-based), data, total_size, name) or None when this is not yEnc."""
    start = body.find(b'=ybegin ')
    if start < 0:
        return None
    eol = body.find(b'\n', start)
    header = _BEGIN.match(body, start).group(1)
    size = re.search(rb'size=(\d+)', header)
    name = re.search(rb'name=(.*)$', header)
    begin = 0
    cursor = eol + 1
    part = _PART.match(body, cursor)
    if part:
        begin = int(part.group(1)) - 1
        cursor = body.find(b'\n', cursor) + 1
    end = body.find(b'\r\n=yend', cursor)
    if end < 0:
        end = body.find(b'\n=yend', cursor)
    if end < 0:
        end = len(body)
    raw = body[cursor:end].replace(b'\r\n', b'').replace(b'\n', b'')
    if b'=' in raw:
        pieces = raw.split(b'=')
        out = [pieces[0].translate(_TABLE)]
        for piece in pieces[1:]:
            if piece:
                out.append(bytes(((piece[0] - 64 - 42) & 255,)))
                out.append(piece[1:].translate(_TABLE))
        data = b''.join(out)
    else:
        data = raw.translate(_TABLE)
    return begin, data, int(size.group(1)) if size else len(data), name.group(1).decode('latin1').strip() if name else ''
