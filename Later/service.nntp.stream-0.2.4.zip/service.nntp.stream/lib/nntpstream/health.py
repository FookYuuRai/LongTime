"""Availability check with STAT: asks whether articles exist (no download), spread through the film."""
import threading
from concurrent.futures import ThreadPoolExecutor

from . import nntp

SAMPLES = 24               # articles asked (STAT is tiny, so many more than a BODY check could afford)
MAX_MISSING = 0.10         # a release with more than this share of its sampled articles gone is refused
WORKERS = 4


def sample_ids(segments, samples=SAMPLES):
    """Article ids spread evenly through a file; always the first and the last."""
    ids = list(segments)
    if len(ids) <= samples:
        return ids
    step = (len(ids) - 1) / float(samples - 1)
    return [ids[int(round(i * step))] for i in range(samples)]


def check(servers, segments, samples=SAMPLES, max_missing=MAX_MISSING):
    """-> {'ok', 'sampled', 'missing', 'unknown', 'reason'}.
    'unknown' = the servers could not answer (not counted as missing). Servers are asked in order: an article
    is missing only when every usable server says so."""
    picked = sample_ids(segments, samples)
    local = threading.local()
    state = {'bad_login': 0, 'no_connection': 0}
    found = [0] * len(servers)
    lock = threading.Lock()

    def connection(index):
        conns = getattr(local, 'conns', None)
        if conns is None:
            conns = local.conns = {}
        if index not in conns:
            conns[index] = nntp.Connection(servers[index])
        return conns[index]

    def ask(message_id):
        usable = False
        for index in range(len(servers)):
            try:
                if connection(index).stat(message_id):
                    with lock:
                        found[index] += 1
                    return True
                usable = True
            except nntp.AuthError:
                with lock:
                    state['bad_login'] += 1
            except Exception:
                local.conns.pop(index, None)
                with lock:
                    state['no_connection'] += 1
        return False if usable else None

    with ThreadPoolExecutor(max_workers=min(WORKERS, len(picked))) as pool:
        answers = list(pool.map(ask, picked))
    missing = answers.count(False)
    unknown = answers.count(None)
    answered = len(picked) - unknown
    result = {'ok': True, 'sampled': len(picked), 'missing': missing, 'unknown': unknown, 'reason': '',
              # which provider answered how many of the sampled articles (a backup shows up here when the first one lacks them)
              'by_server': [{'host': str((servers[i] or {}).get('host') or '') if isinstance(servers[i], dict) else '', 'found': found[i]} for i in range(len(servers))]}
    if not answered:
        result.update(ok=False, reason='login refused' if state['bad_login'] else 'no Usenet server could be reached')
    elif missing / float(answered) > max_missing:
        result.update(ok=False, reason='incomplete: %d of %d sampled articles are gone' % (missing, answered))
    return result
