"""Add-on settings (with defaults when it runs outside Kodi)."""
from . import nntp

RAM = {'0': (32, 20), '1': (64, 40), '2': (100, 64), '3': (100, 128)}     # articles kept / read ahead (about 24 / 48 / 75 MB / 75 MB kept + 100 MB ahead; x2 for a film over 80 GB)


def _get(key, default):
    try:
        import xbmcaddon
        value = str(xbmcaddon.Addon('service.nntp.stream').getSetting(key))
        return value if value != '' else default
    except Exception:
        return default


def own_servers():
    return [line for line in (_get('servers', '') or '').replace(',', ' ').split() if line.strip()]


def limits():
    return RAM.get(str(_get('ram', '1')), RAM['1'])


def connections():
    try:
        return max(1, min(nntp.MAX_CONNECTIONS, int(_get('connections', '8'))))
    except ValueError:
        return 8


def use_saved_caps():
    """Use the connection counts the speed test found for each provider (a server address with /N still wins)."""
    return str(_get('use_saved_caps', 'true')).lower() != 'false'


def connection_limit():
    """0 = automatic; else the most connections open at once over all servers."""
    try:
        if str(_get('connection_mode', '0')) != '1':
            return 0
        return max(1, min(50, int(_get('connection_limit', '10'))))
    except ValueError:
        return 0


def apply():
    """Default connections per server (a server URL's /N still wins)."""
    nntp.DEFAULT_CONNECTIONS = connections()
