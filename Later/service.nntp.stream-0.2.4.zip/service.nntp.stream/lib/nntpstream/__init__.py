"""nntpstream - play Usenet NZBs in Kodi. Public API: check(), play_url(), stop()."""
from .api import check, play_url, prepare, stop, unpack_to, VERSION  # noqa: F401
