"""The fallback: a loopback HTTP server (127.0.0.1 only, no certificate or key shipped) that answers range
requests from the articles. Only used when vfs.nntp is not installed."""
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import paths, plan as planmod
from .fetcher import Fetcher, Stream

IDLE = 60
_server = None
_sources = {}                       # token -> {'plan', 'fetcher', 'handles', 'closed'}
_streams = set()
_threads = []
_stop = threading.Event()
_lock = threading.RLock()


def _open(token):
    with _lock:
        src = _sources.get(token)
        if not src:
            plan = planmod.load(token)
            src = _sources[token] = {'plan': plan, 'fetcher': Fetcher(plan), 'handles': 0, 'closed': 0}
        src['handles'] += 1
        return src


def _release(src):
    with _lock:
        src['handles'] -= 1
        if src['handles'] <= 0:
            src['handles'] = 0
            src['closed'] = time.time()
            src['fetcher'].drop_ahead()


def stop_streams():
    with _lock:
        for stream in list(_streams):
            stream.cancel.set()


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args):
        pass

    def _serve(self, head):
        parts = self.path.split('?')[0].strip('/').split('/')
        if len(parts) != 3 or parts[0] != 'stream' or not all(c in '0123456789abcdef' for c in parts[1]) or not parts[1]:
            return self.send_error(404)
        try:
            src = _open(parts[1])
        except Exception:
            return self.send_error(404)
        try:
            plan = src['plan']
            if parts[2] != plan.name:
                return self.send_error(404)
            size, start, end, code = plan.size, 0, plan.size - 1, 200
            rng = self.headers.get('Range', '')
            if rng.startswith('bytes='):
                a, _, b = rng[6:].partition('-')
                if a == '':
                    start = max(0, size - int(b))
                else:
                    start = int(a)
                    end = int(b) if b else size - 1
                end = min(end, size - 1)
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header('Content-Range', 'bytes */%d' % size)
                    self.send_header('Content-Length', '0')
                    return self.end_headers()
                code = 206
            self.send_response(code)
            self.send_header('Content-Type', 'video/x-matroska' if plan.name.endswith('.mkv') else 'application/octet-stream')
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Content-Length', str(end - start + 1))
            if code == 206:
                self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
            self.end_headers()
            if head:
                return
            stream = Stream(plan, src['fetcher'])
            stream.position = start
            with _lock:
                _streams.add(stream)
            try:
                left = end - start + 1
                while left > 0:
                    chunk = stream.read(min(left, 1 << 20))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (IOError, OSError, ValueError):
                self.close_connection = True
            finally:
                with _lock:
                    _streams.discard(stream)
        finally:
            _release(src)

    def do_GET(self):
        self._serve(False)

    def do_HEAD(self):
        self._serve(True)


def _reaper():
    while not _stop.wait(5):
        gone = []
        with _lock:
            for token, src in list(_sources.items()):
                if not src['handles'] and time.time() - src['closed'] > IDLE:
                    gone.append(_sources.pop(token))
        for src in gone:
            src['fetcher'].close()


def ensure_started():
    """-> port. The server runs in this process; the Kodi service starts it at boot."""
    global _server
    with _lock:
        if _server is None:
            _server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
            _server.daemon_threads = True
            _stop.clear()
            _threads[:] = [threading.Thread(target=_server.serve_forever, kwargs={'poll_interval': 0.2}, name='nntp-http', daemon=True),
                           threading.Thread(target=_reaper, name='nntp-reaper', daemon=True)]
            for thread in _threads:
                thread.start()
            paths.log('local HTTP server on 127.0.0.1:%d' % _server.server_address[1])
        return _server.server_address[1]


def shutdown():
    """Everything stops and is joined (Kodi waits for the script's threads when it stops the service)."""
    global _server
    _stop.set()
    with _lock:
        server, _server = _server, None
        sources = list(_sources.values())
        _sources.clear()
        for stream in list(_streams):
            stream.cancel.set()
    for src in sources:
        src['fetcher'].close()
    if server:
        server.shutdown()
        server.server_close()
    for thread in _threads:
        thread.join(2)
    del _threads[:]
