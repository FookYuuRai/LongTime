"""NZB parsing: files with their article ids, and which one is the film."""
import re
import xml.etree.ElementTree as ET

VIDEO = ('.mkv', '.mp4', '.m4v', '.avi', '.ts', '.m2ts', '.mov', '.webm')


class NzbFile(object):
    def __init__(self, subject, segments):
        self.subject = subject
        self.segments = segments                 # article ids in order
        self.encoded = sum(s[0] for s in segments)
        m = re.search(r'"([^"]+)"', subject)
        if not m:        # no quotes: the name is the word with an extension before "yEnc" / "(1/50)"
            m = re.search(r'([^\s"\[\]]+\.[A-Za-z0-9]{2,4})(?=\s+(?:yEnc|\(\d))', subject)
        self.name = m.group(1) if m else subject


def parse(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    root = ET.fromstring(data)
    files = []
    for f in root.iter():
        if not f.tag.endswith('}file') and f.tag != 'file':
            continue
        segs = []
        for s in f.iter():
            if s.tag.endswith('segment') and (s.text or '').strip():
                segs.append((int(s.get('bytes') or 0), int(s.get('number') or 0), s.text.strip().strip('<>')))
        segs.sort(key=lambda x: x[1])
        if segs:
            files.append(NzbFile(f.get('subject') or '', [(b, n, i) for b, n, i in segs]))
    return files


ARCHIVE_RE = re.compile(r'\.(rar|r\d{2,3}|7z|zip|\d{3})$', re.I)


def recognised(files):
    return any(f.name.lower().endswith(VIDEO) or ARCHIVE_RE.search(f.name) for f in files)


def load(data, servers=None):
    """parse(), and when no file name says video or archive (obfuscated subjects): the real names are read from the first
    article of each big file (the yEnc header carries the name)."""
    files = parse(data)
    if servers and files and not recognised(files):
        try:
            resolve_names(files, servers)
        except Exception:
            pass
    return files


def resolve_names(files, servers, limit=80):
    import threading
    from . import nntp, yenc
    todo = sorted(files, key=lambda f: -f.encoded)[:limit]
    lock = threading.Lock()

    def work():
        while True:
            with lock:
                if not todo:
                    return
                f = todo.pop(0)
            for server in servers:
                conn = None
                try:
                    conn = nntp.Connection(server)
                    decoded = yenc.decode(conn.body(f.segments[0][2]))
                    if decoded and decoded[3]:
                        f.name = decoded[3]
                        break
                except Exception:
                    pass
                finally:
                    if conn:
                        conn.close()

    pool = [threading.Thread(target=work, daemon=True) for _ in range(8)]
    for t in pool:
        t.start()
    for t in pool:
        t.join()


def _episode_score(name, season, episode, absolute):
    """How well a file name says it is this episode (0 = does not)."""
    text = re.sub(r'[\[\](){}_.]+', ' ', name.lower())
    text = re.sub(r'\b(?:19|20)\d{2}\b', ' ', text)                              # a year is no episode number
    text = re.sub(r'\b(?:480|576|720|1080|1440|2160|4320)[pi]?\b|\b[xh]\.?26[45]\b', ' ', text)
    best = 0
    for m in re.finditer(r'\bs(\d{1,2})\s*e(\d{1,4})(?:\s*-?\s*e?(\d{1,4}))?\b', text):         # S01E01 / S01E01-E03
        s_, lo = int(m.group(1)), int(m.group(2))
        hi = int(m.group(3)) if m.group(3) and int(m.group(3)) >= lo else lo
        if season and s_ == season and lo <= episode <= hi: best = max(best, 4)
        elif absolute and lo <= absolute <= hi and s_ in (1, season): best = max(best, 3)
    for m in re.finditer(r'\b(\d{1,2})x(\d{1,3})\b', text):                                    # 1x01
        if season and int(m.group(1)) == season and int(m.group(2)) == episode: best = max(best, 4)
    for m in re.finditer(r'\b(?:e|ep|eps|episode)\s*(\d{1,4})\b', text):                          # E01 / Episode 01
        n = int(m.group(1))
        if n == episode or (absolute and n == absolute): best = max(best, 3)
    for m in re.finditer(r'(?:^|\s)-\s*(\d{1,4})(?:v\d)?(?=\s|$)', text):                         # "Show - 01"
        n = int(m.group(1))
        if n == episode or (absolute and n == absolute): best = max(best, 2)
    return best


def pick_film(files, episode=None):
    """The biggest plain video file - or, when the NZB is a pack of episodes and `episode` (season, episode, absolute) is given, the
    file for THAT episode. Releases packed in RAR / 7z are not supported yet: says so."""
    videos = [f for f in files if f.name.lower().endswith(VIDEO)]
    if videos:
        if episode and len(videos) > 1:
            try:
                season, number, absolute = (int(episode.get('season') or 0), int(episode.get('episode') or 0), int(episode.get('absolute') or 0))
            except (TypeError, ValueError):
                season = number = absolute = 0
            if number:
                scored = [(_episode_score(f.name, season, number, absolute), f) for f in videos]
                top = max(sc for sc, _ in scored)
                if top > 0:
                    return max((f for sc, f in scored if sc == top), key=lambda f: f.encoded)
                raise ValueError('episode %s is not in this pack' % (('S%02dE%02d' % (season, number)) if season else number))
        return max(videos, key=lambda f: f.encoded)
    if any(ARCHIVE_RE.search(f.name) for f in files):
        raise ValueError('packed in RAR / 7z / ZIP: not supported yet')
    names = ', '.join(f.name[:40] for f in sorted(files, key=lambda f: -f.encoded)[:4])
    raise ValueError('no video file in this NZB (biggest files: %s)' % names)
