"""A small NNTP client: TLS that trusts Kodi's list plus your own private certificates, AUTHINFO, STAT, BODY."""
import os
import socket
import ssl
from urllib.parse import unquote, urlparse

from . import paths

DEFAULT_CONNECTIONS = 8
MAX_CONNECTIONS = 20
TIMEOUT = 30


class NntpError(Exception):
    pass


class Missing(NntpError):
    """The article is not on this server (430 / 423 / 420)."""


class AuthError(NntpError):
    pass


class TooMany(NntpError):
    pass


def parse_server(value):
    """'nntps://user:pass@host:563/10' -> dict, or None. The path is the number of connections."""
    value = str(value or '').strip()
    if not value:
        return None
    if '://' not in value:
        value = 'nntps://' + value
    try:
        url = urlparse(value)
        secure = url.scheme.lower() in ('nntps', 'snews', 'ssl', 'tls')
        port = url.port or (563 if secure else 119)
        path = (url.path or '').strip('/')
        connections = int(path) if path.isdigit() else None
    except ValueError:
        return None
    if not url.hostname:
        return None
    if connections is None:
        try:
            from . import caps
            connections = caps.for_host(url.hostname)
        except Exception:
            connections = None
        connections = connections or DEFAULT_CONNECTIONS
    return {'host': url.hostname, 'port': port, 'ssl': secure, 'user': unquote(url.username or ''),
            'password': unquote(url.password or ''), 'connections': max(1, min(connections, MAX_CONNECTIONS))}


_context = None


def tls_context():
    """Kodi's certificate list (if it can be found) + the system's + every .pem/.crt/.cer in the certs folder."""
    global _context
    if _context is not None:
        return _context
    ctx = ssl.create_default_context()
    try:
        import xbmcvfs
        kodi_list = xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem')
        if os.path.isfile(kodi_list):
            ctx.load_verify_locations(kodi_list)
    except Exception:
        pass
    folder = paths.certs()
    for name in sorted(os.listdir(folder)):
        if name.lower().endswith(('.pem', '.crt', '.cer')):
            try:
                ctx.load_verify_locations(os.path.join(folder, name))
            except (ssl.SSLError, OSError):
                paths.log('certificate %s could not be read' % name)
    _context = ctx
    return ctx


def reset_context():
    global _context
    _context = None


class Connection(object):
    def __init__(self, server):
        self.server = server
        raw = socket.create_connection((server['host'], server['port']), TIMEOUT)
        raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock = tls_context().wrap_socket(raw, server_hostname=server['host']) if server['ssl'] else raw
        self.buf = bytearray()
        code, line = self._line()
        if code not in (200, 201):
            raise (TooMany(line) if _too_many(code, line) else NntpError('greeting %d' % code))
        if server['user']:
            self.send('AUTHINFO USER %s' % server['user'])
            code, line = self._line()
            if code == 381:
                self.send('AUTHINFO PASS %s' % server['password'])
                code, line = self._line()
            if code != 281:
                raise (TooMany(line) if _too_many(code, line) else AuthError('login refused (%d)' % code))

    def send(self, text):
        self.sock.sendall(text.encode('utf-8') + b'\r\n')

    def _fill(self):
        chunk = self.sock.recv(262144)
        if not chunk:
            raise NntpError('connection closed')
        self.buf += chunk

    def _line(self):
        while True:
            end = self.buf.find(b'\r\n')
            if end >= 0:
                line = bytes(self.buf[:end]).decode('latin1')
                del self.buf[:end + 2]
                try:
                    return int(line[:3]), line
                except ValueError:
                    raise NntpError('odd answer')
            self._fill()

    def stat(self, message_id):
        """True when the server has the article (no download)."""
        self.send('STAT <%s>' % message_id.strip('<>'))
        code, line = self._line()
        if code == 223:
            return True
        if code in (420, 423, 430):
            return False
        raise NntpError('STAT %d' % code)

    def body(self, message_id):
        """The article body as sent (still yEnc, dot-stuffing removed), or raises Missing."""
        self.send('BODY <%s>' % message_id.strip('<>'))
        code, line = self._line()
        if code in (420, 423, 430):
            raise Missing(message_id)
        if code != 222:
            raise NntpError('BODY %d' % code)
        while True:
            end = self.buf.find(b'\r\n.\r\n')
            if end >= 0:
                body = bytes(self.buf[:end + 2])
                del self.buf[:end + 5]
                break
            if self.buf[:3] == b'.\r\n':
                body = b''
                del self.buf[:3]
                break
            self._fill()
        return body.replace(b'\r\n..', b'\r\n.') if b'\r\n..' in body else body

    def close(self):
        try:
            self.send('QUIT')
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


def _too_many(code, line):
    low = line.lower()
    return code in (400, 481, 482, 502) and any(w in low for w in ('too many', 'connection', 'limit', 'session', 'max'))
