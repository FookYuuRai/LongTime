"""The "nntp-plan 1" text file read by vfs.nntp (C++) and by the Python fallback server."""
import os
import time

from . import paths


class Plan(object):
    def __init__(self):
        self.size = 0
        self.name = 'film.mkv'
        self.keep = 64
        self.ahead = 40
        self.maxconn = 0       # 0 = automatic
        self.servers = []      # dicts as nntp.parse_server
        self.extents = []      # [start, offset, length, part, ids]


def text(plan):
    hexed = lambda v: v.encode('utf-8').hex() if v else '-'
    lines = ['nntp-plan 1', 'size %d' % plan.size, 'name %s' % plan.name.encode('utf-8').hex(),
             'keep %d' % plan.keep, 'ahead %d' % plan.ahead]
    if getattr(plan, 'maxconn', 0):
        lines.append('maxconn %d' % plan.maxconn)
    for s in plan.servers:
        lines.append('server %d %s %d %d %s %s' % (1 if s['ssl'] else 0, s['host'], s['port'], s['connections'],
                                                   hexed(s['user']), hexed(s['password'])))
    for _start, offset, length, part, ids in plan.extents:
        lines.append('extent %d %d %d %d' % (offset, length, part, len(ids)))
        lines.extend(ids)
    return '\n'.join(lines) + '\n'


def parse(data):
    lines = data.splitlines()
    if not lines or not lines[0].startswith('nntp-plan 1'):
        raise ValueError('not a plan')
    plan, start, i = Plan(), 0, 1
    unhex = lambda v: '' if v == '-' else bytes.fromhex(v).decode('utf-8')
    while i < len(lines):
        f = lines[i].split()
        i += 1
        if not f:
            continue
        if f[0] == 'size':
            plan.size = int(f[1])
        elif f[0] == 'name':
            plan.name = bytes.fromhex(f[1]).decode('utf-8')
        elif f[0] == 'keep':
            plan.keep = int(f[1])
        elif f[0] == 'ahead':
            plan.ahead = int(f[1])
        elif f[0] == 'maxconn':
            plan.maxconn = int(f[1])
        elif f[0] == 'server':
            plan.servers.append({'ssl': f[1] != '0', 'host': f[2], 'port': int(f[3]), 'connections': max(1, min(50, int(f[4]))),
                                 'user': unhex(f[5]), 'password': unhex(f[6])})
        elif f[0] == 'extent':
            offset, length, part, n = map(int, f[1:5])
            plan.extents.append([start, offset, length, part, lines[i:i + n]])
            start += length
            i += n
    if not plan.servers or not plan.extents:
        raise ValueError('incomplete plan')
    plan.size = min(plan.size or start, start)
    plan.keep = max(8, plan.keep)
    plan.ahead = max(1, min(plan.keep - 4, plan.ahead))
    return plan


def path_for(token):
    return os.path.join(paths.plans(), token + '.plan')


def save(token, plan):
    path = path_for(token)
    temp = path + '.tmp'
    with open(temp, 'w', encoding='utf-8') as handle:
        handle.write(text(plan))
    try:
        os.chmod(temp, 0o600)
    except OSError:
        pass
    os.replace(temp, path)
    prune(path)
    return path


def prune(current=None, keep=12, hours=24):
    """Plans are only needed while a film plays: keep the newest few, drop the rest (and anything a day old)."""
    try:
        folder = os.path.dirname(current) if current else paths.plans()
        files = []
        for name in os.listdir(folder):
            full = os.path.join(folder, name)
            if os.path.isfile(full) and name != 'leaving':
                files.append((os.path.getmtime(full), full))
        files.sort(reverse=True)
        limit = time.time() - hours * 3600
        for index, (modified, full) in enumerate(files):
            if full != current and (index >= keep or modified < limit):
                try:
                    os.remove(full)
                except OSError:
                    pass
    except OSError:
        pass


def load(token):
    with open(path_for(token), encoding='utf-8') as handle:
        return parse(handle.read())
