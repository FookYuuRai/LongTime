"""Unpack a packed NZB release to a local folder, without any debrid service.

    path = unpack.run(nzb_bytes, servers, folder, progress=cb, cancel=event)

Downloads the archive volumes one at a time (several connections in parallel) to a work file, copies the video out of
each volume into `folder`, and deletes the volume. Disk needed: the video plus one volume.

What it can open: RAR 2/3/4 and RAR 5 archives that are STORED (no compression - which is how Usenet video releases
are packed), multi-volume, not encrypted; and a plain ZIP. A RAR that is compressed, a password-protected one and a
7z are refused with a clear message (nothing is written).
"""
import os
import re
import shutil
import struct
import threading
import time
import zipfile

from . import nntp, nzb as nzbmod, paths, yenc

ARCHIVE = re.compile(r'\.(rar|r\d{2,3}|zip|7z|\d{3})$', re.I)


class Unsupported(Exception):
    pass


class Cancelled(Exception):
    pass


# -- volumes -------------------------------------------------------------------------------------------------------------
def _volume_key(name):
    low = name.lower()
    m = re.search(r'\.part0*(\d+)\.rar$', low)
    if m:
        return (0, int(m.group(1)))
    if low.endswith('.rar'):
        return (0, 0)
    m = re.search(r'\.r(\d{2,3})$', low)
    if m:
        return (1, int(m.group(1)))
    m = re.search(r'\.(\d{3})$', low)
    if m:
        return (1, int(m.group(1)))
    return (2, 0)


def volumes(files):
    """The archive files of the release in reading order, and the kind: 'rar' | 'zip' | '7z'."""
    vols = [f for f in files if ARCHIVE.search(f.name) and not re.search(r'\.par2$', f.name, re.I)]
    if not vols:
        raise Unsupported('no archive in this NZB')
    kinds = set()
    for f in vols:
        low = f.name.lower()
        kinds.add('zip' if low.endswith('.zip') else '7z' if low.endswith('.7z') or re.search(r'\.7z\.\d{3}$', low) else 'rar')
    if '7z' in kinds:
        raise Unsupported('this release is packed as 7z - only stored RAR and ZIP can be opened without a debrid service')
    if kinds == {'zip'} and len(vols) > 1:
        raise Unsupported('a split ZIP is not supported')
    vols.sort(key=lambda f: _volume_key(f.name))
    return vols, ('zip' if 'zip' in kinds else 'rar')


# -- download ------------------------------------------------------------------------------------------------------------
class _Download(object):
    """One archive file (its articles) to a work file, in parallel; every server is tried for an article."""

    def __init__(self, servers, threads, cancel, tick):
        self.servers, self.threads, self.cancel, self.tick = servers, threads, cancel, tick

    def fetch(self, nzbfile, target):
        todo = list(range(len(nzbfile.segments)))
        lock = threading.Lock()
        errors = []
        handle = open(target, 'wb')
        file_lock = threading.Lock()

        def work():
            conns = {}
            try:
                while not self.cancel.is_set() and not errors:
                    with lock:
                        if not todo:
                            return
                        index = todo.pop(0)
                    message_id = nzbfile.segments[index][2]
                    done = False
                    for s, server in enumerate(self.servers):
                        for attempt in range(3):
                            try:
                                if s not in conns:
                                    conns[s] = nntp.Connection(server)
                                raw = conns[s].body(message_id)
                                decoded = yenc.decode(raw)
                                if not decoded:
                                    raise nntp.Missing(message_id)
                                begin, data = decoded[0], decoded[1]
                                with file_lock:
                                    handle.seek(begin)
                                    handle.write(data)
                                self.tick(len(data))
                                done = True
                                break
                            except nntp.Missing:
                                break
                            except nntp.AuthError:
                                break
                            except Exception:
                                conns.pop(s, None)
                                time.sleep(1 + attempt)
                        if done:
                            break
                    if not done:
                        errors.append('articles are missing on every server (%s)' % nzbfile.name)
            finally:
                for c in conns.values():
                    c.close()

        pool = [threading.Thread(target=work, daemon=True, name='nntp-unpack') for _ in range(self.threads)]
        for t in pool:
            t.start()
        for t in pool:
            t.join()
        handle.close()
        if self.cancel.is_set():
            raise Cancelled()
        if errors:
            raise IOError(errors[0])


# -- RAR -----------------------------------------------------------------------------------------------------------------
def _vint(buf, pos):
    value, shift = 0, 0
    while True:
        byte = buf[pos]
        pos += 1
        value |= (byte & 0x7f) << shift
        if not byte & 0x80:
            return value, pos
        shift += 7


def _rar_entries(handle, size):
    """Yields (name, data_start, data_len, split_before, split_after, store, encrypted, is_dir) for each file block."""
    head = handle.read(8)
    if head[:7] == b'Rar!\x1a\x07\x00':
        pos = 7
        while pos + 7 <= size:
            handle.seek(pos)
            base = handle.read(7)
            if len(base) < 7:
                return
            _crc, btype, flags, hsize = struct.unpack('<HBHH', base)
            if hsize < 7:
                return
            if btype == 0x73 and flags & 0x80:
                raise Unsupported('the archive is password-protected')
            if btype == 0x74:
                handle.seek(pos)
                raw = handle.read(hsize)
                pack, unp, _os, _crc2, _ft, _ver, method, nlen, _attr = struct.unpack('<IIBIIBBHI', raw[7:32])
                at = 32
                if flags & 0x100:
                    hp, hu = struct.unpack('<II', raw[at:at + 8])
                    pack |= hp << 32
                    at += 8
                name = raw[at:at + nlen]
                name = name.split(b'\0')[0].decode('utf-8', 'replace') if flags & 0x200 else name.decode('latin1')
                yield (name.replace('\\', '/'), pos + hsize, pack, bool(flags & 1), bool(flags & 2), method == 0x30,
                       bool(flags & 4), (flags & 0xe0) == 0xe0)
                pos += hsize + pack
            else:
                add = 0
                if flags & 0x8000:
                    handle.seek(pos + 7)
                    add = struct.unpack('<I', handle.read(4))[0]
                if btype == 0x7b:
                    return
                pos += hsize + add
        return
    if head[:8] == b'Rar!\x1a\x07\x01\x00':
        pos = 8
        while pos + 8 < size:
            handle.seek(pos)
            chunk = handle.read(32)
            if len(chunk) < 8:
                return
            at = 4
            hsize, at = _vint(chunk, at)
            start = pos + at
            handle.seek(start)
            raw = handle.read(hsize)
            p = 0
            btype, p = _vint(raw, p)
            flags, p = _vint(raw, p)
            if flags & 1:
                _extra, p = _vint(raw, p)
            data = 0
            if flags & 2:
                data, p = _vint(raw, p)
            if btype == 4:
                raise Unsupported('the archive is password-protected')
            if btype == 2:
                fflags, p = _vint(raw, p)
                _unp, p = _vint(raw, p)
                _attr, p = _vint(raw, p)
                if fflags & 2:
                    p += 4
                if fflags & 4:
                    p += 4
                info, p = _vint(raw, p)
                _host, p = _vint(raw, p)
                nlen, p = _vint(raw, p)
                name = raw[p:p + nlen].decode('utf-8', 'replace')
                encrypted = False
                extra_size = 0
                # an encryption record in the extra area (type 1) means a password
                tail = raw[p + nlen:]
                q = 0
                while q < len(tail):
                    try:
                        rsize, q2 = _vint(tail, q)
                        rtype, _ = _vint(tail, q2)
                    except IndexError:
                        break
                    if rtype == 1:
                        encrypted = True
                    q = q2 + rsize
                yield (name, start + hsize, data, bool(flags & 8), bool(flags & 0x10), ((info >> 7) & 7) == 0,
                       encrypted, bool(fflags & 1))
            if btype == 5:
                return
            pos = start + hsize + data
        return
    raise Unsupported('this is not a RAR archive')


def _is_video(name):
    return name.lower().endswith(nzbmod.VIDEO) and 'sample' not in os.path.basename(name).lower()


class _RarOut(object):
    """Copies the video of the volumes (in order) into one output file."""

    def __init__(self, folder):
        self.folder, self.name, self.handle, self.path = folder, None, None, None
        self.done = False

    def feed(self, volume, progress=None):
        size = os.path.getsize(volume)
        with open(volume, 'rb') as handle:
            self.feed_handle(handle, size, progress)

    def feed_handle(self, handle, size, progress=None):
        if True:
            for name, start, length, before, after, store, encrypted, is_dir in list(_rar_entries(handle, size)):
                if is_dir or not _is_video(name):
                    continue
                if encrypted:
                    raise Unsupported('the archive is password-protected')
                if not store:
                    raise Unsupported('the RAR is compressed (not stored): it cannot be unpacked here - use a debrid service')
                base = os.path.basename(name)
                base = re.sub(r'[,;"\\|<>:*?]+', '', base).strip() or 'video.mkv'      # (a comma would split Kodi's PlayMedia(...) arguments)
                if self.name is None:
                    if before:
                        continue                         # the start of this file was in a volume we do not have
                    self.name = base
                    self.path = os.path.join(self.folder, base)
                    self.handle = open(self.path + '.part', 'wb')
                elif base != self.name or self.done:
                    continue
                handle.seek(start)
                left = length
                while left > 0:
                    block = handle.read(min(left, 4 << 20))
                    if not block:
                        raise IOError('the volume ends early')
                    self.handle.write(block)
                    left -= len(block)
                    if progress:
                        progress(len(block))
                if not after:
                    self.done = True

    def finish(self):
        if not self.handle:
            raise Unsupported('no video file inside the archive')
        self.handle.close()
        if os.path.exists(self.path):
            os.remove(self.path)
        os.replace(self.path + '.part', self.path)
        return self.path

    def abort(self):
        if self.handle:
            try:
                self.handle.close()
                os.remove(self.path + '.part')
            except OSError:
                pass


def _zip_out(volume, folder, progress=None):
    with zipfile.ZipFile(volume) as z:
        items = [i for i in z.infolist() if not i.is_dir() and _is_video(i.filename)]
        if not items:
            raise Unsupported('no video file inside the archive')
        if any(i.flag_bits & 1 for i in items):
            raise Unsupported('the archive is password-protected')
        item = max(items, key=lambda i: i.file_size)
        path = os.path.join(folder, re.sub(r'[,;"\\|<>:*?]+', '', os.path.basename(item.filename)).strip() or 'video.mkv')
        with z.open(item) as src, open(path + '.part', 'wb') as dst:
            while True:
                block = src.read(4 << 20)
                if not block:
                    break
                dst.write(block)
                if progress:
                    progress(len(block))
        os.replace(path + '.part', path)
        return path


# -- the whole job -------------------------------------------------------------------------------------------------------
def estimate(files):
    """-> (bytes to download, biggest volume) for the free-space check."""
    vols, _kind = volumes(files)
    sizes = [f.encoded for f in vols]
    return sum(sizes), max(sizes)


def run(nzb_bytes, servers, folder, progress=None, cancel=None, threads=12):
    """Returns the path of the video file in `folder`. Raises Unsupported / Cancelled / IOError with a plain message."""
    cancel = cancel or threading.Event()
    files = nzbmod.load(nzb_bytes, servers)
    vols, kind = volumes(files)
    total, biggest = estimate(files)
    os.makedirs(folder, exist_ok=True)
    free = shutil.disk_usage(folder).free
    need = total + biggest
    if free < need + (200 << 20):
        raise IOError('not enough free space in %s: %.1f GB needed, %.1f GB free' % (folder, need / 1e9, free / 1e9))
    work = os.path.join(folder, '.unpack-work')
    os.makedirs(work, exist_ok=True)
    state = {'done': 0, 'last': 0.0, 'start': time.time()}
    lock = threading.Lock()

    def tick(count):
        with lock:
            state['done'] += count
            now = time.time()
            if progress and now - state['last'] >= 0.5:
                state['last'] = now
                speed = state['done'] / max(now - state['start'], 0.1)
                progress(min(state['done'], total), total, speed)

    download = _Download(servers, max(1, threads), cancel, tick)
    out = _RarOut(folder) if kind == 'rar' else None
    path = None
    try:
        for number, vol in enumerate(vols):
            target = os.path.join(work, 'vol%04d' % number)
            paths.log('unpack: volume %d/%d %s (%.0f MB)' % (number + 1, len(vols), vol.name, vol.encoded / 1e6))
            download.fetch(vol, target)
            if kind == 'zip':
                path = _zip_out(target, folder)
            else:
                out.feed(target)
            os.remove(target)
            if out and out.done:
                break                                    # the rest of the volumes hold nothing we need (e.g. extras)
        if out:
            path = out.finish()
    except BaseException:
        if out:
            out.abort()
        raise
    finally:
        shutil.rmtree(work, ignore_errors=True)
    if progress:
        progress(total, total, 0)
    paths.log('unpack: done %s (%.2f GB)' % (path, os.path.getsize(path) / 1e9))
    return path


# -- stream mode: all the volumes as ONE long file read through vfs.nntp (rapidyenc, shared connections) ---------------------
class _Slice(object):
    """A volume inside the long file, as a file of its own (seek / tell / read)."""

    def __init__(self, reader, base, size):
        self.reader, self.base, self.size, self.at = reader, base, size, 0

    def seek(self, pos, whence=0):
        self.at = pos if whence == 0 else self.at + pos if whence == 1 else self.size + pos
        self.at = max(0, min(self.at, self.size))
        return self.at

    def tell(self):
        return self.at

    def read(self, count=-1):
        if count is None or count < 0 or self.at + count > self.size:
            count = self.size - self.at
        if count <= 0:
            return b''
        self.reader.seek(self.base + self.at)
        data = self.reader.read(count)
        self.at += len(data)
        return data


class VfsReader(object):
    """The long file through Kodi's VFS (nntpstream://)."""

    def __init__(self, url):
        import xbmcvfs
        self.file = xbmcvfs.File(url)
        self.at = 0

    def seek(self, pos):
        if pos != self.at:
            self.file.seek(pos, 0)
            self.at = pos

    def read(self, count):
        data = bytes(self.file.readBytes(count))
        self.at += len(data)
        return data

    def close(self):
        self.file.close()


class HttpReader(object):
    """The long file over the Python fallback server's HTTP Range (tests, and where vfs.nntp is not there)."""

    def __init__(self, url):
        self.url, self.at, self.resp = url, 0, None

    def seek(self, pos):
        if pos != self.at:
            self._drop()
            self.at = pos

    def _drop(self):
        if self.resp:
            try:
                self.resp.close()
            except Exception:
                pass
            self.resp = None

    def read(self, count):
        import urllib.request
        if self.resp is None:
            request = urllib.request.Request(self.url, headers={'Range': 'bytes=%d-' % self.at})
            self.resp = urllib.request.urlopen(request, timeout=60)
        out = bytearray()
        while len(out) < count:
            chunk = self.resp.read(count - len(out))
            if not chunk:
                break
            out += chunk
        self.at += len(out)
        return bytes(out)

    def close(self):
        self._drop()


def build_blob(data, servers, vols, token_seed=b''):
    """Plan for the volumes as one file. -> (token, plan, [(start, size)])"""
    import hashlib
    from . import plan as planmod, settings
    heads = [None] * len(vols)
    errors = []
    todo = list(range(len(vols)))
    lock = threading.Lock()

    def work():
        while True:
            with lock:
                if not todo or errors:
                    return
                i = todo.pop(0)
            got = None
            for server in servers:
                conn = None
                try:
                    conn = nntp.Connection(server)
                    got = yenc.decode(conn.body(vols[i].segments[0][2]))
                    if got:
                        break
                except Exception:
                    pass
                finally:
                    if conn:
                        conn.close()
            if got is None:
                errors.append('the first article of %s is missing on every server' % vols[i].name)
            heads[i] = got

    pool = [threading.Thread(target=work, daemon=True) for _ in range(min(8, len(vols)))]
    for t in pool:
        t.start()
    for t in pool:
        t.join()
    if errors:
        raise IOError(errors[0])
    plan = planmod.Plan()
    plan.name = 'release.rar'
    plan.servers = servers
    keep, ahead = settings.limits()
    plan.keep, plan.ahead = int(keep * 2), int(ahead * 2)
    plan.maxconn = settings.connection_limit()
    spans, start = [], 0
    for vol, head in zip(vols, heads):
        size = head[2]
        plan.extents.append([start, 0, size, len(head[1]) if len(vol.segments) > 1 else size, [s[2] for s in vol.segments]])
        spans.append((start, size))
        start += size
    plan.size = start
    token = hashlib.sha256(data + b'|unpack|' + '|'.join(s['host'] for s in servers).encode()).hexdigest()[:32]
    planmod.save(token, plan)
    return token, plan, spans


def run_stream(data, servers, folder, url_for, reader_class, progress=None, cancel=None):
    """Unpack by reading the release as one long file. url_for(token, plan) -> the URL of it."""
    from . import plan as planmod
    cancel = cancel or threading.Event()
    files = nzbmod.load(data, servers)
    vols, kind = volumes(files)
    total, biggest = estimate(files)
    os.makedirs(folder, exist_ok=True)
    free = shutil.disk_usage(folder).free
    video_estimate = total
    if free < video_estimate + (200 << 20):
        raise IOError('not enough free space in %s: %.1f GB needed, %.1f GB free' % (folder, video_estimate / 1e9, free / 1e9))
    token, plan, spans = build_blob(data, servers, vols)
    paths.log('unpack (stream): %d volume(s), %.2f GB as one file' % (len(vols), plan.size / 1e9))
    reader = reader_class(url_for(token, plan))
    state = {'done': 0, 'last': 0.0, 'start': time.time()}

    def tick(count):
        if cancel.is_set():
            raise Cancelled()
        state['done'] += count
        now = time.time()
        if progress and now - state['last'] >= 0.5:
            state['last'] = now
            progress(min(state['done'], plan.size), plan.size, state['done'] / max(now - state['start'], 0.1))

    out = _RarOut(folder) if kind == 'rar' else None
    path = None
    try:
        for (start, size) in spans:
            piece = _Slice(reader, start, size)
            if kind == 'zip':
                path = _zip_out(piece, folder, tick)
            else:
                out.feed_handle(piece, size, tick)
                if out.done:
                    break
        if out:
            path = out.finish()
    except BaseException:
        if out:
            out.abort()
        raise
    finally:
        reader.close()
        try:
            os.remove(planmod.path_for(token))
        except OSError:
            pass
    if progress:
        progress(plan.size, plan.size, 0)
    paths.log('unpack (stream): done %s (%.2f GB)' % (path, os.path.getsize(path) / 1e9))
    return path
