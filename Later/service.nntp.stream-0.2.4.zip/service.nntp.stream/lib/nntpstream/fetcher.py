"""The Python reader (used when vfs.nntp is not there): connections per server, priorities, read-ahead, cache."""
import heapq
import itertools
import threading
import time
from collections import OrderedDict

from . import nntp, paths, yenc

PIPELINE_WAIT_START = 30.0
WAIT_PLAY = 12.0
START_BYTES = 16 << 20


class Fetcher(object):
    def __init__(self, plan):
        self.plan = plan
        self.cv = threading.Condition()
        self.queues = [[] for _ in plan.servers]       # heaps of (priority, seq, id)
        self.started = [False] * len(plan.servers)
        self.failed = [False] * len(plan.servers)
        self.alive = [0] * len(plan.servers)           # workers still allowed (the provider's limit lowers it)
        self.pending = {}                              # id -> best priority asked
        self.taken = set()
        self.cache = OrderedDict()                     # id -> (begin, data) | None (missing)
        self.delivered = 0
        self.broken = False
        self.closed = False
        self.seq = itertools.count()

    # -- asking ---------------------------------------------------------------------------------------------------
    def want(self, message_id, priority):
        with self.cv:
            if self.closed or message_id in self.cache or message_id in self.taken:
                return
            now = self.pending.get(message_id)
            if now is not None and (priority >= now or (priority > 0 and priority > now // 2)):
                return
            self.pending[message_id] = priority
            self._queue(0, priority, message_id)

    def get(self, message_id, priority, wait, cancel=None):
        self.want(message_id, priority)
        until = time.time() + wait
        with self.cv:
            while True:
                if message_id in self.cache:
                    return self.cache[message_id], True
                if self.closed or (cancel and cancel.is_set()):
                    return None, False
                left = until - time.time()
                if left <= 0:
                    return None, False
                self.cv.wait(min(left, 0.1))

    def drop_ahead(self):
        with self.cv:
            for q in self.queues:
                q[:] = [t for t in q if t[0] <= 0 or t[2] in self.taken or t[2] in self.cache]
                heapq.heapify(q)
            self.pending = {k: v for k, v in self.pending.items() if v <= 0 or k in self.taken}

    def close(self):
        with self.cv:
            self.closed = True
            self.cv.notify_all()

    # -- inside ---------------------------------------------------------------------------------------------------
    def _queue(self, server, priority, message_id):
        while server < len(self.queues) and self.failed[server]:
            server += 1
        if server >= len(self.queues):
            if self.delivered == 0 and all(self.failed):
                self.broken = True
            self.pending.pop(message_id, None)
            self._store(message_id, None)
            return
        heapq.heappush(self.queues[server], (priority, next(self.seq), message_id))
        if not self.started[server]:
            self.started[server] = True
            self.alive[server] = self.plan.servers[server]['connections']
            for _ in range(self.plan.servers[server]['connections']):
                threading.Thread(target=self._work, args=(server,), name='nntp-fetch', daemon=True).start()
        self.cv.notify_all()

    def _store(self, message_id, value):
        self.cache[message_id] = value
        self.cache.move_to_end(message_id)
        while len(self.cache) > self.plan.keep:
            self.cache.popitem(last=False)
        self.cv.notify_all()

    def _work(self, server):
        conn, failures = None, 0
        while not self.closed:
            with self.cv:
                while not self.queues[server] and not self.closed:
                    self.cv.wait(2)
                if self.closed:
                    break
                priority, _, message_id = heapq.heappop(self.queues[server])
                if message_id in self.cache or message_id in self.taken or message_id not in self.pending:
                    continue
                self.taken.add(message_id)
            try:
                if conn is None:
                    conn = nntp.Connection(self.plan.servers[server])
                try:
                    raw = conn.body(message_id)
                except nntp.Missing:
                    with self.cv:
                        self.taken.discard(message_id)
                        self._queue(server + 1, priority, message_id)
                    continue
                decoded = yenc.decode(raw)
                value = (decoded[0], decoded[1]) if decoded else None
                failures = 0
                with self.cv:
                    self.taken.discard(message_id)
                    self.pending.pop(message_id, None)
                    if value:
                        self.delivered += 1
                    self._store(message_id, value)
            except nntp.TooMany:
                conn = None
                with self.cv:
                    self.taken.discard(message_id)
                    heapq.heappush(self.queues[server], (priority, next(self.seq), message_id))
                    if self.alive[server] > 1:                 # the provider's limit: this worker gives its place up
                        self.alive[server] -= 1
                        paths.log('server %d: connection limit, now %d' % (server + 1, self.alive[server]))
                        return
                time.sleep(2)
            except nntp.AuthError as error:
                paths.log('server %d: %s' % (server + 1, error))
                with self.cv:
                    self.taken.discard(message_id)
                    self.failed[server] = True
                    pending = [t for t in self.queues[server]]
                    self.queues[server] = []
                    for t in [(priority, 0, message_id)] + pending:
                        self._queue(server + 1, t[0], t[2])
                return
            except Exception as error:
                conn = None
                failures += 1
                with self.cv:
                    self.taken.discard(message_id)
                    if failures >= 3:
                        paths.log('server %d: %s' % (server + 1, error))
                        if self.delivered == 0:
                            self.failed[server] = True
                        failures = 0
                        self._queue(server + 1, priority, message_id)
                    else:
                        heapq.heappush(self.queues[server], (priority, next(self.seq), message_id))
                time.sleep(1)
        if conn:
            conn.close()


class Stream(object):
    def __init__(self, plan, fetcher):
        self.plan, self.fetcher, self.position = plan, fetcher, 0
        self.cancel = threading.Event()

    def _locate(self, position):
        for start, offset, length, part, ids in self.plan.extents:
            if position < start + length:
                return (start, offset, length, part, ids), offset + (position - start)
        return None, 0

    def _ahead(self, position):
        extent, offset = self._locate(position)
        if not extent:
            return
        step = max(extent[3], 256 << 10)
        for n in range(1, self.plan.ahead + 1):
            ext, off = self._locate(position + n * step)
            if not ext:
                break
            ids = ext[4]
            self.fetcher.want(ids[min(off // ext[3], len(ids) - 1)], n)

    def read(self, size):
        if self.position >= self.plan.size or size <= 0:
            return b''
        extent, offset = self._locate(self.position)
        if not extent:
            return b''
        start, _, length, part, ids = extent
        index = min(offset // part, len(ids) - 1)
        self._ahead(self.position)
        wait = PIPELINE_WAIT_START if self.position < START_BYTES else WAIT_PLAY
        begin, data = 0, b''
        for _ in range(4):
            got, _ok = self.fetcher.get(ids[index], 0, wait, self.cancel)
            if self.cancel.is_set() or self.fetcher.closed:
                raise IOError('closed')
            if self.fetcher.broken:
                raise IOError('no Usenet server can be used')
            if got is None:
                begin, data = index * part, bytes(part)
            else:
                begin, data = got
            if offset < begin and index > 0:
                index = index - 1 - min(index - 1, (begin - offset) // part)
            elif offset >= begin + len(data) and index + 1 < len(ids):
                index = min(len(ids) - 1, index + 1 + (offset - begin - len(data)) // part)
            else:
                break
        if offset < begin or offset >= begin + len(data):
            return b''
        skip = offset - begin
        give = min(len(data) - skip, size, start + length - self.position, self.plan.size - self.position)
        self.position += give
        return data[skip:skip + give]
