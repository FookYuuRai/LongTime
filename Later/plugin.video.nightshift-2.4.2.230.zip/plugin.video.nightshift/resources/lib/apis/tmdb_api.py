import re
# -*- coding: utf-8 -*-
import datetime
from apis.tvdb_api import (TVDB_BASE, _NON_LATIN, _TVDB_ORDERS, _TVDB_TOKEN, _tvdb_english_title, _tvdb_english_titles, _tvdb_image, tvdb_all_episodes, tvdb_get, tvdb_login, tvdb_order_entries, tvdb_orders, tvdb_season_data, tvdb_series_names, tvdb_test_key)  # the TVDB client lives in apis/tvdb_api.py
from caches.meta_cache import cache_function
from caches.lists_cache import lists_cache_object
from modules.settings import get_meta_filter, tmdb_api_key, lists_cache_duraton
from modules.kodi_utils import make_session, remove_keys
# from modules.kodi_utils import logger

session = make_session('https://api.themoviedb.org/3')

def tmdb_dict_removals():
	return ('adult', 'backdrop_path', 'genre_ids', 'original_language', 'original_title', 'overview', 'popularity', 'vote_count', 'video', 'origin_country', 'original_name')

def no_api_key():
	from modules.kodi_utils import notification
	notification('Please set a valid TMDb API Key')
	return []

def _premieres_sort(media, movie_field='primary_release_date'):
	"""Discover sort_by and cache-key suffix. Popularity keeps the existing cache key."""
	from modules.settings import premieres_newest_first
	if not premieres_newest_first(): return '', ''
	if media == 'movie': return '&sort_by=%s.desc' % movie_field, '_newest'
	return '&sort_by=first_air_date.desc', '_newest'

def movie_details(tmdb_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,release_dates,alternative_titles,translations,' \
		'images,keywords&include_image_language=en,null' % (tmdb_id, api_key)
		return get_tmdb(url).json()
	except: return None

def tvshow_details(tmdb_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,content_ratings,alternative_titles,translations,' \
		'images,keywords&include_image_language=en,null' % (tmdb_id, api_key)
		return get_tmdb(url).json()
	except: return None

def episode_groups_data(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'episode_groups_data_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/episode_groups?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def episode_group_details(group_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'episode_groups_details_%s' % group_id
	url = 'https://api.themoviedb.org/3/tv/episode_group/%s?api_key=%s' % (group_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def movie_set_details(collection_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/collection/%s?api_key=%s&language=en' % (collection_id, api_key)
		return get_tmdb(url).json()
	except: return None

def movie_external_id(external_source, external_id, api_key):
	try:
		string = 'movie_external_id_%s_%s' % (external_source, external_id)
		url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		result = result['movie_results']
		if result: return result[0]
		else: return None
	except: return None

def tvshow_external_id(external_source, external_id, api_key):
	try:
		string = 'tvshow_external_id_%s_%s' % (external_source, external_id)
		url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		tv_results = result.get('tv_results') or []
		if tv_results: return tv_results[0]
		# Season-split anime IMDb ids often map to an episode/season, not the show record.
		for key in ('tv_episode_results', 'tv_season_results'):
			for row in result.get(key) or []:
				show_id = row.get('show_id')
				if show_id: return {'id': show_id}
		return None
	except: return None

def tmdb_movies_oscar_winners(page_no):
	from modules.meta_lists import oscar_winners
	return oscar_winners()[page_no-1]

def tmdb_network_details(network_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_network_details_%s' % network_id
	url = 'https://api.themoviedb.org/3/network/%s?api_key=%s' % (network_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_keywords_by_query(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_keywords_by_query_%s_%s' % (query, page_no)
	url = 'https://api.themoviedb.org/3/search/keyword?api_key=%s&query=%s&page=%s' % (api_key, query, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_collections_by_query(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_collections_by_query_%s_%s' % (query, page_no)
	url = 'https://api.themoviedb.org/3/search/collection?api_key=%s&language=en-US&query=%s&page=%s' % (api_key, query, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movie_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movie_keywords_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/movie/%s/keywords?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_tv_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_keywords_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/keywords?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movie_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movie_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (api_key, tmdb_id, page_no)
	return lists_cache_object(get_data, string, url, expiration=96)

def tmdb_tv_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (api_key, tmdb_id, page_no)
	return lists_cache_object(get_data, string, url, expiration=96)

def tmdb_movie_keyword_results_direct(query, page_no):
	if tmdb_api_key() in (None, 'empty_setting', ''): return no_api_key()
	try:
		results = tmdb_movie_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_tv_keyword_results_direct(query, page_no):
	if tmdb_api_key() in (None, 'empty_setting', ''): return no_api_key()
	try:
		results = tmdb_tv_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_production_companies(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_production_companies_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s?api_key=%s&language=en-US' % ('movie' if media_type == 'movie' else 'tv', tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_tv_companies(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_studio_%s_%s' % (company_id, page_no)
	# No language/keyword exclusions here (the usual lists drop anime via keyword 210024): the studio row wants everything the studio made.
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false' \
	'&with_companies=%s&first_air_date.lte=%s&page=%s' % (api_key, company_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_studio(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_studio_%s_%s' % (company_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&with_companies=%s&page=%s' % (api_key, company_id, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_resolve_title(media_type, title, year):
	"""TMDb id for a title + year (used for AniList entries, which carry no TMDb id), or None."""
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', '') or not title: return None
	from urllib.parse import quote
	movie = media_type == 'movie'
	string = 'tmdb_resolve_%s_%s_%s' % (media_type, title, year)
	url = 'https://api.themoviedb.org/3/search/%s?api_key=%s&language=en-US&query=%s&%s=%s' % ('movie' if movie else 'tv', api_key, quote(title), 'year' if movie else 'first_air_date_year', year or '')
	try: results = cache_function(get_tmdb, string, url, expiration=720).get('results') or []
	except: return None
	if not results and year:
		return tmdb_resolve_title(media_type, title, '')
	return results[0]['id'] if results else None

def tmdb_company_id(query):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_company_id_%s' % query
	from urllib.parse import quote
	url = 'https://api.themoviedb.org/3/search/company?api_key=%s&query=%s' % (api_key, quote(query))
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_media_images(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_images_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s/images?include_image_language=en,null&api_key=%s' % (media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_media_videos(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_videos_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s/videos?api_key=%s' % (media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movies_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, json=True, expiration=min(lists_cache_duraton(), 24))

def tmdb_movies_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/movie/popular?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_popular_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/movie/day?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_blockbusters(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_blockbusters_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&sort_by=revenue.desc&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_in_theaters(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_in_theaters_%s' % page_no
	url = 'https://api.themoviedb.org/3/movie/now_playing?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_movies_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=3|2|1&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_latest_releases(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	sort_q, sort_key = _premieres_sort('movie', 'release_date')
	string = 'tmdb_movies_latest_releases%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=4|5|6%s&page=%s' % (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	sort_q, sort_key = _premieres_sort('movie')
	string = 'tmdb_movies_premieres%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=1|3|2%s&page=%s' % (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_genres=%s&language=en-US&region=US&with_original_language=en&sort_by=popularity.desc&release_date.lte=%s&page=%s' \
			% (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_languages_%s_%s' % (language, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&with_original_language=%s&sort_by=popularity.desc&release_date.lte=%s&page=%s' \
			% (api_key, language, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_certifications(certification, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_certifications_%s_%s' % (certification, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en' \
	'&certification_country=US&certification=%s&sort_by=popularity.desc&release_date.lte=%s&page=%s' % (api_key, certification, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&primary_release_year=%s&page=%s' \
							% (api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&primary_release_date.gte=%s' \
			'&primary_release_date.lte=%s&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_providers_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&watch_region=US&with_watch_providers=%s&page=%s' % (api_key, provider, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_recommendations_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/movie/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (tmdb_id, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_movies_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/movie?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, query, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_movies_companies(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_companies_%s_%s' % (company_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&with_companies=%s&page=%s' \
							% (api_key, company_id, page_no)
	return lists_cache_object(get_data, string, url, expiration=168)

def tmdb_movies_reviews(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	url = 'https://api.themoviedb.org/3/movie/%s/reviews?api_key=%s&page=%s' % (tmdb_id, api_key, page_no)
	return get_tmdb(url).json()

def tmdb_tv_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, json=True, expiration=min(lists_cache_duraton(), 24))

def tmdb_tv_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en' \
	'&without_keywords=210024&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(180, reverse=True)
	string = 'tmdb_tv_popular_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&without_keywords=210024' \
	'&include_null_first_air_dates=false&first_air_date.gte=%s' \
	'&first_air_date.lte=%s&page=%s' % (api_key, previous_date, current_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	sort_q, sort_key = _premieres_sort('tv')
	string = 'tmdb_tv_premieres%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&without_keywords=210024%s&page=%s' % (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_airing_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	expiration = min(lists_cache_duraton(), 24)
	string = 'tmdb_tv_airing_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/tv/airing_today?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024&page=%s' \
	% (api_key, page_no)
	return lists_cache_object(get_data, string, url, expiration=expiration)

def tmdb_tv_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_on_the_air_%s' % page_no
	url = 'https://api.themoviedb.org/3/tv/on_the_air?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024&page=%s' \
	% (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_tv_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&with_genres=%s&language=en-US&region=US&with_original_language=en' \
	'&include_null_first_air_dates=false&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_languages_%s_%s' % (language, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false&with_original_language=%s&first_air_date.lte=%s' \
	'&without_keywords=210024&page=%s' % (api_key, language, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_networks(network_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_networks_%s_%s' % (network_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&with_networks=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, network_id, get_current_date(), page_no)
	data = lists_cache_object(get_data, string, url)
	try: enough = len(data['results']) >= 10
	except: return data
	if enough: return data
	# Networks that mostly air non-English or anime shows (e.g. AT-X, TV Tokyo) come back empty or nearly so under the English-only / no-anime filters: retry without them.
	string = 'tmdb_tv_networks_all_%s_%s' % (network_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false' \
	'&with_networks=%s&first_air_date.lte=%s&page=%s' % (api_key, network_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_providers_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false' \
	'&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, provider, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date_year=%s&without_keywords=210024&page=%s' % (api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_aggregate_cast(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_aggregate_cast_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/aggregate_credits?api_key=%s&language=en-US' % (tmdb_id, api_key)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_recommendations_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/tv/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (tmdb_id, api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_tv_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, query, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_tv_reviews(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	url = 'https://api.themoviedb.org/3/tv/%s/reviews?api_key=%s&page=%s' % (tmdb_id, api_key, page_no)
	return get_tmdb(url).json()

def tmdb_anime_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_anime_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&page=%s' % (api_key, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_popular_recent(page_no):
	from modules.meta_lists import years_tvshows
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_anime_popular_recent_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&sort_by=first_air_date.desc&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' \
							% (api_key, years_tvshows()[0]['id'], page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(93, reverse=True)
	sort_q, sort_key = _premieres_sort('tv')
	string = 'tmdb_anime_premieres%s_%s' % (sort_key, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date.gte=%s&first_air_date.lte=%s%s&page=%s' \
							% (api_key, previous_date, current_date, sort_q, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(93, reverse=False)
	string = 'tmdb_anime_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&first_air_date.gte=%s&first_air_date.lte=%s&sort_by=first_air_date.asc&page=%s' \
							% (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(7, reverse=False)
	string = 'tmdb_anime_on_the_air_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&air_date.gte=%s&air_date.lte=%s&page=%s' \
							% (api_key, current_date, future_date, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&with_genres=%s&include_null_first_air_dates=false&first_air_date.lte=%s&page=%s' \
							% (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_providers2_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&with_keywords=210024&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false' \
	'&first_air_date.lte=%s&page=%s' % (api_key, provider, get_current_date(), page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' % (api_key, year, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_anime_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date.gte=%s' \
			'&first_air_date.lte=%s&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(get_data, string, url)

def tmdb_popular_people(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/person/popular?api_key=%s&language=en&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=48)

def tmdb_trending_people_day(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_trending_day_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/person/day?api_key=%s&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=48)

def tmdb_trending_people_week(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_trending_week_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/person/week?api_key=%s&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_people_full_info(actor_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_full_info_%s' % actor_id
	url = 'https://api.themoviedb.org/3/person/%s?api_key=%s&language=en&append_to_response=external_ids,combined_credits,images,tagged_images' % (actor_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_people_info(query, page_no=1):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_people_info_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, query, page_no)
	return cache_function(get_tmdb, string, url, expiration=4)

def season_episodes_details(tmdb_id, season_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	try:
		url = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en&append_to_response=credits' % (tmdb_id, season_no, api_key)
		return get_tmdb(url).json()
	except: return None

def get_dates(days, reverse=True):
	current_date = get_current_date(return_str=False)
	if reverse: new_date = (current_date - datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	else: new_date = (current_date + datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	return str(current_date), new_date

def get_current_date(return_str=True):
	if return_str: return str(datetime.date.today())
	else: return datetime.date.today()

def get_reviews_data(media_type, tmdb_id):
	def builder(media_type, tmdb_id):
		reviews_list, all_data = [], []
		template = '[B]%02d. %s%s[/B][CR][CR]%s'
		media_type = 'movie' if media_type in ('movie', 'movies') else 'tv'
		function = tmdb_movies_reviews if media_type  == 'movie' else tmdb_tv_reviews
		next_page, total_pages = 1, 1
		while next_page <= total_pages:
			data = function(tmdb_id, next_page)
			all_data += data['results']
			total_pages = data['total_pages']
			next_page = data['page'] + 1
		if all_data:
			for count, item in enumerate(all_data, 1):
				try:
					user = item['author'].upper()
					rating = item['author_details'].get('rating')
					if rating: rating = ' - %s/10' % str(rating).split('.')[0]
					else: rating = ''
					content = template % (count, user, rating, item['content'])
					reviews_list.append(content)
				except: pass
		return reviews_list
	string, url = 'tmdb_%s_reviews_%s' % (media_type ,tmdb_id), [media_type, tmdb_id]
	return cache_function(builder, string, url, json=False, expiration=168)

def get_data(url):
	return get_tmdb(url).json()

def get_tmdb(url):
	try: response = session.get(url, timeout=20.0)
	except: response = None
	return response

_TMDB_NOTED = set()


def _tmdb_note(message):
	if message in _TMDB_NOTED: return
	_TMDB_NOTED.add(message)
	import xbmc
	xbmc.log('[NIGHTSHIFT TMDb] %s' % message, xbmc.LOGWARNING)


def _tmdb_json(path, **params):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''):
		_tmdb_note('no TMDb API key is set: add it under Meta Accounts > TMDb. TMDb images, episode stills and TMDb metadata are skipped until then.')
		return {}
	from urllib.parse import urlencode
	query = urlencode([('api_key', api_key), ('language', 'en-US')] + [(k, v) for k, v in params.items()])
	url = 'https://api.themoviedb.org/3/%s?%s' % (path, query)
	try: return cache_function(get_tmdb, 'tmdb_json_%s_%s' % (path, query.replace(api_key, '')), url, expiration=720) or {}
	except Exception as exc:
		_tmdb_note('request %s failed: %s' % (path, exc))
		return {}

def _title_words(text):
	import re, unicodedata
	text = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode().lower()
	return [w for w in re.split(r'[^a-z0-9]+', text.replace("'", '')) if w]

def special_link_titles(media_type, title, ep_name=None, show_title=None):
	"""A special is listed on TMDb twice: as a TV 'Specials' (season 0) episode and as a movie with its own id. Given one side, the
	names of the other side, so the same file is found from either search.
	media_type 'movie': title = the movie title -> [season 0 episode titles of the show it belongs to].
	media_type 'episode': show_title + ep_name (season 0) -> [titles of the movie of the same name]. Cached; [] when nothing links."""
	out = []
	try:
		if media_type == 'movie':
			words = set(_title_words(title))
			queries, seen = [], set()
			for q in (title, str(title).split(' - ')[0], str(title).split(':')[0]):
				q = q.strip()
				if len(q) > 3 and q.lower() not in seen: seen.add(q.lower()); queries.append(q)
			for q in queries:
				for show in (_tmdb_json('search/tv', query=q).get('results') or [])[:3]:
					for ep in (_tmdb_json('tv/%s/season/0' % show['id']).get('episodes') or []):
						ew = _title_words(ep.get('name'))
						if len(ew) >= 2 and set(ew) <= words and ep.get('name') not in out:
							out.append(ep['name'])
					if out: return out
		else:
			ew = _title_words(ep_name)
			if len(ew) < 2: return out
			for q in ('%s %s' % (show_title or '', ep_name), ep_name):
				for movie in (_tmdb_json('search/movie', query=q.strip()).get('results') or [])[:5]:
					for name in (movie.get('title'), movie.get('original_title')):
						if name and set(ew) <= set(_title_words(name)) and name not in out: out.append(name)
				if out: break
	except Exception:
		pass
	return out

# ============================ Episode orders: TVDB v4 + TMDb episode groups ============================
# One list per show: Aired / DVD / Absolute / ... (TVDB, needs your TVDB API key and optional PIN) and TMDb's episode groups.
# Every order is turned into the same list of entries so browsing, playing and Autoplay's next episode all follow the chosen order.






def _title_mode():
	"""'english', 'japanese' or '' (fallback), from Skin Settings > Episode Titles (ns_title_mode)."""
	try:
		from modules.kodi_utils import get_visibility
		for value in ('english', 'japanese', 'romaji'):
			if get_visibility('String.IsEqual(Skin.String(ns_title_mode),%s)' % value): return value
	except Exception: pass
	return ''


def show_name_for_skin(meta):
	"""The show's name in the chosen title mode, from TVDB's names when the show has a TVDB id (English, Japanese, romaji), else TMDb's:
	English only -> English; Japanese only -> Japanese; romaji -> romaji; otherwise the name."""
	meta = meta or {}
	mode = _title_mode()
	names = tvdb_series_names(meta.get('tvdb_id')) if mode in ('english', 'japanese', 'romaji') else {}
	if mode == 'english': return names.get('english') or meta.get('english_title') or meta.get('title') or ''
	if mode == 'japanese': return names.get('native') or meta.get('original_title') or meta.get('title') or ''
	if mode == 'romaji': return names.get('romaji') or names.get('english') or meta.get('title') or ''
	return meta.get('title') or ''

def episode_title_for_skin(item):
	"""The episode name a list shows. Skin Settings > Episode titles (skin setting ns_title_mode):
	'' / 'fallback' (default): the English title, or the Japanese name TVDB has when it has no English one.
	'english': the English title only - else the TMDb English name, else 'Episode N'.
	'japanese': the Japanese name TVDB has; a show or episode without one shows its English title (no Japanese exists)."""
	try:
		from modules.kodi_utils import get_visibility
		mode = ''
		for value in ('english', 'japanese'):
			if get_visibility('String.IsEqual(Skin.String(ns_title_mode),%s)' % value): mode = value
	except Exception: mode = ''
	if mode == 'japanese':
		return item.get('original_title') or item.get('original') or item.get('title') or ''
	if mode == 'english':
		english = item.get('title_en') or ''
		if not english:
			title = item.get('title') or ''
			english = title if title and not _NON_LATIN.search(title) else ''
		return english or 'Episode %s' % item.get('episode', item.get('number', ''))
	return item.get('title') or ''




def order_choices(tmdb_id, tvdb_id):
	"""[{'id','name','source'}] orders for a show: TVDB ones when a key is set, then TMDb episode groups."""
	out = []
	try:
		from modules.settings import tvdb_api_key
		if tvdb_id and tvdb_api_key() not in (None, '', 'empty_setting'):
			for t, name in tvdb_orders(tvdb_id):
				out.append({'id': 'tvdb:%s' % t, 'name': '%s (TVDB)' % ('Aired Order' if t == 'official' else name), 'source': 'tvdb'})
	except Exception: pass
	try:
		from modules.metadata import episode_groups
		for g in episode_groups(tmdb_id) or []:
			out.append({'id': 'tmdb:%s' % g['id'], 'name': '%s (TMDb)' % (g.get('name') or 'Group'), 'source': 'tmdb',
						'info': '%s episodes in %s groups' % (g.get('episode_count', ''), g.get('group_count', ''))})
	except Exception: pass
	return out

def _norm_title(text):
	return ' '.join(_title_words(text))

def order_entries(order_id, meta):
	"""The episodes of an order, in order, each with the TMDb season / episode it plays as (tmdb_season / tmdb_episode; an episode TMDb does
	not list plays as Specials with its own number and is found by its name)."""
	from modules.metadata import episodes_meta, all_episodes_meta
	source, _, key = str(order_id).partition(':')
	tmdb_eps = {}
	try:
		for e in all_episodes_meta(meta, include_specials=True): tmdb_eps[(e['season'], e['episode'])] = e
	except Exception: pass
	by_title, by_air = {}, {}
	for (s, n), e in tmdb_eps.items():
		by_title.setdefault(_norm_title(e.get('title')), (s, n))
		if e.get('premiered'): by_air.setdefault((e['premiered'], n), (s, n))
	entries = []
	if source == 'tvdb':
		entries = tvdb_order_entries(meta.get('tvdb_id'), key)
		# TMDb's season 0 (specials) and regular seasons are matched separately: a special only ever maps into season 0 (by name, then by its
		# number there, then by air date there), never into a regular season; a regular episode maps by number, then by name, then by air date.
		specials_title = {}; specials_air = {}; specials_num = {}
		for (s0, n0), ep in tmdb_eps.items():
			if s0 != 0: continue
			if _norm_title(ep.get('title')): specials_title.setdefault(_norm_title(ep.get('title')), (0, n0))
			if ep.get('premiered'): specials_air.setdefault((ep['premiered'], n0), (0, n0))
			specials_num.setdefault(n0, (0, n0))
		for e in entries:
			name = _norm_title(e.get('title'))
			if e['season'] == 0:
				hit = (specials_title.get(name) if name else None) or specials_num.get(e['number']) or (specials_air.get((e['aired'], e['number'])) if e.get('aired') else None)
			else:
				same = (e['season'], e['number'])
				hit = same if same in tmdb_eps and e['season'] != 0 else None
				if not hit and name: hit = next(((s0, n0) for (s0, n0), ep in tmdb_eps.items() if s0 != 0 and _norm_title(ep.get('title')) == name), None)
				if not hit and e.get('aired'): hit = by_air.get((e['aired'], e['number']))
				if hit and hit[0] == 0: hit = None
			e['tmdb_season'], e['tmdb_episode'] = hit if hit else (e['season'], e['number'] if e.get('number') is not None else 1)
			e['mapped'] = bool(hit)
			if not e.get('title') and hit and tmdb_eps.get(hit, {}).get('title'): e['title'] = tmdb_eps[hit]['title']
			if not e.get('title_en') and hit and meta.get('tmdb_id'): e['title_en'] = tmdb_english_names(meta.get('tmdb_id'), hit[0]).get(str(hit[1])) or ''
			if hit and meta.get('tmdb_id'): e['thumb'] = tmdb_still_map(meta.get('tmdb_id'), hit[0]).get(str(hit[1])) or e['thumb']
	elif source == 'tmdb':
		details = episode_group_details(key) or {}
		pos = 0
		for grp in sorted(details.get('groups') or [], key=lambda g: g.get('order', 0)):
			for e in sorted(grp.get('episodes') or [], key=lambda x: x.get('order', 0)):
				pos += 1
				entries.append({'title': e.get('name') or '', 'aired': e.get('air_date') or '', 'season': grp.get('order', 0), 'number': e.get('order', 0) + 1, 'absolute': pos,
								'thumb': ('https://image.tmdb.org/t/p/original%s' % e['still_path']) if e.get('still_path') else '', 'plot': e.get('overview') or '', 'runtime': e.get('runtime'),
								'tmdb_season': e.get('season_number'), 'tmdb_episode': e.get('episode_number'), 'mapped': True, 'group': grp.get('name') or ''})
	for i, e in enumerate(entries): e['index'] = i
	return entries

def order_special(entry):
	"""True for an entry that is a special in its order (season 0 there, or one TMDb has only as a Special)."""
	return bool(entry) and (entry.get('season') == 0 or entry.get('tmdb_season') == 0)

# ============================ TVDB first (seasons / episodes), TMDb as the fallback ============================
_TVDB_LOGGED = set()

def tvdb_first_enabled():
	try:
		from modules.settings import tvdb_api_key
		from caches.settings_cache import get_setting
		return get_setting('nightshift.tvdb_first', 'false') == 'true' and tvdb_api_key() not in (None, '', 'empty_setting')
	except Exception: return False

def _tvdb_log(key, text):
	if key in _TVDB_LOGGED: return
	_TVDB_LOGGED.add(key)
	try:
		from modules.kodi_utils import logger
		logger('TvdbFirst', text)
	except Exception: pass




def tmdb_episode_stills(tmdb_id, season, episode):
	"""Every TMDb still of one episode (GET /tv/{id}/season/{s}/episode/{e}/images). Cached 7 days when non-empty; empty results only 6h."""
	from caches.meta_cache import meta_cache
	prop = 'tmdb_ep_stills4_%s_%s_%s' % (tmdb_id, season, episode)
	data = meta_cache.get_function(prop)
	if data is not None:
		return data
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''):
		_tmdb_note('no TMDb API key is set: add it under Meta Accounts > TMDb. Episode stills skipped.')
		return []
	path = 'tv/%s/season/%s/episode/%s/images' % (tmdb_id, int(season), int(episode))
	# Images endpoint: no language= filter (that shrinks stills). api_key query auth matches the rest of the addon.
	url = 'https://api.themoviedb.org/3/%s?api_key=%s' % (path, api_key)
	try:
		resp = get_tmdb(url)
		result = resp.json() if resp is not None else {}
	except Exception as exc:
		_tmdb_note('episode stills for tmdb %s S%sE%s failed: %s' % (tmdb_id, season, episode, exc))
		result = {}
	stills = result.get('stills') if isinstance(result, dict) else None
	data = ['https://image.tmdb.org/t/p/original%s' % i['file_path'] for i in (stills or []) if isinstance(i, dict) and i.get('file_path')]
	_tmdb_note('episode stills tmdb %s S%sE%s: %d still(s)%s' % (
		tmdb_id, season, episode, len(data),
		'' if stills is not None else ' (no stills key in response)'))
	# Cache hits for a week; empty sets only briefly so a later TMDb upload is picked up.
	meta_cache.set_function(prop, data, expiration=168 if data else 6)
	return data

def episode_name_variants(meta, season, episode):
	"""Every name an episode goes by, from TVDB: its English name, its original (Japanese) name and the name shown, for the Episode Orders
	entry that plays as this TMDb season / episode (a special included). Cached per show for a day; [] when TVDB has none."""
	from caches.meta_cache import meta_cache
	if not meta or not meta.get('tvdb_id') or not meta.get('tmdb_id'): return []
	key = 'ep_name_variants_%s' % meta.get('tmdb_id')
	table = meta_cache.get_function(key)
	if table is None:
		table = {}
		try:
			for e in order_entries('tvdb:official', meta):
				k = '%s,%s' % (e.get('tmdb_season'), e.get('tmdb_episode'))
				names = table.setdefault(k, [])
				for n in (e.get('title_en'), e.get('original'), e.get('title')):
					if n and n not in names: names.append(n)
		except Exception:
			return []
		if table: meta_cache.set_function(key, table, expiration=24)
	return list(table.get('%s,%s' % (season, episode), []))

def tmdb_english_names(tmdb_id, season):
	"""{'episode': TMDb's English episode name} for one season, cached for 7 days. Used by Episode titles: English only when TVDB has no
	English name for an episode."""
	from caches.meta_cache import meta_cache
	prop = 'tmdb_names_%s_%s' % (tmdb_id, season)
	data = meta_cache.get_function(prop)
	if data is None:
		try: eps = (season_episodes_details(tmdb_id, int(season)) or {}).get('episodes') or []
		except Exception: eps = []
		data = {str(e['episode_number']): e['name'] for e in eps if e.get('episode_number') is not None and e.get('name') and not _NON_LATIN.search(e['name'])}
		if eps: meta_cache.set_function(prop, data, expiration=168)
	return data

def tmdb_still_map(tmdb_id, season):
	"""{'episode': original-size TMDb still url} for one TMDb season, cached for 7 days. TVDB's episode images are only 400 px wide,
	TMDb's stills are the full original, so a TVDB-sourced episode keeps TVDB's data but uses this picture when TMDb has one."""
	from caches.meta_cache import meta_cache
	prop = 'tmdb_stills_%s_%s' % (tmdb_id, season)
	data = meta_cache.get_function(prop)
	if data is None:
		try: eps = (season_episodes_details(tmdb_id, int(season)) or {}).get('episodes') or []
		except Exception: eps = []
		data = {str(e['episode_number']): 'https://image.tmdb.org/t/p/original%s' % e['still_path'] for e in eps if e.get('episode_number') is not None and e.get('still_path')}
		if eps: meta_cache.set_function(prop, data, expiration=168)
	return data

def tvdb_episode_rows(meta, season):
	"""episodes_meta()-shaped rows for one season from TVDB, or None (the caller then uses TMDb)."""
	tvdb_id = meta.get('tvdb_id')
	if not tvdb_id or str(tvdb_id) in ('None', '', '0'): return None
	rows = []
	for e in tvdb_all_episodes(tvdb_id):
		if e['season'] != int(season): continue
		try: duration = int(e.get('runtime')) * 60
		except Exception: duration = 30 * 60
		rows.append({'writer': [], 'director': [], 'mediatype': 'episode', 'episode_type': '', 'episode_id': None, 'title': e.get('title') or 'Episode %s' % e['number'],
					'plot': e.get('plot') or '', 'duration': duration, 'premiered': e.get('aired') or '', 'season': e['season'], 'episode': e['number'], 'original_title': e.get('original') or '', 'title_en': e.get('title_en') or '', 'rating': 0, 'votes': 0,
					'thumb': _tvdb_image(e.get('thumb')), 'tvdb_image': _tvdb_image(e.get('thumb')), 'guest_stars': []})
	if rows:
		stills = tmdb_still_map(meta.get('tmdb_id'), season)
		for r in rows: r['thumb'] = stills.get(str(r['episode'])) or r['thumb']
	if rows:
		names = tmdb_english_names(meta.get('tmdb_id'), season)
		for r in rows:
			if not r.get('title_en'): r['title_en'] = names.get(str(r['episode'])) or ''
	# Map each TVDB row to the TMDb season/episode used for watched history and still bags.
	if rows:
		try:
			from modules.metadata import episodes_meta as _eps_meta
			tmdb_rows = _eps_meta(int(season), meta, use_tvdb_first=False) or []
		except Exception:
			tmdb_rows = []
		by_num = {}
		by_title = {}
		for tr in tmdb_rows:
			try:
				by_num[int(tr.get('episode'))] = tr
			except Exception:
				pass
			tn = (tr.get('title') or tr.get('title_en') or '').strip().lower()
			if tn:
				by_title[tn] = tr
		for r in rows:
			hit = by_num.get(int(r.get('episode') or 0))
			if not hit:
				tn = (r.get('title') or r.get('title_en') or '').strip().lower()
				hit = by_title.get(tn) if tn else None
			if hit:
				r['tmdb_season'] = int(hit.get('season') if hit.get('season') is not None else season)
				r['tmdb_episode'] = int(hit.get('episode'))
			else:
				r['tmdb_season'] = int(season)
				r['tmdb_episode'] = int(r.get('episode') or 0)
	rows.sort(key=lambda r: r['episode'])
	return rows or None
