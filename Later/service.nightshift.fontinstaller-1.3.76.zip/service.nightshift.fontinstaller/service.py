
# -*- coding: utf-8 -*-
# NightShift font installer service; downloads one pinned public GitHub Release asset.
import hashlib
import os
import tempfile
import time
import urllib.request
import zipfile
import xbmc
import xbmcaddon

ADDON_ID = 'service.nightshift.fontinstaller'
SKIN_ID = 'skin.nightshift'
PACK_URL = 'https://fookyuurai.github.io/LongTime/assets/nightshift/fontpack_combined.zip'
PACK_SHA256 = '99f85a7a2e1522446bc49bea0021df77367881f29a4b48e476c1b82a639643cc'
FONT_NAMES = ['NS_combined_base.ttf', 'NS_combined_black.ttf', 'NS_combined_blue.ttf', 'NS_combined_purple.ttf']
MAX_PACK_BYTES = 100 * 1024 * 1024
LOG_PREFIX = '[NightShift Font Installer] '

def log(message, level=xbmc.LOGINFO):
    xbmc.log(LOG_PREFIX + str(message), level)

def _download(path):
    digest = hashlib.sha256()
    size = 0
    request = urllib.request.Request(PACK_URL, headers={'User-Agent': 'NightShift-Font-Installer'})
    with urllib.request.urlopen(request, timeout=90) as response, open(path, 'wb') as target:
        while True:
            block = response.read(1024 * 1024)
            if not block:
                break
            size += len(block)
            if size > MAX_PACK_BYTES:
                raise RuntimeError('font archive exceeds safety size limit')
            target.write(block)
            digest.update(block)
    if digest.hexdigest() != PACK_SHA256:
        raise RuntimeError('font pack SHA-256 verification failed')

def install():
    skin = xbmcaddon.Addon(SKIN_ID)
    skin_path = skin.getAddonInfo('path')
    fonts_dir = os.path.join(skin_path, 'fonts')
    os.makedirs(fonts_dir, exist_ok=True)
    marker = os.path.join(fonts_dir, '.nightshift-fontpack.sha256')
    if os.path.isfile(marker):
        try:
            with open(marker, 'r', encoding='ascii') as f:
                installed = f.read().strip()
            if installed == PACK_SHA256 and all(os.path.isfile(os.path.join(fonts_dir, name)) for name in FONT_NAMES):
                return False
        except Exception:
            pass

    fd, archive_path = tempfile.mkstemp(prefix='nightshift-fonts-', suffix='.zip')
    os.close(fd)
    temp_dir = tempfile.mkdtemp(prefix='nightshift-fonts-')
    try:
        _download(archive_path)
        with zipfile.ZipFile(archive_path, 'r') as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError('font ZIP CRC check failed at ' + bad)
            found = {}
            for info in archive.infolist():
                if info.is_dir():
                    continue
                name = info.filename.replace('\\', '/')
                parts = name.split('/')
                if name.startswith('/') or any(part in ('', '.', '..') for part in parts):
                    raise RuntimeError('unsafe path in font archive')
                base = parts[-1]
                if base in FONT_NAMES:
                    if base in found:
                        raise RuntimeError('duplicate font file: ' + base)
                    data = archive.read(info)
                    if not (data.startswith(b'\x00\x01\x00\x00') or data.startswith(b'OTTO')):
                        raise RuntimeError('invalid font header: ' + base)
                    found[base] = data
        if set(found) != set(FONT_NAMES):
            raise RuntimeError('font pack is missing one or more expected font files')
        for name, data in found.items():
            target = os.path.join(temp_dir, name)
            with open(target, 'wb') as f:
                f.write(data)
        for name in FONT_NAMES:
            os.replace(os.path.join(temp_dir, name), os.path.join(fonts_dir, name))
        marker_tmp = marker + '.tmp'
        with open(marker_tmp, 'w', encoding='ascii') as f:
            f.write(PACK_SHA256 + '\n')
        os.replace(marker_tmp, marker)
        log('Installed and verified all four external fonts.')
        return True
    finally:
        try:
            os.remove(archive_path)
        except OSError:
            pass
        try:
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass

def main():
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            if install():
                # Font files are now present; reload the active skin to load them.
                if xbmc.getSkinDir() == SKIN_ID:
                    xbmc.executebuiltin('ReloadSkin')
                return
        except Exception as exc:
            log('Install attempt failed: ' + str(exc), xbmc.LOGERROR)
        # Retry on later intervals if networking was unavailable at startup.
        if monitor.waitForAbort(900):
            return

if __name__ == '__main__':
    main()
