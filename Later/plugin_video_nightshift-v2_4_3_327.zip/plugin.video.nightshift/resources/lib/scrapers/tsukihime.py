# -*- coding: utf-8 -*-
from apis import tsukihime_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, series_prefix_search_queries, scrape_expiry, scrape_timeout
from modules.settings import tsukihime_include_adult, tsukihime_scrape_active
from modules.utils import clean_file_name
from modules.kodi_utils import logger

def _tsukihime_show(info):
	"""The Tsukihime id of the show: its MyAnimeList and AniList ids come from AniList's title match."""
	try:
		from apis import anilist_api
		match = anilist_api.anime_match(info.get('title'), info.get('year'), info.get('original_title') or '') or {}
	except Exception:
		match = {}
	return tsukihime_api.show_id(mal_id=match.get('mal_id'), anilist_id=match.get('id'))

def _merge_unique(*groups):
	rows, seen = [], set()
	for group in groups:
		for row in group or []:
			if row.get('hash') and row['hash'] not in seen:
				seen.add(row['hash'])
				rows.append(row)
	return rows

class source:
	def __init__(self):
		self.scrape_provider = 'tsukihime'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not tsukihime_scrape_active():
				source_utils.diag_log('TSUKIHIME', 'SCRAPER DISABLED')
				return source_utils.internal_results(self.scrape_provider, self.sources)

			media_type = info.get('media_type')
			absolute_episode = info.get('absolute_episode')
			if media_type == 'episode' and absolute_episode:
				source_utils.diag_log('TSUKIHIME Init', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					info.get('season'), info.get('episode'), absolute_episode, info.get('ep_name') or ''))

			# 1. the show's own releases, page by page until an empty page
			show = _tsukihime_show(info)
			show_rows = tsukihime_api.search_show(show, scrape_timeout(info), scrape_expiry(info)) if show else []
			source_utils.diag_log('TSUKIHIME Show', ('id %s: %d releases' % (show, len(show_rows))) if show else 'no Tsukihime show for this title')

			# 2. name searches, targeted '<title> 01' queries first as Nyaa does
			queries = name_search_queries(info)
			queries = series_prefix_search_queries(info, queries) + queries
			if media_type == 'episode':
				title = clean_file_name(info.get('title') or '').replace('&', 'and')
				try:
					season_i = int(info.get('season'))
					for season_query in ('%s S%02d' % (title, season_i), '%s Season %s' % (title, season_i)):
						if season_query not in queries:
							queries.append(season_query)
				except Exception:
					pass
			source_utils.diag_log('TSUKIHIME Queries', 'generated=%d queries: %s' % (len(queries), ', '.join(repr(q) for q in queries)))
			name_rows = merge_name_searches(tsukihime_api.search, queries, scrape_timeout(info), scrape_expiry(info))

			files = _merge_unique(show_rows, name_rows)
			raw_count = len(files)
			include_adult = tsukihime_include_adult()
			if not include_adult:
				files = [row for row in files if not row.get('adult')]
			source_utils.diag_log('TSUKIHIME Adult', 'include adult=%s dropped=%d' % (include_adult, raw_count - len(files)))

			self.sources = filter_and_build_sources(self.scrape_provider, files, info)
			kept = len(self.sources)
			source_utils.diag_log('TSUKIHIME Match', '%s : %s kept / %s raw (%d from show, %d from names)' % (
				info.get('title', ''), kept, raw_count, len(show_rows), len(name_rows)))
			if raw_count and not self.sources:
				source_utils.diag_log('TSUKIHIME Match', 'all raw results dropped by adult, title or episode filter')

		except Exception as e:
			logger('tsukihime scraper Exception', str(e))
			source_utils.diag_log('TSUKIHIME', 'ERROR %s' % type(e).__name__)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
