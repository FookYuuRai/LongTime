# -*- coding: utf-8 -*-
"""Tsukihime (api.tsukihime.org): an anime torrent index that mirrors releases from Nyaa, NekoBT, TT and Sukebei.

Reads need no API key. The API allows about 200 requests a minute per IP: HTTP 429 is retried, honouring Retry-After for
MAX_RETRY_WAIT seconds at most, so a scrape never waits long. The internal scraper (scrapers/tsukihime.py) reads a show's releases by its Tsukihime id, then searches by name;
both return release rows in the shape every native indexer uses."""
from __future__ import annotations

import threading
import time
from typing import Any
from urllib.parse import urlencode
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, json_http, normalize_info_hash, safe_get

BASE_URL = 'https://api.tsukihime.org'
MAX_PAGE_SIZE = 100       # the API's maximum limit
MAX_PAGES = 40           # the same page ceiling as Nyaa: a name search reads every page up to this
DEFAULT_TIMEOUT = 15      # seconds
USABLE_STATES = ('unprocessed', 'processing', 'completed')   # 'skipped' and 'error' releases are not offered
SUKEBEI_SOURCE = 2                                           # Sukebei is an adult index: its releases count as adult
REQUEST_INTERVAL = 0.35                                      # seconds between requests: about 170 a minute, under the 200 a minute fair-use limit
MAX_RETRY_WAIT = 30                                          # Retry-After is honoured up to this many seconds

TORRENT_STATES = ('unprocessed', 'processing', 'completed', 'skipped', 'error')
SOURCES = {0: 'other', 1: 'Nyaa', 2: 'Sukebei', 3: 'NekoBT'}
TORRENT_SOURCE_SLUGS = ('nyaa', 'nekobt', 'tt', 'sukebei')
EXTERNAL_ANIME_SERVICES = ('mal', 'anilist', 'anidb')


_pace_lock = threading.Lock()
_last_request = [0.0]


def _pace():
	"""Keep consecutive requests REQUEST_INTERVAL apart, so a search never bursts past the fair-use limit."""
	with _pace_lock:
		wait = REQUEST_INTERVAL - (time.monotonic() - _last_request[0])
		if wait > 0:
			time.sleep(wait)
		_last_request[0] = time.monotonic()


class TsukihimeError(Exception):
	"""Raised on HTTP errors, error envelopes, or exhausted retries."""


class TsukihimeAPI:
	def __init__(self, timeout=DEFAULT_TIMEOUT, max_retries=3):
		self.timeout = timeout
		self.max_retries = max_retries

	# ------------------------------------------------------------------
	# Low-level request handling
	# ------------------------------------------------------------------

	def _get(self, path, params=None):
		"""GET a path such as '/v1/torrents', retrying politely on 429."""
		clean = {}
		for key, value in (params or {}).items():
			if value is None:
				continue
			if isinstance(value, bool):
				value = 'true' if value else 'false'
			clean[key] = str(value)
		url = BASE_URL + path
		if clean:
			url += '?' + urlencode(clean)
		for attempt in range(1, self.max_retries + 1):
			_pace()
			resp = safe_get(json_http(), url, self.timeout)
			if resp.status_code == 429:
				delay = self._retry_delay(resp, attempt)
				if attempt < self.max_retries and delay is not None:
					time.sleep(delay)
					continue
				raise TsukihimeError('rate limited (HTTP 429) for %s' % path)
			if resp.status_code >= 400:
				raise TsukihimeError('HTTP %s for %s' % (resp.status_code, path))
			data = resp.json()
			if isinstance(data, dict) and data.get('error') is True:
				raise TsukihimeError('API returned an error for %s' % path)
			return data
		raise TsukihimeError('Gave up on %s after %d attempts' % (path, self.max_retries))

	@staticmethod
	def _retry_delay(resp, attempt):
		"""Retry-After in seconds when the API gives it, up to MAX_RETRY_WAIT; None when the wait is longer than that.
		Without a usable header, a short exponential back-off."""
		try:
			seconds = float(resp.headers.get('Retry-After', ''))
		except (TypeError, ValueError):
			return float(min(2 ** attempt, 8))
		return seconds if 0 <= seconds <= MAX_RETRY_WAIT else None

	# ------------------------------------------------------------------
	# Torrents
	# ------------------------------------------------------------------

	def list_torrents(self, limit: int = 50, offset: int = 0,
					  sort_by: str = "source_date", order: str = "desc",
					  **filters: Any) -> dict[str, Any]:
		"""Releases, newest first by default.

		sort_by: source_date | added_date | totalsize
		Filters: state, main_source, is_adult, has_nzb, category,
				 anime_id, group_id, audiolang, sublang
		"""
		return self._get("/v1/torrents", {
			"limit": limit, "offset": offset,
			"sort_by": sort_by, "order": order, **filters,
		})

	def get_torrent(self, torrent_id: int) -> dict[str, Any]:
		"""One release with its anime, group, files, and tracker stats."""
		return self._get(f"/v1/torrents/{torrent_id}")

	def get_torrent_by_btih(self, btih: str) -> dict[str, Any]:
		"""Look up a release by its 40-character info-hash."""
		return self._get(f"/v1/torrents/btih/{btih}")

	def get_torrent_by_source(self, source: str, eid: int) -> dict[str, Any]:
		"""Look up a release by its tracker ID. source: nyaa | nekobt | tt | sukebei."""
		if source not in TORRENT_SOURCE_SLUGS:
			raise ValueError(f"source must be one of {TORRENT_SOURCE_SLUGS}")
		return self._get(f"/v1/torrents/{source}/{eid}")

	def get_torrent_file(self, torrent_id: int, file_id: int) -> dict[str, Any]:
		"""One file inside a release: hashes, mediainfo, direct links, attachments."""
		return self._get(f"/v1/torrents/{torrent_id}/file/{file_id}")

	# ------------------------------------------------------------------
	# Search
	# ------------------------------------------------------------------

	def search_torrents(self, q: str, limit: int = 50, offset: int = 0,
						**filters: Any) -> dict[str, Any]:
		"""Full-text search. Supports `a | b`, `-word`, and "exact phrase".

		Filters: audiolang, sublang, anime_id, group_id, category
		"""
		return self._get("/v1/search/torrents", {
			"q": q, "limit": limit, "offset": offset, **filters,
		})

	def basic_search(self, query: str, offset: int = 0,
					 max_results: int | None = None) -> list[dict[str, Any]]:
		"""Every result for a name search, largest first.

		Pages through the search endpoint 100 results at a time, from `offset`,
		until the API has no more results. A broad query can mean many requests,
		so pass `max_results` to stop after that many. The collected results are
		then sorted by `totalsize`, largest first.
		"""
		if len(query.strip()) < 2:
			raise ValueError("Search query must be at least 2 characters.")
		if max_results is not None and max_results < 1:
			raise ValueError("max_results must be at least 1.")

		collected: list[dict[str, Any]] = []
		seen_ids: set[Any] = set()
		next_offset = offset

		while True:
			page = self.search_torrents(query, limit=MAX_PAGE_SIZE, offset=next_offset)
			results = page.get("results") or []
			if not results:
				break

			for item in results:
				key = item.get("id")
				if key is not None:
					if key in seen_ids:
						continue          # the same release can shift onto two pages
					seen_ids.add(key)
				collected.append(item)
			next_offset += len(results)

			if max_results is not None and len(collected) >= max_results:
				break

			total = page.get("total")
			if isinstance(total, int):
				if next_offset >= total:
					break
			elif len(results) < MAX_PAGE_SIZE:
				break                     # short page with no total: this was the last one

		ranked = sorted(collected, key=lambda t: t.get("totalsize") or 0, reverse=True)
		return ranked[:max_results] if max_results is not None else ranked

	# ------------------------------------------------------------------
	# Anime
	# ------------------------------------------------------------------

	def get_schedule(self, days: int = 7) -> dict[str, Any]:
		"""Airing schedule for the next N days."""
		return self._get("/v1/schedule", {"days": days})

	def get_seadex(self, limit: int = 48, offset: int = 0, q: str | None = None) -> dict[str, Any]:
		"""Seadex index, optionally filtered by title."""
		return self._get("/v1/seadex", {"limit": limit, "offset": offset, "q": q})

	def get_seadex_entry(self, anilist_id: int) -> dict[str, Any]:
		"""Seadex entry for one AniList ID."""
		return self._get(f"/v1/seadex/{anilist_id}")

	def list_animes(self, limit: int = 50, offset: int = 0,
					sort: str = "season", order: str = "desc",
					**filters: Any) -> dict[str, Any]:
		"""Anime index. sort: season | alphabetical | last_updated. Filters: q, air_status, is_movie."""
		return self._get("/v1/animes", {
			"limit": limit, "offset": offset, "sort": sort, "order": order, **filters,
		})

	def get_anime(self, anime_id: int | str, limit: int = 50, offset: int = 0) -> dict[str, Any]:
		"""One show plus its releases."""
		return self._get(f"/v1/animes/{anime_id}", {"limit": limit, "offset": offset})

	def get_anime_by_external(self, service: str, external_id: int) -> dict[str, Any]:
		"""Look up a show by MyAnimeList, AniList, or AniDB ID. service: mal | anilist | anidb."""
		if service not in EXTERNAL_ANIME_SERVICES:
			raise ValueError(f"service must be one of {EXTERNAL_ANIME_SERVICES}")
		return self._get(f"/v1/animes/{service}/{external_id}")

	def get_anime_groups(self, anime_id: int, limit: int = 40, offset: int = 0,
						 sort: str = "count_desc", q: str | None = None) -> dict[str, Any]:
		"""Release groups that have published for one show."""
		return self._get(f"/v1/animes/{anime_id}/groups", {
			"limit": limit, "offset": offset, "sort": sort, "q": q,
		})

	# ------------------------------------------------------------------
	# Episodes
	# ------------------------------------------------------------------

	def get_episodes(self, anime_id: int) -> dict[str, Any]:
		"""Episodes of a show that have releases."""
		return self._get(f"/v1/animes/{anime_id}/episodes")

	def get_episode(self, anime_id: int, episode: int | str,
					limit: int = 50, offset: int = 0) -> dict[str, Any]:
		"""Releases for one episode. Pass 'null' for the uncategorised bucket."""
		return self._get(f"/v1/animes/{anime_id}/episodes/{episode}", {
			"limit": limit, "offset": offset,
		})

	# ------------------------------------------------------------------
	# Groups
	# ------------------------------------------------------------------

	def list_groups(self, limit: int = 50, offset: int = 0, q: str | None = None,
					sort: str = "alpha_asc", include_all: bool = False) -> dict[str, Any]:
		"""Release groups. sort: alpha_asc | alpha_desc | count_desc."""
		return self._get("/v1/groups", {
			"limit": limit, "offset": offset, "q": q,
			"sort": sort, "include_all": include_all,
		})

	def get_group(self, group_id: int, limit: int = 50, offset: int = 0) -> dict[str, Any]:
		"""One group plus its releases."""
		return self._get(f"/v1/groups/{group_id}", {"limit": limit, "offset": offset})

	def get_group_anime(self, group_id: int, anime_id: int,
						limit: int = 50, offset: int = 0) -> dict[str, Any]:
		"""One group's releases for one show."""
		return self._get(f"/v1/groups/{group_id}/animes/{anime_id}", {
			"limit": limit, "offset": offset,
		})

	def get_group_series(self, group_id: int, limit: int = 48, offset: int = 0,
						 q: str | None = None) -> dict[str, Any]:
		"""Shows a group has released, optionally filtered by title."""
		return self._get(f"/v1/groups/{group_id}/series", {
			"limit": limit, "offset": offset, "q": q,
		})

	# ------------------------------------------------------------------
	# System
	# ------------------------------------------------------------------

	def health(self) -> dict[str, Any]:
		"""Liveness probe with database status."""
		return self._get("/healthz")

	def stats(self) -> dict[str, Any]:
		"""Platform totals: shows, files, and release states."""
		return self._get("/v1/stats")



def release_rows(payload):
	"""A payload as release rows (hash, name, size in GB, seeders, adult), the shape the native indexers use.
	Dropped: releases not in a usable state (skipped, error) and releases without a hash. Legacy AnimeTosho imports are kept.
	Adult releases are kept and flagged: Sukebei releases count as adult, and the scraper decides whether they are shown."""
	rows = []
	for item in (payload or {}).get('results') or []:
		if not isinstance(item, dict):
			continue
		info_hash = normalize_info_hash(item.get('btih'))
		name = (item.get('name') or '').strip()
		if not info_hash or not name or item.get('state') not in USABLE_STATES:
			continue
		adult = bool(item.get('is_adult')) or item.get('main_source') == SUKEBEI_SOURCE
		rows.append({'hash': info_hash, 'name': name, 'size': bytes_to_gb(item.get('totalsize')), 'seeders': 0, 'adult': adult})
	return rows


def _read_pages(fetch, label, max_pages=MAX_PAGES):
	"""Every page of one listing, in order, from fetch(offset). Stops at the last page, at an empty page, at the total, or at
	max_pages (Nyaa's ceiling). Returns (rows, complete): complete is False when a page failed part-way."""
	rows, seen, pages = [], set(), 0
	try:
		for page in range(max(int(max_pages), 1)):
			offset = page * MAX_PAGE_SIZE
			payload = fetch(offset)
			pages += 1
			results = (payload or {}).get('results') or []
			for row in release_rows(payload):
				if row['hash'] not in seen:
					seen.add(row['hash'])
					rows.append(row)
			total = (payload or {}).get('total')
			if not results or len(results) < MAX_PAGE_SIZE:
				break
			if isinstance(total, int) and offset + len(results) >= total:
				break
		else:
			logger('tsukihime api', 'page ceiling %d reached (%s, %d releases)' % (max_pages, label, len(rows)))
		return rows, True
	except Exception as e:
		logger('tsukihime api', '%s: %s (%s) after %d pages' % (type(e).__name__, str(e)[:160], label, pages))
		return rows, False


def show_id(mal_id=None, anilist_id=None, timeout=10):
	"""The Tsukihime id of a show, found by its MyAnimeList id, then its AniList id. None when Tsukihime does not have it.
	Found ids and 'not on Tsukihime' answers are cached for a day; a failed lookup is not cached."""
	client = TsukihimeAPI(timeout=timeout)
	for service, external_id in (('mal', mal_id), ('anilist', anilist_id)):
		if not external_id:
			continue
		cache_key = 'TSUKIHIME_SHOWID_%s_%s' % (service, external_id)
		cached = main_cache.get(cache_key)
		if cached is not None:
			if cached:
				return cached
			continue
		try:
			found = client.get_anime_by_external(service, int(external_id))
		except Exception as e:
			if 'HTTP 404' in str(e):
				main_cache.set(cache_key, 0, expiration=24)
			else:
				logger('tsukihime api', '%s lookup %s: %s' % (service, external_id, str(e)[:160]))
			continue
		show = (found or {}).get('id') if isinstance(found, dict) else None
		if isinstance(show, int) and show > 0:
			main_cache.set(cache_key, show, expiration=24)
			return show
		main_cache.set(cache_key, 0, expiration=24)
	return None


def search_show(anime_id, timeout=10, expiration=24, max_pages=MAX_PAGES):
	"""Every release of one Tsukihime show, page by page until an empty page. This is the show's own list, not a name search.
	Cached per show."""
	cache_key = 'TSUKIHIME_SHOW_%s' % anime_id
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	client = TsukihimeAPI(timeout=timeout)
	rows, complete = _read_pages(lambda offset: client.get_anime(anime_id, limit=MAX_PAGE_SIZE, offset=offset),
								 'show %s' % anime_id, max_pages)
	if rows and complete:
		main_cache.set(cache_key, rows, expiration=expiration)
	return rows


def clear_tsukihime_cache():
	try:
		main_cache.delete_like('TSUKIHIME_%')
		return True
	except Exception:
		return False


def search(query, timeout=10, expiration=24, max_pages=MAX_PAGES):
	"""Release rows for one name search, read page by page as search_show is. Cached per query. merge_name_searches calls
	this once per query."""
	query = (query or '').strip()
	if len(query) < 2:
		return []
	cache_key = 'TSUKIHIME_%s' % query
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	client = TsukihimeAPI(timeout=timeout)
	rows, complete = _read_pages(lambda offset: client.search_torrents(query, limit=MAX_PAGE_SIZE, offset=offset), query, max_pages)
	if rows and complete:
		main_cache.set(cache_key, rows, expiration=expiration)
	return rows
