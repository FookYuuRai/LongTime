import json

import os

import shutil

from datetime import datetime

from caches.base_cache import database_locations, locations, make_database

from modules import kodi_utils, settings

from modules.import_export_utils import offer_save_export_directory, pick_export_folder, settings_privacy_warning, settings_import_reminders

DEBUG_EXPORT_HIDE = (
    'ad.account_id',
    'ad.token',
    'aiostreams.custom_url',
    'aiostreams.instance_name',
    'aiostreams.password',
    'aiostreams.profiles',
    'aiostreams.username',
    'comet.custom_url',
    'comet.url_name',
    'easynews_password',
    'easynews_user',
    'fanarttv_api',
    'folder1.display_name',
    'folder1.movies_directory',
    'folder1.tv_shows_directory',
    'folder2.display_name',
    'folder2.movies_directory',
    'folder2.tv_shows_directory',
    'folder3.display_name',
    'folder3.movies_directory',
    'folder3.tv_shows_directory',
    'folder4.display_name',
    'folder4.movies_directory',
    'folder4.tv_shows_directory',
    'folder5.display_name',
    'folder5.movies_directory',
    'folder5.tv_shows_directory',
    'knaben.custom_url',
    'mdblist.client',
    'mdblist.refresh',
    'mdblist.token',
    'mdblist.user',
    'mediafusion.custom_url',
    'mediafusion.url_name',
    'nzb.unpack_folder',
    'nzb1.key',
    'nzb1.label',
    'nzb1.url',
    'nzb10.key',
    'nzb10.label',
    'nzb10.url',
    'nzb11.key',
    'nzb11.label',
    'nzb11.url',
    'nzb12.key',
    'nzb12.label',
    'nzb12.url',
    'nzb13.key',
    'nzb13.label',
    'nzb13.url',
    'nzb14.enabled',
    'nzb14.key',
    'nzb14.label',
    'nzb14.url',
    'nzb15.key',
    'nzb15.label',
    'nzb15.url',
    'nzb16.key',
    'nzb16.label',
    'nzb16.url',
    'nzb17.key',
    'nzb17.label',
    'nzb17.url',
    'nzb18.key',
    'nzb18.label',
    'nzb18.url',
    'nzb19.key',
    'nzb19.label',
    'nzb19.url',
    'nzb2.key',
    'nzb2.label',
    'nzb2.url',
    'nzb20.key',
    'nzb20.label',
    'nzb20.url',
    'nzb21.key',
    'nzb21.label',
    'nzb21.url',
    'nzb22.key',
    'nzb22.label',
    'nzb22.url',
    'nzb23.key',
    'nzb23.label',
    'nzb23.url',
    'nzb24.key',
    'nzb24.label',
    'nzb24.url',
    'nzb25.key',
    'nzb25.label',
    'nzb25.url',
    'nzb3.key',
    'nzb3.label',
    'nzb3.url',
    'nzb4.key',
    'nzb4.label',
    'nzb4.url',
    'nzb5.key',
    'nzb5.label',
    'nzb5.url',
    'nzb6.key',
    'nzb6.label',
    'nzb6.url',
    'nzb7.key',
    'nzb7.label',
    'nzb7.url',
    'nzb8.key',
    'nzb8.label',
    'nzb8.url',
    'nzb9.key',
    'nzb9.label',
    'nzb9.url',
    'oc.account_id',
    'oc.token',
    'omdb_api',
    'piratebay.custom_url',
    'playback.opensubs_api_key',
    'playback.opensubs_password',
    'playback.opensubs_token',
    'playback.opensubs_username',
    'playback.submaker_manifest',
    'pm.account_id',
    'pm.token',
    'punchplay.client',
    'punchplay.device_id',
    'punchplay.expires',
    'punchplay.refresh',
    'punchplay.token',
    'punchplay.user',
    'rd.account_id',
    'rd.client_id',
    'rd.refresh',
    'rd.secret',
    'rd.token',
    'rpdb_api',
    'rpdb_format',
    'simkl.client',
    'simkl.refresh',
    'simkl.token',
    'simkl.user',
    'tb.token',
    'tmdb.account_id',
    'tmdb.account_session_id',
    'tmdb.lists_read_token',
    'tmdb.session_id',
    'tmdb.token',
    'tmdb.username',
    'tmdb_api',
    'torrentdownloads.custom_url',
    'torrentio.custom_url',
    'torz.custom_url',
    'torz.url_name',
    'trakt.client',
    'trakt.expires',
    'trakt.refresh',
    'trakt.secret',
    'trakt.token',
    'trakt.user',
    'tvdb_api',
    'tvdb_pin',
    'usenet1.host',
    'usenet1.password',
    'usenet1.port',
    'usenet1.user',
    'usenet10.host',
    'usenet10.password',
    'usenet10.port',
    'usenet10.user',
    'usenet11.host',
    'usenet11.password',
    'usenet11.port',
    'usenet11.user',
    'usenet12.host',
    'usenet12.password',
    'usenet12.port',
    'usenet12.user',
    'usenet13.host',
    'usenet13.password',
    'usenet13.port',
    'usenet13.user',
    'usenet14.host',
    'usenet14.password',
    'usenet14.port',
    'usenet14.user',
    'usenet15.host',
    'usenet15.password',
    'usenet15.port',
    'usenet15.user',
    'usenet16.host',
    'usenet16.password',
    'usenet16.port',
    'usenet16.user',
    'usenet17.host',
    'usenet17.password',
    'usenet17.port',
    'usenet17.user',
    'usenet18.host',
    'usenet18.password',
    'usenet18.port',
    'usenet18.user',
    'usenet19.host',
    'usenet19.password',
    'usenet19.port',
    'usenet19.user',
    'usenet2.host',
    'usenet2.password',
    'usenet2.port',
    'usenet2.user',
    'usenet20.host',
    'usenet20.password',
    'usenet20.port',
    'usenet20.user',
    'usenet21.host',
    'usenet21.password',
    'usenet21.port',
    'usenet21.user',
    'usenet22.host',
    'usenet22.password',
    'usenet22.port',
    'usenet22.user',
    'usenet23.host',
    'usenet23.password',
    'usenet23.port',
    'usenet23.user',
    'usenet24.host',
    'usenet24.password',
    'usenet24.port',
    'usenet24.user',
    'usenet25.host',
    'usenet25.password',
    'usenet25.port',
    'usenet25.user',
    'usenet3.host',
    'usenet3.password',
    'usenet3.port',
    'usenet3.user',
    'usenet4.host',
    'usenet4.password',
    'usenet4.port',
    'usenet4.user',
    'usenet5.host',
    'usenet5.password',
    'usenet5.port',
    'usenet5.user',
    'usenet6.host',
    'usenet6.password',
    'usenet6.port',
    'usenet6.user',
    'usenet7.host',
    'usenet7.password',
    'usenet7.port',
    'usenet7.user',
    'usenet8.host',
    'usenet8.password',
    'usenet8.port',
    'usenet8.user',
    'usenet9.host',
    'usenet9.password',
    'usenet9.port',
    'usenet9.user',
    'wetrakr.token',
    'wetrakr.user',
    'zilean.custom_url',
    'zilean.url_name',
)

AUTOPOPULATED_SETTINGS = (
    'services.expiry_alert_state',
    'thumbnail_cleanup_last_run',
    'usenet1.port',
    'usenet10.port',
    'usenet11.port',
    'usenet12.port',
    'usenet13.port',
    'usenet2.port',
    'usenet3.port',
    'usenet4.port',
    'usenet5.port',
    'usenet6.port',
    'usenet7.port',
    'usenet8.port',
    'usenet9.port',
)

def _json_cell(value):
    if isinstance(value, (bytes, bytearray, memoryview)):
        return '<%d bytes>' % len(value)
    return value

def _tables_json(con):
    tables = {}
    names = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    for name in names:
        cur = con.execute('SELECT * FROM "%s"' % name.replace('"', '""'))
        cols = [c[0] for c in cur.description]
        tables[name] = [{c: _json_cell(v) for c, v in zip(cols, row)} for row in cur.fetchall()]
    return tables

def _db_as_json(src):
    """Every table of one SQLite database as a list of row dicts, read directly and read-only as 2.4.3.311 did. Only if that fails
    (for example while the database is in use) is a copy made beside it, read and removed afterwards."""
    import shutil, sqlite3
    try:
        con = sqlite3.connect('file:%s?mode=ro' % src, uri=True, timeout=2)
        try:
            return _tables_json(con)
        finally:
            con.close()
    except sqlite3.Error:
        pass
    copy = src + '.export-copy'
    for stale in (copy, copy + '-wal', copy + '-shm'):
        if os.path.isfile(stale):
            os.remove(stale)
    try:
        shutil.copyfile(src, copy)
        for side in ('-wal', '-shm'):
            if os.path.isfile(src + side):
                shutil.copyfile(src + side, copy + side)
        con = sqlite3.connect(copy)
        try:
            return _tables_json(con)
        finally:
            con.close()
    finally:
        for path in (copy, copy + '-wal', copy + '-shm'):
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except Exception:
                pass

def _write_settings_json(folder, payload):
    """Write the export to the chosen folder: settings.json, or settings-<date-time>.json when settings.json is already there.
    When Kodi cannot write there, the file goes to the add-on's Import Export folder, which needs no extra access. Returns (path, note)."""
    def write(directory):
        name = 'settings.json'
        if kodi_utils.path_exists(os.path.join(directory, name)):
            name = 'settings-%s.json' % datetime.now().strftime('%Y%m%d-%H%M%S')
        path = os.path.join(directory, name)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=1, ensure_ascii=False, default=str)
        return path
    try:
        if not kodi_utils.path_exists(folder, folder=True):
            try:
                kodi_utils.make_directory(folder)
            except OSError as e:
                if e.errno != 17:
                    raise
        return write(folder), ''
    except OSError as e:
        fallback = os.path.join(kodi_utils.addon_profile(), 'Import Export')
        if not kodi_utils.path_exists(fallback, folder=True):
            try:
                kodi_utils.make_directory(fallback)
            except OSError as e2:
                if e2.errno != 17:
                    raise
        path = write(fallback)
        return path, 'Could not write to the chosen folder (%s). Saved in the add-on folder instead.' % (e.strerror or e)

def export_settings_debug(params):
    """The settings database as settings.json. Settings named in DEBUG_EXPORT_HIDE or AUTOPOPULATED_SETTINGS are left out."""
    if not kodi_utils.confirm_dialog(heading='Export settings (debug)',
            text='This file holds every NIGHTSHIFT setting, including any logins, API keys, tokens, usernames and server addresses that are not left out.[CR][CR]Do not post it publicly.',
            ok_label='Export', cancel_label='Cancel', default_control=11, scroll=True):
        return
    folder = pick_export_folder(heading='Choose export folder')
    if not folder:
        return
    try:
        src = database_locations('settings_db')
        if not os.path.isfile(src):
            return kodi_utils.ok_dialog(heading='Export settings (debug)', text='Nothing to export on this device.')
        all_rows = _db_as_json(src).get('settings', [])
        left_out = set(DEBUG_EXPORT_HIDE) | set(AUTOPOPULATED_SETTINGS)
        rows = [r for r in all_rows if r.get('setting_id') not in left_out]
        left = len(all_rows) - len(rows)
        stamp = datetime.now()
        payload = {'database': 'settings.db', 'nightshift_version': str(_addon_version()), 'exported': stamp.strftime('%Y-%m-%dT%H:%M:%S'),
                   'rows_per_table': {'settings': len(rows)}, 'left_out': left, 'tables': {'settings': rows}}
        saved_to, note = _write_settings_json(folder, payload)
    except Exception as e:
        return kodi_utils.ok_dialog(heading='Export failed', text=str(e))
    text = 'Saved %s[CR]%d setting(s) written, %d left out.' % (saved_to, len(rows), left)
    if note:
        text += '[CR]' + note
    kodi_utils.ok_dialog(heading='Export complete', text=text)
    if not note:
        offer_save_export_directory(folder)

def _addon_version():
	try:
		return kodi_utils.addon_info('version') or ''
	except:
		return ''
