# -*- coding: utf-8 -*-
from caches.settings_cache import get_setting, set_setting, default_setting_values, _EXTRAS_LIST_DEFAULT
from modules.kodi_utils import translate_path, get_property, addon_profile, make_directory
from modules.kodi_utils import logger

def tmdb_api_key():
	return get_setting('nightshift.tmdb_api', '')

def tmdb_lists_read_token():
	return get_setting('nightshift.tmdb.lists_read_token', '')

def trakt_client():
	return get_setting('nightshift.trakt.client', '')

def related_fallback_mode():
	"""Related source when Trakt is unavailable: both | tmdb | simkl | off."""
	mode = get_setting('nightshift.related_fallback', 'both')
	return mode if mode in ('both', 'tmdb', 'simkl', 'off') else 'both'

def simkl_client():
	"""Simkl Client ID entered by the user in Meta Accounts (no key is shipped); placeholder counts as empty."""
	value = (get_setting('nightshift.simkl.client', '') or '').strip()
	return '' if value in ('API_HERE', 'empty_setting') else value

def mdblist_client():
	value = (get_setting('nightshift.mdblist.client', '') or '').strip()
	return '' if value in ('API_HERE', 'empty_setting', '0') else value

def trakt_secret():
	return get_setting('nightshift.trakt.secret', '')

def trakt_user_active():
	from caches.settings_cache import settings_cache
	val = settings_cache.read_db_value('trakt.user')
	return val not in (None, 'empty_setting', '')

def simkl_user_active():
	from caches.settings_cache import settings_cache
	user = settings_cache.read_db_value('simkl.user')
	token = settings_cache.read_db_value('simkl.token')
	return user not in (None, 'empty_setting', '') and token not in (None, '0', '', 'empty_setting')

def mdblist_user_active():
	from caches.settings_cache import settings_cache
	user = settings_cache.read_db_value('mdblist.user')
	token = settings_cache.read_db_value('mdblist.token')
	# The refresh token is optional: MDBList does not always hand one out, and requiring it made the account look
	# signed out (no My Lists / list search, watched marks never sent to MDBList).
	return (user not in (None, 'empty_setting', '')
		and token not in (None, '0', '', 'empty_setting'))

def punchplay_user_active():
	"""Authorised when a usable access token exists (username is display-only)."""
	from caches.settings_cache import settings_cache, get_setting
	token = settings_cache.read_db_value('punchplay.token')
	if token in (None, '0', '', 'empty_setting'):
		token = get_setting('nightshift.punchplay.token', '0')
	return token not in (None, '0', '', 'empty_setting')

def punchplay_sync_interval():
	setting = get_setting('nightshift.punchplay.sync_interval', '60')
	try: interval = max(5, int(setting))
	except: interval = 60
	return interval, interval * 60

def wetrakr_user_active():
	from caches.settings_cache import settings_cache
	user = settings_cache.read_db_value('wetrakr.user')
	token = settings_cache.read_db_value('wetrakr.token')
	return user not in (None, 'empty_setting', '') and token not in (None, '0', '', 'empty_setting')

def wetrakr_scrobble_enabled():
	return get_setting('nightshift.wetrakr.scrobble', 'true') == 'true'

def mdblist_sync_interval():
	setting = get_setting('nightshift.mdblist.sync_interval', '60')
	try: interval = max(5, int(setting))
	except: interval = 60
	return interval, interval * 60

def simkl_sync_interval():
	setting = get_setting('nightshift.simkl.sync_interval', '60')
	try: interval = max(5, int(setting))
	except: interval = 60
	return interval, interval * 60

def tmdblist_user_active():
	return get_setting('nightshift.tmdb.account_id', 'empty_setting') not in (None, 'empty_setting', '')

def results_format():
	results_window_numbers_dict = {'List': 2000, 'Rows': 2001, 'WideList': 2002}
	window_format = str(get_setting('nightshift.results.list_format', 'List'))
	if not window_format in results_window_numbers_dict:
		window_format = 'List'
		set_setting('results.list_format', window_format)
	window_number = results_window_numbers_dict[window_format]
	return window_format.lower(), window_number

def store_resolved_to_cloud(debrid_service, pack):
	setting_value = int(get_setting('nightshift.store_resolved_to_cloud.%s' % debrid_service.lower(), '0'))
	return setting_value in (1, 2) if pack else setting_value == 1

def enabled_debrids_check(debrid_service):
	if not get_setting('nightshift.%s.enabled' % debrid_service) == 'true': return False
	return authorized_debrid_check(debrid_service)

def authorized_debrid_check(debrid_service):
	if get_setting('nightshift.%s.token' % debrid_service) in (None, '', 'empty_setting'): return False
	return True

def playback_key():
	return 'media'

def playback_settings():
	return (int(get_setting('nightshift.playback.watched_percent', '90')), int(get_setting('nightshift.playback.resume_percent', '5')))

def playback_watched_percent():
	"""Percent at which playback writes a local watched tick. Follows Watched Status Provider."""
	return 80 if watched_indicators() in (1, 2) else 90

def limit_resolve():
	return get_setting('nightshift.playback.limit_resolve', 'false') == 'true'

def movies_directory():
	return translate_path(get_setting('nightshift.movies_directory'))
	
def tv_show_directory():
	return translate_path(get_setting('nightshift.tv_shows_directory'))

def download_directory(media_type):
	download_directories_dict = {'movie': 'nightshift.movie_download_directory', 'episode': 'nightshift.tvshow_download_directory', 'thumb_url': 'nightshift.image_download_directory',
								'image_url': 'nightshift.image_download_directory','image': 'nightshift.image_download_directory', 'premium': 'nightshift.premium_download_directory',
								None: 'nightshift.premium_download_directory', 'None': False}
	return translate_path(get_setting(download_directories_dict[media_type]))

_IMPORT_EXPORT_DIR_DEFAULT = 'special://profile/addon_data/plugin.video.nightshift/Import Export/'

def import_export_directory_setting():
	# Virtual path for Kodi browse dialogs (works on all platforms).
	path = get_setting('nightshift.import_export_directory', '')
	if path in ('', 'None', None, 'empty_setting'):
		return _IMPORT_EXPORT_DIR_DEFAULT
	return path

def import_export_directory():
	# Filesystem path for os.path / file I/O.
	return translate_path(import_export_directory_setting())

def ensure_import_export_directory():
	path = import_export_directory()
	try:
		make_directory(path)
	except OSError as e:
		if e.errno != 17:
			raise
	return path

WATCHLIST_UNAIRED_ACTIONS = frozenset((
	'trakt_watchlist', 'trakt_watchlist_lists',
	'mdblist_watchlist',
	'punchplay_watchlist', 'punchplay_plantowatch',
	'simkl_plantowatch',
))

def show_unaired_watchlist():
	return get_setting('nightshift.show_unaired_watchlist', 'true') == 'true'

def hide_unaired_watchlist_item(action, unaired):
	return bool(unaired) and action in WATCHLIST_UNAIRED_ACTIONS and not show_unaired_watchlist()

def lists_cache_duraton():
	return int(get_setting('nightshift.lists_cache_duraton', '48'))

def premieres_newest_first():
	"""Content > Premieres & Latest Releases Sort: date-desc instead of popularity."""
	return get_setting('nightshift.tmdb.premieres_sort', '0') == '1'

def auto_start_nightshift():
	return get_setting('nightshift.auto_start_nightshift', 'false') == 'true'

def source_folders_directory(media_type, source):
	setting = 'nightshift.%s.movies_directory' % source if media_type == 'movie' else 'nightshift.%s.tv_shows_directory' % source
	if get_setting(setting) not in ('', 'None', None): return translate_path( get_setting(setting))
	else: return False

def episodes_include_airdate():
	return get_setting('nightshift.episodes.include_airdate', 'true') == 'true'

def hide_episode_thumb():
	return get_setting('nightshift.hide_episode_thumb', 'false') == 'true'

def hide_episode_plot():
	return get_setting('nightshift.hide_episode_plot', 'false') == 'true'

def avoid_episode_spoilers():
	return hide_episode_thumb() or hide_episode_plot()

def spoiler_key():
	return (1 if hide_episode_thumb() else 0) + (2 if hide_episode_plot() else 0)

def show_loading_plot():
	return get_setting('nightshift.show_loading_plot', 'true') == 'true'

def paginate(is_home):
	paginate_lists = int(get_setting('nightshift.paginate.lists', '0'))
	if is_home: return paginate_lists in (2, 3)
	else: return paginate_lists in (1, 3)

def page_limit(is_home):	
	return int(get_setting({True: 'nightshift.paginate.limit_widgets', False: 'nightshift.paginate.limit_addon'}[is_home], '20'))

def quality_filter(setting):
	return get_setting('nightshift.%s' % setting).split(', ')

def quality_sort_order():
	'''User order for Results Sorting when Quality is a key. Lower index = higher in list.'''
	default = ['4K', '1080p', '720p', 'SD']
	raw = get_setting('nightshift.results.quality_sort_order', '4K, 1080p, 720p, SD')
	parts = [i.strip() for i in (raw or '').split(',') if i.strip()]
	if sorted(parts) != sorted(default): return default[:]
	return parts

def sort_to_top_filter(autoplay):
	return {0: False, 1: False if autoplay else True, 2: True if autoplay else False, 3: True}[int(get_setting('nightshift.filter.sort_to_top', '0'))]

def prefer_release_groups(autoplay):
	try: value = int(get_setting('nightshift.filter.prefer_release_groups', '0'))
	except: value = 0
	return {0: False, 1: False if autoplay else True, 2: True if autoplay else False, 3: True}.get(value, False)

def audio_filters():
	setting = get_setting('nightshift.filter_audio')
	if setting in ('empty_setting', ''): return []
	return setting.split(', ')

def preferred_filters():
	setting = get_setting('nightshift.filter.preferred_filters')
	if setting in ('empty_setting', ''): return []
	return setting.split(', ')

def include_prerelease_results():
	return int(get_setting('nightshift.filter.include_prerelease', '0')) == 0

def auto_enable_subs():
	return get_setting('nightshift.playback.auto_enable_subs', 'false') == 'true'

def subtitles_source():
	return get_setting('nightshift.playback.subs_source', '0')

def subtitles_source_options():
	options = {'0': 'Local Subtitles'}
	if submaker_manifest_configured(): options['1'] = 'SubMaker'
	if opensubs_configured(): options['2'] = 'OpenSubtitles'
	return options

def refresh_playback_subs_source():
	from caches.settings_cache import get_setting, set_setting
	opts = subtitles_source_options()
	current = str(get_setting('nightshift.playback.subs_source', '0'))
	if current not in opts:
		if current == '2':
			current = '1' if '1' in opts else '0'
		elif current == '1':
			current = '2' if '2' in opts else '0'
		else:
			current = '0'
		set_setting('playback.subs_source', current)

def submaker_enabled():
	return subtitles_source() == '1'

def opensubs_enabled():
	return subtitles_source() == '2'

def submaker_manifest():
	manifest = get_setting('nightshift.playback.submaker_manifest', 'empty_setting')
	if manifest == 'empty_setting': return ''
	return manifest.strip()

def submaker_manifest_configured():
	manifest = submaker_manifest()
	return bool(manifest) and 'manifest' in manifest

def opensubs_api_key():
	try:
		from apis.opensubs_api import effective_api_key
		return effective_api_key()
	except: return ''

def opensubs_username():
	value = get_setting('nightshift.playback.opensubs_username', 'empty_setting')
	return '' if value in (None, '', '0', 'empty_setting') else str(value).strip()

def opensubs_password():
	value = get_setting('nightshift.playback.opensubs_password', 'empty_setting')
	return '' if value in (None, '', '0', 'empty_setting') else str(value).strip()

def opensubs_configured():
	return bool(opensubs_username()) and bool(opensubs_password())

def subs_alert_fetch_configured():
	return submaker_manifest_configured() or opensubs_configured()

def alert_timing_options(next_episode=False):
	options = {'0': 'Playback Percentage', '1': 'Chapter Info', '2': 'Subtitles Info'}
	if next_episode:
		options['3'] = 'IntroDB Info'
	if not subs_alert_fetch_configured():
		options.pop('2', None)
	return options

def refresh_alert_timing_settings():
	from caches.settings_cache import get_setting, set_setting, settings_cache
	settings_cache.clear_db_cache()
	changed = False
	for setting_id in ('stinger_alert.alert_timing', 'autoplay_alert_timing', 'autoscrape_alert_timing'):
		opts = alert_timing_options(next_episode=(setting_id != 'stinger_alert.alert_timing'))
		current = str(get_setting('nightshift.%s' % setting_id, '1'))
		if current not in opts:
			fallback = '1' if '1' in opts else '0'
			set_setting(setting_id, fallback)
			current = fallback
			changed = True
		try:
			settings_cache.set_memory_cache('%s_name' % setting_id, opts.get(current, ''))
		except: pass
	return changed

def submaker_language():
	return get_setting('nightshift.playback.submaker_language_name', 'English')

def subs_language():
	return submaker_language()

FORCED_LOCAL_SUBS_LANGUAGE_INDEX = '42'

def subs_language_is_forced_local():
	return str(get_setting('nightshift.playback.submaker_language', '0')) == FORCED_LOCAL_SUBS_LANGUAGE_INDEX

def subs_language_for_download():
	if subs_language_is_forced_local(): return 'English'
	return subs_language()

_KODI_SUBTITLE_LANG_SKIP = frozenset(('original', 'original only', 'mediadefault', 'default', 'forced only', 'forced'))

def kodi_subtitle_language():
	try:
		import xbmc
		value = xbmc.getSetting('locale.subtitlelanguage')
	except: return ''
	if not value: return ''
	value = str(value).strip()
	if value.lower() in _KODI_SUBTITLE_LANG_SKIP: return ''
	try:
		name = xbmc.convertLanguage(value, xbmc.ENGLISH_NAME)
		if name and name.lower() not in ('unknown', ''): return name
	except: pass
	return value

def subs_language_preferences():
	if subs_language_is_forced_local(): return []
	prefs = []
	red_light = subs_language()
	if red_light: prefs.append(red_light)
	kodi_lang = kodi_subtitle_language()
	if kodi_lang and (not red_light or kodi_lang.lower() != red_light.lower()):
		prefs.append(kodi_lang)
	return prefs

def submaker_prefer_local():
	return get_setting('nightshift.playback.submaker_prefer_local', 'true') == 'true'

def subs_show_notifications():
	return get_setting('nightshift.playback.subs_show_notifications', 'true') == 'true'

def progress_cleared_alert(media_type='episode'):
	return get_setting('nightshift.progress_cleared.%s' % ('movie' if media_type == 'movie' else 'episode'), 'true') == 'true'

def stingers_show():
	return get_setting('nightshift.stinger_alert.show', 'false') == 'true'

def _alert_timing_mode(setting_id, default='1'):
	value = get_setting('nightshift.%s' % setting_id, default)
	return {'0': 'off', '1': 'chapters', '2': 'subtitles', '3': 'introdb'}.get(str(value), 'chapters')

def stingers_alert_timing():
	return _alert_timing_mode('stinger_alert.alert_timing', '1')

def stingers_use_chapters():
	return stingers_alert_timing() == 'chapters'

def stingers_percentage():
	return int(get_setting('nightshift.stinger_alert.window_percentage', '90'))

def include_anime_tvshow():
	return get_setting('nightshift.include_anime_tvshow', 'false') == 'true'

def show_public_calendars():
	return get_setting('nightshift.show_public_calendars', 'false') == 'true'

def public_calendar_include_anime():
	return get_setting('nightshift.public_calendar_include_anime', 'true') == 'true'

def public_tv_calendar_source():
	"""Preferred source for Public TV Calendar: 'simkl' or 'trakt'. Anime always uses AniList."""
	try:
		choice = int(get_setting('nightshift.public_tv_calendar_source', '0'))
	except (TypeError, ValueError):
		choice = 0
	return 'trakt' if choice == 1 else 'simkl'


def public_calendar_removed(list_name):
	'''True when the user removed the Public (Anime) Calendar from that menu with the menu editor.'''
	key = 'anime' if list_name == 'AnimeList' else 'tv'
	return get_setting('nightshift.public_calendar_removed_%s' % key, 'false') == 'true'

def set_public_calendar_removed(list_name, removed):
	key = 'anime' if list_name == 'AnimeList' else 'tv'
	set_setting('public_calendar_removed_%s' % key, 'true' if removed else 'false')

def public_calendar_max_items():
	"""0 = unlimited; otherwise 1–2000 listitem cap after the day window."""
	try: value = int(get_setting('nightshift.public_calendar_max_items', '0'))
	except (TypeError, ValueError): value = 0
	if value <= 0: return 0
	return max(1, min(2000, value))

def public_calendar_cache_list():
	return get_setting('nightshift.public_calendar_cache_list', 'true') == 'true'

def anime_seasons_episode_group_fallback():
	return get_setting('nightshift.anime.seasons_episode_group_fallback', 'false') == 'true'

def auto_play(media_type):
	return get_setting('nightshift.auto_play_%s' % media_type, 'false') == 'true'

def autoplay_next_episode():
	if auto_play('episode') and get_setting('nightshift.autoplay_next_episode', 'false') == 'true': return True
	else: return False

def skip_intro_mode():
	try:
		return int(get_setting('nightshift.autoplay_skip_intro', '0'))
	except:
		return 0

def skip_intro_all_episodes():
	return get_setting('nightshift.skip_intro_all_episodes', 'true') == 'true'

def _skip_intro_chain_play_type(play_type):
	return play_type in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual')

def skip_intro_enabled(play_type):
	if skip_intro_mode() == 0:
		return False
	if _skip_intro_chain_play_type(play_type):
		return True
	return skip_intro_all_episodes()

def skip_intro_auto_approved(play_type):
	return skip_intro_mode() == 2 and skip_intro_enabled(play_type)

def skip_intro_needs_prompt(play_type):
	return skip_intro_mode() == 1 and skip_intro_enabled(play_type)

def autoplay_skip_intro_mode():
	return skip_intro_mode()

def autoplay_skip_intro_enabled(play_type):
	return skip_intro_enabled(play_type)

def autoplay_skip_intro_auto(play_type):
	return skip_intro_auto_approved(play_type)

def autoscrape_next_episode():
	if not auto_play('episode') and get_setting('nightshift.autoscrape_next_episode', 'false') == 'true': return True
	else: return False

def any_alert_uses_subtitle_timing(media_type='episode'):
	if media_type == 'episode':
		if autoplay_next_episode() and _alert_timing_mode('autoplay_alert_timing') == 'subtitles': return True
		if autoscrape_next_episode() and _alert_timing_mode('autoscrape_alert_timing') == 'subtitles': return True
	elif media_type == 'movie' and stingers_show() and stingers_alert_timing() == 'subtitles':
		return True
	return False

def subs_alert_fetch_enabled(media_type='episode'):
	return any_alert_uses_subtitle_timing(media_type) and subs_alert_fetch_configured()

def autoscrape_confirm():
	return get_setting('nightshift.autoscrape_confirm', 'false') == 'true'

def autoplay_prescrape(scrape_provider):
	return get_setting('nightshift.autoplay.%s' % scrape_provider, 'false') == 'true'

NEXTEP_SCRAPE_MARGIN_SEC = 30
NEXTEP_COMMAND_HEADROOM_SEC = 15
NEXTEP_AUTOSCRAPE_MIN_HEADROOM_SEC = 90
NEXTEP_ALERT_MAX_REMAINING_SEC = 20
NEXTEP_ALERT_MIN_REMAINING_SEC = 20
NEXTEP_CREDITS_ENTRY_GAP_SEC = 15
NEXTEP_INTRODB_BUFFER_SEC = 5
NEXTEP_STOP_NOTIFY_REMAINING_SEC = 90

def nextep_pipeline_headroom(play_type, scraper_time, still_watching_due=False):
	# Scrape budget (results.timeout + NEXTEP_SCRAPE_MARGIN_SEC) plus time for still-watching / autoscrape confirm dialogs.
	headroom = int(scraper_time)
	if still_watching_due:
		headroom += NEXTEP_COMMAND_HEADROOM_SEC
	if 'autoscrape' in play_type and autoscrape_confirm():
		headroom += NEXTEP_COMMAND_HEADROOM_SEC
	if 'autoscrape' in play_type:
		headroom = max(headroom, NEXTEP_AUTOSCRAPE_MIN_HEADROOM_SEC)
	return headroom

def auto_nextep_settings(play_type):
	play_type = 'autoplay' if play_type == 'autoplay_nextep' else 'autoscrape'
	window_percentage = 100 - int(get_setting('nightshift.%s_next_window_percentage' % play_type, '95'))
	alert_timing = _alert_timing_mode('%s_alert_timing' % play_type, '3')
	watching_check = int(get_setting('nightshift.autoplay_watching_check', '3'))
	scraper_time = int(get_setting('nightshift.results.timeout', '60')) + NEXTEP_SCRAPE_MARGIN_SEC
	if play_type == 'autoplay':
		alert_method = int(get_setting('nightshift.autoplay_alert_method', '0'))
		default_action = {'0': 'play', '1': 'cancel', '2': 'pause'}[get_setting('nightshift.autoplay_default_action', '1')]
	else: alert_method, default_action = '', ''
	return {'scraper_time': scraper_time, 'window_percentage': window_percentage, 'alert_method': alert_method,
			'default_action': default_action, 'alert_timing': alert_timing, 'watching_check': watching_check}

def filter_status(filter_type):
	return int(get_setting('nightshift.filter.%s' % filter_type, '0'))

def limit_number_quality():
	return int(get_setting('nightshift.results.limit_number_quality', '0'))

def limit_number_total():
	return int(get_setting('nightshift.results.limit_number_total', '0'))

def trakt_sync_interval():
	setting = get_setting('nightshift.trakt.sync_interval', '60')
	interval = int(setting) * 60
	return setting, interval

def lists_sort_order(setting):
	return int(get_setting('nightshift.sort.%s' % setting, '0'))

def personal_lists_sort_unseen_to_top():
	return get_setting('nightshift.personal_list.sort_unseen_to_top') == 'true'

def personal_lists_unseen_highlight():
	if get_setting('nightshift.personal_list.highlight_unseen', 'false') == 'false': return None
	return get_setting('nightshift.personal_list.unseen_highlight', 'FF4DDBFF')

def personal_lists_show_author():
	return get_setting('nightshift.personal_list.show_author', 'true') == 'true'

def show_specials():
	return get_setting('nightshift.show_specials', 'false') == 'true'

def exclude_specials_from_progress():
	return get_setting('nightshift.exclude_specials_progress', 'true') == 'true'

def single_ep_unwatched_episodes():
	return get_setting('nightshift.single_ep_unwatched_episodes', 'false') == 'true'

def single_ep_unwatched_in_title():
	# Nested under Provide Unwatched Episodes Info — both must be on.
	return single_ep_unwatched_episodes() and get_setting('nightshift.single_ep_unwatched_in_title', 'false') == 'true'

def single_ep_display_format(is_external):
	if is_external: setting, default = 'nightshift.single_ep_display_widget', '1'
	else: setting, default = 'nightshift.single_ep_display', ''
	return int(get_setting(setting, default))

def single_ep_widget_omit_tvshowtitle():
	"""Widgets only: skip TVShowTitle info tag so skins don't show show name under Label."""
	return get_setting('nightshift.single_ep_widget_omit_tvshowtitle', 'false') == 'true'

def single_ep_widget_omit_season_episode():
	"""Widgets only: skip Season/Episode info tags (Label still has SxE via Display Format)."""
	return get_setting('nightshift.single_ep_widget_omit_season_episode', 'false') == 'true'

def calendar_display_format(is_external):
	if is_external:
		setting, default = 'nightshift.trakt.calendar_display_widget', '1'
	else:
		setting, default = 'nightshift.trakt.calendar_display', '0'
	return int(get_setting(setting, default))

def easynews_active():
	if get_setting('nightshift.provider.easynews', 'false') == 'true': easynews_status = easynews_authorized()
	else: easynews_status = False
	return easynews_status

def easynews_playback_method(query):
	method = int(get_setting('nightshift.easynews.playback_method', '0'))
	queries = {'retry': lambda: method in (1, 3), 'non_seek': lambda: method in (2, 3),
				'direct_play': lambda: method in (2, 3) and get_setting('nightshift.easynews.playback_method_limited', 'false') != 'true'}
	setting = queries[query]()
	return setting

def easynews_playback_method_retries():
	return int(get_setting('nightshift.easynews.playback_method_retries', '1')) + 1

def easynews_authorized():
	easynews_user = get_setting('nightshift.easynews_user', 'empty_setting')
	easynews_password = get_setting('nightshift.easynews_password', 'empty_setting')
	if easynews_user in ('empty_setting', '') or easynews_password in ('empty_setting', ''): easynews_status = False
	else: easynews_status = True
	return easynews_status

def nzb_indexer_active():
	"""True when NZB Indexers are enabled and at least one slot is configured."""
	if get_setting('nightshift.provider.nzb', 'false') != 'true': return False
	for slot in range(1, 26):
		if get_setting('nightshift.nzb%d.enabled' % slot, 'false') != 'true': continue
		url = get_setting('nightshift.nzb%d.url' % slot, '')
		key = get_setting('nightshift.nzb%d.key' % slot, '')
		if url not in ('', 'empty_setting') and key not in ('', 'empty_setting'): return True
	return False

def animetosho_nzb_enabled():
	"""AnimeTosho's own NZBs (no indexer account or key needed): on when NZB Indexers is on and the AnimeTosho NZB toggle is on."""
	return get_setting('nightshift.provider.nzb', 'false') == 'true' and get_setting('nightshift.animetosho.nzb', 'false') == 'true'

def usenet_direct_active():
	"""True when at least one direct Usenet (NNTP) provider is enabled with an address."""
	for slot in range(1, 26):
		if get_setting('nightshift.usenet%d.enabled' % slot, 'false') != 'true': continue
		if get_setting('nightshift.usenet%d.host' % slot, '') not in ('', 'empty_setting'): return True
	try:                                   # servers typed into the NNTP Stream add-on itself count too
		from apis import usenet_stream
		return usenet_stream.addon_has_servers()
	except Exception: return False

_HOST_PREFIXES = ('news', 'nntp', 'nntps', 'ssl', 'secure', 'us', 'eu', 'uk', 'de', 'nl', 'au', 'ca', 'fr', 'eu2', 'us2', 'usa', 'europe')

def usenet_host_name(host):
	"""'ssl-eu.xsusenet.com' / 'news.newshosting.com' / 'news.eweka.nl' -> 'xsusenet' / 'newshosting' / 'eweka' (the company, not the server)."""
	try:
		host = (host or '').split('://')[-1].split('/')[0].rsplit('@', 1)[-1].split(':')[0].strip().lower()
		parts = [p for p in host.split('.') if p]
		if len(parts) < 2: return host
		if parts[-2] in ('co', 'com', 'org', 'net') and len(parts) >= 3 and len(parts[-1]) == 2: name = parts[-3]
		else: name = parts[-2]
		return name
	except Exception:
		return ''

def usenet_provider_hosts():
	"""Hosts of the enabled direct Usenet providers (this add-on's slots, then the NNTP Stream add-on's own servers), in order."""
	hosts = []
	for slot in range(1, 26):
		if get_setting('nightshift.usenet%d.enabled' % slot, 'false') != 'true': continue
		host = get_setting('nightshift.usenet%d.host' % slot, '')
		if host in ('', 'empty_setting'): continue
		host = host.split('://')[-1].split('/')[0].rsplit('@', 1)[-1].split(':')[0].strip()
		if host and host not in hosts: hosts.append(host)
	try:
		from apis import usenet_stream
		module = usenet_stream.addon()
		if module:
			from nntpstream import settings as addon_settings
			for url in addon_settings.own_servers():
				host = url.split('://')[-1].rsplit('@', 1)[-1].split(':')[0].split('/')[0].strip()
				if host and host not in hosts: hosts.append(host)
	except Exception: pass
	return hosts

def usenet_provider_label():
	"""Host of the first enabled direct Usenet provider."""
	hosts = usenet_provider_hosts()
	return hosts[0] if hosts else ''

def usenet_provider_name():
	"""The Usenet provider results play from, for the results list: 'NEWSHOSTING' (the first enabled one; backups are not counted)."""
	for host in usenet_provider_hosts():
		name = usenet_host_name(host)
		if name: return name.upper()
	return 'USENET'

def nzb_verify_playable():
	"""Check each NZB result against the direct Usenet providers (articles exist, film not compressed/encrypted) before listing it."""
	return get_setting('nightshift.nzb.verify_playable', 'true') == 'true' and usenet_direct_active()

def nzb_check_limit():
	"""New NZB downloads one search may spend on the archive / playability checks (largest results first). 0 = check everything."""
	try: return max(0, min(200, int(get_setting('nightshift.nzb.check_limit', '15'))))
	except (TypeError, ValueError): return 15

def nzb_unpack_folder():
	"""The folder packed (RAR / ZIP) NZB releases are unpacked to and played from, or '' (off)."""
	if get_setting('nightshift.nzb.unpack_enabled', 'true') != 'true': return ''
	value = (get_setting('nightshift.nzb.unpack_folder', '') or '').strip()
	if value:
		try:
			import xbmcvfs
			value = xbmcvfs.translatePath(value)
		except Exception: pass
	return value

def nzb_unpack_prefer_local():
	return get_setting('nightshift.nzb.unpack_prefer_local', 'false') == 'true'

def nzb_unpack_limit_gb():
	try: return max(0, int(get_setting('nightshift.nzb.unpack_limit_gb', '100')))
	except (TypeError, ValueError): return 100

def nzb_playback_mode():
	"""'0' Auto (TorBox when cached, else direct), '1' direct Usenet only, '2' TorBox only."""
	return get_setting('nightshift.usenet.playback', '0')

def nzb_use_direct(cached=False):
	"""Should this NZB play straight from the Usenet provider (NNTP) rather than via TorBox?"""
	mode = nzb_playback_mode()
	if mode == '2' or not usenet_direct_active(): return False
	if mode == '1': return True
	return not (cached and authorized_debrid_check('tb'))

def nzb_scrape_active():
	"""NZB title scrape — indexers plus a way to play: TorBox Pro usenet and/or direct Usenet (NNTP)."""
	if not (nzb_indexer_active() or animetosho_nzb_enabled()): return False
	mode = nzb_playback_mode()
	torbox = authorized_debrid_check('tb')
	if mode == '2': return torbox
	if mode == '1': return usenet_direct_active()
	return torbox or usenet_direct_active()

def _any_debrid_account():
	return any(enabled_debrids_check(i) for i in ('rd', 'pm', 'ad', 'oc', 'tb'))

def internal_scrapers_enabled():
	return get_setting('nightshift.provider.internal', 'false') == 'true'

def _native_torrent_scrape_active(scraper):
	return internal_scrapers_enabled() and get_setting('nightshift.provider.%s' % scraper, 'false') == 'true' and _any_debrid_account()

def comet_scrape_active():
	return _native_torrent_scrape_active('comet')

def torrentio_scrape_active():
	return _native_torrent_scrape_active('torrentio')

def torz_scrape_active():
	return _native_torrent_scrape_active('torz')

def mediafusion_scrape_active():
	return _native_torrent_scrape_active('mediafusion')

def zilean_scrape_active():
	return _native_torrent_scrape_active('zilean')

def piratebay_scrape_active():
	return _native_torrent_scrape_active('piratebay')

def knaben_scrape_active():
	return _native_torrent_scrape_active('knaben')

def tsukihime_scrape_active():
	return _native_torrent_scrape_active('tsukihime')

def tsukihime_include_adult():
	return get_setting('nightshift.tsukihime.include_adult', 'false') == 'true'

def torrentdownloads_scrape_active():
	return _native_torrent_scrape_active('torrentdownloads')

def nyaa_scrape_active():
	return _native_torrent_scrape_active('nyaa')

def animetosho_scrape_active():
	return _native_torrent_scrape_active('animetosho')


def nzb_search_width():
	return int(get_setting('nightshift.nzb.search_width', '0'))

NZB_QUALITY_TYPES = ('main', 'epname', '2160p remux', '2160p web', '1080p remux', '1080p bd', '1080p web', '720p', 'hdtv', 'dvd')

NZB_QUALITY_DEFAULT = 'epname, 2160p remux, 2160p web, 1080p remux, 1080p bd, 1080p web, 720p, hdtv, dvd'      # the plain main search is off: the type searches replace it

def nzb_quality_search():
	"""On / off (the old 'By quality + Remux' value 2 counts as on)."""
	return get_setting('nightshift.nzb.quality_search', '1') not in ('0', 'false', '')

def nzb_quality_types(media_type=None):
	"""The release types to search for by name, in the order of NZB_QUALITY_TYPES, limited to qualities the Results filter allows."""
	raw = get_setting('nightshift.nzb.quality_types', NZB_QUALITY_DEFAULT)
	chosen = [t.strip() for t in str(raw).split(',') if t.strip() in NZB_QUALITY_TYPES]
	if media_type:
		try: wanted = quality_filter('results_quality_%s' % media_type)
		except Exception: wanted = []
		need_free = ('main', 'epname')
		need = {'2160p': ('4K',), '1080p': ('1080p',), '720p': ('720p',), 'hdtv': ('1080p', '720p'), 'dvd': ('SD',)}
		chosen = [t for t in chosen if t not in need_free and any(q in wanted for q in need[t.split()[0]]) or t in need_free]
	return [t for t in NZB_QUALITY_TYPES if t in chosen]

def nzb_results_per_type():
	"""Search by Quality: how many releases of each type are listed (the largest ones)."""
	try: return max(1, int(get_setting('nightshift.nzb.results_per_type', '15')))
	except Exception: return 15

def nzb_checks_per_type():
	"""Search by Quality: how many of each type's listed releases get the health check (the largest ones)."""
	try: return max(1, int(get_setting('nightshift.nzb.checks_per_type', '2')))
	except Exception: return 2

def results_screen_cache_minutes():
	"""How long the finished results list of a title / episode is kept so reopening it is instant (0 = off)."""
	try: return max(0, int(get_setting('nightshift.results.screen_cache', '30')))
	except Exception: return 30

def nzb_fallback_search():
	return get_setting('nightshift.nzb.fallback_search', 'true') == 'true'

def aiostreams_authorized():
	username = get_setting('nightshift.aiostreams.username', 'empty_setting')
	password = get_setting('nightshift.aiostreams.password', 'empty_setting')
	if username in ('empty_setting', '') or password in ('empty_setting', ''): return False
	return True

def aiostreams_active():
	from apis.aiostreams_api import ENABLED
	if not ENABLED: return False
	if get_setting('nightshift.provider.aiostreams', 'false') == 'true': return aiostreams_authorized()
	return False

def aiostreams_preserve_order():
	return get_setting('nightshift.aiostreams.preserve_order', 'true') == 'true'

def extras_enable_extra_ratings():
	# Meta / Tom(Critic, User) / IMDb score badges (an OMDb request per title) are removed from the Extras page.
	return False

def extras_enabled_ratings():
	# Audience/user scores (Tom/User) are removed from the Extras page.
	return [i for i in get_setting('nightshift.extras.enabled_ratings', 'Meta, Tom/Critic, Tom/User, IMDb, TMDb').split(', ') if i != 'Tom/User']

def extras_enable_item_ratings():
	# Per-item star ratings are removed.
	return False

def extras_enable_scrollbars():
	return get_setting('nightshift.extras.enable_scrollbars', 'false')

def extras_enabled():
	setting = get_setting('nightshift.extras.enabled', '2000,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062')
	if setting in ('', None, 'noop', []): return []
	split_setting = setting.split(',')
	# Reviews (2056), Trakt Comments (2057) and the removed AI Similar list (2055) are not shown on the Extras page.
	enabled = [int(i) for i in split_setting if int(i) not in (2055, 2056, 2057)]
	# From Studio (2067) is new: switch it on for saved lists made before it existed (the saved order lacks it too).
	saved_order = (get_setting('nightshift.extras.order', _EXTRAS_LIST_DEFAULT) or '').split(',')
	for new_id in (2067, 2068, 2069, 2070, 2071, 2072, 2073):
		if new_id not in enabled and str(new_id) not in saved_order: enabled.append(new_id)
	return enabled

def extras_order():
	setting = get_setting('nightshift.extras.order', _EXTRAS_LIST_DEFAULT)
	if setting in ('', None, 'noop', []): return []
	split_setting = setting.split(',')
	order = [int(i) for i in split_setting if i.strip() and int(i) != 2055]
	# From Studio (2067) is new: place it right after Cast (or first) for saved orders made before it existed.
	# English Dub Cast (2068) goes right after Cast too, ahead of From Studio.
	for new_id in (2073, 2072, 2071, 2070, 2069, 2067, 2068):
		if new_id not in order: order.insert(order.index(2051) + 1 if 2051 in order else 0, new_id)
	# Manual Theme Chooser (2074) is new: it can be enabled and ordered from the Extras settings; it is added at the end for saved orders.
	if 2074 not in order: order.insert(order.index(2050) + 1 if 2050 in order else 0, 2074)
	return order

def recommend_service_options():
	"""Because You Watched services — hide options that need missing auth/keys."""
	options = {'0': 'Recommended (TMDb)', '1': 'More Like This (IMDb)'}
	if trakt_user_active(): options['3'] = 'Related (Trakt)'
	return options

def recommend_service():
	try: ind = int(get_setting('nightshift.recommend_service', '0'))
	except (TypeError, ValueError): ind = 0
	opts = recommend_service_options()
	if str(ind) in opts: return ind
	return 0

def recommend_seed():
	return int(get_setting('nightshift.recommend_seed', '5'))

def tv_progress_location():
	return int(get_setting('nightshift.tv_progress_location', '0'))

def check_prescrape_sources(scraper, media_type):
	"""Prescrape only when Check Before Full Search is enabled for that provider."""
	if scraper in ('animetosho', 'nyaa', 'comet', 'torz', 'torrentio', 'mediafusion', 'zilean', 'piratebay', 'torrentdownloads', 'knaben', 'tsukihime'):
		return False
	if scraper in ('easynews', 'aiostreams', 'nzb', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'oc_cloud', 'tb_cloud'):
		return get_setting('nightshift.check.%s' % scraper) == 'true'
	if scraper == 'folders':
		return get_setting('nightshift.check.folders') == 'true'
	if get_setting('nightshift.check.%s' % scraper) == 'true' and auto_play(media_type):
		return True
	return False

def prescrape_enabled(media_type, active_scrapers=None):
	if active_scrapers is None:
		active_scrapers = active_internal_scrapers()
	return any(check_prescrape_sources(scraper, media_type) for scraper in active_scrapers)

def cloud_scrape_before_external(scraper):
	"""Run debrid cloud scrapers before external torrent scrapers when the provider is enabled."""
	cloud_scrapers = {
		'rd_cloud': 'provider.rd_cloud',
		'pm_cloud': 'provider.pm_cloud',
		'ad_cloud': 'provider.ad_cloud',
		'oc_cloud': 'provider.oc_cloud',
		'tb_cloud': 'provider.tb_cloud',
	}
	if scraper in cloud_scrapers:
		return get_setting('nightshift.%s' % cloud_scrapers[scraper]) == 'true'
	return False

EXTERNAL_SCRAPER_SLOT_COUNT = 3

# Fen-style torrent packs shown first in Choose Module when already installed.
# Other still lists every xbmc.python.module. Empty slots are never auto-assigned.
# Chain Scrapers is omitted on purpose — Gears from the same repository is preferred.
KNOWN_EXTERNAL_SCRAPERS = (
	('script.module.classyscrapers', 'Classy Scrapers'),
	('script.module.cocoscrapers', 'CocoScrapers Module'),
	('script.module.diamondscrapers', 'Diamond Scrapers'),
	('script.module.gearsscrapers', 'Gears Scrapers'),
	('script.module.magneto', 'Magneto Module'),
	('plugin.program.taz19scrapers', 'Taz19 Scrapers'),
	('script.module.viperscrapers', 'Viper Scrapers'),
)
KNOWN_EXTERNAL_SCRAPER_IDS = frozenset(i[0] for i in KNOWN_EXTERNAL_SCRAPERS)

def _external_slot_setting(slot, field):
	return 'external_scraper.slot%d.%s' % (int(slot), field)

def external_scraper_slot_data(slot):
	module = get_setting('nightshift.%s' % _external_slot_setting(slot, 'module'), 'empty_setting')
	name = get_setting('nightshift.%s' % _external_slot_setting(slot, 'name'), 'empty_setting')
	enabled = get_setting('nightshift.%s' % _external_slot_setting(slot, 'enabled'), 'false') == 'true'
	if module in ('empty_setting', ''):
		return {'slot': int(slot), 'module': '', 'name': '', 'enabled': False, 'folder_name': ''}
	return {'slot': int(slot), 'module': module, 'name': name, 'enabled': enabled, 'folder_name': module.split('.')[-1]}

def external_scraper_cache_key(module_id, provider):
	return '%s::%s' % (module_id, provider)

def active_external_modules():
	modules = []
	for slot in range(1, EXTERNAL_SCRAPER_SLOT_COUNT + 1):
		data = external_scraper_slot_data(slot)
		if not data['module'] or not data['enabled']: continue
		display = data['name'] if data['name'] not in ('empty_setting', '') else data['folder_name']
		modules.append({'slot': slot, 'module_id': data['module'], 'folder_name': data['folder_name'], 'display_name': display})
	return modules

def external_module_display_name(module_id):
	if not module_id or module_id in ('empty_setting', ''): return ''
	for slot in range(1, EXTERNAL_SCRAPER_SLOT_COUNT + 1):
		data = external_scraper_slot_data(slot)
		if data['module'] == module_id:
			if data['name'] not in ('empty_setting', '', None): return data['name']
			return data['folder_name']
	module_id = str(module_id)
	if '.' in module_id: return module_id.split('.')[-1]
	return module_id

def any_external_scraper_configured():
	for slot in range(1, EXTERNAL_SCRAPER_SLOT_COUNT + 1):
		if external_scraper_slot_data(slot)['module']: return True
	module = get_setting('nightshift.external_scraper.module', 'empty_setting')
	return module not in ('empty_setting', '')

def _sync_legacy_external_scraper_from_slot(slot=1):
	data = external_scraper_slot_data(slot)
	if data['module']:
		set_setting('external_scraper.module', data['module'])
		set_setting('external_scraper.name', data['name'] or data['folder_name'])
	else:
		set_setting('external_scraper.module', 'empty_setting')
		set_setting('external_scraper.name', 'empty_setting')

def external_scraper_module_in_use(module_id, exclude_slot=None):
	if not module_id or module_id in ('empty_setting', ''): return 0
	for slot in range(1, EXTERNAL_SCRAPER_SLOT_COUNT + 1):
		if exclude_slot and int(slot) == int(exclude_slot): continue
		if external_scraper_slot_data(slot)['module'] == module_id: return slot
	return 0

def set_external_scraper_slot(slot, module_id, module_name, enable=True):
	slot = int(slot)
	if module_id and module_id not in ('empty_setting', ''):
		if external_scraper_module_in_use(module_id, exclude_slot=slot): return False
	set_setting(_external_slot_setting(slot, 'module'), module_id or 'empty_setting')
	set_setting(_external_slot_setting(slot, 'name'), module_name or 'empty_setting')
	set_setting(_external_slot_setting(slot, 'enabled'), 'true' if enable and module_id else 'false')
	if slot == 1: _sync_legacy_external_scraper_from_slot(1)
	return True

def swap_external_scraper_slots(slot_a, slot_b):
	slot_a, slot_b = int(slot_a), int(slot_b)
	if slot_a == slot_b: return
	fields = ('module', 'name', 'enabled')
	values = {}
	for slot in (slot_a, slot_b):
		values[slot] = {field: get_setting('nightshift.%s' % _external_slot_setting(slot, field)) for field in fields}
	for field in fields:
		set_setting(_external_slot_setting(slot_a, field), values[slot_b][field] or ('false' if field == 'enabled' else 'empty_setting'))
		set_setting(_external_slot_setting(slot_b, field), values[slot_a][field] or ('false' if field == 'enabled' else 'empty_setting'))
	_sync_legacy_external_scraper_from_slot(1)

def migrate_external_scraper_slots_for_upgrade(had_existing_settings):
	if not had_existing_settings: return False
	migrated = False
	slot1 = external_scraper_slot_data(1)
	if not slot1['module']:
		legacy_module = get_setting('nightshift.external_scraper.module', 'empty_setting')
		legacy_name = get_setting('nightshift.external_scraper.name', 'empty_setting')
		if legacy_module not in ('empty_setting', ''):
			set_external_scraper_slot(1, legacy_module, legacy_name, enable=get_setting('nightshift.provider.external', 'false') == 'true')
			migrated = True
	if get_setting('nightshift.migration.external_scraper_slots_v160', 'false') != 'true':
		set_setting('migration.external_scraper_slots_v160', 'true')
	return migrated

def external_scraper_info():
	modules = active_external_modules()
	if modules:
		entry = modules[0]
		return entry['module_id'], entry['folder_name']
	module = get_setting('nightshift.external_scraper.module')
	if module in ('empty_setting', ''): return None, ''
	return module, module.split('.')[-1]

def external_scraper_enabled_module_count():
	count = 0
	for slot in range(1, EXTERNAL_SCRAPER_SLOT_COUNT + 1):
		data = external_scraper_slot_data(slot)
		if data['module'] and data['enabled']:
			count += 1
	return count

def configured_external_scraper_slots():
	slots = []
	for slot in range(1, EXTERNAL_SCRAPER_SLOT_COUNT + 1):
		data = external_scraper_slot_data(slot)
		if not data['module']: continue
		display = data['name'] if data['name'] not in ('empty_setting', '', None) else data['folder_name']
		slots.append({'slot': slot, 'module_id': data['module'], 'display_name': display, 'enabled': data['enabled']})
	return slots

def external_scraper_settings_tools_label():
	if len(configured_external_scraper_slots()) != 1:
		return 'External Scrapers Settings'
	return 'External Scraper Settings'

def external_scraper_settings_options_label():
	if len(configured_external_scraper_slots()) != 1:
		return 'Open External Scrapers Settings'
	return 'Open External Scraper Settings'

def append_external_scraper_settings_cm(cm_append, build_url_fn):
	if not configured_external_scraper_slots(): return
	cm_append(['external_scraper_settings', ('[B]%s[/B]' % external_scraper_settings_tools_label(),
		'RunPlugin(%s)' % build_url_fn({'mode': 'open_external_scraper_settings'}))])

def append_theme_song_cm(cm_append, build_url_fn, tmdb_id, season=''):
	if 'theme_song' not in cm_enabled(): return
	params = {'mode': 'show_theme.override', 'tmdb_id': tmdb_id}
	if season: params['season'] = season
	cm_append(['theme_song', ('[B]Theme Song[/B]', 'RunPlugin(%s)' % build_url_fn(params))])
	try:
		from modules.show_theme import has_pick
		if has_pick(tmdb_id): cm_append(['theme_song_clear', ('[B]Clear Chosen Theme Song[/B]', 'RunPlugin(%s)' % build_url_fn({'mode': 'show_theme.clear_pick', 'tmdb_id': tmdb_id}))])
	except Exception: pass

def append_cm_if_enabled(cm_append, cm_sort_order, key, label, command):
	# Opt-in shortcuts must gate on enabled membership — stock menus show every cm_append.
	if key not in (cm_sort_order or {}): return
	cm_append([key, (label, command)])

def append_list_shortcut_context_menus(cm_append, build_url_fn, cm_sort_order, media_type, tmdb_id, imdb_id, tvdb_id, title, poster):
	# Catalog lists every service; live CM only appends shortcuts for authorised accounts.
	base = {'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id or 'None', 'media_type': media_type, 'title': title, 'icon': poster}
	if mdblist_user_active():
		append_cm_if_enabled(cm_append, cm_sort_order, 'mdblist_watchlist', '[B]MDBList Watchlist[/B]',
			'RunPlugin(%s)' % build_url_fn(dict(base, mode='mdblist_watchlist_shortcut_choice')))
		append_cm_if_enabled(cm_append, cm_sort_order, 'mdblist_library', '[B]MDBList Library[/B]',
			'RunPlugin(%s)' % build_url_fn(dict(base, mode='mdblist_library_shortcut_choice')))
	if simkl_user_active():
		append_cm_if_enabled(cm_append, cm_sort_order, 'simkl_plantowatch', '[B]Simkl Plan to Watch[/B]',
			'RunPlugin(%s)' % build_url_fn(dict(base, mode='simkl_plantowatch_shortcut_choice')))
	if tmdblist_user_active():
		tmdb_media = 'movie' if media_type == 'movie' else 'tv'
		append_cm_if_enabled(cm_append, cm_sort_order, 'tmdb_watchlist', '[B]TMDb Watchlist[/B]',
			'RunPlugin(%s)' % build_url_fn({'mode': 'tmdb_watchlist_shortcut_choice', 'media_type': tmdb_media, 'tmdb_id': tmdb_id, 'title': title, 'icon': poster}))
		append_cm_if_enabled(cm_append, cm_sort_order, 'tmdb_favorites', '[B]TMDb Favorites[/B]',
			'RunPlugin(%s)' % build_url_fn({'mode': 'tmdb_favorites_shortcut_choice', 'media_type': tmdb_media, 'tmdb_id': tmdb_id, 'title': title, 'icon': poster}))
	if trakt_user_active():
		append_cm_if_enabled(cm_append, cm_sort_order, 'trakt_watchlist', '[B]Trakt Watchlist[/B]',
			'RunPlugin(%s)' % build_url_fn(dict(base, mode='trakt_watchlist_shortcut_choice')))
		append_cm_if_enabled(cm_append, cm_sort_order, 'trakt_collection', '[B]Trakt Library[/B]',
			'RunPlugin(%s)' % build_url_fn(dict(base, mode='trakt_collection_shortcut_choice')))

def append_source_shortcut_context_menus(cm_append, build_url_fn, cm_sort_order, media_type, meta, season='', episode='', playcount='0'):
	params = {'media_type': media_type, 'meta': meta, 'playcount': playcount}
	if media_type == 'episode':
		params.update({'season': season, 'episode': episode})
	append_cm_if_enabled(cm_append, cm_sort_order, 'select_source', '[B]Select Source[/B]',
		'RunPlugin(%s)' % build_url_fn(dict(params, mode='select_source_choice')))
	append_cm_if_enabled(cm_append, cm_sort_order, 'rescrape_select_source', '[B]Rescrape & Select Source[/B]',
		'RunPlugin(%s)' % build_url_fn(dict(params, mode='rescrape_select_source_choice')))

def external_scraper_run_mode():
	return str(get_setting('nightshift.external_scraper.run_mode', '1'))

def external_scraper_run_mode_series():
	return external_scraper_run_mode() == '1'

def external_scraper_run_mode_parallel():
	return external_scraper_run_mode() == '0'

def external_scraper_run_mode_orchestrated():
	return external_scraper_run_mode() in ('1', '2', '3')

def refresh_external_scraper_properties():
	from modules.kodi_utils import set_property
	count = external_scraper_enabled_module_count()
	set_property('nightshift.external_scraper.enabled_count', str(count))
	set_property('nightshift.external_scraper.multi_search', 'true' if count >= 2 else 'false')

def migrate_external_scraper_run_mode_for_upgrade(had_existing_settings):
	if not had_existing_settings:
		return False
	if get_setting('nightshift.external_scraper.run_mode', 'empty_setting') not in ('empty_setting', ''):
		return False
	legacy = get_setting('nightshift.external_scraper.max_modules_parallel', '3')
	set_setting('external_scraper.run_mode', '1' if legacy == '1' else '0')
	return True

def filter_by_name(scraper):
	if get_property('fs_filterless_search') == 'true': return False
	# Not-yet-released title: always apply the strict title/year/pack name gate, whatever the per-scraper setting says.
	if get_property('fs_unreleased_title_filter') == 'true': return True
	return get_setting('nightshift.%s.title_filter' % scraper, 'false') == 'true'

def filter_by_episode_title(scraper):
	return get_setting('nightshift.%s.title_filter_episode' % scraper, 'true') == 'true'

def uncached_min_seeders():
	return int(get_setting('nightshift.results.uncached_min_seeders', '0'))

_DEBRID_CACHE_CHECK_SETTINGS = {
	'Real-Debrid': 'rd.cache_check',
	'TorBox': 'tb.cache_check',
	'Premiumize.me': 'pm.cache_check',
	'Offcloud': 'oc.cache_check',
}

def debrid_cache_check(provider):
	if provider == 'AllDebrid':
		return False
	setting_id = _DEBRID_CACHE_CHECK_SETTINGS.get(provider)
	if not setting_id: return False
	return get_setting('nightshift.%s' % setting_id, 'false') == 'true'

def any_external_cache_check():
	for slug, provider in (('rd', 'Real-Debrid'), ('tb', 'TorBox'), ('pm', 'Premiumize.me'), ('oc', 'Offcloud')):
		if enabled_debrids_check(slug) and debrid_cache_check(provider):
			return True
	return False

def include_uncached_torbox():
	return get_setting('nightshift.tb.include_uncached', 'false') == 'true' and debrid_cache_check('TorBox')

def include_uncached_offcloud():
	return get_setting('nightshift.oc.include_uncached', 'false') == 'true' and debrid_cache_check('Offcloud')

def include_uncached_premiumize():
	return get_setting('nightshift.pm.include_uncached', 'false') == 'true' and debrid_cache_check('Premiumize.me')

def tb_notify_cloud_ready():
	return get_setting('nightshift.tb.notify_cloud_ready', 'true') == 'true'

def oc_notify_cloud_ready():
	return get_setting('nightshift.oc.notify_cloud_ready', 'true') == 'true'

def easynews_language_filter():
	enabled = get_setting('nightshift.easynews.filter_lang') == 'true'
	if enabled: filters = get_setting('nightshift.easynews.lang_filters').split(', ')
	else: filters = []
	return enabled, filters

def easynews_exclude_adult():
	return get_setting('nightshift.easynews.exclude_adult', 'false') == 'true'

def easynews_refresh_credentials():
	return get_setting('nightshift.easynews.refresh_credentials', 'true') == 'true'

def easynews_lang_include_unknown():
	return get_setting('nightshift.easynews.lang_include_unknown', 'true') == 'true'

def easynews_fallback_search():
	return get_setting('nightshift.easynews.fallback_search', 'true') == 'true'

def easynews_search_width():
	return int(get_setting('nightshift.easynews.search_width', '0'))

def size_sort_weighted():
	return get_setting('nightshift.results.size_sort_weighted', 'false') == 'true'

def results_sort_order():
	sort_direction = -1 if get_setting('nightshift.results.size_sort_direction') == '0' else 1
	return (
			lambda k: (k['quality_rank'], k['provider_rank'], sort_direction*k['size_rank']), #Quality, Provider, Size
			lambda k: (k['quality_rank'], sort_direction*k['size_rank'], k['provider_rank']), #Quality, Size, Provider
			lambda k: (k['provider_rank'], k['quality_rank'], sort_direction*k['size_rank']), #Provider, Quality, Size
			lambda k: (k['provider_rank'], sort_direction*k['size_rank'], k['quality_rank']), #Provider, Size, Quality
			lambda k: (sort_direction*k['size_rank'], k['quality_rank'], k['provider_rank']), #Size, Quality, Provider
			lambda k: (sort_direction*k['size_rank'], k['provider_rank'], k['quality_rank'])  #Size, Provider, Quality
			)[int(get_setting('nightshift.results.sort_order', '1'))]

def active_internal_scrapers():
	settings = ['provider.external', 'provider.easynews', 'provider.folders']
	settings_append = settings.append
	for item in [('rd', 'provider.rd_cloud'), ('pm', 'provider.pm_cloud'), ('ad', 'provider.ad_cloud'), ('oc', 'provider.oc_cloud'), ('tb', 'provider.tb_cloud')]:
		if enabled_debrids_check(item[0]): settings_append(item[1])
	active = [i.split('.')[1] for i in settings if get_setting('nightshift.%s' % i) == 'true']
	if aiostreams_active(): active.append('aiostreams')
	if nzb_scrape_active(): active.append('nzb')
	if animetosho_scrape_active(): active.append('animetosho')
	if nyaa_scrape_active(): active.append('nyaa')
	if comet_scrape_active(): active.append('comet')
	if torz_scrape_active(): active.append('torz')
	if torrentio_scrape_active(): active.append('torrentio')
	if mediafusion_scrape_active(): active.append('mediafusion')
	if zilean_scrape_active(): active.append('zilean')
	if piratebay_scrape_active(): active.append('piratebay')
	if torrentdownloads_scrape_active(): active.append('torrentdownloads')
	if knaben_scrape_active(): active.append('knaben')
	if tsukihime_scrape_active(): active.append('tsukihime')
	return active

def provider_sort_ranks():
	fo_priority = int(get_setting('nightshift.folders.priority', '6'))
	aio_priority = int(get_setting('nightshift.aio.priority', '7'))
	en_priority = int(get_setting('nightshift.en.priority', '7'))
	nzb_priority = int(get_setting('nightshift.nzb.priority', '7'))
	rd_priority = int(get_setting('nightshift.rd.priority', '8'))
	ad_priority = int(get_setting('nightshift.ad.priority', '9'))
	pm_priority = int(get_setting('nightshift.pm.priority', '10'))
	oc_priority = int(get_setting('nightshift.oc.priority', '10'))
	tb_priority = int(get_setting('nightshift.tb.priority', '10'))
	return {'easynews': en_priority, 'aiostreams': aio_priority, 'nzb': nzb_priority, 'real-debrid': rd_priority, 'premiumize.me': pm_priority, 'alldebrid': ad_priority,
	'offcloud': oc_priority, 'torbox': tb_priority, 'rd_cloud': rd_priority, 'pm_cloud': pm_priority, 'ad_cloud': ad_priority, 'oc_cloud': oc_priority,
	'tb_cloud': tb_priority, 'folders': fo_priority}

def sort_to_top(provider):
	sort_to_top_dict = {'folders': 'nightshift.results.sort_folders_first', 'rd_cloud': 'nightshift.results.sort_rdcloud_first', 'pm_cloud': 'nightshift.results.sort_pmcloud_first',
						'ad_cloud': 'nightshift.results.sort_adcloud_first', 'oc_cloud': 'nightshift.results.sort_occloud_first', 'tb_cloud': 'nightshift.results.sort_tbcloud_first'}
	return get_setting(sort_to_top_dict[provider]) == 'true'

def auto_resume(media_type, autoplay_status):
	return {0: False, 1: True, 2: autoplay_status}[int(get_setting('nightshift.auto_resume_%s' % media_type))]

def scraping_settings():
	highlight_type = int(get_setting('nightshift.highlight.type', '0'))
	if highlight_type == 2:
		highlight = get_setting('nightshift.scraper_single_highlight', 'FF008EB2')
		return {'highlight_type': 1, '4k': highlight, '1080p': highlight, '720p': highlight, 'sd': highlight}
	easynews_highlight, aiostreams_highlight, nzb_highlight, debrid_cloud_highlight, folders_highlight = '', '', '', '', ''
	rd_highlight, pm_highlight, ad_highlight, oc_highlight, tb_highlight = '', '', '', '', ''
	highlight_4K, highlight_1080P, highlight_720P, highlight_SD = '', '', '', ''
	if highlight_type == 0:
		easynews_highlight = get_setting('nightshift.provider.easynews_highlight', 'FF00B3B2')
		aiostreams_highlight = get_setting('nightshift.provider.aiostreams_highlight', 'FF00D4FF')
		nzb_highlight = get_setting('nightshift.provider.nzb_highlight', 'FFD4A017')
		debrid_cloud_highlight = get_setting('nightshift.provider.debrid_cloud_highlight', 'FF7A01CC')
		folders_highlight = get_setting('nightshift.provider.folders_highlight', 'FFB36B00')
		rd_highlight = get_setting('nightshift.provider.rd_highlight', 'FF3C9900')
		pm_highlight = get_setting('nightshift.provider.pm_highlight', 'FFFF3300')
		ad_highlight = get_setting('nightshift.provider.ad_highlight', 'FFE6B800')
		oc_highlight = get_setting('nightshift.provider.oc_highlight', 'FF5C6BC0')
		tb_highlight = get_setting('nightshift.provider.tb_highlight', 'FF01662A')
	else:
		highlight_4K = get_setting('nightshift.scraper_4k_highlight', 'FFFF00FE')
		highlight_1080P = get_setting('nightshift.scraper_1080p_highlight', 'FFE6B800')
		highlight_720P = get_setting('nightshift.scraper_720p_highlight', 'FF3C9900')
		highlight_SD = get_setting('nightshift.scraper_SD_highlight', 'FF0166FF')
	return {'highlight_type': highlight_type, 'real-debrid': rd_highlight, 'premiumize': pm_highlight, 'alldebrid': ad_highlight,
			'offcloud': oc_highlight, 'torbox': tb_highlight, 'rd_cloud': debrid_cloud_highlight, 'pm_cloud': debrid_cloud_highlight, 'ad_cloud': debrid_cloud_highlight,
			'oc_cloud': debrid_cloud_highlight, 'tb_cloud': debrid_cloud_highlight, 'easynews': easynews_highlight, 'aiostreams': aiostreams_highlight, 'nzb': nzb_highlight, 'folders': folders_highlight,
			'4k': highlight_4K, '1080p': highlight_1080P, '720p': highlight_720P, 'sd': highlight_SD}

def external_cache_check():
	return any_external_cache_check()

def fanarttv_api_key():
	return get_setting('nightshift.fanarttv_api', 'empty_setting')

def tvdb_api_key():
	return get_setting('nightshift.tvdb_api', 'empty_setting')

def tvdb_pin():
	return get_setting('nightshift.tvdb_pin', 'empty_setting')

def omdb_api_key():
	return get_setting('nightshift.omdb_api', 'empty_setting')

def default_all_episodes():
	return int(get_setting('nightshift.default_all_episodes', '0'))

def max_threads():
	if not get_setting('nightshift.limit_concurrent_threads', 'false') == 'true': return 20
	return int(get_setting('nightshift.max_threads', '20'))

def get_meta_filter():
	return get_setting('nightshift.meta_filter', 'true')

def mpaa_region():
	return get_setting('nightshift.mpaa_region', 'US')

def widget_hide_next_page():
	return get_setting('nightshift.widget_hide_next_page', 'false') == 'true'

def widget_hide_watched():
	return get_setting('nightshift.widget_hide_watched', 'false') == 'true'

def widget_hide_watched_fill():
	return widget_hide_watched() and get_setting('nightshift.widget_hide_watched_fill', 'false') == 'true'

def calendar_sort_order():
	return int(get_setting('nightshift.trakt.calendar_sort_order', '0'))

def calendar_day_window():
	'''Inclusive start/end dates for MDBList, PunchPlay, Simkl, and Trakt calendars (Show Previous/Future Days).'''
	from datetime import timedelta
	from modules.utils import get_datetime
	try: previous_days = int(get_setting('nightshift.trakt.calendar_previous_days', '7'))
	except (TypeError, ValueError): previous_days = 7
	try: future_days = int(get_setting('nightshift.trakt.calendar_future_days', '7'))
	except (TypeError, ValueError): future_days = 7
	previous_days = max(0, min(14, previous_days))
	future_days = max(0, min(14, future_days))
	current = get_datetime()
	return current - timedelta(days=previous_days), current + timedelta(days=future_days)

def calendar_date_label_options():
	# (strftime format, use_words, include_date). Hyphen formats match picker labels.
	# Words modes: Today/Tomorrow/weekday within ~1 week; format used outside that window.
	# 0/7/8 Words / date | 1-3 date only | 4-6 Day + date (word and date together)
	date_only = {3: '%Y-%m-%d', 1: '%m-%d-%Y', 2: '%d-%m-%Y'}
	day_plus = {6: '%Y-%m-%d', 4: '%m-%d-%Y', 5: '%d-%m-%Y'}
	words_far = {0: '%Y-%m-%d', 7: '%m-%d-%Y', 8: '%d-%m-%Y'}
	try: choice = int(get_setting('nightshift.trakt.calendar_date_labels', '0'))
	except (TypeError, ValueError): choice = 0
	if choice in date_only: return date_only[choice], False, False
	if choice in day_plus: return day_plus[choice], True, True
	return words_far.get(choice, '%Y-%m-%d'), True, False

def calendar_date_format():
	# None when word labels are used (words-only or Day + date); strftime string for date-only.
	fmt, use_words, _ = calendar_date_label_options()
	if use_words: return None
	return fmt

def ignore_articles():
	return get_setting('nightshift.ignore_articles', 'false') == 'true'

def jump_to_enabled():
	return get_setting('nightshift.paginate.jump_to', 'true') == 'true'

def datetime_utc_offset():
	'''User UTC (+/-) setting only — genuine timezone hours from UTC.'''
	try: return int(get_setting('nightshift.datetime.offset', '0'))
	except (TypeError, ValueError): return 0

def date_offset():
	# TMDb dates are still assumed at 20:00 locally in adjust_premiered_date; offset is real UTC (+/-) only.
	return datetime_utc_offset()

def media_open_action(media_type):
	return int(get_setting('nightshift.media_open_action_%s' % media_type, '0'))

def media_open_action_skip_inprogress_movie():
	return get_setting('nightshift.media_open_action_skip_inprogress_movie', 'false') == 'true'

def media_open_action_skip_inprogress_tvshow():
	return get_setting('nightshift.media_open_action_skip_inprogress_tvshow', 'false') == 'true'

def _resolve_watched_provider():
	ind = int(get_setting('nightshift.watched_indicators', '0'))
	if ind == 1 and not trakt_user_active(): return 0
	if ind == 2 and not simkl_user_active(): return 0
	if ind == 3 and not mdblist_user_active(): return 0
	if ind == 4 and not punchplay_user_active(): return 0
	if ind == 5 and not watchvault_active(): return 0
	return ind

_WV_NOT_OFFERED_LOGGED = [False]


def watchvault_active():
	"""WatchVault is offered as a watched status provider when the add-on is installed and loads here. It is local
	(no sign-in), so it is not hidden like an account would be; if it is missing, the reason is logged once."""
	try:
		from modules import watchvault_helper
		ok = bool(watchvault_helper.available())
		reason = '' if ok else (watchvault_helper.unavailable_reason() or 'not installed or not loading')
	except Exception as e:
		ok, reason = False, str(e)
	if not ok and not _WV_NOT_OFFERED_LOGGED[0]:
		_WV_NOT_OFFERED_LOGGED[0] = True
		try:
			from modules import kodi_utils
			kodi_utils.logger('WatchVault', 'not offered as a watched status provider: %s' % reason)
		except Exception:
			pass
	return ok


def watched_provider_options():
	options = {}
	if mdblist_user_active(): options['3'] = 'MDBList'
	if watchvault_active(): options['5'] = 'WatchVault'
	if punchplay_user_active(): options['4'] = 'PunchPlay'
	options['0'] = 'NIGHTSHIFT'
	if simkl_user_active(): options['2'] = 'Simkl'
	if trakt_user_active(): options['1'] = 'Trakt'
	return options

def offer_watched_provider(provider_index, name):
	from modules.kodi_utils import confirm_dialog
	if confirm_dialog(heading='Watched Status Provider', text='Do you want to set %s as your Watched Status Provider?' % name,
						ok_label='Yes', cancel_label='No', default_control=10):
		set_setting('watched_indicators', str(provider_index), provider_sync=False)
		return True
	return False

def fallback_watched_provider_on_revoke(revoked_index):
	current = int(get_setting('nightshift.watched_indicators', '0'))
	if current != revoked_index: return
	def _next(*candidates):
		for idx, active in candidates:
			if active: return str(idx)
		return '0'
	if revoked_index == 1:
		set_setting('watched_indicators', _next((2, simkl_user_active()), (4, punchplay_user_active()), (3, mdblist_user_active())))
	elif revoked_index == 2:
		set_setting('watched_indicators', _next((1, trakt_user_active()), (4, punchplay_user_active()), (3, mdblist_user_active())))
	elif revoked_index == 3:
		set_setting('watched_indicators', _next((4, punchplay_user_active()), (2, simkl_user_active()), (1, trakt_user_active())))
	elif revoked_index == 4:
		set_setting('watched_indicators', _next((3, mdblist_user_active()), (2, simkl_user_active()), (1, trakt_user_active())))

def watched_indicators():
	return _resolve_watched_provider()

def provider_sync_refresh_widgets(provider_index):
	"""Refresh home widgets after a provider sync only when that provider owns watched/progress indicators."""
	if watched_indicators() != provider_index:
		return False
	keys = {1: 'trakt.refresh_widgets', 2: 'simkl.refresh_widgets', 3: 'mdblist.refresh_widgets', 4: 'punchplay.refresh_widgets'}
	key = keys.get(provider_index)
	if not key:
		return False
	return get_setting('nightshift.%s' % key, 'false') == 'true'

def most_watched_provider():
	return 'simkl' if watched_indicators() == 2 else 'trakt'

def flatten_episodes():
	return get_setting('nightshift.trakt.flatten_episodes', 'false') == 'true'

def nextep_method():
	return int(get_setting('nightshift.nextep.method', '0'))

def nextep_limit_history():
	return get_setting('nightshift.nextep.limit_history', 'false') == 'true'

def nextep_limit():
	return int(get_setting('nightshift.nextep.limit', '100'))

def nextep_include_unwatched():
	return int(get_setting('nightshift.nextep.include_unwatched', '0'))

def nextep_include_airdate():
	return get_setting('nightshift.nextep.include_airdate', 'false') == 'true'

def nextep_airing_today():
	return get_setting('nightshift.nextep.airing_today', 'false') == 'true'

def nextep_include_unaired():
	return get_setting('nightshift.nextep.include_unaired', 'false') == 'true'

_NEXTEP_SORT_ALIASES = {
	'last_played': 'last_played', 'first_aired': 'first_aired', 'name': 'name',
	'0': 'last_played', '1': 'first_aired', '2': 'name',
	'recently_watched': 'last_played', 'airdate': 'first_aired', 'title': 'name'
}

def parse_nextep_sort_key(value):
	if value in (None, ''): return None
	return _NEXTEP_SORT_ALIASES.get(str(value).strip().lower())

def nextep_sort_key(override=None):
	parsed = parse_nextep_sort_key(override)
	if parsed: return parsed
	try: return {0: 'last_played', 1: 'first_aired', 2: 'name'}[int(get_setting('nightshift.nextep.sort_type', '0'))]
	except: return 'last_played'

def nextep_sort_direction():
	return int(get_setting('nightshift.nextep.sort_order', '0')) == 0

def _rescrape_defaults():
	return [('cache_ignored', '1', '0'), ('imdb_year', '0', '1'), ('with_all', '0', '2'), ('episode_group', '0', '3'), ('ignore_filters', '0', '4'), ('full_scrape', '2', '5')]

def rescrape_all_settings():
	return sorted([(i[0], int(get_setting('nightshift.rescrape.%s' % i[0], i[1])), int(get_setting('nightshift.rescrape.%s.order' % i[0], i[2]))) \
					for i in _rescrape_defaults()], key=lambda x: x[2])

def rescrape_settings():
	return [i for i in rescrape_all_settings() if i[1] in (1, 2)]

def rescrape_action_value(action, default='0'):
	return int(get_setting('nightshift.rescrape.%s' % action, default))

def cm_enabled():
	default = 'extras,theme_song,options,playback_options,external_scraper_settings,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,in_trakt_list,' \
				'mdblist_manager,punchplay_manager,simkl_manager,tmdb_manager,trakt_manager,personal_manager,favorites_manager,mark_watched,unmark_previous_episode,force_refresh_calendar,exit,refresh,reload'
	setting = get_setting('nightshift.context_menu.enabled', default)
	if setting in ('', None, 'noop', '[]'): return default.split(',')
	return setting.split(',')

def _merge_cm_order_with_enabled(order, enabled):
	order = [i for i in order if i]
	# Insert missing managers before the next A–Z peer (MDBList → PunchPlay → Simkl → TMDb → Trakt).
	manager_insert = {
		'mdblist_manager': ('punchplay_manager', 'simkl_manager', 'tmdb_manager', 'trakt_manager'),
		'punchplay_manager': ('simkl_manager', 'tmdb_manager', 'trakt_manager'),
		'simkl_manager': ('tmdb_manager', 'trakt_manager'),
		'tmdb_manager': ('trakt_manager', 'personal_manager'),
		'trakt_manager': ('personal_manager',),
	}
	for item in enabled:
		if item in order: continue
		inserted = False
		for anchor in manager_insert.get(item, ()):
			if anchor in order:
				order.insert(order.index(anchor), item)
				inserted = True
				break
		if not inserted: order.append(item)
	return order

def _normalize_cm_list_order(order):
	order = list(order)
	managers = ('mdblist_manager', 'punchplay_manager', 'simkl_manager', 'tmdb_manager', 'trakt_manager')
	present = [m for m in managers if m in order]
	if present:
		insert_at = min(order.index(m) for m in present)
		order = [i for i in order if i not in managers]
		for offset, manager in enumerate(present):
			order.insert(insert_at + offset, manager)
	if 'trakt_manager' in order and 'personal_manager' in order:
		ti, pi = order.index('trakt_manager'), order.index('personal_manager')
		if pi < ti: order[ti], order[pi] = order[pi], order[ti]
	return order

def migrate_external_scraper_context_menu_for_upgrade(had_existing_settings):
	if get_setting('nightshift.external_scraper.cm_menu_migrated', 'false') == 'true': return False
	set_setting('external_scraper.cm_menu_migrated', 'true')
	if not had_existing_settings: return False
	item, changed = 'external_scraper_settings', False
	for setting_key in ('context_menu.enabled', 'context_menu.order'):
		raw = get_setting('nightshift.%s' % setting_key, '')
		if raw in ('', None, 'noop', '[]'): continue
		parts = [p for p in raw.split(',') if p]
		if item in parts: continue
		if 'playback_options' in parts: parts.insert(parts.index('playback_options') + 1, item)
		else: parts.append(item)
		set_setting(setting_key, ','.join(parts))
		changed = True
	return changed

def migrate_theme_song_context_menu_for_upgrade(had_existing_settings):
	if get_setting('nightshift.theme_song.cm_menu_migrated', 'false') == 'true': return False
	set_setting('theme_song.cm_menu_migrated', 'true')
	if not had_existing_settings: return False
	item, changed = 'theme_song', False
	for setting_key in ('context_menu.enabled', 'context_menu.order'):
		raw = get_setting('nightshift.%s' % setting_key, '')
		if raw in ('', None, 'noop', '[]'): continue
		parts = [p for p in raw.split(',') if p]
		if item in parts: continue
		parts.insert(parts.index('extras') + 1 if 'extras' in parts else 0, item)
		set_setting(setting_key, ','.join(parts))
		changed = True
	return changed

def migrate_extras_theme_chooser_top_for_upgrade():
	# one time: a saved extras order gets the Manual Theme Chooser moved to the top
	if get_setting('nightshift.extras.theme_chooser_top_migrated', 'false') == 'true': return False
	set_setting('extras.theme_chooser_top_migrated', 'true')
	raw = get_setting('nightshift.extras.order', '')
	if raw in ('', None, 'noop', '[]'): return False
	parts = [p.strip() for p in raw.split(',') if p.strip()]
	if '2074' not in parts or parts[0] == '2074': return False
	parts.remove('2074'); parts.insert(0, '2074')
	set_setting('extras.order', ','.join(parts))
	return True

def migrate_extras_theme_chooser_after_plot_for_upgrade():
	# one time: the Manual Theme Chooser goes right after the Plot text box in a saved Extras order
	if get_setting('nightshift.extras.theme_chooser_after_plot_migrated', 'false') == 'true': return False
	set_setting('extras.theme_chooser_after_plot_migrated', 'true')
	raw = get_setting('nightshift.extras.order', '')
	if raw in ('', None, 'noop', '[]'): return False
	parts = [p.strip() for p in raw.split(',') if p.strip()]
	if '2074' not in parts: return False
	placed = [p for p in parts if p != '2074']
	placed.insert(placed.index('2050') + 1 if '2050' in placed else 0, '2074')
	if placed == parts: return False
	parts = placed
	set_setting('extras.order', ','.join(parts))
	return True


def migrate_force_refresh_calendar_cm_for_upgrade(had_existing_settings=True):
	"""Ensure Force Refresh AniList Calendar appears in context menus for existing installs."""
	if get_setting('nightshift.force_refresh_calendar_cm_migrated', 'false') == 'true': return False
	set_setting('force_refresh_calendar_cm_migrated', 'true')
	changed = False
	for setting_key in ('context_menu.enabled', 'context_menu.order'):
		raw = get_setting('nightshift.%s' % setting_key, '') or ''
		parts = [p for p in raw.split(',') if p]
		if 'force_refresh_calendar' not in parts:
			# place before exit/refresh/reload if present
			if 'exit' in parts:
				parts.insert(parts.index('exit'), 'force_refresh_calendar')
			else:
				parts.append('force_refresh_calendar')
			set_setting(setting_key, ','.join(parts))
			changed = True
	return changed

def migrate_simkl_context_menu_for_upgrade(had_existing_settings):
	if get_setting('nightshift.simkl.cm_menu_migrated', 'false') == 'true': return False
	set_setting('simkl.cm_menu_migrated', 'true')
	if not had_existing_settings: return False
	item, changed = 'simkl_manager', False
	raw = get_setting('nightshift.context_menu.enabled', '')
	if raw and raw not in ('noop', '[]'):
		parts = [p for p in raw.split(',') if p]
		if item not in parts:
			set_setting('context_menu.enabled', ','.join(parts + [item]))
			changed = True
	raw = get_setting('nightshift.context_menu.order', '')
	if raw and raw not in ('noop', '[]'):
		parts = _merge_cm_order_with_enabled([p for p in raw.split(',') if p], cm_enabled())
		if item not in raw.split(','):
			set_setting('context_menu.order', ','.join(parts))
			changed = True
	return changed

def migrate_mdblist_context_menu_for_upgrade(had_existing_settings):
	if get_setting('nightshift.mdblist.cm_menu_migrated', 'false') == 'true': return False
	set_setting('mdblist.cm_menu_migrated', 'true')
	if not had_existing_settings: return False
	item, changed = 'mdblist_manager', False
	raw = get_setting('nightshift.context_menu.enabled', '')
	if raw and raw not in ('noop', '[]'):
		parts = [p for p in raw.split(',') if p]
		if item not in parts:
			set_setting('context_menu.enabled', ','.join([item] + parts))
			changed = True
	raw = get_setting('nightshift.context_menu.order', '')
	if raw and raw not in ('noop', '[]'):
		parts = _merge_cm_order_with_enabled([p for p in raw.split(',') if p], cm_enabled())
		if item not in raw.split(','):
			set_setting('context_menu.order', ','.join(parts))
			changed = True
	return changed

def migrate_punchplay_context_menu_for_upgrade(had_existing_settings):
	if get_setting('nightshift.punchplay.cm_menu_migrated', 'false') == 'true': return False
	set_setting('punchplay.cm_menu_migrated', 'true')
	if not had_existing_settings: return False
	item, changed = 'punchplay_manager', False
	raw = get_setting('nightshift.context_menu.enabled', '')
	if raw and raw not in ('noop', '[]'):
		parts = [p for p in raw.split(',') if p]
		if item not in parts:
			if 'mdblist_manager' in parts:
				parts.insert(parts.index('mdblist_manager') + 1, item)
			elif 'simkl_manager' in parts:
				parts.insert(parts.index('simkl_manager'), item)
			else:
				parts.append(item)
			set_setting('context_menu.enabled', ','.join(parts))
			changed = True
	raw = get_setting('nightshift.context_menu.order', '')
	if raw and raw not in ('noop', '[]'):
		parts = _normalize_cm_list_order(_merge_cm_order_with_enabled([p for p in raw.split(',') if p], cm_enabled()))
		if item not in raw.split(','):
			set_setting('context_menu.order', ','.join(parts))
			changed = True
	return changed

def migrate_cm_manager_order_for_upgrade():
	if get_setting('nightshift.cm_manager_order_migrated_v3', 'false') == 'true': return False
	set_setting('cm_manager_order_migrated_v3', 'true')
	set_setting('cm_manager_order_migrated_v2', 'true')
	set_setting('cm_manager_order_migrated', 'true')
	before = get_setting('nightshift.context_menu.order', '')
	cm_current_order()
	# Also put TMDb before Trakt in the enabled-items list when both are present.
	enabled_raw = get_setting('nightshift.context_menu.enabled', '')
	if enabled_raw and enabled_raw not in ('noop', '[]'):
		parts = [p for p in enabled_raw.split(',') if p]
		normalized = _normalize_cm_list_order(parts)
		if normalized != parts:
			set_setting('context_menu.enabled', ','.join(normalized))
	return get_setting('nightshift.context_menu.order', '') != before

def cm_current_order():
	default = 'extras,theme_song,options,playback_options,external_scraper_settings,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,in_trakt_list,' \
				'mdblist_manager,punchplay_manager,simkl_manager,tmdb_manager,trakt_manager,personal_manager,favorites_manager,mark_watched,unmark_previous_episode,force_refresh_calendar,exit,refresh,reload'
	setting = get_setting('nightshift.context_menu.order', default)
	if setting in ('', None, 'noop', '[]'): order = default.split(',')
	else: order = setting.split(',')
	enabled = cm_enabled()
	merged = _normalize_cm_list_order(_merge_cm_order_with_enabled(order, enabled))
	if merged != order: set_setting('context_menu.order', ','.join(merged))
	return merged

def cm_sort_order():
	try: setting = {i: c for c, i in enumerate([i for i in cm_current_order() if i in cm_enabled()])}
	except: setting = cm_default_order()
	return setting

def cm_default_order():
	return {i: c for c, i in enumerate(default_setting_values('context_menu.order')['setting_default'].split(','))}

def rpdb_info(media_type):
	if media_type == 'extras': active = extras_enable_item_ratings()
	else: active = int(get_setting('nightshift.rpdb_enabled', '0')) in {'movie': (1, 3), 'tvshow': (2, 3)}[media_type]
	if active: return {'rpdb_api_key': get_setting('nightshift.rpdb_api'), 'rpdb_format': get_setting('nightshift.rpdb_format')}
	else: return {'rpdb_api_key': None, 'rpdb_format': None}

def use_season_name():
	return get_setting('nightshift.use_season_name', 'false') == 'true'


