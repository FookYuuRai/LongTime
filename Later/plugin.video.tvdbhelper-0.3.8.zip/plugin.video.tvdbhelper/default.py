# -*- coding: utf-8 -*-
import json
import os
import sys
import urllib.parse as up

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
# Remove the legacy user-key setting from upgrades; this add-on now uses its
# password-unlocked official credential payload instead.
ADDON.setSettingString('apikey', '')
# Clear the legacy plaintext unlock-password setting from older installations.
ADDON.setSettingString('unlock_password', '')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, os.path.join(ADDON_PATH, 'resources', 'lib'))
import tvdb_api as tv  # noqa: E402
import credentials as tvdb_credentials  # noqa: E402

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
BASE = sys.argv[0]
PARAMS = dict(up.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
ICON = os.path.join(ADDON_PATH, 'icon.png')
PAGE = 'page'


def L(i, *fmt):
    text = ADDON.getLocalizedString(i)
    return text % fmt if fmt else text


def url(**kw):
    return BASE + '?' + up.urlencode(kw)


_SESSION_WINDOW = xbmcgui.Window(10000)
_SESSION_PROPERTY = 'plugin.video.tvdbhelper.credentials.session.v2'


def _session_credentials():
    """Kodi window properties last only for this Kodi process/session, not on disk."""
    raw = _SESSION_WINDOW.getProperty(_SESSION_PROPERTY)
    if not raw:
        return None
    try:
        data = json.loads(raw)
        if (isinstance(data, dict) and isinstance(data.get('api_key'), str)
                and isinstance(data.get('api_key_with_pin'), str)
                and data['api_key'] and data['api_key_with_pin']):
            return data
    except (ValueError, TypeError):
        pass
    _SESSION_WINDOW.clearProperty(_SESSION_PROPERTY)
    return None


def _prompt_and_unlock():
    # Kodi's INPUT_PASSWORD returns an MD5 hash of what was typed, not the text, so it
    # cannot be used as the key-derivation password. INPUT_ALPHANUM with
    # ALPHANUM_HIDE_INPUT masks the entry on screen and returns the typed text.
    hide = getattr(xbmcgui, 'ALPHANUM_HIDE_INPUT', 2)
    password = xbmcgui.Dialog().input(L(30032), type=xbmcgui.INPUT_ALPHANUM, option=hide)
    if not password:
        raise tv.TVDBError(L(30033))
    try:
        credentials = tvdb_credentials.decrypt(password)
    except ValueError:
        raise tv.TVDBError(L(30024))
    except RuntimeError as err:
        raise tv.TVDBError(str(err))
    finally:
        password = ''
    # Runtime-only cache: never persist the password or decrypted credentials
    # in add-on settings or files.
    _SESSION_WINDOW.setProperty(_SESSION_PROPERTY, json.dumps(credentials, separators=(',', ':')))
    return credentials


def unlock_credentials():
    # One password unlocks both TVDB keys for the whole Kodi session. If the session
    # is already unlocked, reuse it: do not prompt again.
    if _session_credentials() is not None:
        xbmcgui.Dialog().notification('TVDB Helper', L(30040), ICON, 3000, False)
        return
    try:
        _prompt_and_unlock()
    except tv.TVDBError as err:
        xbmcgui.Dialog().ok('TVDB Helper', str(err))
        return
    xbmcgui.Dialog().notification('TVDB Helper', L(30039), ICON, 3000, False)
    # RunPlugin action: do not finish a directory listing or re-enter the root route.
    return


def client():
    credentials = _session_credentials()
    if credentials is None:
        credentials = _prompt_and_unlock()
    pin = (ADDON.getSettingString('pin') or '').strip()
    api_key = credentials['api_key_with_pin'] if pin else credentials['api_key']
    cache_dir = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('profile'), 'cache'))
    return tv.Client(api_key, pin,
                     ADDON.getSettingString('language') or 'eng',
                     country=ADDON.getSettingString('country') or 'usa', cache=tv.FileCache(cache_dir))


def add(label, target, folder=True, plot='', art=None, mediatype='video'):
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': ICON, 'thumb': ICON, **(art or {})})
    tag = li.getVideoInfoTag()
    tag.setTitle(label)
    tag.setMediaType(mediatype)
    if plot: tag.setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, folder)


def fail(message):
    xbmcgui.Dialog().ok('TVDB Helper', message)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def poster(item):
    img = item.get('image_url') or item.get('poster') or item.get('image') or ''
    return {'poster': img} if img else {}


def cl():
    return client()


# ---- screens
def root():
    add(L(30020), url(action='search', kind='series'))
    add(L(30029), url(action='search', kind='series', anime='1'))
    add(L(30021), url(action='search', kind='movie'))
    add(L(30030), url(action='search', kind='person'))
    add(L(30031), url(action='search', kind='company'))
    if _session_credentials() is not None:
        add(L(30034), url(action='lock'), folder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def search():
    kind = PARAMS.get('kind', 'series')
    anime = PARAMS.get('anime') == '1'
    query = PARAMS.get('query')
    if not query:
        query = xbmcgui.Dialog().input(L(30022))
        if not query:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return xbmc.executebuiltin('Container.Update(%s,replace)' % url(action='search', kind=kind,
                                                                    anime='1' if anime else '', query=query))
    try:
        results = cl().search(query, kind=kind)
    except tv.TVDBError as err:
        return fail(str(err))
    shown = 0
    for item in results:
        rkind, rid = tv.kind_and_id(item)
        if not rid: continue
        if anime and (rkind != 'series' or not tv.is_anime(item)): continue      # anime = series results with the anime genre / Japanese
        if not anime and kind == 'series' and rkind != 'series': continue
        shown += 1
        name = item.get('name') or '?'
        year = item.get('year') or (item.get('first_air_time') or '')[:4]
        label = name + (' (%s)' % year if year else '')
        plot = item.get('overview') or ''
        if rkind == 'series':
            add(label, url(action='show', id=rid), plot=plot, art=poster(item), mediatype='tvshow')
        elif rkind == 'movie':
            add(label, url(action='movie', id=rid), plot=plot, art=poster(item), mediatype='movie')
        elif rkind == 'person':
            add(label, url(action='person', id=rid), plot=plot, art=poster(item), mediatype='video')
        elif rkind == 'company':
            add(label, url(action='company', id=rid), plot=(item.get('companyType') or ''), art=poster(item), mediatype='video')
    if not shown:
        xbmcgui.Dialog().notification('TVDB Helper', L(30027), ICON, 3000, False)
    xbmcplugin.setContent(HANDLE, {'movie': 'movies', 'person': 'files', 'company': 'files'}.get(kind, 'tvshows'))
    xbmcplugin.endOfDirectory(HANDLE)


def show():
    sid = PARAMS['id']
    try:
        orders = cl().season_types(sid)
    except tv.TVDBError as err:
        return fail(str(err))
    for slug, name in orders:
        add(name, url(action='seasons', id=sid, order=slug))
    xbmcplugin.setContent(HANDLE, 'seasons')
    xbmcplugin.endOfDirectory(HANDLE)


def seasons():
    sid, order = PARAMS['id'], PARAMS.get('order', 'official')
    try:
        eps = cl().all_episodes(sid, order)
    except tv.TVDBError as err:
        return fail(str(err))
    for num, items in tv.group_seasons(eps).items():
        label = L(30025) if num == 0 else L(30026, num)
        add('%s  [%d episodes]' % (label, len(items)), url(action='episodes', id=sid, order=order, season=num))
    xbmcplugin.setContent(HANDLE, 'seasons')
    xbmcplugin.endOfDirectory(HANDLE)


def episodes():
    sid, order, season = PARAMS['id'], PARAMS.get('order', 'official'), int(PARAMS['season'])
    try:
        eps = cl().all_episodes(sid, order)
    except tv.TVDBError as err:
        return fail(str(err))
    for ep in tv.group_seasons(eps).get(season, []):
        label = '%s %s' % (tv.episode_label(ep), ep.get('name') or '')
        plot = ep.get('overview') or ''
        if ep.get('aired'): plot = ('Aired: %s\n' % ep['aired']) + plot
        add(label.strip(), '', folder=False, plot=plot, mediatype='episode')
    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE)


def movie():
    try:
        data = cl().movie_extended(PARAMS['id']) or {}
    except tv.TVDBError as err:
        return fail(str(err))
    title = data.get('name') or '?'
    info = '%s (%s)\n%s' % (title, data.get('year') or '?', data.get('overview') or '')
    add('[B]%s[/B]' % title, '', folder=False, plot=info, art=poster(data), mediatype='movie')
    companies = data.get('companies') or {}
    for kind_key, label in (('studio', 'Studio'), ('network', 'Network'), ('production', 'Production company')):
        for co in companies.get(kind_key) or []:
            add('%s: %s' % (label, co.get('name') or '?'), url(action='company', id=co.get('id')), plot=label)
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)


def person():
    try:
        data = cl().person_extended(PARAMS['id']) or {}
    except tv.TVDBError as err:
        return fail(str(err))
    add('[B]%s[/B]' % (data.get('name') or '?'), '', folder=False, plot=(data.get('birth') or ''), art=poster(data), mediatype='video')
    for kind, cid, name, year, role in tv.credits_by_title(data):
        label = name + (' (%s)' % year if year else '') + (' as %s' % role if role and role != name else '')
        if kind == 'movie':
            add(label, url(action='movie', id=cid), mediatype='movie')
        else:
            add(label, url(action='show', id=cid), mediatype='tvshow')
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)


def company():
    cid = PARAMS['id']
    try:
        data = cl().company(cid) or {}
        series = cl().company_series(cid)
        movies = cl().company_movies(cid)
    except tv.TVDBError as err:
        return fail(str(err))
    add('[B]%s[/B]' % (data.get('name') or '?'), '', folder=False, plot=((data.get('primaryCompanyType') or {}).get('companyTypeName') or ''), mediatype='video')
    for s in (series or {}).get('data') or []:
        add('%s (%s)' % (s.get('name') or '?', s.get('year') or ''), url(action='show', id=s.get('id')), art=poster(s), mediatype='tvshow')
    for m in (movies or {}).get('data') or []:
        add('%s (%s)' % (m.get('name') or '?', m.get('year') or ''), url(action='movie', id=m.get('id')), art=poster(m), mediatype='movie')
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)


def lock_credentials():
    _SESSION_WINDOW.clearProperty(_SESSION_PROPERTY)
    xbmcgui.Dialog().notification('TVDB Helper', 'TVDB credentials locked for this Kodi session.', ICON, 3000, False)
    # RunPlugin action: no directory listing is being rendered.
    return


ROUTES = {'': root, 'unlock': unlock_credentials, 'search': search, 'show': show, 'seasons': seasons, 'episodes': episodes, 'movie': movie, 'person': person, 'company': company, 'lock': lock_credentials}

if __name__ == '__main__':
    ROUTES.get(PARAMS.get('action', ''), root)()
