# -*- coding: utf-8 -*-
import json, time, os, hashlib
from xbmc import getInfoLabel
from urllib.parse import parse_qsl
from modules import kodi_utils
from modules.kodi_utils import external, get_property
# from modules.kodi_utils import logger

def sys_exit_check(mode='navigator.main'):
	from caches.settings_cache import get_setting, is_directory_listing_mode
	if get_setting('nightshift.reuse_language_invoker', 'true') == 'false': return False
	# First open still has external() true before Container.PluginName updates; never discard a built list.
	if is_directory_listing_mode(mode): return False
	if mode == 'open_settings': return False
	if not external(): return False
	return True

def prepare_directory_listing(mode):
	from caches.settings_cache import is_directory_listing_mode
	if not is_directory_listing_mode(mode): return
	try:
		from caches.base_cache import ensure_listing_databases_ready
		ensure_listing_databases_ready()
	except Exception as e:
		kodi_utils.logger('routing', 'prepare listing: %s' % e)

PHASES = []   # 'name seconds' pieces of the plugin start-up, written into the MenuTiming log line

def _phase(name, started):
	PHASES.append('%s %.2f' % (name, time.time() - started))

IMPORT_SECONDS = 0.0   # set by nightshift.py: Python start-up + imports before routing began

def routing(sys):
	del PHASES[:]   # (the plugin's Python session is reused between menu opens: each open starts its own list)
	PHASES.append('imports %.2f' % IMPORT_SECONDS)
	_tc = time.time()
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
	mode = params.get('mode', 'navigator.main')
	state = None
	try:
		state = begin(sys, params, mode)
		_phase('list-cache', _tc)
		if state.get('mode') == 'done': return
	except Exception as e:
		kodi_utils.logger('routing', 'listing cache: %s' % e)
	try: _routing_build(sys)
	finally:
		if state:
			try: finish(state)
			except Exception as e: kodi_utils.logger('routing', 'listing cache finish: %s' % e)

def _routing_build(sys):
	from modules import kodi_utils
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
	mode = params.get('mode', 'navigator.main')
	_t = time.time()
	try:
		from caches.settings_cache import sync_kodi_profile_context
		sync_kodi_profile_context()
	except Exception as e:
		kodi_utils.logger('routing', 'profile context: %s' % e)
	_phase('profile', _t); _t = time.time()
	prepare_directory_listing(mode)
	_phase('databases', _t); _t = time.time()
	from caches.settings_cache import ensure_settings_properties_loaded, should_block_bootstrap_on_entry
	if should_block_bootstrap_on_entry(mode):
		try: ensure_settings_properties_loaded()
		except Exception as e: kodi_utils.logger('routing', 'bootstrap: %s' % e)
		_phase('settings', _t)
	PHASES.append('_build')   # everything after this point is the menu / list itself (imports + building)
	if 'navigator.' in mode:
		from indexers.navigator import Navigator
		return exec('Navigator(params).%s()' % mode.split('.')[1])
	elif 'menu_editor.' in mode:
		from modules.menu_editor import MenuEditor
		return exec('MenuEditor(params).%s()' % mode.split('.')[1])
	elif 'personal_lists.' in mode:
		from indexers import personal_lists
		return exec('personal_lists.%s(params)' % mode.split('.')[1])
	elif 'tmdblist.' in mode:
		from indexers import tmdb_lists
		return exec('tmdb_lists.%s(params)' % mode.split('.')[1])
	elif 'easynews.' in mode:
		from indexers import easynews
		return exec('easynews.%s(params)' % mode.split('.')[1])
	elif mode.startswith('nzb.'):
		from indexers import nzb
		return exec('nzb.%s(params)' % mode.split('.')[1])
	elif 'playback.' in mode:
		from modules.kodi_utils import player_check
		return player_check(mode, params)
	elif 'choice' in mode:
		from indexers import dialogs
		return exec('dialogs.%s(params)' % mode)
	elif mode.startswith('show_theme.'):
		from modules import show_theme
		return {'override': show_theme.override_dialog, 'clear_pick': show_theme.clear_pick, 'clear_all_picks': show_theme.clear_all_picks,
				'purge_all': show_theme.purge_all, 'rescan_folder': show_theme.rescan_folder, 'import_songs': show_theme.import_songs}[mode.split('.')[1]](params)
	elif 'custom_key.' in mode:
		from modules import custom_keys
		return exec('custom_keys.%s()' % mode.split('custom_key.')[1])
	elif 'simkl.' in mode:
		if '.list.' in mode:
			from indexers import simkl_lists
			return exec('simkl_lists.%s(params)' % mode.split('.')[2])
		from apis import simkl_api
		return exec('simkl_api.%s(params)' % mode.split('.')[1])
	elif 'mdblist.' in mode:
		from apis import mdblist_api
		return exec('mdblist_api.%s(params)' % mode.split('.')[1])
	elif 'punchplay.' in mode:
		if '.list.' in mode:
			from indexers import punchplay_lists
			return exec('punchplay_lists.%s(params)' % mode.split('.')[2])
		from apis import punchplay_api
		return exec('punchplay_api.%s(params)' % mode.split('.')[1])
	elif 'wetrakr.' in mode:
		from apis import wetrakr_api
		return exec('wetrakr_api.%s(params)' % mode.split('.')[1])
	elif 'trakt.' in mode:
		if '.list' in mode:
			from indexers import trakt_lists
			return exec('trakt_lists.%s(params)' % mode.split('.')[2])
		from apis import trakt_api
		return exec('trakt_api.%s(params)' % mode.split('.')[1])
	elif 'build' in mode:
		if mode == 'build_movie_list':
			from indexers.movies import Movies
			return Movies(params).fetch_list()
		elif mode == 'build_tvshow_list':
			from indexers.tvshows import TVShows
			return TVShows(params).fetch_list()
		elif mode == 'build_season_list':
			from indexers.seasons import build_season_list
			return build_season_list(params)
		elif mode == 'build_episode_list':
			from indexers.episodes import build_episode_list
			return build_episode_list(params)
		elif mode == 'build_in_progress_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.progress', params)
		elif mode == 'build_recently_watched_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.recently_watched', params)
		elif mode == 'build_next_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.next', params)
		elif mode == 'build_my_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.trakt', params)
		elif mode == 'build_mdbl_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.mdblist', params)
		elif mode == 'build_punchplay_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.punchplay', params)
		elif mode == 'build_simkl_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.simkl', params)
		elif mode == 'build_simkl_public_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.simkl_public', params)
		elif mode == 'build_mdbl_next_up':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.mdblist_next', params)
		elif mode == 'build_next_episode_manager':
			from modules.episode_tools import build_next_episode_manager
			return build_next_episode_manager()
		elif mode == 'build_tmdb_people':
			from indexers.people import tmdb_people
			return tmdb_people(params)
		elif 'random.' in mode:
			from indexers.random_lists import RandomLists
			return RandomLists(params).run_random()
	elif 'watched_status.' in mode:
		if mode == 'watched_status.mark_episode':
			from modules.watched_status import mark_episode
			return mark_episode(params)
		elif mode == 'watched_status.mark_season':
			from modules.watched_status import mark_season
			return mark_season(params)
		elif mode == 'watched_status.mark_tvshow':
			from modules.watched_status import mark_tvshow
			return mark_tvshow(params)
		elif mode == 'watched_status.mark_movie':
			from modules.watched_status import mark_movie
			return mark_movie(params)
		elif mode == 'watched_status.erase_bookmark':
			from modules.watched_status import erase_bookmark
			return erase_bookmark(params.get('media_type'), params.get('tmdb_id'), params.get('season', ''), params.get('episode', ''), params.get('refresh', 'false'))
		elif mode == 'watched_status.unmark_previous_episode':
			from modules.watched_status import unmark_previous_episode
			return unmark_previous_episode(params)
	elif 'search.' in mode:
		if mode == 'search.get_key_id':
			from modules.search import get_key_id
			return get_key_id(params)
		elif mode == 'search.clear_search':
			from modules.search import clear_search
			return clear_search()
		elif mode == 'search.remove':
			from modules.search import remove_from_search
			return remove_from_search(params)
		elif mode == 'search.clear_all':
			from modules.search import clear_all
			return clear_all(params.get('setting_id'), params.get('refresh', 'false'))
		elif mode == 'search.clear_easynews_search_history':
			from modules.search import clear_easynews_search_history
			return clear_easynews_search_history(params.get('refresh', 'false'))
	elif 'real_debrid' in mode:
		if mode == 'real_debrid.rd_cloud':
			from indexers.real_debrid import rd_cloud
			return rd_cloud()
		elif mode == 'real_debrid.rd_downloads':
			from indexers.real_debrid import rd_downloads
			return rd_downloads()
		elif mode == 'real_debrid.browse_rd_cloud':
			from indexers.real_debrid import browse_rd_cloud
			return browse_rd_cloud(params.get('id'))
		elif mode == 'real_debrid.resolve_rd':
			from indexers.real_debrid import resolve_rd
			return resolve_rd(params)
		elif mode == 'real_debrid.rd_account_info':
			from indexers.real_debrid import rd_account_info
			return rd_account_info()
		elif mode == 'real_debrid.authenticate':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().auth()
		elif mode == 'real_debrid.revoke_authentication':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().revoke()
		elif mode == 'real_debrid.delete':
			from indexers.real_debrid import rd_delete
			return rd_delete(params.get('id'), params.get('cache_type'))
	elif 'premiumize' in mode:
		if mode == 'premiumize.pm_cloud':
			from indexers.premiumize import pm_cloud
			return pm_cloud(params.get('id', None), params.get('folder_name', None))
		elif mode == 'premiumize.pm_transfers':
			from indexers.premiumize import pm_transfers
			return pm_transfers()
		elif mode == 'premiumize.pm_account_info':
			from indexers.premiumize import pm_account_info
			return pm_account_info()
		elif mode == 'premiumize.authenticate':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().auth()
		elif mode == 'premiumize.revoke_authentication':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().revoke()
		elif mode == 'premiumize.rename':
			from indexers.premiumize import pm_rename
			return pm_rename(params.get('file_type'), params.get('id'), params.get('name'))
		elif mode == 'premiumize.delete':
			from indexers.premiumize import pm_delete
			return pm_delete(params.get('file_type'), params.get('id'))
	elif 'alldebrid' in mode:
		if mode == 'alldebrid.ad_cloud':
			from indexers.alldebrid import ad_cloud
			return ad_cloud()
		elif mode == 'alldebrid.ad_downloads':
			from indexers.alldebrid import ad_downloads
			return ad_downloads()
		elif mode == 'alldebrid.ad_saved_links':
			from indexers.alldebrid import ad_saved_links
			return ad_saved_links()
		elif mode == 'alldebrid.browse_ad_cloud':
			from indexers.alldebrid import browse_ad_cloud
			return browse_ad_cloud(params.get('id'))
		elif mode == 'alldebrid.resolve_ad':
			from indexers.alldebrid import resolve_ad
			return resolve_ad(params)
		elif mode == 'alldebrid.ad_account_info':
			from indexers.alldebrid import ad_account_info
			return ad_account_info()
		elif mode == 'alldebrid.authenticate':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().auth()
		elif mode == 'alldebrid.revoke_authentication':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().revoke()
		elif mode == 'alldebrid.delete':
			from indexers.alldebrid import ad_delete
			return ad_delete(params.get('id'))
	elif 'offcloud' in mode:
		if mode == 'offcloud.oc_cloud':
			from indexers.offcloud import oc_cloud
			return oc_cloud()
		elif mode == 'offcloud.oc_history':
			from indexers.offcloud import oc_history
			return oc_history()
		elif mode == 'offcloud.browse_oc_cloud':
			from indexers.offcloud import browse_oc_cloud
			return browse_oc_cloud(params.get('folder_id'))
		elif mode == 'offcloud.resolve_oc':
			from indexers.offcloud import resolve_oc
			return resolve_oc(params)
		elif mode == 'offcloud.oc_account_info':
			from indexers.offcloud import oc_account_info
			return oc_account_info()
		elif mode == 'offcloud.authenticate':
			from apis.offcloud_api import OffcloudAPI
			return OffcloudAPI().auth()
		elif mode == 'offcloud.revoke_authentication':
			from apis.offcloud_api import OffcloudAPI
			return OffcloudAPI().revoke()
		elif mode == 'offcloud.delete':
			from indexers.offcloud import oc_delete
			return oc_delete(params.get('folder_id'))
	elif 'torbox' in mode:
		if mode == 'torbox.tb_cloud':
			from indexers.torbox import tb_cloud
			return tb_cloud()
		elif mode == 'torbox.tb_history':
			from indexers.torbox import tb_history
			return tb_history()
		elif mode == 'torbox.browse_tb_cloud':
			from indexers.torbox import browse_tb_cloud
			return browse_tb_cloud(params.get('folder_id'), params.get('media_type'))
		elif mode == 'torbox.resolve_tb':
			from indexers.torbox import resolve_tb
			return resolve_tb(params)
		elif mode == 'torbox.tb_account_info':
			from indexers.torbox import tb_account_info
			return tb_account_info()
		elif mode == 'torbox.authenticate':
			from apis.torbox_api import TorBoxAPI
			return TorBoxAPI().auth()
		elif mode == 'torbox.revoke_authentication':
			from apis.torbox_api import TorBoxAPI
			return TorBoxAPI().revoke()
		elif mode == 'torbox.delete':
			from indexers.torbox import tb_delete
			return tb_delete(params.get('folder_id'), params.get('media_type'))
		elif mode == 'torbox.airlock':
			from indexers.torbox import tb_airlock
			return tb_airlock(params.get('folder_id'), params.get('media_type'))
		elif mode == 'torbox.send_webdl':
			from indexers.torbox import tb_send_webdl
			tb_send_webdl()
	elif 'tmdblist_api' in mode:
		if mode == 'tmdblist_api.authenticate':
			from apis.tmdblist_api import TMDbListAPI
			return TMDbListAPI().auth()
		elif mode == 'tmdblist_api.revoke_authentication':
			from apis.tmdblist_api import TMDbListAPI
			return TMDbListAPI().revoke()
	elif '_cache' in mode:
		from caches import base_cache
		if mode == 'clear_cache':
			return base_cache.clear_cache(params.get('cache'))
		elif mode == 'clear_autoplay_cache':
			# one show's saved Autoplay link (Options -> Clear Autoplay)
			from modules import kodi_utils
			from caches.autoplay_cache import autoplay_cache
			removed = autoplay_cache.clear_origin(params.get('tmdb_id'))
			return kodi_utils.notification('Autoplay cleared' if removed else 'No saved Autoplay link for this show', 3000)
		elif mode == 'view_watching_cache':
			from modules import kodi_utils
			from caches import watching_cache
			rows, total = watching_cache.entries(10), watching_cache.count()
			if not total: return kodi_utils.ok_dialog(heading='Currently Watching Cache', text='Empty')
			lines = ['%s (TMDb %s)  |  %s  |  %s  |  %s  |  %d result(s)' % (show or '?', tid or '?', s.upper(), kind, q, n) for show, tid, s, kind, q, n in rows]
			if total > len(rows): lines.append('... and %d more' % (total - len(rows)))
			return kodi_utils.show_text('Currently Watching Cache (%d)' % total, text='\n'.join(lines))
		elif mode == 'clear_all_cache':
			return base_cache.clear_all_cache()
		elif mode == 'clean_databases_cache':
			return base_cache.clean_databases()
		elif mode == 'check_databases_integrity_cache':
			return base_cache.check_databases_integrity()
	elif '_image' in mode:
		from indexers.images import Images
		return Images().run(params)
	elif '_text' in mode:
		if mode == 'show_text':
			from modules.kodi_utils import show_text
			return show_text(params.get('heading'), params.get('text', None), params.get('file', None),
							params.get('font_size', 'small'), params.get('kodi_log', 'false') == 'true')
		elif mode == 'show_text_media':
			# ###FIX### imported a show_text_media that does not exist in kodi_utils, then called show_text
			# (not imported in this branch) with meta/{} as font_size/kodi_log. Nothing routes here today; make it safe.
			from modules.kodi_utils import show_text
			return show_text(params.get('heading'), params.get('text', None), params.get('file', None))
	elif 'settings_manager.' in mode:
		from caches import settings_cache
		return exec('settings_cache.%s(params)' % mode.split('.')[1])
	elif 'downloader.' in mode:
		from modules import downloader
		return exec('downloader.%s(params)' % mode.split('.')[1])
	elif 'local_backup.' in mode:
		from modules import local_backup
		return getattr(local_backup, mode.split('.', 1)[1])(params)
	elif 'settings_backup.' in mode:
		from modules import settings_backup
		return getattr(settings_backup, mode.split('.', 1)[1])(params)
	elif 'kodi_favorites.' in mode:
		from modules import kodi_favorites_backup
		return getattr(kodi_favorites_backup, mode.split('.', 1)[1])(params)
	elif mode == 'set_view':
		from indexers.navigator import Navigator
		return Navigator(params).set_view()
	elif mode == 'sync_settings':
		from caches.settings_cache import sync_settings
		return sync_settings(params)
	elif mode == 'person_direct.search':
		from indexers.people import person_direct_search
		return person_direct_search(params.get('key_id') or params.get('query'))
	elif mode == 'kodi_refresh':
		from modules.kodi_utils import kodi_refresh
		return kodi_refresh()
	elif mode == 'refresh_widgets':
		from modules.kodi_utils import refresh_widgets
		return refresh_widgets(
			params.get('silent', 'false') == 'true',
			params.get('reload_skin', 'false') == 'true',
			params.get('defer_browsing', 'false') == 'true')
	elif mode == 'person_data_dialog':
		from indexers.people import person_data_dialog
		return person_data_dialog(params)
	elif mode == 'favorite_people':
		from indexers.people import favorite_people
		return favorite_people()
	elif mode == 'manual_add_magnet_to_cloud':
		from modules.debrid import manual_add_magnet_to_cloud
		return manual_add_magnet_to_cloud(params)
	elif mode == 'upload_logfile':
		from modules.kodi_utils import upload_logfile
		return upload_logfile(params)
	elif mode == 'downloader':
		from modules.downloader import runner
		return runner(params)
	elif mode == 'debrid.browse_packs':
		from modules.sources import Sources
		source_item = params.get('source_item')
		if isinstance(source_item, str):
			try:
				source_item = json.loads(source_item)
			except:
				source_item = None
		return Sources().debridPacks(params.get('provider'), params.get('name'), params.get('magnet_url'), params.get('info_hash'), source_item=source_item)
	elif mode == 'open_settings':
		from modules.kodi_utils import open_settings
		return open_settings(params.get('section'))
	elif mode == 'opensubs_test_login':
		from apis.opensubs_api import check_account
		return check_account()
	elif mode == 'opensubs_check_account':
		from apis.opensubs_api import check_account
		return check_account()
	elif mode == 'opensubs_revoke':
		from apis.opensubs_api import revoke_access
		return revoke_access()
	elif mode == 'hide_unhide_progress_items':
		from modules.watched_status import hide_unhide_progress_items
		return hide_unhide_progress_items(params)
	elif mode in ('external_scraper_clear_slot', 'external_scraper_move_slot'):
		from indexers import dialogs
		return exec('dialogs.%s(params)' % mode)
	elif mode == 'open_external_scraper_settings':
		from modules.kodi_utils import external_scraper_settings
		return external_scraper_settings(params)
	elif mode == 'trigger_thumbnail_cleanup':
		from caches.settings_cache import get_setting
		if get_setting('nightshift.thumbnail_cleanup_enabled', 'false') != 'true':
			return kodi_utils.notification('Thumbnail Cleanup is Disabled', 3000)
		confirmed = kodi_utils.confirm_dialog(
			heading='Thumbnail Cache Maintenance',
			text='Clean the thumbnail cache now?[CR][CR]This will:[CR]- Delete cached artwork files[CR]- Remove orphaned entries from Kodi\'s texture database[CR]- Clear NIGHTSHIFT\'s metadata cache[CR]- You Must Restart Kodi Manually',
			ok_label='Clean Now', cancel_label='Cancel', scroll=False)
		if not confirmed:
			return
		# Show busy dialog during cleanup (avoids frozen settings window)
		kodi_utils.show_busy_dialog()
		try:
			from service import ThumbnailCleanup
			removed, pruned = ThumbnailCleanup().run_now()
		finally:
			kodi_utils.hide_busy_dialog()
		if removed is None:
			return kodi_utils.notification('Thumbnail Cleanup Failed - see log', 4000)
		kodi_utils.notification('%s thumbnails cleared, %s DB rows pruned' % (removed, pruned), 5000)

# ===== list cache (kept in this file: a new module file is not seen by a Python session that was running before an update) =====

_MODES = frozenset((
	'build_movie_list', 'build_tvshow_list', 'build_season_list', 'build_episode_list', 'build_in_progress_episode',
	'build_recently_watched_episode', 'build_next_episode', 'build_my_calendar', 'build_mdbl_calendar', 'build_punchplay_calendar',
	'build_simkl_calendar', 'build_simkl_public_calendar', 'build_mdbl_next_up'))
_WATCHED_MODES = frozenset((
	'build_season_list', 'build_episode_list', 'build_in_progress_episode', 'build_recently_watched_episode', 'build_next_episode',
	'build_my_calendar', 'build_mdbl_calendar', 'build_punchplay_calendar', 'build_simkl_calendar', 'build_simkl_public_calendar',
	'build_mdbl_next_up', 'build_movie_list', 'build_tvshow_list'))
_WATCHED_MODES = _WATCHED_MODES - {'build_simkl_public_calendar'}      # airing dates only: not tied to what was watched
_REFRESH_BY_MODE = {'build_simkl_public_calendar': 6 * 3600}           # the public (anime) calendar is rebuilt at most every 6 hours
_MAX_AGE = 7 * 86400          # a saved list is not used after a week
_REFRESH_AFTER = 300          # a list opened again within this many seconds is not rebuilt in the background (see _REFRESH_BY_MODE)
_MAX_FILES = 80

RECORDING = False             # ListItems made now are recorders
SUPPRESS = False              # background rebuild: nothing goes to Kodi
_EVENTS = []
_OK = True

class _Unrecordable(Exception): pass

def _enc(v):
	if v is None or isinstance(v, (bool, int, float, str)): return v
	if isinstance(v, tuple): return {'__t__': [_enc(i) for i in v]}
	if isinstance(v, list): return [_enc(i) for i in v]
	if isinstance(v, dict):
		if not all(isinstance(k, str) for k in v): raise _Unrecordable('key')
		return {k: _enc(i) for k, i in v.items()}
	if type(v).__name__ == 'Actor':
		try: return {'__actor__': [v.getName(), v.getRole(), v.getOrder(), v.getThumbnail()]}
		except Exception: raise _Unrecordable('actor')
	raise _Unrecordable(type(v).__name__)

def _dec(v):
	if isinstance(v, list): return [_dec(i) for i in v]
	if isinstance(v, dict):
		if '__t__' in v: return tuple(_dec(i) for i in v['__t__'])
		if '__actor__' in v:
			import xbmc
			return xbmc.Actor(*v['__actor__'])
		return {k: _dec(i) for k, i in v.items()}
	return v

class Rec(object):
	"""Forwards every call to the real Kodi object and writes it down."""
	def __init__(self, real, log=None, oid=0):
		self._o, self._log, self._id = real, [] if log is None else log, oid
	def __getattr__(self, name):
		target = getattr(self._o, name)
		if not callable(target): return target
		def call(*args, **kwargs):
			global _OK
			result = target(*args, **kwargs)
			try:
				entry = [self._id, name, _enc(list(args)), _enc(kwargs)]
				child = None
				if result is not None and not isinstance(result, (bool, int, float, str, list, tuple, dict)):
					child = len(self._log) + 1
					entry.append(child)
					self._log.append(entry)
					return Rec(result, self._log, child)
				self._log.append(entry)
			except _Unrecordable:
				_OK = False
			return result
		return call

def wrap_listitem(real):
	return Rec(real)

def unwrap(item):
	return item._o if isinstance(item, Rec) else item

def note(kind, *args):
	"""Called by kodi_utils for each directory call while a list is recorded."""
	global _OK
	if not RECORDING: return
	try:
		if kind == 'items':
			out = []
			for url, li, folder in args[0]:
				if not isinstance(li, Rec): raise _Unrecordable('plain item')
				out.append([url, li._log, bool(folder)])
			_EVENTS.append(['items', out])
		elif kind == 'item':
			url, li, folder = args
			if not isinstance(li, Rec): raise _Unrecordable('plain item')
			_EVENTS.append(['items', [[url, li._log, bool(folder)]]])
		else:
			_EVENTS.append([kind] + [_enc(a) for a in args])
	except _Unrecordable:
		_OK = False

def _replay_item(log):
	import xbmcgui
	objs = {0: xbmcgui.ListItem(offscreen=True)}
	for entry in log:
		oid, name, args, kwargs = entry[0], entry[1], _dec(entry[2]), _dec(entry[3])
		result = getattr(objs[oid], name)(*args, **kwargs)
		if len(entry) > 4: objs[entry[4]] = result

def _replay(handle, events):
	import xbmcplugin, xbmcgui
	for ev in events:
		kind = ev[0]
		if kind == 'items':
			items = []
			for url, log, folder in ev[1]:
				objs = {0: xbmcgui.ListItem(offscreen=True)}
				for entry in log:
					oid, name, args, kwargs = entry[0], entry[1], _dec(entry[2]), _dec(entry[3])
					result = getattr(objs[oid], name)(*args, **kwargs)
					if len(entry) > 4: objs[entry[4]] = result
				items.append((url, objs[0], folder))
			xbmcplugin.addDirectoryItems(handle, items)
		elif kind == 'content': xbmcplugin.setContent(handle, ev[1])
		elif kind == 'category': xbmcplugin.setPluginCategory(handle, ev[1])
		elif kind == 'sort': xbmcplugin.addSortMethod(handle, ev[1], labelMask=ev[2])
		elif kind == 'end': xbmcplugin.endOfDirectory(handle, updateListing=ev[1], cacheToDisc=ev[2])

def _folder():
	return os.path.join(kodi_utils.addon_profile(), 'listing_cache')

def _one_db_stamp(name):
	from caches.base_cache import content_stamp
	return content_stamp(name)

def _db_stamp(names):
	parts = []
	for name in names:
		try: parts.append('%s=%s' % (name.replace('_db', ''), _one_db_stamp(name)))
		except Exception: parts.append('%s=?' % name)
	return '|'.join(parts)

_LAST_STAMP = ''

def _key(argv2, mode):
	names = ['settings_db', 'navigator_db', 'favorites_db']
	if mode in _WATCHED_MODES: names.append('watched_db')
	version = kodi_utils.addon_info('version')
	stamp = _db_stamp(names)
	global _LAST_STAMP
	_LAST_STAMP = stamp
	return version, hashlib.sha1(('%s|%s|%s' % (version, argv2, stamp)).encode('utf-8', 'replace')).hexdigest()

def _tidy(version):
	"""Only this version's folder survives; old and surplus files go."""
	try:
		base = _folder()
		if not os.path.isdir(base): return
		for name in os.listdir(base):
			path = os.path.join(base, name)
			if name != version and os.path.isdir(path):
				import shutil; shutil.rmtree(path, ignore_errors=True)
			elif os.path.isfile(path): os.remove(path)
		cur = os.path.join(base, version)
		if os.path.isdir(cur):
			files = sorted((os.path.join(cur, f) for f in os.listdir(cur)), key=os.path.getmtime)
			for f in files[:max(0, len(files) - _MAX_FILES)]: os.remove(f)
	except Exception: pass

def begin(sys_mod, params, mode):
	"""Returns the state for finish(). May already show the saved list."""
	global RECORDING, SUPPRESS, _EVENTS, _OK
	state = {'mode': None}
	try:
		if mode not in _MODES or len(sys_mod.argv) < 3: return state
		if 'random' in sys_mod.argv[2].lower(): return state
		_tk = time.time()
		version, key = _key(sys_mod.argv[2], mode)
		if time.time() - _tk > 0.3: kodi_utils.logger('ListingCache', 'checking the saved state took %.2fs' % (time.time() - _tk))
		path = os.path.join(_folder(), version, key + '.json')
		state.update(path=path, version=version, argv2=sys_mod.argv[2], mode_name=mode)
		_EVENTS, _OK = [], True
		age = None
		try:
			age = time.time() - os.path.getmtime(path)
			if age > _MAX_AGE: age = None
		except OSError: pass
		if age is not None:
			try:
				with open(path, 'r', encoding='utf-8') as f: data = json.load(f)
				t = time.time()
				_replay(int(sys_mod.argv[1]), data['events'])
				kodi_utils.logger('ListingCache', '%s shown from disk in %.2fs (%d events, saved %ds ago)' % (mode, time.time() - t, len(data['events']), age))
				if age < _REFRESH_BY_MODE.get(mode, _REFRESH_AFTER):
					state['mode'] = 'done'
					return state
				SUPPRESS = True        # build again quietly so the next open is current
				state['mode'] = 'refresh'
				RECORDING = True
				return state
			except Exception as e:
				kodi_utils.logger('ListingCache', 'saved copy unusable (%s) - building' % e)
				try: os.remove(path)
				except OSError: pass
				SUPPRESS = False
		kodi_utils.logger('ListingCache', '%s: no saved copy for this state (%s) - building' % (mode, _LAST_STAMP))
		RECORDING = True
		state['mode'] = 'record'
	except Exception as e:
		kodi_utils.logger('ListingCache', 'begin: %s' % e)
		RECORDING = SUPPRESS = False
	return state

def finish(state):
	global RECORDING, SUPPRESS
	was = state.get('mode')
	events, ok = list(_EVENTS), _OK
	RECORDING = SUPPRESS = False
	if was not in ('record', 'refresh'): return
	try:
		if not ok or not events or events[-1][0] != 'end' or not any(e[0] == 'items' and e[1] for e in events):
			return
		paths = [state['path']]
		try:       # the build itself may have changed what the key is made of: the copy must also be found under the state AFTER it
			v2, k2 = _key(state['argv2'], state['mode_name'])
			p2 = os.path.join(_folder(), v2, k2 + '.json')
			if p2 not in paths: paths.append(p2)
		except Exception: pass
		os.makedirs(os.path.dirname(paths[0]), exist_ok=True)
		for path in paths:
			tmp = path + '.tmp'
			with open(tmp, 'w', encoding='utf-8') as f: json.dump({'events': events}, f)
			os.replace(tmp, path)
		_tidy(state['version'])
	except Exception as e:
		kodi_utils.logger('ListingCache', 'save: %s' % e)
