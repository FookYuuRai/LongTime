# -*- coding: utf-8 -*-
"""The built-in ambience tracks are not in the add-on zip. They come as one pack (a zip of the track files) attached to
a GitHub release, and are kept in the add-on's data folder. The first start of the service downloads the pack, checks
its SHA-256 and unpacks it. Until then the built-in tracks are simply not played (the folders you add still are)."""
import hashlib
import os
import shutil
import threading
import urllib.request
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

from tracks import BUILTIN_TRACKS

PACK_URL = 'https://github.com/FookYuuRai/LongTime/releases/download/ambience-audio-v1/ambience-audio-opus96.zip'
PACK_SHA256 = '909525cc0588d2fc5424bc0b833999c7ee1e705c4fcd1841f507be1b487d248b'
PACK_SIZE = 61604994                              # bytes; used only for the progress text
CHUNK = 256 * 1024
TIMEOUT = 30

_lock = threading.Lock()
_running = False


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[NIGHTSHIFT ambience] builtin audio: %s' % msg, level)


def data_dir():
    return xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/builtin_audio/')


def _names():
    return [name for _setting, name, _label in BUILTIN_TRACKS]


def path_for(name):
    """The file of a built-in track, or None while the pack is not there."""
    p = os.path.join(data_dir(), name)
    return p if os.path.isfile(p) and os.path.getsize(p) > 0 else None


def missing():
    return [n for n in _names() if path_for(n) is None]


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(CHUNK), b''):
            h.update(block)
    return h.hexdigest()


def download(url, target, progress=None):
    """Download url to target (a file written in full or not at all)."""
    part = target + '.part'
    with urllib.request.urlopen(url, timeout=TIMEOUT) as response, open(part, 'wb') as out:
        total = int(response.headers.get('Content-Length') or PACK_SIZE or 0)
        done = 0
        while True:
            block = response.read(CHUNK)
            if not block:
                break
            out.write(block)
            done += len(block)
            if progress:
                progress(done, total)
    os.replace(part, target)


def unpack(pack, folder):
    """Extract the track files of the pack into folder. Only the names of BUILTIN_TRACKS are taken; anything else is
    ignored, and names with a folder part are refused. The pack may sit inside folder: the files are extracted to a
    staging folder first and moved into place one by one, so nothing is deleted before it is read."""
    wanted = set(_names())
    staging = folder.rstrip(os.sep) + '_unpack'
    if os.path.isdir(staging):
        shutil.rmtree(staging)
    os.makedirs(staging)
    with zipfile.ZipFile(pack) as z:
        for info in z.infolist():
            name = info.filename
            if info.is_dir() or '/' in name or '\\' in name or name not in wanted:
                continue
            with z.open(info) as src, open(os.path.join(staging, name), 'wb') as dst:
                shutil.copyfileobj(src, dst)
    os.makedirs(folder, exist_ok=True)
    for name in os.listdir(staging):
        os.replace(os.path.join(staging, name), os.path.join(folder, name))
    shutil.rmtree(staging)
    return [n for n in wanted if not os.path.isfile(os.path.join(folder, n))]


def install(url=PACK_URL, sha256=PACK_SHA256, folder=None, progress=None):
    """Download, check and unpack the pack. Returns the list of track names still missing (empty when all is well)."""
    folder = folder or data_dir()
    os.makedirs(folder, exist_ok=True)
    pack = os.path.join(folder, 'pack.zip')
    download(url, pack, progress)
    got = sha256_of(pack)
    if got != sha256:
        os.remove(pack)
        raise ValueError('pack checksum is %s, expected %s' % (got, sha256))
    still = unpack(pack, folder)
    os.remove(pack)
    return still


def ensure_async(notify=True):
    """Start the download in the background if any built-in track is missing. Safe to call on every start."""
    global _running
    if not missing():
        return
    with _lock:
        if _running:
            return
        _running = True
    threading.Thread(target=_worker, args=(notify,), daemon=True).start()


def _worker(notify):
    global _running
    try:
        if notify:
            xbmcgui.Dialog().notification('NIGHTSHIFT Ambience', 'Downloading the built-in tracks', xbmcgui.NOTIFICATION_INFO, 4000, False)
        log('downloading the built-in tracks from %s' % PACK_URL)
        still = install()
        if still:
            log('pack did not contain: %s' % ', '.join(still), xbmc.LOGWARNING)
        elif notify:
            xbmcgui.Dialog().notification('NIGHTSHIFT Ambience', 'Built-in tracks installed', xbmcgui.NOTIFICATION_INFO, 4000, False)
        log('built-in tracks installed')
    except Exception as e:
        log('could not install the built-in tracks: %s' % e, xbmc.LOGWARNING)
        if notify:
            xbmcgui.Dialog().notification('NIGHTSHIFT Ambience', 'Built-in tracks not installed (see log)', xbmcgui.NOTIFICATION_WARNING, 6000, False)
    finally:
        with _lock:
            _running = False
