# -*- coding: utf-8 -*-
"""The extra music folders of NIGHTSHIFT ambience: stored in the add-on's data folder, scanned for tracks."""
import json
import os

import xbmc
import xbmcvfs

CONVERTED = ('.mp3', '.m4a', '.opus')
EXTENSIONS = ('.mp3', '.flac', '.ogg', '.oga', '.opus', '.m4a', '.aac', '.wav', '.wma', '.ape', '.wv')
MAX_DEPTH = 4
MAX_TRACKS = 3000


def _file():
	folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/')
	if not xbmcvfs.exists(folder):
		xbmcvfs.mkdirs(folder)
	return os.path.join(folder, 'folders.json')


def stamp():
	"""Changes whenever the list of folders changes (the service looks at it to reload)."""
	try:
		return os.path.getmtime(_file())
	except OSError:
		return 0


def load():
	try:
		with open(_file(), encoding='utf-8') as handle:
			data = json.load(handle)
		return [str(x) for x in data if x]
	except Exception:
		return []


def save(folders):
	try:
		with open(_file(), 'w', encoding='utf-8') as handle:
			json.dump(list(folders), handle, indent=1, ensure_ascii=False)
		return True
	except Exception as error:
		xbmc.log('[NIGHTSHIFT ambience] cannot save folders: %s' % error, xbmc.LOGWARNING)
		return False


def _join(folder, name):
	if '://' not in folder and '\\' in folder:
		return folder.rstrip('\\') + '\\' + name
	return folder.rstrip('/') + '/' + name


def _text(name):
	"""File names as text (CJK, full-width brackets, etc.); bytes from some back-ends are decoded as UTF-8."""
	if isinstance(name, bytes):
		return name.decode('utf-8', 'replace')
	return name


def scan(folder, depth=0, found=None):
	"""Audio files in a folder and the folders inside it (a few levels deep)."""
	found = [] if found is None else found
	if depth > MAX_DEPTH or len(found) >= MAX_TRACKS:
		return found
	try:
		dirs, files = xbmcvfs.listdir(folder)
	except Exception:
		return found
	dirs, files = [_text(n) for n in dirs], [_text(n) for n in files]
	# A file is skipped when a converted copy (.mp3 / .m4a, made by the converter) with the same name sits beside it,
	# so a song never plays twice while its original is still there.
	converted = set(os.path.splitext(n)[0].lower() for n in files if n.lower().endswith(CONVERTED))
	for name in sorted(files, key=lambda x: x.lower()):
		base, ext = os.path.splitext(name)
		if ext.lower() not in CONVERTED and base.lower() in converted:
			continue
		if name.lower().endswith(EXTENSIONS):
			found.append(_join(folder, name))
			if len(found) >= MAX_TRACKS:
				return found
	for name in sorted(dirs, key=lambda x: x.lower()):
		scan(_join(folder, name), depth + 1, found)
	return found


def tracks():
	"""Every track of every added folder."""
	out = []
	for folder in load():
		for path in scan(folder):
			if path not in out:
				out.append(path)
	return out
