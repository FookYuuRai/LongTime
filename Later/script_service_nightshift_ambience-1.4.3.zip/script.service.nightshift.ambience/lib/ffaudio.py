"""Kodi Python module for the audio codecs inside libffmpeg.so.

Drop-in for a Kodi script.module. Other addons::

    import ffaudio

    pcm = ffaudio.decode_path("special://temp/in.mp3")
    flac = ffaudio.encode_file(pcm.pcm, pcm.rate, pcm.channels, fmt="flac")

Packet path (any name from ffaudio.codecs())::

    dec = ffaudio.Decoder("aac", extradata=asc)
    raw, samples, channels, rate = dec.decode(packet)
    dec.flush()

    enc = ffaudio.Encoder("opus", 48000, 2, bitrate=96000)
    for packet in enc.encode(pcm_f32le_bytes):
        ...
    enc.flush()

MP3 encode is LAME (libmp3lame) inside the same .so. "mp3", "lame", and
"libmp3lame" all encode with LAME and decode with FFmpeg's MP3 decoder.

HE-AAC encode is Fraunhofer FDK-AAC, also inside this .so:
    Encoder("heaac", rate, channels, bitrate)    # HE-AAC v1
    Encoder("heaacv2", rate, 2, bitrate)         # HE-AAC v2, stereo only
    Encoder("libfdk_aac", rate, channels, bitrate)
ALAC encode and decode are the native FFmpeg codec: "alac".
HE-AAC decode uses the native AAC decoder ("aac", "heaac", or "heaacv2").

Opus encode is Xiph libopus 1.5.2. Vorbis encode is Xiph libvorbis 1.3.7.
Encoder("opus") and Encoder("vorbis") use those libraries.
Decoder("opus") and Decoder("vorbis") use FFmpeg's native decoders.
Decoder("libopus") and Decoder("libvorbis") use the Xiph decoders.

PCM is interleaved little-endian float32. One libffmpeg.so, no other FFmpeg
files. Runtime dependencies are the Android system libc, libm, and libdl.
"""

from __future__ import annotations

import ctypes
import os
import sys

_LIB = None
_CODECS = None


class FFaudioError(Exception):
    pass


class AudioPCM:
    """Interleaved float32 PCM."""

    def __init__(self, pcm: bytes, samples: int, channels: int, rate: int, codec: str):
        self.pcm = pcm
        self.samples = samples
        self.channels = channels
        self.rate = rate
        self.codec = codec

    def __len__(self):
        return self.samples

    def __repr__(self):
        return "AudioPCM(codec=%s rate=%s ch=%s samples=%s bytes=%s)" % (
            self.codec, self.rate, self.channels, self.samples, len(self.pcm)
        )


def _lib_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "libffmpeg.so"),
        os.path.join(here, "arm64-v8a", "libffmpeg.so"),
    ]
    try:
        import xbmcaddon
        import xbmcvfs

        base = xbmcvfs.translatePath(xbmcaddon.Addon("script.module.ffaudio").getAddonInfo("path"))
        candidates.insert(0, os.path.join(base, "lib", "libffmpeg.so"))
    except Exception:
        pass
    for path in candidates:
        if path and os.path.isfile(path):
            return path
    raise FFaudioError("libffmpeg.so not found next to ffaudio.py")


def _bind(lib):
    c_int = ctypes.c_int
    c_int64 = ctypes.c_int64
    c_char_p = ctypes.c_char_p
    c_void_p = ctypes.c_void_p
    c_float_p = ctypes.POINTER(ctypes.c_float)
    c_uint8_p = ctypes.POINTER(ctypes.c_uint8)
    p_float = ctypes.POINTER(c_float_p)
    p_uint8 = ctypes.POINTER(c_uint8_p)

    lib.ffw_init.argtypes = []
    lib.ffw_init.restype = c_int
    lib.ffw_version.argtypes = []
    lib.ffw_version.restype = c_char_p
    lib.ffw_wrapper_version.argtypes = []
    lib.ffw_wrapper_version.restype = c_char_p
    lib.ffw_last_error.argtypes = []
    lib.ffw_last_error.restype = c_char_p
    lib.ffw_codec_count.argtypes = []
    lib.ffw_codec_count.restype = c_int
    lib.ffw_codec_at.argtypes = [
        c_int, ctypes.c_char_p, c_int, ctypes.c_char_p, c_int,
        ctypes.POINTER(c_int), ctypes.POINTER(c_int),
    ]
    lib.ffw_codec_at.restype = c_int
    lib.ffw_free.argtypes = [c_void_p]
    lib.ffw_free.restype = None

    lib.ffw_dec_open.argtypes = [c_char_p, c_int, c_int, ctypes.c_void_p, c_int]
    lib.ffw_dec_open.restype = c_void_p
    lib.ffw_dec_close.argtypes = [c_void_p]
    lib.ffw_dec_close.restype = None
    lib.ffw_dec_codec.argtypes = [c_void_p]
    lib.ffw_dec_codec.restype = c_char_p
    lib.ffw_dec_decode.argtypes = [
        c_void_p, ctypes.c_void_p, c_int, p_float,
        ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_int),
    ]
    lib.ffw_dec_decode.restype = c_int
    lib.ffw_dec_flush.argtypes = [
        c_void_p, p_float,
        ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_int),
    ]
    lib.ffw_dec_flush.restype = c_int

    lib.ffw_enc_open.argtypes = [c_char_p, c_int, c_int, c_int]
    lib.ffw_enc_open.restype = c_void_p
    lib.ffw_enc_close.argtypes = [c_void_p]
    lib.ffw_enc_close.restype = None
    lib.ffw_enc_codec.argtypes = [c_void_p]
    lib.ffw_enc_codec.restype = c_char_p
    lib.ffw_enc_frame_size.argtypes = [c_void_p]
    lib.ffw_enc_frame_size.restype = c_int
    lib.ffw_enc_sample_rate.argtypes = [c_void_p]
    lib.ffw_enc_sample_rate.restype = c_int
    lib.ffw_enc_channels.argtypes = [c_void_p]
    lib.ffw_enc_channels.restype = c_int
    lib.ffw_enc_extradata.argtypes = [c_void_p, p_uint8, ctypes.POINTER(c_int)]
    lib.ffw_enc_extradata.restype = c_int
    lib.ffw_enc_encode.argtypes = [c_void_p, ctypes.POINTER(ctypes.c_float), c_int]
    lib.ffw_enc_encode.restype = c_int
    lib.ffw_enc_flush.argtypes = [c_void_p]
    lib.ffw_enc_flush.restype = c_int
    lib.ffw_enc_pop.argtypes = [c_void_p, p_uint8, ctypes.POINTER(c_int), ctypes.POINTER(c_int64)]
    lib.ffw_enc_pop.restype = c_int

    lib.ffw_decode_memory.argtypes = [
        ctypes.c_void_p, c_int, p_float,
        ctypes.POINTER(c_int), ctypes.POINTER(c_int), ctypes.POINTER(c_int),
        ctypes.c_char_p, c_int,
    ]
    lib.ffw_decode_memory.restype = c_int
    lib.ffw_encode_memory.argtypes = [
        c_char_p, c_char_p, ctypes.POINTER(ctypes.c_float), c_int, c_int, c_int, c_int,
        p_uint8, ctypes.POINTER(c_int),
    ]
    lib.ffw_encode_memory.restype = c_int
    return lib


def _lib():
    global _LIB
    if _LIB is None:
        path = _lib_path()
        _LIB = _bind(ctypes.CDLL(path))
        if _LIB.ffw_init() != 0:
            raise FFaudioError(_err())
    return _LIB


def _err() -> str:
    raw = _lib().ffw_last_error()
    if not raw:
        return "ffmpeg error"
    return raw.decode("utf-8", "replace")


def _check(rc: int):
    if rc < 0:
        raise FFaudioError(_err())
    return rc


def _u8(buf: bytes | None):
    if not buf:
        return None, 0
    if len(buf) > 0x7FFFFFFF:
        raise FFaudioError("buffer larger than 2 GiB")
    return ctypes.cast(ctypes.create_string_buffer(buf, len(buf)), ctypes.c_void_p), len(buf)


def version() -> str:
    return _lib().ffw_version().decode()


def wrapper_version() -> str:
    return _lib().ffw_wrapper_version().decode()


def codecs() -> list:
    """Every bundled audio codec: name, long_name, encode, decode."""
    global _CODECS
    if _CODECS is not None:
        return list(_CODECS)
    lib = _lib()
    n = lib.ffw_codec_count()
    _check(n if n >= 0 else -1)
    out = []
    for i in range(n):
        name = ctypes.create_string_buffer(64)
        long_name = ctypes.create_string_buffer(256)
        enc = ctypes.c_int()
        dec = ctypes.c_int()
        _check(lib.ffw_codec_at(i, name, 64, long_name, 256, ctypes.byref(enc), ctypes.byref(dec)))
        out.append({
            "name": name.value.decode(),
            "long_name": long_name.value.decode(),
            "encode": bool(enc.value),
            "decode": bool(dec.value),
        })
    _CODECS = out
    return list(out)


def can_decode(name: str) -> bool:
    return any(c["name"] == name and c["decode"] for c in codecs())


def can_encode(name: str) -> bool:
    return any(c["name"] == name and c["encode"] for c in codecs())


def _take_pcm(pcm_ptr, samples, channels, rate) -> tuple:
    samples = samples.value
    channels = channels.value
    rate = rate.value
    if not pcm_ptr or samples <= 0 or channels <= 0:
        if pcm_ptr:
            _lib().ffw_free(pcm_ptr)
        return b"", 0, channels, rate
    nbytes = samples * channels * 4
    raw = ctypes.string_at(pcm_ptr, nbytes)
    _lib().ffw_free(pcm_ptr)
    return raw, samples, channels, rate


class Decoder:
    """Decode one compressed packet at a time. codec is an FFmpeg name ('aac', 'mp3', 'opus', ...)."""

    def __init__(self, codec: str, sample_rate: int = 0, channels: int = 0, extradata: bytes = b""):
        lib = _lib()
        extra, extra_n = _u8(extradata)
        self._h = lib.ffw_dec_open(codec.encode(), int(sample_rate), int(channels), extra, extra_n)
        if not self._h:
            raise FFaudioError(_err())
        self.codec = lib.ffw_dec_codec(self._h).decode()

    def decode(self, packet: bytes) -> tuple:
        """Return (pcm_f32le, samples, channels, rate). samples may be 0."""
        data, n = _u8(packet)
        pcm = ctypes.POINTER(ctypes.c_float)()
        samples = ctypes.c_int()
        channels = ctypes.c_int()
        rate = ctypes.c_int()
        _check(_lib().ffw_dec_decode(
            self._h, data, n, ctypes.byref(pcm),
            ctypes.byref(samples), ctypes.byref(channels), ctypes.byref(rate),
        ))
        return _take_pcm(pcm, samples, channels, rate)

    def flush(self) -> tuple:
        pcm = ctypes.POINTER(ctypes.c_float)()
        samples = ctypes.c_int()
        channels = ctypes.c_int()
        rate = ctypes.c_int()
        _check(_lib().ffw_dec_flush(
            self._h, ctypes.byref(pcm),
            ctypes.byref(samples), ctypes.byref(channels), ctypes.byref(rate),
        ))
        return _take_pcm(pcm, samples, channels, rate)

    def close(self):
        if getattr(self, "_h", None):
            _lib().ffw_dec_close(self._h)
            self._h = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


class Encoder:
    """Encode interleaved float32 PCM. codec is an FFmpeg encoder name."""

    def __init__(self, codec: str, sample_rate: int, channels: int, bitrate: int = 0):
        if sample_rate <= 0 or channels <= 0:
            raise FFaudioError("sample_rate and channels are required")
        lib = _lib()
        self._h = lib.ffw_enc_open(codec.encode(), int(sample_rate), int(channels), int(bitrate))
        if not self._h:
            raise FFaudioError(_err())
        self.codec = lib.ffw_enc_codec(self._h).decode()
        self.sample_rate = lib.ffw_enc_sample_rate(self._h)
        self.channels = lib.ffw_enc_channels(self._h)
        self.frame_size = lib.ffw_enc_frame_size(self._h)

    def extradata(self) -> bytes:
        data = ctypes.POINTER(ctypes.c_uint8)()
        size = ctypes.c_int()
        _check(_lib().ffw_enc_extradata(self._h, ctypes.byref(data), ctypes.byref(size)))
        if not data or size.value <= 0:
            return b""
        raw = ctypes.string_at(data, size.value)
        _lib().ffw_free(data)
        return raw

    def _pop(self) -> list:
        lib = _lib()
        out = []
        while True:
            data = ctypes.POINTER(ctypes.c_uint8)()
            size = ctypes.c_int()
            pts = ctypes.c_int64()
            rc = lib.ffw_enc_pop(self._h, ctypes.byref(data), ctypes.byref(size), ctypes.byref(pts))
            if rc == 0:
                break
            _check(rc)
            blob = ctypes.string_at(data, size.value) if data and size.value > 0 else b""
            lib.ffw_free(data)
            out.append(blob)
        return out

    def encode(self, pcm: bytes) -> list:
        """pcm is interleaved f32le. Returns zero or more compressed packets."""
        channels = self.channels
        frame_bytes = 4 * channels
        if len(pcm) % frame_bytes != 0:
            raise FFaudioError("pcm length is not a whole number of frames")
        samples = len(pcm) // frame_bytes
        if samples == 0:
            return []
        buf = (ctypes.c_float * (samples * channels)).from_buffer_copy(pcm)
        _check(_lib().ffw_enc_encode(self._h, buf, samples))
        return self._pop()

    def flush(self) -> list:
        _check(_lib().ffw_enc_flush(self._h))
        return self._pop()

    def close(self):
        if getattr(self, "_h", None):
            _lib().ffw_enc_close(self._h)
            self._h = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


def decode_file(data: bytes) -> AudioPCM:
    """Decode a whole audio file (mp3, m4a, flac, ogg, wav, aac, ac3, ...) to float PCM."""
    if not data:
        raise FFaudioError("empty input")
    raw, n = _u8(data)
    pcm = ctypes.POINTER(ctypes.c_float)()
    samples = ctypes.c_int()
    channels = ctypes.c_int()
    rate = ctypes.c_int()
    name = ctypes.create_string_buffer(64)
    _check(_lib().ffw_decode_memory(
        raw, n, ctypes.byref(pcm),
        ctypes.byref(samples), ctypes.byref(channels), ctypes.byref(rate),
        name, 64,
    ))
    blob, ns, ch, sr = _take_pcm(pcm, samples, channels, rate)
    return AudioPCM(blob, ns, ch, sr, name.value.decode() if name.value else "")


def encode_file(pcm: bytes, sample_rate: int, channels: int, fmt: str = "flac",
                codec: str | None = None, bitrate: int = 0) -> bytes:
    """Mux interleaved float32 PCM. fmt is a muxer name: flac, wav, ogg, adts, mp4, ac3, matroska, ..."""
    frame_bytes = 4 * channels
    if channels <= 0 or sample_rate <= 0:
        raise FFaudioError("sample_rate and channels are required")
    if len(pcm) % frame_bytes != 0:
        raise FFaudioError("pcm length is not a whole number of frames")
    samples = len(pcm) // frame_bytes
    if samples <= 0:
        raise FFaudioError("no samples")
    buf = (ctypes.c_float * (samples * channels)).from_buffer_copy(pcm)
    out = ctypes.POINTER(ctypes.c_uint8)()
    out_size = ctypes.c_int()
    codec_arg = None if not codec else codec.encode()
    _check(_lib().ffw_encode_memory(
        fmt.encode(), codec_arg, buf, samples, channels, sample_rate, int(bitrate),
        ctypes.byref(out), ctypes.byref(out_size),
    ))
    blob = ctypes.string_at(out, out_size.value) if out and out_size.value > 0 else b""
    _lib().ffw_free(out)
    return blob


def _read_path(path: str) -> bytes:
    try:
        import xbmcvfs
        handle = xbmcvfs.File(path, "rb")
        try:
            data = handle.readBytes() if hasattr(handle, "readBytes") else handle.read()
        finally:
            handle.close()
        if isinstance(data, str):
            data = data.encode("latin-1")
        return bytes(data)
    except ImportError:
        with open(path, "rb") as handle:
            return handle.read()


def decode_path(path: str) -> AudioPCM:
    """Decode a Kodi VFS path or a normal filesystem path."""
    return decode_file(_read_path(path))


def encode_path(path: str, pcm: bytes, sample_rate: int, channels: int, fmt: str = "flac",
                codec: str | None = None, bitrate: int = 0) -> None:
    data = encode_file(pcm, sample_rate, channels, fmt=fmt, codec=codec, bitrate=bitrate)
    try:
        import xbmcvfs
        handle = xbmcvfs.File(path, "wb")
        try:
            handle.write(bytearray(data))
        finally:
            handle.close()
    except ImportError:
        with open(path, "wb") as handle:
            handle.write(data)
