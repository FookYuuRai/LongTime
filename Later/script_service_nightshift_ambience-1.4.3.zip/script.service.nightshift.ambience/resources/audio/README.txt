The built-in tracks are downloaded by the add-on into its data folder (builtin_audio). Nothing is needed here.
