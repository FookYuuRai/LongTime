#!/usr/bin/env python3
"""Convert music (FLAC, WAV, APE, WV, OGG, OPUS, M4A, ...) to 128 kbps MP3 on a PC.

Run this on a PC (it is NOT run by Kodi):

    python3 convert_flac_to_mp3.py "D:/Music/Ambience" [--bitrate 128k] [--delete]

It needs ffmpeg on the PATH. For every file that is not an MP3 an .mp3 with the same name is
written beside it. The Nightshift Ambience service then ignores the lossless file
whenever that .mp3 exists. --delete removes the original after a good conversion.
"""
import argparse, os, shutil, subprocess, sys

LOSSLESS = ('.flac', '.wav', '.ape', '.wv', '.ogg', '.oga', '.opus', '.m4a', '.aac', '.wma')


def convert(src, bitrate):
    dst = os.path.splitext(src)[0] + '.mp3'
    if os.path.exists(dst) and os.path.getsize(dst) > 0:
        return dst, 'skipped (mp3 exists)'
    cmd = ['ffmpeg', '-y', '-loglevel', 'error', '-i', src, '-vn', '-map_metadata', '0',
           '-codec:a', 'libmp3lame', '-b:a', bitrate, '-id3v2_version', '3', dst]
    r = subprocess.run(cmd)
    if r.returncode != 0 or not os.path.exists(dst) or os.path.getsize(dst) == 0:
        if os.path.exists(dst): os.remove(dst)
        return None, 'FAILED'
    return dst, 'converted'


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('folder')
    p.add_argument('--bitrate', default='128k')
    p.add_argument('--delete', action='store_true', help='delete the original after a good conversion')
    a = p.parse_args()
    if not shutil.which('ffmpeg'):
        sys.exit('ffmpeg was not found. Install it first (https://ffmpeg.org/download.html).')
    done = failed = 0
    for root, _, files in os.walk(a.folder):
        for n in sorted(files):
            if n.lower().endswith(LOSSLESS):
                src = os.path.join(root, n)
                dst, status = convert(src, a.bitrate)
                print('%s: %s' % (status, src))
                if dst:
                    done += 1
                    if a.delete and status == 'converted': os.remove(src)
                else: failed += 1
    print('Done. %d ok, %d failed.' % (done, failed))


if __name__ == '__main__':
    main()
