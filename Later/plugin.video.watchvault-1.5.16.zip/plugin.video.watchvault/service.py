# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
import watchvault as wv  # noqa: E402

BACKUP_NAME = 'watchvault-backup.json'


_EPISODE_ORDER = ('official', 'default', 'absolute', 'dvd', 'alternate')

def _episode_order_name(addon=None):
    try:
        ad = addon or cfg()
        # new int list setting; fall back to legacy string
        try:
            idx = int(ad.getSettingInt('episode_order'))
            return _EPISODE_ORDER[idx] if 0 <= idx < len(_EPISODE_ORDER) else 'official'
        except Exception:
            pass
        val = (ad.getSettingString('episode_order') or 'official').strip().lower()
        return val if val in _EPISODE_ORDER else 'official'
    except Exception:
        return 'official'


def log(msg):
    xbmc.log('[WatchVault] %s' % msg, xbmc.LOGINFO)


def cfg():
    return xbmcaddon.Addon()


def _source_from(path):
    m = re.match(r'^plugin://([^/]+)/', path or '')
    return m.group(1) if m else None


def _blank(v):
    return v is None or v == ''


class HistoryService(xbmc.Player):
    """History service: updates watch history from playback."""

    def __init__(self):
        super().__init__()
        self.cur = None
        self.pos = 0.0
        self.total = 0.0

    # ---- Kodi callbacks
    def onAVStarted(self):
        self.pos = self.total = 0.0
        try:
            if not _is_video_playback(self):
                self.cur = None
                return
            self.cur = self._snapshot()
        except Exception as e:  # never let a bad plugin crash the service
            log('snapshot failed: %s' % e)
            self.cur = None

    def onPlayBackEnded(self):
        self._finish(True)

    def onPlayBackStopped(self):
        self._finish(False)

    def onPlayBackError(self):
        self.cur = None

    # ---- logic
    def _snapshot(self):
        win = xbmcgui.Window(10000)
        ann = {}
        raw = win.getProperty('watchvault.announce')
        if raw:
            win.clearProperty('watchvault.announce')
            try:
                ann = json.loads(raw)
                if time.time() - float(ann.get('ts', 0)) > 180:
                    ann = {}
            except ValueError:
                ann = {}

        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            playing = ''
        source = ann.get('source') or _source_from(playing) or _source_from(
            xbmc.getInfoLabel('Player.Filenameandpath')) or xbmc.getInfoLabel('Container.PluginName') or None

        mode = cfg().getSettingInt('track_mode')  # 0 = only add-ons I added, 1 = everything
        src_row = wv.get_source(source)
        if mode == 0 and not (src_row and src_row['enabled']):
            return None
        if src_row is not None and not src_row['enabled']:
            return None
        if _ignore_source(source):
            return None
        if _is_audio_path(playing) or _is_audio_path(xbmc.getInfoLabel('Player.Filenameandpath')):
            return None
        if not _is_video_playback(self):
            return None

        info = {'title': None, 'year': None, 'season': None, 'episode': None,
                'tvdb_id': None, 'imdb_id': None, 'tmdb_id': None,
                'anilist_id': None, 'mal_id': None,
                'episode_tvdb_id': None, 'episode_imdb_id': None, 'episode_tmdb_id': None,
                'episode_anilist_id': None, 'episode_mal_id': None}
        mediatype = ''
        try:
            tag = self.getVideoInfoTag()
            mediatype = tag.getMediaType()
            if mediatype == 'episode':
                info['title'] = tag.getTVShowTitle()
                info['season'] = tag.getSeason() if tag.getSeason() >= 0 else None
                info['episode'] = tag.getEpisode() if tag.getEpisode() >= 0 else None
            else:
                info['title'] = tag.getTitle() or tag.getOriginalTitle()
            info['year'] = tag.getYear() or None
            show_keys = (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'),
                         ('anilist', 'anilist_id'), ('mal', 'mal_id'))
            ep_keys = (('tvdb', 'episode_tvdb_id'), ('imdb', 'episode_imdb_id'),
                       ('tmdb', 'episode_tmdb_id'), ('anilist', 'episode_anilist_id'),
                       ('mal', 'episode_mal_id'))
            for key, fld in show_keys:
                try:
                    v = tag.getUniqueID(key)
                    if v:
                        info[fld] = v
                except Exception:
                    pass
            if mediatype == 'episode':
                for key, fld in ep_keys:
                    try:
                        v = tag.getUniqueID('episode.' + key)
                        if v:
                            info[fld] = v
                    except Exception:
                        pass
            try:  # a movie's own tvdb id, or an explicit show-level id
                keys = ('tvshow.tvdb', 'tvdb') if mediatype == 'episode' else ('tvdb',)
                for k in keys:
                    v = tag.getUniqueID(k)
                    if v:
                        info['tvdb_id'] = v
                        break
            except Exception:
                pass
        except RuntimeError:
            pass
        if not info['title']:
            info['title'] = xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or xbmc.getInfoLabel('VideoPlayer.Title')
        if not mediatype:
            mediatype = 'episode' if xbmc.getInfoLabel('VideoPlayer.TVShowTitle') else 'movie'
            if mediatype == 'episode':
                info['season'] = xbmc.getInfoLabel('VideoPlayer.Season')
                info['episode'] = xbmc.getInfoLabel('VideoPlayer.Episode')
        for key, fld in (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'), ('tvdb', 'tvdb_id'),
                         ('anilist', 'anilist_id'), ('mal', 'mal_id')):
            if _blank(info.get(fld)):
                v = xbmc.getInfoLabel('VideoPlayer.UniqueID(%s)' % key)
                if not _blank(v):
                    info[fld] = v
        info.update({k: v for k, v in ann.items() if k in info and not _blank(v)})
        if ann and not _blank(info.get('season')) and not _blank(info.get('episode')):
            mediatype = 'episode'       # an explicit announce wins over Kodi's guess
        elif mediatype in ('', 'video'):
            mediatype = 'movie'
        if mediatype == 'episode' and (_blank(info.get('season')) or _blank(info.get('episode'))):
            return None
        if mediatype == 'movie':
            info['season'] = info['episode'] = None
            for key in ('episode_tvdb_id', 'episode_imdb_id', 'episode_tmdb_id',
                        'episode_anilist_id', 'episode_mal_id'):
                info[key] = None
        named = (info['title'], info['tvdb_id'], info['imdb_id'], info['tmdb_id'],
                 info['anilist_id'], info['mal_id'])
        if mediatype not in ('episode', 'movie') or not any(not _blank(v) for v in named):
            return None
        info['episode_title'] = ann.get('episode_title') or (
            xbmc.getInfoLabel('VideoPlayer.Title') if mediatype == 'episode' else None)
        info['aired'] = ann.get('aired')
        return {'info': info, 'source': source}

    def tick(self):
        if self.cur and not _is_video_playback(self):
            # Theme/ambience took over — abandon incomplete video session
            self.cur = None
            return
        if self.cur and _is_video_playback(self):
            try:
                self.pos = self.getTime()
                self.total = self.getTotalTime()
            except RuntimeError:
                pass

    def _timing(self, ended):
        total = self.total if self.total and self.total > 0 else 0.0
        pos = self.pos if self.pos and self.pos > 0 else 0.0
        if total and pos > total:
            pos = total
        if not total:
            return None, None
        runtime = int(round(total))
        if ended:
            remaining = 0
        else:
            remaining = max(0, int(round(total - pos)))
        return runtime, remaining

    def _finish(self, ended):
        cur, self.cur = self.cur, None
        if not cur:
            return
        pct = 100.0 if ended else (self.pos / self.total * 100.0 if self.total > 0 else 0.0)
        runtime, remaining = self._timing(ended)
        extra = {}
        if runtime is not None:
            extra['runtime'] = runtime
        if remaining is not None:
            extra['remaining'] = remaining
        if pct < cfg().getSettingInt('threshold'):
            if extra:
                wv.save_progress(source=cur['source'], **cur['info'], **extra)
                log('progress %s from %s runtime=%s remaining=%s' % (
                    cur['info'].get('title'), cur['source'], runtime, remaining))
            return
        res = wv.mark_watched(source=cur['source'], **cur['info'], **extra)
        log('marked %s from %s: %s' % (cur['info'].get('title'), cur['source'], res))
        if res.get('ok') and cfg().getSettingBool('notify'):
            i = cur['info']
            label = i['title'] if _blank(i.get('season')) else '%s S%02dE%02d' % (
                i['title'], int(i['season']), int(i['episode']))
            xbmcgui.Dialog().notification(
                cfg().getAddonInfo('name') or 'WatchVault',
                cfg().getLocalizedString(30120) % label,
                xbmcgui.NOTIFICATION_INFO, 2500, False)
        self._maybe_catalog(i=cur['info'])

    def _maybe_catalog(self, i):
        c = cfg()
        key = c.getSettingString('tvdb_key').strip()
        if i.get('season') is None or not key or not c.getSettingBool('fetch_catalog'):
            return
        try:
            import tvdb_catalog
            with wv.db() as con:
                sid = wv._show_id(con, i['title'], i.get('year'), i.get('tvdb_id'), i.get('imdb_id'),
                                  i.get('tmdb_id'), create=False)
                have = con.execute('SELECT COUNT(*) FROM episodes WHERE show_id=? AND watched=0',
                                   (sid,)).fetchone()[0] if sid else 1
            if sid and not have:
                c2 = cfg()
                tvdb_catalog.fill_show(key, sid, season_type=_episode_order_name(c2),
                                       original_names=c2.getSettingBool('original_names'))
        except Exception as e:
            log('catalog fetch failed: %s' % e)


# ------------------------------------------------------------------ backups
def _backup_dir():
    folder = cfg().getSettingString('backup_path')
    return folder or None


def _write_backup():
    folder = _backup_dir()
    if not folder or not cfg().getSettingBool('auto_backup'):
        return
    tmp = os.path.join(xbmcvfs.translatePath('special://temp/'), BACKUP_NAME)
    wv.export_json(tmp)
    dest = xbmcvfs.makeLegalFilename(folder.rstrip('/\\') + '/' + BACKUP_NAME) if not folder.startswith(
        ('smb://', 'nfs://', 'special://')) else folder.rstrip('/') + '/' + BACKUP_NAME
    if xbmcvfs.exists(dest):
        xbmcvfs.delete(dest)
    xbmcvfs.copy(tmp, dest)


def _restore_if_empty():
    folder = _backup_dir()
    c = wv.counts()
    if not folder or c['shows'] or c['movies']:
        return
    src = folder.rstrip('/\\') + '/' + BACKUP_NAME
    if not xbmcvfs.exists(src):
        return
    tmp = os.path.join(xbmcvfs.translatePath('special://temp/'), 'watchvault-restore.json')
    if xbmcvfs.copy(src, tmp):
        try:
            res = wv.import_json(tmp)
            log('restored from automatic backup: %s' % res)
            xbmcgui.Dialog().notification(
                cfg().getAddonInfo('name') or 'WatchVault',
                cfg().getLocalizedString(30121),
                xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception as e:
            log('restore failed: %s' % e)


def _refresh_anime():
    """Refresh Offline DB / Kometa when due, then local-fill empty AniList/MAL ids.

    Local fill is network-free and runs after any successful refresh that
    actually changed a dataset (or always when force-style entries are present).
    """
    try:
        import anime_data
        result = anime_data.update()
        log('anime datasets %s' % result)
    except Exception as e:
        log('anime datasets failed: %s' % e)
        result = None
    # Dataset-triggered local fill: offline/Kometa only, never overwrites.
    try:
        changed = False
        if isinstance(result, dict):
            for name in ('offline', 'kometa'):
                slot = result.get(name) or {}
                if slot.get('ok') and not slot.get('skipped') and (
                        slot.get('entries') or not slot.get('unchanged')):
                    # entries present means a new index was written; also run
                    # when unchanged is absent after an ok refresh so a first
                    # install still fills.
                    if slot.get('entries') is not None or not slot.get('unchanged'):
                        changed = True
        # Always attempt local fill after a refresh attempt that did not hard-fail
        # entirely — cheap, local, and fills rows that gained cache coverage.
        if result is not None:
            fill = wv.fill_local_ids(missing_anime=True)
            log('anime local fill %s' % fill)
            # New offline/Kometa data may unlock previous misses
            changed_ds = False
            if isinstance(result, dict):
                for name in ('offline', 'kometa'):
                    slot = result.get(name) or {}
                    if slot.get('ok') and slot.get('entries') is not None and not slot.get('unchanged'):
                        changed_ds = True
            if changed_ds:
                try:
                    wv.clear_negative_cache()
                    log('anime negative cache cleared after dataset change')
                except Exception as e:
                    log('negative cache clear failed: %s' % e)
    except Exception as e:
        log('anime local fill failed: %s' % e)




def _batch_fill_network():
    """Periodic TVDB network fill for missing TVDB ids (remote-id then name)."""
    c = cfg()
    if not c.getSettingBool('sync_fill_enabled'):
        return
    key = c.getSettingString('tvdb_key').strip()
    if not key:
        log('sync fill skipped: no TVDB key')
        return
    try:
        limit = c.getSettingInt('sync_fill_batch') or 50
    except Exception:
        limit = 50
    try:
        # Local first (no network), then TVDB batch
        local = wv.fill_local_ids(missing_anime=True)
        log('sync local fill %s' % local)
        net = wv.batch_fill_network(api_key=key, limit=limit)
        log('sync network fill %s' % net)
    except Exception as e:
        log('sync fill failed: %s' % e)


def _provider_sync(force=False):
    try:
        import provider_sync
        if not force and not provider_sync.provider_sync_enabled():
            return
        res = provider_sync.run_provider_sync(force=force)
        log('provider sync %s' % res)
    except Exception as e:
        log('provider sync failed: %s' % e)



def main():
    monitor = xbmc.Monitor()
    player = HistoryService()
    log('history service started')
    try:
        _restore_if_empty()
    except Exception as e:
        log('restore error: %s' % e)
    threading.Thread(target=_refresh_anime, daemon=True).start()
    last_seq = wv.last_seq()
    last_backup = time.time()
    last_anime = time.time()
    last_sync = time.time() - 5 * 60  # first run ~5 min after start (adjusted by interval check)
    last_provider_sync = 0
    last_provider_seq = wv.last_seq()
    # Kick first network fill shortly after start without blocking
    def _deferred_sync():
        monitor.waitForAbort(5 * 60)
        if not monitor.abortRequested():
            _batch_fill_network()
    threading.Thread(target=_deferred_sync, daemon=True).start()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        player.tick()
        if time.time() - last_backup > 30:
            try:
                seq = wv.last_seq()
                if seq != last_seq:
                    _write_backup()
                    last_seq = seq
            except Exception as e:
                log('backup error: %s' % e)
            last_backup = time.time()
        if time.time() - last_anime > 24 * 60 * 60:
            threading.Thread(target=_refresh_anime, daemon=True).start()
            last_anime = time.time()
        try:
            interval_h = cfg().getSettingInt('sync_fill_hours') or 6
        except Exception:
            interval_h = 6
        if cfg().getSettingBool('sync_fill_enabled') and time.time() - last_sync > interval_h * 3600:
            threading.Thread(target=_batch_fill_network, daemon=True).start()
            last_sync = time.time()
        try:
            import provider_sync as _ps
            if _ps.provider_sync_enabled():
                interval_s = _ps.sync_interval_seconds()
                if time.time() - last_provider_sync > interval_s:
                    threading.Thread(target=_provider_sync, daemon=True).start()
                    last_provider_sync = time.time()
                # Optional: push soon after local marks change
                if cfg().getSettingBool('provider_sync_on_mark'):
                    seq = wv.last_seq()
                    if seq != last_provider_seq:
                        last_provider_seq = seq
                        threading.Thread(target=lambda: (time.sleep(2), _provider_sync()), daemon=True).start()
        except Exception as e:
            log('provider sync schedule error: %s' % e)
    try:
        _write_backup()
    except Exception as e:
        log('final backup error: %s' % e)


if __name__ == '__main__':
    main()
