# -*- coding: utf-8 -*-
"""Live title suggestions for the Nightshift search keyboard.

Uses the TMDb API (api.themoviedb.org) with the Nightshift TMDb API key when one is set. Without a key it
falls back to TMDb's website search, which TMDb may refuse (403). Successful results are cached in memory
for the session; failures are not cached.
"""
import threading

import xbmc

SEARCH_URL = 'https://www.themoviedb.org/search/multi'
HEADERS = {
    'User-Agent': 'Mozilla/5.0',
    'Accept': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://www.themoviedb.org/',
}
TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 9

_cache = {}
_cache_order = []
_cache_lock = threading.Lock()
_session = None


def _get_session():
    global _session
    if _session is None:
        from modules.kodi_utils import make_session
        _session = make_session('https://www.themoviedb.org')
    return _session


API_URL = 'https://api.themoviedb.org/3/search/multi'
_warned_no_key = [False]


def _search(query):
    """Raw TMDb multi-search JSON for `query`. Raises on any failure."""
    from modules.settings import tmdb_api_key
    key = tmdb_api_key()
    if key:
        response = _get_session().get(API_URL, params={'api_key': key, 'query': query, 'language': 'en-US'},
                                      timeout=TIMEOUT)
    else:
        if not _warned_no_key[0]:
            _warned_no_key[0] = True
            xbmc.log('[NIGHTSHIFT keyboard] no TMDb API key set: suggestions use the TMDb website, which may refuse them', xbmc.LOGWARNING)
        response = _get_session().get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                                      headers=HEADERS, timeout=TIMEOUT)
    response.raise_for_status()
    return response.json()


def titles_from_search(data, limit=DEFAULT_LIMIT):
    """Pull unique movie, TV and person names from a TMDb multi-search response."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    titles, seen = [], set()
    for item in results:
        if not isinstance(item, dict):
            continue
        kind = item.get('media_type')
        if kind == 'movie':
            title = item.get('title') or item.get('original_title')
        elif kind in ('tv', 'person'):
            title = item.get('name') or item.get('original_name')
        else:
            continue
        if not isinstance(title, str):
            continue
        title = title.strip()
        key = title.casefold()
        if not title or key in seen:
            continue
        seen.add(key)
        titles.append(title)
        if len(titles) >= limit:
            break
    return titles


def _remember(key, titles):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = titles
        while len(_cache_order) > CACHE_LIMIT:
            _cache.pop(_cache_order.pop(0), None)


def fetch_suggestions(text, limit=DEFAULT_LIMIT):
    """Return up to `limit` title suggestions for `text`. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    key = query.casefold()
    with _cache_lock:
        if key in _cache:
            return list(_cache[key])[:limit]
    try:
        titles = titles_from_search(_search(query), DEFAULT_LIMIT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] suggestions failed for {query!r}: {exc}", xbmc.LOGWARNING)
        return []
    _remember(key, titles)
    return titles[:limit]
