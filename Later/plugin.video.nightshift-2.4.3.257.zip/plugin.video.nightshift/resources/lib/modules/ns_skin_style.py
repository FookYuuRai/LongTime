# -*- coding: utf-8 -*-
"""Reads the active Nightshift skin's style settings so the search keyboard matches the skin.

The value tables mirror the skin's Variables.xml (NSPanelTint, NSOutlineColorVar, NSFocusTextRGBVar,
NSTextAlphaVar). Settings are read with infolabels, so changes made in the skin apply on the next open.
"""
import xbmc

_PANEL_ALPHA = {10: '1A', 20: '33', 30: '4D', 40: '66', 50: '80', 60: '99', 70: 'B3', 80: 'CC', 90: 'E6'}
_TEXT_RGB = {'1': '55CBFF', '2': '9AE4FF', '3': '00E5FF', '4': 'FFD54F', '5': 'FF9800',
             '6': 'E53935', '7': '39FF6A', '8': 'FF4081', '9': 'B388FF', '10': 'CCCCCC'}
_TEXT_ALPHA = {'1': 'E6', '2': 'CC', '3': 'B2', '4': '99', '5': '80', '6': '66', '7': '4C', '8': '33', '9': '1A', '10': '00'}
_OUTLINE_RGB = {'1': 'FF303030', '2': 'FFFFFFFF', '3': 'FF0D47A1', '4': 'FF1E88E5', '5': 'FF102040',
                '6': 'FF5D0000', '7': 'FF0B3D12', '8': 'FF3A0F5C', '9': 'FF7A5A00'}
DEFAULT_PANEL = 'B3FFFFFF'
DEFAULT_TEXT = 'FFFFFFFF'
DEFAULT_OUTLINE = 'FF000000'


def _setting(name):
    return xbmc.getInfoLabel('Skin.String(%s)' % name).strip()


def _has(name):
    return xbmc.getCondVisibility('Skin.HasSetting(%s)' % name)


def style_properties():
    """{window property name: ARGB hex} for the keyboard controls."""
    try:
        alpha = int(_setting('ns_panel_alpha'))
    except ValueError:
        alpha = None
    panel = ('%s' % _PANEL_ALPHA.get(alpha, 'B3')) + 'FFFFFF' if alpha is not None else DEFAULT_PANEL

    text_rgb = _TEXT_RGB.get(_setting('ns_text_color'), 'FFFFFF')
    text_alpha = _TEXT_ALPHA.get(_setting('ns_text_brightness'), 'FF')
    text = (text_alpha if text_alpha != '' else 'FF') + text_rgb
    focus_text = 'FF' + text_rgb

    outline = _OUTLINE_RGB.get(_setting('ns_outline_color'), DEFAULT_OUTLINE)
    if _has('ns_focus_rings'):
        outline = '00000000'

    return {
        'ns_bg': panel,
        'ns_panel': panel,
        'ns_neon': focus_text,
        'ns_focus_text': focus_text,
        'ns_text': text,
        'ns_outline': outline,
    }
