# -*- coding: utf-8 -*-
"""Encrypt Kodi logs locally and upload them using an encrypted GitHub token file."""

import base64
import hashlib
import os
import re
import time
from datetime import datetime, timezone
from urllib.parse import quote

from modules import kodi_utils as k

# Public repository containing the encrypted PAT file.
_TOKEN_REPOSITORY = 'FookYuuRai/logs'
_TOKEN_FILENAME = 'github_token.nstoken'

# Destination for encrypted Kodi logs.
_UPLOAD_REPOSITORY = 'FookYuuRai/LongTime'
_UPLOAD_BRANCH = 'OnTheSide'

_TOKEN_MAGIC = b'NSTOK01\n'
_SALT_BYTES = 16
_NONCE_BYTES = 12
_TAG_BYTES = 16
_SCRYPT_N = 2 ** 14
_SCRYPT_R = 8
_SCRYPT_P = 1

# Encrypted Kodi log format.
_LOG_MAGIC = b'NSLOG01\n'
_LOG_SALT_BYTES = 16
_LOG_NONCE_BYTES = 12
_LOG_TAG_BYTES = 16
_LOG_SCRYPT_N = 2 ** 14
_LOG_SCRYPT_R = 8
_LOG_SCRYPT_P = 1

_GITHUB_API = 'https://api.github.com'

# Remove complete log lines containing URLs or any of these provider hosts.
_FILTERED_HOSTS = (
    'aiostreams.elfhosted.com',
    'aiostreams.fortheweak.cloud',
    'aiostreams-nightly.fortheweak.cloud',
    'aiostreamsfortheweebsstable.midnightignite.me',
    'aiostreamsfortheweebs.midnightignite.me',
    'aiostreams.viren070.me',
    'aiostreams.stremio.ru',
    'aiostreams-nightly.stremio.ru',
    'aio.atbphosting.com',
    'aiostreams.12312023.xyz',
)
_SENSITIVE_LOG_LINE = re.compile(
    rb'https?://' + b'|' + b'|'.join(
        re.escape(host.encode('ascii')) for host in _FILTERED_HOSTS
    ),
    re.IGNORECASE,
)


def strip_sensitive_log_lines(log_data):
    """Remove whole log lines containing an HTTP(S) URL or listed host."""
    kept_lines = []
    removed_lines = 0
    for line in log_data.splitlines(keepends=True):
        if _SENSITIVE_LOG_LINE.search(line):
            removed_lines += 1
        else:
            kept_lines.append(line)
    return b''.join(kept_lines), removed_lines


def _derive_key(passphrase, salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P):
    return hashlib.scrypt(
        passphrase.encode('utf-8'),
        salt=salt,
        n=n,
        r=r,
        p=p,
        maxmem=64 * 1024 * 1024,
        dklen=32,
    )


def encrypt_log_bytes(plaintext, passphrase):
    """Return NSLOG01 container bytes using AES-256-GCM."""
    from Cryptodome.Cipher import AES

    salt = os.urandom(_LOG_SALT_BYTES)
    nonce = os.urandom(_LOG_NONCE_BYTES)
    aad = _LOG_MAGIC + salt + nonce
    key = _derive_key(
        passphrase,
        salt,
        _LOG_SCRYPT_N,
        _LOG_SCRYPT_R,
        _LOG_SCRYPT_P,
    )
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len=_LOG_TAG_BYTES)
    cipher.update(aad)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    return aad + ciphertext + tag


def _decrypt_token_file(encrypted_data, passphrase):
    """Decrypt NSTOK01 and return the GitHub PAT as UTF-8 text."""
    from Cryptodome.Cipher import AES

    header_size = len(_TOKEN_MAGIC) + _SALT_BYTES + _NONCE_BYTES
    minimum_size = header_size + _TAG_BYTES

    if not encrypted_data or len(encrypted_data) < minimum_size:
        raise ValueError('The token file is empty or truncated.')

    if not encrypted_data.startswith(_TOKEN_MAGIC):
        raise ValueError('The token file does not have the NSTOK01 header.')

    salt_start = len(_TOKEN_MAGIC)
    nonce_start = salt_start + _SALT_BYTES
    payload_start = nonce_start + _NONCE_BYTES

    salt = encrypted_data[salt_start:nonce_start]
    nonce = encrypted_data[nonce_start:payload_start]
    ciphertext = encrypted_data[payload_start:-_TAG_BYTES]
    tag = encrypted_data[-_TAG_BYTES:]
    aad = encrypted_data[:payload_start]

    key = _derive_key(passphrase, salt)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len=_TAG_BYTES)
    cipher.update(aad)

    plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    token = plaintext.decode('utf-8').strip()

    if not token:
        raise ValueError('The decrypted token file contains no token.')

    return token


def _prompt_secret(heading):
    option = getattr(k.xbmcgui, 'ALPHANUM_HIDE_INPUT', 1)
    return (k.kodi_dialog().input(heading, option=option) or '').strip()


def _github_headers(token=None):
    headers = {
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Nightshift-Encrypted-Kodi-Log-Uploader',
    }
    if token:
        headers['Authorization'] = 'Bearer %s' % token
    return headers


def _download_token_file():
    """Download the public encrypted token file from the repository root."""
    import requests

    owner, repo = _TOKEN_REPOSITORY.split('/', 1)
    repo_url = '%s/repos/%s/%s' % (
        _GITHUB_API,
        quote(owner, safe=''),
        quote(repo, safe=''),
    )

    response = requests.get(
        repo_url,
        headers=_github_headers(),
        timeout=(15, 30),
    )
    if response.status_code != 200:
        raise RuntimeError(
            'Could not read token repository details (HTTP %s).' %
            response.status_code
        )

    branch = response.json().get('default_branch')
    if not isinstance(branch, str) or not branch.strip():
        raise RuntimeError('GitHub did not report the token repository default branch.')

    raw_url = 'https://raw.githubusercontent.com/%s/%s/%s/%s' % (
        quote(owner, safe=''),
        quote(repo, safe=''),
        quote(branch.strip(), safe='/'),
        quote(_TOKEN_FILENAME, safe=''),
    )

    token_response = requests.get(
        raw_url,
        headers={'User-Agent': 'Nightshift-Encrypted-Kodi-Log-Uploader'},
        timeout=(15, 30),
    )
    if token_response.status_code != 200:
        raise RuntimeError(
            'Could not download %s from %s (HTTP %s).' %
            (_TOKEN_FILENAME, _TOKEN_REPOSITORY, token_response.status_code)
        )

    return token_response.content


def _github_upload(repository, branch, token, filename, encrypted_data):
    import requests

    owner, repo = repository.split('/', 1)
    endpoint = '%s/repos/%s/%s/contents/logs/%s' % (
        _GITHUB_API,
        quote(owner, safe=''),
        quote(repo, safe=''),
        quote(filename, safe=''),
    )
    payload = {
        'message': 'Add encrypted Kodi log %s' % filename,
        'content': base64.b64encode(encrypted_data).decode('ascii'),
        'branch': branch,
    }
    return requests.put(
        endpoint,
        headers=_github_headers(token),
        json=payload,
        timeout=(15, 60),
    )


def upload_logfile(params=None):
    import json as json_module
    from modules.utils import copy2clip

    log_files = [
        ('Current Kodi Log', 'kodi.log'),
        ('Previous Kodi Log', 'kodi.old.log'),
    ]
    list_items = [{'line1': item[0]} for item in log_files]
    kwargs = {
        'items': json_module.dumps(list_items),
        'heading': 'Choose Which Log File to Encrypt and Upload',
        'narrow_window': 'true',
    }
    selected = k.select_dialog(log_files, **kwargs)
    if selected is None:
        return

    log_name, log_filename = selected
    if not k.confirm_dialog(
        heading=log_name,
        text='Encrypt this Kodi log and upload it to GitHub?'
    ):
        return

    token = ''
    token_passphrase = ''
    log_passphrase = ''
    log_passphrase_confirm = ''
    response = None

    # Prompt first, before showing Kodi's busy dialog.
    token_passphrase = _prompt_secret(
        'Passphrase for github_token.nstoken'
    )
    if not token_passphrase:
        return

    busy_shown = False
    try:
        k.show_busy_dialog()
        busy_shown = True

        # The PAT is downloaded encrypted and decrypted only in memory.
        encrypted_token_file = _download_token_file()
        token = _decrypt_token_file(
            encrypted_token_file,
            token_passphrase,
        )
    except ImportError:
        return k.ok_dialog(
            heading='Encryption Dependency Missing',
            text='AES-256-GCM support is unavailable. Enable the Kodi dependency script.module.pycryptodome, then try again.'
        )
    except Exception as exc:
        try:
            k.logger(
                'Encrypted Log Uploader',
                'token file: %s: %s' % (type(exc).__name__, str(exc)[:250])
            )
        except Exception:
            pass
        return k.ok_dialog(
            heading='GitHub Token File',
            text='The encrypted token file could not be downloaded or decrypted. Check the token repository and passphrase, then try again.'
        )
    finally:
        if busy_shown:
            k.hide_busy_dialog()
        token_passphrase = ''

    # Ask for the log encryption passphrase with no busy overlay.
    log_passphrase = _prompt_secret(
        'Encryption passphrase for this Kodi log (at least 12 characters)'
    )
    if len(log_passphrase) < 12:
        token = ''
        return k.ok_dialog(
            heading='Encryption Passphrase',
            text='Use an encryption passphrase with at least 12 characters.'
        )

    log_passphrase_confirm = _prompt_secret(
        'Confirm Kodi log encryption passphrase'
    )
    if log_passphrase != log_passphrase_confirm:
        token = ''
        log_passphrase = ''
        log_passphrase_confirm = ''
        return k.ok_dialog(
            heading='Encryption Passphrase',
            text='The passphrases did not match. Nothing was uploaded.'
        )

    log_path = k.translate_path(
        'special://logpath/%s' % log_filename
    )
    if not k.path_exists(log_path):
        token = ''
        log_passphrase = ''
        log_passphrase_confirm = ''
        return k.ok_dialog(
            heading='GitHub Log Upload',
            text='The selected Kodi log file does not exist.'
        )

    busy_shown = False
    try:
        k.show_busy_dialog()
        busy_shown = True

        with k.open_file(log_path, 'rb') as handle:
            plaintext = handle.read()

        # Strip complete matching lines before any log encryption/upload.
        plaintext, removed_lines = strip_sensitive_log_lines(plaintext)

        encrypted_data = encrypt_log_bytes(
            plaintext,
            log_passphrase,
        )

        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
        suffix = 'current' if log_filename == 'kodi.log' else 'previous'
        unique = '%06d' % (
            int(time.time() * 1000000) % 1000000
        )
        filename = 'kodi-%s-%s-%s.enc' % (
            timestamp,
            suffix,
            unique,
        )

        response = _github_upload(
            _UPLOAD_REPOSITORY,
            _UPLOAD_BRANCH,
            token,
            filename,
            encrypted_data,
        )

    except ImportError:
        return k.ok_dialog(
            heading='Encryption Dependency Missing',
            text='AES-256-GCM support is unavailable. Enable the Kodi dependency script.module.pycryptodome, then try again.'
        )
    except Exception as exc:
        try:
            k.logger(
                'Encrypted Log Uploader',
                '%s: %s' % (type(exc).__name__, str(exc)[:300])
            )
        except Exception:
            pass
        return k.ok_dialog(
            heading='GitHub Log Upload',
            text='The encrypted log could not be uploaded. Check the Kodi log for details and try again.'
        )
    finally:
        # Best-effort removal of in-memory credential references after request.
        token = ''
        token_passphrase = ''
        log_passphrase = ''
        log_passphrase_confirm = ''
        if busy_shown:
            k.hide_busy_dialog()

    if response is None:
        return

    if response.status_code not in (200, 201):
        try:
            detail = response.json().get('message', '')
        except Exception:
            detail = ''

        if response.status_code == 401:
            message = 'GitHub rejected the decrypted token. Check the token and its expiry.'
        elif response.status_code == 403:
            message = 'GitHub denied the upload. Check that the token has Contents: Read and write access to FookYuuRai/LongTime.'
        elif response.status_code == 404:
            message = 'GitHub could not find the target repository or branch, or the token cannot access it.'
        elif response.status_code == 409:
            message = 'GitHub reported a conflict. Try uploading again.'
        else:
            message = 'GitHub upload failed (HTTP %s).' % response.status_code

        if detail:
            message += '[CR]' + str(detail)[:250]

        return k.ok_dialog(
            heading='GitHub Log Upload Failed',
            text=message,
        )

    file_url = 'https://github.com/%s/tree/%s/logs/%s' % (
        _UPLOAD_REPOSITORY,
        quote(_UPLOAD_BRANCH, safe=''),
        quote(filename, safe=''),
    )
    try:
        copy2clip(file_url)
    except Exception:
        pass

    return k.ok_dialog(
        heading='Encrypted Kodi Log Uploaded',
        text=(
            'Only the encrypted file was uploaded. The GitHub token was '
            'downloaded and decrypted in memory; it was not saved locally.'
            '[CR][CR]Repository: [B]%s[/B][CR]Branch: [B]%s[/B]'
            '[CR]File: [B]logs/%s[/B][CR][CR]'
            'The file URL was copied to the clipboard.[CR]'
            'Removed %s log lines containing URLs or filtered provider hosts '
            'before encryption.[CR][CR]'
            'Keep your log encryption passphrase safe: it cannot be '
            'recovered if lost.'
        ) % (
            _UPLOAD_REPOSITORY,
            _UPLOAD_BRANCH,
            filename,
            removed_lines,
        ),
        scroll=True,
    )
