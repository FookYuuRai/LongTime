# -*- coding: utf-8 -*-
"""Nightshift search keyboard with live title suggestions.

The keyboard only collects the search text. Suggestions are filtered to the kind of search that
was started (movie, TV show, people, or all), and the chosen text goes back to the existing
Nightshift search (search.get_key_id), which opens the same Videos-window results as before.
Control IDs start at 9100 so they never clash with skin controls (2000 and up).
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from modules.ns_autocomplete import fetch_items, DEFAULT_LIMIT

ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
DEBOUNCE_SECONDS = 0.15
HOME_WINDOW = 10000
OPEN_PROPERTY = 'nightshift.search.open'   # read by root_focus: no stills while search is open

TITLE_ID = 9170
TEXT_ID = 9160
LIST_ID = 9150        # suggestion strip
KEY_BASE = 9100
KEY_COUNT = 40
SPACE_ID, BACK_ID, CLEAR_ID, SHIFT_ID, SYMBOLS_ID, SEARCH_ID, CAPS_ID = 9140, 9141, 9142, 9143, 9144, 9145, 9146

LETTER_PAGE = list('1234567890qwertyuiopasdfghjkl-zxcvbnm\'&:')   # QWERTY order: digits, then the keyboard rows
SYMBOL_PAGE = list('1234567890!@#$%^&*()-_=+[]{}|;:\'",.<>?/`')

ACTION_PREVIOUS_MENU = getattr(xbmcgui, 'ACTION_PREVIOUS_MENU', 10)
ACTION_NAV_BACK = getattr(xbmcgui, 'ACTION_NAV_BACK', 92)


class NightshiftKeyboard(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.result = ''
        self.heading = ''
        self.kinds = None          # 'Movie', 'TV show', 'Person', or None for all
        self._text = ''
        self._seq = 0
        self._items = []
        self._closed = False
        self._symbols = False
        self._shift = False
        self._caps = False
        self._lock = threading.Lock()
        super().__init__(*args, **kwargs)

    # ---- window lifecycle -------------------------------------------------
    def onInit(self):
        self._closed = False
        self._set_open(True)
        self._apply_skin_style()
        self.getControl(TITLE_ID).setLabel(self.heading or 'Search')
        self._refresh_keys()
        self._refresh_text()
        self._publish(self._next_seq(), [])
        self.setFocusId(KEY_BASE)

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self._cancel()

    def onClick(self, control_id):
        if KEY_BASE <= control_id < KEY_BASE + KEY_COUNT:
            self._press_key(control_id - KEY_BASE)
        elif control_id == SPACE_ID:
            self._set_text(self._text + ' ')
        elif control_id == BACK_ID:
            self._set_text(self._text[:-1])
        elif control_id == CLEAR_ID:
            self._set_text('')
        elif control_id == SHIFT_ID:
            self._shift = not self._shift
            self._refresh_keys()
        elif control_id == CAPS_ID:
            self._caps = not self._caps
            self._refresh_keys()
        elif control_id == SYMBOLS_ID:
            self._symbols = not self._symbols
            self._shift = False
            self._refresh_keys()
        elif control_id == SEARCH_ID:
            self._submit()
        elif control_id == LIST_ID:
            self._choose_suggestion()

    # ---- keys -------------------------------------------------------------
    def _page(self):
        return SYMBOL_PAGE if self._symbols else LETTER_PAGE

    def _uppercase(self):
        # Caps Lock keeps letters uppercase; Shift flips it for one letter.
        return (not self._symbols) and (self._caps != self._shift)

    def _press_key(self, index):
        char = self._page()[index]
        if char.isalpha() and self._uppercase():
            char = char.upper()
        if self._shift and not self._symbols:
            self._shift = False          # Shift applies to one letter
            self._refresh_keys()
        self._set_text(self._text + char)

    def _refresh_keys(self):
        upper = self._uppercase()
        for index, char in enumerate(self._page()):
            if char.isalpha() and upper:
                char = char.upper()
            self.getControl(KEY_BASE + index).setLabel(char)
        self.getControl(SHIFT_ID).setLabel('SHIFT' if self._shift else 'Shift')
        self.getControl(CAPS_ID).setLabel('CAPS' if self._caps else 'Caps')
        self.getControl(SYMBOLS_ID).setLabel('Letters' if self._symbols else 'Symbols')

    # ---- text and suggestions ---------------------------------------------
    def _set_text(self, text):
        self._text = text
        self._refresh_text()
        self._request_suggestions(text)

    def _refresh_text(self):
        self.getControl(TEXT_ID).setLabel(self._text + '_')

    def _next_seq(self):
        with self._lock:
            self._seq += 1
            return self._seq

    def _request_suggestions(self, text):
        seq = self._next_seq()
        if not text.strip():
            self._publish(seq, [])
            return
        threading.Thread(target=self._lookup, args=(seq, text), daemon=True).start()

    def _lookup(self, seq, text):
        time.sleep(DEBOUNCE_SECONDS)       # debounce: skip lookups overtaken by typing
        if not self._is_current(seq):
            return
        items = fetch_items(text, DEFAULT_LIMIT)  # network, never on the key path
        self._publish(seq, items)

    def _is_current(self, seq):
        with self._lock:
            return seq == self._seq and not self._closed

    def _publish(self, seq, items):
        """Show items only if no newer query has started, and only the kind of search that was started."""
        if self.kinds:
            items = [item for item in items if item.get('media') == self.kinds]
        with self._lock:
            if seq != self._seq or self._closed:
                return
            self._items = items
            control = self.getControl(LIST_ID)
            control.reset()
            for item in items:
                row = xbmcgui.ListItem(item['title'])
                row.setLabel2(item.get('media', ''))
                row.setProperty('year', item.get('year', ''))
                row.setProperty('backdrop', item.get('backdrop', ''))
                control.addItem(row)

    def _choose_suggestion(self):
        position = self.getControl(LIST_ID).getSelectedPosition()
        if 0 <= position < len(self._items):
            self.result = self._items[position]['title']
            self._finish()

    # ---- finishing ---------------------------------------------------------
    def _submit(self):
        self.result = self._text.strip()
        self._finish()

    def _cancel(self):
        self.result = ''
        self._finish()

    def _finish(self):
        with self._lock:
            self._closed = True
            self._seq += 1
        self._set_open(False)
        self.close()

    def _set_open(self, flag):
        xbmcgui.Window(HOME_WINDOW).setProperty(OPEN_PROPERTY, '1' if flag else '')

    # ---- skin style (same settings as the rest of the skin) --------------
    def _set_color(self, control_id, method, color):
        try:
            control = self.getControl(control_id)
            if hasattr(control, method):
                getattr(control, method)(color)
        except Exception:
            pass

    def _apply_skin_style(self):
        """Copy the active skin's transparency, text and neon/outline settings onto this window."""
        try:
            from modules.ns_skin_style import style_properties
            props = style_properties()
            for name, value in props.items():
                self.setProperty(name, value)
            for cid in list(range(KEY_BASE, KEY_BASE + KEY_COUNT)) + [SPACE_ID, BACK_ID, CLEAR_ID, SHIFT_ID, SYMBOLS_ID, SEARCH_ID, CAPS_ID, TEXT_ID]:
                self._set_color(cid, 'setTextColor', props['ns_ring_text'])
            self._set_color(TITLE_ID, 'setTextColor', props['ns_ring_text'])
        except Exception as exc:
            xbmc.log(f"[NIGHTSHIFT keyboard] skin style not applied: {exc}", xbmc.LOGWARNING)


def ns_keyboard_input(heading='', kinds=None):
    """Return the text chosen on the search keyboard, or '' if cancelled.
    kinds: 'Movie', 'TV show', 'Person' to filter suggestions, or None for all."""
    try:
        dialog = NightshiftKeyboard('ns_keyboard.xml', ADDON_PATH, 'Default', '1080i')
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] could not open, using Kodi keyboard: {exc}", xbmc.LOGWARNING)
        return xbmcgui.Dialog().input(heading)
    try:
        dialog.heading = heading
        dialog.kinds = kinds
        dialog.doModal()
        return dialog.result
    finally:
        del dialog
