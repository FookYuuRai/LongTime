# -*- coding: utf-8 -*-
"""Reads the active Nightshift skin's style settings so the search keyboard matches the skin.

Values come from the skin's own tables (Variables.xml: NSPanelTint, NSFocusTextRGBVar, NSOutlineColorVar)
and its unset defaults (NSPanelTint = FFFFFFFF, NSFocusTextRGBVar = FFFFFF, NSOutlineColorVar = FF000000).
The skin does not write these settings itself, so an unset setting uses the table default.
"""
import xbmc

# ns_panel_alpha -> NSPanelTint (skin Variables.xml); unset -> FFFFFFFF
_PANEL_ALPHA = {'10': '1AFFFFFF', '20': '33FFFFFF', '30': '4DFFFFFF', '40': '66FFFFFF', '50': '80FFFFFF',
                '60': '99FFFFFF', '70': 'B3FFFFFF', '80': 'CCFFFFFF', '90': 'E6FFFFFF'}
_PANEL_DEFAULT = 'FFFFFFFF'
# ns_text_color -> NSFocusTextRGBVar; unset -> FFFFFF
_TEXT_RGB = {'1': '55CBFF', '2': '9AE4FF', '3': '00E5FF', '4': 'FFD54F', '5': 'FF9800',
             '6': 'E53935', '7': '39FF6A', '8': 'FF4081', '9': 'B388FF', '10': 'CCCCCC'}
_TEXT_DEFAULT = 'FFFFFF'
# ns_outline_color -> NSOutlineColorVar; unset -> FF000000
_OUTLINE_RGB = {'1': 'FF303030', '2': 'FFFFFFFF', '3': 'FF0D47A1', '4': 'FF1E88E5', '5': 'FF102040',
                '6': 'FF5D0000', '7': 'FF0B3D12', '8': 'FF3A0F5C', '9': 'FF7A5A00'}
_OUTLINE_DEFAULT = 'FF000000'
# The skin's keyboard title colour (DialogKeyboard.xml)
TITLE_RGB = 'FF55CBFF'


def _setting(name):
    return xbmc.getInfoLabel('Skin.String(%s)' % name).strip()


def _has(name):
    return xbmc.getCondVisibility('Skin.HasSetting(%s)' % name)


def style_properties():
    """{window property name: ARGB hex} for the keyboard."""
    panel = _PANEL_ALPHA.get(_setting('ns_panel_alpha'), _PANEL_DEFAULT)
    focus_rgb = _TEXT_RGB.get(_setting('ns_text_color'), _TEXT_DEFAULT)
    outline = _OUTLINE_RGB.get(_setting('ns_outline_color'), _OUTLINE_DEFAULT)
    if _has('ns_focus_rings'):
        outline = '00000000'
    return {
        'ns_panel': panel,
        'ns_neon': 'FF' + focus_rgb,
        'ns_outline': outline,
        'ns_title': TITLE_RGB,
    }
