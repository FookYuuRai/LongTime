# -*- coding: utf-8 -*-
"""Live title suggestions for the Nightshift search keyboard.

Uses TMDb's website search (the endpoint the TMDb site uses for its search box). No API key.

Header probe: TMDb may accept some request header sets and refuse others. On the first lookup the add-on
tries each header profile below against the same search, logs ACCEPTED or REJECTED for each, and uses the
first profile that returns JSON results. A profile that gets 403 is dropped and the next one is tried.
Successful results are cached in memory for the session; failures are not cached.
"""
import threading
import time

import xbmc

HOME_URL = 'https://www.themoviedb.org/'
SEARCH_URL = 'https://www.themoviedb.org/search/multi'
PROBE_QUERY = 'seraph'
PROBE_RETRY_SECONDS = 600

USER_FULL = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.themoviedb.org/",
    "Origin": "https://www.themoviedb.org",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}
_UA = USER_FULL["User-Agent"]

# (name, headers) - tried in this order
PROFILES = [
    ("user_full", USER_FULL),
    ("xhr_json", {
        "User-Agent": _UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
    }),
    ("xhr_json_origin", {
        "User-Agent": _UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
        "Origin": "https://www.themoviedb.org",
    }),
    ("chrome_doc_no_referer", {
        "User-Agent": _UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }),
    ("ua_only", {"User-Agent": "Mozilla/5.0"}),
    ("no_headers", {}),
]

TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 9

_cache = {}
_cache_order = []
_cache_lock = threading.Lock()
_state_lock = threading.Lock()
_chosen = {'name': None, 'headers': None}
_last_probe = [0.0]
_session = None


def _new_session(headers):
    """A fresh session that has loaded the TMDb homepage with `headers` (cookies)."""
    from modules.kodi_utils import make_session
    session = make_session('https://www.themoviedb.org')
    try:
        session.get(HOME_URL, headers=headers, timeout=TIMEOUT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] homepage warm-up failed: {exc}", xbmc.LOGWARNING)
    return session


def _try_profile(name, headers, query):
    """(accepted, reason) for one header profile against one search."""
    session = _new_session(headers)
    try:
        response = session.get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                               headers=headers, timeout=TIMEOUT)
    except Exception as exc:
        return False, f"request error: {exc}"
    code = response.status_code
    if code != 200:
        return False, f"HTTP {code}"
    try:
        data = response.json()
    except Exception:
        return False, "HTTP 200 but not JSON"
    if not isinstance(data, dict) or not isinstance(data.get('results'), list):
        return False, "HTTP 200 JSON without results"
    return True, f"HTTP 200 JSON, {len(data['results'])} results"


def probe_headers(query=PROBE_QUERY):
    """Try every profile, log ACCEPTED or REJECTED for each, and return the first accepted (name, headers)."""
    winner = None
    for name, headers in PROFILES:
        accepted, reason = _try_profile(name, headers, query)
        xbmc.log(f"[NIGHTSHIFT keyboard] header probe {name}: {'ACCEPTED' if accepted else 'REJECTED'} ({reason})",
                 xbmc.LOGINFO)
        if accepted and winner is None:
            winner = (name, headers)
            break
    if winner is None:
        xbmc.log("[NIGHTSHIFT keyboard] header probe: no header profile was accepted", xbmc.LOGWARNING)
    else:
        xbmc.log(f"[NIGHTSHIFT keyboard] header probe: using profile {winner[0]}", xbmc.LOGINFO)
    return winner


def _choose_profile():
    with _state_lock:
        if _chosen['headers'] is not None:
            return _chosen['name'], _chosen['headers']
        if time.time() - _last_probe[0] < PROBE_RETRY_SECONDS:
            return None
        _last_probe[0] = time.time()
    winner = probe_headers()
    if winner is None:
        return None
    with _state_lock:
        _chosen['name'], _chosen['headers'] = winner
    return winner


def _search(query):
    """Raw TMDb multi-search JSON. Raises if no profile is accepted or the request fails."""
    chosen = _choose_profile()
    if chosen is None:
        raise RuntimeError('no TMDb header profile accepted (see header probe log lines)')
    name, headers = chosen
    session = _new_session(headers)
    response = session.get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                           headers=headers, timeout=TIMEOUT)
    if response.status_code == 403:
        with _state_lock:
            _chosen['name'], _chosen['headers'] = None, None
            _last_probe[0] = 0.0
        raise RuntimeError(f"403 Client Error: Forbidden with profile {name}")
    response.raise_for_status()
    return response.json()


def titles_from_search(data, limit=DEFAULT_LIMIT):
    """Pull unique movie, TV and person names from a TMDb multi-search response."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    titles, seen = [], set()
    for item in results:
        if not isinstance(item, dict):
            continue
        kind = item.get('media_type')
        if kind == 'movie':
            title = item.get('title') or item.get('original_title')
        elif kind in ('tv', 'person'):
            title = item.get('name') or item.get('original_name')
        else:
            continue
        if not isinstance(title, str):
            continue
        title = title.strip()
        key = title.casefold()
        if not title or key in seen:
            continue
        seen.add(key)
        titles.append(title)
        if len(titles) >= limit:
            break
    return titles


def _remember(key, titles):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = titles
        while len(_cache_order) > CACHE_LIMIT:
            _cache.pop(_cache_order.pop(0), None)


def fetch_suggestions(text, limit=DEFAULT_LIMIT):
    """Return up to `limit` title suggestions for `text`. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    key = query.casefold()
    with _cache_lock:
        if key in _cache:
            return list(_cache[key])[:limit]
    try:
        titles = titles_from_search(_search(query), DEFAULT_LIMIT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] suggestions failed for {query!r}: {exc}", xbmc.LOGWARNING)
        return []
    _remember(key, titles)
    return titles[:limit]
