# -*- coding: utf-8 -*-
from apis import piratebay_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, scrape_expiry, scrape_timeout
from modules.settings import piratebay_scrape_active
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'piratebay'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not piratebay_scrape_active():
				source_utils.diag_log('PIRATEBAY', 'SCRAPER DISABLED')
				return source_utils.internal_results(self.scrape_provider, self.sources)

			media_type = info.get('media_type')
			absolute_episode = info.get('absolute_episode')
			if media_type == 'episode' and absolute_episode:
				source_utils.diag_log('PIRATEBAY Init', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					info.get('season'), info.get('episode'), absolute_episode, info.get('ep_name') or ''))

			queries = name_search_queries(info)
			source_utils.diag_log('PIRATEBAY Queries', 'generated=%d queries: %s' % (len(queries), ', '.join(repr(q) for q in queries)))
			files = merge_name_searches(
				piratebay_api.search, queries, scrape_timeout(info), scrape_expiry(info))

			raw_count = len(files or [])
			self.sources = filter_and_build_sources(self.scrape_provider, files, info)
			kept = len(self.sources)
			source_utils.diag_log('PIRATEBAY Match', '%s : %s kept / %s raw' % (info.get('title', ''), kept, raw_count))
			if raw_count and not self.sources:
				source_utils.diag_log('PIRATEBAY Match', 'all raw results dropped by title/episode filter')

		except Exception as e:
			logger('piratebay scraper Exception', str(e))
			source_utils.diag_log('PIRATEBAY', 'ERROR %s' % type(e).__name__)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources


# Knaben scraper, kept in this file: add-on updates do not always install newly added files.
_KNABEN_SRC = "# -*- coding: utf-8 -*-\nfrom apis.piratebay_api import knaben_api\nfrom modules import source_utils\nfrom modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, scrape_expiry, scrape_timeout\nfrom modules.settings import knaben_scrape_active\nfrom modules.kodi_utils import logger\n\nclass source:\n\tdef __init__(self):\n\t\tself.scrape_provider = 'knaben'\n\t\tself.sources = []\n\n\tdef results(self, info):\n\t\tsource_utils.remember_request(info)\n\t\ttry:\n\t\t\tif not knaben_scrape_active():\n\t\t\t\tsource_utils.diag_log('KNABEN', 'SCRAPER DISABLED')\n\t\t\t\treturn source_utils.internal_results(self.scrape_provider, self.sources)\n\n\t\t\tmedia_type = info.get('media_type')\n\t\t\tabsolute_episode = info.get('absolute_episode')\n\t\t\tif media_type == 'episode' and absolute_episode:\n\t\t\t\tsource_utils.diag_log('KNABEN Init', 'S%02dE%02d (abs=%d) ep_name=%r' % (\n\t\t\t\t\tinfo.get('season'), info.get('episode'), absolute_episode, info.get('ep_name') or ''))\n\n\t\t\tqueries = name_search_queries(info)\n\t\t\tsource_utils.diag_log('KNABEN Queries', 'generated=%d queries: %s' % (len(queries), ', '.join(repr(q) for q in queries)))\n\t\t\tfiles = merge_name_searches(\n\t\t\t\tknaben_api.search, queries, scrape_timeout(info), scrape_expiry(info))\n\n\t\t\traw_count = len(files or [])\n\t\t\tself.sources = filter_and_build_sources(self.scrape_provider, files, info)\n\t\t\tkept = len(self.sources)\n\t\t\tsource_utils.diag_log('KNABEN Match', '%s : %s kept / %s raw' % (info.get('title', ''), kept, raw_count))\n\t\t\tif raw_count and not self.sources:\n\t\t\t\tsource_utils.diag_log('KNABEN Match', 'all raw results dropped by title/episode filter')\n\n\t\texcept Exception as e:\n\t\t\tlogger('knaben scraper Exception', str(e))\n\t\t\tsource_utils.diag_log('KNABEN', 'ERROR %s' % type(e).__name__)\n\t\tsource_utils.internal_results(self.scrape_provider, self.sources)\n\t\treturn self.sources\n"


def _build_knaben_source():
	import types
	module = types.ModuleType('scrapers.knaben')
	exec(compile(_KNABEN_SRC, 'knaben_scraper', 'exec'), module.__dict__)
	return module.source


knaben_source = _build_knaben_source()
