# -*- coding: utf-8 -*-
from apis import animetosho_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, series_prefix_search_queries, scrape_expiry, scrape_timeout
from modules.settings import animetosho_scrape_active
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'animetosho'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not animetosho_scrape_active():
				return source_utils.internal_results(self.scrape_provider, self.sources)
			
			# Log absolute episode for diagnostics (episodes only)
			absolute_episode = info.get('absolute_episode')
			ep_name = info.get('ep_name') or ''
			if info.get('media_type') == 'episode' and absolute_episode:
				source_utils.diag_log('ANIMETOSHO Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					info.get('season'), info.get('episode'), absolute_episode, ep_name))
			
			files = merge_name_searches(
				animetosho_api.search, (lambda q: series_prefix_search_queries(info, q) + q)(name_search_queries(info)), scrape_timeout(info), scrape_expiry(info))
			
			raw_count = len(files or [])
			self.sources = filter_and_build_sources(self.scrape_provider, files, info)
			kept = len(self.sources)
			
			source_utils.diag_log('ANIMETOSHO Match', '%s : %s kept / %s raw' % (
				info.get('title', ''), kept, raw_count))
			if raw_count and not self.sources:
				source_utils.diag_log('ANIMETOSHO Match', 'all raw results dropped by filter_and_build_sources')
				
		except Exception as e:
			logger('animetosho scraper Exception', str(e))
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
