# -*- coding: utf-8 -*-
from apis.easynews_api import EasyNews
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import filter_by_name, filter_by_episode_title, easynews_language_filter, easynews_lang_include_unknown, easynews_fallback_search, easynews_search_width
# from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'easynews'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			filter_lang, lang_filters = easynews_language_filter()
			include_unknown = easynews_lang_include_unknown()
			filter_title = filter_by_name('easynews')
			allow_episode_title = filter_by_episode_title('easynews')
			
			self.media_type, title, self.year, self.season, self.episode = info.get('media_type'), info.get('title'), int(info.get('year')), info.get('season'), info.get('episode')
			self.search_title = clean_file_name(title).replace('&', 'and')
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.absolute_episode = info.get('absolute_episode')
			self.ep_name = info.get('ep_name') or ''
			self.total_aired_eps = info.get('total_aired_eps') or 1  # NEW: for dynamic padding
			self.alt_se = info.get('alt_se') or []
			expiry = info.get('expiry_times')[0]
			
			# Log absolute episode for diagnostics
			if self.media_type == 'episode' and self.absolute_episode:
				source_utils.diag_log('EN Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					self.season, self.episode, self.absolute_episode, self.ep_name))
			
			primary = self._search_name()
			files = self._merge_searches(self._search_queries(), expiry)
			
			if not files and easynews_fallback_search():
				files = self._merge_searches(self._fallback_search_queries(primary), expiry, files)
			
			if not files:
				source_utils.diag_log('EN Match', '%s : 0 files found' % title)
				return source_utils.internal_results(self.scrape_provider, self.sources)
			
			extras = source_utils.extras()
			raw_count = len(files)
			skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'language': 0, 'exception': 0}
			
			def _keep(file_name):
				# ✅ STEP 1: RELEASE FILTER FIRST
				# Release filter removed: it is a Real-Debrid-only rule (applied in debrid.stamp_torrent_cache / rd_cloud).
                
				# ✅ STEP 2: Extras check
				if source_utils.has_extras_word(file_name, extras):
					skipped['extras'] += 1
					source_utils.diag_log('EN Match', 'file REJECT (extras): %r' % file_name)
					return False
                
				# ✅ STEP 3: Standard title/episode matching (includes check-word validation)
				# This calls should_accept_file_title() which internally handles:
				# - episode_title_in_release() (token + contiguous matching)
				# - _ep_name_word_validation() (check-word guard + other token validation)
				# ###FIX### The queries below are title / title+S#E# / title+absolute / title+episode-name, so every
				# hit is already scoped to the show. Accept on ANY evidence (S#E#, absolute number, fuzzy episode
				# name, or the regular title paths) and only drop what matches none of them.
				if self.media_type == 'episode':
					accept_result, why = source_utils.episode_any_match(
						title, file_name, self.aliases, self.year, self.season, self.episode,
						ep_name=self.ep_name, absolute_episode=self.absolute_episode, filter_title=filter_title, allow_series_prefix=True)
				else:
					why = []
					accept_result = source_utils.should_accept_file_title(
							title, file_name, self.aliases, self.year, self.season, self.episode,
							ep_name=self.ep_name,
							absolute_episode=self.absolute_episode,
							in_cloud_folder=False,
							is_recovery_pass=False,
							filter_title=filter_title
					)
                
				if not accept_result:
					skipped['title_filter'] += 1
					source_utils.diag_log('EN Match', 'file REJECT (no S#E# / absolute / episode-name / title match): %r' % file_name)
					return False
				if why: source_utils.diag_log('EN Match', 'file MATCH via %s: %r' % ('+'.join(why), file_name))
                
				return True
            
			def _process():
				for item in files:
					try:
						if item.get('short_vid', False):
							skipped['extras'] += 1
							continue
                        
						file_name = normalize(item['name'])
                        
						if not _keep(file_name):
							continue
                        
						# Language filter (after file acceptance checks)
						if filter_lang and not self._language_ok(item.get('language'), lang_filters, include_unknown):
							skipped['language'] += 1
							source_utils.diag_log('EN Match', 'file REJECT (lang filter): %r' % file_name)
							continue
                        
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						source_utils.diag_log('EN Match', 'file ACCEPT: %r' % file_name)
                        
						url_dl, size = item['url_dl'], round(float(int(item.get('rawSize')))/1073741824, 2)
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name),
									default_quality=self._quality_estimate(int(item.get('width', 0))))
                        
						source_item = {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size, 'size_label': '%.2f GB' % size, 'debrid': self.scrape_provider,
									'extraInfo': details, 'url_dl': url_dl, 'down_url': item['down_url'], 'id': url_dl, 'local': False, 'direct': True, 'source': self.scrape_provider,
									'scrape_provider': self.scrape_provider}
						yield source_item
					except Exception as e:
						skipped['exception'] += 1
						from modules.kodi_utils import logger
						logger('easynews scraper yield source error', str(e))
            
			self.sources = list(_process())
            
			source_utils.diag_log('EN Match', '%s : %s kept / %d raw' % (title, len(self.sources), raw_count))
			if raw_count and not self.sources:
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('EN Match', 'all raw results dropped (%s)' % dropped)
			elif any(skipped.values()):
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('EN Match', 'dropped (%s)' % dropped)
                
		except Exception as e:
			from modules.kodi_utils import logger
			logger('easynews scraper Exception', str(e))
		
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _language_ok(self, language, lang_filters, include_unknown):
		if not language: return include_unknown
		if isinstance(language, (list, tuple)): parts = [str(i).lower() for i in language]
		else: parts = [str(language).lower()]
		return any(p in lang_filters for p in parts)

	def _merge_searches(self, queries, expiry, files=None):
		if files is None: files = []
		queries = queries or []
		seen = {i.get('url_dl') for i in files if i.get('url_dl')}
		for query in queries:
			found = EasyNews.search(query, expiry) or []
			source_utils.diag_log('EN Query', 'query=%r results=%d' % (query, len(found)))
			for item in found:
				if not isinstance(item, dict): continue
				url = item.get('url_dl')
				if url and url not in seen:
					seen.add(url)
					files.append(item)
		source_utils.diag_log('EN Match', 'merged=%d from %d queries' % (len(files), len(queries)))
		return files

	def _add_query(self, queries, seen, query):
		if query and query not in seen:
			seen.add(query)
			queries.append(query)

	def _search_queries(self):
		primary = self._search_name()
		seen = {primary}
		queries = [primary]
		# ###FIX### Episodes always run all four query shapes so the merged result set has everything, and the
		# match filter afterwards drops what matches none of S#E# / absolute number / episode name:
		#   1) title   2) title S#E#   3) title absolute (bare + padded)   4) title episode-name
		if self.media_type != 'movie':
			self._add_query(queries, seen, self.search_title)
			if self.absolute_episode:
				abs_ep = int(self.absolute_episode)
				self._add_query(queries, seen, '%s %d' % (self.search_title, abs_ep))
				padded = source_utils.padded_absolute(abs_ep, self.total_aired_eps)
				if padded: self._add_query(queries, seen, '%s %s' % (self.search_title, padded))
			if self.ep_name:
				ep_clean = clean_file_name(normalize(self.ep_name)).replace('&', 'and')
				self._add_query(queries, seen, '%s %s' % (self.search_title, ep_clean))
			for _as, _ae in list(self.alt_se)[:3]:
				try: self._add_query(queries, seen, '%s S%02dE%02d' % (self.search_title, int(_as), int(_ae)))
				except Exception: pass
		width = easynews_search_width()
		if width >= 1:
			if self.media_type == 'movie': self._add_query(queries, seen, self.search_title)
			else: self._add_query(queries, seen, '%s S%02d' % (self.search_title, self.season))
		if width >= 2:
			if self.media_type != 'movie': self._add_query(queries, seen, self.search_title)
			for alias in self.aliases:
				name = clean_file_name(alias).replace('&', 'and')
				if name == self.search_title: continue
				if self.media_type == 'movie':
					self._add_query(queries, seen, '%s %d' % (name, self.year))
					self._add_query(queries, seen, name)
				else:
					self._add_query(queries, seen, '%s S%02dE%02d' % (name, self.season, self.episode))
					self._add_query(queries, seen, '%s S%02d' % (name, self.season))
		if self.media_type != 'movie' and self.absolute_episode:
			abs_ep = int(self.absolute_episode)
			if self.ep_name:
				ep_clean = clean_file_name(normalize(self.ep_name)).replace('&', 'and')
				self._add_query(queries, seen, ep_clean)
			
			# Bare absolute - ALWAYS added (no padding)
			self._add_query(queries, seen, '%s %d' % (self.search_title, abs_ep))
			
			# Padded form ('047' for episode 47 of a 131-episode show)
			padded_query = source_utils.padded_absolute(abs_ep, self.total_aired_eps)
			if padded_query:
				self._add_query(queries, seen, '%s %s' % (self.search_title, padded_query))
		return queries

	def _fallback_search_queries(self, primary):
		queries = []
		seen = {primary}
		for query in self._search_queries():
			seen.add(query)
		for alias in self.aliases:
			name = clean_file_name(alias).replace('&', 'and')
			if name == self.search_title: continue
			if self.media_type == 'movie':
				self._add_query(queries, seen, '%s %d' % (name, self.year))
			else:
				self._add_query(queries, seen, '%s S%02dE%02d' % (name, self.season, self.episode))
				self._add_query(queries, seen, '%s S%02d' % (name, self.season))
		return queries

	def _quality_estimate(self, width):
		if width > 1920: return '4K'
		if 1280 < width <= 1920: return '1080p'
		if 720 < width <= 1280: return '720p'
		return 'SD'

	def _search_name(self):
		if self.media_type == 'movie': return '%s %d' % (self.search_title, self.year)
		else: return '%s S%02dE%02d' % (self.search_title,  self.season, self.episode)