# -*- coding: utf-8 -*-
from apis import nyaa_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, series_prefix_search_queries, scrape_expiry, scrape_timeout
from modules.settings import nyaa_scrape_active
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'nyaa'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not nyaa_scrape_active():
				source_utils.diag_log('NYAA', 'SCRAPER DISABLED')
				return source_utils.internal_results(self.scrape_provider, self.sources)
			
			# ===== INIT DIAGNOSTICS =====
			absolute_episode = info.get('absolute_episode')
			ep_name = info.get('ep_name') or ''
			media_type = info.get('media_type')
			title = info.get('title') or ''
			season = info.get('season')
			episode = info.get('episode')
			
			if media_type == 'episode' and absolute_episode:
				source_utils.diag_log('NYAA Init', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					season, episode, absolute_episode, ep_name))
			
			source_utils.diag_log('NYAA Init', 'query_title=%r type=%s season=%s episode=%s' % (
				title, media_type, season, episode))
			
			# ===== SEARCH QUERIES =====
			queries = name_search_queries(info)
			queries = series_prefix_search_queries(info, queries) + queries # targeted '<title> 01' queries first so a slow / rate-limited host cannot cut them off
			timeout = scrape_timeout(info)
			expiry = scrape_expiry(info)
			
			source_utils.diag_log('NYAA Queries', 'generated=%d queries: %s' % (len(queries), ', '.join(repr(q) for q in queries)))
			
			# ===== MERGE RESULTS FROM ALL QUERIES =====
			files = merge_name_searches(
				nyaa_api.search, queries, timeout, expiry)
			
			raw_count = len(files or [])
			source_utils.diag_log('NYAA Merge', 'raw total=%d from %d queries' % (raw_count, len(queries)))
			
			# ===== RAW DUMP (full listing - no cap for debug) =====
			for idx, raw in enumerate(files):
				source_utils.diag_log('NYAA Raw',
					'[%d] hash=%s size=%.2f seeders=%d name=%r' % (
						idx,
						(raw.get('hash') or ''),
						raw.get('size') or 0,
						raw.get('seeders') or 0,
						raw.get('name') or ''))
			
			# ===== FILTER & BUILD SOURCES =====
			self.sources = filter_and_build_sources(self.scrape_provider, files, info)
			kept = len(self.sources)
			
			source_utils.diag_log('NYAA Match', '%s : %s kept / %s raw' % (
				info.get('title', ''), kept, raw_count))
			
			if raw_count and not self.sources:
				# Log why everything was dropped
				dropped_reasons = []
				for raw in files:
					path = raw.get('name', '')
					if source_utils.is_error_release_name(path):
						dropped_reasons.append('error_name')
				
				if dropped_reasons:
					source_utils.diag_log('NYAA Match', 'all raw results dropped (reasons: %s)' % ', '.join(set(dropped_reasons)))
				else:
					source_utils.diag_log('NYAA Match', 'all raw results dropped by title/episode filter')
			
			# ===== QUALITY BREAKDOWN =====
			if self.sources:
				quality_counts = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
				for src in self.sources:
					qual = src.get('quality', 'SD')
					if qual == '4K': quality_counts['4K'] += 1
					elif qual == '1080p': quality_counts['1080p'] += 1
					elif qual == '720p': quality_counts['720p'] += 1
					else: quality_counts['SD'] += 1
				
				source_utils.diag_log('NYAA Quality', '4K=%d 1080p=%d 720p=%d SD=%d' % tuple(quality_counts.values()))
			
		except Exception as e:
			logger('nyaa scraper Exception', str(e))
			source_utils.diag_log('NYAA', 'ERROR %s' % type(e).__name__)
		
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
