# -*- coding: utf-8 -*-
import re
import time
from apis.nzb_api import search_all, nzb_link_hash, dedupe_releases
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import filter_by_name, filter_by_episode_title, nzb_fallback_search, nzb_search_width, nzb_quality_search, nzb_quality_types, nzb_results_per_type, nzb_checks_per_type, nzb_scrape_active, animetosho_nzb_enabled, nzb_use_direct, nzb_verify_playable, nzb_playback_mode, nzb_unpack_prefer_local, authorized_debrid_check
from modules.kodi_utils import logger as _log

QUERY_BUDGET = 40                  # default seconds; the Direct Sources setting 'Search Time Budget' (1-120) replaces it

def _query_budget():
	try:
		from caches.settings_cache import get_setting
		return max(1, min(120, int(get_setting('nightshift.nzb.query_budget', str(QUERY_BUDGET)))))
	except Exception:
		return QUERY_BUDGET

_RES_2160 = re.compile(r'(?<![a-z0-9])(?:2160p|4k|uhd)(?![a-z0-9])', re.I)
_RES_1080 = re.compile(r'(?<![a-z0-9])1080[pi](?![a-z0-9])', re.I)
_RES_720 = re.compile(r'(?<![a-z0-9])720p(?![a-z0-9])', re.I)
_HDTV = re.compile(r'(?<![a-z0-9])(?:hdtv|pdtv|dsr|tvrip)(?![a-z0-9])', re.I)
_RES_DVD = re.compile(r'(?<![a-z0-9])(?:dvd(?:rip|r|5|9)?|480p|576p|ntsc|pal)(?![a-z0-9])', re.I)
_REMUX = re.compile(r'(?<![a-z0-9])remux(?![a-z0-9])', re.I)
_BD = re.compile(r'(?<![a-z0-9])(?:blu-?ray|bdrip|brrip|bd25|bd50|bdmv|bd)(?![a-z0-9])', re.I)
_WEB = re.compile(r'(?<![a-z0-9])(?:web[-. ]?dl|web[-. ]?rip|web)(?![a-z0-9])', re.I)

RELEASE_TYPES = ('2160p remux', '2160p web', '1080p remux', '1080p bd', '1080p web', '720p', 'hdtv', 'dvd')

def release_type(name):
	"""'2160p remux' / '2160p web' / '1080p remux' / '1080p bd' / '1080p web' / '720p' / 'hdtv' / 'dvd', or '' for any other kind of release.
	An HDTV release is 'hdtv' at any resolution (so '720p' holds the other 720p releases)."""
	name = name or ''
	if _HDTV.search(name): return 'hdtv'
	if _RES_2160.search(name):
		if _REMUX.search(name): return '2160p remux'
		return '2160p web' if _WEB.search(name) else ''
	if _RES_1080.search(name):
		if _REMUX.search(name): return '1080p remux'
		if _BD.search(name): return '1080p bd'
		if _WEB.search(name): return '1080p web'
		return ''
	if _RES_720.search(name): return '720p'
	if _RES_DVD.search(name): return 'dvd'
	return ''

def group_by_release_type(sources, types, per_group, keep_other=False):
	"""Only the chosen release types, and of each the `per_group` largest (0 = no cap). With keep_other (the main or the episode
	title search is on) every other release forms one more group, capped the same way. Nothing left -> the list is returned unchanged."""
	groups = {}
	for item in sources:
		kind = release_type(item.get('name') or item.get('display_name'))
		if kind in types: groups.setdefault(kind, []).append(item)
		elif keep_other: groups.setdefault('other', []).append(item)
	if not groups: return sources
	keep = set()
	for kind, items in groups.items():
		items.sort(key=lambda i: -(i.get('size') or 0))
		keep.update(id(i) for i in (items[:per_group] if per_group and per_group > 0 else items))
	return [i for i in sources if id(i) in keep]

class source:
	def __init__(self):
		self.scrape_provider = 'nzb'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		self._started = time.time()
		try:
			if not nzb_scrape_active():
				_log('NZB', 'scraper skipped: inactive (needs NZB Indexers on + an indexer URL/key, and TorBox or a Direct Usenet provider as allowed by Playback Method)')
				return source_utils.internal_results(self.scrape_provider, self.sources)
			filter_title = filter_by_name('nzb')
			allow_episode_title = filter_by_episode_title('nzb')
			self.media_type, title, self.year, self.season, self.episode = info.get('media_type'), info.get('title'), int(info.get('year')), info.get('season'), info.get('episode')
			self.raw_title = title
			self.search_title = clean_file_name(title).replace('&', 'and')
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.absolute_episode = info.get('absolute_episode')
			self.ep_name = info.get('ep_name') or ''
			self.total_aired_eps = info.get('total_aired_eps') or 1  # NEW: for dynamic padding
			expiry = info.get('expiry_times')[0]
			
			# Log absolute episode for diagnostics
			if self.media_type == 'episode' and self.absolute_episode:
				source_utils.diag_log('NZB Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					self.season, self.episode, self.absolute_episode, self.ep_name))
			
			primary = self._search_name()
			group_queries = self._quality_queries(primary)
			if group_queries:
				# Search by Quality: one search per chosen release type INSTEAD of the main search; the main searches only run if these find nothing
				files = self._merge_searches(group_queries, expiry, light_after_first=True)
				if not files: files = self._merge_searches(self._search_queries(), expiry)
			else:
				files = self._merge_searches(self._search_queries(), expiry)
			files = self._add_animetosho(info, files)
			if not files and nzb_fallback_search(): files = self._merge_searches(self._fallback_search_queries(primary), expiry, files)
			if not files:
				_log('NZB', '%s : indexers returned 0 results' % title)
				source_utils.diag_log('NZB Match', '%s : 0 kept / 0 raw (no query results)' % title)
				return source_utils.internal_results(self.scrape_provider, self.sources)
			cached_hashes = self._torbox_cached_hashes([i.get('link', '') for i in files if i.get('link')])
			extras = source_utils.extras()
			raw_count = len(files)
			skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'hash': 0, 'no_link': 0, 'exception': 0, 'archive': 0, 'unreadable_nzb': 0, 'unplayable': 0}
			def _process():
				for item in files:
					try:
						file_name = normalize(item.get('name', ''))
						if not file_name:
							skipped['no_link'] += 1
							continue
                        
						# RELEASE FILTER CHECK
						# Release filter removed: it is a Real-Debrid-only rule (applied in debrid.stamp_torrent_cache / rd_cloud).
                        
						_whole_show = False
						if self.media_type == 'episode' and source_utils.has_extras_word(file_name, extras):
							try:
								from modules.native_torrents import pack_type_from_name as _ptn, has_multi_season_range as _hmsr
								# 'Show S01-S03 + Specials + Extras' holds the episodes: an extras word in a multi-season pack name is not an extras-only release
								_whole_show = _ptn(file_name, self.season) == 'show' and bool(source_utils.names_season_set(file_name) or _hmsr(file_name))
							except Exception: _whole_show = False
						if source_utils.has_extras_word(file_name, extras) and not _whole_show:
							skipped['extras'] += 1
							source_utils.diag_log('NZB Match', 'file REJECT (extras): %r' % file_name)
							continue
						# ###FIX### accept on ANY evidence (S#E#, absolute number, fuzzy episode name, title paths)
						if self.media_type == 'episode':
							_ok, _why = source_utils.episode_any_match(
								title, file_name, self.aliases, self.year, self.season, self.episode,
								ep_name=self.ep_name, absolute_episode=self.absolute_episode, filter_title=filter_title, allow_series_prefix=True)
						else:
							_why = []
							_ok = source_utils.should_accept_file_title(
								title, file_name, self.aliases, self.year, self.season, self.episode,
								ep_name=self.ep_name,
								absolute_episode=self.absolute_episode,
								in_cloud_folder=False,
								is_recovery_pass=False,
								filter_title=filter_title
							)
						_pack = None
						if not _ok and self.media_type == 'episode':
							# a season pack / complete series of THIS show (same rule the torrent scrapers use): no episode token by design
							try:
								from modules.native_torrents import pack_type_from_name
								_pairs = [(self.season, self.episode)] + source_utils.alt_gate_pairs(self.season, self.episode, self.absolute_episode)
								_pack = None
								for _ps, _pe in _pairs:
									_pack = pack_type_from_name(file_name, _ps)
									if _pack: break
								if not _pack and source_utils.names_season_titles(file_name, title, self.aliases): _pack = 'show'   # 'The Aegis of Uruk & The Sword of Uruk': both season titles named
								if _pack and source_utils.check_title(title, file_name, self.aliases, self.year, 'pack', self.episode) and not source_utils.names_other_episode(file_name, self.season, self.episode, self.absolute_episode):
									_ok = True
									# an explicit episode range that does not contain the requested episode ('Eps 001-082' for episode 83) can never yield it
									from modules.native_torrents import pack_episode_ranges
									_targets = set()
									for _v in (self.episode, self.absolute_episode):
										try:
											if _v and int(_v) > 0: _targets.add(int(_v))
										except Exception: pass
									_ranges = pack_episode_ranges(file_name)
									if _ranges and _targets and not any(lo <= t <= hi for (lo, hi) in _ranges for t in _targets):
										_ok = False
										source_utils.diag_log('NZB Match', 'file REJECT (pack range %s excludes targets=%s): %r' % (_ranges, sorted(_targets), file_name))
							except Exception:
								_ok = False
						if not _ok and self.media_type == 'episode':
							_kind = None
							for _i, (_ps, _pe) in enumerate([(self.season, self.episode)] + source_utils.alt_gate_pairs(self.season, self.episode, self.absolute_episode)):
								_kind = source_utils.loose_release_kind(file_name, title, self.aliases, _ps, _pe, self.absolute_episode)
								if _kind == 'season' and _i:    # the other numbering must be named in the release itself
									from modules.native_torrents import pack_type_from_name as _ptn
									if not (_ptn(file_name, _ps) or source_utils._ORDINAL_SEASON_RE.search(file_name)): _kind = None
								if _kind: break
							if _kind:
								_ok = True
								if _kind == 'season': _pack = _pack or 'season'
						if not _ok:
							skipped['title_filter'] += 1
							source_utils.diag_log('NZB Match', 'file REJECT (no S#E# / absolute / episode-name / title match): %r' % file_name)
							continue
						source_utils.diag_log('NZB Match', 'file ACCEPT: %r' % file_name)
						nzb_link = item.get('link', '')
						if not nzb_link:
							skipped['no_link'] += 1
							continue
						nzb_hash = nzb_link_hash(nzb_link)
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						size_bytes = int(item.get('size', 0) or 0)
						size = round(size_bytes / 1073741824.0, 2) if size_bytes else 0.0
						size_label = '%.2f GB' % size if size_bytes else 'N/A'
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name))
						indexer = item.get('indexer', 'NZB')
						if indexer and indexer not in details: details = '%s | Site: %s' % (details, indexer)
						if _pack: details = '%s | PACK' % details
						direct = nzb_use_direct(nzb_hash in cached_hashes)
						source_item = {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size,
									'size_label': '%.2f GB' % size if size_bytes else 'N/A', 'debrid': self.scrape_provider, 'extraInfo': details,
									'url_dl': nzb_link, 'id': nzb_hash, 'nzb_link': nzb_link, 'nzb_hash': nzb_hash,
									'nzb_indexer': indexer, 'nzb_alternates': list(item.get('alternates') or []), 'nzb_no_grab': bool(item.get('no_grab')), 'nzb_cached': nzb_hash in cached_hashes, 'nzb_direct': direct,
									'local': False, 'direct': False, 'source': self.scrape_provider, 'scrape_provider': self.scrape_provider}
						yield source_item
					except Exception as e:
						skipped['exception'] += 1
						from modules.kodi_utils import logger
						logger('nzb scraper yield source error', str(e))
			self.sources = list(_process())
			if group_queries and self.sources:
				# only the chosen release types, and of each the largest few (the same number the playability check covers)
				before = len(self.sources)
				chosen = nzb_quality_types(self.media_type)
				if 'main' in chosen or 'epname' in chosen:
					# a title search returns every kind of release: nothing is left out, all of it is grouped by release type (the search
					# toggles then decide what is searched for by name, not what is shown)
					types, other = set(RELEASE_TYPES), True
				else: types, other = set(chosen), False
				self.sources = group_by_release_type(self.sources, types, nzb_results_per_type(), keep_other=other)
				_log('NZB', 'Search by Quality: %d of %d result(s) kept (chosen release types, %d largest of each)' % (len(self.sources), before, nzb_results_per_type()))
			# The archive / playability checks run later, on the FINAL results list (check_results), so only releases that will really be
			# shown - the largest few of them - cost an NZB download.
			_log('NZB', '%s : %s kept / %d raw (direct Usenet=%s)' % (title, len(self.sources), raw_count, any(i.get('nzb_direct') for i in self.sources)))
			source_utils.diag_log('NZB Match', '%s : %s kept / %d raw' % (title, len(self.sources), raw_count))
			if raw_count and not self.sources:
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('NZB Match', 'all raw results dropped (%s)' % dropped)
			elif any(skipped.values()):
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('NZB Match', 'dropped (%s)' % dropped)
		except Exception as e:
			from modules.kodi_utils import logger
			logger('nzb scraper Exception', str(e))
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _add_animetosho(self, info, files):
		"""AnimeTosho NZBs (setting: AnimeTosho NZBs): searched with the same queries as the AnimeTosho torrent scraper;
		they then go through the same matching and playability steps as any indexer result."""
		try:
			if not animetosho_nzb_enabled(): return files
			from apis import animetosho_api
			from modules.native_torrents import name_search_queries, scrape_timeout
			timeout = scrape_timeout(info)
			queries = name_search_queries(info) or []
			per_query = max(5, min(10, int(timeout) // max(1, len(queries) or 1)))
			seen = {i.get('link') for i in files if i.get('link')}
			added = 0
			expiry = info.get('expiry_times')[0] or 24
			def _one(query):
				try: return animetosho_api.search_nzb(query, timeout=per_query, expiration=expiry) or []
				except Exception: return []
			# all queries at once (they were asked one after the other and, with several queries, used up the NZB scraper's whole wait)
			from concurrent.futures import ThreadPoolExecutor
			with ThreadPoolExecutor(max_workers=max(1, min(4, len(queries)))) as pool:
				batches = list(pool.map(_one, queries))
			for batch in batches:
				for item in batch:
					if item['link'] not in seen:
						seen.add(item['link'])
						files.append(item)
						added += 1
			source_utils.diag_log('NZB Match', 'AnimeTosho NZBs: %d added from %d queries' % (added, len(queries)))
		except Exception as e:
			_log('NZB', 'AnimeTosho NZB search failed: %s' % e)
		return files

	def _torbox_cached_hashes(self, links):
		try:
			if not authorized_debrid_check('tb'): return set()
			from apis.torbox_api import TorBoxAPI
			hashes = [nzb_link_hash(link) for link in links if link]
			return TorBoxAPI().usenet_hashes_cached(hashes)
		except: return set()

	def _merge_searches(self, queries, expiry, files=None, light_after_first=False):
		if files is None: files = []
		queries = queries or []
		seen = {i.get('link') for i in files if i.get('link')}
		for number, query in enumerate(queries):
			if files and time.time() - getattr(self, '_started', time.time()) > _query_budget():       # the scrape dialog stops waiting at 60 s: stop asking, use what is in
				source_utils.diag_log('NZB Match', 'query budget (%d s) used up - skipping the remaining queries' % _query_budget())
				break
			found = search_all(query, expiration=expiry, light=bool(light_after_first and number)) or []
			source_utils.diag_log('NZB Match', 'query=%r results=%d' % (query, len(found)))
			for item in found:
				link = item.get('link')
				if link and link not in seen:
					seen.add(link)
					files.append(item)
		source_utils.diag_log('NZB Match', 'merged=%d from %d queries (same release on several indexers is listed once per indexer)' % (len(files), len(queries)))
		return files

	def _add_query(self, queries, seen, query):
		if query and query not in seen:
			seen.add(query)
			queries.append(query)

	def _search_queries(self):
		primary = self._search_name()
		seen = {primary}
		queries = [primary]
		width = nzb_search_width()
		# the same episode under the releases' own numbering (TMDb S01E25 = release S02E01), at every search width: without it the
		# Focused width only ever asked for S01E25 and the S02 episodes / packs were never searched for
		for alt_season, alt_episode in self._alt_season_pairs():
			self._add_query(queries, seen, '%s S%02dE%02d' % (self.search_title, alt_season, alt_episode))
			self._add_query(queries, seen, '%s S%02d' % (self.search_title, alt_season))
		if width >= 1:
			if self.media_type == 'movie': self._add_query(queries, seen, self.search_title)
			else: self._add_query(queries, seen, '%s S%02d' % (self.search_title, self.season))
		if width >= 2:
			if self.media_type != 'movie': self._add_query(queries, seen, self.search_title)
			for alias in self.aliases:
				name = clean_file_name(alias).replace('&', 'and')
				if name == self.search_title: continue
				if self.media_type == 'movie':
					self._add_query(queries, seen, '%s %d' % (name, self.year))
					self._add_query(queries, seen, name)
				else:
					self._add_query(queries, seen, '%s S%02dE%02d' % (name, self.season, self.episode))
					self._add_query(queries, seen, '%s S%02d' % (name, self.season))
			# base series title: "Dragon Ball Super: Beerus" -> "Dragon Ball Super" (releases rarely carry the subtitle)
			base = self._base_series_title()
			if base:
				self._add_query(queries, seen, '%s S%02dE%02d' % (base, self.season, self.episode))
				self._add_query(queries, seen, '%s S%02d' % (base, self.season))
		if self.media_type != 'movie' and int(self.season or 0) == 0:
			for word in ('Specials', 'OVA', 'S00'):
				self._add_query(queries, seen, '%s %s' % (self.search_title, word))
			if self.ep_name:
				ep_sp = clean_file_name(normalize(self.ep_name)).replace('&', 'and')
				if ep_sp:
					self._add_query(queries, seen, '%s %s' % (self.search_title, ep_sp))
					self._add_query(queries, seen, ep_sp)
		if self.media_type != 'movie' and self.absolute_episode:
			abs_ep = int(self.absolute_episode)
			if self.ep_name:
				ep_clean = clean_file_name(normalize(self.ep_name)).replace('&', 'and')
				self._add_query(queries, seen, ep_clean)
			
			abs_titles = [self.search_title]
			base = self._base_series_title() if width >= 2 else ''
			if base: abs_titles.append(base)
			for abs_title in abs_titles:
				# Bare absolute - ALWAYS added (no padding)
				self._add_query(queries, seen, '%s %d' % (abs_title, abs_ep))
				
				# Padded form ('047' for episode 47 of a 131-episode show)
				padded_query = source_utils.padded_absolute(abs_ep, self.total_aired_eps)
				if padded_query:
					self._add_query(queries, seen, '%s %s' % (abs_title, padded_query))
		return queries

	QUALITY_WORDS = {'2160p remux': '2160p remux', '2160p web': '2160p web', 'hdtv': 'hdtv', '1080p remux': '1080p remux', '1080p bd': '1080p bluray', '1080p web': '1080p web', '720p': '720p', 'dvd': 'dvd'}

	def _quality_queries(self, primary):
		"""Search by Quality (master switch) runs the searches that are switched on, each its own request to every indexer:
		the plain main search (Title Year / Show SxxExx), 'Show Episode Name' (TV, no quality words), and one per release type
		('Title 2020 2160p web', '... 1080p bluray', '... hdtv', '... dvd'). Indexers only return the first ~100 hits of a search,
		so asking for each kind by name keeps the big releases from being pushed out by the small ones."""
		if not nzb_quality_search(): return []
		types = nzb_quality_types(self.media_type)
		queries = []
		if 'main' in types: queries.append(primary)
		queries += ['%s %s' % (primary, self.QUALITY_WORDS[t]) for t in types if t in self.QUALITY_WORDS]
		if 'epname' in types and self.media_type == 'episode' and self.ep_name:
			ep_clean = clean_file_name(normalize(self.ep_name)).replace('&', 'and')
			if ep_clean: queries.append('%s %s' % (self.search_title, ep_clean))
		# the same episode under the releases' own numbering (TMDb S01E25 = release S02E01): 'Show S02 1080p remux' finds the S02 packs
		# and episodes, which the requested-numbering queries above never can
		for alt_season, _alt_ep in self._alt_season_pairs():
			if 'main' in types: queries.append('%s S%02d' % (self.search_title, alt_season))
			queries += ['%s S%02d %s' % (self.search_title, alt_season, self.QUALITY_WORDS[t]) for t in types if t in self.QUALITY_WORDS]
		return list(dict.fromkeys(queries))[:20]

	def _alt_season_pairs(self):
		"""[(season, episode)] of this episode under another numbering, e.g. [(2, 1)] for TMDb S01E25. Empty for movies / no alternative."""
		if self.media_type == 'movie': return []
		try: return source_utils.alt_gate_pairs(self.season, self.episode, self.absolute_episode)
		except Exception: return []

	def _base_series_title(self):
		"""TV only: the title before a subtitle, e.g. 'Dragon Ball Super: Beerus' -> 'Dragon Ball Super'. '' if none."""
		if self.media_type == 'movie': return ''
		raw = getattr(self, 'raw_title', '') or ''
		for sep in (':', ' - ', ' \u2013 '):
			if sep in raw:
				base = clean_file_name(raw.split(sep, 1)[0]).replace('&', 'and').strip()
				if len(base) >= 3 and base.lower() != self.search_title.lower(): return base
				return ''
		return ''


	def _fallback_search_queries(self, primary):
		queries, seen = [], {primary}
		for query in self._search_queries():
			seen.add(query)
		for alias in self.aliases:
			name = clean_file_name(alias).replace('&', 'and')
			if name == self.search_title: continue
			if self.media_type == 'movie':
				self._add_query(queries, seen, '%s %d' % (name, self.year))
			else:
				self._add_query(queries, seen, '%s S%02dE%02d' % (name, self.season, self.episode))
				self._add_query(queries, seen, '%s S%02d' % (name, self.season))
		return queries

	def _search_name(self):
		if self.media_type == 'movie': return '%s %d' % (self.search_title, self.year)
		return '%s S%02dE%02d' % (self.search_title, self.season, self.episode)


# --- checks on the FINAL results list -----------------------------------------------------------------------------------------
# Run from sources.process_results after every filter, sort and limit: only the NZB results that will really be shown are
# looked at, and of those only the largest few (Settings: Check Limit per Search) that are not judged yet cost an NZB download.

def _limit_playability(todo, log):
	"""The results to judge. Normally the Check Limit LARGEST ones (sorted by size first, whatever order the list is shown in).
	With Search by Quality on: the largest few (Health Checks per Release Type) of EACH release type. A judged result outside that
	costs nothing (a dead one is simply dropped), and one inside it costs nothing either, so opening the same search again
	downloads nothing."""
	from apis.nzb_api import nzb_check_limit, nzb_in_memory
	from apis import usenet_stream
	grouped = nzb_quality_search()
	limit = nzb_checks_per_type() if grouped else nzb_check_limit()
	if not limit or limit < 1: return todo
	ranked = sorted(todo.values(), key=lambda s: -(s.get('size') or 0))
	if grouped:
		counts, top = {}, []
		for s in ranked:
			kind = release_type(s.get('name') or s.get('display_name')) or 'other'
			counts[kind] = counts.get(kind, 0) + 1
			if counts[kind] <= limit: top.append(s)
	else:
		top = ranked[:limit]
	known = lambda s: nzb_in_memory(s['nzb_link']) or usenet_stream.verdict_cached(s['nzb_link'])
	in_top = {id(s) for s in top}
	extra = [s for s in ranked if id(s) not in in_top and known(s)]
	new = [s for s in top if not known(s)]
	log('playability: %d of %d NZB result(s) chosen by size (%s): %d to download and check, %d already judged, %d more judged earlier, %d listed unchecked' % (
		len(top), len(ranked), ('%d largest of each release type' % limit) if grouped else ('largest %.1f GB' % ((top[0].get('size') or 0) if top else 0)),
		len(new), len(top) - len(new), len(extra), len(ranked) - len(top) - len(extra)))
	return {id(s): s for s in top + extra}

def drop_unplayable(sources, skipped):
	"""Direct-Usenet results only (TorBox-cached ones play from TorBox).
	- A release whose articles are gone is dropped - but only when NO indexer copy of it works: the copies from the
	  other indexers are tried in slot order and the first one that works replaces the failing top one.
	- A 7z / compressed / encrypted archive cannot be streamed from the provider; it goes to TorBox (which unpacks
	  it) when TorBox is available, else it is dropped.
	- Results the check could not judge stay."""
	try:
		from apis import usenet_stream
		from apis.nzb_api import nzb_check_limit, nzb_in_memory
		def log(m):
			source_utils.diag_log('NZB Match', m)
			_log('NZB', m)                    # also in the Kodi log, not only the live trace
		import time
		deadline = time.time() + 40
		todo = {id(s): s for s in sources if s.get('nzb_direct') and not s.get('nzb_no_grab')}
		if not todo: return sources
		# Only the largest few results that are not judged yet cost an NZB download; judged ones are free.
		todo = _limit_playability(todo, log)
		if not todo: return sources
		limit = nzb_check_limit()
		if nzb_quality_search(): limit = nzb_checks_per_type() * len({release_type(x.get('name') or x.get('display_name')) or 'other' for x in todo.values()})
		spent = len([x for x in todo.values() if not usenet_stream.verdict_cached(x['nzb_link'])])
		budget = [(limit - spent) if limit and limit > 0 else 10 ** 6]      # downloads left for other indexers' copies of dead results
		tried = {}                                    # id(source) -> candidates already judged: [(candidate, verdict, reason)]
		state = {id(s): None for s in todo.values()}  # the verdict that stands for each source
		judged = {}
		for round_no in range(4):
			batch = []
			for key, s in todo.items():
				if state[key] and state[key][0] in (True, 'unpack'): continue
				cands = [{'link': s['nzb_link'], 'indexer': s['nzb_indexer'], 'slot': 0}] + list(s.get('nzb_alternates') or [])
				done = {c['link'] for c, _, _ in tried.get(key, [])}
				nxt = next((c for c in cands if c['link'] not in done), None)
				if nxt and round_no and not (nzb_in_memory(nxt['link']) or usenet_stream.verdict_cached(nxt['link'])):
					if budget[0] <= 0: continue               # strict limit: another indexer's copy is one more download, and the allowance is spent
					budget[0] -= 1
				if nxt: batch.append((key, nxt))
			if not batch or time.time() >= deadline: break
			verdicts = usenet_stream.check_many([c['link'] for _, c in batch], budget=max(5, deadline - time.time()), log=log)
			for key, cand in batch:
				value = verdicts.get(cand['link']) or (None, 'not finished')
				tried.setdefault(key, []).append((cand, value[0], value[1]))
				judged[cand['link']] = value
				cur = state[key]
				# rank: working (True / unpack) beats unknown (None) beats dead (False); earlier slot wins ties
				if cur is None or (value[0] in (True, 'unpack')) or (cur[0] is False and value[0] is None):
					state[key] = (value[0], value[1], cand)
				elif cur[0] is False and value[0] is False:
					pass
		kept, dead, moved, unpacked, local = [], 0, 0, 0, 0
		torbox_ok = nzb_playback_mode() != '1' and authorized_debrid_check('tb')
		for s in sources:
			key = id(s)
			if key not in state:
				kept.append(s)
				continue
			verdict, reason, cand = state[key] if state[key] else (None, 'unchecked', None)
			if verdict is False:
				dead += 1
				log('unplayable REJECT (%s, %d copies tried): %r' % (reason, len(tried.get(key, [])), s.get('name')))
				continue
			if cand and cand['link'] != s['nzb_link']:      # a lower copy works while the top one failed: use it
				log('swapped %r: %s failed (%s) -> %s works' % (s.get('name'), s.get('nzb_indexer'), tried[key][0][2], cand.get('indexer')))
				old_indexer = s.get('nzb_indexer')
				s['extraInfo'] = (s.get('extraInfo') or '').replace('Site: %s' % old_indexer, 'Site: %s' % cand.get('indexer'))
				s.update({'nzb_link': cand['link'], 'url_dl': cand['link'], 'nzb_hash': nzb_link_hash(cand['link']),
						'id': nzb_link_hash(cand['link']), 'nzb_indexer': cand.get('indexer') or old_indexer})
				moved += 1
			if verdict == 'unpack':
				local_ok = usenet_stream.unpack_ready() and not re.search(r'7z|compress|password|encrypt', str(reason), re.I)
				if local_ok and (nzb_unpack_prefer_local() or not torbox_ok):
					s['nzb_local_unpack'] = True
					s['extraInfo'] = '%s | UNPACK to local folder' % (s.get('extraInfo') or '')
					local += 1
				elif torbox_ok:
					s['nzb_direct'] = False
					s['extraInfo'] = '%s | UNPACK via TorBox' % (s.get('extraInfo') or '')
					unpacked += 1
				else:
					dead += 1
					log('archive REJECT (%s; TorBox not available and no usable local unpack folder): %r' % (reason, s.get('name')))
					continue
			kept.append(s)
		sources = kept
		if dead: skipped['unplayable'] = dead
		log('playability: checked=%d dead=%d swapped-to-another-indexer=%d sent-to-TorBox-to-unpack=%d unpack-to-local-folder=%d unknown=%d' % (
			len(judged), dead, moved, unpacked, local, sum(1 for v in judged.values() if v[0] is None)))
	except Exception as e:
		_log('NZB', 'playability check skipped: %s' % e)
	return sources


def check_results(results, only=None):
	"""The final results list with the dead, archive and unreadable NZB results taken out (other providers' results untouched).
	only: check just these NZB results (Autoplay: the one it is about to play) - every other NZB result is left as it is, unchecked."""
	try:
		_only = None if only is None else {o.get('nzb_link') for o in only}   # (the autoplay candidates can be copies: matched by link)
		nzb = [s for s in results if s.get('scrape_provider') == 'nzb' and (_only is None or s.get('nzb_link') in _only)]
		if not nzb: return results
		skipped = {}
		kept = list(nzb)
		if nzb_verify_playable(): kept = drop_unplayable(kept, skipped)
		keep_ids = {id(s) for s in kept}
		checked_ids = {id(s) for s in nzb}
		# an NZB result that was not part of this check (autoplay checks only the next pick) stays in the list untouched
		out = [s for s in results if s.get('scrape_provider') != 'nzb' or id(s) in keep_ids or id(s) not in checked_ids]
		if len(out) != len(results):
			source_utils.diag_log('NZB Match', 'final list: %d of %d NZB result(s) kept (%s)' % (len(kept), len(nzb), ', '.join('%s=%s' % kv for kv in skipped.items() if kv[1])))
		return out
	except Exception as e:
		_log('NZB', 'final-list check skipped: %s' % e)
		return results
