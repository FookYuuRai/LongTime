# -*- coding: utf-8 -*-
from threading import Thread
from apis.alldebrid_api import AllDebridAPI
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name
# from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'ad_cloud'
		self.sources = []
		self.AllDebrid = AllDebridAPI()
		self.extensions = source_utils.supported_video_extensions()

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not enabled_debrids_check('ad'): return source_utils.internal_results(self.scrape_provider, self.sources)
			self.folder_results, self.scrape_results = [], []
			self.filter_title = filter_by_name(self.scrape_provider)
			self.media_type, title = info.get('media_type'), info.get('title')
			self.year, self.season, self.episode = int(info.get('year')), info.get('season'), info.get('episode')
			self.absolute_episode = info.get('absolute_episode')
			self.ep_name = info.get('ep_name', '')  # Episode name for title-token override
			self.tmdb_id = info.get('tmdb_id')
			self.title = title
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.folder_query = source_utils.clean_title(normalize(title))
			self.folder_queries = source_utils.folder_title_queries(title, self.aliases)
			
			# Log absolute episode for diagnostics (episodes only)
			if self.media_type == 'episode' and self.absolute_episode:
				source_utils.diag_log('AD Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					self.season, self.episode, self.absolute_episode, self.ep_name))
			
			self._scrape_history()
			self._scrape_links()
			self._scrape_cloud()
			# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			self._apply_title_token_recovery()
			# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			if not self.scrape_results: return source_utils.internal_results(self.scrape_provider, self.sources)
			
			raw_count = len(self.scrape_results)
			skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'exception': 0}
			
			def _process():
				for item in self.scrape_results:
					try:
						file_name = normalize(item['n'])
						
						# RELEASE FILTER CHECK
						# Release filter removed: it is a Real-Debrid-only rule (applied in debrid.stamp_torrent_cache / rd_cloud).
                        
						# Use unified wrapper for title/episode acceptance (cloud-folder gating)
						if not source_utils.should_accept_file_title(
							self.title, file_name, self.aliases, self.year, self.season, self.episode,
							ep_name=self.ep_name if self.media_type == 'episode' else None,
							absolute_episode=self.absolute_episode,
							in_cloud_folder=True,
							is_recovery_pass=False,
							filter_title=self.filter_title
						):
							skipped['title_filter'] += 1
							source_utils.diag_log('AD Match', 'file REJECT (title_filter): %r' % file_name)
							continue
						
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						direct_debrid_link = item.get('direct_debrid_link', False)
						file_dl, size = item['l'], round(float(int(item['s']))/1073741824, 2)
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name))
						source_item = {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size, 'size_label': '%.2f GB' % size,
										'extraInfo': details, 'url_dl': file_dl, 'id': file_dl, 'downloads': False, 'direct': True, 'source': self.scrape_provider,
										'debrid': self.scrape_provider, 'scrape_provider': self.scrape_provider, 'direct_debrid_link': direct_debrid_link,
						'folder_id': item.get('folder_id')}
						source_utils.diag_log('AD Match', 'file ACCEPT: %r' % file_name)
						yield source_item
					except: 
						skipped['exception'] += 1
			self.sources = list(_process())
			
			source_utils.diag_log('AD Match', '%s : %s kept / %d raw' % (title, len(self.sources), raw_count))
			if raw_count and not self.sources:
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('AD Match', 'all raw results dropped (%s)' % dropped)
			elif any(skipped.values()):
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('AD Match', 'dropped (%s)' % dropped)
		except Exception as e:
			from modules.kodi_utils import logger
			logger('alldebrid scraper Exception', str(e))
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _dedupe_key(self, name):
		return name.replace('/', '').lower()

	def _already_scraped(self, name):
		key = self._dedupe_key(name)
		return key in {self._dedupe_key(d['n']) for d in self.scrape_results}

	def _append_scrape_result(self, item):
		if not item.get('l') or self._already_scraped(item.get('n', '')): return
		self.scrape_results.append(item)

	def _folder_matches(self, folder_name):
		"""Check if folder name matches show title or aliases.
		
		Used for folder-gated loose matching: when a folder is matched,
		we can accept files via episode-title tokens even if S#E# doesn't match.
		"""
		if not folder_name: return True
		if not self.filter_title: return True
		cleaned = source_utils.clean_title(normalize(folder_name))
		if not cleaned: return True
		queries = getattr(self, 'folder_queries', None) or [self.folder_query]
		if self.ep_name and source_utils.episode_title_in_release(self.ep_name, normalize(folder_name)):
			return True
		return any(q and q in cleaned for q in queries)

	def _file_matches(self, filename, folder_matched=False):
		"""Check if file matches media type and optionally uses folder context.
		
		For episodes:
		- If folder_matched=True: accept via S#E# tokens OR episode-title tokens
		- If folder_matched=False: apply stricter matching (require show title + episode)
		
		Args:
			filename: File to check
			folder_matched: Whether file is inside a matched folder (enables loose matching)
		"""
		if self.media_type == 'movie':
			if not any(x in normalize(filename) for x in self._year_query_list()): return False
		# Use unified wrapper to handle episode vs movie logic and folder gating
		if not source_utils.should_accept_file_title(
			self.title, filename, self.aliases, self.year, self.season, self.episode,
			ep_name=self.ep_name,
			absolute_episode=self.absolute_episode,
			in_cloud_folder=folder_matched,
			is_recovery_pass=False,
			filter_title=self.filter_title
		):
			return False
		return True

	def _scrape_history(self):
		try:
			history = self.AllDebrid.history()
			my_history = history.get('links', []) or []
			my_history = [i for i in my_history if not i.get('error')]
			my_history = [i for i in my_history if i['filename'].lower().endswith(tuple(self.extensions))]
			for item in my_history:
				filename = item['filename']
				if not self._file_matches(filename, folder_matched=False): continue
				self._append_scrape_result({
					'l': item.get('link_dl') or item.get('link'),
					's': item['size'],
					'n': filename,
					'direct_debrid_link': bool(item.get('link_dl')),
				})
		except: pass

	def _scrape_links(self):
		try:
			links = self.AllDebrid.user_links()
			my_links = links.get('links', []) or []
			my_links = [i for i in my_links if i['filename'].lower().endswith(tuple(self.extensions))]
			for item in my_links:
				filename = item['filename']
				if not self._file_matches(filename, folder_matched=False): continue
				self._append_scrape_result({'l': item['link'], 's': item['size'], 'n': filename})
		except: pass

	def _scrape_cloud(self):
		"""Scrape cloud files with folder-gated loose matching for episodes.
		
		Workflow:
		1. Detect show-matched folders (folder_matches returns True)
		2. For files in matched folders: pass folder_matched=True to enable ep-title override
		3. For files not in matched folders: pass folder_matched=False for stricter checks
		"""
		try:
			try:
				my_cloud_files = self.AllDebrid.user_cloud()['magnets']
				my_cloud_files = [i for i in my_cloud_files if i['statusCode'] == 4]
			except: return self.sources
			threads = []
			append = threads.append
			for item in my_cloud_files:
				folder_name = item.get('filename') or ''
				folder_matched = self._folder_matches(folder_name)
				if not folder_matched and self.filter_title:
					# Folder doesn't match: check year for movies
					if self.media_type == 'movie':
						normalized = normalize(folder_name)
						if normalized and not any(x in normalized for x in self._year_query_list()):
							source_utils.diag_log('AD FolderGate', 'REJECT (movie year) folder=%r' % folder_name)
							continue
				folder_id = item.get('id')
				if folder_id:
					source_utils.diag_log('AD FolderGate', 'enter folder=%r matched=%s' % (folder_name, folder_matched))
					self.folder_results.append((folder_id, folder_matched))
			source_utils.diag_log('AD FolderGate', 'folders accepted=%d of %d' % (len(self.folder_results), len(my_cloud_files)))
			if not self.folder_results: return self.sources
			for folder_id, folder_matched in self.folder_results:
				append(Thread(target=self._scrape_folders, args=(folder_id, folder_matched)))
			[i.start() for i in threads]
			[i.join() for i in threads]
		except: pass

	def _scrape_folders(self, folder_id, folder_matched=False):
		"""Process files inside a folder with folder-context-aware matching.
		
		When folder_matched=True (folder name matches show title):
		- For episodes: accept via S#E# tokens OR episode-title tokens (loose override)
		
		When folder_matched=False (folder name doesn't match):
		- Apply stricter checks (require show title + episode)
		
		Args:
			folder_id: Folder ID to scan
			folder_matched: Whether folder name matched show title
		"""
		try:
			if isinstance(folder_id, dict):
				folder_id = folder_id.get('id')
			if not folder_id: return
			links = self.AllDebrid.cloud_file_links(folder_id)
			links = [i for i in links if i.get('n', '').lower().endswith(tuple(self.extensions)) and i.get('l')]
			for item in links:
				# Use unified wrapper which handles folder gating and episode overrides
				if not source_utils.should_accept_file_title(
					self.title, item['n'], self.aliases, self.year, self.season, self.episode,
					ep_name=self.ep_name,
					absolute_episode=self.absolute_episode,
					in_cloud_folder=folder_matched,
					is_recovery_pass=False,
					filter_title=self.filter_title
				):
					source_utils.diag_log('AD FolderContents', 'file REJECT folder_id=%s file=%r matched=%s' % (folder_id, item.get('n'), folder_matched))
					continue
				source_utils.diag_log('AD FolderContents', 'file ACCEPT file=%r matched=%s' % (item.get('n'), folder_matched))
				item['folder_id'] = folder_id  # lets autoplay-next-episode stay inside this cloud folder
				self._append_scrape_result(item)
		except: return

	# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
	def _apply_title_token_recovery(self):
		"""Recovery pass: use title-token override to catch any missed episodes.
		
		This is a redundancy check that runs after standard matching.
		Files that passed standard matching are NOT re-processed.
		This only catches files that would have been rejected by standard matching
		but have valid episode-title tokens.
		
		For AllDebrid, we re-scan cloud folders that were already matched,
		looking for files with episode-title tokens.
		
		Set to run only for episodes when ep_name is available.
		"""
		if self.media_type != 'episode' or not self.ep_name:
			return
		
		try:
			# Track already-added files to avoid duplicates
			existing_names = {self._dedupe_key(d['n']) for d in self.scrape_results}
			
			try:
				my_cloud_files = self.AllDebrid.user_cloud()['magnets']
				my_cloud_files = [i for i in my_cloud_files if i['statusCode'] == 4]
			except:
				return
			
			for item in my_cloud_files:
				folder_name = item.get('filename') or ''
				# Only re-scan folders that previously matched the show title
				if not self._folder_matches(folder_name):
					continue
				
				folder_id = item.get('id')
				if not folder_id:
					continue
				
				try:
					links = self.AllDebrid.cloud_file_links(folder_id)
					links = [i for i in links if i.get('n', '').lower().endswith(tuple(self.extensions)) and i.get('l')]
					
					for link_item in links:
						# Skip if already in results
						if self._dedupe_key(link_item.get('n', '')) in existing_names:
							continue
						
						# Try recovery pass using unified wrapper (episode-title tokens only)
						if source_utils.should_accept_file_title(
							self.title, link_item['n'], self.aliases, self.year, self.season, self.episode,
							ep_name=self.ep_name,
							in_cloud_folder=True,
							is_recovery_pass=True,  # Recovery mode: ONLY ep-title tokens
							filter_title=False
						):
							source_utils.diag_log('AD CloudMatch', 'RECOVERY add: %r' % link_item.get('n'))
							self._append_scrape_result(link_item)
							existing_names.add(self._dedupe_key(link_item.get('n', '')))
				except:
					continue
		except:
			pass
	# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====

	def _year_query_list(self):
		return (str(self.year), str(self.year+1), str(self.year-1))
