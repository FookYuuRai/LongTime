# -*- coding: utf-8 -*-
import re

from apis.real_debrid_api import RealDebrid
from modules import source_utils
from threading import Thread
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name
from modules.kodi_utils import logger

# NOTE:
# RELEASE_FILTER_RE / passes_release_filter / release_filter_reason live in
# modules/source_utils.py and are called as source_utils.* throughout this file.
# Do NOT redefine them here — a local definition would shadow the shared one.

class source:
	def __init__(self):
		self.scrape_provider = 'rd_cloud'
		self.sources = []
		self.extensions = source_utils.supported_video_extensions()

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not enabled_debrids_check('rd'):
				return source_utils.internal_results(
					self.scrape_provider,
					self.sources
				)

			self.folder_results = []
			self.scrape_results = []

			filter_title = filter_by_name(self.scrape_provider)

			self.media_type = info.get('media_type')
			title = info.get('title')
			self.tmdb_id = info.get('tmdb_id')

			try:
				self.year = int(info.get('year') or 0)
			except:
				self.year = 0

			self.season = info.get('season')
			self.episode = info.get('episode')
			self.absolute_episode = info.get('absolute_episode')

			self.aliases = source_utils.get_aliases_titles(
				info.get('aliases', [])
			)

			self.title = title
			self.ep_name = info.get('ep_name', '')

			self.folder_query = source_utils.clean_title(
				normalize(title)
			)

			self.folder_queries = source_utils.folder_title_queries(
				title,
				self.aliases
			)

			self._scrape_downloads()
			self._scrape_cloud()

			# TITLE-TOKEN OVERRIDE RECOVERY PASS
			self._apply_title_token_recovery()

			if not self.scrape_results:
				return source_utils.internal_results(
					self.scrape_provider,
					self.sources
				)

			aliases = self.aliases

			def _process():
				for item in self.scrape_results:
					try:
						# Final safety check before source creation.
						if not source_utils.passes_release_filter(
							item.get('path', '')
						):
							source_utils.diag_log(
								'RD ReleaseFilter',
								'FINAL REJECT (path) provider=%s path=%r '
								'token=%r (reappeared after earlier filters — investigate)' %
								(
									self.scrape_provider,
									item.get('path', ''),
									source_utils.release_filter_reason(
										item.get('path', '')
									)
								)
							)

							continue

						file_name = self._get_filename(item['path'])

						if not source_utils.passes_release_filter(file_name):
							source_utils.diag_log(
								'RD ReleaseFilter',
								'FINAL REJECT (filename) provider=%s '
								'path=%r filename=%r token=%r' %
								(
									self.scrape_provider,
									item.get('path', ''),
									file_name,
									source_utils.release_filter_reason(file_name)
								)
							)

							continue

						if self.media_type == 'episode':
							if not source_utils.should_accept_file_title(
								title,
								file_name,
								aliases,
								self.year,
								self.season,
								self.episode,
								ep_name=self.ep_name,
								absolute_episode=self.absolute_episode,
								in_cloud_folder=True,
								is_recovery_pass=False,
								filter_title=False
							):
								continue

						elif not source_utils.should_accept_file_title(
							title,
							file_name,
							aliases,
							self.year,
							self.season,
							self.episode,
							ep_name=None,
							in_cloud_folder=True,
							filter_title=False
						):
							continue

						display_name = clean_file_name(file_name)
						display_name = display_name.replace('html', ' ')
						display_name = display_name.replace('+', ' ')
						display_name = display_name.replace('-', ' ')

						file_dl = item['url_link']
						size = round(
							float(item['bytes']) / 1073741824,
							2
						)

						video_quality, details = source_utils.get_file_info(
							name_info=source_utils.release_info_format(
								file_name
							)
						)

						direct_debrid_link = item.get(
							'direct_debrid_link',
							False
						)

						folder_id = item.get('folder_id', '')
						cache_type = item.get('cache_type', '')

						source_item = {
							'name': file_name,
							'display_name': display_name,
							'quality': video_quality,
							'size': size,
							'size_label': '%.2f GB' % size,
							'extraInfo': details,
							'url_dl': file_dl,
							'id': file_dl,
							'downloads': False,
							'direct': True,
							'source': self.scrape_provider,
							'debrid': self.scrape_provider,
							'scrape_provider': self.scrape_provider,
							'direct_debrid_link': direct_debrid_link,
							'folder_id': folder_id,
							'cache_type': cache_type
						}

						yield source_item

					except:
						pass

			self.sources = list(_process())

		except Exception as e:
			logger(
				'RD scraper Exception',
				str(e)
			)

		source_utils.internal_results(
			self.scrape_provider,
			self.sources
		)

		return self.sources

	def _scrape_cloud(self):
		"""
		Scrape cloud folders.

		The release filter is applied to individual files in
		_scrape_folders(), immediately after the selected files are known.
		Folder names themselves are NOT release-filtered — the filter
		applies to files, not folders.
		"""
		try:
			try:
				my_cloud_files = RealDebrid.user_cloud()

				my_cloud_files = [
					i for i in my_cloud_files
					if i['status'] == 'downloaded'
				]

			except:
				return self.sources

			results_append = self.folder_results.append
			year_query_list = self._year_query_list()

			for item in my_cloud_files:
				normalized = normalize(item['filename'])
				folder_name = source_utils.clean_title(normalized)

				if not folder_name:
					source_utils.diag_log(
						'RD FolderGate',
						'accept (empty name) id=%s name=%r' %
						(
							item['id'],
							item['filename']
						)
					)

					results_append(item['id'])

				elif not any(q and q in folder_name for q in self.folder_queries):
					if not (
						self.media_type == 'episode'
						and self.ep_name
						and source_utils.episode_title_in_release(self.ep_name, normalized)
					):
						source_utils.diag_log(
							'RD FolderGate',
							'REJECT id=%s name=%r '
							'(no query in cleaned=%r, queries=%r)' %
							(
								item['id'],
								item['filename'],
								folder_name,
								self.folder_queries
							)
						)

						continue

					source_utils.diag_log(
						'RD FolderGate',
						'accept (ep-name rescue) id=%s name=%r' %
						(
							item['id'],
							item['filename']
						)
					)

					results_append(item['id'])

				else:
					if (
						self.media_type == 'movie'
						and not any(
							x in normalized
							for x in year_query_list
						)
					):
						source_utils.diag_log(
							'RD FolderGate',
							'REJECT (movie year) id=%s name=%r' %
							(
								item['id'],
								item['filename']
							)
						)

						continue

					source_utils.diag_log(
						'RD FolderGate',
						'accept (title match) id=%s name=%r queries=%r' %
						(
							item['id'],
							item['filename'],
							self.folder_queries
						)
					)

					results_append(item['id'])

			if not self.folder_results:
				source_utils.diag_log(
					'RD FolderGate',
					'NO folders accepted — nothing to list, file can never be seen'
				)

				return self.sources

			threads = []
			threads_append = threads.append

			for folder_id in self.folder_results:
				threads_append(
					Thread(
						target=self._scrape_folders,
						args=(folder_id,)
					)
				)

			[i.start() for i in threads]
			[i.join() for i in threads]

		except:
			pass

	def _scrape_folders(self, folder_info):
		"""
		Process files inside a Real-Debrid folder.

		The release filter is applied immediately after selected files are
		known, before extension filtering or episode/title matching.

		The selected list must remain intact while links are mapped because
		Real-Debrid links align with the complete selected-file list.
		"""
		try:
			folder_files = RealDebrid.user_cloud_info(folder_info)

			raw_files = folder_files.get('files') or []
			file_urls = folder_files.get('links') or []

			source_utils.diag_log(
				'RD FolderContents',
				'folder=%s raw files=%d links=%d' %
				(
					folder_info,
					len(raw_files),
					len(file_urls)
				)
			)

			for raw_file in raw_files:
				source_utils.diag_log(
					'RD FolderContents',
					'  raw: selected=%r id=%s path=%r' %
					(
						raw_file.get('selected'),
						raw_file.get('id'),
						raw_file.get('path')
					)
				)

			# Keep all selected files so Real-Debrid link positions stay aligned.
			selected = [
				i for i in raw_files
				if i.get('selected') == 1
			]

			# --- RELEASE FILTER (primary pass) ------------------------------
			release_rejected = [
				i for i in selected
				if not source_utils.passes_release_filter(
					i.get('path', '')
				)
			]

			for item in release_rejected:
				source_utils.diag_log(
					'RD ReleaseFilter',
					'REJECT (folder) folder=%s path=%r token=%r' %
					(
						folder_info,
						item.get('path', ''),
						source_utils.release_filter_reason(
							item.get('path', '')
						)
					)
				)

			release_passed = [
				i for i in selected
				if source_utils.passes_release_filter(
					i.get('path', '')
				)
			]

			source_utils.diag_log(
				'RD ReleaseFilter',
				'folder=%s release filter: %d passed, %d rejected '
				'(of %d selected)' %
				(
					folder_info,
					len(release_passed),
					len(release_rejected),
					len(selected)
				)
			)
			# -----------------------------------------------------------------

			link_map = {}

			try:
				for idx, link in enumerate(file_urls):
					if idx < len(selected):
						link_map[selected[idx].get('id')] = link
			except Exception:
				pass

			# Extension filtering happens after the release filter.
			contents = [
				i for i in release_passed
				if i.get('path', '').lower().endswith(
					tuple(self.extensions)
				)
			]

			ext_rejected_count = len(release_passed) - len(contents)

			source_utils.diag_log(
				'RD FolderContents',
				'folder=%s after release+extension filter: %d files '
				'(%d rejected by extension)' %
				(
					folder_info,
					len(contents),
					ext_rejected_count
				)
			)

			scrape_results_append = self.scrape_results.append

			for item in contents:
				# Defensive release filter before URL assignment and matching.
				# Should never trigger (primary pass already ran); log loudly
				# if it does, since that indicates an ordering problem.
				if not source_utils.passes_release_filter(
					item.get('path', '')
				):
					source_utils.diag_log(
						'RD ReleaseFilter',
						'DEFENSIVE REJECT (folder loop) folder=%s path=%r '
						'token=%r (should have been caught in primary pass!)' %
						(
							folder_info,
							item.get('path', ''),
							source_utils.release_filter_reason(
								item.get('path', '')
							)
						)
					)

					continue

				if not item.get('url_link'):
					pos = selected.index(item) if item in selected else -1

					if 0 <= pos < len(file_urls):
						item.update({
							'url_link': file_urls[pos]
						})

				if not item.get('url_link'):
					item.update({
						'url_link': link_map.get(
							item.get('id'),
							''
						)
					})

			contents.sort(
				key=lambda k: k['path']
			)

			for item in contents:
				# Final early release-name check before episode matching.
				# Same situation as the defensive check above — the primary
				# pass already ran. Log loudly if this ever fires.
				if not source_utils.passes_release_filter(
					item.get('path', '')
				):
					source_utils.diag_log(
						'RD ReleaseFilter',
						'DEFENSIVE REJECT (pre-match) folder=%s path=%r '
						'token=%r (should have been caught in primary pass!)' %
						(
							folder_info,
							item.get('path', ''),
							source_utils.release_filter_reason(
								item.get('path', '')
							)
						)
					)

					continue

				normalized = normalize(item['path'])

				if self.media_type == 'episode':
					modes = source_utils.cloud_episode_matches_all(
						self.season,
						self.episode,
						normalized,
						self.absolute_episode,
						self.ep_name
					)

					accepted = source_utils.should_accept_file_title(
						self.title,
						normalized,
						self.aliases,
						self.year,
						self.season,
						self.episode,
						ep_name=self.ep_name,
						absolute_episode=self.absolute_episode,
						in_cloud_folder=True,
						is_recovery_pass=False,
						filter_title=False
					)

					if not accepted:
						source_utils.diag_log(
							'RD FolderContents',
							'file REJECT path=%r abs=%s ep_name=%r '
							'modes=%s (no token/bare/ep-name match)' %
							(
								normalized,
								self.absolute_episode,
								self.ep_name,
								modes or '[]'
							)
						)

						continue

					source_utils.diag_log(
						'RD FolderContents',
						'file ACCEPT path=%r abs=%s modes=%s url_link=%s' %
						(
							normalized,
							self.absolute_episode,
							modes or 'ep-name-override',
							bool(item.get('url_link'))
						)
					)

				if item['path'].replace('/', '').lower() not in [
					d['path'].replace('/', '').lower()
					for d in self.scrape_results
				]:
					item.update({
						'folder_id': folder_info,
						'cache_type': 'torrent'
					})

					scrape_results_append(item)

		except Exception as e:
			try:
				logger(
					'RD FolderContents',
					'folder %s error: %s' %
					(
						folder_info,
						e
					)
				)
			except:
				pass

	def _scrape_downloads(self):
		"""
		Scrape download history.

		The release filter is applied immediately after the downloads API
		returns, before extension, title, year, season, or episode checks.
		"""
		try:
			my_downloads = RealDebrid.downloads()

			# --- RELEASE FILTER (primary pass) ------------------------------
			release_passed = [
				i for i in my_downloads
				if source_utils.passes_release_filter(
					i.get('filename', '')
				)
			]

			for item in my_downloads:
				if not source_utils.passes_release_filter(
					item.get('filename', '')
				):
					source_utils.diag_log(
						'RD ReleaseFilter',
						'REJECT (downloads) filename=%r token=%r' %
						(
							item.get('filename', ''),
							source_utils.release_filter_reason(
								item.get('filename', '')
							)
						)
					)

			source_utils.diag_log(
				'RD ReleaseFilter',
				'downloads release filter: %d passed, %d rejected '
				'(of %d total)' %
				(
					len(release_passed),
					len(my_downloads) - len(release_passed),
					len(my_downloads)
				)
			)
			# -----------------------------------------------------------------

			# Extension filter is applied after the release filter.
			my_downloads = [
				i for i in release_passed
				if i.get('download', '').lower().endswith(
					tuple(self.extensions)
				)
			]

			scrape_results_append = self.scrape_results.append
			year_query_list = self._year_query_list()

			source_utils.diag_log(
				'RD FolderGate',
				'Downloads after release+extension filter: %d candidates' %
				len(my_downloads)
			)

			for item in my_downloads:
				# Defensive check before title matching.
				if not source_utils.passes_release_filter(
					item.get('filename', '')
				):
					source_utils.diag_log(
						'RD ReleaseFilter',
						'DEFENSIVE REJECT (downloads loop) filename=%r '
						'token=%r (should have been caught in primary pass!)' %
						(
							item.get('filename', ''),
							source_utils.release_filter_reason(
								item.get('filename', '')
							)
						)
					)

					continue

				normalized = normalize(item['filename'])
				folder_name = source_utils.clean_title(normalized)

				if not any(q and q in folder_name for q in self.folder_queries):
					source_utils.diag_log(
						'RD FolderGate',
						'RD Cloud REJECT (title gate) name=%r '
						'cleaned=%r queries=%r' %
						(
							item['filename'],
							folder_name,
							self.folder_queries
						)
					)

					continue

				if self.media_type == 'movie':
					if not any(
						x in normalized
						for x in year_query_list
					):
						source_utils.diag_log(
							'RD FolderGate',
							'RD Cloud REJECT (movie year) name=%r' %
							item['filename']
						)

						continue

				elif self.media_type == 'episode':
					if not source_utils.should_accept_file_title(
						self.title,
						normalized,
						self.aliases,
						self.year,
						self.season,
						self.episode,
						ep_name=self.ep_name,
						absolute_episode=self.absolute_episode,
						in_cloud_folder=True,
						is_recovery_pass=False,
						filter_title=False
					):
						source_utils.diag_log(
							'RD FolderGate',
							'RD Cloud REJECT (S/E match) name=%r' %
							item['filename']
						)

						continue

				item = self.make_downloads_item(item)

				if item['path'].replace('/', '').lower() not in [
					d['path'].replace('/', '').lower()
					for d in self.scrape_results
				]:
					source_utils.diag_log(
						'RD FolderGate',
						'RD Cloud ACCEPT name=%r' %
						item['path']
					)

					scrape_results_append(item)

		except:
			pass

	def _apply_title_token_recovery(self):
		"""
		Recovery pass using episode-title tokens only.

		The release filter is applied immediately after the downloads API
		returns, before recovery matching.
		"""
		if self.media_type != 'episode' or not self.ep_name:
			return

		try:
			existing_paths = {
				d['path'].replace('/', '').lower()
				for d in self.scrape_results
			}

			try:
				my_downloads = RealDebrid.downloads()

				# --- RELEASE FILTER (primary pass) --------------------------
				release_passed = [
					i for i in my_downloads
					if source_utils.passes_release_filter(
						i.get('filename', '')
					)
				]

				for item in my_downloads:
					if not source_utils.passes_release_filter(
						item.get('filename', '')
					):
						source_utils.diag_log(
							'RD ReleaseFilter',
							'REJECT (recovery) filename=%r token=%r' %
							(
								item.get('filename', ''),
								source_utils.release_filter_reason(
									item.get('filename', '')
								)
							)
						)
				# -------------------------------------------------------------

				# Extension filter is applied after the release filter.
				my_downloads = [
					i for i in release_passed
					if i.get('download', '').lower().endswith(
						tuple(self.extensions)
					)
				]

			except:
				return

			scrape_results_append = self.scrape_results.append

			for item in my_downloads:
				# Defensive check before recovery matching.
				if not source_utils.passes_release_filter(
					item.get('filename', '')
				):
					source_utils.diag_log(
						'RD ReleaseFilter',
						'DEFENSIVE REJECT (recovery loop) filename=%r '
						'token=%r (should have been caught in primary pass!)' %
						(
							item.get('filename', ''),
							source_utils.release_filter_reason(
								item.get('filename', '')
							)
						)
					)

					continue

				if item['filename'].replace('/', '').lower() in existing_paths:
					continue

				normalized = normalize(item['filename'])
				folder_name = source_utils.clean_title(normalized)

				if not any(q and q in folder_name for q in self.folder_queries):
					continue

				if source_utils.should_accept_file_title(
					self.title,
					normalized,
					self.aliases,
					self.year,
					self.season,
					self.episode,
					ep_name=self.ep_name,
					absolute_episode=self.absolute_episode,
					in_cloud_folder=True,
					is_recovery_pass=True,
					filter_title=False
				):
					source_utils.diag_log(
						'RD CloudMatch',
						'RECOVERY add: %r' % normalized
					)

					item_obj = self.make_downloads_item(item)
					scrape_results_append(item_obj)

					existing_paths.add(
						normalized.replace('/', '').lower()
					)

		except:
			pass

	def make_downloads_item(self, item):
		return {
			'url_link': item['download'],
			'bytes': item['filesize'],
			'path': item['filename'],
			'folder_id': item['id'],
			'cache_type': 'download',
			'direct_debrid_link': True
		}

	def _get_filename(self, name):
		if name.startswith('/'):
			name = name.split('/')[-1]

		return normalize(name)

	def _year_query_list(self):
		return (
			str(self.year),
			str(self.year + 1),
			str(self.year - 1)
		)
