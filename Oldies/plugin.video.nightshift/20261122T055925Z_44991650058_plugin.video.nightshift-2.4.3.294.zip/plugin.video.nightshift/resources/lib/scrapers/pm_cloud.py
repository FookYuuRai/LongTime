# -*- coding: utf-8 -*-
import time
from apis.premiumize_api import Premiumize
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name
from caches.settings_cache import get_setting
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'pm_cloud'
		self.sources, self.scrape_results = [], []
		self.extensions = source_utils.supported_video_extensions()
		self._folder_queue = []
		self._folders_scanned = 0
		self._max_folder_scans = 24
		self._listall_reserve_seconds = 8

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not enabled_debrids_check('pm'): return source_utils.internal_results(self.scrape_provider, self.sources)
			self.filter_title = filter_by_name(self.scrape_provider)
			self.media_type, title = info.get('media_type'), info.get('title')
			try: self.year = int(info.get('year') or 0)
			except: self.year = 0
			self.season, self.episode = info.get('season'), info.get('episode')
			self.absolute_episode = info.get('absolute_episode')
			self.ep_name = info.get('ep_name', '')  # Episode name for title-token override
			self.folder_query = source_utils.clean_title(normalize(title))
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.title_queries = self._title_queries()
			self.title = title
			self.scrape_deadline = time.time() + min(25, max(10, int(get_setting('nightshift.results.timeout', '20'))))
			self._scrape_cloud()
			# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			# Must run BEFORE the early return and BEFORE _process(), so files it
			# rescues into scrape_results actually get processed into sources.
			self._apply_title_token_recovery()
			# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			if not self.scrape_results: return source_utils.internal_results(self.scrape_provider, self.sources)
			def _process():
				for item in self.scrape_results:
					try:
						file_name = self._item_label(item)
						if self.media_type == 'episode':
							file_only = normalize(item.get('name') or '')
							if not source_utils.should_accept_file_title(
								self.title, file_only, self.aliases, self.year, self.season, self.episode,
								ep_name=self.ep_name,
								absolute_episode=self.absolute_episode,
								in_cloud_folder=True,
								is_recovery_pass=False,
								filter_title=False  # Cloud folders always bypass filter_title
							): continue
						elif not source_utils.should_accept_file_title(
							self.title, file_name, self.aliases, self.year, self.season, self.episode,
							ep_name=None,
							in_cloud_folder=True,
							is_recovery_pass=False,
							filter_title=False  # Cloud folders always bypass filter_title
						): continue
						display_name = clean_file_name(normalize(item.get('name') or file_name)).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						file_dl = item['id']
						size = round(float(item.get('size') or 0)/1073741824, 2)
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name))
						source_item = {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size, 'size_label': '%.2f GB' % size,
									'debrid': self.scrape_provider, 'extraInfo': details, 'url_dl': file_dl, 'id': file_dl, 'downloads': False, 'direct': True,
									'source': self.scrape_provider, 'scrape_provider': self.scrape_provider}
						# folder the file lives in (lets autoplay-next-episode stay inside this cloud folder)
						_p = str(item.get('path') or '').replace('\\', '/')
						source_item['folder_path'] = _p.rsplit('/', 1)[0] if '/' in _p else ''
						yield source_item
					except: pass
			self.sources = list(_process())
		except Exception as e:
			logger('PM scraper Exception', str(e))
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _title_queries(self):
		queries = set()
		if self.folder_query: queries.add(self.folder_query)
		for candidate in list(self.aliases or []):
			if not candidate: continue
			query = source_utils.clean_title(normalize(candidate))
			if not query: continue
			# ###FIX### degenerate-query guard — CJK aliases collapse to '', '&', '()'
			# after ASCII normalization + clean_title; a 1-2 char or non-alphanumeric
			# query matches almost anything as a substring (cross-show contamination).
			if len(query) < 3 or not any(c.isalnum() for c in query): continue
			queries.add(query)
		return queries

	def _item_label(self, item):
		path, name = (item.get('path') or '').strip(), (item.get('name') or '').strip()
		if path and name and not path.rstrip('/').endswith(name):
			return normalize('%s %s' % (path.replace('/', ' '), name))
		return normalize(path or name)

	def _list_folder(self, folder_id):
		"""Folder/list during scrape; bounded timeout so one slow call cannot eat the whole search."""
		if time.time() > self.scrape_deadline - 3:
			return []
		try:
			url = 'folder/list?id=%s' % folder_id if folder_id else 'folder/list'
			try:
				response = Premiumize._get(url, timeout=10)
			except TypeError:
				response = Premiumize._get(url)
			if not isinstance(response, dict) or str(response.get('status', '')).lower() != 'success':
				return []
			return response.get('content') or []
		except: return []

	def _is_video_file(self, item):
		link = (item.get('link') or '').lower()
		if link and link.endswith(tuple(self.extensions)): return True
		name = (item.get('name') or '').lower()
		return name.endswith(tuple(self.extensions))

	def _matches_title(self, label):
		if not self.title_queries: return True
		folder_name = source_utils.clean_title(label)
		# ###FIX### belt-and-braces: a degenerate query can never fire here even if one
		# slips into the list — min length 3 and must contain alphanumeric chars.
		return any(len(q) >= 3 and q in folder_name for q in self.title_queries)

	def _folder_entry_kind(self, name, path):
		"""'title' = folder name proves the show; 'ep-name' = episode-title rescue only; None = no proof."""
		label = normalize('%s %s' % (path, name))
		if self._matches_title(label): return 'title'
		if self.ep_name and source_utils.episode_title_in_release(self.ep_name, label): return 'ep-name'
		return None

	def _has_media_hint(self, label):
		if self.media_type == 'movie':
			return bool(self.year and str(self.year) in label)
		return source_utils.seas_ep_filter_exact(self.season, self.episode, label)

	def _should_enter_folder(self, name, path, depth, parent_verified):
		"""GATE SEMANTICS (returns (entered, title_proof)):
		- Depth-0 folders: entered ONLY on title match (or ep-name rescue).
		- Subfolders: descended ONLY inside a matched branch (parent title-verified),
		  so generic names like 'Season 1' work without carrying the title.
		- ep-name rescue ALWAYS opens a folder, but marks it UNVERIFIED — trust
		  must come from the TITLE, never from an episode-title match.
		Returns: (entered, title_proved) — title_proved is True ONLY on a real
		title match (parent inheritance does not create a new proof root).
		"""
		if time.time() > self.scrape_deadline: return False, None
		label = normalize('%s %s' % (path, name))
		kind = self._folder_entry_kind(name, path)
		# ep-name override ALWAYS opens the folder — but never as a verified branch
		if kind == 'ep-name':
			source_utils.diag_log('PM FolderGate', 'enter (ep-name rescue, UNVERIFIED subtree) depth=%s name=%r' % (depth, name))
			return True, None
		if kind == 'title':
			source_utils.diag_log('PM FolderGate', 'enter (title match) depth=%s name=%r folder_clean=%r queries=%r' % (
				depth, name, source_utils.clean_title(label), sorted(self.title_queries)))
			return True, True
		# Subfolders of a TITLE-verified branch inherit ('Season 1', disc dirs, etc.)
		if parent_verified:
			source_utils.diag_log('PM FolderGate', 'enter (parent verified) depth=%s name=%r' % (depth, name))
			return True, True
		source_utils.diag_log('PM FolderGate', 'SKIP folder depth=%s name=%r path=%r (no proof, parent unverified, queries=%r)' % (
			depth, name, path, sorted(self.title_queries)))
		return False, None

	def _file_passes(self, label, filename=None, folder_matched=True):
		"""STRONGER episode matching - require stronger match."""
		normalized = normalize(filename or label)
		
		# 1. ep-name override ALWAYS accepts
		if self.media_type == 'episode' and self.ep_name and \
				source_utils.episode_title_in_release(self.ep_name, normalized):
			source_utils.diag_log('PM FolderContents', 'file PASS (ep-name) label=%r' % label)
			return True
		
		# 2. Check for absolute_episode match
		has_abs = self.absolute_episode and str(self.absolute_episode) in normalized
		
		# 3. Check for S#E# exact match
		has_se = source_utils.seas_ep_filter_exact(self.season, self.episode, normalized)
		
		# 4. Weak bare episode check
		bare_only = False
		if self.media_type == 'episode' and not has_abs and not has_se:
			bare_only = any(x in normalized for x in [
				'-%s-' % self.episode, ' -%s ' % self.episode,
				'%s.' % self.episode, '%s_' % self.episode
			])
		
		# Reject bare-only matches
		if bare_only:
			source_utils.diag_log('PM FolderGate', 'file REJECT (bare episode only) label=%r' % label)
			return False
		
		if not folder_matched and not self._matches_title(label):
			source_utils.diag_log('PM FolderGate', 'file REJECT (unverified) label=%r' % label)
			return False
		if self.filter_title and not self._matches_title(label):
			source_utils.diag_log('PM FolderGate', 'file REJECT (title) label=%r' % label)
			return False
		if self.media_type == 'movie':
			if self.year and not any(x in label for x in self._year_query_list()):
				source_utils.diag_log('PM FolderGate', 'file REJECT (year) label=%r' % label)
				return False
		if not source_utils.should_accept_file_title(
			self.title, normalized, self.aliases, self.year, self.season, self.episode,
			ep_name=self.ep_name,
			absolute_episode=self.absolute_episode,
			in_cloud_folder=True,
			is_recovery_pass=False,
			filter_title=False
		):
			source_utils.diag_log('PM FolderGate', 'file REJECT (S/E match) label=%r' % label)
			return False
		return True

	def _scrape_cloud(self):
		# Queue entries: (folder_id, path_prefix, depth, verified)
		# Root starts UNVERIFIED — root files must prove title themselves;
		# depth-0 folders are entered only on title match and then verified.
		self._folder_queue = [(None, '', 0, False)]
		self._folders_scanned = 0
		walk_deadline = self.scrape_deadline - self._listall_reserve_seconds
		while self._folder_queue and time.time() < walk_deadline and self._folders_scanned < self._max_folder_scans:
			folder_id, path_prefix, depth, folder_matched = self._folder_queue.pop(0)
			source_utils.diag_log('PM FolderWalk', 'scanning folder_id=%r path=%r depth=%s verified=%s (queue=%d scanned=%d)' % (
				folder_id, path_prefix, depth, folder_matched, len(self._folder_queue), self._folders_scanned))
			self._scan_folder(folder_id, path_prefix, depth, folder_matched)
		if self._folder_queue and self._folders_scanned >= self._max_folder_scans:
			source_utils.diag_log('PM FolderWalk', 'STOPPED: max folder scans reached (%d) — queued folders never opened' % self._max_folder_scans)
		if not self.scrape_results and time.time() < self.scrape_deadline:
			source_utils.diag_log('PM FolderWalk', 'walk found nothing — falling back to listall')
			self._scrape_cloud_listall()

	def _scan_folder(self, folder_id, path_prefix, depth, folder_matched):
		self._folders_scanned += 1
		try:
			content = self._list_folder(folder_id)
		except: return
		# FOLDERCONTENTS: raw listing BEFORE any filtering — one line per item PM reports
		source_utils.diag_log('PM FolderContents', 'folder=%r verified=%s raw items=%d' % (
			path_prefix or '(root)', folder_matched, len(content)))
		for rf in content:
			if isinstance(rf, dict):
				source_utils.diag_log('PM FolderContents', '  raw: id=%s type=%r name=%r link=%r' % (
					rf.get('id'), rf.get('type'), rf.get('name'), bool(rf.get('link'))))
		append_result = self.scrape_results.append
		for item in content:
			if time.time() > self.scrape_deadline: return
			if not isinstance(item, dict): continue
			name = (item.get('name') or '').strip()
			if not name: continue
			child_path = '%s/%s' % (path_prefix, name) if path_prefix else name
			if item.get('type') == 'folder':
				entered, child_proof = self._should_enter_folder(name, child_path, depth, folder_matched)
				if entered:
					# Only a TITLE-proved folder propagates verification; ep-name-rescued
					# subtrees stay unverified — files inside must prove the show themselves.
					child_verified = True if child_proof else folder_matched
					self._folder_queue.append((item.get('id'), child_path, depth + 1, child_verified))
				continue
			if not self._is_video_file(item):
				source_utils.diag_log('PM FolderContents', '  drop (not video/ext): name=%r' % name)
				continue
			file_item = {'id': item.get('id'), 'name': name, 'size': item.get('size') or 0, 'path': child_path}
			label = self._item_label(file_item)
			if not self._file_passes(label, name, folder_matched): continue
			source_utils.diag_log('PM FolderContents', '  ACCEPT: name=%r path=%r verified=%s' % (name, child_path, folder_matched))
			append_result(file_item)

	def _scrape_cloud_listall(self):
		"""Fallback when folder walk finds nothing (flat API)."""
		if time.time() > self.scrape_deadline - 2:
			return
		try:
			try:
				response = Premiumize.user_cloud_all(timeout=12)
			except TypeError:
				response = Premiumize.user_cloud_all()
			if not isinstance(response, dict) or str(response.get('status', '')).lower() != 'success':
				return
			cloud_files = response.get('files') or []
			cloud_files = [i for i in cloud_files if isinstance(i, dict) and self._is_video_file(i)]
		except: return
		append = self.scrape_results.append
		source_utils.diag_log('PM FolderWalk', 'listall: %d video files reported' % len(cloud_files))
		for item in cloud_files:
			if time.time() > self.scrape_deadline: break
			label = self._item_label(item)
			# Flat items: verify title from the full path label ourselves
			if not self._file_passes(label, item.get('name'), self._matches_title(label)): continue
			source_utils.diag_log('PM FolderWalk', 'listall ACCEPT: %r' % label)
			append(item)

	# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
	# Fallback pass using should_accept_file_title() with recovery mode to catch missed files.
	# Comment out entire block to disable and test if removal is needed.
	def _apply_title_token_recovery(self):
		"""Recovery pass: episode-title tokens only, from the flat cloud API.

		Runs after standard matching; files already matched are skipped.
		Gate: label must carry show title OR ep-name tokens (override always).
		"""
		if self.media_type != 'episode' or not self.ep_name:
			return

		if time.time() > self.scrape_deadline - 2:
			return

		try:
			existing_ids = {d['id'] for d in self.scrape_results}

			try:
				response = Premiumize.user_cloud_all(timeout=12)
			except TypeError:
				response = Premiumize.user_cloud_all()

			if not isinstance(response, dict) or str(response.get('status', '')).lower() != 'success':
				return

			cloud_files = response.get('files') or []
			cloud_files = [i for i in cloud_files if isinstance(i, dict) and self._is_video_file(i)]

			append_result = self.scrape_results.append
			for item in cloud_files:
				if time.time() > self.scrape_deadline:
					break

				if item.get('id') in existing_ids:
					continue

				# Gate: show title in label, or ep-name rescue (override always)
				label = self._item_label(item)
				if not self._matches_title(label) and not (
						self.ep_name and source_utils.episode_title_in_release(self.ep_name, label)):
					continue

				file_name = normalize(item.get('name') or '')
				if source_utils.should_accept_file_title(
					self.title, file_name, self.aliases, self.year, self.season, self.episode,
					ep_name=self.ep_name,
					in_cloud_folder=True,
					is_recovery_pass=True,  # Recovery mode: ONLY ep-title tokens
					filter_title=False
				):
					source_utils.diag_log('PM CloudMatch', 'RECOVERY add: %r' % label)
					append_result(item)
					existing_ids.add(item.get('id'))
		except:
			pass
	# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====

	def _year_query_list(self):
		if not self.year: return ()
		return (str(self.year), str(self.year + 1), str(self.year - 1))