# -*- coding: utf-8 -*-
from threading import Thread
from apis.offcloud_api import Offcloud
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name
# from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'oc_cloud'
		self.sources = []
		self.extensions = source_utils.supported_video_extensions()

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not enabled_debrids_check('oc'): return source_utils.internal_results(self.scrape_provider, self.sources)
			self.folder_results, self.scrape_results = [], []
			self.filter_title = filter_by_name(self.scrape_provider)
			self.media_type, title = info.get('media_type'), info.get('title')
			self.year, self.season, self.episode = int(info.get('year') or 0), info.get('season'), info.get('episode')
			self.absolute_episode = info.get('absolute_episode')
			self.ep_name = info.get('ep_name', '')  # Episode name for title-token override
			self.title = title
			self.folder_query = source_utils.clean_title(normalize(title))
			self.year_query_list = tuple(map(str, range(self.year - 1, self.year + 2)))
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.title_queries = self._title_queries()
			
			# Log absolute episode for diagnostics (episodes only)
			if self.media_type == 'episode' and self.absolute_episode:
				source_utils.diag_log('OC Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					self.season, self.episode, self.absolute_episode, self.ep_name))
			
			self._scrape_cloud()
			# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			self._apply_title_token_recovery()
			# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====
			if not self.scrape_results: return source_utils.internal_results(self.scrape_provider, self.sources)
			
			raw_count = len(self.scrape_results)
			skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'exception': 0}
			
			def _process():
				for item in self.scrape_results:
					try:
						file_name = item['filename']
						
						# RELEASE FILTER CHECK
						# Release filter removed: it is a Real-Debrid-only rule (applied in debrid.stamp_torrent_cache / rd_cloud).
                        
						# Use unified wrapper for cloud-folder matching
						if not source_utils.should_accept_file_title(
							self.title, file_name, self.aliases, self.year, self.season, self.episode,
							ep_name=self.ep_name if self.media_type == 'episode' else None,
							absolute_episode=self.absolute_episode,
							in_cloud_folder=True,
							is_recovery_pass=False,
							filter_title=self.filter_title
						):
							skipped['title_filter'] += 1
							source_utils.diag_log('OC Match', 'file REJECT (title_filter): %r' % file_name)
							continue
						
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						file_dl, size = Offcloud.requote_uri(item['url']), 0
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name))
						source_utils.diag_log('OC Match', 'file ACCEPT: %r' % file_name)
						source_item = {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size, 'size_label': '%.2f GB' % size,
									'extraInfo': details, 'url_dl': file_dl, 'id': file_dl, 'downloads': False, 'direct': True, 'source': self.scrape_provider,
									'debrid': self.scrape_provider, 'scrape_provider': self.scrape_provider, 'direct_debrid_link': True}
						yield source_item
					except Exception:
						skipped['exception'] += 1
			self.sources = list(_process())
			
			source_utils.diag_log('OC Match', '%s : %s kept / %s raw' % (title, len(self.sources), raw_count))
			if raw_count and not self.sources:
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('OC Match', 'all raw results dropped (%s)' % dropped)
			elif any(skipped.values()):
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('OC Match', 'dropped (%s)' % dropped)
		except Exception as e:
			from modules.kodi_utils import logger
			logger('offcloud scraper Exception', e)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _title_queries(self):
		queries = set()
		for candidate in [self.title] + list(self.aliases or []):
			if not candidate:
				continue
			for variant in (candidate, source_utils.normalize(candidate), normalize(candidate)):
				if not variant:
					continue
				query = source_utils.clean_title(variant)
				if query:
					queries.add(query)
		return queries

	def _title_match(self, clean_file, folder_name):
		return any(q and (q in clean_file or (folder_name and q in folder_name)) for q in self.title_queries)

	def _contains_year(self, *texts):
		if not self.year:
			return False
		for text in texts:
			if not text:
				continue
			if any(str(y) in text for y in self.year_query_list):
				return True
		return False

	def _prefilter_folder(self, folder_name, raw_folder):
		"""Pre-filter folders to determine if we should scan inside.
		
		For episodes: folder name should indicate it might contain episodes
		(e.g., show title, season indicator, or S#E# hints).
		"""
		if not folder_name and not raw_folder:
			return False
		if self.media_type == 'movie':
			if not self._title_match('', folder_name):
				return False
			if self.year and not self._contains_year(raw_folder):
				return False
			return True
		if self.folder_query and self.folder_query in folder_name:
			return True
		if any(q and q in folder_name for q in self.title_queries):
			return True
		if source_utils.seas_ep_filter_exact(self.season, self.episode, raw_folder):
			return True
		# Untitled folders: enter on ep-name tokens or the bare absolute episode
		if self.ep_name and source_utils.episode_title_in_release(self.ep_name, normalize(raw_folder or folder_name)):
			return True
		try:
			if self.absolute_episode and int(self.absolute_episode) in set(
					source_utils.iter_bare_episode_numbers(raw_folder or '')): return True
		except Exception: pass
		return self._title_match('', folder_name)

	def _cloud_file_matches(self, normalized, folder_name='', folder_prefiltered=False, ep_name_override=False):
		"""Check if file matches requested media.

		For episodes:
		- If folder_prefiltered=True: can use episode-title token override (loose match)
		- If folder_prefiltered=False: apply stricter matching

		Args:
			normalized: Normalized filename
			folder_name: Folder name (context)
			folder_prefiltered: Whether folder passed pre-filter (enables loose matching)
			ep_name_override: Whether to use episode-title token override
		"""
		# Use unified wrapper that handles cloud-folder gating and title checks
		return source_utils.should_accept_file_title(
			self.title, normalized, self.aliases, self.year, self.season, self.episode,
			ep_name=self.ep_name if ep_name_override else None,
			absolute_episode=self.absolute_episode,
			in_cloud_folder=folder_prefiltered,
			is_recovery_pass=False,
			filter_title=self.filter_title
		)

	def _is_cloud_archive(self, item):
		if item.get('isDirectory'):
			return True
		file_name = (item.get('fileName') or '').lower()
		return not file_name.endswith(tuple(self.extensions))

	def _scrape_cloud(self):
		"""Scrape cloud with folder-context awareness for loose matching.
		
		Workflow:
		1. Pre-filter folders to see if they might contain episodes
		2. For matched folders: pass folder_prefiltered=True to enable ep-title override
		3. For unmatched folders: keep stricter checking
		"""
		try:
			try:
				my_cloud_files = Offcloud.user_cloud_check()
			except Exception:
				return
			if not my_cloud_files: return
			results_append = self.folder_results.append
			seen_ids = set()
			for item in my_cloud_files:
				if str(item.get('status', '')).lower() != 'downloaded': continue
				request_id = item.get('requestId')
				if self._is_cloud_archive(item):
					raw_folder = item.get('fileName') or ''
					folder_name = source_utils.clean_title(normalize(raw_folder))
					folder_prefiltered = self._prefilter_folder(folder_name, raw_folder)
					if not folder_prefiltered:
						source_utils.diag_log('OC FolderGate', 'SKIP folder=%r (no title/S&E/ep-name/abs tokens)' % raw_folder)
						continue
					source_utils.diag_log('OC FolderGate', 'enter folder=%r' % raw_folder)
					if request_id and request_id not in seen_ids:
						seen_ids.add(request_id)
						results_append((request_id, folder_name, raw_folder, folder_prefiltered))
				else:
					file_name = item.get('fileName', '')
					normalized = normalize(file_name)
					# Use wrapper for standalone files (no folder context)
					# ep_name now passed so the protected ep-title path can fire
					if not self._cloud_file_matches(normalized, ep_name_override=True):
						source_utils.diag_log('OC FolderContents', 'file REJECT (root) file=%r' % normalized)
						continue
					link = Offcloud.item_play_link(item)
					if link: self.scrape_results.append({'filename': normalized, 'url': link})
			if not self.folder_results: return
			threads = [Thread(target=self._scrape_folders, args=(i,)) for i in self.folder_results]
			[i.start() for i in threads]
			[i.join() for i in threads]
		except Exception:
			return

	def _scrape_folders(self, folder_info):
		"""Process files inside a folder with context awareness.
		
		folder_info tuple: (request_id, folder_name, raw_folder, folder_prefiltered)
		
		When folder_prefiltered=True (folder passed pre-filter):
		- For episodes: use ep_name_override=True to enable episode-title token matching
		
		Args:
			folder_info: Tuple with folder metadata
		"""
		try:
			request_id, folder_name, raw_folder, folder_prefiltered = folder_info
			results_append = self.scrape_results.append
			torrent_files = Offcloud.torrent_info(request_id)
			if not isinstance(torrent_files, list): return
			for item in torrent_files:
				try:
					if not isinstance(item, str) or not item.lower().endswith(tuple(self.extensions)): continue
					normalized = normalize(item.split('/')[-1])
					# Use unified wrapper which handles folder prefiltering and ep-name override
					if not source_utils.should_accept_file_title(
						self.title, normalized, self.aliases, self.year, self.season, self.episode,
						ep_name=self.ep_name,
						absolute_episode=self.absolute_episode,
						in_cloud_folder=folder_prefiltered,
						is_recovery_pass=False,
						filter_title=self.filter_title
					):
						source_utils.diag_log('OC FolderContents', 'file REJECT folder=%r file=%r' % (raw_folder, normalized))
						continue
					source_utils.diag_log('OC FolderContents', 'file ACCEPT folder=%r file=%r' % (raw_folder, normalized))
					results_append({'filename': normalized, 'url': item})
				except Exception:
					continue
		except Exception:
			return

	# ===== TITLE-TOKEN OVERRIDE RECOVERY PASS =====
	def _apply_title_token_recovery(self):
		"""Recovery pass: use title-token override to catch any missed episodes.
		
		This is a redundancy check that runs after standard matching.
		Files that passed standard matching are NOT re-processed.
		This only catches files that would have been rejected by standard matching
		but have valid episode-title tokens.
		
		For Offcloud, we re-scan pre-filtered folders for episode-title token matches.
		
		Set to run only for episodes when ep_name is available.
		"""
		if self.media_type != 'episode' or not self.ep_name:
			return
		
		try:
			# Track already-added files to avoid duplicates
			existing_files = {r['filename'].lower() for r in self.scrape_results}
			
			try:
				my_cloud_files = Offcloud.user_cloud_check()
			except Exception:
				return
			
			if not my_cloud_files:
				return
			
			results_append = self.scrape_results.append
			
			for item in my_cloud_files:
				if str(item.get('status', '')).lower() != 'downloaded':
					continue
				
				if self._is_cloud_archive(item):
					raw_folder = item.get('fileName') or ''
					folder_name = source_utils.clean_title(normalize(raw_folder))
					folder_prefiltered = self._prefilter_folder(folder_name, raw_folder)
					
					# Only re-scan pre-filtered folders
					if not folder_prefiltered:
						continue
					
					request_id = item.get('requestId')
					if not request_id:
						continue
					
					try:
						torrent_files = Offcloud.torrent_info(request_id)
						if not isinstance(torrent_files, list):
							continue
                        
						for file_item in torrent_files:
							if not isinstance(file_item, str) or not file_item.lower().endswith(tuple(self.extensions)):
								continue
                            
							normalized = normalize(file_item.split('/')[-1])
							
							# Skip if already in results
							if normalized.lower() in existing_files:
								continue
                            
							# Try recovery pass using unified wrapper (episode-title tokens only)
							if source_utils.should_accept_file_title(
								self.title, normalized, self.aliases, self.year, self.season, self.episode,
								ep_name=self.ep_name,
								in_cloud_folder=True,
								is_recovery_pass=True,  # Recovery mode: ONLY ep-title tokens
								filter_title=False
							):
                                
								link = Offcloud.item_play_link({'fileName': file_item})
								if link:
									source_utils.diag_log('OC CloudMatch', 'RECOVERY add: %r' % normalized)
									results_append({'filename': normalized, 'url': link})
									existing_files.add(normalized.lower())
					except Exception:
						continue
		except Exception:
			pass
	# ===== END TITLE-TOKEN OVERRIDE RECOVERY PASS =====
