# -*- coding: utf-8 -*-
from apis import torrentdownloads_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, merge_name_searches, name_search_queries, scrape_expiry, scrape_timeout
from modules.settings import torrentdownloads_scrape_active
from modules.utils import clean_file_name
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'torrentdownloads'
		self.sources = []

	def results(self, info):
		source_utils.remember_request(info)
		try:
			if not torrentdownloads_scrape_active():
				source_utils.diag_log('TORRENTDOWNLOADS', 'SCRAPER DISABLED')
				return source_utils.internal_results(self.scrape_provider, self.sources)

			media_type = info.get('media_type')
			absolute_episode = info.get('absolute_episode')
			if media_type == 'episode' and absolute_episode:
				source_utils.diag_log('TORRENTDOWNLOADS Init', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					info.get('season'), info.get('episode'), absolute_episode, info.get('ep_name') or ''))

			queries = name_search_queries(info)
			category = '8' if media_type == 'episode' else '4'
			info_queries = set(queries[:1])
			if media_type == 'episode':
				title = clean_file_name(info.get('title') or '').replace('&', 'and')
				try:
					season_i = int(info.get('season'))
					for season_query in ('%s S%02d' % (title, season_i), '%s Season %s' % (title, season_i)):
						if season_query not in queries:
							queries.append(season_query)
						info_queries.add(season_query)
				except Exception:
					pass
			def _search(query, timeout=10, expiration=24):
				return torrentdownloads_api.search(
					query, timeout=timeout, expiration=expiration, category=category,
					include_info=query in info_queries)
			source_utils.diag_log('TORRENTDOWNLOADS Queries', 'generated=%d queries: %s' % (len(queries), ', '.join(repr(q) for q in queries)))
			files = merge_name_searches(
				_search, queries, scrape_timeout(info), scrape_expiry(info))

			raw_count = len(files or [])
			self.sources = filter_and_build_sources(self.scrape_provider, files, info)
			kept = len(self.sources)
			source_utils.diag_log('TORRENTDOWNLOADS Match', '%s : %s kept / %s raw' % (info.get('title', ''), kept, raw_count))
			if raw_count and not self.sources:
				source_utils.diag_log('TORRENTDOWNLOADS Match', 'all raw results dropped by title/episode filter')

		except Exception as e:
			logger('torrentdownloads scraper Exception', str(e))
			source_utils.diag_log('TORRENTDOWNLOADS', 'ERROR %s' % type(e).__name__)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
