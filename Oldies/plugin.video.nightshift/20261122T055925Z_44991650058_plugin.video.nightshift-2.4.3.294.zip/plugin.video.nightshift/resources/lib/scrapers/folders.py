# -*- coding: utf-8 -*-
import os
from urllib.parse import urlparse
from caches.main_cache import cache_object
from modules import source_utils
from modules.kodi_utils import list_dirs, open_file
from modules.utils import clean_file_name, normalize, make_thread_list
from modules.settings import filter_by_name, max_threads
# from modules.kodi_utils import logger

class source:
	def __init__(self, scrape_provider, scraper_name, folder_path):
		self.scrape_provider = scrape_provider
		self.scraper_name = scraper_name
		self.folder_path = folder_path
		self.sources, self.scrape_results = [], []
		self.extensions = source_utils.supported_video_extensions()
		self.folder_results = []  # store matched folders for recovery pass

	def results(self, info):
		try:
			if not self.folder_path: return source_utils.internal_results(self.scraper_name, self.sources)
			filter_title = filter_by_name('folders')
			self.media_type, title, self.year = info.get('media_type'), info.get('title'), int(info.get('year'))
			self.title = title  # used by the recovery pass (it referenced an undefined local `title`)
			self.season, self.episode = info.get('season'), info.get('episode')
			self.absolute_episode = info.get('absolute_episode')
			self.tmdb_id = info.get('tmdb_id')
			self.ep_name = info.get('ep_name', '')
			
			# Log absolute episode for diagnostics (episodes only)
			if self.media_type == 'episode' and self.absolute_episode:
				source_utils.diag_log('Folders Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					self.season, self.episode, self.absolute_episode, self.ep_name))
			
			self.title_query = source_utils.clean_title(normalize(title))
			self.folder_query = self._season_query_list() if self.media_type == 'episode' else self._year_query_list()
			self.folder_results = []
			self._scrape_directory(self.folder_path, first_run=True)
			# Recovery pass: re-scan matched folders using title-token override to catch missed episodes.
			self._apply_title_token_recovery()
			if not self.scrape_results: return source_utils.internal_results(self.scraper_name, self.sources)
			aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			
			raw_count = len(self.scrape_results)
			skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'exception': 0}
			# ###FIX### `extras` was never defined here: _keep() raised NameError for every file that passed
			# the release filter and _process()'s bare except silently dropped it (folder scrapers returned nothing).
			extras = source_utils.extras()
			
			def _keep(file_name, folder_matched):
				# ✅ STEP 2: RELEASE FILTER CHECK (after ep-name protection)
				# Release filter removed: it is a Real-Debrid-only rule (applied in debrid.stamp_torrent_cache / rd_cloud).
				
				# ✅ STEP 3: Extras check
				if source_utils.has_extras_word(file_name, extras):
					skipped['extras'] += 1
					source_utils.diag_log('Folders Match', 'file REJECT (extras): %r' % file_name)
					return False
                
				# ✅ STEP 4: Standard title/episode matching
				if not source_utils.should_accept_file_title(
						title, file_name, aliases, self.year, self.season, self.episode,
						ep_name=self.ep_name,
						absolute_episode=self.absolute_episode,
						in_cloud_folder=bool(folder_matched),
						is_recovery_pass=False,
						filter_title=filter_title
				):
					skipped['title_filter'] += 1
					source_utils.diag_log('Folders Match', 'file REJECT: %r' % file_name)
					return False
				return True
			
			def _process():
				for item in self.scrape_results:
					try:
						# item layout: (orig_name, url_path, size, folder_matched_bool)
						file_name = normalize(item[0])
						folder_matched = item[3] if len(item) > 3 else False
                        
						if not _keep(file_name, folder_matched):
							continue
                        
						source_utils.diag_log('Folders Match', 'file ACCEPT: %r (folder_matched=%s)' % (file_name, folder_matched))
						display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						file_dl = item[1]
						try: size = item[2]
						except: size = self._get_size(file_dl)
						video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(file_name))
						source_item = {'name': file_name, 'display_name': display_name, 'quality': video_quality, 'size': size, 'size_label': '%.2f GB' % size, 'debrid': 'folders',
									'extraInfo': details, 'url_dl': file_dl, 'id': file_dl, self.scrape_provider : True, 'direct': True, 'source': self.scraper_name,
									'scrape_provider': 'folders'}
						yield source_item
					except: 
						skipped['exception'] += 1
			self.sources = list(_process())
			
			source_utils.diag_log('Folders Match', '%s : %s kept / %d raw' % (title, len(self.sources), raw_count))
			if raw_count and not self.sources:
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('Folders Match', 'all raw results dropped (%s)' % dropped)
			elif any(skipped.values()):
				dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
				source_utils.diag_log('Folders Match', 'dropped (%s)' % dropped)
		except Exception as e:
			from modules.kodi_utils import logger
			logger('NightShift folders scraper Exception', str(e))
		source_utils.internal_results(self.scraper_name, self.sources)
		return self.sources

	def _dedupe_key(self, name):
		return (name or '').replace('/', '').lower()

	def _already_scraped(self, name):
		key = self._dedupe_key(name)
		return key in {self._dedupe_key(d[0]) for d in self.scrape_results if d and d[0]}

	def _append_scrape_result(self, item):
		# item: (orig_name, url_path, size, folder_matched_bool)
		if not item or not item[1] or self._already_scraped(item[0]): return
		self.scrape_results.append(item)

	def _make_dirs(self, folder_name):
		folder_files = []
		folder_files_append = folder_files.append
		dirs, files =  list_dirs(folder_name)
		for i in dirs: folder_files_append((i, 'folder'))
		for i in files: folder_files_append((i, 'file'))
		return folder_files

	def _scrape_directory(self, folder_name, first_run=False):
		"""folder_name may be a string path or a tuple (path, folder_matched_bool)"""
		def _process(item):
			file_type = item[1]
			normalized = normalize(item[0])
			item_name = source_utils.clean_title(normalized)
			if file_type == 'file':
				ext = os.path.splitext(urlparse(item[0]).path)[-1].lower()
				if ext in self.extensions:
					# ✅ FIXED: Check ep-name BEFORE rejecting on S/E mismatch
					if self.media_type == 'episode':
						if not source_utils.seas_ep_filter(self.season, self.episode, normalized):
							# Keep ep-name-only files; strict S/E gate must not drop them
							if not (self.ep_name and source_utils.episode_title_in_release(self.ep_name, normalized)):
								return
					url_path = self.url_path(folder_path, item[0])
					size = self._get_size(url_path)
					# append file with folder_matched flag from the current folder context
					scrape_results_append((item[0], url_path, size, folder_matched))
			else:
				# if folder name matches (title or year/season tokens), mark it as matched
				if self.title_query in item_name or any(x in item_name for x in self.folder_query):
					full_path = os.path.join(folder_path, item[0])
					folder_results_append((full_path, True))
					# track matched folders for recovery pass
					try: self.folder_results.append(full_path)
					except: pass
				else:
					source_utils.diag_log('Folders FolderGate', 'SKIP folder=%r (no title/season/year tokens)' % item[0])

		# support being passed either a plain path or a tuple (path, folder_matched)
		folder_matched = False
		if isinstance(folder_name, tuple) or isinstance(folder_name, list):
			try:
				folder_path = folder_name[0]
				folder_matched = bool(folder_name[1])
			except Exception:
				folder_path = folder_name[0]
				folder_matched = False
		else:
			folder_path = folder_name

		folder_results = []
		scrape_results_append = self.scrape_results.append
		folder_results_append = folder_results.append
		string = 'FOLDERSCRAPER_%s_%s' % (self.scrape_provider, folder_path)
		folder_files = cache_object(self._make_dirs, string, (folder_path), json=False, expiration=4)
		folder_threads = list(make_thread_list(_process, folder_files))
		[i.join() for i in folder_threads]
		if not folder_results: return
		return self._scraper_worker(folder_results)

	def _scraper_worker(self, folder_results):
		# folder_results is a list of (path, folder_matched_bool)
		scraper_threads = list(make_thread_list(self._scrape_directory, folder_results))
		[i.join() for i in scraper_threads]

	def url_path(self, folder, file):
		return os.path.join(folder, file)

	def _get_size(self, file):
		if file.endswith('.strm'): return 'strm'
		with open_file(file) as f: s = f.size()
		return round(float(s)/1073741824, 2)

	# Recovery pass to catch episodes using episode-title tokens inside matched folders
	def _apply_title_token_recovery(self):
		"""Recovery pass: re-scan matched folders for files that match via episode-title tokens."""
		if self.media_type != 'episode' or not self.ep_name:
			return

		try:
			# Track already-added files to avoid duplicates
			existing_names = {self._dedupe_key(d[0]) for d in self.scrape_results if d and d[0]}

			# Re-scan each matched folder
			for folder_path in getattr(self, 'folder_results', []):
				try:
					folder_files = list_dirs(folder_path)[1] or []
				except Exception:
					continue

				for filename in folder_files:
					try:
						# skip non-playable extensions
						if not filename.lower().endswith(tuple(self.extensions)):
							continue
						normalized = normalize(filename)
						if not normalized:
							continue
						# skip if already present
						if self._dedupe_key(normalized) in existing_names:
							continue
						# build url_path and size
						url_path = self.url_path(folder_path, filename)
						size = self._get_size(url_path)
						# ✅ FIXED: Pass actual title to enable check-word validation
						if source_utils.should_accept_file_title(
								self.title, normalized, source_utils.get_aliases_titles([]), self.year, self.season, self.episode,
								ep_name=self.ep_name,
								in_cloud_folder=True,
								is_recovery_pass=True,
								filter_title=False
						):
							# append found item (orig name, url_path, size, folder_matched=True)
							source_utils.diag_log('Folders CloudMatch', 'RECOVERY add: %r' % normalized)
							self._append_scrape_result((filename, url_path, size, True))
							existing_names.add(self._dedupe_key(normalized))
					except Exception:
						continue
		except Exception:
			pass

	def _year_query_list(self):
		return (str(self.year), str(self.year+1), str(self.year-1))

	def _season_query_list(self):
		return ('season%02d' % int(self.season), 'season%s' % self.season)