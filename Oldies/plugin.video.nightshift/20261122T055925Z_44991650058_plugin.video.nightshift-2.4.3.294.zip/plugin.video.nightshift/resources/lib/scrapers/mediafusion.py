# -*- coding: utf-8 -*-
from apis import mediafusion_api
from modules import source_utils
from modules.native_torrents import filter_and_build_sources, scrape_expiry, scrape_timeout
from modules.settings import mediafusion_scrape_active
from modules.kodi_utils import logger

class source:
	def __init__(self):
		self.scrape_provider = 'mediafusion'
		self.sources = []

	def results(self, info):
		try:
			if not mediafusion_scrape_active():
				return source_utils.internal_results(self.scrape_provider, self.sources)
			imdb_id = info.get('imdb_id')
			if not imdb_id:
				source_utils.diag_log('MEDIAFUSION Match', 'no imdb_id, skipped')
				return source_utils.internal_results(self.scrape_provider, self.sources)

			absolute_episode = info.get('absolute_episode')
			ep_name = info.get('ep_name') or ''
			if info.get('media_type') == 'episode' and absolute_episode:
				source_utils.diag_log('MEDIAFUSION Match', 'S%02dE%02d (abs=%d) ep_name=%r' % (
					info.get('season'), info.get('episode'), absolute_episode, ep_name))

			streams = mediafusion_api.search_streams(
				imdb_id, info.get('media_type'), info.get('season'), info.get('episode'),
				timeout=scrape_timeout(info), expiration=scrape_expiry(info))

			raw_count = len(streams or [])
			self.sources = filter_and_build_sources(self.scrape_provider, streams, info)
			kept = len(self.sources)

			source_utils.diag_log('MEDIAFUSION Match', '%s : %s kept / %s raw' % (
				info.get('title', ''), kept, raw_count))
			if raw_count and not self.sources:
				source_utils.diag_log('MEDIAFUSION Match', 'all raw results dropped by filter_and_build_sources')

		except Exception as e:
			logger('mediafusion scraper Exception', str(e))
			source_utils.diag_log('MEDIAFUSION', 'ERROR %s' % type(e).__name__)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
