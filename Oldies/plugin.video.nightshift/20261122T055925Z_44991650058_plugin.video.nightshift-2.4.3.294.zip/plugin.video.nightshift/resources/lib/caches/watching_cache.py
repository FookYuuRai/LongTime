# -*- coding: utf-8 -*-
"""Currently-watching cache (watching_db): what each scraper / indexer / provider already returned for the show being watched.

Stored per scraper:
  show     the whole-show query by NAME ('Dragon Ball Super', an alias)                  - tmdb id translated to the show name
  episode  episode-name searches ('SOS from the Future ...', '<show> SOS from the Future ...')
  id       id based requests (AIOStreams 'tt1234567:1:47')
Every row is keyed by the TMDb id (plus the show name), so one show's rows are found and filtered directly - see for_show().

The next episode, a re-scrape or autoplay / auto-resolve reads these rows to MATCH, FILTER and CHOOSE from - the requests to the
services are not repeated. Episode-number queries (S01E47, absolute number) are never stored.

Lifetime: rows are kept between Kodi sessions so an episode that is already out is answered from the database and no indexer / service is asked again.
At Kodi start rows older than RETAIN_DAYS and everything beyond the MAX_SHOWS most recently used shows are removed; Maintenance -> Clear Currently
Watching Cache empties it by hand. Lists are stored compressed. A show is keyed by its TMDb id (anime too); without one, by its normalised name.
"""
import ast
import copy
import json
import re
import threading
import time
import zlib
from caches.base_cache import connect_database, ensure_database_tables

_DB = 'watching_db'
RETAIN_DAYS = 7          # a stored show list is used for a week
MAX_SHOWS = 40           # most recently used shows kept (a show's lists can be a few hundred KB per indexer)
_ready = [False]


def _db():
	if not _ready[0]:
		try:
			ensure_database_tables(_DB)
			_ready[0] = True
		except Exception:
			pass
	return connect_database(_DB)


def _norm(text):
	return re.sub(r'[^a-z0-9]+', ' ', (text or '').lower()).strip()


def _ctx():
	try:
		from modules import source_utils
		ctx = getattr(source_utils._request_ctx, 'value', None)
		if ctx and ctx.get('media_type') in ('episode', 'movie'): return ctx
	except Exception:
		pass
	return None


def _encode(results, py=False):
	"""JSON for the plain result lists; 'PY:' + repr for rows that hold more than JSON can (external provider rows - the same repr / literal form external_cache uses)."""
	text = None
	if py:
		try:
			rep = repr(results)
			ast.literal_eval(rep)
			text = 'PY:' + rep
		except Exception:
			pass
	if text is None: text = json.dumps(results, default=str)
	try: return b'Z' + zlib.compress(text.encode('utf-8'), 6)
	except Exception: return text


def _decode(text):
	if isinstance(text, (bytes, bytearray)):
		if text[:1] == b'Z': text = zlib.decompress(bytes(text[1:])).decode('utf-8')
		else: text = bytes(text).decode('utf-8')
	if text.startswith('PY:'): return ast.literal_eval(text[3:])
	return json.loads(text)


def classify(query):
	"""'show' whole show / title, 'season' a whole season, 'episode' an episode-name search, 'number' a search for one episode number (S01E47, absolute 47 ...);
	None for a movie query that is not title / title + year."""
	ctx = _ctx()
	if not ctx: return None
	q = _norm(query)
	names = {n for n in [_norm(ctx.get('title'))] + [_norm(a) for a in (ctx.get('aliases') or ())] if n}
	if q in names: return 'show'
	if ctx.get('media_type') == 'movie':
		year = str(ctx.get('year') or '').strip()
		return 'show' if year and any(q == '%s %s' % (n, year) for n in names) else None
	# '<name> S01' / '<name> season 1' (any season): covers every episode of that season
	if any(re.fullmatch(r'%s (?:s\d{1,2}|season \d{1,2})' % re.escape(n), q) for n in names): return 'season'
	epn = _norm(ctx.get('ep_name'))
	if epn and len(epn.split()) >= 2 and (q == epn or any(q == '%s %s' % (n, epn) for n in names)): return 'episode'
	# everything else is about ONE episode ('<name> S01E47', '<name> 47', '<name> 047', alternate numbering, ...)
	return 'number'


def _tmdb():
	"""The show's key: its TMDb id; a show without one is keyed by its name."""
	ctx = _ctx() or {}
	return str(ctx.get('tmdb_id') or '') or ('name:' + _norm(ctx.get('title')) if ctx.get('title') else '')


def db_only(scraper=''):
	"""True when this scraper has to answer from the database (the database-first pass of the request in progress)."""
	ctx = _ctx()
	if not ctx: return False
	scraper = 'nzb' if (scraper or '').startswith('nzb_') else scraper
	return scraper in (ctx.get('db_scrapers') or ())


def scrapers_for_show(tmdb_id):
	"""Scraper ids (as the scraper list names them) that have rows stored for this show."""
	out = set()
	try:
		for (scraper,) in _db().execute("SELECT DISTINCT scraper FROM watch_index WHERE kind NOT IN ('match', 'meta') AND kind NOT IN ('id', 'single', 'number', 'episode') AND tmdb_id = ? AND results NOT IN ('[]', 'PY:[]')", (str(tmdb_id or ''),)).fetchall():
			out.add('nzb' if scraper.startswith('nzb_') else scraper)
	except Exception:
		pass
	return out


def get(scraper, query):
	try:
		row = _db().execute('SELECT results FROM watch_index WHERE tmdb_id = ? AND scraper = ? AND query = ?', (_tmdb(), scraper, _norm(query))).fetchone()
		return _decode(row[0]) if row else None
	except Exception:
		return None


def put(scraper, query, results, kind='show', ttl=None, py=False):
	try:
		ctx = _ctx() or {}
		_db().execute('INSERT OR REPLACE INTO watch_index (tmdb_id, scraper, query, show, kind, results, updated, ttl) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
					(_tmdb(), scraper, _norm(query), ctx.get('title') or '', kind, _encode(results, py), int(time.time()), ttl))
		return True
	except Exception:
		return False


_EPISODE_KINDS = ('id', 'single', 'number', 'episode')   # rows that belong to ONE episode (AIOStreams id request, external single-episode search, S01E47 / absolute-number and episode-name searches)


# ---- episode index: the stored lists sorted by episode (S#E#, alternate numbering, absolute number) and release group ------------------
# Every stored list of a scraper (show / season / episode-name / episode-number searches) is read once, each release name is parsed once, and the
# names are filed by episode and by group. An episode that was never played is then answered from what is already stored - a lookup, not a search.
# The index is only a finder: whatever it returns still goes through the scraper's normal accept / reject matching.
_INDEX = {}                # (tmdb_id, scraper) -> {'stamp': (rows, newest), 'se': {}, 'num': {}, 'count': n, 'unnumbered': n}
_INDEX_LOCK = threading.Lock()
_POOL_KINDS = ('number', 'episode')   # searches the index can answer instead of the service
_INDEX_KINDS = "('show', 'season', 'episode', 'number')"
_RES_NUMBERS = {480, 576, 720, 1080, 1440, 2160, 4320}
_ISOLATED_NUM_RE = re.compile(r'(?<![a-z0-9.])(\d{1,4})(?:v\d)?(?![a-z0-9]|\.\d)', re.I)


def _item_name(item):
	try:
		if isinstance(item, dict):
			return str(item.get('name') or item.get('title') or item.get('filename') or '')
	except Exception:
		pass
	return ''


def _numbers_in(name):
	"""Isolated numbers of an anime-style name ('Show - 047 [1080p]'): not resolutions, not years, not audio layouts ('5.1')."""
	out = set()
	for m in _ISOLATED_NUM_RE.finditer(name):
		n = int(m.group(1))
		if n in _RES_NUMBERS or 1900 <= n <= 2100: continue
		out.add(n)
	return out


def _build_index(tmdb, scraper):
	from modules import source_utils as su
	index = {'se': {}, 'num': {}, 'count': 0, 'unnumbered': 0}
	seen = set()
	for (res,) in _db().execute("SELECT results FROM watch_index WHERE tmdb_id = ? AND scraper = ? AND kind IN " + _INDEX_KINDS, (tmdb, scraper)).fetchall():
		try: items = _decode(res)
		except Exception: continue
		for item in items if isinstance(items, list) else ():
			name = _item_name(item)
			if not name: continue
			key = (item.get('hash') or item.get('link') or item.get('url_dl') or name)
			if key in seen: continue
			seen.add(key)
			index['count'] += 1
			try:
				tokens = {t for t in su.iter_season_episode_tokens(name) if t[1] not in _RES_NUMBERS}
				for tok in tokens: index['se'].setdefault(tok, []).append(item)
				numbers = set() if tokens else _numbers_in(name)
				for n in numbers: index['num'].setdefault(n, []).append(item)
				if not tokens and not numbers: index['unnumbered'] += 1
			except Exception:
				index['unnumbered'] += 1
	return index


def _index_for(tmdb, scraper):
	row = _db().execute("SELECT COUNT(*), MAX(updated) FROM watch_index WHERE tmdb_id = ? AND scraper = ? AND kind IN " + _INDEX_KINDS, (tmdb, scraper)).fetchone()
	stamp = (row[0], row[1]) if row else (0, 0)
	with _INDEX_LOCK:
		index = _INDEX.get((tmdb, scraper))
		if index is None or index['stamp'] != stamp:
			index = _build_index(tmdb, scraper)
			index['stamp'] = stamp
			_INDEX[(tmdb, scraper)] = index
	return index


def episode_lookup(scraper, season, episode, absolute=None, group=None):
	"""Stored releases of this scraper for one episode - found by S#E#, the other numbering of the same episode, or the absolute number -
	optionally only one release group / tagger. Packs, ranges and names without a number are not returned (their lists already reach the scraper).
	Returns [(item, release group)]."""
	tmdb = _tmdb()
	if not tmdb: return []
	try:
		from modules import source_utils as su
		from modules.release_groups import group_from_name
		index = _index_for(tmdb, scraper)
		season, episode, absolute = int(season), int(episode), int(absolute or 0)
		picked, seen = [], set()
		def take(items):
			for item in items or ():
				if id(item) not in seen:
					seen.add(id(item)); picked.append(item)
		take(index['se'].get((season, episode)))
		for alt in su._alt_pairs(season, episode, absolute) or (): take(index['se'].get(tuple(alt)))
		if absolute:
			take(index['se'].get((1, absolute)))
			take(index['num'].get(absolute))
		if season == 1: take(index['num'].get(episode))
		out = []
		for item in picked:
			grp = group_from_name(_item_name(item))
			if group and grp.lower() != str(group).lower(): continue
			out.append((copy.copy(item), grp))
		return out
	except Exception:
		return []


def episode_groups(scraper, season, episode, absolute=None):
	"""{release group: number of stored releases} for one episode - which groups already have it."""
	out = {}
	for _item, grp in episode_lookup(scraper, season, episode, absolute): out[grp or '?'] = out.get(grp or '?', 0) + 1
	return out


def _pooled(scraper, label):
	"""The stored releases for the requested episode as the answer to an episode search; None when the index holds none."""
	ctx = _ctx() or {}
	if ctx.get('media_type') != 'episode' or not ctx.get('season') or not ctx.get('episode'): return None
	found = episode_lookup(scraper, ctx.get('season'), ctx.get('episode'), ctx.get('absolute'))
	if not found: return None
	groups = {}
	for _item, grp in found: groups[grp or '?'] = groups.get(grp or '?', 0) + 1
	trace(False, '%s | episode index: %d stored release(s) for S%sE%s | groups: %s | no request sent' % (
		label, len(found), ctx.get('season'), ctx.get('episode'), ', '.join('%s (%d)' % g for g in sorted(groups.items(), key=lambda g: -g[1])[:6])))
	return [item for item, _grp in found]


_PRE = []   # (time, tag, message): lines traced before the scraper window opened (the per-episode decision comes first)


def take_pre():
	"""Lines traced in the last 20 seconds before the scraper window existed (oldest first); emptied."""
	now = time.time()
	out = [(t, m) for ts, t, m in _PRE if now - ts < 20]
	del _PRE[:]
	return out


def trace(live, message):
	"""One line per request: 'LIVE CODE TRACE' when a service is really asked, 'LOCAL DATABASE CODE TRACE' when the stored rows answer.
	Written to the Kodi log and streamed into the scraper window's trace pane (whose header follows the tag)."""
	tag = 'LIVE CODE TRACE' if live else 'LOCAL DATABASE CODE TRACE'
	try:
		from modules import source_utils
		sink = source_utils.TRACE_SINK
		if sink: sink(tag, message)
		else:
			_PRE.append((time.time(), tag, message))
			del _PRE[:-30]
	except Exception:
		pass
	try:
		from modules.kodi_utils import logger
		logger(tag, message)
	except Exception:
		pass


def _n(result):
	try: return len(result or [])
	except Exception: return 0


def cached(scraper, query, fetch, kind=None, ttl=None, py=False):
	"""Answer a show-name / season / episode-name query (or an id request: kind='id') from the database, otherwise run fetch() and remember a non-empty answer."""
	kind = kind or classify(query)
	label = '%s | %r' % (scraper, query)
	if (_ctx() or {}).get('live'):
		# Live Search: always ask the service, keep the fresh answer in the database
		result = fetch()
		stored = bool(kind and result)
		if stored: put(scraper, query, result, kind, ttl, py)
		trace(True, '%s | Live Search | %d result(s)%s' % (label, _n(result), ' | database row refreshed' if stored else ' | not stored (%s)' % ('empty' if kind else 'episode-number query')))
		return result
	if db_only(scraper):
		# database-first pass: answer from what is stored, never from the service; a miss is an empty answer (the caller then falls back to a full scrape)
		if not kind:
			trace(False, '%s | not a stored query type (episode number or another season) - skipped, no request sent' % label)
			return []
		hit = get(scraper, query)
		if not hit and kind in _POOL_KINDS:
			pooled = _pooled(scraper, label)
			if pooled is not None: return pooled
		if not hit and kind in _EPISODE_KINDS:
			# instant results: a request about this episode only that is not stored sends NOTHING (the user's Live Search asks the service and stores the answer);
			# when every stored source comes up empty the regular live scrape still runs (_db_first_fallback)
			trace(False, '%s | %s request for this episode only - nothing stored, no request sent (Live Search fetches it)' % (label, kind))
			return []
		trace(False, '%s | %s %s | %d result(s) | no request sent' % (label, kind, 'HIT' if hit else 'MISS (nothing stored)', _n(hit)))
		return hit or []
	if not kind:
		result = fetch()
		trace(True, '%s | unexpected query type | live request | %d result(s)' % (label, _n(result)))
		return result
	hit = get(scraper, query)
	if hit:
		trace(False, '%s | %s HIT | %d result(s) | no request sent' % (label, kind, len(hit)))
		return hit
	if kind in _POOL_KINDS:
		pooled = _pooled(scraper, label)       # never searched for this episode yet, but its releases may already be in the stored lists
		if pooled is not None: return pooled
	result = fetch()
	if result: put(scraper, query, result, kind, ttl, py)
	trace(True, '%s | %s not stored yet | live request | %d result(s)%s' % (label, kind, _n(result), ' | stored' if result else ' | empty, not stored'))
	return result


# ---- match cache: the accept / reject decision for one release name, for one request -------------------------------------------------
# The matchers are pure functions of (names, season / episode / absolute, episode name, alt numbering, flags), so the same release name that
# shows up under several queries, in several scrapers, or again in autoplay / next-episode prep / a rescrape is judged ONCE. Stored in
# watch_index with kind='match' (hidden from the views), emptied with everything else on Kodi start / Clear Currently Watching Cache.
_MEM = {}        # (tmdb_id, key) -> (ok, reasons)
_LOADED = set()  # tmdb ids whose stored decisions are already in _MEM
_PENDING = []    # new decisions not written yet
_STATS = [0, 0]  # hits, misses
_MEM_MAX = 60000


def match_key(*parts):
	import hashlib
	return hashlib.sha1(repr(parts).encode('utf-8', 'replace')).hexdigest()[:24]


def _load(tmdb):
	if tmdb in _LOADED: return
	_LOADED.add(tmdb)
	if not tmdb: return
	try:
		for key, res in _db().execute("SELECT query, results FROM watch_index WHERE tmdb_id = ? AND scraper = '_match' AND kind = 'match'", (tmdb,)).fetchall():
			try:
				ok, why = json.loads(res)
				_MEM[(tmdb, key)] = (bool(ok), tuple(why))
			except Exception: pass
	except Exception:
		pass


def match_get(key):
	tmdb = _tmdb()
	if len(_MEM) > _MEM_MAX: _MEM.clear(); _LOADED.clear()
	_load(tmdb)
	hit = _MEM.get((tmdb, key))
	if hit is None: _STATS[1] += 1
	else: _STATS[0] += 1
	return hit


def match_put(key, ok, why):
	tmdb = _tmdb()
	_MEM[(tmdb, key)] = (bool(ok), tuple(why or ()))
	if tmdb:
		_PENDING.append((tmdb, key, json.dumps([bool(ok), list(why or ())])))
		if len(_PENDING) >= 400: match_flush()


def match_flush():
	"""Write the new decisions in one transaction (called when enough piled up and when a scrape is done)."""
	if not _PENDING: return
	rows, _PENDING[:] = list(_PENDING), []
	try:
		now = int(time.time())
		dbcon = _db()
		dbcon.executemany("INSERT OR REPLACE INTO watch_index (tmdb_id, scraper, query, show, kind, results, updated, ttl) VALUES (?, '_match', ?, '', 'match', ?, ?, NULL)",
						[(t, k, r, now) for t, k, r in rows])
		dbcon.commit()
	except Exception:
		pass
	try:
		from modules.source_utils import diag_log
		diag_log('MatchCache', 'stored %d decisions (this process: %d reused, %d judged)' % (len(rows), _STATS[0], _STATS[1]))
	except Exception: pass


def count():
	try: return _db().execute("SELECT COUNT(*) FROM watch_index WHERE kind NOT IN ('match', 'meta')").fetchone()[0]
	except Exception: return 0


def entries(limit=10):
	"""[(show, tmdb_id, scraper, kind, query, number_of_results), ...] newest first."""
	try:
		rows = _db().execute("SELECT show, tmdb_id, scraper, kind, query, results FROM watch_index WHERE kind NOT IN ('match', 'meta') ORDER BY tmdb_id, updated DESC LIMIT ?", (int(limit),)).fetchall()
		out = []
		for show, tmdb_id, scraper, kind, query, results in rows:
			try: n = len(_decode(results))
			except Exception: n = 0
			out.append((show, tmdb_id, scraper, kind, query, n))
		return out
	except Exception:
		return []


def for_show(tmdb_id, scraper=None, kind=None):
	"""Everything stored for one show (TMDb id), optionally for one scraper / kind: [(scraper, kind, query, results), ...].
	Matching, filtering and the autoplay choice read the show's rows from here instead of asking the services again."""
	try:
		sql, args = "SELECT scraper, kind, query, results FROM watch_index WHERE kind NOT IN ('match', 'meta') AND tmdb_id = ?", [str(tmdb_id or '')]
		if scraper: sql, args = sql + ' AND scraper = ?', args + [scraper]
		if kind: sql, args = sql + ' AND kind = ?', args + [kind]
		return [(sc, kd, q, _decode(r)) for sc, kd, q, r in _db().execute(sql, args).fetchall()]
	except Exception:
		return []


def clear_all():
	_MEM.clear(); _LOADED.clear(); _INDEX.clear(); del _PENDING[:]
	try:
		dbcon = _db()
		dbcon.execute('DELETE FROM watch_index')
		for old in ('queries', 'watch_queries'):   # layouts of earlier builds
			try: dbcon.execute('DROP TABLE IF EXISTS %s' % old)
			except Exception: pass
		try: dbcon.execute('VACUUM')
		except Exception: pass
		return True
	except Exception:
		return False


def purge():
	"""Kodi start: forget what is too old and what belongs to shows not watched lately; the rest stays for the next session."""
	_MEM.clear(); _LOADED.clear(); _INDEX.clear(); del _PENDING[:]
	try:
		try:
			from modules.kodi_utils import addon_info
			version = str(addon_info('version'))
		except Exception:
			version = ''
		dbcon = _db()
		row = dbcon.execute("SELECT results FROM watch_index WHERE tmdb_id = '_meta' AND scraper = '_meta' AND query = 'version'").fetchone()
		if version and (not row or row[0] != version):     # a new version may match and store differently: start from nothing once
			clear_all()
			dbcon.execute("INSERT OR REPLACE INTO watch_index (tmdb_id, scraper, query, show, kind, results, updated, ttl) VALUES ('_meta', '_meta', 'version', '', 'meta', ?, ?, NULL)", (version, int(time.time())))
			return True
		now = int(time.time())
		removed = dbcon.execute("DELETE FROM watch_index WHERE tmdb_id != '_meta' AND (updated < ? OR (ttl IS NOT NULL AND updated + ttl < ?))", (now - RETAIN_DAYS * 86400, now)).rowcount or 0
		shows = [r[0] for r in dbcon.execute("SELECT tmdb_id FROM watch_index WHERE tmdb_id != '_meta' GROUP BY tmdb_id ORDER BY MAX(updated) DESC").fetchall()]
		for tmdb_id in shows[MAX_SHOWS:]:
			removed += dbcon.execute("DELETE FROM watch_index WHERE tmdb_id = ?", (tmdb_id,)).rowcount or 0
		for old in ('queries', 'watch_queries'):
			try: dbcon.execute('DROP TABLE IF EXISTS %s' % old)
			except Exception: pass
		if removed:
			try: dbcon.execute('VACUUM')
			except Exception: pass
		return True
	except Exception:
		return False
