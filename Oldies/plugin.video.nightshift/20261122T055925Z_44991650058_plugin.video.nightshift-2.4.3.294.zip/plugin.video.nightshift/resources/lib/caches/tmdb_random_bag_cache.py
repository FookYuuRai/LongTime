# -*- coding: utf-8 -*-
"""Persistent local cache for TMDb episode-still random bags.

The TMDb still list is fetched only when an episode has no usable local set (or
its set is older than the refresh window). Image bytes are stored under the
add-on profile and indexed in tmdb_random_bag.db. Bag draws are persisted.
"""
import os
import time
import random
import hashlib
from datetime import datetime
from threading import Lock

from caches.base_cache import connect_database, ensure_database_tables
from modules import kodi_utils

_DB = 'tmdb_stills_db'
_STILLS_FOLDER = 'TMDb Random Bag Episode Stills'
_SET_REFRESH_SECONDS = 30 * 86400
_PURGE_CHECK_SECONDS = 300
_last_purge_check = 0
_DB_READY = False
_DB_LOCK = Lock()


def _now():
    return int(time.time())


def _profile_dir():
    return os.path.join(kodi_utils.addon_profile(), _STILLS_FOLDER)


def _ensure_dir(folder):
    try:
        os.makedirs(folder, exist_ok=True)
        return True
    except Exception as exc:
        kodi_utils.logger('TMDbRandomBag', 'Create cache folder failed: %s' % exc)
        return False


def _db():
    global _DB_READY
    if not _DB_READY:
        with _DB_LOCK:
            if not _DB_READY:
                ensure_database_tables(_DB)
                _DB_READY = True
    return connect_database(_DB)


def _setting_value(setting_id, fallback):
    value = kodi_utils.get_property('nightshift.' + setting_id)
    if value in ('', None):
        try:
            from caches.settings_cache import get_setting
            value = get_setting('nightshift.' + setting_id, str(fallback))
        except Exception:
            value = fallback
    return value


def _retention_days():
    try:
        value = int(_setting_value('tmdb_random_bag_retention', 7))
    except Exception:
        value = 7
    return value if value in (1, 7, 14) else 7


def _size_limit_bytes():
    try:
        value = int(_setting_value('tmdb_random_bag_size_limit', 250))
    except Exception:
        value = 250
    if value not in (50, 100, 250, 1024, 10240):
        value = 250
    return value * 1024 * 1024


def _timestamp(value):
    if value in (None, ''):
        return 0
    try:
        return int(float(value))
    except Exception:
        pass
    try:
        text = str(value).strip().replace('Z', '+00:00')
        parsed = datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            return int(time.mktime(parsed.timetuple()))
        return int(parsed.timestamp())
    except Exception:
        return 0


def _show_last_played(tmdb_id):
    """Get last playback for this show across NIGHTSHIFT and supported provider caches."""
    keys = {str(tmdb_id)}
    try:
        from modules.tvdb_ids import read_keys
        keys.update(str(i) for i in (read_keys(str(tmdb_id)) or []) if i)
    except Exception:
        pass
    if not keys:
        return 0
    marks = ','.join('?' for _ in keys)
    newest = 0
    for db_name in ('watched_db', 'trakt_db', 'simkl_db', 'mdblist_db', 'punchplay_db'):
        dbcon = None
        try:
            dbcon = connect_database(db_name)
            for table in ('watched', 'progress'):
                rows = dbcon.execute(
                    'SELECT last_played FROM %s WHERE db_type = ? AND media_id IN (%s)' % (table, marks),
                    tuple(['episode'] + sorted(keys))
                ).fetchall()
                for row in rows:
                    newest = max(newest, _timestamp(row[0]))
        except Exception:
            pass
        finally:
            try:
                if dbcon: dbcon.close()
            except Exception:
                pass
    return newest


def _file_size(path):
    try:
        return os.path.getsize(path) if os.path.isfile(path) else 0
    except Exception:
        return 0


def _delete_group(dbcon, tmdb_id):
    """Delete a show's cache; keep any record whose file could not be removed."""
    rows = dbcon.execute(
        'SELECT season, episode, image_key, local_path FROM episode_stills WHERE tmdb_id = ?', (str(tmdb_id),)
    ).fetchall()
    removed, freed = 0, 0
    for season, episode, image_key, file_path in rows:
        try:
            size = _file_size(file_path)
            if file_path and os.path.isfile(file_path):
                os.remove(file_path)
            dbcon.execute(
                'DELETE FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                (str(tmdb_id), int(season), int(episode), str(image_key))
            )
            if size:
                removed += 1
                freed += size
        except Exception as exc:
            kodi_utils.logger('TMDbRandomBag', 'Could not remove %s: %s' % (file_path, exc))
    remaining = dbcon.execute('SELECT COUNT(*) FROM episode_stills WHERE tmdb_id=?', (str(tmdb_id),)).fetchone()[0]
    if not remaining:
        dbcon.execute('DELETE FROM episode_still_sets WHERE tmdb_id=?', (str(tmdb_id),))
    return removed, freed


def _delete_episode(dbcon, tmdb_id, season, episode):
    rows = dbcon.execute(
        'SELECT image_key, local_path FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=?',
        (str(tmdb_id), int(season), int(episode))
    ).fetchall()
    removed, freed = 0, 0
    for image_key, file_path in rows:
        try:
            size = _file_size(file_path)
            if file_path and os.path.isfile(file_path):
                os.remove(file_path)
            dbcon.execute(
                'DELETE FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                (str(tmdb_id), int(season), int(episode), str(image_key))
            )
            if size:
                removed += 1
                freed += size
        except Exception as exc:
            kodi_utils.logger('TMDbRandomBag', 'Could not remove %s: %s' % (file_path, exc))
    remaining = dbcon.execute(
        'SELECT COUNT(*) FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=?',
        (str(tmdb_id), int(season), int(episode))
    ).fetchone()[0]
    if not remaining:
        dbcon.execute('DELETE FROM episode_still_sets WHERE tmdb_id=? AND season=? AND episode=?',
                      (str(tmdb_id), int(season), int(episode)))
    return removed, freed

def _cached_bytes(dbcon):
    """Reconcile indexed sizes with bytes actually on disk before enforcing the cap."""
    total = 0
    rows = dbcon.execute('SELECT tmdb_id, season, episode, image_key, local_path FROM episode_stills').fetchall()
    for tmdb_id, season, episode, image_key, local_path in rows:
        actual = _file_size(local_path)
        dbcon.execute(
            'UPDATE episode_stills SET size_bytes=? WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
            (actual, str(tmdb_id), int(season), int(episode), str(image_key))
        )
        total += actual
    return total


def purge_expired_and_over_limit(protect_tmdb_id=None, protect_episode=None, force=False):
    """Purge shows inactive beyond retention; enforce selected total-byte ceiling.

    The retention clock is based on the show's most recent playback. If a show
    has no local playback record, its cache creation date is used as a safe
    fallback. While Kodi is playing video, automatic deletion is deferred.
    """
    global _last_purge_check
    now = _now()
    if not force and now - _last_purge_check < _PURGE_CHECK_SECONDS:
        return 0, 0
    try:
        if kodi_utils.get_visibility('Player.HasVideo'):
            return 0, 0
    except Exception:
        pass
    _last_purge_check = now

    dbcon = _db()
    removed_files = 0
    removed_bytes = 0
    try:
        _cached_bytes(dbcon)
        groups = dbcon.execute(
            'SELECT s.tmdb_id, MIN(s.created_at), COALESCE(MAX(i.last_access), 0), '
            'COALESCE(SUM(i.size_bytes), 0) '
            'FROM episode_still_sets s LEFT JOIN episode_stills i ON i.tmdb_id = s.tmdb_id AND i.season = s.season AND i.episode = s.episode '
            'GROUP BY s.tmdb_id'
        ).fetchall()
        candidates = []
        for tmdb_id, created_at, last_access, bytes_used in groups:
            last_played = _show_last_played(tmdb_id)
            base_time = last_played or int(created_at or 0)
            candidates.append({
                'tmdb_id': str(tmdb_id), 'base_time': base_time,
                'last_access': int(last_access or 0), 'bytes': int(bytes_used or 0)
            })

        # Age policy is based on show playback (not row focus / image access).
        max_age = _retention_days() * 86400
        for item in sorted(candidates, key=lambda x: (x['base_time'], x['last_access'])):
            if item['tmdb_id'] == str(protect_tmdb_id or ''):
                continue
            if item['base_time'] and now - item['base_time'] >= max_age:
                count, freed = _delete_group(dbcon, item['tmdb_id'])
                removed_files += count
                removed_bytes += freed

        # Enforce total disk cap, oldest last-played shows first. If no playback
        # record exists, oldest cache creation is the fallback ordering.
        total = _cached_bytes(dbcon)
        ceiling = _size_limit_bytes()
        if total >= ceiling:
            size_groups = []
            rows = dbcon.execute(
                'SELECT s.tmdb_id, s.season, s.episode, MIN(s.created_at), COALESCE(SUM(i.size_bytes), 0) '
                'FROM episode_still_sets s LEFT JOIN episode_stills i ON i.tmdb_id = s.tmdb_id AND i.season = s.season AND i.episode = s.episode '
                'GROUP BY s.tmdb_id, s.season, s.episode'
            ).fetchall()
            last_played_by_show = {}
            for tmdb_id, season, episode, created_at, bytes_used in rows:
                episode_key = (str(tmdb_id), int(season), int(episode))
                if protect_episode and episode_key == (str(protect_episode[0]), int(protect_episode[1]), int(protect_episode[2])):
                    continue
                if str(tmdb_id) not in last_played_by_show:
                    last_played_by_show[str(tmdb_id)] = _show_last_played(tmdb_id)
                last_played = last_played_by_show[str(tmdb_id)]
                size_groups.append((last_played or int(created_at or 0), int(created_at or 0), episode_key, int(bytes_used or 0)))
            for _last_played, _created_at, episode_key, bytes_used in sorted(size_groups):
                if total < ceiling:
                    break
                count, freed = _delete_episode(dbcon, episode_key[0], episode_key[1], episode_key[2])
                removed_files += count
                removed_bytes += freed
                total -= freed
        dbcon.commit()
    except Exception as exc:
        kodi_utils.logger('TMDbRandomBag', 'Purge failed: %s' % exc)
    finally:
        try: dbcon.close()
        except Exception: pass
    return removed_files, removed_bytes


def _tmdb_has_episode(tmdb_id, season, episode):
    from apis.tmdb_api import season_episodes_details
    episodes = (season_episodes_details(tmdb_id, int(season)) or {}).get('episodes') or []
    return any(int(e.get('episode_number') or 0) == int(episode) for e in episodes)

def _absolute_fallback_stills(tmdb_id, season, episode, absolute):
    """TMDb has no such season/episode (a show TMDb keeps as one season): the absolute number is the episode's place in
    TMDb's own numbering, so its stills come from that position (S04E01 = absolute 47 = TMDb S01E47)."""
    from apis.tmdb_api import tmdb_episode_stills
    try:
        if _tmdb_has_episode(tmdb_id, season, episode) or not _tmdb_has_episode(tmdb_id, 1, absolute):
            return []
        urls = tmdb_episode_stills(tmdb_id, 1, int(absolute)) or []
        kodi_utils.logger('TMDbRandomBag', 'still fallback tmdb %s S%sE%s -> S01E%02d (absolute): %d still(s)' % (
            tmdb_id, season, episode, int(absolute), len(urls)))
        return urls
    except Exception as exc:
        kodi_utils.logger('TMDbRandomBag', 'still fallback failed tmdb %s S%sE%s: %s' % (tmdb_id, season, episode, exc))
        return []
def _download_episode_stills(tmdb_id, season, episode, title='', absolute=None):
    from apis.tmdb_api import tmdb_episode_stills
    from modules.settings import tmdb_api_key
    if tmdb_api_key() in (None, '', 'empty_setting'):
        kodi_utils.logger('TMDbRandomBag', 'no TMDb API key: episode stills not fetched for tmdb %s S%sE%s (set it under Meta Accounts > TMDb)' % (tmdb_id, season, episode))
        return 0
    urls = tmdb_episode_stills(tmdb_id, season, episode) or []
    if not urls and absolute:
        urls = _absolute_fallback_stills(tmdb_id, season, episode, absolute)
    dbcon = _db()
    now = _now()
    downloaded = 0
    try:
        dbcon.execute(
            'INSERT OR IGNORE INTO episode_still_sets '
            '(tmdb_id, season, episode, title, created_at, fetched_at, last_played, cycle, last_image) '
            'VALUES (?, ?, ?, ?, ?, ?, ?, 1, "")',
            (str(tmdb_id), int(season), int(episode), str(title or ''), now, now, _show_last_played(tmdb_id))
        )
        folder = os.path.join(_profile_dir(), str(tmdb_id), str(season), str(episode))
        if urls and _ensure_dir(folder):
            import requests
            session = requests.Session()
            for url in urls:
                if not url:
                    continue
                key = hashlib.sha1(str(url).encode('utf-8')).hexdigest()
                existing = dbcon.execute(
                    'SELECT local_path FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                    (str(tmdb_id), int(season), int(episode), key)
                ).fetchone()
                if existing and _file_size(existing[0]):
                    continue
                extension = os.path.splitext(str(url).split('?', 1)[0])[1].lower()
                if extension not in ('.jpg', '.jpeg', '.png', '.webp'):
                    extension = '.jpg'
                local_path = os.path.join(folder, key + extension)
                try:
                    response = session.get(url, timeout=(8, 20))
                    response.raise_for_status()
                    content = response.content
                    if not content:
                        continue
                    with open(local_path, 'wb') as image_file:
                        image_file.write(content)
                    size = len(content)
                    try:
                        dbcon.execute(
                            'INSERT OR REPLACE INTO episode_stills '
                            '(tmdb_id, season, episode, image_key, source_url, local_path, size_bytes, created_at, last_access, drawn_cycle) '
                            'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
                            (str(tmdb_id), int(season), int(episode), key, str(url), local_path, size, now, now)
                        )
                        downloaded += 1
                    except Exception:
                        try: os.remove(local_path)
                        except Exception: pass
                        raise
                except Exception as exc:
                    kodi_utils.logger('TMDbRandomBag', 'Still download failed (%s S%sE%s): %s' % (tmdb_id, season, episode, exc))
        valid_stills = dbcon.execute(
            'SELECT COUNT(*) FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=?',
            (str(tmdb_id), int(season), int(episode))
        ).fetchone()[0]
        fetched_at = now if (not urls or valid_stills) else now - _SET_REFRESH_SECONDS + (4 * 3600)
        dbcon.execute(
            'UPDATE episode_still_sets SET fetched_at=?, title=CASE WHEN ? != "" THEN ? ELSE title END, '
            'last_played=? WHERE tmdb_id=? AND season=? AND episode=?',
            (fetched_at, str(title or ''), str(title or ''), _show_last_played(tmdb_id), str(tmdb_id), int(season), int(episode))
        )
        dbcon.commit()
    finally:
        try: dbcon.close()
        except Exception: pass
    purge_expired_and_over_limit(protect_tmdb_id=tmdb_id, protect_episode=(tmdb_id, season, episode), force=True)
    return downloaded


def _ensure_episode_set(tmdb_id, season, episode, title='', absolute=None):
    dbcon = _db()
    try:
        row = dbcon.execute(
            'SELECT fetched_at FROM episode_still_sets WHERE tmdb_id=? AND season=? AND episode=?',
            (str(tmdb_id), int(season), int(episode))
        ).fetchone()
        count = int(dbcon.execute(
            'SELECT COUNT(*) FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=?',
            (str(tmdb_id), int(season), int(episode))
        ).fetchone()[0] or 0)
        files_ok = 0
        if count:
            rows = dbcon.execute(
                'SELECT image_key, local_path FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=?',
                (str(tmdb_id), int(season), int(episode))
            ).fetchall()
            for image_key, file_path in rows:
                if _file_size(file_path):
                    files_ok += 1
                else:
                    dbcon.execute(
                        'DELETE FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                        (str(tmdb_id), int(season), int(episode), image_key)
                    )
            dbcon.commit()
        # Sparse sets (0–1 still) refresh sooner so a prior en,null-filtered fetch can be replaced
        # with the full still list after the language-filter fix.
        refresh_window = _SET_REFRESH_SECONDS if files_ok >= 2 else min(_SET_REFRESH_SECONDS, 3600)
        if row and files_ok == count and files_ok and _now() - int(row[0] or 0) < refresh_window:
            dbcon.execute(
                'UPDATE episode_still_sets SET last_played=? WHERE tmdb_id=? AND season=? AND episode=?',
                (_show_last_played(tmdb_id), str(tmdb_id), int(season), int(episode))
            )
            return True
        if row and count == 0 and not absolute and _now() - int(row[0] or 0) < refresh_window:
            return True  # Empty TMDb still set is also cached; no repeat API call.
    finally:
        try: dbcon.close()
        except Exception: pass
    _download_episode_stills(tmdb_id, season, episode, title, absolute)
    return True


def ensure_episode_set(tmdb_id, season, episode, title='', absolute=None):
    """Seed one episode's still set (TMDb, with the absolute-number fallback) without drawing a still."""
    try:
        return _ensure_episode_set(str(tmdb_id), int(season), int(episode), title, absolute)
    except Exception as exc:
        kodi_utils.logger('TMDbRandomBag', 'seed failed tmdb %s S%sE%s: %s' % (tmdb_id, season, episode, exc))
        return False

def pick_next(tmdb_id, season, episode, title='', absolute=None):
    """Return one persistent local still, advancing the episode's no-repeat bag."""
    try:
        tmdb_id, season, episode = str(tmdb_id), int(season), int(episode)
        if absolute is None:
            from apis.tmdb_api import absolute_for_tmdb_episode
            absolute = absolute_for_tmdb_episode(tmdb_id, season, episode)
        _ensure_episode_set(tmdb_id, season, episode, title, absolute)
        dbcon = _db()
        try:
            row = dbcon.execute(
                'SELECT cycle, last_image FROM episode_still_sets WHERE tmdb_id=? AND season=? AND episode=?',
                (tmdb_id, season, episode)
            ).fetchone()
            if not row:
                import xbmc
                xbmc.log('[NIGHTSHIFT TMDb stills] no still set for tmdb %s S%sE%s: TMDb returned no stills or the download failed' % (tmdb_id, season, episode), xbmc.LOGINFO)
                return ''
            cycle, last_image = int(row[0] or 1), str(row[1] or '')
            candidates = dbcon.execute(
                'SELECT image_key, local_path FROM episode_stills '
                'WHERE tmdb_id=? AND season=? AND episode=? AND drawn_cycle < ?',
                (tmdb_id, season, episode, cycle)
            ).fetchall()
            candidates = [(key, path) for key, path in candidates if _file_size(path)]
            if not candidates:
                cycle += 1
                candidates = dbcon.execute(
                    'SELECT image_key, local_path FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=?',
                    (tmdb_id, season, episode)
                ).fetchall()
                candidates = [(key, path) for key, path in candidates if _file_size(path)]
            if not candidates:
                kodi_utils.logger('TMDbRandomBag', 'no TMDb still for tmdb %s S%sE%s: TMDb returned none, or every downloaded file is missing' % (tmdb_id, season, episode))
                return ''
            if len(candidates) > 1:
                nonrepeat = [i for i in candidates if i[0] != last_image]
                if nonrepeat:
                    candidates = nonrepeat
            image_key, local_path = random.choice(candidates)
            now = _now()
            dbcon.execute(
                'UPDATE episode_stills SET drawn_cycle=?, last_access=? '
                'WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                (cycle, now, tmdb_id, season, episode, image_key)
            )
            dbcon.execute(
                'UPDATE episode_still_sets SET cycle=?, last_image=?, last_played=? '
                'WHERE tmdb_id=? AND season=? AND episode=?',
                (cycle, image_key, _show_last_played(tmdb_id), tmdb_id, season, episode)
            )
            dbcon.commit()
        finally:
            dbcon.close()
        try:
            purge_expired_and_over_limit(protect_tmdb_id=tmdb_id, protect_episode=(tmdb_id, season, episode))
        except Exception as purge_exc:
            kodi_utils.logger('TMDbRandomBag', 'cache purge after a draw failed: %s' % purge_exc)
        return local_path
    except Exception as exc:
        kodi_utils.logger('TMDbRandomBag', 'Bag draw failed: %s' % exc)
        return ''


def current_image(tmdb_id, season, episode):
    """Return persisted current bag image without advancing it; empty if not seeded yet."""
    try:
        dbcon = _db()
        try:
            row = dbcon.execute(
                'SELECT s.last_image, i.local_path FROM episode_still_sets s JOIN episode_stills i '
                'ON i.tmdb_id=s.tmdb_id AND i.season=s.season AND i.episode=s.episode AND i.image_key=s.last_image '
                'WHERE s.tmdb_id=? AND s.season=? AND s.episode=?',
                (str(tmdb_id), int(season), int(episode))
            ).fetchone()
            return row[1] if row and _file_size(row[1]) else ''
        finally:
            dbcon.close()
    except Exception:
        return ''


def purge_all():
    """Remove only TMDb Random Bag Episode Stills files and database data."""
    dbcon = _db()
    removed_files = 0
    removed_bytes = 0
    try:
        rows = dbcon.execute('SELECT tmdb_id, season, episode, image_key, local_path FROM episode_stills').fetchall()
        for tmdb_id, season, episode, image_key, file_path in rows:
            try:
                size = _file_size(file_path)
                if file_path and os.path.isfile(file_path):
                    os.remove(file_path)
                dbcon.execute(
                    'DELETE FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                    (str(tmdb_id), int(season), int(episode), str(image_key))
                )
                if size:
                    removed_files += 1
                    removed_bytes += size
            except Exception as exc:
                kodi_utils.logger('TMDbRandomBag', 'Purge-all could not remove %s: %s' % (file_path, exc))
        folder = _profile_dir()
        try:
            if os.path.isdir(folder):
                for root, dirs, files in os.walk(folder, topdown=False):
                    for name in files:
                        file_path = os.path.join(root, name)
                        try:
                            size = _file_size(file_path)
                            os.remove(file_path)
                            removed_files += 1
                            removed_bytes += size
                        except Exception:
                            pass
                    for name in dirs:
                        try: os.rmdir(os.path.join(root, name))
                        except Exception: pass
                try: os.rmdir(folder)
                except Exception: pass
        except Exception:
            pass
        # Remove index records only after the file is gone (or was already missing).
        for tmdb_id, season, episode, image_key, file_path in dbcon.execute(
                'SELECT tmdb_id, season, episode, image_key, local_path FROM episode_stills').fetchall():
            if not _file_size(file_path):
                dbcon.execute(
                    'DELETE FROM episode_stills WHERE tmdb_id=? AND season=? AND episode=? AND image_key=?',
                    (str(tmdb_id), int(season), int(episode), str(image_key))
                )
        dbcon.execute('DELETE FROM episode_still_sets WHERE NOT EXISTS '
                      '(SELECT 1 FROM episode_stills i WHERE i.tmdb_id=episode_still_sets.tmdb_id '
                      'AND i.season=episode_still_sets.season AND i.episode=episode_still_sets.episode)')
        dbcon.commit()
        dbcon.execute('VACUUM')
    finally:
        try: dbcon.close()
        except Exception: pass
    return removed_files, removed_bytes

def cache_stats():
    dbcon = _db()
    try:
        rows, size = dbcon.execute('SELECT COUNT(*), COALESCE(SUM(size_bytes),0) FROM episode_stills').fetchone()
        return int(rows or 0), int(size or 0)
    finally:
        dbcon.close()


def preload_show_episode_stills(tmdb_id, title='', seasons=None, meta=None):
    """Background-fill still bags for every episode of a show (seasons / episodes / extras only — never calendars).

    Safe to call often: each episode set is cached; work runs on a daemon thread.
    """
    try:
        tmdb_id = str(tmdb_id or '').strip()
        if not tmdb_id or tmdb_id in ('0', 'None'):
            return
        # Skip when skin is not using TMDb episode backgrounds
        try:
            from modules import kodi_utils
            if not kodi_utils.get_visibility('String.IsEqual(Skin.String(ns_episode_bg_source),tmdb)'):
                return
        except Exception:
            pass
        import threading
        def _worker():
            try:
                from modules.metadata import episodes_meta, tvshow_meta
                from modules.settings import tmdb_api_key, mpaa_region
                from modules.utils import get_datetime
                show_meta = meta
                if not show_meta or not show_meta.get('season_data'):
                    show_meta = tvshow_meta('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime()) or {}
                season_nums = seasons
                if not season_nums:
                    season_nums = [int(s.get('season_number')) for s in (show_meta.get('season_data') or [])
                                   if int(s.get('season_number') or -1) >= 0]
                    # TMDb specials are season 0 even when season_data omitted the specials row.
                    if 0 not in season_nums:
                        season_nums = [0] + season_nums
                total = 0
                for season in season_nums:
                    try:
                        rows = episodes_meta(int(season), show_meta, include_simkl_images=False) or []
                    except Exception:
                        rows = []
                    for row in rows:
                        try:
                            ep = int(row.get('episode') or 0)
                        except Exception:
                            continue
                        if ep < 1:
                            continue
                        _ensure_episode_set(tmdb_id, int(season), ep, title or show_meta.get('title') or '')
                        total += 1
                try:
                    from modules import kodi_utils
                    kodi_utils.logger('TMDbRandomBag', 'preloaded stills for tmdb %s: %d episode set(s)' % (tmdb_id, total))
                except Exception:
                    pass
            except Exception as exc:
                try:
                    from modules import kodi_utils
                    kodi_utils.logger('TMDbRandomBag', 'preload failed tmdb %s: %s' % (tmdb_id, exc))
                except Exception:
                    pass
        threading.Thread(target=_worker, name='NS-TMDbStillPreload', daemon=True).start()
    except Exception:
        pass
