# -*- coding: utf-8 -*-
"""NIGHTSHIFT artwork: one picture per section, alternating between a 'framed' and a 'cutout' style on every Kodi start.
Only artwork selection lives here. Scrapers, source results and the CRT dialog pages are not touched."""
import os, sys
from urllib.parse import parse_qs

STYLES = ('framed', 'cutout')
STYLE_PROP = 'nightshift.style'
SECTIONS = ('home', 'movies', 'tv', 'anime', 'calendar', 'search')

def _addon():
	import xbmcaddon
	return xbmcaddon.Addon('plugin.video.nightshift')

def _state_file():
	import xbmcvfs
	return os.path.join(xbmcvfs.translatePath(_addon().getAddonInfo('profile')), 'nightshift_style.txt')

def _read_state():
	try:
		with open(_state_file()) as f: return f.read().strip()
	except Exception: return ''

def startup_flip():
	"""Called once per Kodi start by the service: framed -> cutout -> framed -> ..."""
	import xbmc, xbmcgui
	last = _read_state()
	style = STYLES[1] if last == STYLES[0] else STYLES[0]
	try:
		path = _state_file(); os.makedirs(os.path.dirname(path), exist_ok=True)
		with open(path, 'w') as f: f.write(style)
	except Exception: pass
	xbmcgui.Window(10000).setProperty(STYLE_PROP, style)
	xbmc.log('###NIGHTSHIFT###: NIGHTSHIFT startup style -> %s' % style, 1)
	return style

def current_style():
	import xbmcgui
	style = xbmcgui.Window(10000).getProperty(STYLE_PROP)
	if style not in STYLES: style = _read_state() or STYLES[0]
	return style if style in STYLES else STYLES[0]

def current_section():
	"""Which section of the addon is being listed, read from the plugin URL."""
	try: q = parse_qs(sys.argv[2].lstrip('?'))
	except Exception: return 'home'
	g = lambda k: (q.get(k) or [''])[0]
	mode, action, mtype = g('mode'), g('action'), g('menu_type')
	hay = ' '.join((mode, action, g('list_name'), g('name'))).lower()
	if 'calendar' in hay: return 'calendar'
	if 'search' in hay: return 'search'
	if mtype == 'anime' or 'anime' in hay: return 'anime'
	if mtype == 'tvshow' or 'tvshow' in hay or 'tv show' in hay: return 'tv'
	if mtype == 'movie' or 'movie' in hay: return 'movies'
	return 'home'

SKIN_BACKGROUNDS = {'home': 'home.jpg', 'movies': 'movies.jpg', 'tv': 'tvshows.jpg', 'anime': 'anime.jpg', 'calendar': 'anime.jpg', 'search': 'search.jpg'}

def skin_picture(section):
	"""The NIGHTSHIFT skin ships one picture per section; use it so list backgrounds match the home screen."""
	try:
		import xbmc, xbmcvfs
		if xbmc.getSkinDir() != 'skin.nightshift': return None
		path = xbmcvfs.translatePath('special://skin/media/backgrounds/%s' % SKIN_BACKGROUNDS.get(section, 'home.jpg'))
		return path if os.path.exists(path) else None
	except Exception: return None

def section_fanart(section=None):
	"""Full path of the picture for this section in the current style. Falls back to the framed picture, then to None."""
	section = section or current_section()
	picture = skin_picture(section)
	if picture: return picture
	base = os.path.join(_addon().getAddonInfo('path'), 'resources', 'media', 'nightshift')
	for style in (current_style(), STYLES[0]):
		path = os.path.join(base, '%s_%s.jpg' % (section, style))
		if os.path.exists(path): return path
	return None
