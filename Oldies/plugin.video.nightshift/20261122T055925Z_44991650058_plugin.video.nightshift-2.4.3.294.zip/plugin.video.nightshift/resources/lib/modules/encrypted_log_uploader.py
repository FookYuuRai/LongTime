# -*- coding: utf-8 -*-
"""Encrypt Kodi logs locally and upload them to a GitHub repository."""

import base64
import hashlib
import os
import time
from datetime import datetime, timezone
from urllib.parse import quote

from modules import kodi_utils as k

_MAGIC = b'NSLOG01\n'  # 8 bytes; format version 1
_SALT_BYTES = 16
_NONCE_BYTES = 12
_TAG_BYTES = 16
_SCRYPT_N = 2 ** 14
_SCRYPT_R = 8
_SCRYPT_P = 1
_GITHUB_API = 'https://api.github.com'
_DEFAULT_REPOSITORY = 'FookYuuRai/logs'


def _derive_key(passphrase, salt):
    return hashlib.scrypt(
        passphrase.encode('utf-8'),
        salt=salt,
        n=_SCRYPT_N,
        r=_SCRYPT_R,
        p=_SCRYPT_P,
        maxmem=64 * 1024 * 1024,
        dklen=32,
    )


def encrypt_log_bytes(plaintext, passphrase):
    """Return NSLOG01 container bytes using AES-256-GCM."""
    from Cryptodome.Cipher import AES

    salt = os.urandom(_SALT_BYTES)
    nonce = os.urandom(_NONCE_BYTES)
    aad = _MAGIC + salt + nonce
    key = _derive_key(passphrase, salt)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len=_TAG_BYTES)
    cipher.update(aad)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    return aad + ciphertext + tag


def _prompt_secret(heading):
    option = getattr(k.xbmcgui, 'ALPHANUM_HIDE_INPUT', 1)
    return (k.kodi_dialog().input(heading, option=option) or '').strip()


def _github_headers(token):
    return {
        'Accept': 'application/vnd.github+json',
        'Authorization': 'Bearer %s' % token,
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Nightshift-Encrypted-Kodi-Log-Uploader',
    }


def _get_default_branch(repository, token):
    """Read the target repository's actual default branch from GitHub."""
    import requests

    owner, repo = repository.split('/', 1)
    endpoint = '%s/repos/%s/%s' % (
        _GITHUB_API, quote(owner, safe=''), quote(repo, safe=''))
    response = requests.get(endpoint, headers=_github_headers(token), timeout=(15, 30))
    if response.status_code != 200:
        try:
            detail = response.json().get('message', '')
        except Exception:
            detail = ''
        raise RuntimeError('Could not read repository default branch (HTTP %s): %s' % (response.status_code, detail))
    branch = response.json().get('default_branch')
    if not isinstance(branch, str) or not branch.strip():
        raise RuntimeError('GitHub did not report a default branch for this repository.')
    return branch.strip()


def _github_upload(repository, branch, token, filename, encrypted_data):
    import requests

    owner, repo = repository.split('/', 1)
    endpoint = '%s/repos/%s/%s/contents/logs/%s' % (
        _GITHUB_API, quote(owner, safe=''), quote(repo, safe=''), quote(filename, safe=''))
    payload = {
        'message': 'Add encrypted Kodi log %s' % filename,
        'content': base64.b64encode(encrypted_data).decode('ascii'),
        'branch': branch,
    }
    return requests.put(endpoint, headers=_github_headers(token), json=payload, timeout=(15, 60))


def upload_logfile(params=None):
    import json as json_module
    from modules.utils import copy2clip

    log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
    list_items = [{'line1': item[0]} for item in log_files]
    kwargs = {
        'items': json_module.dumps(list_items),
        'heading': 'Choose Which Log File to Encrypt and Upload',
        'narrow_window': 'true',
    }
    selected = k.select_dialog(log_files, **kwargs)
    if selected is None:
        return
    log_name, log_filename = selected
    if not k.confirm_dialog(heading=log_name, text='Encrypt this Kodi log and upload it to GitHub?'):
        return

    # Fixed to the dedicated private log repository. The GitHub token should
    # be fine-grained and restricted to this repository only.
    repository = _DEFAULT_REPOSITORY

    token = _prompt_secret('GitHub fine-grained token (Contents: Read and write)')
    if not token:
        return

    passphrase = _prompt_secret('Encryption passphrase (at least 12 characters)')
    if len(passphrase) < 12:
        return k.ok_dialog(heading='Encryption Passphrase', text='Use an encryption passphrase with at least 12 characters.')
    passphrase_confirm = _prompt_secret('Confirm encryption passphrase')
    if passphrase != passphrase_confirm:
        return k.ok_dialog(heading='Encryption Passphrase', text='The passphrases did not match. Nothing was uploaded.')

    log_path = k.translate_path('special://logpath/%s' % log_filename)
    if not k.path_exists(log_path):
        return k.ok_dialog(heading='GitHub Log Upload', text='The selected Kodi log file does not exist.')

    busy_shown = False
    try:
        k.show_busy_dialog()
        busy_shown = True
        with k.open_file(log_path, 'rb') as handle:
            plaintext = handle.read()
        encrypted_data = encrypt_log_bytes(plaintext, passphrase)

        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
        suffix = 'current' if log_filename == 'kodi.log' else 'previous'
        # Add microseconds to avoid collisions if two uploads happen within one second.
        unique = '%06d' % (int(time.time() * 1000000) % 1000000)
        filename = 'kodi-%s-%s-%s.enc' % (timestamp, suffix, unique)
        branch = _get_default_branch(repository, token)
        response = _github_upload(repository, branch, token, filename, encrypted_data)
    except ImportError:
        return k.ok_dialog(
            heading='Encryption Dependency Missing',
            text='AES-256-GCM support is unavailable. Install or enable the Kodi dependency script.module.pycryptodome, then try again.')
    except Exception as exc:
        try:
            k.logger('Encrypted Log Uploader', '%s: %s' % (type(exc).__name__, str(exc)[:300]))
        except Exception:
            pass
        return k.ok_dialog(heading='GitHub Log Upload', text='The log could not be encrypted or uploaded. Check the Kodi log for details and try again.')
    finally:
        if busy_shown:
            k.hide_busy_dialog()

    if response.status_code not in (200, 201):
        try:
            detail = response.json().get('message', '')
        except Exception:
            detail = ''
        if response.status_code == 401:
            message = 'GitHub rejected the token. Check that it is valid and has access to this repository.'
        elif response.status_code == 403:
            message = 'GitHub denied the upload. Check the token permissions and repository rules.'
        elif response.status_code == 404:
            message = 'GitHub could not find the repository, or the token cannot access it.'
        elif response.status_code == 409:
            message = 'GitHub reported a conflict. Try uploading again.'
        else:
            message = 'GitHub upload failed (HTTP %s).' % response.status_code
        if detail:
            message += '[CR]' + str(detail)[:250]
        return k.ok_dialog(heading='GitHub Log Upload Failed', text=message)

    file_url = 'https://github.com/%s/blob/%s/logs/%s' % (
        repository, quote(branch, safe=''), quote(filename, safe=''))
    try:
        copy2clip(file_url)
    except Exception:
        pass
    return k.ok_dialog(
        heading='Encrypted Kodi Log Uploaded',
        text='Only the encrypted file was uploaded. The encryption passphrase was not saved.[CR][CR]Repository: [B]%s[/B][CR]Branch: [B]%s[/B][CR]File: [B]logs/%s[/B][CR][CR]The GitHub file URL was copied to the clipboard.[CR][CR]Keep your passphrase safe: it cannot be recovered if lost.' % (repository, branch, filename),
        scroll=True,
    )
