# -*- coding: utf-8 -*-
"""Nightshift autocomplete using the official TMDB v3 API.

The v3 API key is the NIGHTSHIFT setting nightshift.tmdb_api (Settings > TMDb API > API Key (v3 API)).
It is read on each request, so a key entered in the settings window applies to the next search.
Existing fetch_items/fetch_suggestions/scope_for interfaces are preserved.
"""
import threading
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import requests
import xbmc

SEARCH_BASE = 'https://api.themoviedb.org/3/search/%s'
TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 50
MAX_PAGES = 3
MIN_GAP_SECONDS = 0.3  # Conservative local pacing, not TMDB's official limit.
RATE_LIMIT_SECONDS = 60
CACHE_TTL_SECONDS = 600

_cache = {}
_cache_order = []
_cache_times = {}
_cache_lock = threading.Lock()
_request_lock = threading.Lock()
_last_request = [0.0]
_cooldown_until = [0.0]
_session = None
_language = 'en-US'

# Values the settings schema ships as "no key yet" (see caches/settings_cache.py, tmdb_api default).
_NO_KEY_VALUES = ('', 'API_HERE', 'empty_setting')

class TmdbRateLimited(RuntimeError):
    """A 429 response or an active request cooldown."""

class TmdbAuthenticationError(RuntimeError):
    """Missing or rejected TMDB credentials."""


def _tmdb_key():
    """The TMDb v3 API key from NIGHTSHIFT settings (nightshift.tmdb_api), or '' when none is set.

    Imported lazily so this module can be imported without the settings layer loaded.
    """
    from modules.settings import tmdb_api_key
    value = str(tmdb_api_key() or '').strip()
    return '' if value in _NO_KEY_VALUES else value


def is_cooling_down():
    return time.monotonic() < _cooldown_until[0]


def _retry_delay(value):
    try:
        return max(1.0, float(value))
    except (TypeError, ValueError):
        try:
            dt = parsedate_to_datetime(value)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return max(1.0, (dt - datetime.now(timezone.utc)).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return float(RATE_LIMIT_SECONDS)


def _search(query, endpoint='multi', page=1):
    """One TMDb API request with the v3 key from settings. No header probes or website fallback."""
    global _session
    if endpoint not in ('multi', 'movie', 'tv', 'person', 'collection'):
        raise ValueError('Unsupported TMDB search endpoint')
    api_key = _tmdb_key()
    if not api_key:
        raise TmdbAuthenticationError('No TMDb API key in NIGHTSHIFT settings (TMDb API > API Key)')
    with _request_lock:
        if is_cooling_down():
            raise TmdbRateLimited('TMDB cooldown is active')
        gap = MIN_GAP_SECONDS - (time.monotonic() - _last_request[0])
        if gap > 0:
            time.sleep(gap)
        if _session is None:
            _session = requests.Session()
        headers = {'Accept': 'application/json'}
        params = {'api_key': api_key, 'query': query, 'language': _language,
                  'page': page, 'include_adult': 'false'}
        try:
            response = _session.get(SEARCH_BASE % endpoint, params=params,
                                    headers=headers, timeout=TIMEOUT)
        except requests.RequestException:
            # Never log the request URL: it may contain the API key.
            raise RuntimeError('TMDB API network request failed') from None
        finally:
            _last_request[0] = time.monotonic()
        if response.status_code == 429:
            delay = _retry_delay(response.headers.get('Retry-After'))
            _cooldown_until[0] = time.monotonic() + delay
            raise TmdbRateLimited('TMDB HTTP 429; paused for %.1f seconds' % delay)
        if response.status_code in (401, 403):
            raise TmdbAuthenticationError('TMDB rejected authentication/access (HTTP %s)' % response.status_code)
        if response.status_code != 200:
            raise RuntimeError('TMDB search failed (HTTP %s)' % response.status_code)
        try:
            data = response.json()
        except ValueError:
            raise RuntimeError('TMDB returned invalid JSON') from None
        if not isinstance(data, dict) or not isinstance(data.get('results'), list):
            raise RuntimeError('TMDB response does not contain a results list')
        return data


IMAGE_URL = 'https://image.tmdb.org/t/p/original%s'   # original size, same as the skin's list backgrounds
MEDIA_LABEL = {'movie': 'Movie', 'tv': 'TV show', 'anime': 'Anime', 'person': 'Person', 'collection': 'Collection'}
ANIMATION_GENRE = 16

# What the person is searching for -> (kinds shown, anime filter, heading, TMDb search endpoint).
# anime filter: True = anime only, False = TV without anime, None = either.
# Endpoints: multi (keywords and every other search), movie, tv (TV and anime), person, collection.
ALL_KINDS = ('movie', 'tv', 'person')
ENDPOINT_KIND = {'movie': 'movie', 'tv': 'tv', 'person': 'person', 'collection': 'collection'}


def scope_for(media_type='', search_type='media_title'):
    """Suggestion scope for a search entry: (kinds, anime, heading, endpoint). Unknown searches use multi."""
    media_type, search_type = (media_type or ''), (search_type or 'media_title')
    if search_type == 'people':
        return ('person',), None, 'Search People', 'person'
    if search_type == 'tmdb_collection':
        return ('collection',), None, 'Search Collections', 'collection'
    if search_type == 'tmdb_keyword':
        return ALL_KINDS, None, 'Search Keywords', 'multi'
    if search_type == 'media_title':
        if media_type == 'movie':
            return ('movie',), None, 'Search Movies', 'movie'
        if media_type == 'tv_show':
            return ('tv',), False, 'Search TV Shows', 'tv'
        if media_type == 'anime':
            return ('tv',), True, 'Search Anime', 'tv'
        return ('tv',), None, 'Search TV Shows & Anime', 'tv'
    return ALL_KINDS, None, 'Search', 'multi'


def _image(path):
    return IMAGE_URL % path if isinstance(path, str) and path.startswith('/') else ''


def _backdrop(entry, kind):
    """TMDb backdrop for a result. A person has no backdrop of their own, so use the first title they are known for."""
    if kind == 'person':
        for work in entry.get('known_for') or []:
            if isinstance(work, dict) and isinstance(work.get('backdrop_path'), str) and work['backdrop_path'].startswith('/'):
                return _image(work['backdrop_path'])
        return ''
    return _image(entry.get('backdrop_path'))


def _is_anime(entry):
    """Local Japanese-animation heuristic, not an official TMDB anime flag."""
    genres = entry.get('genre_ids')
    japanese = entry.get('original_language') == 'ja' or 'JP' in (entry.get('origin_country') or [])
    if isinstance(genres, list):
        return ANIMATION_GENRE in genres and japanese
    return False


def items_from_search(data, default_kind=None):
    """Every movie, TV show, person and collection in a TMDb search response, in order, with artwork and year.
    /search/multi tags each result with media_type; /search/movie, /tv, /person and /collection do not, so
    `default_kind` names what that endpoint returns. Each item carries 'kind' and 'anime' for filtering."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    items = []
    for entry in results:
        if not isinstance(entry, dict):
            continue
        kind = entry.get('media_type') or default_kind
        if kind == 'movie':
            title, date = entry.get('title') or entry.get('original_title'), entry.get('release_date')
        elif kind == 'tv':
            title, date = entry.get('name') or entry.get('original_name'), entry.get('first_air_date')
        elif kind in ('person', 'collection'):
            title, date = entry.get('name') or entry.get('original_name'), None
        else:
            continue
        if not isinstance(title, str) or not title.strip():
            continue
        anime = kind == 'tv' and _is_anime(entry)
        items.append({
            'id': entry.get('id'),
            'poster': _image(entry.get('poster_path')),
            'title': title.strip(),
            'kind': kind,
            'anime': anime,
            'media': MEDIA_LABEL['anime' if anime else kind],
            'year': date[:4] if isinstance(date, str) and date[:4].isdigit() else '',
            'backdrop': _backdrop(entry, kind),
            'portrait': _image(entry.get('profile_path')) if kind == 'person' else '',
        })
    return items


def filter_items(items, scope, limit=None):
    """Keep only what this search mode can open, drop repeated titles, stop at `limit`."""
    kinds, anime = scope[0], scope[1]
    if limit is not None and int(limit) <= 0:
        return []
    limit = int(limit) if limit is not None else None
    out, seen = [], set()
    for item in items:
        if item['kind'] not in kinds:
            continue
        if anime is True and not item['anime']:
            continue
        if anime is False and item['anime']:
            continue
        key = item['title'].casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
        if limit and len(out) >= limit:
            break
    return out


def titles_from_search(data, limit=DEFAULT_LIMIT, scope=None):
    scope = scope or (ALL_KINDS, None, 'Search', 'multi')
    return [item['title'] for item in filter_items(items_from_search(data), scope, limit)]


def _remember(key, items):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = items
        _cache_times[key] = time.monotonic()
        while len(_cache_order) > CACHE_LIMIT:
            oldest = _cache_order.pop(0)
            _cache.pop(oldest, None)
            _cache_times.pop(oldest, None)


def _fetch_pages(query, endpoint, default_kind=None):
    """Raw items from up to MAX_PAGES pages of one endpoint. Page 1 must answer or this raises, so the caller can
    fall back. A later page that fails keeps the pages already fetched."""
    data = _search(query, endpoint, 1)
    items = items_from_search(data, default_kind)
    total = data.get('total_pages')
    last = min(total, MAX_PAGES) if isinstance(total, int) else MAX_PAGES
    for page in range(2, last + 1):
        try:
            data = _search(query, endpoint, page)
        except Exception as exc:
            xbmc.log(f"[NIGHTSHIFT keyboard] /search/{endpoint} page {page} failed for {query!r}: {exc}",
                     xbmc.LOGWARNING)
            break
        items += items_from_search(data, default_kind)
    return items


def _load(query, endpoint):
    """Keep partial pages; never fall back after auth errors or rate limiting."""
    try:
        return _fetch_pages(query, endpoint, ENDPOINT_KIND.get(endpoint))
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] TMDB /search/{endpoint}: {exc}", xbmc.LOGWARNING)
        return None


def fetch_items(text, limit=DEFAULT_LIMIT, scope=None):
    """Up to `limit` result dicts (title, kind, media, year, backdrop) for `text`, limited to what `scope`
    (see scope_for) can open. The cache is per endpoint and holds the unfiltered response. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    scope = scope or (ALL_KINDS, None, 'Search', 'multi')
    endpoint = scope[3]
    key = '%s|%s|%s' % (_language, endpoint, query.casefold())
    with _cache_lock:
        cached = _cache.get(key)
        if time.monotonic() - _cache_times.get(key, 0) > CACHE_TTL_SECONDS:
            cached = None
    if cached is None:
        cached = _load(query, endpoint)
        if cached is None:
            return []
        _remember(key, cached)
    return filter_items(cached, scope, limit)


def fetch_suggestions(text, limit=DEFAULT_LIMIT, scope=None):
    return [item['title'] for item in fetch_items(text, limit, scope)]
