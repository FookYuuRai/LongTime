# -*- coding: utf-8 -*-
"""Background pre-warm so first page opens hit the lists cache instead of the network.

Runs once per Kodi start from the service, slowly, and stops on abort, on playback, or when the 'prewarm_lists' setting is off.
It only calls the same cached functions the menus use, so nothing here changes what a page shows.
"""
from modules import kodi_utils, settings

PREWARM_DELAY = 45        # seconds after startup before anything is requested
PREWARM_PAUSE = 0.6       # seconds between requests
PREWARM_TOP = 8           # titles per list whose Related list is warmed


def _enabled():
	try:
		from caches.settings_cache import get_setting
		return get_setting('nightshift.prewarm_lists', 'true') != 'false'
	except Exception: return True


def _should_stop(monitor):
	if monitor.abortRequested() or not _enabled(): return True
	try:
		import xbmc
		return xbmc.Player().isPlaying()
	except Exception: return False


def _pause(monitor, seconds=PREWARM_PAUSE):
	return monitor.waitForAbort(seconds)


def _results(data):
	return [i for i in ((data or {}).get('results') or []) if isinstance(i, dict) and i.get('id')] if isinstance(data, dict) else []


def run(monitor):
	if _pause(monitor, PREWARM_DELAY): return
	try:
		# Rows are only dropped on read when expired, so unvisited ones (yesterday's popular titles) would pile up: purge them once per start.
		from apis import tmdb_api  # import order matters: importing caches.lists_cache first stalls the thread
		from caches.lists_cache import lists_cache
		removed = lists_cache.purge_expired()
		kodi_utils.logger('NIGHTSHIFT', 'Lists Cache: removed %s expired rows' % removed)
	except BaseException as e: kodi_utils.logger('Lists Cache Purge', '%s: %s' % (type(e).__name__, e))
	if not _enabled(): return
	try:
		from apis import tmdb_api
		if settings.tmdb_api_key() in (None, '', 'empty_setting', 'API_HERE'): return
		kodi_utils.logger('NIGHTSHIFT', 'Pre-warm Starting')
		lists = (('movie', tmdb_api.tmdb_movies_popular), ('movie', tmdb_api.tmdb_movies_popular_today),
				('tvshow', tmdb_api.tmdb_tv_popular), ('tvshow', tmdb_api.tmdb_tv_popular_today))
		related_on = settings.related_fallback_mode() != 'off'
		warmed = 0
		for media_type, function in lists:
			if _should_stop(monitor): return
			try: data = function(1)
			except Exception: data = None
			warmed += 1
			if not related_on or _pause(monitor): continue
			from apis.related_fallback import _tmdb_recommendation_ids
			for item in _results(data)[:PREWARM_TOP]:
				if _should_stop(monitor): return
				try: _tmdb_recommendation_ids(media_type, item['id'])
				except Exception: pass
				warmed += 1
				if _pause(monitor): return
		kodi_utils.logger('NIGHTSHIFT', 'Pre-warm Finished (%s requests)' % warmed)
	except Exception as e: kodi_utils.logger('Pre-warm', str(e))
