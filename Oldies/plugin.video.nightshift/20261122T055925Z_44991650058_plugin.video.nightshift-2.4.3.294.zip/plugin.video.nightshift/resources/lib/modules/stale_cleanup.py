# -*- coding: utf-8 -*-
"""Runs once whenever the installed NIGHTSHIFT version changes (zip install / update): makes sure only the freshly installed code
is used - no leftover files from earlier builds, no stale byte-code, no other copy of the addon, no cached search results made by
an older build."""
import os, shutil
from modules import kodi_utils

ADDON_ID = 'plugin.video.nightshift'
KEEP_TOP = ('manifest.txt',)

def _log(msg):
	try: kodi_utils.logger('NIGHTSHIFT', 'StaleCleanup - %s' % msg)
	except Exception: pass

def _remove_pycache(root):
	removed = 0
	for base, dirs, _files in os.walk(root):
		for d in list(dirs):
			if d == '__pycache__':
				shutil.rmtree(os.path.join(base, d), ignore_errors=True)
				dirs.remove(d)
				removed += 1
	return removed

def _prune_to_manifest(addon_path):
	"""Delete files in the addon folder that the installed package did not ship (modules removed in newer builds, renamed files)."""
	manifest = os.path.join(addon_path, 'resources', 'manifest.txt')
	if not os.path.isfile(manifest): return 0
	with open(manifest, encoding='utf-8') as f:
		shipped = {line.strip().replace('\\', '/') for line in f if line.strip()}
	shipped.add('resources/manifest.txt')
	removed = 0
	for base, dirs, files in os.walk(addon_path):
		dirs[:] = [d for d in dirs if d != '__pycache__']
		for name in files:
			rel = os.path.relpath(os.path.join(base, name), addon_path).replace(os.sep, '/')
			if rel not in shipped:
				try: os.remove(os.path.join(base, name)); removed += 1
				except Exception: pass
	for base, dirs, files in os.walk(addon_path, topdown=False):
		if base != addon_path and not os.listdir(base):
			try: os.rmdir(base)
			except Exception: pass
	return removed

def _remove_other_copies(addon_path):
	"""Another folder in the addons directory that declares the same addon id (an old renamed / backup copy) competes with the real one."""
	addons_dir = os.path.dirname(addon_path.rstrip('/\\'))
	removed = []
	for name in os.listdir(addons_dir):
		path = os.path.join(addons_dir, name)
		if os.path.abspath(path) == os.path.abspath(addon_path) or not os.path.isdir(path): continue
		xml = os.path.join(path, 'addon.xml')
		if not os.path.isfile(xml): continue
		try:
			with open(xml, encoding='utf-8', errors='ignore') as f: head = f.read(600)
			if 'id="%s"' % ADDON_ID in head:
				shutil.rmtree(path, ignore_errors=True)
				removed.append(name)
		except Exception: pass
	packages = os.path.join(addons_dir, 'packages')
	if os.path.isdir(packages):
		for name in os.listdir(packages):
			if name.startswith(ADDON_ID) and name.endswith('.zip'):
				try: os.remove(os.path.join(packages, name)); removed.append('packages/' + name)
				except Exception: pass
	return removed

def _clear_search_caches():
	try:
		from caches.main_cache import main_cache
		for like in ('NYAA_%', 'ANIMETOSHO_%', 'FOLDERSCRAPER_%'):
			try: main_cache.delete_like(like)
			except Exception: pass
	except Exception: pass
	try:
		from caches.external_cache import ExternalCache
		ExternalCache().clear_cache()
	except Exception: pass

def run(addon_path, previous_version, new_version):
	_log('%s -> %s' % (previous_version or 'first start', new_version))
	try: _log('pruned %d stale file(s)' % _prune_to_manifest(addon_path))
	except Exception as e: _log('prune failed: %s' % e)
	try: _log('removed %d __pycache__ folder(s)' % _remove_pycache(addon_path))
	except Exception as e: _log('pycache failed: %s' % e)
	try:
		copies = _remove_other_copies(addon_path)
		if copies: _log('removed other copies: %s' % ', '.join(copies))
	except Exception as e: _log('copy check failed: %s' % e)
	_clear_search_caches()
