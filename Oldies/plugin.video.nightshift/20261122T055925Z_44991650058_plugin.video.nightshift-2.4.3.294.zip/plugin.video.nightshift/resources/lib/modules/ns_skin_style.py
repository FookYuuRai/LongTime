# -*- coding: utf-8 -*-
"""Reads the active Nightshift skin's style settings so the search keyboard matches the skin.

Values come from the skin's own tables (Variables.xml: NSPanelTint, NSFocusTextRGBVar, NSOutlineColorVar)
and its unset defaults (NSPanelTint = FFFFFFFF, NSFocusTextRGBVar = FFFFFF, NSOutlineColorVar = FF000000).
The skin does not write these settings itself, so an unset setting uses the table default.
"""
import xbmc

# ns_panel_alpha -> NSPanelTint (skin Variables.xml); unset -> FFFFFFFF
_PANEL_ALPHA = {'10': '1AFFFFFF', '20': '33FFFFFF', '30': '4DFFFFFF', '40': '66FFFFFF', '50': '80FFFFFF',
                '60': '99FFFFFF', '70': 'B3FFFFFF', '80': 'CCFFFFFF', '90': 'E6FFFFFF'}
_PANEL_DEFAULT = 'FFFFFFFF'
# ns_text_color -> NSFocusTextRGBVar; unset -> FFFFFF
_TEXT_RGB = {'1': '55CBFF', '2': '9AE4FF', '3': '00E5FF', '4': 'FFD54F', '5': 'FF9800',
             '6': 'E53935', '7': '39FF6A', '8': 'FF4081', '9': 'B388FF', '10': 'CCCCCC'}
_TEXT_DEFAULT = 'FFFFFF'
# ns_outline_color -> NSOutlineColorVar; unset -> FF000000
_OUTLINE_RGB = {'1': 'FF303030', '2': 'FFFFFFFF', '3': 'FF0D47A1', '4': 'FF1E88E5', '5': 'FF102040',
                '6': 'FF5D0000', '7': 'FF0B3D12', '8': 'FF3A0F5C', '9': 'FF7A5A00'}
_OUTLINE_DEFAULT = 'FF000000'
# The skin's keyboard title colour (DialogKeyboard.xml)
TITLE_RGB = 'FF55CBFF'


# The skin's 16-step ring colour table (Variables.xml: NSRingColorVar_blue / _black / _purple, identical).
RING_COLOURS = {'0': 'FF303030', '1': 'FFFFFFFF', '2': 'FF000000', '3': 'FF2882FF', '4': 'FF0D47A1',
                '5': 'FF102040', '6': 'FF49C9FF', '7': 'FF963CDC', '8': 'FF3A0F5C', '9': 'FFFF4FA3',
                '10': 'FFC62828', '11': 'FF5D0000', '12': 'FFFF8C1A', '13': 'FFFFC107', '14': 'FF2E9E3E',
                '15': 'FF0B3D12'}
# When several rings are on, the first one in this order sets the text colour.
RING_ORDER = ('blue', 'black', 'purple')
RING_TEXT_DEFAULT = 'FFFFFFFF'


def _setting(name):
    return xbmc.getInfoLabel('Skin.String(%s)' % name).strip()


def _has(name):
    return xbmc.getCondVisibility('Skin.HasSetting(%s)' % name)


def ring_text_color():
    """Text colour from the first ring that is on (blue, then black, then purple)."""
    for ring in RING_ORDER:
        if _has('ns_ring_%s_off' % ring):
            continue                       # this ring is switched off in the skin
        return RING_COLOURS.get(_setting('ns_ring_%s_color' % ring), RING_TEXT_DEFAULT)
    return RING_TEXT_DEFAULT


def style_properties():
    """{window property name: ARGB hex} for the keyboard."""
    panel = _PANEL_ALPHA.get(_setting('ns_panel_alpha'), _PANEL_DEFAULT)
    focus_rgb = _TEXT_RGB.get(_setting('ns_text_color'), _TEXT_DEFAULT)
    outline = _OUTLINE_RGB.get(_setting('ns_outline_color'), _OUTLINE_DEFAULT)
    if _has('ns_focus_rings'):
        outline = '00000000'
    return {
        'ns_panel': panel,
        'ns_neon': 'FF' + focus_rgb,
        'ns_outline': outline,
        'ns_title': TITLE_RGB,
        'ns_ring_text': ring_text_color(),
    }
