# -*- coding: utf-8 -*-
import os
import re

# Bundled Scene / P2P groups (TRaSH-style tiers as a static reference — not a live importer).
# Higher score sorts first within the current Results Sorting keys. Quality is never jumped.
_TIER_1 = frozenset((
	'3ctweb', 'aida', 'bhdstudio', 'btw', 'byndr', 'crisc', 'ctrlhd', 'deflate', 'ebp', 'epsilon',
	'flux', 'framestor', 'hifi', 'hone', 'kralimarko', 'kitsune', 'ncmt', 'ntb', 'playnerd', 'pmp',
	'qoq', 'sa89', 'slignome', 'successfulcrab', 'surfinbird', 'tayto', 'tepes', 'tommy', 'visum',
	'xebec',
))
_TIER_2 = frozenset((
	'amb3r', 'bluhd', 'cfl', 'chd', 'crfw', 'd-z0n3', 'd3g', 'decibel', 'don', 'fum', 'geckos',
	'hallowed', 'hdchina', 'hdman', 'hds', 'hidt', 'ijp', 'ika', 'ntg', 'pauliso', 'peculate',
	'pter', 'sigma', 'sicfoi', 'w4nk3r', 'welp',
))
_TIER_3 = frozenset((
	'evo', 'joy', 'kogi', 'monkee', 'phoenix', 'qman', 'strife', 'qxr',
))
_SCORES = {}
for _name in _TIER_1: _SCORES[_name] = 3
for _name in _TIER_2: _SCORES[_name] = 2
for _name in _TIER_3: _SCORES[_name] = 1

# Source / codec tokens that can appear as the last hyphen segment — never treat as a group.
_NOT_GROUP = frozenset((
	'aac', 'amzn', 'atvp', 'av1', 'avc', 'bluray', 'complete', 'criterion', 'dd5', 'ddp5', 'dsnp',
	'dts', 'dv', 'h264', 'h265', 'hdr', 'hdr10', 'hevc', 'hmax', 'hybrid', 'imax', 'internal',
	'multi', 'nf', 'pcok', 'proper', 'repack', 'remux', 'sdr', 'season', 'truehd', 'uhd', 'web',
	'webdl', 'webrip', 'x264', 'x265',
))

_NAME_RE = re.compile(r'[\s_]+')


def _filename_blob(name):
	if not name: return ''
	raw = str(name).split('|')[0].split('?')[0].strip()
	if not raw: return ''
	stem = os.path.splitext(os.path.basename(raw))[0]
	return _NAME_RE.sub('.', stem).strip('.').lower()


def _group_from_blob(blob):
	if not blob: return ''
	bracket = re.search(r'[\[(]([a-z0-9][a-z0-9@.\-]{1,19})[\])]\s*$', blob)
	if bracket:
		token = bracket.group(1).replace('@', '').strip('.')
		if _score_token(token): return token
		blob = blob[:bracket.start()].rstrip('.')
	hyphen = re.search(r'-([a-z0-9][a-z0-9@.]{1,19})$', blob)
	if hyphen:
		return hyphen.group(1).replace('@', '').strip('.')
	return ''


def _score_token(token):
	if not token: return 0
	key = token.lower().replace('@', '')
	if key in _NOT_GROUP: return 0
	direct = _SCORES.get(key)
	if direct: return direct
	# D-Z0N3 stored with hyphen; blob may keep it as d-z0n3 or d.z0n3
	return _SCORES.get(key.replace('.', '-'), 0)


def release_group_boost(item):
	'''Integer 0–3. Safe no-op when the name has no known group.'''
	if not isinstance(item, dict): return 0
	aio = item.get('aio_release_group') or ''
	score = _score_token(str(aio).strip())
	if score: return score
	for key in ('display_name', 'name', 'url'):
		blob = _filename_blob(item.get(key))
		score = _score_token(_group_from_blob(blob))
		if score: return score
		# Known group as a delimited suffix when hyphen parse missed (e.g. D-Z0N3).
		if blob:
			for group, value in _SCORES.items():
				if len(group) < 3: continue
				if blob.endswith('-' + group) or blob.endswith('.' + group):
					return value
	return 0


def group_from_name(name):
	'''Release group tag of a file name: trailing (...x264-NTb, [TGx]) or leading anime-style ([SubsPlease] Show - 01).
	Returns '' when none is found.'''
	try:
		raw = str(name or '').split('|')[0].split('?')[0].strip()
		raw = raw.replace('\\', '/').rsplit('/', 1)[-1]
		raw = re.sub(r'\.(mkv|mp4|avi|m4v|ts|m2ts|wmv|mov|nzb|rar)$', '', raw, flags=re.I)
		lead = re.match(r'^\s*[\[(]([^\])]{2,25})[\])]', raw)
		# trailing alt-title / info parentheses: '... H.264-VARYG (Romelia Senki: ..., Multi-Subs)' -> the group is in front of them
		for _ in range(3):
			tail = re.search(r'\s*[\[(]([^\[\]()]{14,}|[^\[\]()]*[\s,][^\[\]()]*)[\])]\s*$', raw)
			if not tail or tail.start() == 0: break
			raw = raw[:tail.start()].rstrip()
		# short source tags in brackets at the end ('... -Tsundere-Raws (CR)', '[WEB-DL]') are not the group
		for _ in range(3):
			tail = re.search(r'\s*[\[(]([A-Za-z0-9 .\-]{1,12})[\])]\s*$', raw)
			if tail and tail.start() > 0 and (_bad_group(tail.group(1)) or tail.group(1).lower().replace(' ', '') in _SOURCE_TAGS):
				raw = raw[:tail.start()].rstrip()
			else: break
		spaced = raw
		raw = _NAME_RE.sub('.', raw).strip('.')
		# '...-VARYG-xpost' / '...VARYG.xPost' / '[xpost]': the repost marker is not the group - the word before it is
		raw = re.sub(r'(?:[-._\s]*[\[(]?xposts?[\])]?)+$', '', raw, flags=re.I).strip('.-_ ')
		if raw.lower().endswith('-d-z0n3'): return 'D-Z0N3'
		# spaced names: the last word is the tag, hyphens inside it belong to the group ('... AAC -Tsundere-Raws', '... epname group-tag-name')
		spaced = re.sub(r'(?:[-._\s]*[\[(]?xposts?[\])]?)+$', '', spaced, flags=re.I).strip('.-_ ')
		if ' ' in spaced:
			word = spaced.rsplit(' ', 1)[-1].strip('-_ ')
			if '-' in word and not re.search(r'[\[\]()]', word):
				segs = [x for x in word.split('-') if x]
				while len(segs) > 1 and _bad_group(segs[0]): segs = segs[1:]
				cand = '-'.join(segs)
				if cand and len(cand) <= 24 and not _bad_group(cand) and not _bad_group(segs[-1]): return cand
		m = re.search(r'[\[(]([A-Za-z0-9@]{2,15})[\])]$', raw) or re.search(r'-([A-Za-z0-9@]{2,15})$', raw)
		token = m.group(1).replace('@', '') if m else ''
		if token and not _bad_group(token): return token
		if lead:
			token = lead.group(1).strip()
			if not _bad_group(token): return token
		return ''
	except Exception:
		return ''


_SOURCE_TAGS = frozenset(('cr', 'crunchyroll', 'bili', 'bilibili', 'b-global', 'funi', 'funimation', 'adn', 'hidive', 'amzn', 'nf', 'dsnp', 'atvp', 'vrv', 'vostfr', 'multisubs', 'multi-subs', 'engsub', 'dual', 'dualaudio', 'dual-audio'))

def _bad_group(token):
	key = token.lower().replace(' ', '')
	if not key or key in _NOT_GROUP or key.isdigit(): return True
	if re.fullmatch(r'\d{3,4}[pi]|x\.?26[45]|h\.?26[45]|10bit|8bit|dl|rip|hd|sd|[0-9a-f]{8}|web|bd|dvd|batch|v\d|aac\d*(\.\d)?|ddp?\d*(\.\d)?|flac|opus|ac3|eac3|hdr\d*|sdr', key): return True
	return False
