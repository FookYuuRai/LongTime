# -*- coding: utf-8 -*-
"""Kodi 22 accepts None where a string is expected but logs "Passing None where a string is expected ...".

This module turns None into an empty string at the Kodi API boundary (xbmc.log, getInfoLabel, executebuiltin,
getCondVisibility, Window and ListItem), and logs each distinct caller file:line once, so any remaining source can be found.
"""
import sys
import xbmc
import xbmcgui

_seen = set()
_orig = {}
_installed = [False]


def _note(api, frame):
    try:
        site = '%s:%d' % (frame.f_code.co_filename.rsplit('/', 1)[-1], frame.f_lineno)
    except Exception:
        site = '?'
    key = (api, site)
    if key in _seen:
        return
    _seen.add(key)
    try:
        _orig['xbmc.log'](u'[NIGHTSHIFT compat] None passed to %s at %s; sent as an empty string' % (api, site), xbmc.LOGWARNING)
    except Exception:
        pass


def _s(value, api, frame):
    if value is None:
        _note(api, frame)
        return ''
    return value


def _wrap_module_function(module, name):
    fn = getattr(module, name, None)
    if fn is None:
        return
    label = '%s.%s' % (module.__name__, name)
    _orig[label] = fn

    def wrapper(first=None, *args, **kwargs):
        first = _s(first, label, sys._getframe(1))
        return fn(first, *args, **kwargs)
    try:
        setattr(module, name, wrapper)
    except Exception:
        pass


def _patch_classes():
    OW = xbmcgui.Window
    OL = xbmcgui.ListItem

    class Window(OW):
        def getProperty(self, key, *args, **kwargs):
            return OW.getProperty(self, _s(key, 'Window.getProperty', sys._getframe(1)), *args, **kwargs)

        def setProperty(self, key, value, *args, **kwargs):
            frame = sys._getframe(1)
            return OW.setProperty(self, _s(key, 'Window.setProperty', frame), _s(value, 'Window.setProperty', frame), *args, **kwargs)

        def clearProperty(self, key, *args, **kwargs):
            return OW.clearProperty(self, _s(key, 'Window.clearProperty', sys._getframe(1)), *args, **kwargs)

    class ListItem(OL):
        def __init__(self, label='', label2='', iconImage='', thumbnailImage='', path='', *args, **kwargs):
            frame = sys._getframe(1)
            OL.__init__(self, _s(label, 'ListItem', frame), _s(label2, 'ListItem', frame), _s(iconImage, 'ListItem', frame),
                        _s(thumbnailImage, 'ListItem', frame), _s(path, 'ListItem', frame), *args, **kwargs)

        def setLabel(self, label):
            return OL.setLabel(self, _s(label, 'ListItem.setLabel', sys._getframe(1)))

        def setLabel2(self, label):
            return OL.setLabel2(self, _s(label, 'ListItem.setLabel2', sys._getframe(1)))

        def setPath(self, path):
            return OL.setPath(self, _s(path, 'ListItem.setPath', sys._getframe(1)))

        def setProperty(self, key, value):
            frame = sys._getframe(1)
            return OL.setProperty(self, _s(key, 'ListItem.setProperty', frame), _s(value, 'ListItem.setProperty', frame))

        def setArt(self, art):
            if isinstance(art, dict):
                frame = sys._getframe(1)
                art = dict((k, _s(v, 'ListItem.setArt', frame)) for k, v in art.items())
            return OL.setArt(self, art)

        def setInfo(self, type, infoLabels):
            if isinstance(infoLabels, dict):
                frame = sys._getframe(1)
                clean = {}
                for k, v in infoLabels.items():
                    if v is None:
                        _note('ListItem.setInfo', frame)
                        continue
                    clean[k] = v
                infoLabels = clean
            return OL.setInfo(self, type, infoLabels)

    xbmcgui.Window = Window
    xbmcgui.ListItem = ListItem


def install():
    if _installed[0]:
        return
    _installed[0] = True
    for name in ('log', 'getInfoLabel', 'executebuiltin', 'getCondVisibility'):
        _wrap_module_function(xbmc, name)
    try:
        _patch_classes()
    except Exception:
        pass


install()
