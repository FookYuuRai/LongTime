# -*- coding: utf-8 -*-
"""Nightshift search keyboard with live TMDb suggestions and a results view.

Suggestions follow the search being run (movies, TV shows, anime, TV shows and anime, people, keywords, collections).
Keys mode: keyboard plus a suggestion strip; the backdrop follows the highlighted suggestion.
Results mode: moving up into the suggestions hides the keyboard and shows the results
with the TMDb backdrop of the focused title. Back returns to the keys; Back or Cancel on the
keys closes the search. Choosing a result runs it through the existing Nightshift search.
Control IDs start at 9100 so they never clash with skin controls (2000 and up).
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from modules.ns_autocomplete import fetch_items, scope_for, is_cooling_down, DEFAULT_LIMIT

ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
DEBOUNCE_SECONDS = 0.15
HOME_WINDOW = 10000
OPEN_PROPERTY = 'nightshift.search.open'   # read by root_focus: no stills while search is open
MODE_PROPERTY = 'ns.mode'                  # 'keys' or 'results' (drives control visibility)

TITLE_PROPERTY = 'ns.title'   # text drawn by the skin's ring-font label stack
INPUT_PROPERTY = 'ns.input'
STATUS_PROPERTY = 'ns.status'  # shown in the suggestion area while it is empty
KEY_PROPERTY = 'ns.k.%d'      # label of each key, shown through the same stack
LIST_ID = 9150        # suggestion strip (keys mode)
RESULTS_ID = 9151     # results list (results mode)
KEY_BASE = 9100
KEY_COUNT = 40
SPACE_ID, BACK_ID, CLEAR_ID, SHIFT_ID, SYMBOLS_ID, SEARCH_ID, CAPS_ID = 9140, 9141, 9142, 9143, 9144, 9145, 9146

LETTER_PAGE = list('1234567890qwertyuiopasdfghjkl-zxcvbnm\'&:')   # QWERTY order: digits, then the keyboard rows
SYMBOL_PAGE = list('1234567890!@#$%^&*()-_=+[]{}|;:\'",.<>?/`')

ACTION_PREVIOUS_MENU = getattr(xbmcgui, 'ACTION_PREVIOUS_MENU', 10)
ACTION_NAV_BACK = getattr(xbmcgui, 'ACTION_NAV_BACK', 92)


class NightshiftKeyboard(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.result = ''
        self.heading = ''
        self._scope = scope_for()
        self._text = ''
        self._seq = 0
        self._items = []
        self._closed = False
        self._symbols = False
        self._shift = False
        self._caps = False
        self._lock = threading.Lock()
        super().__init__(*args, **kwargs)

    # ---- window lifecycle -------------------------------------------------
    def onInit(self):
        self._closed = False
        self._set_mode('keys')
        self._set_open(True)
        self._set_title(self.heading or self._scope[2])
        self._refresh_keys()
        self._refresh_text()
        self.setProperty(STATUS_PROPERTY, 'Type to search')
        self._publish(self._next_seq(), [])
        self._focus(KEY_BASE)

    def onFocus(self, control_id):
        # Moving up into the suggestion strip switches to the results view. With nothing to show,
        # hand focus straight back to the keys instead of leaving it on an empty list.
        if control_id == LIST_ID and self._mode() == 'keys':
            if self._items:
                self._enter_results()
            else:
                self._focus(KEY_BASE)

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            if self._mode() == 'results':
                self._leave_results()
            else:
                self._cancel()

    def onClick(self, control_id):
        if KEY_BASE <= control_id < KEY_BASE + KEY_COUNT:
            self._press_key(control_id - KEY_BASE)
        elif control_id == SPACE_ID:
            self._set_text(self._text + ' ')
        elif control_id == BACK_ID:
            self._set_text(self._text[:-1])
        elif control_id == CLEAR_ID:
            self._set_text('')
        elif control_id == SHIFT_ID:
            self._shift = not self._shift
            self._refresh_keys()
        elif control_id == CAPS_ID:
            self._caps = not self._caps
            self._refresh_keys()
        elif control_id == SYMBOLS_ID:
            self._symbols = not self._symbols
            self._shift = False
            self._refresh_keys()
        elif control_id == SEARCH_ID:
            self._submit()
        elif control_id == LIST_ID:
            self._enter_results()
        elif control_id == RESULTS_ID:
            self._choose_result()

    # ---- mode -------------------------------------------------------------
    def _mode(self):
        return self.getProperty(MODE_PROPERTY) or 'keys'

    def _set_mode(self, mode):
        self.setProperty(MODE_PROPERTY, mode)

    def _set_title(self, text):
        self.setProperty(TITLE_PROPERTY, text)

    def _focus(self, control_id, tries=12):
        """Focus a control and confirm it took. A control that was hidden a moment ago is only focusable once
        the skin has re-evaluated its visibility, so a single setFocusId can silently fail; retry briefly."""
        for _ in range(tries):
            try:
                self.setFocusId(control_id)
                xbmc.sleep(30)
                if self.getFocusId() == control_id:
                    return True
            except Exception:
                xbmc.sleep(30)
        return False

    def _enter_results(self):
        if not self._items:
            return
        self._set_mode('results')
        self._set_title('Results for %s' % self._text if self._text else 'Results')
        if not self._focus(RESULTS_ID):
            # Could not reach the list: go back to the keys rather than strand the focus on a hidden control.
            self._leave_results()

    def _leave_results(self):
        self._set_mode('keys')
        self._set_title(self.heading or self._scope[2])
        self._focus(KEY_BASE)

    def _choose_result(self):
        position = self.getControl(RESULTS_ID).getSelectedPosition()
        if 0 <= position < len(self._items):
            self.result = self._items[position]['title']
            self._finish()

    # ---- keys -------------------------------------------------------------
    def _page(self):
        return SYMBOL_PAGE if self._symbols else LETTER_PAGE

    def _uppercase(self):
        # Caps Lock keeps letters uppercase; Shift flips it for one letter.
        return (not self._symbols) and (self._caps != self._shift)

    def _press_key(self, index):
        char = self._page()[index]
        if char.isalpha() and self._uppercase():
            char = char.upper()
        if self._shift and not self._symbols:
            self._shift = False          # Shift applies to one letter
            self._refresh_keys()
        self._set_text(self._text + char)

    def _refresh_keys(self):
        upper = self._uppercase()
        for index, char in enumerate(self._page()):
            if char.isalpha() and upper:
                char = char.upper()
            self.setProperty(KEY_PROPERTY % (KEY_BASE + index), char)
        self.setProperty('ns.k.shift', 'SHIFT' if self._shift else 'Shift')
        self.setProperty('ns.k.caps', 'CAPS' if self._caps else 'Caps')
        self.setProperty('ns.k.symbols', 'Letters' if self._symbols else 'Symbols')

    # ---- text and suggestions ---------------------------------------------
    def _set_text(self, text):
        self._text = text
        self._refresh_text()
        self._request_suggestions(text)

    def _refresh_text(self):
        self.setProperty(INPUT_PROPERTY, self._text + '_')

    def _next_seq(self):
        with self._lock:
            self._seq += 1
            return self._seq

    def _request_suggestions(self, text):
        seq = self._next_seq()
        if not text.strip():
            self.setProperty(STATUS_PROPERTY, 'Type to search')
            self._publish(seq, [])
            return
        self.setProperty(STATUS_PROPERTY, 'Searching...')
        threading.Thread(target=self._lookup, args=(seq, text), daemon=True).start()

    def _lookup(self, seq, text):
        time.sleep(DEBOUNCE_SECONDS)       # debounce: skip lookups overtaken by typing
        if not self._is_current(seq):
            return
        items = fetch_items(text, DEFAULT_LIMIT, self._scope)  # network, never on the key path
        if self._is_current(seq):
            if items:
                status = ''
            elif is_cooling_down():
                status = 'TMDb is busy, suggestions resume shortly'
            else:
                status = 'No suggestions'
            self.setProperty(STATUS_PROPERTY, status)
        self._publish(seq, items)

    def _is_current(self, seq):
        with self._lock:
            return seq == self._seq and not self._closed

    def _publish(self, seq, items):
        """Show items only if no newer query has started (stale-result protection).
        An unchanged list is left alone, and a rebuilt one keeps the highlighted row, so a late reply
        never yanks the list out from under someone who is already scrolling it."""
        with self._lock:
            if seq != self._seq or self._closed:
                return
            if [i['title'] for i in items] == [i['title'] for i in self._items] and items:
                return
            self._items = items
            for list_id in (LIST_ID, RESULTS_ID):
                control = self.getControl(list_id)
                try:
                    position = control.getSelectedPosition()
                except Exception:
                    position = 0
                control.reset()
                for item in items:
                    row = xbmcgui.ListItem(item['title'])
                    row.setLabel2(item.get('media', ''))
                    row.setProperty('year', item.get('year', ''))
                    row.setProperty('backdrop', item.get('backdrop', ''))
                    row.setProperty('portrait', item.get('portrait', ''))
                    control.addItem(row)
                if items and list_id == RESULTS_ID and position > 0:
                    control.selectItem(min(position, len(items) - 1))

    # ---- finishing ---------------------------------------------------------
    def _submit(self):
        self.result = self._text.strip()
        self._finish()

    def _cancel(self):
        self.result = ''
        self._finish()

    def _finish(self):
        with self._lock:
            self._closed = True
            self._seq += 1
        self._set_open(False)
        self.close()

    def _set_open(self, flag):
        xbmcgui.Window(HOME_WINDOW).setProperty(OPEN_PROPERTY, '1' if flag else '')


def ns_keyboard_input(heading='', media_type='', search_type='media_title'):
    """Return the text chosen on the Nightshift search screen, or '' if cancelled.
    media_type / search_type are the same values the search menu passes to search.get_key_id,
    so the suggestions only offer what that search can open."""
    try:
        dialog = NightshiftKeyboard('ns_keyboard.xml', ADDON_PATH, 'Default', '1080i')
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] could not open, using Kodi keyboard: {exc}", xbmc.LOGWARNING)
        return xbmcgui.Dialog().input(heading)
    try:
        dialog._scope = scope_for(media_type, search_type)
        dialog.heading = heading
        dialog.doModal()
        return dialog.result
    finally:
        del dialog
