# -*- coding: utf-8 -*-
import re
import base64
from urllib.parse import quote_plus
from modules.utils import clean_file_name, normalize
from modules import source_utils

_HASH_HEX = re.compile(r'^[a-f0-9]{40}$')
_BTIH = re.compile(r'btih:([a-zA-Z0-9]+)', re.I)
_SIZE = re.compile(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', re.I)
_SEEDERS = re.compile(r'(?:👤|seeders?)\s*[:\s]*(\d+)', re.I)
_SXXEXX = re.compile(r's\d{1,2}e\d{1,2}', re.I)
_SEASON_TAG = re.compile(r'(?:s|season)[.\s_-]*(\d{1,2})(?:[^\de]|$)', re.I)
_INFO_LINE = re.compile(r'(💾|👤|⚙️)')

# ===== PACK / BATCH DETECTION =====
# Explicit episode ranges: "Eps 083 - 118", "Episodes 1-24", "Ep.01~12"
_EP_RANGE_PREFIXED = re.compile(
	r'(?<![a-z0-9])(?:episodes?|eps?)[.\s_]*0*(\d{1,4})\s*(?:-|~|\u2013|\u2014|\bto\b)\s*(?:episodes?|eps?)?[.\s_]*0*(\d{1,4})(?![0-9])',
	re.I)
# Bracketed bare ranges: "[001-220]", "(01-12)", "[01-12v2]"
_EP_RANGE_BRACKETED = re.compile(
	r'[\[(]\s*0*(\d{1,4})\s*(?:-|~|\u2013|\u2014|\bto\b)\s*0*(\d{1,4})\s*(?:v\d+)?\s*[\])]',
	re.I)
# Bare zero-padded ranges: "Show 001-070", "(1080p) 071-136" (lo must start with 0 so resolutions,
# years and bitrates like 1080-720 / 2019-2021 are never read as episodes)
_EP_RANGE_ZERO_PADDED = re.compile(
	r'(?<![a-z0-9])(0\d{2,3})\s*(?:-|~|\u2013|\u2014)\s*(0?\d{2,4})(?![0-9a-z])', re.I)
# Multi-season ranges where BOTH ends carry an S/Season prefix: "S01-S05", "Season 1 - Season 5".
# Both prefixes are required so single episodes named "Show S04 - 119" are never read as a range.
_MULTI_SEASON_RANGE = re.compile(
	r'(?<![a-z0-9])(?:seasons?|s)[.\s_]*0*(\d{1,2})\s*(?:-|~|\u2013|\u2014|\bto\b)\s*(?:seasons?|s)[.\s_]*0*(\d{1,2})(?![0-9])',
	re.I)
# "Season 01-25", "Season 1 to 5", "Seasons 1-5" (word form; hi must exceed lo)
_MULTI_SEASON_WORD_RANGE = re.compile(
	r'(?<![a-z0-9])seasons?[.\s_]*0*(\d{1,2})\s*(?:-|~|\u2013|\u2014|\bto\b)\s*(?:seasons?[.\s_]*)?0*(\d{1,2})(?![0-9])',
	re.I)
# "Show S04 - 119.mkv": season marker + dash + episode number is a SINGLE episode, not a season pack
_SEASON_DASH_EP = re.compile(r'(?<![a-z0-9])s\d{1,2}\s*-\s*0*\d{1,4}(?![0-9pi])', re.I)
_BATCH_WORD = re.compile(r'(?<![a-z0-9])batch(?![a-z0-9])', re.I)
# A range must span at least this many episodes to count as a pack (E05-E06 double-episodes are not packs)
_MIN_PACK_RANGE_SPAN = 3

NATIVE_INDEXER_SCRAPERS = ('animetosho', 'nyaa', 'piratebay', 'torrentdownloads', 'knaben')
NATIVE_SITE_SCRAPERS = ('comet', 'torz', 'torrentio', 'mediafusion', 'zilean')
NATIVE_TORRENT_SCRAPERS = NATIVE_INDEXER_SCRAPERS + NATIVE_SITE_SCRAPERS
# scrapers whose releases may carry extra series-name words in front of the show title ('[Group] Aoki Denshou Welsh & Shedar 01')
SERIES_PREFIX_SCRAPERS = ('nyaa', 'animetosho')
NATIVE_SITE_DISPLAY = {
	'comet': 'COMET',
	'torrentio': 'TORRENTIO',
	'torz': 'TORZ',
	'nyaa': 'NYAA',
	'animetosho': 'ANIMETOSHO',
	'mediafusion': 'MEDIAFUSION',
	'zilean': 'ZILEAN',
	'piratebay': 'PIRATEBAY',
	'torrentdownloads': 'TORRENTDOWNLOADS',
	'knaben': 'KNABEN',
}
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

_json_session = None

def json_http():
	global _json_session
	if _json_session is None:
		from modules.kodi_utils import make_session
		_json_session = make_session('https://')
		_json_session.headers.update({'User-Agent': USER_AGENT, 'Accept': 'application/json'})
	return _json_session

class _FallbackResponse:
	"""Minimal requests.Response stand-in for the urllib fallback path."""
	def __init__(self, url, status, body, headers):
		self.url, self.status_code, self.content, self.headers = url, status, body, headers
		enc = 'utf-8'
		try:
			m = re.search(r'charset=([\w-]+)', headers.get('Content-Type', '') or '', re.I)
			if m: enc = m.group(1)
		except Exception:
			pass
		self.text = body.decode(enc, 'replace')
	def json(self):
		import json
		return json.loads(self.text)
	def raise_for_status(self):
		if self.status_code >= 400:
			import requests
			raise requests.exceptions.HTTPError('%s Error for url: %s' % (self.status_code, self.url))

_EXTRA_CA_FILES = []   # tests / overrides; Kodi's own bundle is looked up lazily by _kodi_ca_file()

def _kodi_ca_file():
	"""Kodi's own CA bundle (special://xbmc/system/certs/cacert.pem) - newer than the certifi file the Python add-on ships with."""
	try:
		import xbmcvfs, os
		path = xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem')
		if path and os.path.exists(path): return path
	except Exception:
		pass
	return None

def _trust_contexts():
	"""Verified TLS contexts to try in order: Python's platform store, then Kodi's bundled CA file. Verification is always ON."""
	import ssl
	out = [ssl.create_default_context()]
	for path in list(_EXTRA_CA_FILES) + [_kodi_ca_file()]:
		if not path: continue
		try:
			ctx = ssl.create_default_context()
			ctx.load_verify_locations(cafile=path)
			out.append(ctx)
		except Exception:
			pass
	return out

_AIA_CA_ISSUERS = bytes.fromhex('2b06010505073002')   # OID 1.3.6.1.5.5.7.48.2 (caIssuers)

def _aia_urls(der):
	"""http(s) URLs of the 'CA Issuers' entries in a certificate's Authority Information Access extension."""
	urls, pos = [], 0
	while True:
		pos = der.find(_AIA_CA_ISSUERS, pos)
		if pos < 0: break
		pos += len(_AIA_CA_ISSUERS)
		if der[pos:pos + 1] == b'\x86':          # [6] uniformResourceIdentifier
			n = der[pos + 1]
			start = pos + 2
			if n & 0x80:
				k = n & 0x7f; n = int.from_bytes(der[start:start + k], 'big'); start += k
			url = der[start:start + n].decode('ascii', 'ignore')
			if url.lower().startswith(('http://', 'https://')): urls.append(url)
	return urls

def _peer_leaf_der(host, port, timeout):
	"""The leaf certificate a server presents. Used ONLY to read where its issuing CA can be fetched; nothing is sent over this connection."""
	import ssl, socket
	ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
	with socket.create_connection((host, port), timeout=timeout) as sock:
		with ctx.wrap_socket(sock, server_hostname=host) as tls:
			return tls.getpeercert(binary_form=True)

def _fetch_intermediates(der, timeout, depth=3):
	"""Follow the AIA 'CA Issuers' links (what browsers do) to collect the intermediate certificate(s) a server forgot to send."""
	import ssl
	from urllib.request import urlopen
	found = []
	for _ in range(depth):
		got = None
		for url in _aia_urls(der):
			try:
				with urlopen(url, timeout=timeout) as r: raw = r.read(20000)
				got = ssl.PEM_cert_to_DER_cert(raw.decode('ascii')) if raw.lstrip().startswith(b'-----BEGIN') else raw
				break
			except Exception:
				continue
		if not got or got in found: break
		found.append(got); der = got
	return found

def _urllib_get(url, timeout, headers):
	"""Further TLS attempts after requests rejected the certificate. Verification stays ON in every one of them:
	  1. Python's platform CA store, 2. Kodi's own bundled CA file,
	  3. servers that forget to send their intermediate certificate ('unable to get local issuer certificate'): fetch the
	     missing intermediate from the certificate's own AIA link (as a browser does) and verify it up to a trusted root."""
	import ssl
	from urllib.request import Request, urlopen
	from urllib.error import HTTPError, URLError
	from urllib.parse import urlparse
	req = Request(url, headers=headers or {})
	def _go(ctx):
		try:
			with urlopen(req, context=ctx, timeout=timeout) as resp:
				return _FallbackResponse(url, resp.status, resp.read(), dict(resp.headers))
		except HTTPError as e:
			return _FallbackResponse(url, e.code, e.read() or b'', dict(e.headers or {}))
	first = None
	contexts = _trust_contexts()
	for ctx in contexts:
		try: return _go(ctx)
		except (ssl.SSLError, URLError) as e:
			if isinstance(e, URLError) and not isinstance(getattr(e, 'reason', None), ssl.SSLError): raise
			first = first or e
	u = urlparse(url)
	if u.scheme == 'https':
		extra = _fetch_intermediates(_peer_leaf_der(u.hostname, u.port or 443, timeout), timeout)
		if extra:
			# Fresh contexts, partial-chain OFF (Python 3.13 turns it on by default): the fetched intermediate is only a link
			# for building the chain and must still lead, signature by signature, to a genuine root from the platform / Kodi store.
			# An intermediate that does not chain to a trusted root is never accepted as an anchor.
			for base in _trust_contexts():
				try:
					flag = getattr(ssl, 'VERIFY_X509_PARTIAL_CHAIN', 0)
					if flag: base.verify_flags &= ~flag
					for der in extra: base.load_verify_locations(cadata=ssl.DER_cert_to_PEM_cert(der))
					return _go(base)
				except (ssl.SSLError, URLError) as e:
					first = first or e
	raise first

def _kodi_vfs_get(url, timeout, headers):
	"""Last resort: let Kodi itself fetch the URL (xbmcvfs.File -> Kodi's libcurl and Kodi's own cacert.pem), independent of the Python
	add-on certificate bundle and of Python's ssl. Kodi's VFS gives no status code: an empty body means it failed. Verification stays on."""
	import xbmcvfs
	from urllib.parse import quote
	hdr = '&'.join('%s=%s' % (k, quote(str(v), safe='')) for k, v in (headers or {}).items() if k.lower() not in ('accept-encoding', 'connection'))
	handle = xbmcvfs.File(url + ('|' + hdr if hdr else ''))
	try:
		body = bytes(handle.readBytes())
	finally:
		try: handle.close()
		except Exception: pass
	if not body:
		raise OSError('Kodi VFS returned nothing for %s' % url)
	return _FallbackResponse(url, 200, body, {})

_FAILED_HOSTS = {}
_FAILED_HOST_TTL = 45

def _host_of(url):
	try:
		from urllib.parse import urlparse
		return urlparse(url).netloc.lower()
	except Exception: return ''

def _host_recently_failed(host):
	if not host: return False
	stamp = _FAILED_HOSTS.get(host)
	if stamp is None: return False
	from time import monotonic
	if monotonic() - stamp < _FAILED_HOST_TTL: return True
	_FAILED_HOSTS.pop(host, None)
	return False

def _mark_host_failed(host):
	if not host: return
	from time import monotonic
	_FAILED_HOSTS[host] = monotonic()

def safe_get(session, url, timeout, **kw):
	"""session.get(), and when TLS verification fails retry once through the platform CA store (verification stays on).
	The real SSL reason is logged so a failing host can be told apart from an outdated CA bundle."""
	import requests
	from modules.kodi_utils import logger
	host = _host_of(url)
	if _host_recently_failed(host):
		raise requests.exceptions.ConnectionError('skipped %s: failed moments ago' % host)
	try:
		return session.get(url, timeout=timeout, **kw)
	except requests.exceptions.SSLError as e:
		logger('native ssl', 'requests rejected TLS for %s: %s' % (url, str(e)[:300]))
		headers = dict(session.headers)
		headers.update(kw.get('headers') or {})
		headers.pop('Accept-Encoding', None)
		if kw.get('params'):
			from urllib.parse import urlencode
			url = url + ('&' if '?' in url else '?') + urlencode(kw['params'])
		try:
			response = _urllib_get(url, timeout, headers)
			logger('native ssl', 'platform / Kodi CA store (or fetched intermediate) accepted %s' % url)
			return response
		except Exception as e2:
			logger('native ssl', 'platform / Kodi CA store and AIA intermediate also failed for %s: %s %s' % (url, type(e2).__name__, str(e2)[:300]))
			try:
				response = _kodi_vfs_get(url, timeout, headers)
				logger('native ssl', 'Kodi\'s own network stack accepted %s' % url)
				return response
			except Exception as e3:
				logger('native ssl', 'Kodi\'s own network stack also failed for %s: %s %s' % (url, type(e3).__name__, str(e3)[:200]))
			_mark_host_failed(host)
			raise e
	except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError):
		_mark_host_failed(host)
		raise

def source_site_label(scrape_provider):
	return 'Indexer' if scrape_provider in NATIVE_INDEXER_SCRAPERS else 'Site'

def normalize_info_hash(value):
	if not value:
		return None
	text = str(value).strip()
	match = _BTIH.search(text)
	if match:
		text = match.group(1)
	text = text.lower()
	if _HASH_HEX.match(text):
		return text
	if len(text) == 32:
		try:
			padded = text.upper() + ('=' * ((8 - (len(text) % 8)) % 8))
			decoded = base64.b32decode(padded)
			if len(decoded) == 20:
				return decoded.hex()
		except Exception:
			return None
	return None

def parse_size_gb(text):
	if not text:
		return 0.0
	match = _SIZE.search(str(text).replace('\xa0', ' '))
	if not match:
		return 0.0
	raw, unit = match.group(1).rsplit(None, 1)
	try:
		value = float(raw.replace(',', ''))
	except Exception:
		return 0.0
	if unit.lower().startswith('m'):
		return round(value / 1024.0, 2)
	return round(value, 2)

def parse_seeders(text):
	if not text:
		return 0
	match = _SEEDERS.search(str(text))
	if not match:
		return 0
	try:
		return int(match.group(1))
	except Exception:
		return 0

def bytes_to_gb(size_bytes):
	try:
		value = float(size_bytes or 0)
	except Exception:
		return 0.0
	if value <= 0:
		return 0.0
	return round(value / 1073741824.0, 2)

def magnet_url(info_hash, name):
	display = quote_plus((name or info_hash).replace(' ', '.'))
	return 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, display)

def instance_base_url(setting_id, urls, custom_setting_id=None, custom_index=None):
	from caches.settings_cache import get_setting
	try:
		idx = int(get_setting('nightshift.%s' % setting_id, '0'))
	except (TypeError, ValueError):
		idx = 0
	if custom_index is not None and idx == custom_index:
		custom = (get_setting('nightshift.%s' % custom_setting_id, '') or '').strip().rstrip('/')
		return custom
	if idx < 0 or idx >= len(urls):
		idx = 0
	return urls[idx]

def stremio_stream_url(base, imdb_id, media_type, season=None, episode=None):
	if not base or not imdb_id:
		return None
	imdb_id = str(imdb_id).strip()
	if '/stream/' in base:
		return base
	if media_type == 'movie':
		return '%s/stream/movie/%s.json' % (base, imdb_id)
	return '%s/stream/series/%s:%s:%s.json' % (base, imdb_id, int(season), int(episode))

def parse_stremio_stream(raw):
	info_hash = normalize_info_hash(raw.get('infoHash') or '')
	if not info_hash:
		info_hash = normalize_info_hash(raw.get('url') or '')
	if not info_hash:
		return None
	description = raw.get('description') or raw.get('title') or ''
	description = str(description).replace('┈➤', '\n')
	lines = [i.strip() for i in description.split('\n') if i.strip()]
	hints = raw.get('behaviorHints') or {}
	name = hints.get('filename') or raw.get('behaviorHints', {}).get('filename')
	if not name and lines:
		name = lines[0]
	if not name:
		name = raw.get('name') or info_hash
	# Addon error/placeholder rows — "Invalid magnet", "Invalid link", empty
	# names. NAME only: placeholder text surfaces as the name (via the
	# lines[0] fallback), while the full description legitimately carries
	# size/seeder/cache-status lines ("not cached") for real torrents.
	if source_utils.is_error_release_name(name):
		source_utils.diag_log('StremioParse', 'REJECT placeholder row: name=%r' % name)
		return None
	info_line = ''
	for line in lines:
		if _INFO_LINE.search(line):
			info_line = line
			break
	if not info_line:
		info_line = description
	size = parse_size_gb(info_line)
	if not size:
		try:
			video_size = float(hints.get('videoSize') or 0)
			if video_size > 1048576:
				size = round(video_size / 1073741824.0, 2)
		except Exception:
			size = 0.0
	return {
		'hash': info_hash,
		'name': name,
		'size': size,
		'seeders': parse_seeders(info_line),
		'description': description,
	}

def search_stremio_streams(url, cache_prefix, timeout=15, expiration=24, log_name='stremio api'):
	from caches.main_cache import main_cache
	from modules.kodi_utils import logger
	if not url:
		return []
	cache_key = '%s_%s' % (cache_prefix, url)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	streams = []
	try:
		response = safe_get(json_http(), url, max(5, int(timeout)))
		response.raise_for_status()
		payload = response.json() or {}
		for raw in payload.get('streams') or []:
			parsed = parse_stremio_stream(raw)
			if parsed:
				streams.append(parsed)
	except Exception as e:
		logger(log_name, '%s: %s (%s)' % (type(e).__name__, str(e)[:200], url))
		return []
	logger(log_name, 'streams=%d url=%s' % (len(streams), url))
	main_cache.set(cache_key, streams, expiration=expiration)
	return streams

def scrape_timeout(info, cap=20):
	from caches.settings_cache import get_setting
	timeout = int(get_setting('nightshift.results.timeout', '20'))
	if 'timeout' in info:
		timeout = max(5, int(info['timeout']) - 1)
	return min(timeout, cap)

def scrape_expiry(info):
	return int((info.get('expiry_times') or [24])[0] or 24)



def has_multi_season_range(name):
	for regex in (_MULTI_SEASON_RANGE, _MULTI_SEASON_WORD_RANGE):
		for match in regex.finditer(name or ''):
			try:
				if int(match.group(2)) > int(match.group(1)):
					return True
			except Exception:
				continue
	return False

def pack_episode_ranges(name):
	"""Explicit episode ranges in a release name -> [(lo, hi), ...].
	Runs on the RAW name (normalize() strips the en-dash some uploaders use)."""
	ranges = []
	for regex in (_EP_RANGE_PREFIXED, _EP_RANGE_BRACKETED, _EP_RANGE_ZERO_PADDED):
		for match in regex.finditer(name or ''):
			try:
				lo, hi = int(match.group(1)), int(match.group(2))
			except Exception:
				continue
			if lo >= 1900:  # (1998-2002) year span, not episodes
				continue
			if hi - lo + 1 < _MIN_PACK_RANGE_SPAN:
				continue
			if (lo, hi) not in ranges:
				ranges.append((lo, hi))
	return ranges

def pack_season_ranges(name):
	"""Season ranges in a release name -> [(lo, hi), ...]  ('Season 01-25' -> [(1, 25)], 'S01-S05' -> [(1, 5)]).
	A lone season tag ('S01', 'Season 2') is returned as (n, n) when no range is present."""
	ranges = []
	for regex in (_MULTI_SEASON_RANGE, _MULTI_SEASON_WORD_RANGE):
		for match in regex.finditer(name or ''):
			try:
				lo, hi = int(match.group(1)), int(match.group(2))
			except Exception:
				continue
			if hi > lo and (lo, hi) not in ranges:
				ranges.append((lo, hi))
	if not ranges:
		try:
			dotted = normalize(name or '').lower().replace(' ', '.')
			tag = _SEASON_TAG.search(dotted)
			if tag:
				ranges.append((int(tag.group(1)), int(tag.group(1))))
		except Exception:
			pass
	return ranges

def pack_details(name):
	"""Structured pack info for logs / result rows:
	season_ranges  [(1, 25)]      from 'Season 01-25', 'S01-S05', 'Seasons 1-5'
	ep_ranges      [(83, 118)]    from 'Eps 083 - 118', 'Episodes 1-24', '[001-220]'
	batch          True/False     'Batch' marker
	markers        ['complete', 'batch']   SEASON_PACK_MARKERS words that matched"""
	markers = source_utils.pack_marker_hits(normalize(name or '').lower().replace(' ', '.'))
	return {
		'season_ranges': pack_season_ranges(name),
		'ep_ranges': pack_episode_ranges(name),
		'batch': bool(_BATCH_WORD.search(name or '')) or 'batch' in markers,
		'markers': markers,
	}

def _fmt_ranges(ranges):
	return ','.join('%d-%d' % (lo, hi) if lo != hi else '%d' % lo for (lo, hi) in ranges) if ranges else '-'

def pack_details_label(details):
	details = details or {}
	return 'seasons=%s eps=%s batch=%s markers=%s' % (
		_fmt_ranges(details.get('season_ranges')), _fmt_ranges(details.get('ep_ranges')),
		'Y' if details.get('batch') else 'N', ','.join(details.get('markers') or []) or '-')

def pack_type_from_name(name, season=None):
	if not name:
		return None

	release = normalize(name)

	if _SXXEXX.search(release.replace(' ', '.')):
		return None
	if _SEASON_DASH_EP.search(name):
		return None

	dotted = release.lower().replace(' ', '.')

	# ###FIX### Pack words now come from ONE whole-word list (source_utils.SEASON_PACK_MARKERS)
	# shared with check_title()/should_accept_file_title(). The old private substring list here
	# had drifted from it and matched inside words ('eps' hit 'Creeps', 'Steps').
	marker_hits = source_utils.pack_marker_hits(dotted)
	if any(hit not in source_utils.WEAK_PACK_MARKERS for hit in marker_hits):
		return 'show'

	# Multi-season sets ('S1 & S2', 'S01+S02', 'Season 1 & 2', 'Seasons 1-2'): a show pack, but only for a season it lists
	covered = source_utils.names_season_set(name)
	if len(covered) >= 2:
		try:
			if season in (None, '', 'pack') or int(season) in covered: return 'show'
		except Exception: pass
		return None
	# Multi-season ranges (S01-S05, Season 01-25) are show packs
	if has_multi_season_range(name):
		return 'show'
	# 'eps' / 'episodes' / 'batch', or an explicit episode range ("Eps 083 - 118", "[001-220]")
	if marker_hits or pack_episode_ranges(name):
		return 'season'

	if season in (None, '', 'pack'):
		if re.search(r'season', dotted):
			return 'season'
		return None
	try:
		season_i = int(season)
	except Exception:
		return None
	season_fill = '%02d' % season_i
	match = _SEASON_TAG.search(dotted)
	if match and int(match.group(1)) == season_i:
		return 'season'
	if '.s%s.' % season_fill in '.%s.' % dotted.replace('-', '.'):
		return 'season'
	if 'season.%s' % season_i in dotted or 'season.%s' % season_fill in dotted:
		return 'season'
	return None

def apply_pack_size(size, package, season_divider, show_divider, episode_count=None):
	try:
		size = float(size or 0)
	except Exception:
		return 0.0
	# An explicit episode range in the name is the most accurate divisor available
	if package and episode_count:
		size = size / float(episode_count)
	elif package == 'season' and season_divider:
		size = size / float(season_divider)
	elif package == 'show' and show_divider:
		size = size / float(show_divider)
	return round(size, 2)

def build_source(scrape_provider, name, info_hash, size=0.0, seeders=0, package=None, extra_name_info='', details=None):
	file_name = normalize(name or info_hash)
	display_name = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
	try:
		_tag = re.match(r'\s*(\[[^\]]{1,40}\])', file_name)
		if _tag and '.' in _tag.group(1):
			# 'P.Anon' must not be shown as 'P Anon': keep the group tag exactly as released
			_rest = display_name.split(']', 1)[1] if ']' in display_name else display_name
			display_name = _tag.group(1) + _rest
	except Exception: pass
	name_info = source_utils.release_info_format(file_name)
	if extra_name_info:
		name_info = '%s.%s' % (name_info, extra_name_info)
	quality, extra_info = source_utils.get_file_info(name_info=name_info)
	if quality == 'SD' and not package and scrape_provider in SERIES_PREFIX_SCRAPERS:
		# Anime uploads often carry no resolution at all ('[P.Anon] Show 01', 0.5 GB) and would be filed as SD - and vanish when SD is
		# switched off. With no resolution tag anywhere in the name, estimate it from the single-episode size.
		try:
			if not source_utils.get_release_quality(name_info) and not re.search(r'(?i)(?<![0-9])(2160|1440|1080|720|576|540|480|360|240)\s*[pi]?(?![0-9])|\b4k\b|\bdvd|\bsd\b|\buhd\b', name or ''):
				gb = float(size or 0)
				if gb >= 0.9: quality = '1080p'
				elif gb >= 0.35: quality = '720p'
		except Exception: pass
	if package:
		# ###FIX### Nothing emitted the PACK tag, so packs never showed as packs
		# (and the PACK preferred-tag filter could never match).
		extra_info = 'PACK | %s' % extra_info if extra_info else 'PACK'
	item = {
		'name': file_name,
		'display_name': display_name,
		'quality': quality,
		'size': round(float(size or 0), 2),
		'size_label': '%.2f GB' % float(size or 0),
		'hash': info_hash,
		'url': magnet_url(info_hash, file_name),
		'id': info_hash,
		'seeders': int(seeders or 0),
		'source': 'torrent',
		'provider': scrape_provider,
		'scrape_provider': scrape_provider,
		'extraInfo': extra_info,
		'direct': False,
		'debridonly': True,
		'external': False,
		'local': False,
	}
	if package:
		item['package'] = package
		# Pack fields (also useful to any results-window code that wants to show them)
		details = details or pack_details(file_name)
		item['pack_season_ranges'] = [list(r) for r in details.get('season_ranges') or []]
		item['pack_ep_ranges'] = [list(r) for r in details.get('ep_ranges') or []]
		item['pack_batch'] = bool(details.get('batch'))
	return item

def punctuated_title(raw_title):
	"""The title with its punctuation kept (curly quotes made straight, accents folded): "A Returner's Magic Should Be Special". '' when it
	is the same as the stripped title (nothing to add)."""
	try:
		text = source_utils.normalize(raw_title or '').lower().replace('\u2019', "'").replace('\u2018', "'").replace('`', "'")
		text = re.sub(r'\s+', ' ', text).strip()
		stripped = re.sub(r'[^a-z0-9\s]', '', text.replace('&', ' and ')).strip()
		return text if text and re.search(r"[^a-z0-9\s]", text) and text != stripped else ''
	except Exception:
		return ''

def name_search_queries(info):
	# Accent-fold first (via source_utils.normalize), then expand '&', THEN strip punctuation/symbols
	raw_title = info.get('title') or ''
	normalized = source_utils.normalize(raw_title).lower().replace('&', ' and ')
	title = re.sub(r'[^a-z0-9\s]', '', normalized).strip()
	if not title:
		title = clean_file_name(raw_title).replace('&', ' and ')
	
	year = int(info.get('year') or 0)
	media_type = info.get('media_type')
	season, episode = info.get('season'), info.get('episode')
	absolute_episode = info.get('absolute_episode')
	aliases = source_utils.get_aliases_titles(info.get('aliases', []))
	queries, seen = [], set()

	def _add(query):
		query = (query or '').strip()
		if not query or query in seen:
			return
		seen.add(query)
		queries.append(query)

	punct = punctuated_title(raw_title)
	if media_type == 'movie':
		_add('%s %d' % (title, year))
		if punct: _add('%s %d' % (punct, year))
		for alias in aliases:
			alias_normalized = source_utils.normalize(alias).lower().replace('&', ' and ')
			alias_clean = re.sub(r'[^a-z0-9\s]', '', alias_normalized).strip()
			if alias_clean and alias_clean != title:
				_add('%s %d' % (alias_clean, year))
		return queries
	hdlr = 'S%02dE%02d' % (int(season), int(episode))
	hdlr_alt = 'S%dE%d' % (int(season), int(episode))
	_add('%s %s' % (title, hdlr))
	if punct: _add('%s %s' % (punct, hdlr))
	if hdlr_alt != hdlr:
		_add('%s %s' % (title, hdlr_alt))

	for _as, _ae in (info.get('alt_se') or [])[:3]:
		try: _add('%s S%02dE%02d' % (title, int(_as), int(_ae)))
		except Exception: pass
	if absolute_episode not in (None, '', 0, '0'):
		try:
			abs_i = int(absolute_episode)
		except Exception:
			abs_i = None
		if abs_i:
			# Basic queries - ALWAYS added (bare absolute, no padding)
			_add('%s - %s' % (title, abs_i))
			_add('%s %s' % (title, abs_i))
			if punct: _add('%s %s' % (punct, abs_i))
			
			# Padded forms ('047' for episode 47 of a 131-episode show): long shows number their releases with the width of the total
			total_aired = info.get('total_aired_eps') or info.get('season_episode_count') or 0
			padded_query = source_utils.padded_absolute(abs_i, total_aired)
			if padded_query:
				_add('%s - %s' % (title, padded_query))
				_add('%s %s' % (title, padded_query))

	# Releases of long / anime shows often carry the episode title ('Show - 047 - SOS from the Future ...'): one query with it
	try:
		_epn = re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9\s]', ' ', source_utils.normalize(info.get('ep_name') or '').lower().replace('&', ' and '))).strip()
		if _epn and len(_epn.split()) >= 2 and not re.match(r'^(?:episode|ep)\s*\d+$', _epn): _add('%s %s' % (title, _epn))
	except Exception: pass
	if int(season) == 0:
		# Specials: releases call them S00E##, Specials, OVA / OAD / ONA, or only carry the episode title
		for word in ('specials', 'special', 'ova', 'oad', 'sp'):
			_add('%s %s' % (title, word))
		_add('%s S00' % title)
		_add('%s season 0' % title)
		try:
			_n = int(episode)
			_add('%s OVA %d' % (title, _n)); _add('%s OVA %02d' % (title, _n)); _add('%s SP%02d' % (title, _n)); _add('%s Special %d' % (title, _n))
		except Exception: pass
		try:
			_sn = re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9\s]', ' ', source_utils.normalize(info.get('ep_name') or '').lower().replace('&', ' and '))).strip()
			if _sn and not re.match(r'^(?:episode|ep|special)\s*\d+$', _sn): _add('%s %s' % (title, _sn)); _add(_sn)
		except Exception: pass
	for alias in aliases[:2]:
		alias_normalized = source_utils.normalize(alias).lower().replace('&', ' and ')
		alias_clean = re.sub(r'[^a-z0-9\s]', '', alias_normalized).strip()
		if alias_clean and alias_clean != title:
			_add('%s %s' % (alias_clean, hdlr))
	# Bare show title — no S#E#/abs suffix. Surfaces season/show packs and
	# batch releases whose names carry no episode token. Runs LAST so the
	# targeted S#E#/abs queries claim their hits first; hash-dedup in
	# merge_name_searches() prevents any double-counting.
	_add(title)
	if punct: _add(punct)   # the whole-show search with the punctuation kept: "a returner's magic should be special" next to "a returners magic should be special"
	return queries

def series_prefix_search_queries(info, existing=()):
	"""Extra nyaa queries for '[Group] Aoki Denshou Welsh & Shedar 01': nyaa matches whole words, so 'and' never finds an '&' title
	and a bare '1' never finds '01'. Adds the title without 'and' / with '&', each with the zero-padded and the bare absolute
	number. Pure additions - results still go through the same title / episode gate."""
	try:
		if info.get('media_type') != 'episode': return []
		absolute_episode = info.get('absolute_episode')
		abs_i = int(absolute_episode) if absolute_episode not in (None, '', 0, '0') else (int(info.get('episode')) if str(info.get('season')) == '1' else 0)
		if abs_i <= 0: return []
		normalized = source_utils.normalize(info.get('title') or '').lower().replace('&', ' and ')
		base = re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9\s]', '', normalized)).strip()
		if not base: return []
		variants = [base]
		_p = punctuated_title(info.get('title') or '')
		if _p: variants.append(_p)
		if ' and ' in ' %s ' % base:
			variants.append(re.sub(r'\s+', ' ', (' %s ' % base).replace(' and ', ' ')).strip())
			variants.append(re.sub(r'\s+', ' ', (' %s ' % base).replace(' and ', ' & ')).strip())
		numbers = ['%02d' % abs_i, str(abs_i)] if abs_i < 100 else [str(abs_i)]
		_pad = source_utils.padded_absolute(abs_i, info.get('total_aired_eps') or info.get('season_episode_count') or 0)
		if _pad and _pad not in numbers: numbers.insert(0, _pad)
		seen, out = set(existing or ()), []
		for variant in variants:
			for number in numbers:
				query = '%s %s' % (variant, number)
				if variant == base and number == str(abs_i): continue # already built by name_search_queries
				if query not in seen:
					seen.add(query)
					out.append(query)
		return out
	except Exception:
		return []

def merge_name_searches(search_fn, queries, timeout, expiry):
	files, seen = [], set()
	queries = queries or []
	per_query = max(5, min(10, int(timeout) // max(1, len(queries) or 1)))
	for query in queries:
		try:
			from caches import watching_cache
			found = watching_cache.cached(getattr(search_fn, '__module__', 'native').split('.')[-1].replace('_api', ''), query,
										lambda: search_fn(query, timeout=per_query, expiration=expiry)) or []
		except Exception:
			found = search_fn(query, timeout=per_query, expiration=expiry) or []
		source_utils.diag_log('NativeQuery', 'query=%r results=%d' % (query, len(found)))
		for item in found:
			info_hash = item.get('hash')
			if info_hash and info_hash not in seen:
				seen.add(info_hash)
				files.append(item)
	source_utils.diag_log('NativeQuery', 'merged=%d from %d queries' % (len(files), len(queries)))
	return files

def filter_and_build_sources(scrape_provider, items, info):
	from modules.settings import filter_by_name, filter_by_episode_title
	from modules.kodi_utils import logger
	filter_title = filter_by_name(scrape_provider)
	from modules.kodi_utils import get_property as _get_property
	filterless = _get_property('fs_filterless_search') == 'true' # the user's explicit 'filterless search' is the only way to lift the show-name floor
	allow_episode_title = filter_by_episode_title(scrape_provider)
	title = info.get('title', '')
	year = int(info.get('year') or 0)
	season, episode = info.get('season'), info.get('episode')
	media_type = info.get('media_type')
	aliases = source_utils.get_aliases_titles(info.get('aliases', []))
	absolute_episode = info.get('absolute_episode')
	ep_name = info.get('ep_name') or ''
	extras = source_utils.extras()
	season_divider = int(info.get('season_episode_count') or 1) or 1
	show_divider = int(info.get('total_aired_eps') or 1) or 1
	
	# Log absolute episode + total aired counts for diagnostics (episode only)
	if media_type == 'episode' and absolute_episode:
		total_aired_eps = info.get('total_aired_eps') or 1
		season_episode_count = info.get('season_episode_count') or 1
		source_utils.diag_log('%s Match' % scrape_provider, 
			'S%02dE%02d (abs=%d) ep_name=%r total_aired=%d season_eps=%d' % (
				season, episode, absolute_episode, ep_name, total_aired_eps, season_episode_count))
	
	# Title gate inputs: shows exactly which show title + aliases a release is checked against
	source_utils.diag_log('%s Match' % scrape_provider, 'title gate: title=%r year=%s aliases(%d)=%s' % (
		title, year, len(aliases), ', '.join(repr(a) for a in aliases[:40]) or '-'))

	sources, seen = [], set()
	skipped = {'release_filter': 0, 'extras': 0, 'title_filter': 0, 'pack_range': 0, 'duplicate': 0, 'bad_name': 0, 'exception': 0}
	episode_targets = set()
	if media_type == 'episode':
		for value in (episode, absolute_episode):
			try:
				if value and int(value) > 0:
					episode_targets.add(int(value))
			except Exception:
				pass

	# ===== RAW DUMP (parity with RD 'FolderContents' raw listing) =====
	raw_items = items or []
	source_utils.diag_log('%s Raw' % scrape_provider, 'raw items=%d' % len(raw_items))
	for raw in raw_items:#[:80]:  # cap so huge result sets don't flood the log
		source_utils.diag_log('%s Raw' % scrape_provider,
			'  raw: hash=%s size=%.2f seeders=%d name=%r' % (
				(raw.get('hash') or '')[:12],
				raw.get('size') or 0,
				raw.get('seeders') or 0,
				raw.get('name') or ''))

	def _match_modes(file_name):
		# Same classifier rd_cloud logs alongside its verdicts (episodes only)
		if media_type != 'episode':
			return []
		try:
			return source_utils.cloud_episode_matches_all(
				season, episode, file_name, absolute_episode, ep_name)
		except Exception:
			return []

	_BOOKISH = re.compile(r'\(digital[^)]*\)|\bmanga\b|\bepub\b|\bcbz\b|\bcbr\b|\blight novel|\bost\b|soundtrack|\bcue\b|\bmp3\b', re.I)
	_VIDEOISH = re.compile(r'(?<![a-z0-9])(?:2160p|1080p|720p|480p|x264|x265|h\.?264|h\.?265|hevc|av1|web-?dl|web-?rip|bluray|bdrip|blu-ray|bd|dvd|dvd_?iso|iso|remux|film|movie|ova|ona|oad|batch|complete|season)(?![a-z0-9])', re.I)

	# The same episode under its other numbering (TMDb S01E25 = S02E01 by the season split): a pack that names the OTHER season is a pack for
	# this episode too. The (S01, absolute) form is left out for later seasons: it would let every S01 pack through for any S02 request.
	season_pairs = [(season, episode)]
	try:
		for _as, _ae in sorted(source_utils._alt_pairs(season, episode, absolute_episode)):
			if int(_as) != int(season) and not (int(_as) == 1 and int(season) != 1): season_pairs.append((_as, _ae))
	except Exception: pass

	def _pack_type(file_name):
		for _s, _e in season_pairs:
			found = pack_type_from_name(file_name, _s)
			if found: return found
		return None

	def _keep(file_name):
		if media_type in ('episode', 'movie') and _BOOKISH.search(file_name) and not _VIDEOISH.search(file_name):
			skipped['extras'] += 1
			source_utils.diag_log('%s Match' % scrape_provider, 'file REJECT (book / manga, no video tags): %r' % file_name)
			return False, None
		# Release filter removed: it is a Real-Debrid-only rule (debrid.stamp_torrent_cache / rd_cloud),
		# never applied while scraping (nyaa, animetosho, torrentio, comet, torz).
		
		# 'Show S01-S03 + Specials + Extras' is a whole-show pack that holds the episodes: an extras word in a multi-season pack name is not an extras-only release
		if source_utils.has_extras_word(file_name, extras) and not (media_type == 'episode' and _pack_type(file_name) == 'show' and
				(source_utils.names_season_set(file_name) or has_multi_season_range(file_name) or source_utils.pack_marker_hits(file_name.lower().replace(' ', '.')))):
			skipped['extras'] += 1
			source_utils.diag_log('%s Match' % scrape_provider,
				'file REJECT (extras): %r' % file_name)
			return False, None
		
		# ###FIX### Classify pack-ness FIRST. should_accept_file_title() has its own
		# pack shortcut and returns True for "Seasons 1-5" style names, so the old code
		# returned (True, None) before pack_type_from_name() ever ran -> package=None
		# -> item never got the PACK tag and was resolved as a single file.
		package = _pack_type(file_name) if media_type == 'episode' else None

		# Explicit episode range that does not contain the requested episode
		# (e.g. "Eps 001-082" for abs=83) can never yield the episode: drop it.
		if package and episode_targets:
			ranges = pack_episode_ranges(file_name)
			if ranges and not any(lo <= t <= hi for (lo, hi) in ranges for t in episode_targets):
				skipped['pack_range'] += 1
				source_utils.diag_log('%s Match' % scrape_provider,
					'file REJECT (pack range %s excludes targets=%s): %r' % (
						ranges, sorted(episode_targets), file_name))
				return False, 'pack_range'  # sentinel: already logged, skip the generic reject line

		# Show-name packs: bare show name, show + movies / OVA, franchise list, episode range covering the target
		if media_type == 'episode':
			_pk, _pk_why = source_utils.show_pack_kind(title, aliases, file_name, season, episode, absolute_episode)
			if _pk:
				source_utils.diag_log('%s Match' % scrape_provider, 'file ACCEPT (pack, %s): %r' % (_pk_why, file_name))
				return True, 'show'
		# Movies: title AND year (+/-1) must be in the name - 'Alien Resurrection 1997' / a year-less 'Alien' are not 'Alien (1979)'.
		if filter_title and media_type == 'movie' and not source_utils.external_name_ok(
				'movie', title, file_name, aliases=aliases, year=year):
			skipped['title_filter'] += 1
			return False, None

		# STEP 3: same acceptance rule as NZB / EasyNews / AIOStreams. For episodes the requested show must lead the name
		# (or S#E# / absolute number AND the episode name must both hit); a bare "<other show> The Anime S01" is not accepted.
		if media_type == 'episode':
			accepted, _why = source_utils.episode_any_match(
				title, file_name, aliases, year, season, episode,
				ep_name=ep_name, absolute_episode=absolute_episode, filter_title=filter_title,
				allow_series_prefix=True) # '[Group] Show Title 01' form: every indexer / usenet / external provider, same strict rule
		else:
			accepted = source_utils.should_accept_file_title(
				title, file_name, aliases, year, season, episode,
				ep_name=ep_name,
				absolute_episode=absolute_episode,
				in_cloud_folder=False,
				is_recovery_pass=False,
				filter_title=filter_title)
		if accepted and media_type == 'episode' and not filterless and not source_utils.show_named_in_release(title, file_name, aliases):
			# an episode-name / number-only hit never proves it is this show: other shows' 'Rebirth.S01E01' stay out
			skipped['title_filter'] += 1
			source_utils.diag_log('%s Match' % scrape_provider, 'file REJECT (show title not in name): %r' % file_name)
			return False, None
		if accepted:
			return True, package
		if package and source_utils.check_title(title, file_name, aliases, year, 'pack', episode) and not (
				media_type == 'episode' and source_utils.names_other_episode(file_name, season, episode, absolute_episode)):
			return True, package
		if media_type == 'episode' and not filterless:
			kind = None
			for _i, (_s, _e) in enumerate(season_pairs):
				kind = source_utils.loose_release_kind(file_name, title, aliases, _s, _e, absolute_episode)
				# the other numbering needs the name to say that season itself ('S02', 'Season 2', '2nd Season'): the show title alone proves nothing there
				if kind == 'season' and _i and not (pack_type_from_name(file_name, _s) or (source_utils._ORDINAL_SEASON_RE.search(file_name) and
						source_utils.names_other_episode(file_name, _s, _e, absolute_episode) is False)): kind = None
				if kind: break
			if kind:
				return True, ('season' if kind == 'season' else None)
		skipped['title_filter'] += 1
		return False, None

	for raw in raw_items:
		try:
			info_hash = raw.get('hash')
			if not info_hash or info_hash in seen:
				skipped['duplicate'] += 1
				continue
			file_name = raw.get('name') or ''
			if source_utils.is_error_release_name(file_name):
				skipped['bad_name'] += 1
				source_utils.diag_log('%s Match' % scrape_provider,
					'file REJECT path=%r (empty or invalid release name)' % file_name)
				continue
			# Pack names carry no episode token by design: running the per-episode
			# classifier on them only logs misleading EP-NUM/ABS-E FAILED/REJECT lines.
			package_hint = _pack_type(file_name) if media_type == 'episode' else None
			modes = ['PACK:%s' % package_hint] if package_hint else _match_modes(file_name)
			keep, package = _keep(file_name)
			if not keep:
				if package != 'pack_range':
					source_utils.diag_log('%s Match' % scrape_provider,
						'file REJECT path=%r modes=%s (no title/S-E/ep-name match)' % (
							file_name, modes or '[]'))
				continue
			seen.add(info_hash)
			details = pack_details(file_name) if package else None
			pack_ranges = details['ep_ranges'] if details else []
			source_utils.diag_log('%s Match' % scrape_provider,
				'file ACCEPT path=%r modes=%s package=%s %s' % (
					file_name, modes or 'title', package, pack_details_label(details) if details else 'ranges=-'))
			range_count = sum(hi - lo + 1 for (lo, hi) in pack_ranges) if pack_ranges else None
			# ###FIX### Show the REAL pack size (774.80 GB), not a per-episode estimate (0.63 GB). Dividing made packs
			# look tiny in the results list; the results size filter already exempts packs, so nothing needs the estimate.
			try: size = round(float(raw.get('size') or 0), 2)
			except Exception: size = 0.0
			sources.append(build_source(
				scrape_provider, file_name, info_hash, size, raw.get('seeders') or 0, package, details=details))
		except Exception as e:
			skipped['exception'] += 1
			logger('%s scraper yield source error' % scrape_provider, str(e))
	
	source_utils.diag_log('%s Match' % scrape_provider, 'kept=%d raw=%d' % (len(sources), len(raw_items)))
	if len(raw_items) and not sources:
		dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
		source_utils.diag_log('%s Match' % scrape_provider, 'all raw results dropped (%s)' % dropped)
	elif any(skipped.values()):
		dropped = ', '.join('%s=%s' % (k, v) for k, v in skipped.items() if v)
		source_utils.diag_log('%s Match' % scrape_provider, 'dropped (%s)' % dropped)
	return sources
