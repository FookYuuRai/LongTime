# -*- coding: utf-8 -*-
"""Scrolling file name for the player's info screen (Settings: Playback -> Show Source Filename in Player). The skin cuts
the name off after one line; while the info screen is open this draws the whole name, scrolling and looping, over that
line. It exists only while the info screen is visible: it closes with it, and any key press closes it and is handed on."""
import os
import xbmc
import xbmcgui
from threading import Thread

_ACTIONS = {1: 'Left', 2: 'Right', 3: 'Up', 4: 'Down', 7: 'Select', 9: 'Back', 10: 'Back', 92: 'Back', 11: 'Info'}


class FilenameBanner(xbmcgui.WindowXMLDialog):
	def __new__(cls, *args, **kwargs):
		return super().__new__(cls, *args)

	def onAction(self, action):
		# the banner never keeps a key to itself: close, then pass it on to the player / info screen
		try:
			name = _ACTIONS.get(action.getId())
			self.close()
			if name == 'Info': xbmc.executebuiltin('Dialog.Close(fullscreeninfo,true)')
			elif name: xbmc.executebuiltin('Action(%s)' % name)
		except Exception: pass


def _info_visible():
	return xbmc.getCondVisibility('Window.IsVisible(fullscreeninfo)')


def _run(text):
	try:
		path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))  # the add-on folder
		player, monitor, win = xbmc.Player(), xbmc.Monitor(), None
		while not monitor.abortRequested() and player.isPlaying():
			if _info_visible():
				if win is None:
					win = FilenameBanner('source_filename.xml', path, 'Default', '1080i')
					win.setProperty('filename', text)
					win.show()
			elif win is not None:
				try: win.close()
				except Exception: pass
				win = None
			if monitor.waitForAbort(0.3): break
		if win is not None:
			try: win.close()
			except Exception: pass
	except Exception as e:
		try: xbmc.log('[NIGHTSHIFT] filename banner: %s' % e, xbmc.LOGWARNING)
		except Exception: pass


def start_banner(text):
	if text: Thread(target=_run, args=(text,), daemon=True).start()
