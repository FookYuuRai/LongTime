# -*- coding: utf-8 -*-
"""TorrentDownloads, two RSS feeds (both carry the info hash, so no page scraping):
  www.torrentdownloads.pro   GET /rss.xml?new=1&type=search&cid=<4 tv | 8 anime>&search=<query>
        <item><title/><size>bytes</size><seeders/><leechers/><info_hash/></item>
  www.torrentdownload.info   GET /feed?q=<query>
        <item><title/><link>.../<NAME>/<INFOHASH></link><description>Size: 1.37 GB Seeds: 4990 , Peers: 35 Hash: <HASH></description></item>
Results of both are merged by hash (the larger size wins)."""
import re
from html import unescape
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, instance_base_url, normalize_info_hash, parse_size_gb
from apis import indexer_http

TORRENTDOWNLOADS_URLS = (
	'https://www.torrentdownloads.pro',
)
TORRENTDOWNLOAD_INFO = 'https://www.torrentdownload.info'
_SEEDS = re.compile(r'Seeds?:\s*([\d,]+)', re.I)
_SIZE = re.compile(r'Size:\s*([\d.,]+\s*[KMGT]?i?B)', re.I)
_ITEM = re.compile(r'<item>(.*?)</item>', re.I | re.S)
_CDATA = re.compile(r'<!\[CDATA\[(.*?)\]\]>', re.S)


def torrentdownloads_base_url():
	return instance_base_url('torrentdownloads.url', TORRENTDOWNLOADS_URLS, 'torrentdownloads.custom_url', 1) or TORRENTDOWNLOADS_URLS[0]


def clear_torrentdownloads_cache():
	try:
		main_cache.delete_like('TORRENTDOWNLOADS_%')
		return True
	except Exception:
		return False


def _items(xml_text):
	"""<item> blocks of a feed. Both feeds are not strictly valid XML (bare & in titles, stray text), so they are read with regexes."""
	return _ITEM.findall(xml_text or '')


def _child(block, tag):
	m = re.search(r'<%s[^>]*>(.*?)</%s>' % (tag, tag), block, re.I | re.S)
	if not m:
		return ''
	value = m.group(1).strip()
	c = _CDATA.search(value)
	if c: value = c.group(1).strip()
	return unescape(value)


def _to_int(text):
	try: return int(re.sub(r'[^\d]', '', text or '') or 0)
	except Exception: return 0


def _parse_main(xml_text):
	"""torrentdownloads.pro feed."""
	rows = []
	for it in _items(xml_text):
		info_hash = normalize_info_hash(_child(it, 'info_hash'))
		name = _child(it, 'title')
		if not info_hash or not name: continue
		size = _child(it, 'size')
		rows.append({'hash': info_hash, 'name': name, 'size': bytes_to_gb(size) if size.isdigit() else parse_size_gb(size),
					'seeders': _to_int(_child(it, 'seeders'))})
	return rows


def _parse_info(xml_text):
	"""torrentdownload.info feed: the hash is the last path part of <link> (and in the description)."""
	rows = []
	for it in _items(xml_text):
		link, desc, name = _child(it, 'link'), _child(it, 'description'), _child(it, 'title')
		info_hash = normalize_info_hash(link.rstrip('/').rsplit('/', 1)[-1]) or normalize_info_hash((re.search(r'Hash:\s*([A-Za-z0-9]+)', desc) or [None, ''])[1])
		if not info_hash or not name: continue
		size = _SIZE.search(desc)
		seeds = _SEEDS.search(desc)
		rows.append({'hash': info_hash, 'name': name.replace('-', ' ').strip() if '-' in name and ' ' not in name else name,
					'size': parse_size_gb(size.group(1)) if size else 0, 'seeders': _to_int(seeds.group(1)) if seeds else 0})
	return rows


def _merge(*groups):
	by_hash = {}
	for group in groups:
		for row in group or ():
			old = by_hash.get(row['hash'])
			if not old or (row.get('size') or 0) > (old.get('size') or 0):
				by_hash[row['hash']] = row
	return list(by_hash.values())


def _fetch(key, bases, path, params, parser, query, timeout, expiration):
	cache_key = 'TORRENTDOWNLOADS_%s_%s' % (key, query)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	try:
		text, _ = indexer_http.get_text('torrentdownloads', bases, path, params, timeout, accept='application/rss+xml, text/xml, */*',
										validate=lambda t: '<item' in (t or '') or '<rss' in (t or '')[:600])
	except Exception as e:
		logger('torrentdownloads api', '%s: %s (%s)' % (type(e).__name__, str(e)[:160], query))
		return []
	rows = parser(text)
	if rows: main_cache.set(cache_key, rows, expiration=expiration)
	return rows


def search(query, timeout=10, expiration=24, category='4', include_info=True):
	query = (query or '').strip()
	if not query:
		return []
	bases = [torrentdownloads_base_url()] + list(TORRENTDOWNLOADS_URLS)
	main = []
	for cid in ('8' if str(category) == '8' else '4', '4' if str(category) == '8' else '8'):      # TV, then anime (or the reverse)
		main = _fetch('pro%s' % cid, bases, '/rss.xml', {'new': 1, 'type': 'search', 'cid': cid, 'search': query}, _parse_main, query, timeout, expiration)
		if main: break
	if not include_info:
		return main
	info = _fetch('info', [TORRENTDOWNLOAD_INFO], '/feed', {'q': query}, _parse_info, query, timeout, expiration)
	return _merge(main, info)
