# -*- coding: utf-8 -*-
"""PirateBay through apibay's JSON endpoint:  GET <base>/q.php?q=<query>&cat=0
-> [{"id","name","info_hash","leechers","seeders","num_files","size"(bytes),"username","added","status","category","imdb"}, ...]
No hits is a single placeholder row ("No results returned", all-zero hash), which is dropped here."""
from urllib.parse import quote_plus
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, instance_base_url, normalize_info_hash
from apis import indexer_http

PIRATEBAY_URLS = (
	'https://apibay.org',
)


def piratebay_base_url():
	return instance_base_url('piratebay.url', PIRATEBAY_URLS, 'piratebay.custom_url', 1) or PIRATEBAY_URLS[0]


def piratebay_search_url(query):
	"""Kept for callers that show / test the URL: the first base that would be tried."""
	base = piratebay_base_url().rstrip('/')
	if not base or not query:
		return None
	if 'q.php' in base:
		if '%s' in base:
			return base % quote_plus(query)
		return '%s%sq=%s' % (base, '&' if '?' in base else '?', quote_plus(query))
	return '%s/q.php?q=%s&cat=0' % (base, quote_plus(query))


def clear_piratebay_cache():
	try:
		main_cache.delete_like('PIRATEBAY_%')
		return True
	except Exception:
		return False


def _bases():
	"""The chosen / custom base first, then the built-in mirrors. A custom value that already contains q.php is used as typed."""
	chosen = piratebay_base_url().rstrip('/')
	return [chosen] + [u for u in PIRATEBAY_URLS if u.rstrip('/') != chosen]


def _row(raw):
	if not isinstance(raw, dict):
		return None
	name = (raw.get('name') or '').strip()
	if not name or name.lower() == 'no results returned':
		return None
	info_hash = normalize_info_hash(raw.get('info_hash') or raw.get('infoHash') or '')
	if not info_hash or set(info_hash) == {'0'}:
		return None
	try: seeders = int(raw.get('seeders') or 0)
	except Exception: seeders = 0
	return {'hash': info_hash, 'name': name, 'size': bytes_to_gb(raw.get('size')), 'seeders': seeders}


def search(query, timeout=10, expiration=24):
	query = (query or '').strip()
	if not query:
		return []
	cache_key = 'PIRATEBAY_%s_%s' % (piratebay_base_url(), query)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	try:
		first = piratebay_base_url().rstrip('/')
		if 'q.php' in first:      # a custom full URL: use it exactly as given
			payload, _ = indexer_http.get_json('piratebay', [''], piratebay_search_url(query), timeout=timeout)
		else:
			payload, _ = indexer_http.get_json('piratebay', _bases(), '/q.php', {'q': query, 'cat': 0}, timeout)
	except Exception as e:
		logger('piratebay api', '%s: %s (%s)' % (type(e).__name__, str(e)[:200], query))
		return []
	results, seen = [], set()
	for raw in (payload if isinstance(payload, list) else []):
		row = _row(raw)
		if row and row['hash'] not in seen:
			seen.add(row['hash'])
			results.append(row)
	main_cache.set(cache_key, results, expiration=expiration)
	return results


# Knaben lives in this file: add-on updates do not always install newly added files.
_KNABEN_API_SRC = '# -*- coding: utf-8 -*-\n"""Knaben (meta-search over many trackers) through its v2 JSON API:\nGET <base>/v2/search?q=<query>&sf=title&o=seeders&d=desc&s=<=300&f=<offset>  ->  {"hits": [{"title","hash","magnetUrl","seeders","peers","bytes","tracker",...}]}\nZero-seeder rows are requested too (the bare \'dead\' flag): a torrent can be fully cached on a debrid with nobody seeding it."""\nfrom urllib.parse import quote_plus\nfrom caches.main_cache import main_cache\nfrom modules.kodi_utils import logger\nfrom modules.native_torrents import bytes_to_gb, instance_base_url, normalize_info_hash\nfrom apis import indexer_http\n\nKNABEN_URLS = (\n\t\'https://api.knaben.org\',\n)\nPAGE_SIZE = 150\n\n\ndef knaben_base_url():\n\treturn instance_base_url(\'knaben.url\', KNABEN_URLS, \'knaben.custom_url\', 1) or KNABEN_URLS[0]\n\n\ndef knaben_search_url(query):\n\tbase = knaben_base_url().rstrip(\'/\')\n\tif not base or not query:\n\t\treturn None\n\treturn \'%s/v2/search?dead&q=%s&sf=title&o=seeders&d=desc&s=%d&f=0\' % (base, quote_plus(query), PAGE_SIZE)\n\n\ndef clear_knaben_cache():\n\ttry:\n\t\tmain_cache.delete_like(\'KNABEN_%\')\n\t\treturn True\n\texcept Exception:\n\t\treturn False\n\n\ndef _bases():\n\tchosen = knaben_base_url().rstrip(\'/\')\n\treturn [chosen] + [u for u in KNABEN_URLS if u.rstrip(\'/\') != chosen]\n\n\ndef _row(raw):\n\tif not isinstance(raw, dict):\n\t\treturn None\n\tname = (raw.get(\'title\') or raw.get(\'name\') or \'\').strip()\n\tif not name:\n\t\treturn None\n\tinfo_hash = normalize_info_hash(raw.get(\'hash\') or raw.get(\'infoHash\') or \'\')\n\tif not info_hash:\n\t\tmagnet = raw.get(\'magnetUrl\') or raw.get(\'magnet\') or \'\'\n\t\tif \'btih:\' in magnet:\n\t\t\tinfo_hash = normalize_info_hash(magnet.split(\'btih:\', 1)[1].split(\'&\', 1)[0])\n\tif not info_hash or set(info_hash) == {\'0\'}:\n\t\treturn None\n\ttry: seeders = int(raw.get(\'seeders\') or 0)\n\texcept Exception: seeders = 0\n\treturn {\'hash\': info_hash, \'name\': name, \'size\': bytes_to_gb(raw.get(\'bytes\') or raw.get(\'size\')), \'seeders\': seeders}\n\n\ndef search(query, timeout=10, expiration=24):\n\tquery = (query or \'\').strip()\n\tif not query:\n\t\treturn []\n\tcache_key = \'KNABEN_%s_%s\' % (knaben_base_url(), query)\n\tcached = main_cache.get(cache_key)\n\tif cached is not None:\n\t\treturn cached\n\ttry:\n\t\tpayload, _ = indexer_http.get_json(\'knaben\', _bases(), \'/v2/search?dead\',\n\t\t\t{\'q\': query, \'sf\': \'title\', \'o\': \'seeders\', \'d\': \'desc\', \'s\': PAGE_SIZE, \'f\': 0}, timeout)\n\texcept Exception as e:\n\t\tlogger(\'knaben api\', \'%s: %s (%s)\' % (type(e).__name__, str(e)[:200], query))\n\t\treturn []\n\thits = payload.get(\'hits\') if isinstance(payload, dict) else payload\n\tresults, seen = [], set()\n\tfor raw in (hits if isinstance(hits, list) else []):\n\t\trow = _row(raw)\n\t\tif row and row[\'hash\'] not in seen:\n\t\t\tseen.add(row[\'hash\'])\n\t\t\tresults.append(row)\n\tmain_cache.set(cache_key, results, expiration=expiration)\n\treturn results\n'


def _build_knaben_api():
	import types
	module = types.ModuleType('apis.knaben_api')
	exec(compile(_KNABEN_API_SRC, 'knaben_api', 'exec'), module.__dict__)
	return module


knaben_api = _build_knaben_api()
