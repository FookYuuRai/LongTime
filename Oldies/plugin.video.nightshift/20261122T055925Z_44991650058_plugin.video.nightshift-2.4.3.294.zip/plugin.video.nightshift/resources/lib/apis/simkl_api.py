# -*- coding: utf-8 -*-
import json
import os
import time
import calendar
import requests
from datetime import datetime
from threading import Lock
from urllib.parse import urljoin, quote
from caches import simkl_cache
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils, settings, list_sort
from modules.http_defaults import META_API_TIMEOUT
from modules.utils import copy2clip, make_qrcode, make_tinyurl

BASE_URL = 'https://api.simkl.com'

# Nightshift policy: api.simkl.com is not used for lists/meta/images/search.
# Only the public non-anime TV calendar is used, via data.simkl.in CDN (not call_simkl).
SIMKL_API_DISABLED = True
_SIMKL_DISABLED_LOGGED = False


# Session breaker: after HTTP 429, skip further Simkl calls until Kodi restarts (daily limit).
_SIMKL_429_TRIPPED = False

OAUTH_DEVICE_URL = 'https://api.simkl.com/oauth2/device'
OAUTH_TOKEN_URL = 'https://api.simkl.com/oauth2/token'
DEVICE_SCOPE = 'media:read media:write'
DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code'
SIMKL_APP_NAME = 'nightshift' # short lowercase identifier, as the Simkl API asks for app-name
SIMKL_CLIENT_ID = '' # no shipped key: each user enters their own Simkl Client ID in Settings > Accounts
# Shared across plugin invokers + SimklMonitor (in-memory alone is not enough in Kodi).
_SIMKL_MIN_REQUEST_GAP = 1.5
_SIMKL_THROTTLE_PROP = 'nightshift.simkl_last_request_at'
_SIMKL_SYNC_BUSY_PROP = 'nightshift.simkl_sync_busy'
_SIMKL_SYNC_BUSY_AT_PROP = 'nightshift.simkl_sync_busy_at'
_request_lock = Lock()
_sync_lock = Lock()
_last_request_time = 0.0
_throttle_path = None

def _simkl_throttle_path():
	global _throttle_path
	if not _throttle_path:
		_throttle_path = os.path.join(kodi_utils.addon_profile(), 'simkl_api_throttle')
	return _throttle_path

def _shared_last_request_at():
	last = _last_request_time
	try:
		last = max(last, float(kodi_utils.get_property(_SIMKL_THROTTLE_PROP) or 0))
	except Exception:
		pass
	try:
		last = max(last, os.path.getmtime(_simkl_throttle_path()))
	except Exception:
		pass
	return last

def _claim_request_slot(now):
	global _last_request_time
	_last_request_time = now
	try: kodi_utils.set_property(_SIMKL_THROTTLE_PROP, '%.3f' % now)
	except Exception: pass
	try:
		path = _simkl_throttle_path()
		folder = os.path.dirname(path)
		if folder and not os.path.isdir(folder):
			try: os.makedirs(folder)
			except Exception: pass
		with open(path, 'w') as handle:
			handle.write('%.3f\n' % now)
	except Exception:
		pass

def _throttle():
	"""Space Simkl HTTP calls across threads and separate Kodi Python invokers."""
	with _request_lock:
		while True:
			now = time.time()
			wait = _SIMKL_MIN_REQUEST_GAP - (now - _shared_last_request_at())
			if wait <= 0:
				_claim_request_slot(now)
				return
			kodi_utils.sleep(int(wait * 1000) + 25)

def _client_id():
	"""Simkl Client ID from Settings > Accounts (blank when not set)."""
	try: return settings.simkl_client() or SIMKL_CLIENT_ID
	except Exception: return SIMKL_CLIENT_ID

def _simkl_token():
	from caches.settings_cache import settings_cache
	token = settings_cache.read_db_value('simkl.token')
	if token in (None, '0', '', 'empty_setting'):
		token = get_setting('nightshift.simkl.token', '0')
	return token

def _headers():
	token = _simkl_token()
	h = {'Content-Type': 'application/json', 'User-Agent': '%s/%s' % (SIMKL_APP_NAME, kodi_utils.addon_version())}
	if token not in ('0', '', None, 'empty_setting'): h['Authorization'] = 'Bearer %s' % token
	return h

def _url(path, auth=True):
	cid = _client_id()
	if not cid: return None
	base = path if path.startswith('http') else urljoin(BASE_URL, path.lstrip('/'))
	sep = '&' if '?' in base else '?'
	return '%s%sclient_id=%s&app-name=%s&app-version=%s' % (base, sep, cid, SIMKL_APP_NAME, kodi_utils.addon_version())

def _pin_headers():
	return {'User-Agent': '%s/%s' % (SIMKL_APP_NAME, kodi_utils.addon_version())}

def _device_post(url, payload):
	"""POST JSON to Simkl's OAuth 2.0 device endpoints -> (http status, dict). No redirect URL or secret is needed."""
	sep = '&' if '?' in url else '?'
	url = '%s%sapp-name=%s&app-version=%s' % (url, sep, SIMKL_APP_NAME, kodi_utils.addon_version())
	resp = requests.post(url, data=json.dumps(payload), headers=dict(_pin_headers(), **{'Content-Type': 'application/json'}), timeout=META_API_TIMEOUT)
	try: body = resp.json() or {}
	except Exception: body = {}
	return resp.status_code, body if isinstance(body, dict) else {}

def _simkl_pin_auth_url(pin):
	user_code = pin.get('user_code', '')
	if pin.get('verification_uri_complete'): return pin['verification_uri_complete']
	verify = (pin.get('verification_uri') or pin.get('verification_url') or 'https://simkl.com/pin').rstrip('/')
	return '%s/%s' % (verify, user_code)

_SIMKL_REFRESH_PROP = 'nightshift.simkl_refreshing'

def _simkl_refresh_token(used_token):
	"""AUTH V2: swap the 7-day access token for a new one with the saved refresh token (valid 180 days, renewed on every use).
	One process refreshes at a time: another process that already did leaves a different token behind, which is simply used.
	Returns True when a usable (new) access token is saved."""
	import xbmcgui
	win = xbmcgui.Window(10000)
	waited = 0
	while win.getProperty(_SIMKL_REFRESH_PROP) and waited < 20:
		kodi_utils.sleep(500); waited += 1
	current = _simkl_token()
	if current not in ('0', '', None, 'empty_setting') and current != used_token: return True
	refresh = get_setting('nightshift.simkl.refresh', '0')
	try:
		from caches.settings_cache import settings_cache
		refresh = settings_cache.read_db_value('simkl.refresh') or refresh
	except Exception: pass
	if refresh in ('0', '', None, 'empty_setting') or not _client_id():
		kodi_utils.logger('Simkl', 'access token rejected and no refresh token is saved: authorise Simkl again in Settings > Accounts')
		kodi_utils.notification('Simkl sign-in expired: authorise Simkl again in Settings > Accounts', 6000)
		return False
	win.setProperty(_SIMKL_REFRESH_PROP, 'true')
	try:
		resp = requests.post(OAUTH_TOKEN_URL, data={'grant_type': 'refresh_token', 'client_id': _client_id(), 'refresh_token': refresh},
			headers=_pin_headers(), timeout=META_API_TIMEOUT)
		try: body = resp.json() or {}
		except Exception: body = {}
		if resp.status_code == 200 and body.get('access_token'):
			set_setting('simkl.token', body['access_token'])
			if body.get('refresh_token'): set_setting('simkl.refresh', body['refresh_token'])
			from caches.settings_cache import settings_cache
			settings_cache.clear_db_cache()
			kodi_utils.logger('Simkl', 'access token refreshed')
			return True
		kodi_utils.logger('Simkl', 'refresh failed HTTP %s %s' % (resp.status_code, body.get('error') or (resp.text or '')[:120]))
		if body.get('error') in ('invalid_grant', 'invalid_client', 'invalid_request') or resp.status_code in (400, 401):
			kodi_utils.notification('Simkl sign-in expired: authorise Simkl again in Settings > Accounts', 6000)
	except Exception as e: kodi_utils.logger('Simkl Error', 'refresh: %s' % e)
	finally: win.clearProperty(_SIMKL_REFRESH_PROP)
	return False

def call_simkl(path, data=None, method=None, is_delete=False, _retried=False):
	"""All api.simkl.com traffic is disabled. Public TV calendar uses data.simkl.in CDN only."""
	global _SIMKL_DISABLED_LOGGED, _SIMKL_429_TRIPPED
	if SIMKL_API_DISABLED:
		if not _SIMKL_DISABLED_LOGGED:
			_SIMKL_DISABLED_LOGGED = True
			kodi_utils.logger('Simkl', 'api.simkl.com disabled — only public non-anime TV calendar (CDN) is allowed; path blocked: %s' % (path or '')[:80])
		return None
	if _SIMKL_429_TRIPPED:
		return None
	_throttle()
	url = _url(path)
	if not url: return None
	headers = _headers()
	try:
		if is_delete:
			resp = requests.delete(url, headers=headers, timeout=META_API_TIMEOUT)
		elif method == 'get' or (data is None and not method):
			resp = requests.get(url, headers=headers, timeout=META_API_TIMEOUT)
		else:
			payload = json.dumps(data) if isinstance(data, (dict, list)) else data
			resp = requests.post(url, data=payload, headers=headers, timeout=META_API_TIMEOUT)
		if resp.status_code in (200, 201): return resp.json() if resp.text else True
		if resp.status_code == 204: return True
		if resp.status_code == 401 and not _retried and 'Authorization' in headers:
			if _simkl_refresh_token(headers['Authorization'][7:]): return call_simkl(path, data=data, method=method, is_delete=is_delete, _retried=True)
		body = ''
		try: body = (resp.text or '')[:200]
		except Exception: pass
		if resp.status_code == 429:
			_SIMKL_429_TRIPPED = True
			kodi_utils.logger('Simkl', 'HTTP 429 daily limit — further Simkl API calls disabled until Kodi restart (public TV calendar / personal lists only need Simkl; episode images use TMDb)')
		else:
			kodi_utils.logger('Simkl', 'HTTP %s %s %s%s' % (resp.status_code, url.split('?')[0], body, ' (no access token: authorize Simkl in Settings > Accounts)' if resp.status_code == 401 and 'Authorization' not in headers else ''))
	except Exception as e: kodi_utils.logger('Simkl Error', str(e))
	return None

def _simkl_latin_title(name):
	"""Romaji / English / abbreviation usable against Latin release names (skips CJK, Cyrillic, anything under 3 letters)."""
	try:
		from modules.source_utils import normalize
		letters = [c for c in normalize(name or '') if c.isalpha()]
		return len(letters) >= 3 and sum(1 for c in letters if ord(c) < 0x0250) >= int(len(letters) * 0.85)
	except Exception: return False

def simkl_episode_images(tvdb_id):
	"""{'season,episode': picture url} from Simkl's episode pictures for a TVDB show (simkl.in/episodes/<img>_w.jpg). Needs the Simkl
	account. Cached 7 days once Simkl answered; {} when the account is not signed in or Simkl has no link for the show."""
	if not tvdb_id or str(tvdb_id) in ('None', '0', '0000000', ''): return {}
	from caches.meta_cache import meta_cache
	prop = 'simkl_ep_images_%s' % tvdb_id
	cached = meta_cache.get_function(prop)
	if cached is not None: return cached
	found = call_simkl('/search/id?tvdb=%s' % tvdb_id)
	sid = ((found[0].get('ids') or {}).get('simkl') if isinstance(found, list) and found else None)
	if not sid: return {}
	eps = call_simkl('/tv/episodes/%s' % sid)
	if not isinstance(eps, list): return {}
	out = {}
	for e in eps:
		try:
			if e.get('img'): out['%d,%d' % (int(e.get('season')), int(e.get('episode')))] = 'https://simkl.in/episodes/%s_w.jpg' % e['img']
		except Exception: continue
	meta_cache.set_function(prop, out, expiration=168)
	return out

def simkl_anime_titles(tmdb_id=None, tvdb_id=None, imdb_id=None):
	"""Simkl's title, English title, romaji and Latin alternative names for an anime (series level).

	Looked up by TVDb / IMDb first (Simkl's TMDb id can be a wrong movie id on season-split entries), then TMDb.
	Cached per id; a failed request is not cached so it is retried next time."""
	empty = ('None', None, '', 'empty_setting', 0, '0', '0000000', 'tt0000000')
	lookups = [(k, v) for k, v in (('tvdb', tvdb_id), ('imdb', imdb_id), ('tmdb', tmdb_id)) if v not in empty]
	if not lookups: return []
	cache_key = 'anime_titles_%s_%s' % lookups[0]
	try:
		cached = simkl_cache.simkl_cache.get(cache_key)
		if isinstance(cached, list): return cached
	except Exception: pass
	try:
		sid = None
		for key, value in lookups:
			path = '/search/id?%s=%s' % (key, quote(str(value)))
			if key == 'tmdb': path += '&type=tv'
			result = call_simkl(path, method='get')
			if result is None: return []
			for row in result if isinstance(result, list) else []:
				if isinstance(row, dict) and row.get('type') == 'anime' and (row.get('ids') or {}).get('simkl'):
					sid = row['ids']['simkl']
					break
			if sid: break
		if not sid:
			simkl_cache.simkl_cache.set(cache_key, [])
			return []
		detail = call_simkl('/anime/%s' % sid, method='get')
		if not isinstance(detail, dict): return []
		names = [detail.get('title'), detail.get('en_title'), detail.get('title_romaji')]
		for alt in detail.get('alt_titles') or []:
			# 'short' alt names carry abbreviations people put in release names (DBZ, DBS, SAO); 3+ letters only (checked below).
			if isinstance(alt, dict): names.append(alt.get('name'))
		out, seen = [], set()
		for name in names:
			if not name or not _simkl_latin_title(name) or name.casefold() in seen: continue
			seen.add(name.casefold())
			out.append(name)
		simkl_cache.simkl_cache.set(cache_key, out)
		return out
	except Exception as e:
		kodi_utils.logger('Simkl Titles', str(e))
		return []

def simkl_get_pin():
	"""Ask Simkl for a device code: {user_code, device_code, verification_uri, expires_in, interval} or None."""
	cid = _client_id()
	if not cid:
		try:
			cid = (kodi_utils.kodi_dialog().input('Simkl Client ID') or '').strip()
			if cid:
				set_setting('simkl.client', cid)
				from caches.settings_cache import settings_cache
				settings_cache.clear_db_cache()
		except Exception: cid = ''
	if not cid: return None
	try:
		status, body = _device_post(OAUTH_DEVICE_URL, {'client_id': cid, 'scope': DEVICE_SCOPE})
		return body if status == 200 and body.get('user_code') else None
	except Exception: return None

def simkl_test_client_id():
	"""Request a device code - the same acceptance check Trakt/PunchPlay use for client keys."""
	cid = _client_id()
	if not cid:
		return False, 'Simkl Client ID Key is not set.'
	try:
		status, body = _device_post(OAUTH_DEVICE_URL, {'client_id': cid, 'scope': DEVICE_SCOPE})
		if status == 200:
			if body.get('user_code'): return True, 'Simkl Client ID Key is valid.'
			return False, 'Simkl Client ID Key failed.[CR]Simkl returned an empty device code.'
		detail = body.get('error_description') or body.get('message') or body.get('error') or 'No details returned.'
		return False, 'Simkl Client ID Key failed.[CR]Simkl rejected the Client ID (HTTP %s).[CR]%s' % (status, detail)
	except Exception as e:
		return False, 'Simkl Client ID Key failed.[CR]Could not reach Simkl: %s' % str(e)

def simkl_poll_pin(pin):
	user_code, device_code = pin.get('user_code'), pin.get('device_code')
	if not user_code or not device_code: return None
	expires_in = int(pin.get('expires_in') or 900)
	interval = max(int(pin.get('interval') or 5), 1)
	auth_url = _simkl_pin_auth_url(pin)
	qr_code = make_qrcode(auth_url) or ''
	copy2clip(auth_url)
	short_url = make_tinyurl(auth_url)
	p_dialog_insert = '[CR]OR visit [B]%s[/B]' % short_url if short_url else ''
	content = 'Enter [B]%s[/B] at [B]simkl.com/pin[/B][CR]OR scan the [B]QR Code[/B]%s[CR][CR]Waiting for authorisation...' % (user_code, p_dialog_insert)
	progress = kodi_utils.progress_dialog('Simkl Authorise', qr_code)
	progress.update(content, 0)
	expires = time.time() + expires_in
	while time.time() < expires:
		if progress.iscanceled():
			progress.close()
			return None
		_throttle()
		try:
			status, resp = _device_post(OAUTH_TOKEN_URL, {'client_id': _client_id(), 'device_code': device_code, 'grant_type': DEVICE_GRANT})
			if resp.get('access_token'):
				progress.close()
				return resp
			error = str(resp.get('error') or '')
			if error in ('access_denied', 'expired_token', 'invalid_grant', 'invalid_client'):
				progress.close()
				return None
			if error == 'slow_down': interval += 5
		except Exception: pass
		progress.update(content, int(100 * (1 - (expires - time.time()) / float(expires_in))))
		kodi_utils.sleep(interval * 1000)
	progress.close()
	return None

def simkl_authenticate(dummy=''):
	pin = simkl_get_pin()
	if not pin or not pin.get('user_code'): return kodi_utils.notification('Simkl Authorisation Failed', 3000)
	granted = simkl_poll_pin(pin)
	if not granted: return kodi_utils.notification('Simkl Authorisation Canceled', 3000)
	set_setting('simkl.token', granted['access_token'])
	set_setting('simkl.refresh', granted.get('refresh_token') or '0')
	from caches.settings_cache import settings_cache
	settings_cache.clear_db_cache()
	# Simkl requires POST /users/settings (no body) — GET fails and falls back to "Simkl User".
	info = call_simkl('/users/settings', data={})
	if info and info.get('user'):
		u = info['user']
		set_setting('simkl.user', str(u.get('name') or u.get('login') or u.get('username') or 'Simkl User'))
	else: set_setting('simkl.user', 'Simkl User')
	settings.offer_watched_provider(2, 'Simkl')
	kodi_utils.notification('Simkl Account Authorised', 3000)
	simkl_sync_activities(force_update=True)
	try: kodi_utils.container_refresh()
	except: pass
	return True

SIMKL_TRAKT_IMPORT_URL = 'https://simkl.com/apps/import/trakt/'

def simkl_import_trakt(params=None):
	from threading import Thread
	from modules.trakt_import_help import open_official_trakt_import_page
	def _after():
		Thread(target=simkl_sync_activities, kwargs={'force_update': True}, daemon=True).start()
	return open_official_trakt_import_page(
		'Simkl', SIMKL_TRAKT_IMPORT_URL,
		icon=kodi_utils.get_icon('simkl') or kodi_utils.addon_icon(),
		after_close=_after)


def simkl_revoke_authentication(dummy=''):
	set_setting('simkl.user', 'empty_setting')
	set_setting('simkl.token', '0')
	set_setting('simkl.refresh', '0')
	settings.fallback_watched_provider_on_revoke(2)
	simkl_cache.clear_all_simkl_cache_data(silent=True, refresh=False)
	kodi_utils.notification('Simkl Authorisation Reset', 3000)

def _tmdb_id(ids):
	try:
		if ids.get('tmdb'): return str(int(ids['tmdb']))
	except: pass
	return None

# Defined early — anime id enrich helpers use this before the sync-cache block below.
_SIMKL_ID_EMPTY = ('None', None, '', 'empty_setting', 0, '0')

def _simkl_ids_from_dict(ids):
	media_ids = {}
	if not isinstance(ids, dict): return media_ids
	for key in ('tmdb', 'imdb', 'tvdb', 'simkl'):
		value = ids.get(key)
		if value in _SIMKL_ID_EMPTY: continue
		if key in ('tmdb', 'tvdb', 'simkl'):
			try: value = int(value)
			except: pass
		media_ids[key] = value
	return media_ids

def _simkl_enrich_anime_ids(simkl_id, media_ids):
	"""Sync all-items often omits TVDb / ships movie TMDb ids for season-split anime."""
	try:
		sid = int(simkl_id)
	except: return media_ids
	cache_key = 'anime_ids_%s' % sid
	try:
		cached = simkl_cache.simkl_cache.get(cache_key)
		if isinstance(cached, dict):
			merged = dict(media_ids or {})
			for key, value in cached.items():
				if key not in merged and value not in _SIMKL_ID_EMPTY: merged[key] = value
			return merged
	except: pass
	detail = call_simkl('/anime/%s' % sid, method='get')
	if not isinstance(detail, dict): return media_ids
	detail_ids = _simkl_ids_from_dict(detail.get('ids') or {})
	try: simkl_cache.simkl_cache.set(cache_key, detail_ids)
	except: pass
	merged = dict(media_ids or {})
	for key, value in detail_ids.items():
		if key not in merged and value not in _SIMKL_ID_EMPTY: merged[key] = value
	return merged

def _simkl_media_ids(item, media_kind):
	try:
		if media_kind == 'movies': obj = item.get('movie')
		else: obj = item.get('show') or item.get('anime')
		if not isinstance(obj, dict): obj = item
		ids = obj.get('ids') or item.get('ids') or {}
		if not isinstance(ids, dict): ids = {}
		media_ids = _simkl_ids_from_dict(ids)
		if media_kind == 'anime':
			simkl_id = ids.get('simkl')
			# Incomplete sync ids (e.g. Re:Zero S4 = episode IMDb only; Steel Ball Run = dead TMDb only).
			if simkl_id and not (media_ids.get('tvdb') and media_ids.get('imdb') and media_ids.get('tmdb')):
				media_ids = _simkl_enrich_anime_ids(simkl_id, media_ids)
		return media_ids
	except: return {}

def _simkl_all_items(media_kind, status):
	# Default sync payload includes title/year (needed for list_sort). ids_only strips titles and
	# makes Title A–Z a no-op.
	path = '/sync/all-items/%s/%s' % (media_kind, status)
	response = call_simkl(path, method='get')
	if response is None:
		kodi_utils.logger('Simkl', 'list fetch failed: %s' % path)
		return None
	if response is True:
		return []
	if isinstance(response, list):
		return response
	if not isinstance(response, dict):
		kodi_utils.logger('Simkl', 'list fetch unexpected response for %s: %s' % (path, type(response).__name__))
		return None
	items = response.get(media_kind)
	if items is None and media_kind in ('shows', 'anime'):
		items = response.get('shows') or response.get('anime')
	if items is None:
		items = response.get('items') or response.get('list')
	if items is None:
		return []
	return items if isinstance(items, list) else []

def _simkl_release_key(item, media_kind):
	block = _simkl_item_block(item, media_kind)
	if not isinstance(block, dict): block = {}
	for key in ('released', 'released_at', 'first_aired', 'aired'):
		val = block.get(key)
		if val not in (None, '', 'None'): return val
	year = block.get('year')
	if year not in (None, '', 'None', 0):
		try: return '%04d-01-01' % int(year)
		except: pass
	return '9999-12-31' if media_kind == 'movies' else '9999-12-31T00:00:00.000Z'

_SIMKL_STATUS_CACHE_PREFIX = 'simkl_all_items'
_SIMKL_LIST_ACTIVITY_KEYS = ('plantowatch', 'watching', 'completed', 'hold', 'dropped', 'removed_from_list', 'all')
_SIMKL_STATUS_KEYS = ('plantowatch', 'watching', 'completed', 'hold', 'dropped')
_SIMKL_STATUS_LABELS = {'plantowatch': 'Plan to Watch', 'watching': 'Watching', 'completed': 'Completed', 'hold': 'On Hold', 'dropped': 'Dropped'}

def _simkl_list_cache_key(media_kind, status):
	return '%s_%s_%s' % (_SIMKL_STATUS_CACHE_PREFIX, media_kind, status)

def clear_simkl_list_status_cache(media_kind=None, status=None):
	try:
		from caches.lists_cache import lists_cache
		if media_kind and status:
			lists_cache.delete(_simkl_list_cache_key(media_kind, status))
		elif media_kind:
			if media_kind == 'movies': kinds = ('movies',)
			elif media_kind == 'anime': kinds = ('anime',)
			else: kinds = ('shows', 'anime')
			for kind in kinds:
				for st in _SIMKL_STATUS_KEYS:
					lists_cache.delete(_simkl_list_cache_key(kind, st))
		else:
			lists_cache.delete_like('%s_%%' % _SIMKL_STATUS_CACHE_PREFIX)
	except: pass

def _simkl_item_block(item, media_kind):
	if media_kind == 'movies': return item.get('movie', {}) or {}
	return item.get('show') or item.get('anime') or {}

def _simkl_normalize_list_item(item, media_kind, order):
	if not isinstance(item, dict) or item.get('is_rewatch'): return None
	media_ids = _simkl_media_ids(item, media_kind)
	if not media_ids: return None
	block = _simkl_item_block(item, media_kind)
	return {'order': order, 'media_ids': media_ids, 'type': 'movie' if media_kind == 'movies' else 'show',
		'title': block.get('title', ''), 'collected_at': item.get('added_to_watchlist_at') or '',
		'released': _simkl_release_key(item, media_kind)}

def _simkl_sort_status_list(result, status, media_kind):
	# Anime shelves use the shows sort default (same episode content type in NIGHTSHIFT).
	sort_media = 'movies' if media_kind == 'movies' else 'shows'
	try: return list_sort.sort_source(result, 'simkl.%s' % status, sort_media, 'simkl')
	except Exception as e:
		kodi_utils.logger('Simkl', 'sort %s/%s failed: %s' % (media_kind, status, e))
		return result

def _simkl_store_status_list(media_kind, status, result):
	try:
		from caches.lists_cache import lists_cache
		lists_cache.set(_simkl_list_cache_key(media_kind, status), result, expiration=settings.lists_cache_duraton())
	except: pass

def _simkl_fetch_status_live(media_kind, status):
	items = _simkl_all_items(media_kind, status)
	if items is None: return None
	result, skipped = [], 0
	for count, item in enumerate(items, 1):
		entry = _simkl_normalize_list_item(item, media_kind, count)
		if entry is None:
			if isinstance(item, dict) and not item.get('is_rewatch'): skipped += 1
			continue
		result.append(entry)
	if skipped and not result:
		kodi_utils.logger('Simkl', 'list %s/%s: %s items had no tmdb/imdb/tvdb ids' % (media_kind, status, skipped))
	return _simkl_sort_status_list(result, status, media_kind)

def _simkl_warm_status_caches(media_kind):
	"""One /sync/all-items/{type}/all pull; fill every status bucket (avoids 5× throttle)."""
	items = _simkl_all_items(media_kind, 'all')
	if items is None: return False
	buckets = {st: [] for st in _SIMKL_STATUS_KEYS}
	skipped, unstatused = 0, 0
	for item in items:
		if not isinstance(item, dict) or item.get('is_rewatch'): continue
		st = (item.get('status') or '').lower()
		if st not in buckets:
			unstatused += 1
			continue
		entry = _simkl_normalize_list_item(item, media_kind, len(buckets[st]) + 1)
		if entry is None:
			skipped += 1
			continue
		buckets[st].append(entry)
	# Rows without status mean we cannot bucket — fall back to per-status fetches.
	if unstatused and not any(buckets.values()):
		kodi_utils.logger('Simkl', 'list %s/all: %s items missing status; using per-status fetch' % (media_kind, unstatused))
		return False
	if skipped:
		kodi_utils.logger('Simkl', 'list %s/all: skipped %s items without ids' % (media_kind, skipped))
	for st, result in buckets.items():
		_simkl_store_status_list(media_kind, st, _simkl_sort_status_list(result, st, media_kind))
	return True

def _simkl_fetch_status(media_kind, status):
	if not settings.simkl_user_active(): return []
	try:
		from caches.lists_cache import lists_cache
		cached = lists_cache.get(_simkl_list_cache_key(media_kind, status))
		if cached is not None: return cached
	except: pass
	# Prefer one /all pull so manager + multi-shelf opens don't pay 5× API throttle.
	if _simkl_warm_status_caches(media_kind):
		try:
			from caches.lists_cache import lists_cache
			cached = lists_cache.get(_simkl_list_cache_key(media_kind, status))
			if cached is not None: return cached
		except: pass
	result = _simkl_fetch_status_live(media_kind, status)
	result = [] if result is None else result
	_simkl_store_status_list(media_kind, status, result)
	return result

def _simkl_fetch_tv_status(status):
	"""Shows + anime combined (Next Episodes watchlist, manager membership, dropped IDs)."""
	shows = _simkl_fetch_status('shows', status)
	anime = _simkl_fetch_status('anime', status)
	if not shows and not anime: return []
	return list_sort.sort_source(shows + anime, 'simkl.%s' % status, 'shows', 'simkl')

def simkl_plantowatch(media_kind, page_no=None):
	return _simkl_fetch_status(media_kind, 'plantowatch')

def simkl_completed(media_kind, page_no=None):
	return _simkl_fetch_status(media_kind, 'completed')

def simkl_watching(media_kind, page_no=None):
	return _simkl_fetch_status(media_kind, 'watching')

def simkl_hold(media_kind, page_no=None):
	return _simkl_fetch_status(media_kind, 'hold')

def simkl_dropped(media_kind, page_no=None):
	return _simkl_fetch_status(media_kind, 'dropped')

_SIMKL_DROPPED_CACHE_KEY = 'simkl_hidden_items_dropped'

def clear_simkl_dropped_cache():
	simkl_cache.simkl_cache.delete(_SIMKL_DROPPED_CACHE_KEY)

def simkl_get_dropped_items():
	cached = simkl_cache.simkl_cache.get(_SIMKL_DROPPED_CACHE_KEY)
	if cached is not None: return cached
	items = []
	for item in _simkl_fetch_tv_status('dropped'):
		try:
			tmdb_id = item.get('media_ids', {}).get('tmdb')
			if tmdb_id: items.append(int(tmdb_id))
		except: pass
	simkl_cache.simkl_cache.set(_SIMKL_DROPPED_CACHE_KEY, items)
	return items

def _simkl_list_ids(tmdb_id, imdb_id=None, tvdb_id=None, simkl_id=None):
	# Prefer Simkl's own id for season-split anime — parent TMDb/IMDb/TVDb often miss the library row.
	if simkl_id not in _SIMKL_ID_EMPTY:
		try: return {'simkl': int(simkl_id)}
		except: return {'simkl': simkl_id}
	ids = {'tmdb': int(tmdb_id)}
	if imdb_id and imdb_id not in ('None', None, ''): ids['imdb'] = imdb_id
	if tvdb_id and str(tvdb_id) not in ('None', '0', ''):
		try: ids['tvdb'] = int(tvdb_id)
		except: ids['tvdb'] = tvdb_id
	return ids

def _simkl_list_bucket(media_type, media_kind=None):
	if media_type == 'movie': return 'movies'
	if media_kind == 'anime': return 'anime'
	return 'shows'

def _simkl_list_add_ok(result, media_type, media_kind=None):
	if not isinstance(result, dict): return False
	keys = ('movies',) if media_type == 'movie' else ('shows', 'anime')
	added = result.get('added') or {}
	for key in keys:
		if added.get(key): return True
	not_found = result.get('not_found') or {}
	for key in keys:
		if not_found.get(key):
			kodi_utils.logger('Simkl', 'add-to-list not_found: %s' % not_found.get(key))
			break
	return False

def _simkl_list_remove_ok(result, media_type, media_kind=None):
	# Bare True/empty body used to toast Success while deleting nothing (season-split anime miss).
	if not isinstance(result, dict): return False
	keys = ('movies',) if media_type == 'movie' else ('shows', 'anime')
	deleted = result.get('deleted') or {}
	if not isinstance(deleted, dict): return False
	for key in keys:
		val = deleted.get(key)
		if val: return True
	return False

def _simkl_refresh_after_list_change(listname=None, media_type='movie', media_kind=None):
	clear_simkl_dropped_cache()
	if media_type == 'movie': clear_simkl_list_status_cache('movies')
	elif media_kind == 'anime': clear_simkl_list_status_cache('anime')
	else: clear_simkl_list_status_cache('shows')
	if settings.watched_indicators() == 2:
		simkl_sync_activities()
	if kodi_utils.path_check('simkl') or kodi_utils.external():
		kodi_utils.kodi_refresh()

def _simkl_id_match(item_ids, imdb_id=None, tvdb_id=None, tmdb_id=None, simkl_id=None):
	if not isinstance(item_ids, dict): return False
	if simkl_id not in _SIMKL_ID_EMPTY and str(item_ids.get('simkl')) == str(simkl_id): return True
	if imdb_id and imdb_id not in _SIMKL_ID_EMPTY and str(item_ids.get('imdb')) == str(imdb_id): return True
	if tvdb_id and tvdb_id not in _SIMKL_ID_EMPTY and str(item_ids.get('tvdb')) == str(tvdb_id): return True
	if tmdb_id and tmdb_id not in _SIMKL_ID_EMPTY and str(item_ids.get('tmdb')) == str(tmdb_id): return True
	return False

def _simkl_item_in_status(media_type, status, imdb_id=None, tvdb_id=None, tmdb_id=None, simkl_id=None, media_kind=None):
	try:
		if media_type == 'movie':
			items = _simkl_fetch_status('movies', status)
		elif media_kind in ('shows', 'anime'):
			items = _simkl_fetch_status(media_kind, status)
		else:
			items = _simkl_fetch_tv_status(status)
		for item in items:
			if _simkl_id_match(item.get('media_ids'), imdb_id, tvdb_id, tmdb_id, simkl_id): return True
	except: pass
	return False

def simkl_search_my_lists(query):
	query = (query or '').strip().lower()
	if not query or not settings.simkl_user_active(): return []
	results = []
	statuses = ('plantowatch', 'completed', 'watching', 'hold', 'dropped')
	for status in statuses:
		for item in _simkl_fetch_status('movies', status):
			if status in ('watching', 'hold'): continue
			title = (item.get('title') or '').strip()
			if query not in title.lower(): continue
			entry = dict(item)
			entry['status'] = status
			entry['status_label'] = _SIMKL_STATUS_LABELS.get(status, status)
			entry['media_kind'] = 'movies'
			results.append(entry)
	for status in statuses:
		for media_kind in ('shows', 'anime'):
			for item in _simkl_fetch_status(media_kind, status):
				title = (item.get('title') or '').strip()
				if query not in title.lower(): continue
				entry = dict(item)
				entry['status'] = status
				entry['status_label'] = _SIMKL_STATUS_LABELS.get(status, status)
				entry['media_kind'] = media_kind
				results.append(entry)
	return results

def simkl_manager_choice(params):
	if not settings.simkl_user_active(): return kodi_utils.notification('No Active Simkl Account', 3500)
	media_type = params.get('media_type') or params.get('content') or 'movie'
	list_media = 'movie' if media_type == 'movie' else 'tvshow'
	media_kind = params.get('simkl_media_kind') or None
	icon = params.get('icon') or kodi_utils.get_icon('simkl')
	imdb_id, tvdb_id, tmdb_id = params.get('imdb_id'), params.get('tvdb_id'), params.get('tmdb_id')
	simkl_id = params.get('simkl_id')
	status_map = [
		('plantowatch', 'Add to [B]Plan to Watch[/B]', 'Remove from [B]Plan to Watch[/B]'),
		('completed', 'Add to [B]Completed[/B]', 'Remove from [B]Completed[/B]'),
		('dropped', 'Add to [B]Dropped[/B]', 'Remove from [B]Dropped[/B]')
	]
	if media_type != 'movie':
		status_map.insert(1, ('watching', 'Add to [B]Watching[/B]', 'Remove from [B]Watching[/B]'))
		status_map.insert(3, ('hold', 'Add to [B]On Hold[/B]', 'Remove from [B]On Hold[/B]'))
	choices = []
	kind = media_kind if media_kind in ('shows', 'anime', 'movies') else None
	for status, add_label, remove_label in status_map:
		if _simkl_item_in_status(list_media, status, imdb_id, tvdb_id, tmdb_id, simkl_id, kind):
			choices.append((remove_label, 'remove_%s' % status))
		else:
			choices.append((add_label, status))
	from indexers.dialogs import _manager_mark_watched_choices
	choices.extend(_manager_mark_watched_choices(params))
	choices.extend([
		('Reset [B]Scrobble[/B]', 'reset_scrobble'),
		('Open [B]Plan to Watch[/B]', 'open_plantowatch'),
		('Open [B]Completed[/B]', 'open_completed'),
	])
	if media_type != 'movie':
		choices.append(('Open [B]Watching[/B]', 'open_watching'))
		choices.append(('Open [B]On Hold[/B]', 'open_hold'))
	choices.extend([
		('Open [B]Dropped[/B]', 'open_dropped'),
		('Open [B]Simkl Lists[/B]', 'open_lists'),
		('Refresh Widgets', 'refresh'),
	])
	list_items = [{'line1': item[0], 'icon': icon} for item in choices]
	choice = kodi_utils.select_dialog([i[1] for i in choices], **{'items': json.dumps(list_items), 'heading': 'Simkl Lists Manager'})
	if choice == None: return
	if choice == 'refresh':
		kodi_utils.kodi_refresh()
		return kodi_utils.notification('Widgets Refreshed', 2500)
	open_modes = {
		'open_plantowatch': 'navigator.simkl_watchlists',
		'open_completed': 'navigator.simkl_completed',
		'open_watching': 'navigator.simkl_watching',
		'open_hold': 'navigator.simkl_hold',
		'open_dropped': 'navigator.simkl_dropped',
		'open_lists': 'navigator.simkl_lists',
	}
	if choice in open_modes:
		return kodi_utils.container_update({'mode': open_modes[choice]})
	if choice == 'mark_watched':
		from indexers.dialogs import _trakt_manager_mark
		return _trakt_manager_mark(params, 'mark_as_watched')
	if choice == 'mark_unwatched':
		from indexers.dialogs import _trakt_manager_mark
		return _trakt_manager_mark(params, 'mark_as_unwatched')
	if choice == 'reset_scrobble':
		return simkl_reset_scrobble(params)
	if choice in ('plantowatch', 'watching', 'completed', 'hold', 'dropped'):
		return simkl_add_to_list(choice, tmdb_id, list_media, imdb_id, tvdb_id, simkl_id, media_kind)
	if choice.startswith('remove_'):
		return simkl_remove_from_list(choice.replace('remove_', ''), tmdb_id, list_media, imdb_id, tvdb_id, simkl_id, media_kind)

def simkl_hide_unhide_progress_items(params):
	action, media_id = params['action'], params.get('media_id')
	imdb_id, tvdb_id = params.get('imdb_id'), params.get('tvdb_id', 'None')
	if action == 'drop': return simkl_add_to_list('dropped', media_id, 'tvshow', imdb_id, tvdb_id)
	return simkl_remove_from_list('dropped', media_id, 'tvshow', imdb_id, tvdb_id)

def _simkl_history_counts_ok(result, action, media_type):
	"""True when Simkl reports added/deleted counts > 0 (not a silent no-op)."""
	if not isinstance(result, dict): return False
	result_key = 'added' if action == 'mark_as_watched' else 'deleted'
	bucket = result.get(result_key) or {}
	if media_type == 'movie':
		keys = ('movies',)
	else:
		keys = ('shows', 'anime', 'episodes')
	if bucket.get('episodes', 0) > 0: return True
	for item_key in keys:
		val = bucket.get(item_key, 0)
		if isinstance(val, list) and val: return True
		try:
			if int(val or 0) > 0: return True
		except Exception:
			pass
	return False

def _simkl_history_not_found(result):
	if not isinstance(result, dict): return False
	nf = result.get('not_found') or {}
	for key in ('movies', 'shows', 'anime', 'episodes'):
		val = nf.get(key)
		if isinstance(val, list) and val: return True
		try:
			if int(val or 0) > 0: return True
		except Exception:
			pass
	return False

def _simkl_added_episodes(result, action='mark_as_watched'):
	if not isinstance(result, dict): return 0
	key = 'added' if action == 'mark_as_watched' else 'deleted'
	try: return int((result.get(key) or {}).get('episodes') or 0)
	except Exception:
		return 0

def _simkl_regular_season_numbers(tmdb_id):
	try:
		from modules import metadata
		from modules.utils import get_datetime
		meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	except Exception:
		meta = None
	nums, seen = [], set()
	for item in (meta or {}).get('season_data') or []:
		try: n = int(item.get('season_number'))
		except Exception: continue
		if n > 0 and n not in seen:
			seen.add(n)
			nums.append(n)
	return nums

def _simkl_tmdb_is_anime(tmdb_id):
	"""TMDb anime keyword — used to choose Simkl anime[] history vs shows[]."""
	try:
		from modules.metadata import is_anime_check
		return bool(is_anime_check(tmdb_id=str(tmdb_id)))
	except Exception:
		return False

def _simkl_history_tv_entry(tmdb_id, tvdb_id=0, season=None, episode=None, watched_at=None, use_tvdb_anime_seasons=False):
	entry = {'ids': _simkl_list_ids(tmdb_id, tvdb_id=tvdb_id)}
	# Kodi/TMDb season numbering for anime needs this flag or Simkl may only set watching status.
	if use_tvdb_anime_seasons:
		entry['use_tvdb_anime_seasons'] = True
	if season is not None and episode is not None:
		ep = {'number': int(episode)}
		if watched_at: ep['watched_at'] = watched_at
		entry['seasons'] = [{'number': int(season), 'episodes': [ep]}]
	elif season is not None:
		entry['seasons'] = [{'number': int(season)}]
	return entry

def _simkl_history_expand_seasons(url, tmdb_id, tvdb_id, bucket, use_tvdb):
	"""Whole-show history can move Completed without episode timestamps (Force Sync then undoes local ticks).
	Season-number POSTs are Simkl's documented 'mark every episode in this season'."""
	nums = _simkl_regular_season_numbers(tmdb_id)
	if not nums: return False, None
	entry = _simkl_history_tv_entry(tmdb_id, tvdb_id, None, None, None, use_tvdb)
	entry['seasons'] = [{'number': n} for n in nums]
	result = call_simkl(url, data={bucket: [entry]})
	kodi_utils.logger('Simkl', 'history show season-expand tmdb=%s seasons=%s added_episodes=%s' % (
		tmdb_id, len(nums), _simkl_added_episodes(result)))
	return True, result

def simkl_watched_status_mark(action, media_type, tmdb_id, tvdb_id=0, season=None, episode=None):
	if action == 'mark_as_watched':
		url = '/sync/history'
		watched_at = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
	else:
		url = '/sync/history/remove'
		watched_at = None
	if media_type == 'movie':
		item = {'ids': {'tmdb': int(tmdb_id)}}
		if watched_at: item['watched_at'] = watched_at
		result = call_simkl(url, data={'movies': [item]})
		if _simkl_history_counts_ok(result, action, 'movie'):
			return True
		# Already clear on Simkl.
		if action == 'mark_as_unwatched' and isinstance(result, dict): return True
		# Add with 0 added = already watched (e.g. finished after mid-play pause, or marked in Simkl app).
		# Same idea as Trakt — not a failure unless Simkl reports not_found.
		if action == 'mark_as_watched' and isinstance(result, dict) and not _simkl_history_not_found(result):
			return True
		kodi_utils.logger('Simkl', 'history %s failed for movie tmdb=%s: %s' % (action, tmdb_id, result))
		return False
	# TV / episode / season — Simkl stores many titles under anime[], not shows[].
	if media_type in ('episode',):
		item_type, s_num, e_num = 'episode', season, episode
	elif media_type == 'season':
		item_type, s_num, e_num = 'season', season, None
	else:
		item_type, s_num, e_num = 'tvshow', None, None
	known_anime = _simkl_tmdb_is_anime(tmdb_id)
	# history/remove: top-level anime[] is silently ignored — must use shows[].
	# history add: anime[] is valid; prefer it for known anime then fall back to shows[].
	if action == 'mark_as_unwatched':
		attempts = (('shows', True), ('shows', False)) if known_anime else (('shows', False), ('shows', True))
	elif known_anime:
		attempts = (('anime', True), ('shows', True))
	else:
		attempts = (('shows', False), ('anime', True), ('shows', True))
	last_result = None
	saw_not_found = False
	shelf_only = False
	for bucket, use_tvdb in attempts:
		entry = _simkl_history_tv_entry(tmdb_id, tvdb_id, s_num, e_num, watched_at, use_tvdb)
		# Documented whole-show expand: no seasons/episodes + status=completed.
		if action == 'mark_as_watched' and item_type == 'tvshow':
			entry['status'] = 'completed'
		last_result = call_simkl(url, data={bucket: [entry]})
		# Network/HTTP failure (None) — do not stack more long timeouts on other buckets.
		if last_result is None:
			kodi_utils.logger('Simkl', 'history %s network failure for %s tmdb=%s tvdb=%s' % (action, item_type, tmdb_id, tvdb_id))
			return False
		if _simkl_history_counts_ok(last_result, action, 'shows'):
			if action != 'mark_as_watched' or item_type != 'tvshow' or _simkl_added_episodes(last_result) > 0:
				return True
			# added.shows>0 with 0 episodes: shelf-only. Expand via season numbers (#238).
			shelf_only = True
			kodi_utils.logger('Simkl', 'history mark_as_watched show added.episodes=0 tmdb=%s, expanding seasons' % tmdb_id)
			posted, expanded = _simkl_history_expand_seasons(url, tmdb_id, tvdb_id, bucket, use_tvdb)
			if not posted:
				continue
			if expanded is None:
				kodi_utils.logger('Simkl', 'history season-expand network failure for tvshow tmdb=%s tvdb=%s' % (tmdb_id, tvdb_id))
				return False
			last_result = expanded
			if _simkl_added_episodes(expanded) > 0:
				return True
			continue
		if action == 'mark_as_unwatched' and _simkl_history_not_found(last_result):
			saw_not_found = True
	if action == 'mark_as_unwatched' and item_type == 'tvshow' and tvdb_id and int(tvdb_id) > 0:
		fallback = call_simkl(url, data={'shows': [{'ids': {'tvdb': int(tvdb_id)}}]})
		if fallback is None:
			kodi_utils.logger('Simkl', 'history %s network failure for %s tmdb=%s tvdb=%s' % (action, item_type, tmdb_id, tvdb_id))
			return False
		if _simkl_history_counts_ok(fallback, action, 'shows'):
			return True
		if _simkl_history_not_found(fallback): saw_not_found = True
		last_result = fallback
	# Unwatched already clear on Simkl (explicit not_found). Do not treat bare deleted:0 as success —
	# that was hiding silent no-ops when remove used the wrong envelope.
	if action == 'mark_as_unwatched' and saw_not_found:
		kodi_utils.logger('Simkl', 'history mark_as_unwatched already clear for %s tmdb=%s tvdb=%s' % (item_type, tmdb_id, tvdb_id))
		return True
	# Add with 0 added across buckets = already watched — not a failure unless not_found.
	# Show-level added.shows with 0 episodes is not already-watched: shelf moved, ticks did not.
	if action == 'mark_as_watched' and item_type == 'tvshow' and shelf_only:
		kodi_utils.logger('Simkl', 'history mark_as_watched show no episode expansion tmdb=%s tvdb=%s: %s' % (tmdb_id, tvdb_id, last_result))
		return False
	if action == 'mark_as_watched' and isinstance(last_result, dict) and not _simkl_history_not_found(last_result):
		return True
	kodi_utils.logger('Simkl', 'history %s failed for %s tmdb=%s tvdb=%s: %s' % (action, item_type, tmdb_id, tvdb_id, last_result))
	return False

def _scrobble_payload(media_type, tmdb_id, percent, season=None, episode=None):
	data = {'progress': float(percent)}
	if media_type == 'movie':
		data['movie'] = {'ids': {'tmdb': int(tmdb_id)}}
	else:
		data['show'] = {'ids': {'tmdb': int(tmdb_id)}}
		data['episode'] = {'season': int(season), 'number': int(episode)}
	return data

def simkl_official_status(media_type):
	if kodi_utils.service_scrobbler_defer('script.simkl',
		auth_keys=('access_token', 'token', 'authorization', 'Authorization', 'simkl_token'),
		scrobble_enable_keys=('auto_scrobble', 'autoscrobble', 'scrobble_enabled', 'auto_scrobble_enabled')): return False
	return True

def simkl_scrobble(action, media_type, tmdb_id, percent=0, season=None, episode=None):
	if not settings.simkl_user_active(): return
	path = {'start': '/scrobble/start', 'pause': '/scrobble/pause', 'stop': '/scrobble/stop'}.get(action)
	if not path: return
	call_simkl(path, data=_scrobble_payload(media_type, tmdb_id, percent, season, episode))

def simkl_progress(action, media_type, tmdb_id, percent, season=None, episode=None, resume_id=None, refresh_simkl=False):
	if action == 'clear_progress' and resume_id:
		_throttle()
		url = _url('/sync/playback/%s' % resume_id)
		if not url: return
		try: requests.delete(url, headers=_headers(), timeout=META_API_TIMEOUT)
		except: pass
	else:
		simkl_scrobble('pause', media_type, tmdb_id, percent, season, episode)
	if refresh_simkl: simkl_sync_activities(force_update=True)

def simkl_reset_scrobble(params):
	from modules.watched_status import erase_bookmark
	media_type, tmdb_id = params.get('media_type'), params.get('tmdb_id')
	season, episode = params.get('season', ''), params.get('episode', '')
	watched_db = __import__('modules.watched_status', fromlist=['get_database']).get_database(2)
	try:
		if media_type == 'movie':
			simkl_scrobble('stop', 'movie', tmdb_id, 0)
			resume_id = watched_db.execute('SELECT resume_id FROM progress WHERE db_type=? AND media_id=?', ('movie', str(tmdb_id))).fetchone()[0]
			simkl_progress('clear_progress', 'movie', tmdb_id, 0, resume_id=resume_id)
			erase_bookmark('movie', tmdb_id, '', '', 'true', 2)
		elif media_type == 'episode' and season and episode:
			simkl_scrobble('stop', 'episode', tmdb_id, 0, season, episode)
			row = watched_db.execute('SELECT resume_id FROM progress WHERE db_type=? AND media_id=? AND season=? AND episode=?',
				('episode', str(tmdb_id), int(season), int(episode))).fetchone()
			if row:
				simkl_progress('clear_progress', 'episode', tmdb_id, 0, season, episode, resume_id=row[0])
			erase_bookmark('episode', tmdb_id, season, episode, 'true', 2)
		else: return kodi_utils.notification('Reset Scrobble is only available for movies and episodes', 3500)
		kodi_utils.notification('Success', 3000)
	except: kodi_utils.notification('Error', 3000)

def simkl_add_to_list(listname, tmdb_id, media_type, imdb_id=None, tvdb_id=None, simkl_id=None, media_kind=None):
	bucket = _simkl_list_bucket(media_type, media_kind)
	ids = _simkl_list_ids(tmdb_id, imdb_id, tvdb_id, simkl_id)
	post = {bucket: [{'to': listname, 'ids': ids}]}
	result = call_simkl('/sync/add-to-list', data=post)
	success = _simkl_list_add_ok(result, media_type, media_kind)
	if success:
		_simkl_refresh_after_list_change(listname, media_type, media_kind)
		kodi_utils.notify_success()
	else: kodi_utils.notify_error()
	return success

def simkl_remove_from_list(listname, tmdb_id, media_type, imdb_id=None, tvdb_id=None, simkl_id=None, media_kind=None):
	bucket = _simkl_list_bucket(media_type, media_kind)
	ids = _simkl_list_ids(tmdb_id, imdb_id, tvdb_id, simkl_id)
	post = {bucket: [{'ids': ids}]}
	result = call_simkl('/sync/history/remove', data=post)
	success = _simkl_list_remove_ok(result, media_type, media_kind)
	# Season-split anime often only matches under anime[]; some removes only clear via shows[].
	if not success and bucket == 'anime':
		result = call_simkl('/sync/history/remove', data={'shows': [{'ids': ids}]})
		success = _simkl_list_remove_ok(result, media_type, media_kind)
	if success:
		_simkl_refresh_after_list_change(listname, media_type, media_kind)
		kodi_utils.notify_success()
	else: kodi_utils.notify_not_in_list()
	return success

_SIMKL_SHOW_WATCHED_ACTIVITY_KEYS = ('watching', 'plantowatch', 'completed', 'hold', 'dropped', 'removed_from_list', 'all')
_SIMKL_MOVIE_WATCHED_ACTIVITY_KEYS = ('plantowatch', 'completed', 'dropped', 'removed_from_list', 'all')
# Full library pull when deletions cannot be inferred from a date_from delta.
_SIMKL_MOVIE_FULL_SYNC_KEYS = ('completed', 'removed_from_list')
_SIMKL_SHOW_FULL_SYNC_KEYS = ('removed_from_list',)
_SIMKL_TV_SYNC_QUERY = 'extended=full&episode_watched_at=yes&include_all_episodes=yes'
# full_anime_seasons adds tvdb {season,episode} so Kodi/TMDb SxE matches AniDB-backed library rows.
_SIMKL_ANIME_SYNC_QUERY = 'extended=full_anime_seasons&episode_watched_at=yes&include_all_episodes=yes'
# Phase 2 multi-type: one /sync/all-items?date_from=… (shows + anime + movies).
_SIMKL_PHASE2_ALL_QUERY = 'extended=full_anime_seasons&episode_watched_at=yes&include_all_episodes=yes'

def _simkl_date_from(cached_activities):
	"""Previous activities.all for Phase 2 date_from — None means full (Phase 1) pull."""
	ts = str((cached_activities or {}).get('all') or '').strip()
	if not ts: return None
	# Sentinel from default_activities() / never-synced installs.
	if ts.startswith('2020-01-01'): return None
	return ts

def _simkl_with_date_from(query, date_from=None):
	if not date_from: return query
	return '%s&date_from=%s' % (query, quote(date_from, safe=''))

def _simkl_apply_movie_watched(data, date_from=None, filter_status=False):
	"""Apply movies[] from an all-items payload into the local watched cache."""
	insert_list = []
	insert_append = insert_list.append
	for item in (data or {}).get('movies', data if isinstance(data, list) else []):
		try:
			movie = item.get('movie', item)
			tmdb_id = _tmdb_id(movie.get('ids', {}))
			if not tmdb_id: continue
			status = str(item.get('status') or '').lower()
			watched_at = item.get('last_watched_at') or item.get('watched_at')
			# Unified Phase 2 returns all statuses — only store completed/watched movies.
			if filter_status and not watched_at and status != 'completed': continue
			if not watched_at: watched_at = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
			insert_append(('movie', tmdb_id, '', '', watched_at, movie.get('title', '')))
		except: pass
	if date_from:
		simkl_cache.simkl_watched_cache.merge_bulk_movie_watched(insert_list)
	else:
		simkl_cache.simkl_watched_cache.set_bulk_movie_watched(insert_list)

def simkl_indicators_movies(date_from=None):
	path = '/sync/all-items/movies/completed?%s' % _simkl_with_date_from('extended=full', date_from)
	data = call_simkl(path, method='get') or {}
	_simkl_apply_movie_watched(data, date_from, filter_status=False)

def _simkl_append_tv_watched(insert_append, data, item_key, touched_ids=None):
	"""Flatten shows[] or anime[] all-items into local episode watched rows."""
	items = data.get(item_key, data if isinstance(data, list) else [])
	for item in items:
		try:
			if item_key == 'anime':
				show = item.get('anime') or item.get('show') or item
			else:
				show = item.get('show') or item
			tmdb_id = _tmdb_id(show.get('ids', {}))
			if not tmdb_id: continue
			if touched_ids is not None: touched_ids.add(str(tmdb_id))
			title = show.get('title', '')
			for season in item.get('seasons', []):
				try: snum = int(season.get('number', season.get('season')))
				except: continue
				for ep in season.get('episodes', []):
					watched_at = ep.get('watched_at') or ep.get('last_watched_at')
					if not watched_at: continue
					# Prefer TVDB-mapped S/E for anime so NIGHTSHIFT matches TMDb season lists.
					tvdb_map = ep.get('tvdb') if isinstance(ep.get('tvdb'), dict) else None
					try:
						if tvdb_map and tvdb_map.get('season') is not None and tvdb_map.get('episode') is not None:
							ep_snum = int(tvdb_map['season'])
							epnum = int(tvdb_map['episode'])
						else:
							ep_snum = snum
							epnum = int(ep.get('number', ep.get('episode')))
					except Exception:
						continue
					insert_append(('episode', tmdb_id, ep_snum, epnum, watched_at, title))
		except: pass

def _simkl_apply_tv_watched(data, date_from=None):
	"""Apply shows[] + anime[] from an all-items payload into the local watched cache."""
	insert_list = []
	insert_append = insert_list.append
	touched_ids = set() if date_from else None
	_simkl_append_tv_watched(insert_append, data or {}, 'shows', touched_ids)
	_simkl_append_tv_watched(insert_append, data or {}, 'anime', touched_ids)
	if date_from:
		simkl_cache.simkl_watched_cache.merge_bulk_tvshow_watched(insert_list, touched_ids)
	else:
		simkl_cache.simkl_watched_cache.set_bulk_tvshow_watched(insert_list)

def simkl_indicators_tv(date_from=None):
	if date_from:
		# Phase 2: one multi-type request (shows + anime; movies ignored here).
		data = call_simkl('/sync/all-items?%s' % _simkl_with_date_from(_SIMKL_PHASE2_ALL_QUERY, date_from), method='get') or {}
		_simkl_apply_tv_watched(data, date_from)
		return
	# Phase 1: sequential per-type full pulls (Simkl guidance for large libraries).
	insert_list = []
	insert_append = insert_list.append
	shows = call_simkl('/sync/all-items/shows?%s' % _SIMKL_TV_SYNC_QUERY, method='get') or {}
	_simkl_append_tv_watched(insert_append, shows, 'shows')
	anime = call_simkl('/sync/all-items/anime?%s' % _SIMKL_ANIME_SYNC_QUERY, method='get') or {}
	_simkl_append_tv_watched(insert_append, anime, 'anime')
	simkl_cache.simkl_watched_cache.set_bulk_tvshow_watched(insert_list)

def simkl_indicators_phase2(date_from):
	"""Phase 2 continuous sync: one /sync/all-items?date_from= for movies + shows + anime."""
	if not date_from: return
	data = call_simkl('/sync/all-items?%s' % _simkl_with_date_from(_SIMKL_PHASE2_ALL_QUERY, date_from), method='get') or {}
	_simkl_apply_movie_watched(data, date_from, filter_status=True)
	_simkl_apply_tv_watched(data, date_from)

def simkl_sync_playback():
	items = call_simkl('/sync/playback', method='get') or []
	movie_ins, ep_ins = [], []
	for item in items:
		try:
			progress = float(item.get('progress') or 0)
			if progress <= 1: continue
			if item.get('type') == 'movie':
				tmdb_id = _tmdb_id(item.get('movie', {}).get('ids', {}))
				if not tmdb_id: continue
				movie_ins.append(('movie', tmdb_id, '', '', str(round(progress, 1)), 0, item.get('paused_at', ''), item['id'], item['movie'].get('title', '')))
			elif item.get('type') == 'episode':
				show = item.get('show', {})
				tmdb_id = _tmdb_id(show.get('ids', {}))
				if not tmdb_id: continue
				ep = item.get('episode', {})
				ep_ins.append(('episode', tmdb_id, ep.get('season'), ep.get('number'), str(round(progress, 1)), 0,
					item.get('paused_at', ''), item['id'], show.get('title', '')))
		except: pass
	simkl_cache.simkl_watched_cache.set_bulk_movie_progress(movie_ins)
	simkl_cache.simkl_watched_cache.set_bulk_tvshow_progress(ep_ins)

def _activity_ts(ts_str):
	if not ts_str: return 0
	try: return int(calendar.timegm(time.strptime(ts_str.rstrip('Z').split('.')[0], '%Y-%m-%dT%H:%M:%S')))
	except: return 0

def _activity_block_changed(latest_blk, cached_blk, keys):
	for key in keys:
		if _activity_ts(latest_blk.get(key, '')) > _activity_ts(cached_blk.get(key, '')): return True
	return False

def simkl_sync_activities(params=None, force_update=False):
	if isinstance(params, dict): force_update = params.get('force_update', 'false') in ('true', 'True', True) or force_update
	if not settings.simkl_user_active(): return 'no account'
	# Coalesce overlapping syncs (monitor + list refresh + mark-watched) across invokers.
	if not force_update:
		try:
			if kodi_utils.get_property(_SIMKL_SYNC_BUSY_PROP) == 'true':
				started = float(kodi_utils.get_property(_SIMKL_SYNC_BUSY_AT_PROP) or 0)
				if started and (time.time() - started) < 180:
					return 'not needed'
		except Exception:
			pass
		if not _sync_lock.acquire(False):
			return 'not needed'
	else:
		_sync_lock.acquire(True)
	try:
		try:
			kodi_utils.set_property(_SIMKL_SYNC_BUSY_PROP, 'true')
			kodi_utils.set_property(_SIMKL_SYNC_BUSY_AT_PROP, '%.3f' % time.time())
		except Exception:
			pass
		return _simkl_sync_activities_body(force_update=force_update)
	finally:
		try:
			kodi_utils.set_property(_SIMKL_SYNC_BUSY_PROP, 'false')
			kodi_utils.clear_property(_SIMKL_SYNC_BUSY_AT_PROP)
		except Exception:
			pass
		_sync_lock.release()

def _simkl_sync_activities_body(force_update=False):
	if force_update:
		simkl_cache.clear_all_simkl_cache_data(silent=True, refresh=False)
		clear_simkl_list_status_cache()
	try: latest = call_simkl('/sync/activities', method='get')
	except: return 'failed'
	if not latest: return 'failed'
	cached = simkl_cache.reset_activity(latest)
	if not force_update and _activity_ts(latest.get('all', '')) <= _activity_ts(cached.get('all', '')): return 'not needed'
	# Phase 2: date_from = previously saved activities.all (before this poll overwrote it).
	date_from = None if force_update else _simkl_date_from(cached)
	movies, shows = latest.get('movies', {}), latest.get('tv_shows', {})
	anime = latest.get('anime', {})
	cached_movies, cached_shows = cached.get('movies', {}), cached.get('tv_shows', {})
	cached_anime = cached.get('anime', {})
	watched_keys_movies = _SIMKL_MOVIE_WATCHED_ACTIVITY_KEYS
	watched_keys_shows = _SIMKL_SHOW_WATCHED_ACTIVITY_KEYS
	playback_keys = ('playback', 'all')
	if force_update or _activity_block_changed(movies, cached_movies, _SIMKL_LIST_ACTIVITY_KEYS):
		clear_simkl_list_status_cache('movies')
	if force_update or _activity_block_changed(shows, cached_shows, _SIMKL_LIST_ACTIVITY_KEYS):
		clear_simkl_list_status_cache('shows')
		clear_simkl_calendar_cache()
	if force_update or _activity_block_changed(anime, cached_anime, _SIMKL_LIST_ACTIVITY_KEYS):
		clear_simkl_list_status_cache('anime')
		clear_simkl_calendar_cache()
	need_movies = force_update or _activity_block_changed(movies, cached_movies, watched_keys_movies)
	need_tv = force_update or _activity_block_changed(shows, cached_shows, watched_keys_shows) \
		or _activity_block_changed(anime, cached_anime, watched_keys_shows)
	# date_from deltas omit removals — full pull when completed/removed move.
	movie_from = None if (not date_from or _activity_block_changed(movies, cached_movies, _SIMKL_MOVIE_FULL_SYNC_KEYS)) else date_from
	tv_from = None if (not date_from
		or _activity_block_changed(shows, cached_shows, _SIMKL_SHOW_FULL_SYNC_KEYS)
		or _activity_block_changed(anime, cached_anime, _SIMKL_SHOW_FULL_SYNC_KEYS)) else date_from
	if need_movies and need_tv and movie_from and tv_from and movie_from == tv_from:
		# Simkl Phase 2 multi-type: one request for movies + shows + anime.
		simkl_indicators_phase2(movie_from)
		clear_simkl_dropped_cache()
	else:
		if need_movies: simkl_indicators_movies(date_from=movie_from)
		if need_tv:
			simkl_indicators_tv(date_from=tv_from)
			clear_simkl_dropped_cache()
	if force_update or _activity_block_changed(movies, cached_movies, playback_keys) or _activity_block_changed(shows, cached_shows, playback_keys):
		simkl_sync_playback()
	return 'success'

def simkl_force_sync(params=None):
	if not settings.simkl_user_active(): return kodi_utils.notification('Simkl account not authorised', 3000)
	progress = kodi_utils.progress_dialog('Simkl Sync')
	status = 'failed'
	try:
		progress.update('Syncing with Simkl...', 0)
		status = simkl_sync_activities(force_update=True)
	except Exception as e:
		kodi_utils.logger('Simkl', 'Force sync failed: %s' % e)
	finally:
		kodi_utils.close_progress_dialog(progress)
	if status == 'failed': kodi_utils.notification('Simkl Sync Failed', 3000)
	else:
		kodi_utils.notification('Simkl Sync Complete', 3000)
		kodi_utils.kodi_refresh()
	return status

SIMKL_TRENDING_BASE = 'https://data.simkl.in/discover/trending'
SIMKL_CALENDAR_CDN_BASE = 'https://data.simkl.in/calendar/v2'
SIMKL_CALENDAR_CACHE_KEY = 'simkl_calendar_v7_joined'
SIMKL_PUBLIC_CALENDAR_CACHE_KEYS = {
	'tv': 'simkl_calendar_v7_public_tv',
	'anime': 'simkl_calendar_v7_public_anime',
	'all': 'simkl_calendar_v7_public_all',
}
_SIMKL_TRENDING_TRAKT_KEYS = {'movies': 'movie', 'tv': 'show', 'anime': 'show'}

def _simkl_trending_url(media_kind):
	return '%s/%s/today_100.json' % (SIMKL_TRENDING_BASE, media_kind)

def _simkl_cdn_query_url(url):
	sep = '&' if '?' in url else '?'
	return '%s%sclient_id=%s&app-name=%s&app-version=%s' % (url, sep, _client_id(), SIMKL_APP_NAME, kodi_utils.addon_version())

def _simkl_trending_query_url(url):
	return _simkl_cdn_query_url(url)

def clear_simkl_calendar_cache():
	try: simkl_cache.simkl_cache.delete(SIMKL_CALENDAR_CACHE_KEY)
	except: pass
	for key in SIMKL_PUBLIC_CALENDAR_CACHE_KEYS.values():
		try: simkl_cache.simkl_cache.delete(key)
		except: pass

def _simkl_calendar_library_by_simkl():
	"""Watching + Plan to Watch (shows + anime), keyed by Simkl id."""
	shows_by_simkl = {}
	for status in ('watching', 'plantowatch'):
		for media_kind in ('shows', 'anime'):
			for row in _simkl_fetch_status(media_kind, status) or []:
				try:
					sid = str((row.get('media_ids') or {}).get('simkl') or '')
					if sid: shows_by_simkl[sid] = row
				except Exception:
					continue
	return shows_by_simkl

def _simkl_fetch_calendar_payload(feed):
	"""Return (calendar_rows, metadata_by_simkl_id) from a public CDN v2 feed."""
	url = _simkl_cdn_query_url('%s/%s.json' % (SIMKL_CALENDAR_CDN_BASE, feed))
	_throttle()
	try:
		resp = requests.get(url, headers=_pin_headers(), timeout=META_API_TIMEOUT)
		if resp.status_code != 200:
			kodi_utils.logger('Simkl', 'Calendar CDN HTTP %s for %s' % (resp.status_code, feed))
			return [], {}
		payload = resp.json()
	except Exception as e:
		kodi_utils.logger('Simkl', 'Calendar CDN error %s: %s' % (feed, e))
		return [], {}
	if isinstance(payload, dict):
		calendar_rows = payload.get('calendar', [])
		metadata = payload.get('metadata') or {}
	else:
		calendar_rows = payload or []
		metadata = {}
	if not isinstance(calendar_rows, list): calendar_rows = []
	if not isinstance(metadata, dict): metadata = {}
	return calendar_rows, metadata

def _simkl_fetch_calendar_feed(feed):
	calendar_rows, _metadata = _simkl_fetch_calendar_payload(feed)
	return calendar_rows

def _simkl_cal_day(value):
	"""'2026-10-12T15:00:00Z' / '2026-10-12' -> datetime.date or None."""
	try:
		s = str(value or '')[:10]
		return datetime.strptime(s, '%Y-%m-%d').date() if s else None
	except Exception: return None

def _simkl_cal_candidate_seasons(rows, day):
	"""Regular seasons that can hold an airing on `day`: the last season dated on/before it, plus the next one."""
	if not rows: return []
	idx = 0
	for i, (n, air_date, count) in enumerate(rows):
		d = _simkl_cal_day(air_date)
		if d and day and (d - day).days <= 2: idx = i
	return [rows[i][0] for i in (idx, idx + 1) if i < len(rows)]

def _simkl_cal_step(rows, get_eps, season, episode, steps):
	"""Walk `steps` episodes forward from (season, episode), rolling into the next TMDb season when this one runs out.
	Works for per-season numbering (S2E4) and continuous numbering inside one season (S1E16)."""
	numbers = [r[0] for r in rows]
	counts = dict((r[0], r[2]) for r in rows)
	def _span(s):
		nums = [e[0] for e in get_eps(s) or [] if e[0]]
		if nums: return min(nums), max(nums)
		return 1, max(counts.get(s) or 0, 1)
	while steps > 0:
		first, last = _span(season)
		room = last - episode
		if steps <= room: return season, episode + steps
		nxt = [n for n in numbers if n > season]
		if not nxt:
			# TMDb has not added these episodes yet — keep counting in the final season.
			return season, episode + steps
		steps -= room + 1
		season = nxt[0]
		episode = _span(season)[0]
	return season, episode

def _simkl_cal_resolve_from_tmdb(rows, get_eps, aired_day, ep_no, release_day=None):
	"""Map a Simkl airing onto TMDb's own season/episode numbering.

	Simkl anime are season-split: ep_no counts from the first episode of that Simkl entry.
	1) Anchor: the TMDb episode aired on the entry's release date is Simkl ep 1; walk ep_no-1
	   forward. Gives S02E04 when TMDb has a second season, S01E16 when TMDb keeps one
	   continuous season (12 episodes before + 4).
	2) Otherwise match the airing's own date against TMDb episode air dates.
	Returns (season, episode) or None."""
	if not rows or not aired_day: return None
	if release_day:
		best = None
		for s in _simkl_cal_candidate_seasons(rows, release_day):
			for e_no, e_date in get_eps(s) or []:
				if not e_no or not e_date: continue
				diff = abs((e_date - release_day).days)
				if diff <= 2 and (best is None or (diff, s, e_no) < best[0]): best = ((diff, s, e_no), s, e_no)
		if best:
			season, episode = _simkl_cal_step(rows, get_eps, best[1], best[2], max(ep_no - 1, 0))
			target_date = next((d for e, d in get_eps(season) or [] if e == episode and d), None)
			# Sanity check against TMDb's own date for that episode when it has one.
			if target_date is None or abs((target_date - aired_day).days) <= 3: return season, episode
	found = []
	for s in _simkl_cal_candidate_seasons(rows, aired_day):
		eps = get_eps(s) or []
		for e_no, e_date in eps:
			if not e_no or not e_date: continue
			diff = abs((e_date - aired_day).days)
			if diff > 1: continue
			agrees = e_no == ep_no
			found.append((0 if agrees else 1, diff, s, e_no))
	if found:
		found.sort()
		return found[0][2], found[0][3]
	# TMDb has a placeholder season with no episode dates yet: if this Simkl entry started after every dated
	# TMDb episode, it is that season (S02E04, not S01E04).
	if release_day:
		dated_eps = [(s, d) for s, _a, _c in rows for e_no, d in (get_eps(s) or []) if d]
		last_dated = max([d for s, d in dated_eps] or [None]) if dated_eps else None
		if last_dated and release_day > last_dated:
			dated_seasons = set(s for s, d in dated_eps)
			later = [n for n, _a, _c in rows if n > max(dated_seasons) and not any(d for e, d in (get_eps(n) or []))]
			if later:
				first = min([e for e, d in (get_eps(later[0]) or []) if e] or [1])
				return later[0], first + max(ep_no - 1, 0)
			# No placeholder season either: TMDb simply keeps counting in its final season (S01E170 -> S01E173).
			if max(dated_seasons) == rows[-1][0]:
				last_ep = max([e for e, d in (get_eps(rows[-1][0]) or []) if e] or [0])
				if last_ep: return rows[-1][0], last_ep + max(ep_no, 1)
	return None

def _simkl_calendar_show_meta(tmdb, ids, memo):
	"""(tmdb_id, tmdb tvshow meta) for a calendar show, correcting Simkl's wrong TMDb ids.

	Simkl often gives a season-split anime entry a TMDb id that is a movie or an unrelated show
	(Black Clover Second Season -> TMDb 336735, a 2004 movie). The id is only trusted when TMDb's TV show
	carries the same TVDb/IMDb id Simkl reports; otherwise the show is looked up by IMDb / TVDb, which finds the
	parent series (73223) whose seasons are what the calendar S/E has to be expressed in."""
	key = ('show', tmdb)
	if key in memo: return memo[key]
	result = (tmdb, None)
	try:
		from modules import metadata
		from modules.utils import get_datetime
		api_key, region, now = settings.tmdb_api_key(), settings.mpaa_region(), get_datetime()
		ids = ids or {}
		want = [str(ids.get(k)) for k in ('tvdb', 'imdb') if ids.get(k) not in _SIMKL_ID_EMPTY]
		def _usable(m): return bool(m) and not m.get('blank_entry') and bool(m.get('season_data'))
		def _matches(m):
			if not want: return True
			have = [str(m.get('tvdb_id') or ''), str(m.get('imdb_id') or '')]
			return any(w in have for w in want)
		meta = metadata.tvshow_meta('tmdb_id', tmdb, api_key, region, now)
		if _usable(meta) and _matches(meta): result = (tmdb, meta)
		else:
			for id_type, value in (('imdb_id', ids.get('imdb')), ('tvdb_id', ids.get('tvdb'))):
				if value in _SIMKL_ID_EMPTY: continue
				alt = metadata.tvshow_meta(id_type, str(value), api_key, region, now)
				if _usable(alt):
					try: result = (int(alt.get('tmdb_id')), alt)
					except Exception: continue
					break
			else:
				if _usable(meta): result = (tmdb, meta)
	except Exception: pass
	memo[key] = result
	return result

def _simkl_calendar_tmdb_context(tmdb, memo, ids=None):
	"""(rows, get_eps) for a TMDb show; season rows and per-season episode lists are memoised."""
	key = ('ctx', tmdb)
	if key in memo: return memo[key]
	ctx = (None, None)
	try:
		from modules import metadata
		tmdb_eff, meta = _simkl_calendar_show_meta(tmdb, ids, memo)
		rows = []
		for item in (meta or {}).get('season_data') or []:
			try: n = int(item.get('season_number'))
			except Exception: continue
			if n <= 0: continue
			rows.append((n, str(item.get('air_date') or '')[:10], int(item.get('episode_count') or 0)))
		rows.sort()
		def get_eps(season):
			ek = ('eps', tmdb_eff, season)
			if ek not in memo:
				try:
					memo[ek] = [(int(i.get('episode') or 0), _simkl_cal_day(i.get('premiered'))) for i in metadata.episodes_meta(season, meta) or []]
				except Exception: memo[ek] = []
			return memo[ek]
		if rows: ctx = (rows, get_eps)
	except Exception: pass
	memo[key] = ctx
	return ctx

def _simkl_calendar_resolve_season(ep, tmdb, aired, ep_no, season_no, memo, is_anime=False, release_date=None):
	result = _simkl_calendar_resolve_season_inner(ep, tmdb, aired, ep_no, season_no, memo, is_anime, release_date)
	try:
		if is_anime:
			n = memo.get('_log_count', 0)
			if n < 25 and (result != (season_no, ep_no) or n < 3):
				memo['_log_count'] = n + 1
				kodi_utils.logger('Simkl Calendar', 'anime tmdb=%s date=%s release=%s simkl s%s ep=%s -> S%sE%s' % (
					tmdb, str(aired)[:10], str(release_date or '')[:10], season_no, ep_no, result[0], result[1]))
	except Exception: pass
	return result

def _simkl_calendar_resolve_season_inner(ep, tmdb, aired, ep_no, season_no, memo, is_anime=False, release_date=None):
	"""Return (season, episode) for a calendar airing, in TMDb's numbering.

	Simkl anime airings are season-split (ep counts from that Simkl entry and the season is
	missing or unreliable), which used to become S01E<n> — S2E4 showed as 1x04, and a show
	TMDb keeps as one continuous season (12 eps, then cour 2 ep 4) should be S01E16.
	Order: TMDb release-date anchor / air-date match, Simkl's own season, Simkl's tvdb mapping,
	TMDb season air dates. Falls back to S01 like before.
	"""
	# Non-anime with a real season: trust it.
	if season_no >= 1 and not is_anime: return season_no, ep_no
	try:
		rows, get_eps = _simkl_calendar_tmdb_context(tmdb, memo)
		if rows:
			hit = _simkl_cal_resolve_from_tmdb(rows, get_eps, _simkl_cal_day(aired), ep_no, _simkl_cal_day(release_date))
			if hit: return hit
	except Exception: pass
	if season_no > 1: return season_no, ep_no
	tv = ep.get('tvdb') if isinstance(ep.get('tvdb'), dict) else None
	try:
		if tv and tv.get('season') is not None and tv.get('episode') is not None:
			s, e = int(tv['season']), int(tv['episode'])
			if s > 0 and e > 0: return s, e
	except Exception: pass
	try:
		rows, _get_eps = _simkl_calendar_tmdb_context(tmdb, memo)
		if not rows: return 1, ep_no
		aired_day = str(aired or '')[:10]
		chosen, prior, prior_chosen = None, 0, 0
		for n, air_date, count in rows:
			if air_date and aired_day and air_date <= aired_day: chosen, prior_chosen = (n, count), prior
			prior += count
		if chosen is None:
			# TMDb has not dated a brand-new season yet — a premiere (ep 1) belongs to the first undated season.
			dated = [n for n, d, c in rows if d]
			undated = [n for n, d, c in rows if not d and (not dated or n > max(dated))]
			if ep_no == 1 and undated: return min(undated), 1
			return 1, ep_no
		season, count = chosen
		# Absolute-style numbering (ep beyond this season's count): subtract earlier seasons.
		if count and ep_no > count and prior_chosen and ep_no > prior_chosen:
			ep_no -= prior_chosen
		return season, ep_no
	except Exception:
		return 1, ep_no

def _simkl_calendar_row(entry, library_row, memo=None, is_anime=False, release_date=None):
	"""Normalize a CDN airing + library show into the shared calendar row shape."""
	ep = entry.get('episode', {}) or {}
	try:
		ep_no = int(ep.get('episode'))
	except Exception:
		return None
	try:
		season_no = int(ep.get('season') or 0)
	except Exception:
		season_no = 0
	mids = dict(library_row.get('media_ids') or {})
	try:
		tmdb = int(mids.get('tmdb'))
	except Exception:
		return None
	title = library_row.get('title') or ''
	# Keep full ISO (…Z) so Calendars UTC (+/-) can shift Today/Tomorrow labels.
	aired = str(entry.get('date') or '').strip()
	if not aired: return None
	# Anime v2 rows often omit season — resolve the real season (was hard-coded S01).
	memo = memo if memo is not None else {}
	if is_anime or season_no < 1: tmdb = _simkl_calendar_show_meta(tmdb, mids, memo)[0]
	season_no, ep_no = _simkl_calendar_resolve_season(ep, tmdb, aired, ep_no, season_no, memo, is_anime, release_date)
	media_ids = {'tmdb': tmdb}
	for key in ('imdb', 'tvdb', 'simkl'):
		val = mids.get(key)
		if val not in _SIMKL_ID_EMPTY: media_ids[key] = val
	return {
		'sort_title': '%s s%s e%s' % (title, str(season_no).zfill(2), str(ep_no).zfill(2)),
		'media_ids': media_ids,
		'season': season_no,
		'episode': ep_no,
		'first_aired': aired
	}

def _simkl_calendar_row_public(entry, meta, memo=None, is_anime=False):
	"""Normalize a CDN airing + feed metadata (no personal library join)."""
	if not isinstance(meta, dict): return None
	ep = entry.get('episode', {}) or {}
	try:
		ep_no = int(ep.get('episode'))
	except Exception:
		return None
	try:
		season_no = int(ep.get('season') or 0)
	except Exception:
		season_no = 0
	ids = meta.get('ids') or {}
	try:
		tmdb = int(ids.get('tmdb'))
	except Exception:
		return None
	title = meta.get('title') or meta.get('en_title') or ''
	aired = str(entry.get('date') or '').strip()
	if not aired: return None
	memo = memo if memo is not None else {}
	if is_anime or season_no < 1: tmdb = _simkl_calendar_show_meta(tmdb, ids, memo)[0]
	season_no, ep_no = _simkl_calendar_resolve_season(ep, tmdb, aired, ep_no, season_no, memo, is_anime, meta.get('release_date'))
	media_ids = {'tmdb': tmdb}
	for key in ('imdb', 'tvdb'):
		val = ids.get(key)
		if val not in _SIMKL_ID_EMPTY: media_ids[key] = val
	sid = ids.get('simkl_id') or ids.get('simkl') or entry.get('simkl_id')
	if sid not in _SIMKL_ID_EMPTY: media_ids['simkl'] = sid
	return {
		'sort_title': '%s s%s e%s' % (title, str(season_no).zfill(2), str(ep_no).zfill(2)),
		'media_ids': media_ids,
		'season': season_no,
		'episode': ep_no,
		'first_aired': aired
	}

def _simkl_build_calendar_joined():
	shows_by_simkl = _simkl_calendar_library_by_simkl()
	if not shows_by_simkl: return []
	data, memo = [], {}
	for feed in ('tv', 'anime'):
		calendar_rows, metadata = _simkl_fetch_calendar_payload(feed)
		for entry in calendar_rows:
			if not isinstance(entry, dict): continue
			try:
				sid = str(entry.get('simkl_id') or '')
				row = shows_by_simkl.get(sid)
				if not row: continue
				release_date = (metadata.get(sid) or {}).get('release_date') if isinstance(metadata, dict) else None
				normalized = _simkl_calendar_row(entry, row, memo, feed == 'anime', release_date)
				if normalized: data.append(normalized)
			except Exception:
				continue
	return [i for n, i in enumerate(data) if i not in data[n + 1:]]

def _simkl_build_public_calendar(feeds):
	data, memo = [], {}
	for feed in feeds:
		calendar_rows, metadata = _simkl_fetch_calendar_payload(feed)
		for entry in calendar_rows:
			if not isinstance(entry, dict): continue
			try:
				sid = str(entry.get('simkl_id') or '')
				meta = metadata.get(sid) or {}
				normalized = _simkl_calendar_row_public(entry, meta, memo, feed == 'anime')
				if normalized: data.append(normalized)
			except Exception:
				continue
	return [i for n, i in enumerate(data) if i not in data[n + 1:]]

def _filter_simkl_calendar_day_window(data):
	from modules.utils import calendar_service_local_date
	start_date, end_date = settings.calendar_day_window()
	filtered = []
	for item in data:
		aired, _ = calendar_service_local_date(item.get('first_aired', ''))
		if aired is None: continue
		if start_date <= aired <= end_date:
			filtered.append(item)
	return filtered

def _simkl_anime_id(tmdb_id=None, tvdb_id=None, imdb_id=None):
	"""Simkl id of an anime (looked up by TVDb / IMDb / TMDb, cached), or None."""
	lookups = [(k, v) for k, v in (('tvdb', tvdb_id), ('imdb', imdb_id), ('tmdb', tmdb_id)) if v not in _SIMKL_ID_EMPTY + ('tt0000000', '0000000')]
	if not lookups: return None
	string = 'anime_sid_%s_%s' % lookups[0]
	cached = simkl_cache.simkl_cache.get(string)
	if isinstance(cached, dict) and time.time() - cached.get('at', 0) < 7 * 86400: return cached.get('sid')
	sid = None
	for key, value in lookups:
		path = '/search/id?%s=%s' % (key, quote(str(value)))
		if key == 'tmdb': path += '&type=tv'
		result = call_simkl(path, method='get')
		if result is None: return None
		for row in result if isinstance(result, list) else []:
			if isinstance(row, dict) and row.get('type') == 'anime' and (row.get('ids') or {}).get('simkl'):
				sid = row['ids']['simkl']
				break
		if sid: break
	simkl_cache.simkl_cache.set(string, {'at': time.time(), 'sid': sid})
	return sid

def _simkl_utc_stamp(value):
	"""Simkl episode dates carry the broadcast offset (+09:00): written as UTC, like the calendar feed, so the user's UTC setting applies the same way."""
	try:
		from datetime import timezone
		dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
		if dt.tzinfo is None: return str(value)
		return dt.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
	except Exception: return str(value)

def simkl_anime_season_air_dates(tmdb_id, tvdb_id, imdb_id, season):
	"""{episode number: air date} of one season of an anime, from the same Simkl episode dates the calendar uses.

	Simkl lists every episode with the TVDb season / episode it belongs to, so a season of the show maps straight onto its
	episodes. Empty when Simkl does not know the show (or its client id is missing)."""
	try:
		if not _client_id(): return {}
		sid = _simkl_anime_id(tmdb_id, tvdb_id, imdb_id)
		if not sid: return {}
		string = 'anime_eps_%s' % sid
		cached = simkl_cache.simkl_cache.get(string)
		if isinstance(cached, dict) and time.time() - cached.get('at', 0) < 12 * 3600: rows = cached.get('rows') or []
		else:
			data = call_simkl('/anime/episodes/%s?extended=full' % sid, method='get')
			if not isinstance(data, list): rows = (cached or {}).get('rows') or []
			else:
				rows = [[(i.get('tvdb') or {}).get('season'), (i.get('tvdb') or {}).get('episode'), i.get('date')] for i in data
						if isinstance(i, dict) and i.get('type') == 'episode' and i.get('date')]
				for row in rows: row[2] = _simkl_utc_stamp(row[2])
				simkl_cache.simkl_cache.set(string, {'at': time.time(), 'rows': rows})
		out = {}
		for s_no, e_no, date in rows:
			try:
				if int(s_no) == int(season) and int(e_no) > 0: out[int(e_no)] = date
			except Exception: continue
		return out
	except Exception: return {}

def simkl_get_my_calendar(dummy=None):
	"""Personal episode calendar: CDN calendar/v2 joined to Watching + Plan to Watch.

	Cached joined payload is unfiltered; Show Previous/Future Days is applied on read
	so shared Calendars settings match PunchPlay/MDBList without waiting for cache expiry.
	"""
	if not settings.simkl_user_active(): return []
	cached = simkl_cache.simkl_cache.get(SIMKL_CALENDAR_CACHE_KEY)
	if cached:
		data = cached
	else:
		data = _simkl_build_calendar_joined() or []
		if data: simkl_cache.simkl_cache.set(SIMKL_CALENDAR_CACHE_KEY, data)
		elif cached is not None:
			simkl_cache.simkl_cache.delete(SIMKL_CALENDAR_CACHE_KEY)
	filtered = _filter_simkl_calendar_day_window(data)
	try:
		start_date, end_date = settings.calendar_day_window()
		kodi_utils.logger('NIGHTSHIFT', 'Simkl calendar: %s cached/fetched, %s in day window (%s → %s)' % (
			len(data), len(filtered), start_date, end_date))
	except Exception:
		pass
	return filtered

def simkl_get_public_calendar(feeds='all'):
	"""Public episode calendar from Simkl CDN only (no api.simkl.com).

	Nightshift policy: only the non-anime TV feed is used. Anime calendar is AniList.
	CDN metadata in the feed is enough; no search/id or full meta from Simkl API.
	"""
	# Always TV-only regardless of caller (anime goes through AniList).
	feeds = 'tv'
	feed_list = ('tv',)
	cache_key = SIMKL_PUBLIC_CALENDAR_CACHE_KEYS[feeds]
	cached = simkl_cache.simkl_cache.get(cache_key)
	if cached:
		data = cached
	else:
		data = _simkl_build_public_calendar(feed_list) or []
		if data: simkl_cache.simkl_cache.set(cache_key, data)
		elif cached is not None:
			simkl_cache.simkl_cache.delete(cache_key)
	filtered = _filter_simkl_calendar_day_window(data)
	capped = filtered
	try:
		max_items = settings.public_calendar_max_items()
		if max_items and len(filtered) > max_items:
			from modules.utils import calendar_service_local_date, get_datetime
			today = get_datetime()
			def _distance(item):
				aired, _ = calendar_service_local_date(item.get('first_aired', ''))
				if aired is None: return 99999
				return abs((aired - today).days)
			# Spread the cap across every day in the window (round-robin, nearest day first). A plain
			# "closest to today" cut let today's episodes fill the whole cap and hid all other dates.
			by_day = {}
			for item in filtered:
				by_day.setdefault((item.get('first_aired') or '').split('T')[0], []).append(item)
			day_order = sorted(by_day, key=lambda d: _distance(by_day[d][0]))
			capped, idx = [], 0
			while len(capped) < max_items and any(idx < len(by_day[d]) for d in day_order):
				for d in day_order:
					if idx < len(by_day[d]) and len(capped) < max_items: capped.append(by_day[d][idx])
				idx += 1
	except Exception:
		capped = filtered
	try:
		start_date, end_date = settings.calendar_day_window()
		kodi_utils.logger('NIGHTSHIFT', 'Simkl public calendar (%s): %s cached/fetched, %s in day window → %s capped (%s → %s)' % (
			feeds, len(data), len(filtered), len(capped), start_date, end_date))
	except Exception:
		pass
	return capped

def _simkl_trending_ids(item):
	ids = item.get('ids') or {}
	result = {}
	for key in ('tmdb', 'imdb', 'tvdb', 'slug'):
		value = ids.get(key)
		if value in (None, ''): continue
		if key == 'tmdb':
			try: result[key] = int(value)
			except: result[key] = value
		else: result[key] = value
	return result

def _simkl_trending_to_trakt(item, media_kind):
	ids = _simkl_trending_ids(item)
	if not ids.get('tmdb'): return None
	return {_SIMKL_TRENDING_TRAKT_KEYS[media_kind]: {'ids': ids}}

def _simkl_fetch_trending_today(media_kind):
	from caches.lists_cache import lists_cache_object
	def _fetch(dummy):
		_throttle()
		try:
			resp = requests.get(_simkl_trending_query_url(_simkl_trending_url(media_kind)), headers=_pin_headers(), timeout=META_API_TIMEOUT)
			if resp.status_code != 200:
				kodi_utils.logger('Simkl Trending', 'HTTP %s for %s' % (resp.status_code, media_kind))
				return None
			data = resp.json()
			if isinstance(data, list): items = data
			else: items = data.get(media_kind) or data.get('items') or []
			results = []
			for item in items:
				converted = _simkl_trending_to_trakt(item, media_kind)
				if converted: results.append(converted)
			if not results:
				kodi_utils.logger('Simkl Trending', 'No usable items for %s' % media_kind)
				return None
			return results
		except Exception as e:
			kodi_utils.logger('Simkl Trending Error', str(e))
			return None
	result = lists_cache_object(_fetch, 'simkl_trending_%s_today_100' % media_kind, 'dummy_arg', expiration=1)
	return result or []

def clear_simkl_trending_cache(media_kind=None):
	try:
		from caches.lists_cache import lists_cache
		dbcon = lists_cache.manual_connect('lists_db')
		if media_kind: dbcon.execute('DELETE FROM lists WHERE id = ?', ('simkl_trending_%s_today_100' % media_kind,))
		else: dbcon.execute('DELETE FROM lists WHERE id LIKE ?', ('simkl_trending_%',))
		dbcon.execute('VACUUM')
	except: pass

def simkl_trending_today_count(media_kind):
	return len(_simkl_fetch_trending_today(media_kind))

def simkl_trending_today_page(media_kind, page_no, page_size=20):
	full_list = _simkl_fetch_trending_today(media_kind)
	start = (int(page_no) - 1) * page_size
	return full_list[start:start + page_size]
