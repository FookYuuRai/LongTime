# -*- coding: utf-8 -*-
"""Intro, credits and other skip times for an episode, from the MediaStructureEngine Skip add-on
(service.mediastructureengine.skip), which looks them up (TheIntroDB, IntroDB), finds anime openings and endings with
AnimeThemes theme songs, reads chapters and compares episodes. This module keeps the functions and the answers the
player always used; it only asks that add-on (JSON-RPC NotifyAll) and reads its answer from a Home window property.
The player still does the skipping. Without that add-on, or when it does not answer, every function gives None.
"""
import json
import re
import time
import xbmc
import xbmcgui

SENDER = 'service.mediastructureengine.skip'
_HOME = 10000
_PREFIX = 'mse_skip.result.'
_POLL_SEC = 0.5
_ANSWER_WAIT_SEC = 5
_RESOLVE_WAIT_SEC = 180
_MIN_SEGMENT_SEC = 10
_MIN_END_SEC = 15
_MAX_SEGMENT_SEC = 600
_MAX_INTRO_START_FRAC = 0.5
_EMPTY = (None, '', 'None', '0', '0000000', 'tt0000000', 0)


def _clean(value):
	return '' if value in _EMPTY else str(value)


def _media(tmdb_id, imdb_id, season, episode, duration_sec=None, tvdb_id=None, title=None, mode='api'):
	try: season, episode = int(season), int(episode)
	except: return None
	media = {'tmdb_id': _clean(tmdb_id), 'imdb_id': _clean(imdb_id), 'tvdb_id': _clean(tvdb_id), 'season': season,
		'episode': episode, 'title': title or '', 'mode': mode,
		'buttons': ['credits']}  # the player shows its own next-episode alert; the skip add-on shows intro, recap and preview
	if not (media['tmdb_id'] or media['imdb_id'] or media['tvdb_id']): return None
	try:
		if duration_sec and float(duration_sec) > 60: media['duration_s'] = float(duration_sec)
	except: pass
	return media


def _key(media):
	return '|'.join(str(x) for x in (media['tmdb_id'], media['tvdb_id'], media['imdb_id'], media['season'], media['episode']))


def _read(media):
	try:
		data = json.loads(xbmcgui.Window(_HOME).getProperty(_PREFIX + _key(media)) or 'null')
		return data if isinstance(data, dict) and 'status' in data else None
	except: return None


def set_art(meta):
	'''The thumbnail and the "Show | 01x02 | Name" line of what plays, for the skip add-on's popup, as the player's own skip prompt picture: episode thumb, else the show's fanart, fanart only for unwatched with spoilers off).'''
	try:
		if not meta: return
		thumb = meta.get('ep_thumb') or meta.get('fanart') or ''
		try:
			from modules.settings import hide_episode_thumb
			if hide_episode_thumb() and int(meta.get('playcount') or 0) == 0: thumb = meta.get('fanart') or ''
		except: pass
		label = '%s[B] | [/B]%02dx%02d' % (meta.get('title') or '', int(meta.get('season') or 0), int(meta.get('episode') or 0))
		name = meta.get('ep_name') or ''
		if name and not re.match(r'^\s*(?:episode|ep)\s*\d*\s*$', name, re.I): label += '[B] | [/B]%s' % name
		home = xbmcgui.Window(_HOME)
		home.setProperty('mse_skip.art.thumb', thumb)
		home.setProperty('mse_skip.art.label', label)
	except: pass


def _ask(media):
	try:
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
			'params': {'sender': SENDER, 'message': 'Resolve', 'data': media}}))
	except: pass


def _valid_segment(start_sec, end_sec, duration_sec=None):
	try: start_sec, end_sec = float(start_sec), float(end_sec)
	except: return None
	if end_sec <= start_sec: return None
	length = end_sec - start_sec
	if length < _MIN_SEGMENT_SEC or length > _MAX_SEGMENT_SEC: return None
	if end_sec < _MIN_END_SEC: return None
	if duration_sec:
		try:
			total = float(duration_sec)
			if total > 60:
				if end_sec > total: return None
				if start_sec > total * _MAX_INTRO_START_FRAC: return None
		except: pass
	return {'start_sec': start_sec, 'end_sec': end_sec}


def _intro_from(data, duration_sec):
	for seg in ((data or {}).get('segments') or {}).get('intro') or []:
		if seg.get('end') is None: continue
		segment = _valid_segment(seg.get('start') or 0.0, seg['end'], duration_sec)
		if segment:
			segment['source'] = seg.get('source') or 'skip'
			return segment
	return None


def _credits_from(data, duration_sec):
	for seg in ((data or {}).get('segments') or {}).get('credits') or []:
		try: start = float(seg.get('start'))
		except: continue
		if start < 0: continue
		try:
			total = float(duration_sec) if duration_sec else 0
			if total > 60 and start > total: continue
		except: pass
		return start
	return None


def _wait(media, pick, duration_sec):
	"""Waits for the add-on's answer: the first time `pick` finds something, or when it says it is done."""
	started = time.time()
	answered = False
	while time.time() - started < _RESOLVE_WAIT_SEC:
		data = _read(media)
		if data:
			answered = True
			found = pick(data, duration_sec)
			if found is not None: return found
			if data.get('status') == 'done': return None
		elif time.time() - started > _ANSWER_WAIT_SEC and not answered:
			return None
		if xbmc.Monitor().waitForAbort(_POLL_SEC): return None
	return None


def peek_intro_segment_cache(tmdb_id, imdb_id, season, episode, duration_sec=None, tvdb_id=None):
	# The intro skip button is the skip add-on's (it comes back after a rewind); the player's own prompt gets no timing.
	return None
	media = _media(tmdb_id, imdb_id, season, episode, tvdb_id=tvdb_id)
	if not media: return None
	data = _read(media)
	if not data: return '__miss__'
	segment = _intro_from(data, duration_sec)
	if segment: return segment
	return None if data.get('status') == 'done' else '__miss__'


def prefetch_intro_segment(tmdb_id, imdb_id, season, episode, duration_sec=None, tvdb_id=None, title=None):
	media = _media(tmdb_id, imdb_id, season, episode, duration_sec, tvdb_id, title, mode='api')
	if media: _ask(media)


def prefetch_credits_start(tmdb_id, imdb_id, season, episode, duration_sec=None, tvdb_id=None, title=None):
	prefetch_intro_segment(tmdb_id, imdb_id, season, episode, duration_sec, tvdb_id, title)


def resolve_intro_segment(tmdb_id, imdb_id, season, episode, duration_sec=None, tvdb_id=None, title=None):
	media = _media(tmdb_id, imdb_id, season, episode, duration_sec, tvdb_id, title, mode='full')
	if not media: return None
	_ask(media)
	return None


def resolve_credits_start_sec(tmdb_id, imdb_id, season, episode, duration_sec=None, tvdb_id=None, title=None):
	media = _media(tmdb_id, imdb_id, season, episode, duration_sec, tvdb_id, title, mode='full')
	if not media: return None
	_ask(media)
	return _wait(media, _credits_from, duration_sec)
