# -*- coding: utf-8 -*-
import re
import json
import time
import requests
from threading import Thread
from urllib.parse import urlencode, urlparse
from caches.main_cache import cache_object
from caches.settings_cache import get_setting, set_setting
from modules.utils import copy2clip, make_qrcode, make_tinyurl
from modules import source_utils
from modules.source_utils import supported_video_extensions, seas_ep_filter, extras
from modules.kodi_utils import sleep, ok_dialog, progress_dialog, notification
# logger = kodi_utils.logger

class PremiumizeAPI:
	def __init__(self):
		self.token = get_setting('nightshift.pm.token', 'empty_setting')

	def auth(self):
		self.token = ''
		line = '%s[CR]%s[CR]%s'
		data = {'response_type': 'device_code', 'client_id': '751712187'}
		url = 'https://www.premiumize.me/token'
		response = self._post(url, data)
		user_code = response['user_code']
		auth_url = response.get('verification_uri')
		qr_code = make_qrcode(auth_url) or ''
		copy2clip(auth_url)
		short_url = make_tinyurl(auth_url)
		visit = short_url or auth_url
		content = 'Scan the [B]QR Code[/B][CR]OR visit [B]%s[/B][CR]AND Enter this Code: [B]%s[/B]' % (visit, user_code)
		progressDialog = progress_dialog('Premiumize Authorise', qr_code)
		progressDialog.update(content, 0)
		device_code = response['device_code']
		expires_in = int(response['expires_in'])
		sleep_interval = int(response['interval'])
		poll_url = 'https://www.premiumize.me/token'
		data = {'grant_type': 'device_code', 'client_id': '751712187', 'code': device_code}
		start, time_passed = time.time(), 0
		while not progressDialog.iscanceled() and time_passed < expires_in and not self.token:
			sleep(1000 * sleep_interval)
			response = self._post(poll_url, data)
			if 'error' in response:
				time_passed = time.time() - start
				progress = int(100 * time_passed/float(expires_in))
				progressDialog.update(content, progress)
				continue
			try:
				progressDialog.close()
				self.token = str(response['access_token'])
				set_setting('pm.token', self.token)
			except:
				 ok_dialog(heading='Premiumize', text='Authorisation failed.')
				 break
		try: progressDialog.close()
		except: pass
		if self.token:
			account_info = self.account_info()
			set_setting('pm.account_id', str(account_info['customer_id']))
			set_setting('pm.enabled', 'true')
			ok_dialog(heading='Premiumize', text='Account authorised.')

	def revoke(self):
		set_setting('pm.token', 'empty_setting')
		set_setting('pm.account_id', 'empty_setting')
		set_setting('pm.enabled', 'false')
		notification('Premiumize Authorisation Reset', 3000)

	def account_info(self):
		url = 'account/info'
		response = self._post(url)
		return response

	def check_cache(self, hashes):
		url = 'cache/check'
		data = {'items[]': hashes}
		return self._post(url, data, timeout=45)

	def check_single_magnet(self, hash_string):
		cache_info = self.check_cache(hash_string)['response']
		return cache_info[0]

	def unrestrict_link(self, link):
		data = {'src': link}
		url = 'transfer/directdl'
		response = self._post(url, data)
		try: return self.add_headers_to_url(response['content'][0]['link'])
		except: return None


	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode, ep_name=None, absolute_episode=None, year=0, aliases=None):
		# ###FIX### Previous version crashed on its first lines and always returned None:
		#  - `source_utils.supported_video_extensions()` used a name that was never imported (NameError)
		#  - `__import__('caches.settings_cache').get_setting(...)` returns the top-level `caches`
		#    package, which has no get_setting (AttributeError)
		# Pack contents are now matched with source_utils.pick_pack_episode_file() (no show-title gate
		# on files that are already inside a title-matched torrent) and every step is diag_log'd.
		from modules.kodi_utils import logger
		diag_log = source_utils.diag_log
		try:
			diag_log('PM_Enter', 'RESOLVE title=%r S=%s E=%s abs=%s ep_name=%r store_to_cloud=%s' % (
				title, season, episode, absolute_episode, ep_name, store_to_cloud))
			extensions = source_utils.supported_video_extensions()

			# === INSTANT TRANSFER (directdl file listing) ===
			result = self.instant_transfer(magnet_url)
			status = result.get('status') if isinstance(result, dict) else None
			if status != 'success':
				logger('PM_Reject', 'instant_transfer failed status=%r message=%r' % (
					status, (result.get('message') if isinstance(result, dict) else str(result)[:120])))
				return None

			content = result.get('content') or []
			valid_results = [i for i in content if any((i.get('path') or '').lower().endswith(x) for x in extensions) and i.get('link', '') != '']
			files = [{'path': i.get('path') or '', 'filename': (i.get('path') or '').replace('\\', '/').split('/')[-1],
					'size': i.get('size') or 0, 'link': i['link']} for i in valid_results]
			diag_log('PM_Count', 'VALID_VIDEO_FILES=%d of %d content items' % (len(files), len(content)))
			source_utils.log_pack_contents(files, 'Premiumize hash=%s' % (str(info_hash)[:12]))

			if not files:
				logger('PM_Reject', 'no video files with links in instant_transfer result (content items=%d)' % len(content))
				return None

			# === NO SEASON (movie): largest file ===
			if not season:
				biggest = max(files, key=lambda x: int(x.get('size') or 0))
				diag_log('PM_Select', 'NO-SEASON largest=%r' % biggest['filename'])
				if store_to_cloud: Thread(target=self.create_transfer, args=(magnet_url,)).start()
				return self.add_headers_to_url(biggest['link'])

			# === EPISODE: find the requested episode inside the pack ===
			chosen, reason = source_utils.pick_pack_episode_file(
				files, season, episode, absolute_episode=absolute_episode, ep_name=ep_name or '',
				title=title, label='Premiumize')
			if not chosen:
				# No confident match: return None so the caller can offer the manual file picker
				# instead of silently playing the wrong episode (old code fell back to LARGEST file).
				logger('PM_Reject', 'no confident episode match in pack: reason=%s S=%s E=%s abs=%s files=%d' % (
					reason, season, episode, absolute_episode, len(files)))
				return None

			diag_log('PM_Success', 'reason=%s file=%r' % (reason, chosen['filename']))
			if store_to_cloud: Thread(target=self.create_transfer, args=(magnet_url,)).start()
			return self.add_headers_to_url(chosen['link'])

		except Exception as e:
			import traceback
			logger('PM_Exception', '%s: %s\n%s' % (type(e).__name__, str(e), traceback.format_exc()))
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		try:
			end_results = []
			append = end_results.append
			extensions = source_utils.supported_video_extensions()
			result = self.instant_transfer(magnet_url)
			if not isinstance(result, dict) or result.get('status') != 'success':
				source_utils.diag_log('PM_Browse', 'instant_transfer not successful: %r' % (result.get('status') if isinstance(result, dict) else None))
				return None
			for item in result.get('content') or []:
				full_path = item.get('path') or ''
				if any(full_path.lower().endswith(x) for x in extensions) and not item.get('link', '') == '':
					path = full_path.replace('\\', '/').split('/')[-1] or full_path
					# 'path' keeps the folder context (Season N/...) used by pack episode matching
					append({'link': item['link'], 'filename': path, 'size': item['size'], 'path': full_path})
			return end_results
		except Exception as e:
			try:
				from modules.kodi_utils import logger
				logger('PM_Exception', 'display_magnet_pack %s: %s' % (type(e).__name__, e))
			except Exception:
				pass
			return None

	def user_cloud(self, folder_id=None):
		if folder_id:
			string = 'pm_user_cloud_%s' % folder_id
			url = 'folder/list?id=%s' % folder_id
		else:
			string = 'pm_user_cloud_root'
			url = 'folder/list'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_all(self):
		string = 'pm_user_cloud_all_files'
		url = 'item/listall'
		return cache_object(self._get, string, url, False, 0.03)

	def rename_cache_item(self, file_type, file_id, new_name):
		if file_type == 'folder': url = 'folder/rename'
		else: url = 'item/rename'
		data = {'id': file_id , 'name': new_name}
		response = self._post(url, data)
		return response['status']

	def transfers_list(self, fresh=False):
		if fresh:
			try:
				from caches.base_cache import connect_database
				dbcon = connect_database('maincache_db')
				dbcon.execute("""DELETE FROM maincache WHERE id=?""", ('pm_transfers_list',))
			except:
				pass
		url = 'transfer/list'
		response = self._get(url)
		if not response or not isinstance(response, dict):
			response = self._post(url, {})
		if not response or not isinstance(response, dict):
			return {'status': 'error', 'message': 'Invalid response', 'transfers': []}
		if str(response.get('status', '')).lower() != 'success':
			return response
		transfers = response.get('transfers')
		if transfers is None:
			transfers = response.get('data') or []
		if isinstance(transfers, dict):
			transfers = list(transfers.values())
		if not isinstance(transfers, list):
			transfers = []
		response['transfers'] = transfers
		return response

	def instant_transfer(self, magnet_url):
		url = 'transfer/directdl'
		data = {'src': magnet_url}
		return self._post(url, data)

	def create_transfer(self, magnet):
		data = {'src': magnet, 'folder_id': 0}
		url = 'transfer/create'
		return self._post(url, data)

	def delete_transfer(self, transfer_id):
		data = {'id': transfer_id}
		url = 'transfer/delete'
		return self._post(url, data)

	def delete_object(self, object_type, object_id):
		data = {'id': object_id}
		url = '%s/delete' % object_type
		response = self._post(url, data)
		return response['status']

	def get_item_details(self, item_id, fresh=False):
		url = 'item/details'
		data = {'id': item_id}
		if fresh:
			return self._post(url, data)
		string = 'pm_item_details_%s' % item_id
		args = [url, data]
		return cache_object(self._post, string, args, False, 0.5)

	def add_headers_to_url(self, url):
		# Play/download links. CDN hosts (EnergyCDN etc) already authenticate in the
		# signed path — sending API Bearer makes Kodi Range requests restart from
		# byte 0 (start-of-playback loop). Keep Bearer only when the file host is
		# premiumize.me itself. api.premiumize.me / www.premiumize.me/api still use
		# headers() in _get/_post.
		headers = {'User-Agent': 'NIGHTSHIFT'}
		host = ''
		try:
			host = (urlparse((url or '').split('|')[0]).hostname or '').lower()
		except Exception:
			pass
		if host == 'premiumize.me' or host.endswith('.premiumize.me'):
			headers['Authorization'] = 'Bearer %s' % self.token
		return url + '|' + urlencode(headers)

	def headers(self):
		return {'User-Agent': 'NIGHTSHIFT', 'Authorization': 'Bearer %s' % self.token}

	def _get(self, url, data={}, timeout=20):
		if self.token in ('empty_setting', ''): return None
		url = 'https://www.premiumize.me/api/' + url
		response = requests.get(url, data=data, headers=self.headers(), timeout=timeout).text
		try: return json.loads(response)
		except: return response

	def _post(self, url, data={}, timeout=20):
		if self.token in ('empty_setting', '') and not 'token' in url: return None
		if not 'token' in url: url = 'https://www.premiumize.me/api/' + url
		response = requests.post(url, data=data, headers=self.headers(), timeout=timeout).text
		try: return json.loads(response)
		except: return response

	def clear_cache(self, clear_hashes=True):
		try:
			from caches.debrid_cache import debrid_cache
			from caches.base_cache import connect_database
			dbcon = connect_database('maincache_db')
			user_cloud_success = False
			# USER CLOUD
			try:
				try:
					user_cloud_cache = dbcon.execute("""SELECT id FROM maincache WHERE id LIKE ?""", ('pm_user_cloud%',)).fetchall()
					user_cloud_cache = [i[0] for i in user_cloud_cache]
				except:
					user_cloud_success = True
				if not user_cloud_success:
					for i in user_cloud_cache:
						dbcon.execute("""DELETE FROM maincache WHERE id=?""", (i,))
					user_cloud_success = True
			except: user_cloud_success = False
			# DOWNLOAD LINKS
			try:
				dbcon.execute("""DELETE FROM maincache WHERE id=?""", ('pm_transfers_list',))
				download_links_success = True
			except: download_links_success = False
			# HASH CACHED STATUS
			if clear_hashes:
				try:
					debrid_cache.clear_debrid_results('pm')
					hash_cache_status_success = True
				except: hash_cache_status_success = False
			else: hash_cache_status_success = True
		except: return False
		if False in (user_cloud_success, download_links_success, hash_cache_status_success): return False
		return True

Premiumize = PremiumizeAPI()
