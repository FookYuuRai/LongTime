# -*- coding: utf-8 -*-
"""What this add-on knows about Newznab-style indexers, picked from the slot's own URL.

The URL a person pastes into an indexer slot is not always the API address: a website (https://nzbgeek.info), the API
address with /api on the end, or the full link with ?apikey=... Each is turned into the base the client needs (the client adds
/api), and the indexer is recognised so its API host, kind and usual limits are known.

Profile keys: api (API host), cat (categories to ask for), params (extra search parameters, dropped when they give nothing),
get_link (item links carry no key: build /api?t=get&id=..&apikey=..), no_grab (a small NZB-download quota: the add-on does not
download its NZBs for the pre-checks, only when one is played - the indexer's own health filter does that job).

Limits per tier come from the community list https://gist.github.com/steveulven/8df11c1e5a01d82aea74 (hits = API calls
per day, grabs = NZB downloads per day). The add-on cannot tell which tier an account is on, so these are only used in
messages (why an indexer was paused), never to block a request.
"""
import re

# host (site, no www) -> profile.  api: host that answers /api when it differs from the site.
PROFILES = {
	'nzbgeek.info':      {'name': 'NZBgeek',        'api': 'api.nzbgeek.info',     'limits': 'free: no listed limits'},
	'nzb.su':            {'name': 'NZB.su',         'api': 'api.nzb.su',           'limits': 'free 10 grabs/day; VIP 5000 hits, 450 grabs'},
	'oznzb.com':         {'name': 'OZnzb',          'api': 'api.oznzb.com',        'limits': 'free 5 hits, 5 grabs; VIP 1000 hits, 100 grabs'},
	'althub.co.za':      {'name': 'altHUB',         'api': 'api.althub.co.za',     'limits': 'API only on altUNLIMITED'},
	'nzbplanet.net':     {'name': 'NZBPlanet',      'api': 'api.nzbplanet.net',    'limits': 'free: API disabled; VIP 5000 hits'},
	'drunkenslug.com':   {'name': 'DrunkenSlug',    'api': 'api.drunkenslug.com',  'limits': 'free 25 hits, 5 grabs; Ale 1000 hits, 100 grabs'},
	'nzb.cat':           {'name': 'NZB.cat',        'limits': 'free 500 hits, 50 grabs; VIP 5000 hits, 1000 grabs'},
	'nzb.is':            {'name': 'NZB.is',         'limits': 'free 5 hits, 5 grabs; VIP 2000 hits, 200 grabs'},
	'usenet-crawler.com':{'name': 'Usenet-Crawler', 'limits': 'free 10000 hits, 1000 grabs'},
	'simplynzbs.com':    {'name': 'SimplyNZBs',     'limits': 'free 5 hits, 5 grabs; VIP 5000 hits, 1000 grabs'},
	'nzbfinder.ws':      {'name': 'NZBFinder',      'limits': 'free 100 hits, 10 grabs; Basic 5000 hits'},
	'lulunzb.com':       {'name': 'LuluNZB',        'limits': 'guest 5 hits, 5 grabs; VIP 10000 hits'},
	'pfmonkey.com':      {'name': 'PFMonkey',       'limits': 'free: API disabled; VIP 10000 hits, 1000 grabs'},
	'casstormnzb.com':   {'name': 'CasstormNZB',    'limits': 'unlimited hits for VIP'},
	'amenzb.moe':        {'name': 'AmeNZB', 'kind': 'newznab', 'cat': '5070', 'get_link': True, 'no_grab': True, 'params': {'healthy': '1'},
	                      'limits': '10000 API hits/day, 100 NZB downloads/day; API calls must come from your pinned API IP (error 100 otherwise)'},
	'omgwtfnzbs.org':    {'name': 'OMGWTFNZBS',     'limits': 'custom API, VIP only', 'kind': 'custom'},
}


def _clean_host(url):
	host = re.sub(r'^[a-z]+://', '', (url or '').strip().lower()).split('/', 1)[0].split('?', 1)[0]
	host = host.rsplit('@', 1)[-1].split(':', 1)[0]
	return host[4:] if host.startswith('www.') else host


def kind_of(url):
	"""'hydra' (NZBHydra2), 'prowlarr' or 'newznab' (direct indexers), from the address."""
	low = (url or '').lower()
	if 'hydra' in low or ':5076' in low: return 'hydra'
	if 'prowlarr' in low or ':9696' in low or re.search(r'/\d+/api', low): return 'prowlarr'
	return 'newznab'


def profile_for(url):
	"""The known profile for a slot URL (a copy), plus its kind; {'kind': ...} alone for an unknown indexer."""
	host = _clean_host(url)
	for site, profile in PROFILES.items():
		api = (profile.get('api') or '')
		if host == site or host.endswith('.' + site) or (api and host == api):
			found = dict(profile)
			found.setdefault('kind', kind_of(url))
			return found
	return {'kind': kind_of(url)}


def normalize_base(url):
	"""The base URL the client adds /api to.  'nzbgeek.info', 'https://nzbgeek.info/', 'https://api.nzbgeek.info/api?apikey=x'
	and 'https://api.nzbgeek.info' all become 'https://api.nzbgeek.info'. Prowlarr style 'http://host:9696/3/api' becomes
	'http://host:9696/3'."""
	text = (url or '').replace('empty_setting', '').strip()
	if not text: return ''
	if not re.match(r'^[a-z][a-z0-9+.-]*://', text, re.I): text = 'https://' + text
	text = text.split('?', 1)[0].split('#', 1)[0].rstrip('/')
	text = re.sub(r'/api(/.*)?$', '', text, flags=re.I).rstrip('/')
	match = re.match(r'^([a-z][a-z0-9+.-]*://)([^/]+)(.*)$', text, re.I)
	if not match: return text
	scheme, host, path = match.groups()
	if path in ('', '/'):                                     # a bare site: use its API host when it has a different one
		profile = profile_for(host)
		api = profile.get('api')
		if api and _clean_host(host) != api: return '%s%s' % (scheme, api)
	return text
