## -*- coding: utf-8 -*-
import re
from html import unescape
from urllib.parse import quote_plus
from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from modules.kodi_utils import make_session, logger
from modules import source_utils
from modules.native_torrents import USER_AGENT, normalize_info_hash, parse_size_gb

NYAA_BASE = 'https://nyaa.si'
MAX_PAGES = 40 # every page nyaa has (it stops by itself at an empty page / 'No results found'; about 14 pages of 75 in practice)

# ===== HTML TABLE PARSING REGEXES =====
_ROW = re.compile(r'<tr[^>]*>(.*?)</tr>', re.I | re.S)
_TD = re.compile(r'<td[^>]*>(.*?)</td>', re.I | re.S)
_VIEW_LINK = re.compile(r'<a\s+href="/view/\d+"[^>]*>(.*?)</a>', re.S)
_MAGNET_LINK = re.compile(r'href="magnet:\?xt=urn:btih:([A-Za-z0-9]+)[^"]*"', re.I)
_TAG = re.compile(r'<[^>]+>')
_INT = re.compile(r'\d+')
_NO_RESULTS = re.compile(r'No results found', re.I)

NYAA_CATEGORIES = {
	'0': '0_0',
	'1': '1_2',
	'2': '1_0',
}

_session = None

def _http():
	global _session
	if _session is None:
		_session = make_session('https://')
		_session.headers.update({'User-Agent': USER_AGENT, 'Accept': 'text/html, */*'})
	return _session

def nyaa_category():
	idx = str(get_setting('nightshift.nyaa.category', '0'))
	category = NYAA_CATEGORIES.get(idx, '0_0')
	source_utils_diag_log('NYAA Config', 'category_id=%s category_code=%s' % (idx, category))
	return category

def source_utils_diag_log(tag, message):
	"""Thin wrapper - diag_log only fires when Diagnostic Logging is enabled.
	###FIX### source_utils was never imported here, so every call raised NameError
	and was swallowed by the bare except: NYAA Config/Parse/Pagination/HTTP/Cache
	lines never reached kodi.log."""
	try:
		source_utils.diag_log(tag, message)
	except Exception:
		pass

def _cell_text(cell_html):
	"""Strip tags / entities from a <td> and collapse whitespace."""
	try:
		text = _TAG.sub('', cell_html)
		text = unescape(text)
		return re.sub(r'\s+', ' ', text).strip()
	except Exception:
		return ''

def _to_int(text):
	match = _INT.search(text or '')
	return int(match.group()) if match else 0

def _parse_torrent_rows(html_text, page_num):
	"""Parse nyaa.si HTML result rows into the same item dicts the RSS parser produced."""
	results, seen = [], set()
	row_count = 0
	parse_errors = 0
	
	for row_html in _ROW.findall(html_text or ''):
		try:
			row_count += 1
			tds = _TD.findall(row_html)
			if len(tds) < 8:
				continue  # header (<th>), pagination, or junk row
			
			magnet = _MAGNET_LINK.search(tds[2])
			title_link = _VIEW_LINK.search(tds[1])
			if not magnet or not title_link:
				continue
			
			info_hash = normalize_info_hash(magnet.group(1))
			name = _cell_text(title_link.group(1))
			if not info_hash or not name or info_hash in seen:
				continue
			seen.add(info_hash)
			
			size_str = _cell_text(tds[3])
			seeders = _to_int(_cell_text(tds[5]))
			
			results.append({
				'hash': info_hash,
				'name': name,
				'size': parse_size_gb(size_str),
				'seeders': seeders,
			})
		except Exception as e:
			parse_errors += 1
			continue
	
	if page_num == 1:
		source_utils_diag_log('NYAA Parse', 'page=%d rows_scanned=%d parsed=%d errors=%d' % (
			page_num, row_count, len(results), parse_errors))
	
	return results

def _cache_key(base):
	return 'NYAA_%s' % base

def clear_nyaa_cache():
	source_utils_diag_log('NYAA Cache', 'clearing cache...')
	try:
		main_cache.delete_like('NYAA_%')
		source_utils_diag_log('NYAA Cache', 'cleared successfully')
		return True
	except Exception as e:
		source_utils_diag_log('NYAA Cache', 'clear FAILED %s' % type(e).__name__)
		return False

def search(query, timeout=10, expiration=24, max_pages=MAX_PAGES):
	"""Search nyaa.si HTML endpoint, sorted largest-first, paginated until an empty page."""
	query = (query or '').strip()
	if not query:
		source_utils_diag_log('NYAA API', 'EMPTY QUERY RETURN EARLY')
		return []
	
	category = nyaa_category()
	cache_key = _cache_key('html|%s|%s' % (category, query))
	
	source_utils_diag_log('NYAA API', 'SEARCH START query=%r category=%s timeout=%d max_pages=%d' % (
		query, category, timeout, max_pages))
	
	cached = main_cache.get(cache_key)
	if cached is not None:
		source_utils_diag_log('NYAA API', 'CACHED query=%r results=%d (from cache)' % (query, len(cached or [])))
		return cached
	
	all_results, seen = [], set()
	http = _http()
	pages_fetched = 0
	total_added = 0
	pagination_empty = False
	no_results_detected = False
	
	try:
		for page in range(1, max(int(max_pages), 1) + 1):
			# Build URL with proper pagination and sorting
			url = '%s/?q=%s&c=%s&f=0&s=size&o=desc&p=%d' % (NYAA_BASE, quote_plus(query), category, page)
			
			try:
				from modules.native_torrents import safe_get
				try:
					response = safe_get(http, url, max(5, int(timeout)))
					response.raise_for_status()
				except Exception:
					import time as _t; _t.sleep(1.5)       # one more try (nyaa answers 429 / drops a request now and then) before giving up on the later pages
					response = safe_get(http, url, max(5, int(timeout)))
					response.raise_for_status()
			except Exception as e:
				source_utils_diag_log('NYAA HTTP', 'GET FAILED page=%d %s (%s)' % (page, type(e).__name__, query))
				break
			
			if _NO_RESULTS.search(response.text):
				source_utils_diag_log('NYAA Pagination', 'page=%d NO RESULTS FOUND - stopping' % page)
				no_results_detected = True
				break
			
			page_results = _parse_torrent_rows(response.text, page)
			pages_fetched += 1
			
			if not page_results:
				source_utils_diag_log('NYAA Pagination', 'page=%d EMPTY PAGE - stopping' % page)
				pagination_empty = True
				break
			
			added_this_page = 0
			for item in page_results:
				if item['hash'] not in seen:
					seen.add(item['hash'])
					all_results.append(item)
					added_this_page += 1
					total_added += 1
			
			source_utils_diag_log('NYAA Pagination', 'page=%d fetched=%d new=%d cumulative=%d' % (
				page, len(page_results), added_this_page, total_added))
			
			if not added_this_page:
				source_utils_diag_log('NYAA Pagination', 'page=%d DUPLICATE ONLY - stopping' % page)
				break
	
	except Exception as e:
		source_utils_diag_log('NYAA API', 'EXCEPTION %s query=%r' % (type(e).__name__, query))
		return []
	
	source_utils_diag_log('NYAA API', 'SEARCH COMPLETE query=%r pages=%d total=%d' % (
		query, pages_fetched, total_added))
	
	if total_added and pages_fetched == max_pages and not (pagination_empty or no_results_detected):
		source_utils_diag_log('NYAA Pagination', 'WARNING: reached max_pages=%d - may have more results available' % max_pages)
	
	if all_results:
		main_cache.set(cache_key, all_results, expiration=expiration)
		source_utils_diag_log('NYAA Cache', 'SET cache_key=%s expiration=%dh' % (cache_key, expiration))
	
	return all_results