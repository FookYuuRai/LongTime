# -*- coding: utf-8 -*-
"""One HTTP path for the four native indexers (AnimeTosho, Nyaa, PirateBay / apibay, TorrentDownloads).

Every request goes through modules.native_torrents.safe_get, so a failing certificate is retried through the platform CA store,
Kodi's own CA file, the missing-intermediate fetch and finally Kodi's own network stack - always with verification ON. On top of that
this module walks a list of mirrors (the one that answered last time first) and says plainly in the log which host failed and why.
"""
from urllib.parse import urlencode
from modules.kodi_utils import make_session, logger
from modules.native_torrents import USER_AGENT, safe_get

_session = None
_GOOD = {}          # indexer name -> base url that answered last


def _http():
	global _session
	if _session is None:
		_session = make_session('https://')
		_session.headers.update({'User-Agent': USER_AGENT, 'Accept': '*/*'})
	return _session


def ordered(name, bases):
	"""Bases with the one that worked last time first (duplicates dropped, order otherwise kept)."""
	bases = [b.rstrip('/') for b in bases if b is not None]      # '' = the path is already a full URL
	good = _GOOD.get(name)
	if good in bases:
		bases.remove(good)
		bases.insert(0, good)
	return list(dict.fromkeys(bases))


def get_text(name, bases, path, params=None, timeout=10, accept='*/*', validate=None):
	"""GET base+path(?params) on each mirror in turn; returns (text, base) of the first usable answer, else raises the last error.
	`validate(text)` -> truthy when the body is a real answer (a mirror's "lander" or block page is not)."""
	last = None
	for base in ordered(name, bases):
		url = base + path
		if params: url += ('&' if '?' in url else '?') + urlencode(params)
		try:
			response = safe_get(_http(), url, max(2, int(timeout)), headers={'Accept': accept})
			if response.status_code >= 400:
				raise RuntimeError('HTTP %s' % response.status_code)
			text = response.text
			if validate is not None and not validate(text):
				raise RuntimeError('unexpected answer (%d bytes): %r' % (len(text or ''), (text or '')[:60]))
			_GOOD[name] = base
			return text, base
		except Exception as e:
			last = e
			logger('%s api' % name, '%s failed: %s: %s' % (url.split('//')[-1].split('/')[0], type(e).__name__, str(e)[:160]))
	raise last if last else RuntimeError('no %s host' % name)


def get_json(name, bases, path, params=None, timeout=10):
	import json
	text, base = get_text(name, bases, path, params, timeout, accept='application/json',
						validate=lambda t: (t or '').lstrip()[:1] in ('[', '{'))
	return json.loads(text), base
