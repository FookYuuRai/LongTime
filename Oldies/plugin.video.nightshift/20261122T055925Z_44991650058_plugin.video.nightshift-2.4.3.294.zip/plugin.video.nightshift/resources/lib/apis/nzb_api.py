# -*- coding: utf-8 -*-
"""
NZB Indexer API - Newznab protocol client.

Works with any indexer exposing the standard Newznab API:
NZBGeek, NZBPlanet, DrunkenSlug, NZBHydra2, Prowlarr, etc.

Settings (per slot 1-3, all under the nightshift prefix):
	nzb{n}.enabled - "true" / "false"
	nzb{n}.label   - friendly name shown in menus
	nzb{n}.url     - base URL, e.g. "https://api.nzbgeek.info"
	nzb{n}.key     - Newznab API key

Master toggle: provider.nzb
"""
import hashlib
from urllib.parse import quote as urlquote
from caches.settings_cache import get_setting
from modules.kodi_utils import make_session, logger

session = make_session('https://')

def _tls_get(url, params=None, timeout=20, headers=None):
	"""session.get with the shared TLS rescue (platform store, Kodi's CA file, missing-intermediate fetch; verification stays on)."""
	from modules.native_torrents import safe_get
	kw = {}
	if params is not None: kw['params'] = params
	if headers: kw['headers'] = headers
	return safe_get(session, url, timeout, **kw)
BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'   # some hosts (AnimeTosho's CDN) refuse unknown agents
_SLOT_PAUSE = {}              # (slot, base url) -> time until which an indexer is left alone (503 / 429 / limit reached)

def nzb_link_hash(link):
	"""TorBox usenet cache key — MD5 of the NZB download URL."""
	return hashlib.md5(str(link or '').strip().encode('utf-8')).hexdigest()

NZB_SLOT_COUNT = 25
# Newznab movie + TV categories (2000 movies, 5000 tv)
DEFAULT_CATS = '2000,5000'

class NzbIndexerAPI:
	def __init__(self, slot=1):
		self.slot = slot
		prefix = 'nightshift.nzb%d' % slot
		self.enabled = get_setting('%s.enabled' % prefix, 'false') == 'true'
		self.label = get_setting('%s.label' % prefix) or 'NZB Indexer %d' % slot
		from apis.nzb_profiles import normalize_base, profile_for
		self.base_url = normalize_base(get_setting('%s.url' % prefix) or '')      # site / API / pasted link -> the base to add /api to
		self.profile = profile_for(self.base_url)                                  # which indexer it is, its API host, kind and usual limits
		self.api_key = (get_setting('%s.key' % prefix) or '').replace('empty_setting', '').strip().strip('"\' ')

	def is_configured(self):
		return bool(self.base_url and self.api_key)

	def is_active(self):
		return self.enabled and self.is_configured()

	# ---- one request, with the polite handling indexers need: 503/429 -> one retry, then pause this indexer ----
	def _paused(self):
		return _SLOT_PAUSE.get((self.slot, self.base_url), 0) - _time.time() > 0

	def _pause(self, seconds, why):
		_SLOT_PAUSE[(self.slot, self.base_url)] = _time.time() + seconds
		name = self.profile.get('name') or self.label
		hint = (' (%s)' % self.profile['limits']) if self.profile.get('limits') and ('limit' in why or '429' in why) else ''
		logger('NZB', 'indexer %s (%s) paused %ss: %s%s' % (self.slot, name, int(seconds), why, hint))

	def _get(self, params, timeout=20):
		"""session.get on /api. HTTP 429 / 502 / 503 / 504: wait (Retry-After, max 5s) and try once more; if it is still
		refusing, this indexer is paused for a minute so the rest of the queries do not hammer it. Returns the response or None."""
		url = '%s/api' % self.base_url
		for attempt in (0, 1):
			response = _tls_get(url, params=params, timeout=timeout, headers={'User-Agent': BROWSER_UA, 'Accept': '*/*'})
			if response.status_code not in (429, 502, 503, 504):
				return response
			delay = _retry_after(response, 2)
			if attempt == 0:
				logger('NZB', 'indexer %s answered HTTP %s; trying once more in %ss' % (self.slot, response.status_code, min(delay, 5)))
				_time.sleep(min(delay, 5))
				continue
			self._pause(max(60, delay), 'HTTP %s (service unavailable / too many requests)' % response.status_code)
			return None
		return None

	def search(self, query, cat=DEFAULT_CATS, expiration=2, light=False):
		"""light: a follow-up query of the same scrape to an indexer that already answered properly - no retry chain when it finds
		nothing (XML, no extras, no category = up to 3 more requests), and an empty answer is remembered for 20 minutes so the same
		query is not sent again by the next search."""
		if not self.is_configured(): return []
		if self._paused(): return []
		try:
			from caches.main_cache import main_cache
			from caches import watching_cache
			string = 'NZB_%s_%s_%s' % (self.slot, urlquote(self.base_url, safe=''), urlquote(query, safe=''))
			live = bool((watching_cache._ctx() or {}).get('live'))
			def _fetch():
				cached = main_cache.get(string)
				if cached: return cached
				if light and not live and main_cache.get(string + '_EMPTY'): return []
				result = self._search(query, cat, retry=not light)
				# only keep real hits: a failed or empty search must not be served from cache for hours
				if result: main_cache.set(string, result, expiration=expiration)
				elif light and getattr(self, '_last_readable', False): main_cache.set(string + '_EMPTY', True, expiration=0.33)
				return result
			return watching_cache.cached('nzb_%s' % self.slot, query, _fetch)
		except Exception:
			return self._search(query, cat, retry=not light)

	def capabilities(self):
		"""Fetch indexer caps - used by Test Connection. JSON when the indexer honours o=json, else Newznab XML (AmeNZB and many
		others answer XML only). Returns a dict ('server' / 'channel' info) or {'error': why}."""
		try:
			params = {'t': 'caps', 'apikey': self.api_key, 'o': 'json'}
			response = self._get(params, timeout=15)
			if response is None: return {'error': 'indexer unavailable (HTTP 503/429)'}
			try:
				data = response.json()
				if isinstance(data, dict): return data
			except Exception:
				pass
			text = (response.text or '').strip()
			import re as _re
			m = _re.search(r'<error[^>]*code="(\d+)"[^>]*description="([^"]*)"', text)
			if m: return {'error': '%s (code %s)' % (m.group(2), m.group(1))}
			if '<caps' in text[:2000] or '<server' in text[:2000]:
				server = {}
				try:
					import xml.etree.ElementTree as ET
					node = ET.fromstring(text).find('server')
					if node is not None: server = dict(node.attrib)
				except Exception:
					pass
				return {'server': server}
			if response.status_code != 200: return {'error': 'HTTP %s' % response.status_code}
			return {'error': 'Unexpected reply (not Newznab): %s' % _re.sub(r'\s+', ' ', text[:120])}
		except Exception as e:
			return {'error': str(e)}

	def verify_key(self):
		"""Authenticated check: t=caps needs no key, so a wrong key still 'connects'. Returns (ok, message)."""
		import re
		try:
			params = {'t': 'search', 'apikey': self.api_key, 'q': 'test', 'o': 'json', 'limit': 1}
			response = self._get(params, timeout=20)
			if response is None: return False, 'Indexer unavailable (HTTP 503 / too many requests) - try again in a minute'
			text = response.text or ''
			try: data = response.json()
			except Exception: data = None
			if isinstance(data, dict):
				error = data.get('error') or data.get('Error')
				if error:
					attrs = error.get('@attributes', error) if isinstance(error, dict) else {}
					desc = attrs.get('description') if isinstance(attrs, dict) else None
					code = attrs.get('code') if isinstance(attrs, dict) else None
					return False, '%s%s' % (desc or str(error)[:150], (' (code %s)' % code) if code else '')
				import json as _j
				channel = data.get('channel') if isinstance(data.get('channel'), dict) else {}
				flat = _j.dumps(data).lower()
				# some indexers answer HTTP 200 with the complaint inside the body instead of an error element
				if any(w in flat for w in ('api key', 'apikey', 'api_key', 'incorrect user', 'invalid key', 'unauthor')) and 'item' not in channel:
					hint = _j.dumps(channel.get('account') or channel)[:160]
					return False, 'Indexer says: %s' % hint
				if 'item' not in channel and 'response' not in channel:
					return False, 'Indexer sent no search result block (usually a rejected or unactivated key). Reply: %s' % _j.dumps(channel.get('account') or channel)[:160]
				return True, ''
			m = re.search(r'<error[^>]*code="(\d+)"[^>]*description="([^"]*)"', text)
			if m: return False, '%s (code %s)' % (m.group(2), m.group(1))
			if response.status_code == 200 and ('<rss' in text[:2000] or '<channel' in text[:2000]): return True, ''      # Newznab XML answer
			if response.status_code in (401, 403): return False, 'HTTP %s - API key rejected' % response.status_code
			if response.status_code != 200: return False, 'HTTP %s' % response.status_code
			return False, 'Unexpected reply: %s' % text[:120].replace(chr(10), ' ')
		except Exception as e:
			return False, str(e)[:150]

	def _search(self, query, cat=DEFAULT_CATS, extras=True, retry=True):
		profile = self.profile or {}
		if cat == DEFAULT_CATS and profile.get('cat'): cat = profile['cat']         # e.g. AmeNZB files anime under 5070
		params = {'t': 'search', 'apikey': self.api_key, 'q': query, 'o': 'json', 'limit': 100}
		if cat: params['cat'] = cat
		if extras and profile.get('params'): params.update(profile['params'])
		try:
			response = self._get(params, timeout=20)
			if response is None: return []                         # 429 / 503 twice: this indexer is paused, nothing cached
			try: data = response.json()
			except Exception: data = None
			results = self._parse_results(data) if isinstance(data, (dict, list)) else []
			if not results and data is None:                        # some indexers / Prowlarr ignore o=json and answer RSS XML
				results = self._parse_xml(response.text or '')
				if results: logger('NZB', 'indexer %s answered XML (no JSON); read it anyway' % self.slot)
				if retry and not results and params.get('o') == 'json' and not self._paused() and (response.status_code >= 400 or not (response.text or '').lstrip()[:5] in ('<?xml', '<rss ', '<rss>')):
					# JSON was refused or unreadable (HTTP error / odd body): ask again the plain Newznab way (XML) once
					logger('NZB', 'indexer %s q=%r: o=json gave nothing usable (http=%s); retrying as XML' % (self.slot, query, response.status_code))
					xml_params = {k: v for k, v in params.items() if k != 'o'}
					response2 = self._get(xml_params, timeout=20)
					if response2 is not None:
						results = self._parse_xml(response2.text or '')
						if results: response = response2
			self._note_error(data, response)
			results = self._more_pages(params, results, data, response)
			results = self._finish(results)
			if results: logger('NZB', 'indexer %s q=%r -> %d items' % (self.slot, query, len(results)))
			else: logger('NZB', 'indexer %s q=%r http=%s -> 0 items (%s)' % (self.slot, query, response.status_code, self._empty_reason(data, response)))
			if retry and not results and extras and profile.get('params') and not self._paused():
				logger('NZB', 'indexer %s q=%r: retrying without %s' % (self.slot, query, ','.join(profile['params'])))
				return self._search(query, cat=cat, extras=False, retry=retry)
			text = response.text or ''
			readable = data is not None or '<rss' in text[:600] or ('<?xml' in text[:100] and '<error' not in text[:600])      # an answer, not an outage page
			self._last_readable = bool(readable and not self._is_error(data))
			if retry and not results and cat and readable and not self._paused() and not self._is_error(data):
				# category filter can hide everything on some indexers - retry once with no cat at all
				logger('NZB', 'indexer %s q=%r: retrying without category filter' % (self.slot, query))
				return self._search(query, cat=None, extras=extras, retry=retry)
			return results
		except Exception as e:
			logger('NIGHTSHIFT', 'NZB indexer %s search error: %s' % (self.slot, e))
			self._last_readable = False
			self._pause(60, 'search error (%s) - left alone for the rest of this search' % type(e).__name__)      # the next queries of this scrape do not hit it again
			return []

	@staticmethod
	def _total_from(data, text):
		"""The total number of matches a Newznab answer reports (response total), or None."""
		try:
			if isinstance(data, dict):
				channel = data.get('channel') or {}
				node = (channel.get('response') if isinstance(channel, dict) else None) or data.get('response') or {}
				if isinstance(node, list): node = node[0] if node else {}
				attrs = node.get('@attributes', node) if isinstance(node, dict) else {}
				if attrs.get('total') not in (None, ''): return int(attrs['total'])
			import re as _re
			m = _re.search(r'<[a-z0-9]*:?response[^>]*\btotal="(\d+)"', text or '', _re.I)
			if m: return int(m.group(1))
		except Exception:
			pass
		return None

	def _more_pages(self, params, results, data, response):
		"""No cap: Newznab answers one page ('limit'); keep asking with the next offset until the indexer's reported total is read
		(or, when it reports none, until a page brings nothing new)."""
		try:
			if not results: return results
			limit = int(params.get('limit') or 100)
			total = self._total_from(data, response.text)
			if total is not None and total <= len(results): return results
			if total is None and len(results) < limit: return results        # a short first page and no total: that was everything
			seen = {(r.get('id') or r.get('link')) for r in results}
			offset, pages = len(results), 1
			while pages < 1000 and not self._paused():
				page_params = dict(params)
				page_params['offset'] = offset
				reply = self._get(page_params, timeout=20)
				if reply is None: break
				try: page_data = reply.json()
				except Exception: page_data = None
				page = self._parse_results(page_data) if isinstance(page_data, (dict, list)) else []
				if not page and page_data is None: page = self._parse_xml(reply.text or '')
				fresh = [r for r in page if (r.get('id') or r.get('link')) not in seen]
				if not fresh: break
				for r in fresh: seen.add(r.get('id') or r.get('link'))
				results = results + fresh
				offset += len(page)
				pages += 1
				if total is not None and offset >= total: break
				if total is None and len(page) < min(limit, 20): break
			if pages > 1: logger('NZB', 'indexer %s: read %d pages -> %d items (indexer total %s)' % (self.slot, pages, len(results), total))
		except Exception as e:
			logger('NZB', 'indexer %s: paging stopped (%s)' % (self.slot, str(e)[:80]))
		return results

	def _finish(self, results):
		"""Per-indexer clean-up of parsed results: build the download link for indexers whose items carry none with a key,
		and mark indexers with a small NZB-download quota (their NZBs are not downloaded for the pre-checks)."""
		profile = self.profile or {}
		for item in results:
			if profile.get('get_link') and item.get('id') and 'apikey=' not in item.get('link', '').lower():
				item['link'] = '%s/api?t=get&id=%s&apikey=%s' % (self.base_url, item['id'], self.api_key)
			if profile.get('no_grab'): item['no_grab'] = True
		return results

	def _note_error(self, data, response):
		"""A Newznab error element: pause the indexer when the account is out of hits / API disabled / key refused."""
		try:
			text = response.text or ''
			code, desc = None, ''
			if isinstance(data, dict) and (data.get('error') or data.get('Error')):
				error = data.get('error') or data.get('Error')
				attrs = error.get('@attributes', error) if isinstance(error, dict) else {}
				code, desc = str(attrs.get('code', '')), str(attrs.get('description', '') or error)[:120]
			else:
				import re as _re
				m = _re.search(r'<error[^>]*code="(\d+)"[^>]*description="([^"]*)"', text)
				if m: code, desc = m.group(1), m.group(2)
			if not code: return
			if code in ('500', '429') or 'limit' in desc.lower(): self._pause(3600, 'request limit reached - %s' % desc)
			elif code in ('100', '101', '102', '103'): self._pause(900, 'rejected (code %s) - %s' % (code, desc))
		except Exception:
			pass

	@staticmethod
	def _parse_xml(text):
		"""Newznab RSS (what Prowlarr / most indexers send when JSON is not honoured)."""
		results = []
		try:
			if '<rss' not in text[:2000] and '<item' not in text[:5000]: return []
			import xml.etree.ElementTree as ET
			root = ET.fromstring(text)
			for item in root.iter('item'):
				attrs = {}
				for node in item:
					tag = node.tag.split('}')[-1]
					if tag == 'attr': attrs[node.get('name', '')] = node.get('value', '')
				enclosure = item.find('enclosure')
				link = (item.findtext('link') or '').strip() or (enclosure.get('url', '') if enclosure is not None else '')
				try: size = int(attrs.get('size') or (enclosure.get('length') if enclosure is not None else 0) or 0)
				except Exception: size = 0
				name = (item.findtext('title') or '').strip()
				if link and name:
					results.append({'name': name, 'size': size, 'category': attrs.get('category', ''), 'group': attrs.get('group', ''),
									'age': item.findtext('pubDate') or '', 'link': link, 'grabs': int(attrs.get('grabs') or 0), 'id': attrs.get('guid', '')})
		except Exception:
			return []
		return results

	@staticmethod
	def _is_error(data):
		return isinstance(data, dict) and bool(data.get('error') or data.get('Error'))

	@staticmethod
	def _empty_reason(data, response):
		"""Why a search came back empty, for the log (never includes the URL or API key)."""
		try:
			if data is None:
				return 'not JSON: %r' % (response.text or '')[:100]
			if isinstance(data, dict):
				error = data.get('error') or data.get('Error')
				if error:
					attrs = error.get('@attributes', error) if isinstance(error, dict) else {}
					return 'indexer error: %s' % (attrs.get('description') or attrs.get('code') or str(error)[:100])
				channel = data.get('channel') or {}
				resp = channel.get('response') if isinstance(channel, dict) else None
				total = (resp.get('@attributes', resp) if isinstance(resp, dict) else {}).get('total')
				if total is not None: return 'indexer says total=%s' % total
				import json as _j, re as _re
				snippet = _re.sub(r'(?i)(apikey|api_key|r)=[^&"\s]+', r'\1=***', _j.dumps(channel)[:300])
				account = _re.sub(r'(?i)(apikey|api_key|r)=[^&"\s]+', r'\1=***', _j.dumps(channel.get('account'))[:400]) if isinstance(channel, dict) else ''
				return 'no items; keys=%s channel_keys=%s account=%s attrs=%s' % (list(data.keys())[:6], list(channel.keys())[:8] if isinstance(channel, dict) else type(channel).__name__, account, _j.dumps(data.get('@attributes'))[:120])
			return 'unexpected %s' % type(data).__name__
		except Exception as e:
			return 'unreadable: %s' % type(e).__name__

	@staticmethod
	def _parse_results(data):
		results = []
		try:
			if isinstance(data, list): data = {'item': data}
			channel = data.get('channel') or {}
			# Newznab JSON layouts differ: channel.item (most), a top-level item list (some proxies)
			items = (channel.get('item') if isinstance(channel, dict) else None) or data.get('item') or data.get('items') or []
			if isinstance(items, dict): items = [items]
			for item in items:
				try:
					attrs = {}
					raw_attrs = item.get('newznab:attr') or item.get('attr') or []
					if isinstance(raw_attrs, dict): raw_attrs = [raw_attrs]
					for attr in raw_attrs:
						if isinstance(attr, dict):
							inner = attr.get('@attributes', attr)
							attrs[inner.get('@name') or inner.get('name', '')] = inner.get('@value') or inner.get('value', '')
					enclosure = item.get('enclosure') or {}
					if isinstance(enclosure, list): enclosure = enclosure[0] if enclosure else {}
					enclosure_attrs = enclosure.get('@attributes', enclosure) if isinstance(enclosure, dict) else {}
					link = item.get('link', '') or enclosure_attrs.get('@url') or enclosure_attrs.get('url', '')
					try: size = int(attrs.get('size') or enclosure_attrs.get('@length') or enclosure_attrs.get('length') or 0)
					except: size = 0
					result = {'name': item.get('title', ''), 'size': size, 'category': attrs.get('category', ''),
							'group': attrs.get('group', ''), 'age': item.get('pubDate', ''), 'link': link,
							'grabs': int(attrs.get('grabs') or 0), 'id': attrs.get('guid', '')}
					if result['link'] and result['name']: results.append(result)
				except: pass
		except: pass
		return results

def enabled_slots():
	"""All enabled + configured slot APIs."""
	apis = [NzbIndexerAPI(slot) for slot in range(1, NZB_SLOT_COUNT + 1)]
	return [api for api in apis if api.is_active()]

def release_key(name):
	"""Release name reduced to letters+digits, so 'Show.S01E01.1080p-GRP' and 'show s01e01 1080p grp' are one release."""
	import re
	return re.sub(r'[^a-z0-9]+', '', (name or '').lower())

def dedupe_releases(items):
	"""One entry per release name, from the TOP-most indexer slot (lowest 'slot'; a missing slot ranks last; between
	equal slots the first seen stays). The other copies are not thrown away: they are listed on the kept item as
	'alternates' (top-most first), so a copy that turns out to be dead can be swapped for one that works.
	Order of the kept items is preserved."""
	groups, order = {}, []
	for item in items:
		key = release_key(item.get('name', '')) or item.get('link', '')
		if not key: continue
		if key not in groups:
			groups[key] = []
			order.append(key)
		groups[key].append(item)
		for alt in item.get('alternates') or []:                       # copies already set aside by an earlier merge
			groups[key].append({'name': item.get('name'), 'link': alt.get('link'), 'indexer': alt.get('indexer'), 'slot': alt.get('slot')})
	kept = []
	for key in order:
		copies = sorted(groups[key], key=lambda i: i.get('slot') or 999)       # stable: equal slots keep first-seen order
		best, rest = copies[0], []
		seen = {best.get('link')}
		for other in copies[1:]:
			link = other.get('link')
			if link and link not in seen:
				seen.add(link)
				rest.append({'link': link, 'indexer': other.get('indexer'), 'slot': other.get('slot')})
		best['alternates'] = rest
		kept.append(best)
	return kept

def search_all(query, cat=DEFAULT_CATS, expiration=2, light=False):
	"""Search EVERY enabled indexer slot (in parallel) and merge. The same release found on several indexers is NOT merged:
	each copy is its own result (the one that is kept by a de-duplication is not always the one that plays)."""
	if get_setting('nightshift.provider.nzb', 'false') != 'true': return []
	apis = enabled_slots()
	if not apis: return []
	from modules import source_utils as _su
	_ctx_value = getattr(_su._request_ctx, 'value', None)
	def _one(api):
		_su._request_ctx.value = _ctx_value   # worker threads keep the request context (currently-watching cache)
		try: return api.search(query, cat=cat, expiration=expiration, light=light) or []
		except Exception: return []
	try:
		from concurrent.futures import ThreadPoolExecutor
		with ThreadPoolExecutor(max_workers=len(apis)) as pool:
			batches = list(pool.map(_one, apis))
	except Exception:
		batches = [_one(api) for api in apis]
	merged = []
	for api, batch in zip(apis, batches):               # slot order: the top-most indexer is first
		for item in batch:
			if item.get('name'):
				item['indexer'] = api.label
				item['slot'] = api.slot
				merged.append(item)
	merged.sort(key=lambda i: i.get('size', 0), reverse=True)          # every copy is listed (its Site: label says which indexer); equal sizes keep slot order
	return merged


# --- one download per NZB ----------------------------------------------------------------------------------------
# The scrape (Single Video Only, playability check) and the play itself need the same NZB. It is downloaded once and kept
# IN MEMORY for a few minutes (a small, capped cache), so an indexer is not asked again (HTTP 429) - never on disk: a scrape
# touches hundreds of NZBs and files of that kind filled a TV box's storage. What is worth keeping longer (what an NZB
# holds, whether it is playable) is a few bytes in the database cache.
import os, re as _re, threading as _threading, time as _time
from collections import OrderedDict as _OrderedDict
NZB_MEMORY_SECONDS = 600
NZB_MEMORY_BYTES = 24 << 20          # at most 24 MB of NZBs held at once
_MEM = _OrderedDict()                # link hash -> (time, bytes)
_MEM_LOCK = _threading.Lock()
_HOST_GATE = {}                  # indexer host -> semaphore (at most 2 downloads at once per indexer)
_HOST_COOLDOWN = {}              # indexer host -> time until which it asked us to slow down (HTTP 429)
_LINK_BLOCK = {}                 # link hash -> (time until which the indexer will not hand this NZB out again, why)
_AUTH_TOLD = set()               # indexer hosts whose refused key has been reported on screen this session
_HOST_STRIKES = {}               # indexer host -> how many refusals in a row (429 / limit reached); a good NZB resets it
_GATE_LOCK = _threading.Lock()

def _host(link):
	try: return link.split('//', 1)[-1].split('/', 1)[0].lower()
	except Exception: return ''

def _retry_after(response, default=8):
	try: return max(1, min(int(float(response.headers.get('Retry-After', default))), 30))
	except Exception: return default

def stored_nzb(link):
	"""The NZB bytes kept in memory from an earlier download (None if none / too old)."""
	try:
		key = nzb_link_hash(link)
		with _MEM_LOCK:
			entry = _MEM.get(key)
			if entry and _time.time() - entry[0] < NZB_MEMORY_SECONDS:
				_MEM.move_to_end(key)
				return entry[1]
			_MEM.pop(key, None)
	except Exception: pass
	data = _disk_nzb(link)
	if data:
		try:
			with _MEM_LOCK: _MEM[nzb_link_hash(link)] = (_time.time(), data)
		except Exception: pass
	return data

# NZBs that were played are also kept on disk, gzip-compressed (about 2.8x smaller: a 50 GB film is ~2.3 MB), two days from last use, at most ~120 MB: some indexers hand out
# one NZB only a few times a day (nzb.life: three deliveries in 24 hours), and every play, playability check and retry used to ask again.
NZB_DISK_SECONDS = 48 * 3600
NZB_DISK_BYTES = 120 << 20

def _disk_dir():
	try:
		from modules.kodi_utils import addon_profile
		path = os.path.join(addon_profile(), 'nzbcache')
		os.makedirs(path, exist_ok=True)
		return path
	except Exception:
		return ''

def _disk_nzb(link):
	try:
		folder = _disk_dir()
		if not folder: return None
		path = os.path.join(folder, nzb_link_hash(link) + '.nzb.gz')
		if not os.path.isfile(path): return None
		if _time.time() - os.path.getmtime(path) > NZB_DISK_SECONDS:
			os.remove(path)
			return None
		import gzip
		with gzip.open(path, 'rb') as handle:
			data = handle.read()
		if b'<nzb' not in data[:4000].lower(): return None
		try: os.utime(path, None)                       # kept two days from its LAST use
		except OSError: pass
		return data
	except Exception:
		return None

def keep_on_disk(link, data):
	"""Called when an NZB is PLAYED (not for the playability checks, which would fill the folder with 15 NZBs per search): keeps
	it two days so replaying, seeking back in or retrying never asks the indexer again."""
	try:
		folder = _disk_dir()
		if folder:
			path = os.path.join(folder, nzb_link_hash(link) + '.nzb.gz')
			if os.path.isfile(path):
				os.utime(path, None)
				return
		_store_disk(link, data)
	except Exception: pass

def _store_disk(link, data):
	try:
		folder = _disk_dir()
		if not folder: return
		import gzip
		path = os.path.join(folder, nzb_link_hash(link) + '.nzb.gz')
		temp = path + '.tmp'
		with gzip.open(temp, 'wb', compresslevel=6) as handle:
			handle.write(data)
		os.replace(temp, path)
		files = []
		for name in os.listdir(folder):
			full = os.path.join(folder, name)
			try: files.append((os.path.getmtime(full), os.path.getsize(full), full))
			except OSError: pass
		now, total = _time.time(), sum(f[1] for f in files)
		for mtime, size, full in sorted(files):
			if now - mtime > NZB_DISK_SECONDS or total > NZB_DISK_BYTES:
				try: os.remove(full); total -= size
				except OSError: pass
	except Exception:
		pass

def _store_nzb(link, data):
	try:
		if not data or len(data) > NZB_MEMORY_BYTES // 2: return
		key = nzb_link_hash(link)
		with _MEM_LOCK:
			_MEM[key] = (_time.time(), data)
			_MEM.move_to_end(key)
			total = sum(len(v[1]) for v in _MEM.values())
			while total > NZB_MEMORY_BYTES and len(_MEM) > 1:
				total -= len(_MEM.popitem(last=False)[1][1])
	except Exception: pass

def purge_if_due():
	"""Called once per search and at start-up: removes what older versions left on disk (the usenet/nzb folder of downloaded
	NZBs and the old local-stream job files), which could fill the storage of a small box. A cheap check, then nothing."""
	try:
		from modules.kodi_utils import addon_profile
		import shutil
		base = os.path.join(addon_profile(), 'usenet')
		if not os.path.isdir(base): return 0
		removed = 0
		for name in os.listdir(base):
			full = os.path.join(base, name)
			try:
				if os.path.isdir(full): shutil.rmtree(full, ignore_errors=True)
				else: os.remove(full)
				removed += 1
			except Exception: pass
		try: os.rmdir(base)
		except Exception: pass
		if removed: logger('NZB', 'removed %d old item(s) from userdata/usenet (NZBs are no longer kept on disk)' % removed)
		return removed
	except Exception:
		return 0

def _nzb_variants(link):
	"""The link itself, then the same file with the other extension: '.nzb.gz' <-> '.nzb' (AnimeTosho-style hosts serve either)."""
	base, sep, query = (link or '').partition('?')
	tail = (sep + query) if sep else ''
	low = base.lower()
	if low.endswith('.nzb.gz'): return [link, base[:-3] + tail]
	if low.endswith('.nzb'): return [link, base + '.gz' + tail]
	return [link]

def _with_current_key(link):
	"""The same download link with this indexer's CURRENT key in it. A link keeps the key it was made with (search results are
	saved for hours, and a saved list or a link from before a key change still carries the old one): the indexer answers
	"Invalid API Key" for that one release while everything else works. Only the key value is replaced (apikey= / api_key= / r=);
	links to hosts that are not one of the configured indexers are left untouched."""
	try:
		import re as _re
		host = _host(link)
		if not host or '?' not in link: return link
		for api in enabled_slots():
			hosts = {_host(api.base_url), (api.profile or {}).get('api', '')}
			if host not in {h for h in hosts if h}: continue
			def swap(m):
				return m.group(1) + api.api_key
			fresh, n = _re.subn(r'(?i)([?&](?:apikey|api_key|r)=)[^&#]*', swap, link)
			if n and fresh != link:
				logger('NZB', 'download link for %s carried a different key than the one in the settings (slot %s): using the current one' % (host, api.slot))
			elif n == 0:
				logger('NZB', 'download link for %s has no key in it (parameters: %s)' % (host, ','.join(sorted(k.split('=')[0] for k in link.split('?', 1)[1].split('&')))[:80]))
				if 't=get' in link.lower(): return link + '&apikey=' + api.api_key
			return fresh
	except Exception:
		pass
	return link

def fetch_nzb(link, patient=False, timeout=20):
	"""(status, bytes). Tries the link, and if that is gone or not an NZB, the same link with .nzb <-> .nzb.gz swapped.
	Whatever is found is kept under the ORIGINAL link, so every later reader hits the disk copy. See _fetch_nzb_one."""
	data = stored_nzb(link)
	if data: return 200, data
	status, data = 0, b''
	for variant in _nzb_variants(_with_current_key(link)):
		status, data = _fetch_nzb_one(variant, link, patient, timeout)
		if status == 200 and data: return 200, data
		if status in (429, 0): break                       # the host is busy / unreachable: another spelling will not help
		if len(_nzb_variants(link)) > 1:
			logger('NZB', '%s failed (HTTP %s)%s' % (variant.split('?')[0].rsplit('/', 1)[-1][:60], status, '; trying the other extension' if variant == link else ''))
	return status, data

def _fetch_nzb_one(link, orig_link, patient=False, timeout=20):
	"""(status, bytes) for ONE url. Disk copy first (status 200, no request). Otherwise one download, at most 2 at a time per indexer.
	On HTTP 429 the indexer is left alone for its Retry-After: a scrape (patient=False) gives up at once (status 429),
	playing (patient=True) waits and tries again up to 3 times. status 0 = network error."""
	data = stored_nzb(orig_link)
	if data: return 200, data
	host = _host(link)
	if link_block(orig_link)[0]: return 429, b''
	with _GATE_LOCK:
		gate = _HOST_GATE.setdefault(host, _threading.Semaphore(2))
	status = 0
	for attempt in range(3 if patient else 1):
		wait = _HOST_COOLDOWN.get(host, 0) - _time.time()
		if wait > 0:
			if host in _AUTH_TOLD and wait > 5: return 401, b''
			if not patient or wait > 5 or attempt >= 1: return 429, b''     # playing does not sit out a long pause: the next indexer's copy is tried at once
			_time.sleep(wait)
		with gate:
			data = stored_nzb(orig_link)               # another worker may have just fetched it
			if data: return 200, data
			response = None
			for retry in (0, 1):                       # a dropped connection is retried once
				try:
					response = _tls_get(link, timeout=timeout, headers={'User-Agent': BROWSER_UA, 'Accept': '*/*'})
					break
				except Exception as e:
					logger('NZB', 'download failed (%s) %s: %s' % (host, type(e).__name__, str(e)[:120]))
					if retry: break
					_time.sleep(1)
			if response is None: return 0, b''
		status = response.status_code
		if status == 429:
			blocked = _already_delivered(response)
			if blocked:
				wait_s = _raw_retry_after(response, 24 * 3600)
				_LINK_BLOCK[nzb_link_hash(orig_link)] = (_time.time() + wait_s, blocked)
				logger('NZB', 'indexer %s will not hand out this NZB again for %s (%s). It said: %s' % (host, _fmt_wait(wait_s), blocked, _refusal_note(response)))
				return 429, b''
			delay = _host_strike(host, _retry_after(response))
			logger('NZB', 'indexer %s answered 429 (too many requests); leaving it alone for %ss. It said: %s' % (host, delay, _refusal_note(response)))
			if patient and attempt == 0 and delay <= 5:
				continue
			return 429, b''
		content = response.content
		if content[:2] == b'\x1f\x8b':                    # AnimeTosho serves .nzb.gz
			try:
				import gzip
				content = gzip.decompress(content)
			except Exception:
				content = b''
		if status == 200 and b'<nzb' in content[:4000].lower():
			_store_nzb(orig_link, content)
			_HOST_STRIKES.pop(host, None)
			return 200, content
		if status == 200:
			kind, note = _classify_not_nzb(content)
			logger('NZB', 'indexer %s answered HTTP 200 without an NZB (%s): %s' % (host, kind, note))
			if kind == 'auth':
				try:
					params = sorted(k.split('=')[0] for k in link.split('?', 1)[1].split('&')) if '?' in link else []
					logger('NZB', 'key refused for %s: link parameters %s' % (host, ','.join(params)[:100]))
				except Exception: pass
				_HOST_COOLDOWN[host] = _time.time() + 1800        # a wrong key stays wrong: not asked again for half an hour (change the key in the settings)
				if host not in _AUTH_TOLD:
					_AUTH_TOLD.add(host)
					try:
						from modules import kodi_utils as _ku
						_ku.notification('%s says: %s - check this indexer\'s API key in the settings' % (host, (note.split('description=')[-1].strip('"/> ') or 'the key was refused')[:40]), 7000)
					except Exception: pass
				return 401, b''
			if kind == 'limit':
				_host_strike(host, 60)
				return 429, b''
			if kind == 'gone': return 404, b''
		return status, b''
	return status, b''

_LIMIT_WORDS = ('limit', 'exceeded', 'too many', 'slow down', 'quota', 'try again later', 'rate')
_GONE_WORDS = ('no such item', 'not found', 'removed', 'does not exist', 'dmca', 'taken down', 'deleted', 'unavailable release')

def _classify_not_nzb(content):
	"""('limit' | 'gone' | 'unknown', short text) for a 200 answer that is not an NZB (usually the indexer's own error message)."""
	try:
		text = content[:600].decode('utf-8', 'ignore')
	except Exception:
		return 'unknown', ''
	note = ' '.join(text.split())[:160]
	low = note.lower()
	import re as _re
	code = _re.search(r'code="?(\d+)', low)
	if code and code.group(1) in ('100', '101', '102', '105') or 'invalid api key' in low or 'incorrect user credentials' in low or 'api key' in low and 'invalid' in low: return 'auth', note
	if code and code.group(1) in ('429', '500', '501'): return 'limit', note
	if code and code.group(1) == '300': return 'gone', note
	if any(w in low for w in _LIMIT_WORDS): return 'limit', note
	if any(w in low for w in _GONE_WORDS): return 'gone', note
	return 'unknown', note

def _already_delivered(response):
	"""A short reason when a 429 means "you already downloaded THIS NZB" (the indexer allows only a few deliveries of one NZB a day), else ''."""
	try:
		low = ' '.join((response.text or '')[:800].lower().split())
		if 'already downloaded' in low or 'already been delivered' in low or 'already grabbed' in low:
			return 'this NZB was already delivered the most times the indexer allows in 24 hours'
	except Exception: pass
	return ''

def _raw_retry_after(response, default):
	try: return max(1, min(int(float(response.headers.get('Retry-After', default))), 48 * 3600))
	except Exception: return default

def _fmt_wait(seconds):
	return '%d h %02d min' % (seconds // 3600, seconds % 3600 // 60) if seconds >= 3600 else '%d min' % max(1, seconds // 60)

def link_block(link):
	"""(seconds left, why) when the indexer refuses to hand out this NZB again for a while, else (0, '')."""
	try:
		until, why = _LINK_BLOCK.get(nzb_link_hash(link), (0, ''))
		left = int(until - _time.time())
		return (left, why) if left > 0 else (0, '')
	except Exception:
		return 0, ''

def _refusal_note(response):
	"""What an indexer's refusal says, for the log: the relevant headers (Retry-After, rate-limit counters, content type) and the first
	200 characters of the body with any key hidden. Never the key itself."""
	try:
		import re as _re
		headers = response.headers
		keep = []
		for name in headers:
			low = name.lower()
			if low in ('retry-after', 'content-type', 'server', 'cf-ray', 'cf-mitigated') or 'ratelimit' in low or 'rate-limit' in low or low.startswith('x-') and ('limit' in low or 'remaining' in low or 'reset' in low or 'quota' in low):
				keep.append('%s=%s' % (name, str(headers.get(name))[:40]))
		body = ' '.join((response.text or '')[:400].split())[:200]
		body = _re.sub(r'(?i)(apikey|api_key|r|key|token)=[^&"\s<]+', r'\1=***', body)
		return '[%s] body: %s' % (', '.join(keep) or 'no useful headers', body or '(empty)')
	except Exception:
		return '(could not read the reply)'

def _host_strike(host, delay):
	"""An indexer refused us: leave it alone for `delay` seconds, doubling with each refusal in a row (max 10 minutes). Returns the pause."""
	n = _HOST_STRIKES.get(host, 0) + 1
	_HOST_STRIKES[host] = n
	delay = min(600, max(int(delay), int(delay) * (2 ** (n - 1)) if n > 1 else int(delay)))
	_HOST_COOLDOWN[host] = _time.time() + delay
	return delay

def nzb_check_limit():
	"""How many NEW NZB downloads one search may spend on checks (largest first); results already judged cost nothing."""
	try:
		from modules.settings import nzb_check_limit as limit
		return limit()
	except Exception:
		return 15

def nzb_in_memory(link):
	try:
		with _MEM_LOCK:
			entry = _MEM.get(nzb_link_hash(link))
			return bool(entry and _time.time() - entry[0] < NZB_MEMORY_SECONDS)
	except Exception:
		return False
