# -*- coding: utf-8 -*-
"""Zilean (DMM hash search):  GET <base>/dmm/filtered?ImdbId=<tt..>[&Season=<n>&Episode=<n>]
-> [{"raw_title","parsed_title","info_hash","size"(bytes as a string),"seasons":[..],"episodes":[..],"complete","trash",...}]
Tried on each mirror in turn (the one that answered last time first); an empty answer moves on to the next mirror."""
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, instance_base_url, normalize_info_hash
from apis import indexer_http

ZILEAN_URLS = (
	'https://zilean.stremio.ru',
	'https://zileanfortheweebs.midnightignite.me',
)


def zilean_base_url():
	return instance_base_url('zilean.url', ZILEAN_URLS, 'zilean.custom_url', 2)


def _query(imdb_id, media_type, season=None, episode=None):
	params = {'ImdbId': str(imdb_id).strip()}
	if media_type != 'movie':
		params.update({'Season': int(season), 'Episode': int(episode)})
	return params


def zilean_search_url(imdb_id, media_type, season=None, episode=None):
	"""The URL of the first mirror that would be asked (shown in logs / tests). A custom value containing /dmm/ is used as typed."""
	base = zilean_base_url()
	if not base or not imdb_id:
		return None
	if '/dmm/' in base:
		return base
	from urllib.parse import urlencode
	return '%s/dmm/filtered?%s' % (base.rstrip('/'), urlencode(_query(imdb_id, media_type, season, episode)))


def clear_zilean_cache():
	try:
		main_cache.delete_like('ZILEAN_%')
		return True
	except Exception:
		return False


def _row(raw):
	if not isinstance(raw, dict):
		return None
	info_hash = normalize_info_hash(raw.get('info_hash') or raw.get('infoHash') or '')
	name = raw.get('raw_title') or raw.get('filename') or raw.get('name') or ''
	if not info_hash or not name or set(info_hash) == {'0'}:
		return None
	return {'hash': info_hash, 'name': name, 'size': bytes_to_gb(raw.get('size') or raw.get('filesize')), 'seeders': 0}


def _rows(payload):
	if not isinstance(payload, list):
		payload = (payload or {}).get('files') or (payload or {}).get('results') or [] if isinstance(payload, dict) else []
	rows, seen = [], set()
	for raw in payload:
		row = _row(raw)
		if row and row['hash'] not in seen:
			seen.add(row['hash'])
			rows.append(row)
	return rows


def search_streams(imdb_id, media_type, season=None, episode=None, timeout=15, expiration=24):
	if not imdb_id:
		return []
	first = zilean_base_url()
	if not first:
		return []
	cache_key = 'ZILEAN_%s_%s_%s_%s_%s' % (first, imdb_id, media_type, season, episode)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	rows, error = [], None
	if '/dmm/' in first:                         # a custom full URL: exactly as typed, no mirrors
		try: rows = _rows(indexer_http.get_json('zilean', [''], first, None, timeout)[0])
		except Exception as e: error = e
	else:
		mirrors = [first] + [u for u in ZILEAN_URLS if u.rstrip('/') != first.rstrip('/')]
		for base in indexer_http.ordered('zilean', mirrors):
			try:
				payload, _ = indexer_http.get_json('zilean', [base], '/dmm/filtered', _query(imdb_id, media_type, season, episode), timeout)
			except Exception as e:
				error = e
				continue
			rows = _rows(payload)
			if rows: break
	if not rows:
		if error: logger('zilean api', '%s: %s (%s)' % (type(error).__name__, str(error)[:200], imdb_id))
		return []
	logger('zilean api', 'imdb=%s results=%d' % (imdb_id, len(rows)))
	main_cache.set(cache_key, rows, expiration=expiration)
	return rows
