# -*- coding: utf-8 -*-
"""Direct Usenet for NIGHTSHIFT: slots + login test only. Everything else (checking that a release is there, reading the
NZB, fetching and decoding articles, connections, caching, the stream itself) is done by the NNTP Stream add-on
(service.nntp.stream, with vfs.nntp for the native reader). NIGHTSHIFT passes it the enabled provider slots in order
and nothing else, so the add-on's own settings (connections per server, memory) are the only ones that apply."""
import hashlib
import os
import sys
import threading
import time
from urllib.parse import quote

ADDON_ID = 'service.nntp.stream'
SLOTS = tuple(range(1, 26))             # provider 1, then backups 2-25 in order (a missing article is asked from the next)
NOT_INSTALLED = 'the NNTP Stream add-on (service.nntp.stream) is not installed or not enabled'
_MODULE = [None]


# --- the add-on -------------------------------------------------------------------------------------------------

def addon():
    """The add-on's nntpstream module, or None. Works with or without Kodi having put it on the path."""
    if _MODULE[0]:
        return _MODULE[0]
    try:
        import nntpstream
    except ImportError:
        try:
            import xbmcaddon
            path = os.path.join(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'), 'lib')
            if path not in sys.path:
                sys.path.append(path)
            import nntpstream
        except Exception:
            return None
    _MODULE[0] = nntpstream
    return nntpstream


def installed():
    return addon() is not None


def _nntp():
    module = addon()
    if not module:
        return None
    from nntpstream import nntp
    return nntp


# --- the provider slots -------------------------------------------------------------------------------------------

def _setting(key, default=''):
    from caches.settings_cache import get_setting
    value = get_setting('nightshift.%s' % key, default)
    return '' if value in (None, 'empty_setting') else str(value).strip()


def clean_host(value):
    """'nntps://user@news.x.com:563/path' -> ('news.x.com', 563 or None)."""
    value = str(value or '').strip()
    if '://' in value:
        value = value.split('://', 1)[1]
    value = value.split('/', 1)[0]
    if '@' in value:
        value = value.rsplit('@', 1)[1]
    port = None
    if value.count(':') == 1:
        value, typed = value.split(':')
        if typed.strip().isdigit():
            port = int(typed)
    return value.strip(), port


def slot_server(slot):
    """Provider settings of one slot as a server dict, or None (off / incomplete)."""
    if _setting('usenet%d.enabled' % slot, 'false') != 'true':
        return None
    host, typed_port = clean_host(_setting('usenet%d.host' % slot))
    if not host:
        return None
    secure = _setting('usenet%d.ssl' % slot, 'true') != 'false'
    saved = _setting('usenet%d.port' % slot, '0')
    port = int(saved) if saved.isdigit() and int(saved) else typed_port
    if not port:
        port = 563 if secure else 119
    return {'host': host, 'port': port, 'ssl': secure, 'user': _setting('usenet%d.user' % slot),
            'password': _setting('usenet%d.password' % slot)}


def server_url(server):
    """'nntps://user:pass@host:port' - no connection count: how many connections to open is the add-on's decision."""
    auth = ''
    if server.get('user'):
        auth = '%s:%s@' % (quote(server['user'], safe=''), quote(server.get('password', ''), safe=''))
    return '%s://%s%s:%s' % ('nntps' if server.get('ssl') else 'nntp', auth, server['host'], server['port'])


def own_servers():
    """The enabled providers as server URLs, in slot order."""
    return [server_url(s) for s in (slot_server(n) for n in SLOTS) if s]


def parse(value):
    """'nntps://user:pass@host:563' -> {'host', 'port', 'ssl', 'user', 'password'} or None."""
    nntp = _nntp()
    return nntp.parse_server(value) if nntp else None


def addon_has_servers():
    """Servers typed into the NNTP Stream add-on's own settings (the add-on is a fine place for them)."""
    module = addon()
    if not module:
        return False
    try:
        from nntpstream import settings as addon_settings
        return bool(addon_settings.own_servers())
    except Exception:
        return False


def configured():
    return bool(own_servers()) or addon_has_servers()


# --- play and check (through the add-on) ----------------------------------------------------------------------

def _nzb_data(link):
    """The NZB's bytes, fetched with the indexer's own link and key (disk copy first, polite to busy indexers)."""
    from apis.nzb_api import fetch_nzb
    status, data = fetch_nzb(link, patient=True)
    if status in (404, 410):
        raise ValueError('NZB removed at the indexer (HTTP %s)' % status)
    if status == 429:
        from apis.nzb_api import link_block, _fmt_wait
        left, why = link_block(link)
        if left:
            raise ValueError('the indexer will not give this NZB again for %s (%s)' % (_fmt_wait(left), why))
    if status == 401:
        raise ValueError('the indexer refused the API key - check it in the settings')
    if status != 200 or not data:
        raise ValueError('the indexer did not give the NZB (HTTP %s)' % status if status else 'the indexer did not answer')
    try:
        from apis.nzb_api import keep_on_disk
        keep_on_disk(link, data)               # played: kept two days, so a replay or retry costs no download
    except Exception:
        pass
    return data


_HINT = {'v': None}


def set_episode(media_type, season=None, episode=None, absolute=None):
    """The episode being searched / played: an NZB that is a pack of episodes then opens (and is checked on) THAT episode's file, not the biggest one."""
    try:
        if media_type == 'episode' and episode:
            _HINT['v'] = {'season': int(season or 0), 'episode': int(episode), 'absolute': int(absolute or 0)}
        else:
            _HINT['v'] = None
    except (TypeError, ValueError):
        _HINT['v'] = None


def _call_with_episode(function, *args, **kwargs):
    """Calls the add-on's function with the episode hint; an older NNTP Stream add-on (no such argument) is called without it."""
    hint = _HINT['v']
    if hint:
        try:
            return function(*args, episode=hint, **kwargs)
        except TypeError as exc:
            if 'episode' not in str(exc): raise
    return function(*args, **kwargs)


def open_stream(nzb_link, name='video.mkv'):
    """(url, reason): the URL Kodi plays for this NZB, or ('', why not). The add-on has read the NZB and the film's first
    article by then, so a release whose articles are gone fails here instead of in the player."""
    module = addon()
    if not module:
        return '', NOT_INSTALLED
    servers = own_servers()
    if not servers and not addon_has_servers():
        return '', 'no Usenet provider is set up'
    try:
        data = _nzb_data(nzb_link)
        return _call_with_episode(module.play_url, data, servers, name=name), ''       # NIGHTSHIFT's slots first, the add-on's own servers as backup
    except Exception as exc:
        reason = str(exc) or type(exc).__name__
        if any(word in reason.lower() for word in ('incomplete', 'gone', 'removed', 'no video file', 'not found', 'removed at the indexer')):
            mark_dead(nzb_link, reason)
        return '', reason


def unpack_ready():
    """True when packed releases can be unpacked to the user's folder: folder set and an NNTP Stream add-on that can do it."""
    try:
        from modules.settings import nzb_unpack_folder
        module = addon()
        return bool(nzb_unpack_folder() and module and hasattr(module, 'unpack_to'))
    except Exception:
        return False


def _prune_unpacked(folder, limit_gb, keep_path=None):
    """Deletes the oldest unpacked videos so the folder stays under the limit (0 = never)."""
    import os
    if not limit_gb: return
    try:
        files = []
        for name in os.listdir(folder):
            full = os.path.join(folder, name)
            if os.path.isfile(full) and name.lower().endswith(('.mkv', '.mp4', '.m4v', '.avi', '.ts', '.m2ts', '.mov', '.webm')):
                files.append((os.path.getmtime(full), os.path.getsize(full), full))
        files.sort()
        total = sum(f[1] for f in files)
        for modified, size, full in files:
            if total <= limit_gb * 1e9: break
            if full == keep_path: continue
            try:
                os.remove(full)
                total -= size
            except OSError:
                pass
    except OSError:
        pass


def unpack_local(nzb_link, name='video.mkv'):
    """(path, reason): the video of a packed release, downloaded and unpacked into the user's folder (a progress dialog with Cancel)."""
    import hashlib, json, os, threading, time
    from modules.settings import nzb_unpack_folder, nzb_unpack_limit_gb
    module = addon()
    if not module or not hasattr(module, 'unpack_to'):
        return '', 'update the NNTP Stream add-on (0.2.0 or newer) to unpack archives'
    folder = nzb_unpack_folder()
    if not folder:
        return '', 'no unpack folder is set'
    servers = own_servers()
    if not servers and not addon_has_servers():
        return '', 'no Usenet provider is set up'
    key = hashlib.sha1(nzb_link.split('apikey=')[0].encode()).hexdigest()[:16]
    index_path = os.path.join(folder, '.nightshift-unpacked.json')
    try:
        with open(index_path) as handle:
            index = json.load(handle)
    except Exception:
        index = {}
    known = index.get(key)
    if known and os.path.isfile(known):
        try: os.utime(known, None)
        except OSError: pass
        return known, ''                                  # unpacked before: play it again
    try:
        data = _nzb_data(nzb_link)
        os.makedirs(folder, exist_ok=True)
        _prune_unpacked(folder, nzb_unpack_limit_gb())
        import xbmcgui
        dialog = xbmcgui.DialogProgress()
        dialog.create('Unpacking %s' % name, 'Downloading from your Usenet provider...')
        cancel = threading.Event()
        last = [0.0]
        def progress(done, total, speed):
            if dialog.iscanceled():
                cancel.set()
                return
            if time.time() - last[0] < 0.4: return
            last[0] = time.time()
            percent = int(done * 100 / total) if total else 0
            left = ((total - done) / speed) if speed > 0 else 0
            dialog.update(percent, '%.2f of %.2f GB  -  %.1f MB/s  -  about %d min left' % (done / 1e9, total / 1e9, speed / 1e6, left / 60 + 0.5))
        try:
            path = module.unpack_to(data, servers, folder, progress=progress, cancel=cancel)
        finally:
            try: dialog.close()
            except Exception: pass
        index[key] = path
        try:
            with open(index_path, 'w') as handle: json.dump(index, handle)
        except OSError: pass
        _prune_unpacked(folder, nzb_unpack_limit_gb(), keep_path=path)
        return path, ''
    except Exception as exc:
        reason = str(exc) or type(exc).__name__
        if type(exc).__name__ == 'Cancelled': reason = 'unpacking cancelled'
        return '', reason


def stop():
    module = _MODULE[0]
    if module:
        try:
            module.stop()
        except Exception:
            pass


def _verdict_key(link, servers):
    hint = _HINT['v']
    digest = hashlib.sha1(('|'.join(servers) + (repr(sorted(hint.items())) if hint else '')).encode('utf-8')).hexdigest()[:10]
    return 'NZBCHK_%s_%s' % (hashlib.sha1(link.encode('utf-8')).hexdigest()[:16], digest)


def verdict_cached(link):
    """True when this release was judged lately (so checking it again costs no NZB download)."""
    try:
        from caches.main_cache import main_cache
        return main_cache.get(_verdict_key(link, own_servers())) is not None
    except Exception:
        return False


def verdict_dead(link):
    """True when this release was judged dead lately (articles gone)."""
    try:
        from caches.main_cache import main_cache
        value = main_cache.get(_verdict_key(link, own_servers()))
        return isinstance(value, tuple) and value[0] is False
    except Exception:
        return False


def mark_dead(link, reason=''):
    """A release that could not be opened because its articles are gone is remembered as dead (next list hides it)."""
    try:
        from caches.main_cache import main_cache
        main_cache.set(_verdict_key(link, own_servers()), (False, reason or 'could not be opened'), expiration=24)
    except Exception:
        pass


def _provider_key(link):
    return 'NZBPRV_%s' % hashlib.sha1(link.encode('utf-8')).hexdigest()[:16]


def _remember_provider(link, result):
    """Which Usenet provider answered for this release (the one that had most of the sampled articles; the first one wins a tie).
    Older NNTP Stream add-ons do not say: nothing is kept then."""
    try:
        best = None
        for entry in result.get('by_server') or []:
            if entry.get('found') and (best is None or entry['found'] > best['found']): best = entry
        if best and best.get('host'):
            from caches.main_cache import main_cache
            main_cache.set(_provider_key(link), best['host'], expiration=8)
    except Exception:
        pass


def served_by(link):
    """Name of the Usenet provider that has this release ('NEWSHOSTING'), or '' when it was not checked / the add-on does not say."""
    try:
        from caches.main_cache import main_cache
        host = main_cache.get(_provider_key(link))
        if host:
            from modules.settings import usenet_host_name
            return usenet_host_name(host).upper()
    except Exception:
        pass
    return ''


def check_many(links, budget=30, workers=6, log=None):
    """{link: (verdict, reason)}. verdict: True (it is there), False (articles gone: drop), 'unpack' (a RAR / 7z release: a
    debrid usenet service has to unpack it) or None (could not tell: keep it). The add-on does the looking (one STAT per
    sampled article against the providers, in order); the NZB itself comes from the indexer once and is kept on disk."""
    module = addon()
    servers = own_servers()
    out = {}
    if not module or not (servers or addon_has_servers()) or not links:
        return {link: (None, 'no Usenet provider' if module else NOT_INSTALLED) for link in links}
    digest = hashlib.sha1('|'.join(servers).encode('utf-8')).hexdigest()[:10]
    deadline = time.time() + budget
    lock = threading.Lock()
    todo = list(links)

    def one(link):
        key = _verdict_key(link, servers)
        try:
            from caches.main_cache import main_cache
            cached = main_cache.get(key)
            if isinstance(cached, tuple) and len(cached) == 2:
                return cached
        except Exception:
            main_cache = None
        value = fetch_verdict(link)
        try:
            if main_cache:                  # an answer is kept in the database (a few bytes); a "don't know" for a quarter of an hour,
                main_cache.set(key, value, expiration=24 if value[0] is False else 8 if value[0] is not None else 0.25)   # so reopening the list costs no new download
        except Exception:
            pass
        return value

    def fetch_verdict(link):
        try:
            from apis.nzb_api import fetch_nzb
            status, data = fetch_nzb(link, patient=False)
            if status in (404, 410):
                return False, 'NZB removed at the indexer'
            if status != 200 or not data:
                if status == 401:
                    return None, 'indexer refused the API key'
                return None, 'NZB not available (HTTP %s)' % status        # busy / unreachable: not dead, keep it
            result = _call_with_episode(module.check, data, servers)
            _remember_provider(link, result)
            return _verdict(result)
        except Exception as exc:
            return None, str(exc) or type(exc).__name__

    def work():
        while time.time() < deadline:
            with lock:
                if not todo:
                    return
                link = todo.pop(0)
            value = one(link)
            with lock:
                out[link] = value
            if log:
                log('check %s -> %s (%s)' % (link.split('?')[0][-60:], value[0], value[1]))

    threads = [threading.Thread(target=work, daemon=True) for _ in range(max(1, min(workers, len(links))))]
    for t in threads:
        t.start()
    for t in threads:
        t.join(max(0.1, deadline - time.time()))
    return out


def _verdict(result):
    if result.get('ok'):
        return True, 'ok'
    reason = str(result.get('reason') or '')
    low = reason.lower()
    if result.get('missing'):
        return False, reason or 'articles removed from every provider'
    if 'rar' in low or '7z' in low or 'packed' in low:
        return 'unpack', reason
    if 'no video file' in low or 'empty' in low:
        return False, reason
    return None, reason or 'could not tell'


# --- Test Login ---------------------------------------------------------------------------------------------------

TRIES = ((563, True), (443, True), (119, False))     # the usual NNTP ports, SSL first


def detect(host, user, password, connections=None, port=None):
    """(server address 'nntps://...', reason) - finds the port and SSL by itself: a typed port with and without SSL, else
    563 / 443 SSL, then 119. reason is '' when the login works; a wrong login keeps the port it reached."""
    nntp = _nntp()
    if not nntp:
        return '', NOT_INSTALLED
    import socket
    auth = '%s:%s@' % (quote(user, safe=''), quote(password, safe='')) if user else ''
    tries = ((port, True), (port, False)) if port else TRIES
    first = None
    for number, secure in tries:
        value = '%s://%s%s:%s' % ('nntps' if secure else 'nntp', auth, host, number)
        first = first or value
        try:
            nntp.Connection(nntp.parse_server(value)).close()
            return value, ''
        except nntp.AuthError:
            return value, 'login refused - check the username and password'
        except socket.gaierror:
            return value, 'address %s not found - check the spelling' % host
        except Exception:
            continue
    return first, 'no Usenet server answered on %s' % ('port %s' % port if port else 'ports 563, 443 or 119')


def check(value):
    """Log in to a server ('nntps://...'): '' when it works, else why not."""
    nntp = _nntp()
    if not nntp:
        return NOT_INSTALLED
    server = nntp.parse_server(value)
    if not server:
        return 'not a server address'
    try:
        nntp.Connection(server).close()
        return ''
    except nntp.AuthError:
        return 'login refused'
    except OSError as exc:
        import socket
        if isinstance(exc, socket.gaierror):
            return 'address %s not found - check the spelling' % server['host']
        if isinstance(exc, (socket.timeout, ConnectionRefusedError)):
            return 'no answer on port %s - check the port and SSL' % server['port']
        return type(exc).__name__
    except Exception as exc:
        return type(exc).__name__
