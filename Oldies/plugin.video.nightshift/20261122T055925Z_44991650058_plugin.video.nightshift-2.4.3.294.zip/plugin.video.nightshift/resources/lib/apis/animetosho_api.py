# -*- coding: utf-8 -*-
import time as _time
from urllib.parse import urlencode
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import bytes_to_gb, json_http, normalize_info_hash, safe_get

ANIMETOSHO_JSON = 'https://feed.animetosho.org/json'
# AnimeTosho's feeds ("replace rss2 / atom with json") live on more than one domain; the one that answers is remembered.
ANIMETOSHO_HOSTS = ['https://feed.animetosho.org/json', 'https://feed.animetosho.net/json']
_GOOD = {'host': None}
MAX_PAGES = 20


def clear_animetosho_cache():
	try:
		main_cache.delete_like('ANIMETOSHO_%')
		return True
	except Exception:
		return False


def _parse_item(raw):
	info_hash = normalize_info_hash(raw.get('info_hash') or '')
	name = raw.get('torrent_name') or raw.get('title') or ''
	nzb = (raw.get('nzb_url') or '').strip()
	if not name or not (info_hash or nzb):
		return None
	try:
		seeders = int(raw.get('seeders') or 0)
	except Exception:
		seeders = 0
	try:
		size_bytes = int(raw.get('total_size') or 0)
	except Exception:
		size_bytes = 0
	return {
		'hash': info_hash,
		'name': name,
		'size': bytes_to_gb(raw.get('total_size')),
		'size_bytes': size_bytes,
		'seeders': seeders,
		'nzb': nzb,
		'id': raw.get('id') or raw.get('tosho_id') or '',
	}


def _get_json(params, timeout):
	"""GET <feed>/json?<params> on the first AnimeTosho domain that answers (the working one is tried first next time)."""
	hosts = list(ANIMETOSHO_HOSTS)
	if _GOOD['host'] in hosts:
		hosts.remove(_GOOD['host'])
		hosts.insert(0, _GOOD['host'])
	last = None
	for host in hosts:
		try:
			response = safe_get(json_http(), '%s?%s' % (host, urlencode(params)), max(5, int(timeout)))
			response.raise_for_status()
			payload = response.json()
			_GOOD['host'] = host
			return payload
		except Exception as e:
			last = e
			logger('animetosho api', '%s failed: %s: %s' % (host.split('/')[2], type(e).__name__, str(e)[:120]))
	raise last if last else RuntimeError('no AnimeTosho host')


def torrent_detail(torrent_id, timeout=10):
	"""The feed's per-torrent record (json?show=torrent&id=N). Cached a day. {} when unavailable."""
	if not torrent_id:
		return {}
	key = 'ANIMETOSHO_V2_DETAIL_%s' % torrent_id
	cached = main_cache.get(key)
	if cached is not None:
		return cached
	try:
		payload = _get_json({'show': 'torrent', 'id': torrent_id}, timeout)
		if isinstance(payload, list):
			payload = payload[0] if payload else {}
		if not isinstance(payload, dict):
			payload = {}
	except Exception:
		return {}
	logger('animetosho api', 'detail id=%s fields=%s' % (torrent_id, sorted(payload.keys())[:30]))
	main_cache.set(key, payload, expiration=24)
	return payload


def _fetch(query, timeout=10, expiration=24):
	"""Every parsed item AnimeTosho returns for a query (torrent and/or NZB), cached."""
	query = (query or '').strip()
	if not query:
		return []
	cache_key = 'ANIMETOSHO_V2_%s' % urlencode({'q': query})
	cached = main_cache.get(cache_key)
	if cached is not None:
		logger('animetosho api', 'CACHED query=%r results=%d' % (query, len(cached or [])))
		return cached
	results = []
	try:
		seen = set()
		started = _time.time()
		for page in range(1, MAX_PAGES + 1):
			if page > 1 and _time.time() - started > max(15, int(timeout) * 2): break   # a slow feed must not hold the whole scrape: keep what is in          # every page of the feed, until one adds nothing new
			try:
				payload = _get_json({'q': query} if page == 1 else {'q': query, 'page': page}, timeout)
			except Exception:
				if page == 1: raise
				break                                  # a later page failing keeps what was already collected
			if not isinstance(payload, list) or not payload:
				break
			added = 0
			for raw in payload:
				parsed = _parse_item(raw)
				if not parsed:
					continue
				key = parsed['hash'] or parsed['nzb']
				if key in seen:
					continue
				seen.add(key)
				results.append(parsed)
				added += 1
			if not added:
				break
	except Exception as e:
		logger('animetosho api', '%s: %s (query=%r)' % (type(e).__name__, str(e)[:160], query))
		return []
	logger('animetosho api', 'query=%r results=%d (nzb: %d)' % (query, len(results), sum(1 for r in results if r['nzb'])))
	main_cache.set(cache_key, results, expiration=expiration)
	return results


def search(query, timeout=10, expiration=24):
	"""Torrent results (items with an info hash) - what the AnimeTosho torrent scraper uses."""
	return [r for r in _fetch(query, timeout, expiration) if r['hash']]


def search_nzb(query, timeout=10, expiration=24):
	"""NZB results: items AnimeTosho also posted to Usenet, as NZB-scraper entries (the NZB link needs no API key)."""
	found = []
	rows = _fetch(query, timeout, expiration)
	# only when the list carries no NZB link at all (a different list format): ask the per-torrent record of the first few rows
	missing = [r for r in rows if r.get('id')][:5] if rows and not any(r['nzb'] for r in rows) else []
	for r in missing:
		detail = torrent_detail(r['id'], timeout)
		link = (detail.get('nzb_url') or '') if isinstance(detail, dict) else ''
		if link:
			r['nzb'] = link
	for r in rows:
		if r['nzb']:
			found.append({'name': r['name'], 'size': r['size_bytes'], 'link': r['nzb'], 'indexer': 'AnimeTosho', 'slot': 99,
						'category': '5070', 'group': '', 'age': '', 'grabs': 0})
	return found
