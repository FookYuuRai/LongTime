# -*- coding: utf-8 -*-
"""MediaFusion (Stremio addon):  GET <base>/stream/series/<tt..>:<season>:<episode>.json  |  <base>/stream/movie/<tt..>.json
-> {"streams": [{"name","description","infoHash","fileIdx","sources","behaviorHints":{"filename","videoSize","bingeGroup"}}, ...]}
Tried on each mirror in turn (the one that answered last time first); an empty answer moves on to the next mirror."""
from caches.main_cache import main_cache
from modules.kodi_utils import logger
from modules.native_torrents import instance_base_url, parse_stremio_stream, stremio_stream_url
from apis import indexer_http

MEDIAFUSION_URLS = (
	'https://mediafusionfortheweebs.midnightignite.me',
	'https://mediafusion.elfhosted.com',
)


def mediafusion_base_url():
	return instance_base_url('mediafusion.url', MEDIAFUSION_URLS, 'mediafusion.custom_url', 2)


def mediafusion_stream_url(imdb_id, media_type, season=None, episode=None):
	return stremio_stream_url(mediafusion_base_url(), imdb_id, media_type, season, episode)


def clear_mediafusion_cache():
	try:
		main_cache.delete_like('MEDIAFUSION_%')
		return True
	except Exception:
		return False


def _path(imdb_id, media_type, season, episode):
	imdb_id = str(imdb_id).strip()
	if media_type == 'movie':
		return '/stream/movie/%s.json' % imdb_id
	return '/stream/series/%s:%s:%s.json' % (imdb_id, int(season), int(episode))


def _streams(payload):
	rows = []
	for raw in ((payload or {}).get('streams') or []) if isinstance(payload, dict) else []:
		try: parsed = parse_stremio_stream(raw)
		except Exception: parsed = None
		if parsed: rows.append(parsed)
	return rows


def search_streams(imdb_id, media_type, season=None, episode=None, timeout=15, expiration=24):
	if not imdb_id:
		return []
	first = (mediafusion_base_url() or '').rstrip('/')
	if not first:
		return []
	cache_key = 'MEDIAFUSION_%s_%s_%s_%s_%s' % (first, imdb_id, media_type, season, episode)
	cached = main_cache.get(cache_key)
	if cached is not None:
		return cached
	rows, error = [], None
	if '/stream/' in first:                      # a custom full URL: exactly as typed, no mirrors
		try: rows = _streams(indexer_http.get_json('mediafusion', [''], first, None, max(5, int(timeout)))[0])
		except Exception as e: error = e
	else:
		mirrors = [first] + [u for u in MEDIAFUSION_URLS if u.rstrip('/') != first]
		for base in indexer_http.ordered('mediafusion', mirrors):
			try:
				payload, _ = indexer_http.get_json('mediafusion', [base], _path(imdb_id, media_type, season, episode), None, max(5, int(timeout)))
			except Exception as e:
				error = e
				continue
			rows = _streams(payload)
			if rows: break
	if not rows:
		if error: logger('mediafusion api', '%s: %s (%s)' % (type(error).__name__, str(error)[:200], imdb_id))
		return []
	logger('mediafusion api', 'imdb=%s streams=%d' % (imdb_id, len(rows)))
	main_cache.set(cache_key, rows, expiration=expiration)
	return rows
