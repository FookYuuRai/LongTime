# -*- coding: utf-8 -*-
"""Related titles when Trakt is unavailable (no Trakt client key).

TMDb recommendations cover normal titles, Simkl covers anime (its anime detail returns user recommendations and
similar titles with TMDb/IMDb/TVDb ids attached, so no id mapping is needed). Both return Trakt-shaped rows
({'ids': {...}}) so every existing Related consumer (Extras row, Browse Related, random lists) keeps working.

Which source is used follows the 'related_fallback' setting: both | tmdb | simkl | off.
"""
from urllib.parse import quote
from caches.lists_cache import lists_cache_object
from modules import kodi_utils, settings

RELATED_LIMIT = 20
_EMPTY = (None, '', 'None', 0, '0', 'empty_setting', 'API_HERE', '0000000', 'tt0000000')


def _row(ids):
	out = {}
	for key in ('tmdb', 'imdb', 'tvdb'):
		value = (ids or {}).get(key)
		if value in _EMPTY: continue
		out[key] = int(value) if key in ('tmdb', 'tvdb') and str(value).isdigit() else value
	return {'ids': out} if out else None


def _simkl_ready():
	try:
		from apis.simkl_api import _client_id
		return _client_id() not in _EMPTY
	except Exception: return False


def _simkl_related_data(imdb_id):
	"""Disabled: Simkl API is not used for related/meta (public TV calendar CDN only)."""
	return {'anime': False, 'rows': []}
	from apis.simkl_api import call_simkl  # noqa: unreachable
	found = call_simkl('/search/id?imdb=%s' % quote(str(imdb_id)), method='get')
	if not isinstance(found, list): return None
	simkl_id = next((r['ids']['simkl'] for r in found if isinstance(r, dict) and r.get('type') == 'anime' and (r.get('ids') or {}).get('simkl')), None)
	if not simkl_id: return {'anime': False, 'rows': []}
	detail = call_simkl('/anime/%s?extended=full' % simkl_id, method='get')
	if not isinstance(detail, dict): return None
	rows, seen = [], set()
	for key in ('users_recommendations', 'similar'):
		for item in detail.get(key) or []:
			row = _row(item.get('ids')) if isinstance(item, dict) else None
			if not row: continue
			ident = row['ids'].get('tmdb') or row['ids'].get('imdb') or row['ids'].get('tvdb')
			if ident in seen: continue
			seen.add(ident)
			rows.append(row)
	return {'anime': True, 'rows': rows[:RELATED_LIMIT]}


def _tmdb_recommendation_ids(media_type, tmdb_id):
	from apis.tmdb_api import get_data
	kind = 'movie' if media_type == 'movie' else 'tv'
	url = 'https://api.themoviedb.org/3/%s/%s/recommendations?api_key=%s&language=en-US&page=1' % (kind, tmdb_id, settings.tmdb_api_key())
	return lists_cache_object(get_data, 'related_fb_tmdb_%s_%s' % (kind, tmdb_id), url)


def _tmdb_related(media_type, imdb_id):
	from modules.metadata import movie_meta_external_id, tvshow_meta_external_id
	api_key = settings.tmdb_api_key()
	if api_key in _EMPTY: return []
	finder = movie_meta_external_id if media_type == 'movie' else tvshow_meta_external_id
	found = finder('imdb_id', imdb_id, api_key)
	if not found: return []
	tmdb_id = found.get('show_id') or found.get('id')
	data = _tmdb_recommendation_ids(media_type, tmdb_id)
	results = data.get('results') if isinstance(data, dict) else None
	rows = [_row({'tmdb': i.get('id')}) for i in (results or [])[:RELATED_LIMIT] if isinstance(i, dict)]
	return [r for r in rows if r]


def related_fallback(media_type, imdb_id):
	"""Trakt-shaped related rows for media_type ('movie' or 'tvshow') and an IMDb id; [] when nothing is available or the setting is off."""
	try:
		mode = settings.related_fallback_mode()
		if mode == 'off' or imdb_id in _EMPTY: return []
		rows, anime_rows = [], False
		if mode in ('both', 'simkl') and _simkl_ready():
			data = lists_cache_object(_simkl_related_data, 'related_fb_simkl_%s' % imdb_id, imdb_id)
			if isinstance(data, dict) and data.get('anime') and data.get('rows'): rows, anime_rows = data['rows'], True
		# TMDb: everything in 'tmdb' mode; in 'both' mode every title Simkl did not answer for (normal titles, or anime Simkl had nothing for).
		if mode == 'tmdb' or (mode == 'both' and not anime_rows): rows = _tmdb_related(media_type, imdb_id)
		return rows
	except Exception as e:
		kodi_utils.logger('Related Fallback', str(e))
		return []
