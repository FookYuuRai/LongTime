# -*- coding: utf-8 -*-
"""Live title suggestions for the Nightshift search keyboard.

Uses TMDb's public website search. No API key and no api.themoviedb.org calls.
Successful results are cached in memory for the session; failures are not cached.
"""
import threading

import xbmc

SEARCH_URL = 'https://www.themoviedb.org/search/multi'
HEADERS = {
    'User-Agent': 'Mozilla/5.0',
    'Accept': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://www.themoviedb.org/',
}
TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 9

_cache = {}
_cache_order = []
_cache_lock = threading.Lock()
_session = None


def _get_session():
    global _session
    if _session is None:
        from modules.kodi_utils import make_session
        _session = make_session('https://www.themoviedb.org')
    return _session


def titles_from_search(data, limit=DEFAULT_LIMIT):
    """Pull unique movie, TV and person names from a TMDb multi-search response."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    titles, seen = [], set()
    for item in results:
        if not isinstance(item, dict):
            continue
        kind = item.get('media_type')
        if kind == 'movie':
            title = item.get('title') or item.get('original_title')
        elif kind in ('tv', 'person'):
            title = item.get('name') or item.get('original_name')
        else:
            continue
        if not isinstance(title, str):
            continue
        title = title.strip()
        key = title.casefold()
        if not title or key in seen:
            continue
        seen.add(key)
        titles.append(title)
        if len(titles) >= limit:
            break
    return titles


def _remember(key, titles):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = titles
        while len(_cache_order) > CACHE_LIMIT:
            _cache.pop(_cache_order.pop(0), None)


def fetch_suggestions(text, limit=DEFAULT_LIMIT):
    """Return up to `limit` title suggestions for `text`. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    key = query.casefold()
    with _cache_lock:
        if key in _cache:
            return list(_cache[key])[:limit]
    try:
        response = _get_session().get(SEARCH_URL, params={'query': query, 'language': 'en-US'},
                                      headers=HEADERS, timeout=TIMEOUT)
        response.raise_for_status()
        titles = titles_from_search(response.json(), DEFAULT_LIMIT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] suggestions failed for {query!r}: {exc}", xbmc.LOGWARNING)
        return []
    _remember(key, titles)
    return titles[:limit]
