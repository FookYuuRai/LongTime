# -*- coding: utf-8 -*-
"""Live title suggestions for the Nightshift search keyboard.

Uses TMDb's website search, one endpoint per search type: /search/multi, /search/movie, /search/tv, /search/person, /search/collection. No API key.

Header profiles: TMDb may accept some request header sets and refuse others. Each endpoint gets its own try:
the profiles below are tried in turn for that endpoint and that query, every refusal is logged as REJECTED, and
the first profile that returns JSON results is remembered for that endpoint. Only when every profile is refused
for a query does the lookup fall back to /search/multi. Successful results are cached in memory for the session;
failures are not cached.
"""
import threading

import xbmc

HOME_URL = 'https://www.themoviedb.org/'
SEARCH_BASE = 'https://www.themoviedb.org/search/%s'

USER_FULL = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.themoviedb.org/",
    "Origin": "https://www.themoviedb.org",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}
_UA = USER_FULL["User-Agent"]

# (name, headers) - tried in this order
PROFILES = [
    ("user_full", USER_FULL),
    ("xhr_json", {
        "User-Agent": _UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
    }),
    ("xhr_json_origin", {
        "User-Agent": _UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.themoviedb.org/",
        "Origin": "https://www.themoviedb.org",
    }),
    ("chrome_doc_no_referer", {
        "User-Agent": _UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }),
    ("ua_only", {"User-Agent": "Mozilla/5.0"}),
    ("no_headers", {}),
]

TIMEOUT = (4, 8)
CACHE_LIMIT = 200
DEFAULT_LIMIT = 9

_cache = {}
_cache_order = []
_cache_lock = threading.Lock()
_state_lock = threading.Lock()
_winner = {}   # endpoint -> (profile name, headers) that last returned JSON for that endpoint
_session = None


def _new_session(headers):
    """A fresh session that has loaded the TMDb homepage with `headers` (cookies)."""
    from modules.kodi_utils import make_session
    session = make_session('https://www.themoviedb.org')
    try:
        session.get(HOME_URL, headers=headers, timeout=TIMEOUT)
    except Exception as exc:
        xbmc.log(f"[NIGHTSHIFT keyboard] homepage warm-up failed: {exc}", xbmc.LOGWARNING)
    return session


def _try_profile(endpoint, name, headers, query, page=1):
    """One request to /search/<endpoint> with one header profile. Returns (data, reason); data is None if refused."""
    session = _new_session(headers)
    params = {'query': query, 'language': 'en-US'}
    if page > 1:
        params['page'] = page
    try:
        response = session.get(SEARCH_BASE % endpoint, params=params, headers=headers, timeout=TIMEOUT)
    except Exception as exc:
        return None, f"request error: {exc}"
    if response.status_code != 200:
        return None, f"HTTP {response.status_code}"
    try:
        data = response.json()
    except Exception:
        return None, "HTTP 200 but not JSON"
    if not isinstance(data, dict) or not isinstance(data.get('results'), list):
        return None, "HTTP 200 JSON without results"
    return data, f"HTTP 200 JSON, {len(data['results'])} results"


def _profile_order(endpoint):
    """Profiles to try for one endpoint: the one that last worked for it first, then every other one in order."""
    with _state_lock:
        winner = _winner.get(endpoint)
    if winner is None:
        return list(PROFILES)
    return [winner] + [p for p in PROFILES if p[0] != winner[0]]


def _search(query, endpoint='multi', page=1):
    """Raw TMDb search JSON from /search/<endpoint> (multi, movie, tv, person, collection).

    Each endpoint runs its own header try. The first profile that answers with JSON wins and is remembered for
    that endpoint. Raises only when every profile is refused for this query, so the caller can fall back.
    """
    for name, headers in _profile_order(endpoint):
        data, reason = _try_profile(endpoint, name, headers, query, page)
        xbmc.log(f"[NIGHTSHIFT keyboard] header probe /search/{endpoint} {name}: "
                 f"{'ACCEPTED' if data is not None else 'REJECTED'} ({reason})", xbmc.LOGINFO)
        if data is not None:
            with _state_lock:
                if (_winner.get(endpoint) or (None,))[0] != name:
                    xbmc.log(f"[NIGHTSHIFT keyboard] header probe /search/{endpoint}: using profile {name}",
                             xbmc.LOGINFO)
                _winner[endpoint] = (name, headers)
            return data
    xbmc.log(f"[NIGHTSHIFT keyboard] header probe /search/{endpoint}: no header profile was accepted for {query!r}",
             xbmc.LOGWARNING)
    raise RuntimeError(f'no TMDb header profile accepted for /search/{endpoint} (see header probe log lines)')


IMAGE_URL = 'https://image.tmdb.org/t/p/original%s'   # original size, same as the skin's list backgrounds
MEDIA_LABEL = {'movie': 'Movie', 'tv': 'TV show', 'anime': 'Anime', 'person': 'Person', 'collection': 'Collection'}
ANIMATION_GENRE = 16

# What the person is searching for -> (kinds shown, anime filter, heading, TMDb search endpoint).
# anime filter: True = anime only, False = TV without anime, None = either.
# Endpoints: multi (keywords and every other search), movie, tv (TV and anime), person, collection.
ALL_KINDS = ('movie', 'tv', 'person')
ENDPOINT_KIND = {'movie': 'movie', 'tv': 'tv', 'person': 'person', 'collection': 'collection'}


def scope_for(media_type='', search_type='media_title'):
    """Suggestion scope for a search entry: (kinds, anime, heading, endpoint). Unknown searches use multi."""
    media_type, search_type = (media_type or ''), (search_type or 'media_title')
    if search_type == 'people':
        return ('person',), None, 'Search People', 'person'
    if search_type == 'tmdb_collection':
        return ('collection',), None, 'Search Collections', 'collection'
    if search_type == 'tmdb_keyword':
        return ALL_KINDS, None, 'Search Keywords', 'multi'
    if search_type == 'media_title':
        if media_type == 'movie':
            return ('movie',), None, 'Search Movies', 'movie'
        if media_type == 'tv_show':
            return ('tv',), False, 'Search TV Shows', 'tv'
        if media_type == 'anime':
            return ('tv',), True, 'Search Anime', 'tv'
        return ('tv',), None, 'Search TV Shows & Anime', 'tv'
    return ALL_KINDS, None, 'Search', 'multi'


def _image(path):
    return IMAGE_URL % path if isinstance(path, str) and path.startswith('/') else ''


def _backdrop(entry, kind):
    """TMDb backdrop for a result. A person has no backdrop of their own, so use the first title they are known for."""
    if kind == 'person':
        for work in entry.get('known_for') or []:
            if isinstance(work, dict) and isinstance(work.get('backdrop_path'), str) and work['backdrop_path'].startswith('/'):
                return _image(work['backdrop_path'])
        return ''
    return _image(entry.get('backdrop_path'))


def _is_anime(entry):
    """Best guess from the search result itself: a Japanese animation. The finished results list
    uses TMDb's anime keyword, which this search response does not carry, so this is only for suggestions."""
    genres = entry.get('genre_ids')
    japanese = entry.get('original_language') == 'ja' or 'JP' in (entry.get('origin_country') or [])
    if isinstance(genres, list):
        return ANIMATION_GENRE in genres and japanese
    return entry.get('original_language') == 'ja'


def items_from_search(data, default_kind=None):
    """Every movie, TV show, person and collection in a TMDb search response, in order, with artwork and year.
    /search/multi tags each result with media_type; /search/movie, /tv, /person and /collection do not, so
    `default_kind` names what that endpoint returns. Each item carries 'kind' and 'anime' for filtering."""
    results = data.get('results') if isinstance(data, dict) else None
    if not isinstance(results, list):
        return []
    items = []
    for entry in results:
        if not isinstance(entry, dict):
            continue
        kind = entry.get('media_type') or default_kind
        if kind == 'movie':
            title, date = entry.get('title') or entry.get('original_title'), entry.get('release_date')
        elif kind == 'tv':
            title, date = entry.get('name') or entry.get('original_name'), entry.get('first_air_date')
        elif kind in ('person', 'collection'):
            title, date = entry.get('name') or entry.get('original_name'), None
        else:
            continue
        if not isinstance(title, str) or not title.strip():
            continue
        anime = kind == 'tv' and _is_anime(entry)
        items.append({
            'title': title.strip(),
            'kind': kind,
            'anime': anime,
            'media': MEDIA_LABEL['anime' if anime else kind],
            'year': date[:4] if isinstance(date, str) and date[:4].isdigit() else '',
            'backdrop': _backdrop(entry, kind),
        })
    return items


def filter_items(items, scope, limit=None):
    """Keep only what this search mode can open, drop repeated titles, stop at `limit`."""
    kinds, anime = scope[0], scope[1]
    out, seen = [], set()
    for item in items:
        if item['kind'] not in kinds:
            continue
        if anime is True and not item['anime']:
            continue
        if anime is False and item['anime']:
            continue
        key = item['title'].casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
        if limit and len(out) >= limit:
            break
    return out


def titles_from_search(data, limit=DEFAULT_LIMIT, scope=None):
    scope = scope or (ALL_KINDS, None, 'Search', 'multi')
    return [item['title'] for item in filter_items(items_from_search(data), scope, limit)]


def _remember(key, items):
    with _cache_lock:
        if key not in _cache:
            _cache_order.append(key)
        _cache[key] = items
        while len(_cache_order) > CACHE_LIMIT:
            _cache.pop(_cache_order.pop(0), None)


def _load(query, endpoint):
    """Unfiltered items for `query`. The typed endpoints (movie, tv, person, collection) are tried first; if one
    is refused or does not answer with JSON, fall back to /search/multi (two pages) so suggestions still appear.
    Returns None only when nothing worked. Every outcome is logged."""
    if endpoint != 'multi':
        try:
            items = items_from_search(_search(query, endpoint), ENDPOINT_KIND.get(endpoint))
            xbmc.log(f"[NIGHTSHIFT keyboard] /search/{endpoint} {query!r}: {len(items)} results", xbmc.LOGINFO)
            return items
        except Exception as exc:
            xbmc.log(f"[NIGHTSHIFT keyboard] /search/{endpoint} failed for {query!r}: {exc}; falling back to /search/multi", xbmc.LOGWARNING)
        if endpoint == 'collection':
            return None        # multi has no collections
    items = []
    for page in (1, 2):
        try:
            items += items_from_search(_search(query, 'multi', page))
        except Exception as exc:
            xbmc.log(f"[NIGHTSHIFT keyboard] /search/multi page {page} failed for {query!r}: {exc}", xbmc.LOGWARNING)
            if page == 1:
                return None
            break
    xbmc.log(f"[NIGHTSHIFT keyboard] /search/multi {query!r}: {len(items)} results", xbmc.LOGINFO)
    return items


def fetch_items(text, limit=DEFAULT_LIMIT, scope=None):
    """Up to `limit` result dicts (title, kind, media, year, backdrop) for `text`, limited to what `scope`
    (see scope_for) can open. The cache is per endpoint and holds the unfiltered response. Never raises."""
    query = (text or '').strip()
    if not query:
        return []
    scope = scope or (ALL_KINDS, None, 'Search', 'multi')
    endpoint = scope[3]
    key = '%s|%s' % (endpoint, query.casefold())
    with _cache_lock:
        cached = _cache.get(key)
    if cached is None:
        cached = _load(query, endpoint)
        if cached is None:
            return []
        _remember(key, cached)
    return filter_items(cached, scope, limit)


def fetch_suggestions(text, limit=DEFAULT_LIMIT, scope=None):
    return [item['title'] for item in fetch_items(text, limit, scope)]
