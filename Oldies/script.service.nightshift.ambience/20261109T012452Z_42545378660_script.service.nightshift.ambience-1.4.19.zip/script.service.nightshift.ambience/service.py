# -*- coding: utf-8 -*-
"""NIGHTSHIFT menu ambience.

Plays a quiet loop while you browse the NIGHTSHIFT menus (home screen and NIGHTSHIFT add-on lists)
and gets out of the way the moment anything real starts playing. It restarts after playback ends.
"""
import os
import xbmc
import xbmcaddon
import xbmcgui
import json
import secrets
import threading
import time
from urllib.parse import unquote

import xbmcvfs

import musicfolders
from tracks import BUILTIN_TRACKS
import builtin_audio

ADDON = xbmcaddon.Addon()
SKIN_ID = 'skin.nightshift'
NIGHTSHIFT_PLUGIN = 'plugin://plugin.video.nightshift/'
PROP = 'PlayingBackgroundMedia'     # the skin hides the now-playing bar while this is set
AMBIENCE_FILE_PROPERTY = 'nightshift.ambience.playing.file'  # exact file currently owned by this service
THEME_WANTED_PROPERTY = 'nightshift.theme.wanted'
BG_DIR = 'special://skin/media/backgrounds/'
BG_PROP = 'NSBG'                      # Window(Home).Property(NSBG): the image the skin draws behind the Home menus
BG_SKIP = ('screen_bg',)              # the grid backdrop under everything is not part of the rotation
DEFAULT_VOLUME = 40                   # percent, when the skin string is empty
GRACE_POLLS = 2                      # seconds a menu may look "wrong" (e.g. while a folder loads) before we stop
RESTART_DELAY = 3                    # seconds to wait after real playback ends
PACK_WAIT = 90                      # seconds after the service starts that the first track waits for the built-in pack (boot without network yet)
PACK_WAIT_MAX = 900                  # ... and the longest it waits for a download that is still running
RECENT_KEEP = 4                      # tracks remembered across restarts: a new session never opens with one of them
START_SETTLE = 2                     # polls the menus must have been "allowed" before a track may start (a video may be about to open)
QUIET_POLL = 3                       # seconds between polls while real playback runs: nothing is asked of Kodi then
BUSY_CONDITION = 'Window.IsActive(busydialog) | Window.IsActive(busydialognocancel) | Window.IsActive(progressdialog) | Player.HasMedia | Player.Caching | !String.IsEmpty(Window(10000).Property(nightshift.theme.wanted))'

def log(msg):
	xbmc.log('[NIGHTSHIFT ambience] %s' % msg, xbmc.LOGINFO)

def setting_bool(key, default=True):
	try: return xbmcaddon.Addon().getSettingBool(key)      # a fresh instance: sees a change made in the settings window
	except Exception: return default

def _norm(path):
	path = unquote(path or '').replace('\\', '/')
	return path.rstrip('/').lower()

def _same_file(a, b):
	a, b = _norm(a), _norm(b)
	return a == b or os.path.basename(a) == os.path.basename(b)

def skin_string(name):
	return (xbmc.getInfoLabel('Skin.String(%s)' % name) or '').strip()

def track_exists(path):
	"""Local, network (smb/nfs/...) or Android paths, with any characters in the name."""
	try:
		if xbmcvfs.exists(path): return True
	except Exception: pass
	try: return os.path.exists(path)
	except Exception: return False

class AmbiencePlayer(xbmc.Player):
	def __init__(self):
		super().__init__()
		self.our_path = ''
		self.real_playback = False
		self.dead = False             # set when Kodi asks the service to stop: callbacks then do nothing

	def is_ours(self):
		try:
			if not (self.isPlayingAudio() and self.our_path): return False
			return _same_file(self.getPlayingFile(), self.our_path)
		except Exception: return False

	def onPlayBackStarted(self):
		if self.dead: return
		# Anything that is not our own track counts as real playback (video, music, a stream from the add-on...)
		if not self.is_ours():
			self.real_playback = True      # first: the background thread goes quiet right away
			if getattr(self, 'on_real', None): self.on_real()

	def onAVStarted(self):
		if self.dead: return
		if not self.is_ours(): self.real_playback = True

	def onPlayBackStopped(self):
		if self.dead: return
		if not self.is_ours(): self.real_playback = False

	def onPlayBackEnded(self):
		if self.dead: return
		if not self.is_ours(): self.real_playback = False

class Ambience(xbmc.Monitor):
	def onNotification(self, sender, method, data):
		# The folder buttons send this over JSON-RPC (JSONRPC.NotifyAll): scan once now, no polling.
		if sender == 'script.service.nightshift.ambience' and method.endswith('rescan'):
			self.rescan_requested = True

	def __init__(self):
		super().__init__()
		self.player = AmbiencePlayer()
		self.extra = []
		self.rescan_requested = False
		self.extra_changed = False
		self.rotation_has_tracks = False
		self.rotation_number = 0
		self.bad_polls = 0
		self.resume_at = 0
		self.ticks = 0
		self.path = ADDON.getAddonInfo('path')
		self.playlist = []            # remaining tracks in the current no-repeat shuffle bag
		self.folders_stamp = None
		self.builtin_stamp = None        # detects built-in files arriving after the async download/unpack
		self.born = time.monotonic()
		self.pack_wait_logged = False
		self.recent = self.load_recent()      # base names of the last tracks played, kept across Kodi restarts
		self.last_track = self.recent[-1] if self.recent else ''
		self.bad_tracks = 0
		self.saved_volume = None      # the user's own volume while ambience plays quieter
		self.applied_volume = None
		self.started_at = 0
		self.quiet = False            # True once real playback was seen and cleaned up after: the service then stays idle
		self.allowed_streak = 0

	def recent_file(self):
		folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/')
		if not xbmcvfs.exists(folder): xbmcvfs.mkdirs(folder)
		return os.path.join(folder, 'recent_tracks.json')

	def load_recent(self):
		try:
			with open(self.recent_file(), encoding='utf-8') as handle:
				return [str(x) for x in json.load(handle)][-RECENT_KEEP:]
		except Exception: return []

	def remember(self, path):
		name = os.path.basename(_norm(path))
		self.recent = [x for x in self.recent if x != name][-(RECENT_KEEP - 1):] + [name]
		try:
			with open(self.recent_file(), 'w', encoding='utf-8') as handle: json.dump(self.recent, handle)
		except Exception: pass

	def builtin_signature(self):
		"""Snapshot the complete-pack ready state and enabled built-in tracks."""
		available = builtin_audio.available_paths()
		return tuple((setting_id, setting_bool(setting_id, True), bool(available.get(name)))
			for setting_id, name, _label in BUILTIN_TRACKS)

	def build_playlist(self):
		"""Build a fresh bag of every enabled track; selection removes one item at a time."""
		tracks = []
		if setting_bool('builtin', True) or not self.extra_tracks():
			tracks += self.builtin_tracks()
		tracks += self.extra_tracks()
		# A file present in both the built-in list and an added folder is still one song in the bag.
		unique, seen = [], set()
		for path in tracks:
			key = _norm(path)
			if key and key not in seen:
				seen.add(key)
				unique.append(path)
		self.playlist = unique
		self.rotation_has_tracks = bool(unique)
		self.folders_stamp = musicfolders.stamp()
		self.builtin_stamp = self.builtin_signature()
		self.extra_changed = False
		self.rotation_number += 1
		log('built secure shuffle bag cycle %d: %d unique track(s), %d from added folders' %
			(self.rotation_number, len(unique), len(self.extra)))

	def current_rotation(self):
		tracks = []
		if setting_bool('builtin', True) or not self.extra_tracks(): tracks += self.builtin_tracks()
		return tracks + self.extra_tracks()

	def builtin_tracks(self):
		"""Return built-in tracks only when the complete current pack is ready."""
		available = builtin_audio.available_paths()
		if not available:
			return []
		return [available[name] for setting_id, name, _label in BUILTIN_TRACKS
			if setting_bool(setting_id, True) and available.get(name)]

	def extra_tracks(self):
		stamp = musicfolders.stamp()
		if getattr(self, '_extra_for', None) != stamp or self.rescan_requested:
			self.rescan_requested = False
			previous = list(self.extra)
			try: self.extra = musicfolders.tracks()
			except Exception as e: log('folder scan failed: %s' % e); self.extra = []
			self._extra_for = stamp
			self.extra_changed = self.extra != previous
			if self.extra_changed:
				log('local music folder scan refreshed: %d track(s)' % len(self.extra))
		return self.extra

	def track_path(self):
		"""Draw one track from the remaining bag; refill only after every track was drawn once."""
		# Built-in audio and MediaStore-indexed files can arrive after service startup.
		# Re-scan local folders periodically and rebuild when the list changes, including
		# the initial-empty -> first-indexed-track transition.
		extras = self.extra_tracks()
		if (self.folders_stamp != musicfolders.stamp()
				or self.builtin_stamp != self.builtin_signature()
				or self.extra_changed
				or (not self.playlist and (self.rotation_has_tracks or extras))):
			self.build_playlist()
		if not self.playlist: return ''
		if setting_bool('shuffle', True):
			names = set(self.recent)
			candidates = [i for i, path in enumerate(self.playlist) if os.path.basename(_norm(path)) not in names]
			if not candidates:
				candidates = [i for i, path in enumerate(self.playlist) if not self.last_track or not _same_file(path, self.last_track)]
			if not candidates: candidates = list(range(len(self.playlist)))
			selected = candidates[secrets.randbelow(len(candidates))]
		else:
			selected = 0
		path = self.playlist.pop(selected)
		log('shuffle bag draw: %s; %d track(s) remain in cycle %d' %
			(os.path.basename(path), len(self.playlist), self.rotation_number))
		self.remember(path)
		return path

	def skin_active(self):
		return xbmc.getSkinDir() == SKIN_ID

	def menus_allowed(self):
		"""True while browsing NIGHTSHIFT menus and no show theme owns the audio slot."""
		if xbmc.getInfoLabel('Window(10000).Property(%s)' % THEME_WANTED_PROPERTY): return False
		if not setting_bool('enabled', True) or not self.skin_active(): return False
		if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo) | Window.IsActive(videoosd) | Window.IsActive(visualisation) | Window.IsActive(videobookmarks)'): return False
		if not setting_bool('nightshift_only', False): return True
		if xbmc.getCondVisibility('Window.IsActive(home)'): return True
		return (xbmc.getInfoLabel('Container.FolderPath') or '').startswith(NIGHTSHIFT_PLUGIN)

	def about_to_play(self):
		"""Something is being opened or is already loaded (resolving a stream, buffering, a video starting): never start a track now."""
		try: return xbmc.getCondVisibility(BUSY_CONDITION)
		except Exception: return False

	def mark(self, on):
		if on == getattr(self, '_marked', None): return      # nothing changed: no call into the GUI
		try:
			win = xbmcgui.Window(10025)
			win.setProperty(PROP, 'true') if on else win.clearProperty(PROP)
			home = xbmcgui.Window(10000)
			if on and self.player.our_path:
				home.setProperty(AMBIENCE_FILE_PROPERTY, self.player.our_path)
			else:
				home.clearProperty(AMBIENCE_FILE_PROPERTY)
			self._marked = on
		except Exception as error:
			log('could not publish ambience player state: %s' % error)

	def waiting_for_pack(self):
		"""True while the built-in pack is still arriving (a first start, or Kodi booting before the network is up).
		Until it is complete the draw would only see the few files that already exist and keep opening with the same one."""
		if builtin_audio.pack_ready() or not (setting_bool('builtin', True) or not self.extra_tracks()): return False
		age = time.monotonic() - self.born
		if age >= PACK_WAIT_MAX or (age >= PACK_WAIT and not builtin_audio.installing()): return False
		if not self.pack_wait_logged:
			self.pack_wait_logged = True
			log('waiting for the built-in track pack before the first track')
		return True

	def start(self):
		# Retry a failed or interrupted download on a later idle poll. The player
		# still cannot see individual files until the complete pack is verified.
		if not builtin_audio.pack_ready():
			builtin_audio.ensure_async(notify=False)
		if self.player.isPlaying() or self.about_to_play():
			self.resume_at = 2; return            # do not draw/consume a track while another player or theme handoff is active
		if self.waiting_for_pack():
			self.resume_at = 3; return            # the first track comes from the complete pack, not from the few files that exist before it
		path = self.track_path()
		if not path:
			self.resume_at = 10; return           # nothing is switched on; look again in a few seconds
		if not track_exists(path):
			log('missing track %s; removed from this shuffle-bag cycle' % path); self.bad_tracks += 1
			if self.bad_tracks > 50: self.resume_at = 30; self.bad_tracks = 0
			return
		self.last_track = path
		self.apply_ambience_volume()
		self.player.our_path = path
		self.mark(True)                       # set before playback so the now-playing bar never flashes
		self.player.real_playback = False
		item = xbmcgui.ListItem(path=path)
		self.player.play(path, item, windowed=True)
		self.bad_tracks = 0
		self.started_at = 3
		log('started %s' % os.path.basename(path))

	def stop(self):
		if self.player.is_ours():
			self.player.stop(); log('stopped ambience')
		self.restore_user_volume()
		self.player.our_path = ''
		self.mark(False)


	# --- ambience-only volume -------------------------------------------------------------------------------------
	# Kodi has one master volume, so the ambience level works by swapping: the user's volume is remembered when an
	# ambience track starts, the (quieter) ambience level is applied, and the user's volume comes back the moment
	# anything else plays or the ambience stops. Video / music playback therefore always runs at the normal volume.
	def target_volume(self):
		raw = skin_string('ns_ambience_volume')
		try: return max(0, min(100, int(raw)))
		except ValueError: return DEFAULT_VOLUME

	def get_volume(self):
		try:
			data = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Application.GetProperties', 'params': {'properties': ['volume']}})))
			return int(data['result']['volume'])
		except Exception: return None

	def set_volume(self, value):
		xbmc.executebuiltin('SetVolume(%d,false)' % int(value))

	def _saved_file(self):
		folder = xbmcvfs.translatePath('special://profile/addon_data/script.service.nightshift.ambience/')
		if not xbmcvfs.exists(folder): xbmcvfs.mkdirs(folder)
		return os.path.join(folder, 'user_volume.json')

	def apply_ambience_volume(self):
		target = self.target_volume()
		current = self.get_volume()
		if current is None: return
		if self.saved_volume is None:
			if current == target: return          # already at the ambience level, nothing to swap
			self.saved_volume = current
			try:
				with open(self._saved_file(), 'w') as handle: json.dump({'volume': current}, handle)
			except Exception: pass
		elif self.applied_volume is not None and current != self.applied_volume:
			# the user turned the volume while ambience played: that is their volume now, leave it alone
			self.saved_volume = None
			self.applied_volume = None
			self.forget_saved()
			return
		if current != target:
			self.set_volume(target)
		self.applied_volume = target

	def forget_saved(self):
		try: os.remove(self._saved_file())
		except Exception: pass

	def restore_user_volume(self):
		if self.saved_volume is None: return
		value = self.saved_volume
		self.saved_volume = None
		self.applied_volume = None
		self.set_volume(value)
		self.forget_saved()
		log('volume back to %d%%' % value)

	def restore_after_crash(self):
		try:
			with open(self._saved_file()) as handle: value = int(json.load(handle)['volume'])
			self.set_volume(value); log('volume restored to %d%% (left over from an earlier session)' % value)
		except Exception: pass
		self.forget_saved()

	def watch_volume(self):
		"""The slider in the skin settings: follow it live while an ambience track plays."""
		if self.saved_volume is None and not self.player.is_ours(): return
		target = self.target_volume()
		if self.applied_volume is not None and target != self.applied_volume:
			current = self.get_volume()
			if current == self.applied_volume:
				self.set_volume(target)
				self.applied_volume = target

	# --- random Home backgrounds ------------------------------------------------------------------------------------
	def background_pool(self):
		pool = []
		try: files = xbmcvfs.listdir(BG_DIR)[1]
		except Exception: files = []
		for name in sorted(files):
			stem, ext = os.path.splitext(name)
			if ext.lower() not in ('.jpg', '.jpeg', '.png') or stem in BG_SKIP: continue
			if xbmc.getCondVisibility('Skin.HasSetting(ns_hide_bg_%s)' % stem): continue    # switched off in the skin settings
			pool.append(BG_DIR + name)
		return pool

	def pick_background(self):
		"""A new image for every menu position: secrets.choice, never the same one twice in a row."""
		pool = self.background_pool()
		home = xbmcgui.Window(10000)
		if not pool:
			home.clearProperty(BG_PROP); return
		current = home.getProperty(BG_PROP)
		choices = [p for p in pool if p != current] or pool
		home.setProperty(BG_PROP, secrets.choice(choices))

	def background_key(self):
		if xbmc.getCondVisibility('Skin.HasSetting(ns_bg_fixed)') or not xbmc.getCondVisibility('Window.IsActive(home)'):
			return None
		return '|'.join((xbmc.getInfoLabel('Window(Home).Property(Nightshift.Section)'),
			xbmc.getInfoLabel('Container(9000).CurrentItem'), xbmc.getInfoLabel('Container(9200).CurrentItem')))

	def background_loop(self):
		last = object()
		flip_path = None
		skin_ok = False
		skin_checked = 0.0
		while not self.abortRequested():
			# While anything real plays (a video above all) this thread asks Kodi for nothing at all: every call below
			# takes the GUI lock, and on a small device that lock is what the video renderer needs.
			if self.quiet or self.player.real_playback:
				if self.waitForAbort(QUIET_POLL): break
				continue
			delay = 0.5
			now = time.monotonic()
			if now - skin_checked > 2.0:
				skin_ok = self.skin_active(); skin_checked = now
			if skin_ok:
				try:
					# watched-icon mix: eyes / red diamond are told apart by row parity; a secrets coin flip, re-rolled for every folder you open, decides which parity gets which
					here = xbmc.getInfoLabel('Container.FolderPath') or ''
					if here != flip_path or not xbmcgui.Window(10000).getProperty('NSWFLIP'):
						xbmcgui.Window(10000).setProperty('NSWFLIP', secrets.choice(('0', '1'))); flip_path = here
				except Exception as e: log('watched-icon flip error: %s' % e)
				try:
					key = self.background_key()
					if key is None:
						if last is not None: xbmcgui.Window(10000).clearProperty(BG_PROP)
						last = None
					else:
						delay = 0.15            # on the Home screen: follow the menu quickly
						if key != last or not xbmcgui.Window(10000).getProperty(BG_PROP):
							self.pick_background(); last = key
				except Exception as e: log('background error: %s' % e)
			else:
				last = object()
			if self.waitForAbort(delay): break

	def tick(self):
		playing = self.player.isPlaying()
		if playing and self.quiet and self.player.real_playback:
			return                    # real playback was already dealt with: stay completely out of Kodi's way
		ours = self.player.is_ours()
		self.watch_volume()
		if playing and not ours:
			# real playback: never touch it, drop our marker, remember to restart later
			self.restore_user_volume()
			self.player.real_playback = True
			self.player.our_path = ''
			self.mark(False)
			self.resume_at = RESTART_DELAY
			self.bad_polls = 0
			self.allowed_streak = 0
			self.quiet = True
			return
		self.quiet = False
		if self.player.real_playback and not playing:
			self.player.real_playback = False
			self.resume_at = RESTART_DELAY
		if self.resume_at > 0:
			self.resume_at -= 1
			return
		allowed = self.menus_allowed()
		if ours:
			self.bad_polls = 0 if allowed else self.bad_polls + 1
			if self.bad_polls >= GRACE_POLLS: self.stop(); self.bad_polls = 0
			return
		if not playing:
			self.mark(False)
			if not allowed:
				self.allowed_streak = 0
				self.restore_user_volume()
			else:
				# the menus must have been allowed for a moment: a video that is being opened is not "playing" yet
				self.allowed_streak += 1
				if self.allowed_streak >= START_SETTLE: self.start()

	def onAbortRequested(self):
		self.player.dead = True

	def onSettingsChanged(self):
		self.playlist = []            # rebuild the remaining no-repeat bag after a setting/folder change
		self.rotation_has_tracks = False
		self.folders_stamp = None
		if self.player.is_ours():
			playing = self.player.our_path
			if not self.menus_allowed() or (playing and playing not in self.current_rotation()): self.stop()   # also when its own switch was turned off

	def check_addon_updates(self):
		"""The skin's Add-ons screen (sidebar > Check updates) picks how often the repositories are checked: every 1 / 6 / 12 / 24 hours or
		every week. 0 or nothing chosen leaves it to Kodi."""
		try: hours = int(xbmc.getInfoLabel('Skin.String(ns_addon_check_hours)') or 0)
		except ValueError: hours = 0
		now = time.time()
		if hours <= 0:
			self.update_check_at = None
			return
		if getattr(self, 'update_check_at', None) is None or getattr(self, 'update_check_hours', 0) != hours:
			self.update_check_at, self.update_check_hours = now, hours       # counted from when it was chosen / Kodi started
			return
		if now - self.update_check_at >= hours * 3600:
			self.update_check_at = now
			xbmc.executebuiltin('UpdateAddonRepos', False)
			log('add-on update check (every %d h)' % hours)

	def run(self):
		log('service started')
		builtin_audio.ensure_async()             # downloads the built-in tracks the first time (or when some are missing)
		self.restore_after_crash()
		self.player.on_real = self.restore_user_volume
		threading.Thread(target=self.background_loop, daemon=True).start()
		while not self.abortRequested():
			try: self.tick()
			except Exception as e: log('tick error: %s' % e)
			try: self.check_addon_updates()
			except Exception as e: log('update check error: %s' % e)
			if self.waitForAbort(QUIET_POLL if self.quiet else 1): break
		self.player.dead = True
		# Shutting down (Kodi quitting, or the add-on being disabled while a track plays). Kodi waits for this script to
		# end, so nothing below may wait for Kodi in return (Player.stop(), JSON-RPC and window-property calls all do,
		# which froze Kodi until it killed the script). Only queued built-ins are used here; they run after we are gone.
		try:
			if self.player.our_path: xbmc.executebuiltin('PlayerControl(Stop)', False)
			if self.saved_volume is not None:
				xbmc.executebuiltin('SetVolume(%d,false)' % int(self.saved_volume), False)
				self.saved_volume = None
				self.forget_saved()
			xbmc.executebuiltin('ClearProperty(%s,10025)' % PROP, False)
			xbmc.executebuiltin('ClearProperty(%s,10000)' % AMBIENCE_FILE_PROPERTY, False)
		except Exception: pass
		log('service stopped')

if __name__ == '__main__':
	Ambience().run()
