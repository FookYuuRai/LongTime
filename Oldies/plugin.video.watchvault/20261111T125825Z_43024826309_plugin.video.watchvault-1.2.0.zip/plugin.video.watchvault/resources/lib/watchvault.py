# -*- coding: utf-8 -*-
"""WatchVault core: a local watch-history database plus a small API that other
Kodi add-ons can call. Works inside Kodi and (for testing) outside it.

Identity rules
  * TV episodes are stored under their show (tvdb id preferred, title+year as
    fallback) as season / episode.  Season 0 = specials (TVDB aired order).
  * Movies are stored by tvdb id (imdb / tmdb optional) or title+year.
Nothing in here talks to the internet.
"""
import json
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime

ADDON_ID = 'plugin.video.watchvault'
FORMAT = 'watchvault'
FORMAT_VERSION = 1
CHANGE_LOG_LIMIT = 5000

SCHEMA = """
CREATE TABLE IF NOT EXISTS shows(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tvdb_id INTEGER UNIQUE, imdb_id TEXT, tmdb_id INTEGER,
  anilist_id INTEGER, mal_id INTEGER,
  title TEXT NOT NULL, year INTEGER, created TEXT);
CREATE INDEX IF NOT EXISTS ix_shows_title ON shows(title COLLATE NOCASE);
CREATE TABLE IF NOT EXISTS episodes(
  show_id INTEGER NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
  season INTEGER NOT NULL, episode INTEGER NOT NULL,
  tvdb_id INTEGER, imdb_id TEXT, tmdb_id INTEGER, anilist_id INTEGER, mal_id INTEGER,
  title TEXT, aired TEXT,
  watched INTEGER NOT NULL DEFAULT 0,
  play_count INTEGER NOT NULL DEFAULT 0,
  last_watched TEXT,
  runtime INTEGER, remaining INTEGER,
  PRIMARY KEY(show_id, season, episode));
CREATE TABLE IF NOT EXISTS movies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tvdb_id INTEGER UNIQUE, imdb_id TEXT, tmdb_id INTEGER,
  anilist_id INTEGER, mal_id INTEGER,
  title TEXT NOT NULL, year INTEGER,
  watched INTEGER NOT NULL DEFAULT 0,
  play_count INTEGER NOT NULL DEFAULT 0,
  last_watched TEXT, created TEXT,
  runtime INTEGER, remaining INTEGER);
CREATE TABLE IF NOT EXISTS sources(
  addon_id TEXT PRIMARY KEY, name TEXT,
  enabled INTEGER NOT NULL DEFAULT 1,
  ack_seq INTEGER NOT NULL DEFAULT 0, added TEXT);
CREATE TABLE IF NOT EXISTS changes(
  seq INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, kind TEXT,
  title TEXT, year INTEGER, tvdb_id INTEGER, imdb_id TEXT, tmdb_id INTEGER,
  anilist_id INTEGER, mal_id INTEGER,
  season INTEGER, episode INTEGER, watched INTEGER, source TEXT,
  runtime INTEGER, remaining INTEGER,
  ep_tvdb_id INTEGER, ep_imdb_id TEXT, ep_tmdb_id INTEGER,
  ep_anilist_id INTEGER, ep_mal_id INTEGER);
"""


# ----------------------------------------------------------------- plumbing
def data_dir():
    env = os.environ.get('WATCHVAULT_DIR')
    if env:
        path = env
    else:
        try:
            import xbmcvfs
            path = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
        except ImportError:
            path = os.path.join(os.path.expanduser('~'), '.watchvault')
    os.makedirs(path, exist_ok=True)
    return path


def db_path():
    return os.path.join(data_dir(), 'watchvault.db')


def _init(con):
    if con.execute('PRAGMA user_version').fetchone()[0] < 1:
        con.executescript(SCHEMA)
        con.execute('PRAGMA user_version=1')
        con.commit()
    cols = [r[1] for r in con.execute('PRAGMA table_info(sources)')]
    legacy = 'cur' + 'sor'  # name used by 1.0 databases for the sync position
    if cols and legacy in cols and 'ack_seq' not in cols:
        con.execute('ALTER TABLE sources RENAME COLUMN %s TO ack_seq' % legacy)
        con.commit()
    for table, extra in (
            ('shows', (('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'))),
            ('movies', (('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'))),
            ('episodes', (('runtime', 'INTEGER'), ('remaining', 'INTEGER'),
                          ('imdb_id', 'TEXT'), ('tmdb_id', 'INTEGER'),
                          ('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'))),
            ('changes', (('runtime', 'INTEGER'), ('remaining', 'INTEGER'),
                         ('anilist_id', 'INTEGER'), ('mal_id', 'INTEGER'),
                         ('ep_tvdb_id', 'INTEGER'), ('ep_imdb_id', 'TEXT'),
                         ('ep_tmdb_id', 'INTEGER'), ('ep_anilist_id', 'INTEGER'),
                         ('ep_mal_id', 'INTEGER')))):
        have = {r[1] for r in con.execute('PRAGMA table_info(%s)' % table)}
        for name, decl in extra:
            if name not in have:
                con.execute('ALTER TABLE %s ADD COLUMN %s %s' % (table, name, decl))
        con.commit()
    for stmt in (
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_shows_anilist ON shows(anilist_id) WHERE anilist_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_shows_mal ON shows(mal_id) WHERE mal_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_movies_anilist ON movies(anilist_id) WHERE anilist_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_movies_mal ON movies(mal_id) WHERE mal_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_tvdb ON episodes(tvdb_id) WHERE tvdb_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_imdb ON episodes(imdb_id) WHERE imdb_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_tmdb ON episodes(tmdb_id) WHERE tmdb_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_anilist ON episodes(anilist_id) WHERE anilist_id IS NOT NULL',
            'CREATE UNIQUE INDEX IF NOT EXISTS ix_eps_mal ON episodes(mal_id) WHERE mal_id IS NOT NULL'):
        try:
            con.execute(stmt)
        except sqlite3.Error:
            pass
    con.commit()


def connect(path=None):
    con = sqlite3.connect(path or db_path(), timeout=15)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    _init(con)
    return con


@contextmanager
def db(path=None):
    con = connect(path)
    try:
        with con:
            yield con
    finally:
        con.close()


def _now():
    return datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')


def _secs(v):
    """Seconds for runtime or time remaining. Empty stays empty. Negatives are dropped."""
    if v is None or v == '' or isinstance(v, bool):
        return None
    try:
        n = int(round(float(v)))
    except (TypeError, ValueError):
        return None
    if n < 0:
        return None
    return n


def _col(row, name):
    return row[name] if name in row.keys() else None


def _int(v):
    try:
        if v is None or v == '' or isinstance(v, bool):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


def _id(v):
    i = _int(v)
    return i if i and i > 0 else None


def _txt(v):
    v = (v or '').strip() if isinstance(v, str) else v
    return v or None


def _split_title(title):
    title = (title or '').strip()
    m = re.match(r'^(.*?)\s*\((\d{4})\)\s*$', title)
    if m and m.group(1):
        return m.group(1).strip(), int(m.group(2))
    return title, None


def _sort_title(t):
    t = (t or '').lower()
    return re.sub(r'^(the|a|an)\s+', '', t)


def _notify(message, data=None):
    try:
        import xbmc
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
            'params': {'sender': ADDON_ID, 'message': message, 'data': data or {}}}))
    except Exception:
        pass


def _log_change(con, kind, title=None, year=None, tvdb_id=None, imdb_id=None,
                tmdb_id=None, season=None, episode=None, watched=None, source=None,
                runtime=None, remaining=None, anilist_id=None, mal_id=None, ep_ids=None):
    ep_ids = ep_ids or {}
    cur = con.execute(
        'INSERT INTO changes(ts,kind,title,year,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
        'season,episode,watched,source,runtime,remaining,ep_tvdb_id,ep_imdb_id,ep_tmdb_id,ep_anilist_id,ep_mal_id)'
        ' VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        (_now(), kind, title, year, _id(tvdb_id), _txt(imdb_id), _id(tmdb_id), _id(anilist_id), _id(mal_id),
         season, episode, None if watched is None else int(bool(watched)), source,
         _secs(runtime), _secs(remaining),
         ep_ids.get('tvdb_id'), ep_ids.get('imdb_id'), ep_ids.get('tmdb_id'),
         ep_ids.get('anilist_id'), ep_ids.get('mal_id')))
    seq = cur.lastrowid
    con.execute('DELETE FROM changes WHERE seq <= ?', (seq - CHANGE_LOG_LIMIT,))
    return seq


# ------------------------------------------------------------ identity lookup
_ID_KEYS = ('tvdb_id', 'imdb_id', 'tmdb_id', 'anilist_id', 'mal_id')


def _media_ids(tvdb_id=None, imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None):
    return {
        'tvdb_id': _id(tvdb_id),
        'imdb_id': _txt(imdb_id),
        'tmdb_id': _id(tmdb_id),
        'anilist_id': _id(anilist_id),
        'mal_id': _id(mal_id),
    }


def _known(ids):
    return any(ids.values())


def _fallback_title(ids, movie=False):
    if ids.get('tvdb_id'):
        return 'TVDB %s' % ids['tvdb_id']
    if ids.get('imdb_id'):
        return ids['imdb_id']
    if ids.get('tmdb_id'):
        return 'TMDB %s' % ids['tmdb_id']
    if ids.get('anilist_id'):
        return 'AniList %s' % ids['anilist_id']
    if ids.get('mal_id'):
        return 'MAL %s' % ids['mal_id']
    return 'Unknown movie' if movie else 'Unknown show'


def _lookup(con, table, ids):
    for key in _ID_KEYS:
        if ids.get(key):
            row = con.execute('SELECT * FROM %s WHERE %s=?' % (table, key), (ids[key],)).fetchone()
            if row:
                return row
    return None


def _attach(con, table, row, ids, year=None):
    sets, args = [], []
    for key in _ID_KEYS:
        val = ids.get(key)
        if val and not row[key]:
            other = con.execute(
                'SELECT id FROM %s WHERE %s=? AND id!=?' % (table, key), (val, row['id'])).fetchone()
            if other:
                continue
            sets.append(key + '=?')
            args.append(val)
    if year and not row['year']:
        sets.append('year=?')
        args.append(year)
    if sets:
        con.execute('UPDATE %s SET %s WHERE id=?' % (table, ','.join(sets)), args + [row['id']])


def _title_match(con, table, title, year, ids):
    for row in con.execute('SELECT * FROM %s WHERE lower(title)=lower(?)' % table, (title,)):
        if year and row['year'] and row['year'] != year:
            continue
        clash = False
        for key in _ID_KEYS:
            if ids.get(key) and row[key] and row[key] != ids[key]:
                clash = True
                break
        if not clash:
            return row
    return None


def _show_row(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
              anilist_id=None, mal_id=None):
    title, y2 = _split_title(title)
    year = _id(year) or y2
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    row = _lookup(con, 'shows', ids)
    if row:
        return row
    if title:
        return _title_match(con, 'shows', title, year, ids)
    return None


def _show_id(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
             anilist_id=None, mal_id=None, create=True):
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    row = _show_row(con, title, year, **ids)
    title, y2 = _split_title(title)
    year = _id(year) or y2
    if row:
        _attach(con, 'shows', row, ids, year)
        return row['id']
    if not create:
        return None
    title = title or _fallback_title(ids)
    cur = con.execute(
        'INSERT INTO shows(tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,title,year,created)'
        ' VALUES(?,?,?,?,?,?,?,?)',
        (ids['tvdb_id'], ids['imdb_id'], ids['tmdb_id'], ids['anilist_id'], ids['mal_id'],
         title, year, _now()))
    return cur.lastrowid


def _movie_row(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
               anilist_id=None, mal_id=None):
    title, y2 = _split_title(title)
    year = _id(year) or y2
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    row = _lookup(con, 'movies', ids)
    if row:
        return row
    if title:
        return _title_match(con, 'movies', title, year, ids)
    return None


def _movie_id(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
              anilist_id=None, mal_id=None, create=True):
    ids = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    row = _movie_row(con, title, year, **ids)
    title, y2 = _split_title(title)
    year = _id(year) or y2
    if row:
        _attach(con, 'movies', row, ids, year)
        return row['id']
    if not create:
        return None
    title = title or _fallback_title(ids, movie=True)
    cur = con.execute(
        'INSERT INTO movies(tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,title,year,created)'
        ' VALUES(?,?,?,?,?,?,?,?)',
        (ids['tvdb_id'], ids['imdb_id'], ids['tmdb_id'], ids['anilist_id'], ids['mal_id'],
         title, year, _now()))
    return cur.lastrowid


def _resolve_episode(con, title, year, series_ids, season, episode, ep_ids, create=True):
    """One episode row for every id that points at the same file."""
    hit = _lookup(con, 'episodes', ep_ids)
    if hit:
        show = con.execute('SELECT * FROM shows WHERE id=?', (hit['show_id'],)).fetchone()
        if show:
            _attach(con, 'shows', show, series_ids, _id(year))
        return hit['show_id'], hit['season'], hit['episode']
    sid = _show_id(con, title, year, create=create, **series_ids)
    return sid, season, episode


def _write_episode(con, sid, season, episode, ep_ids, title, aired, mode, ts, runtime, remaining):
    ids = [ep_ids[k] for k in _ID_KEYS]
    base = [sid, season, episode] + ids + [_txt(title), _txt(aired)]
    if mode == 'watch':
        con.execute(
            'INSERT INTO episodes(show_id,season,episode,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
            'title,aired,watched,play_count,last_watched,runtime,remaining)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,1,1,?,?,?)'
            ' ON CONFLICT(show_id,season,episode) DO UPDATE SET'
            ' watched=1, play_count=episodes.play_count+1, last_watched=excluded.last_watched,'
            ' tvdb_id=COALESCE(episodes.tvdb_id,excluded.tvdb_id),'
            ' imdb_id=COALESCE(episodes.imdb_id,excluded.imdb_id),'
            ' tmdb_id=COALESCE(episodes.tmdb_id,excluded.tmdb_id),'
            ' anilist_id=COALESCE(episodes.anilist_id,excluded.anilist_id),'
            ' mal_id=COALESCE(episodes.mal_id,excluded.mal_id),'
            ' title=COALESCE(excluded.title,episodes.title),'
            ' aired=COALESCE(excluded.aired,episodes.aired),'
            ' runtime=COALESCE(excluded.runtime,episodes.runtime),'
            ' remaining=COALESCE(excluded.remaining,episodes.remaining)',
            base + [ts, runtime, remaining])
    elif mode == 'unwatch':
        con.execute(
            'INSERT INTO episodes(show_id,season,episode,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
            'title,aired,watched,play_count,runtime,remaining)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,0,0,?,?)'
            ' ON CONFLICT(show_id,season,episode) DO UPDATE SET'
            ' watched=0, play_count=0, last_watched=NULL, remaining=NULL,'
            ' tvdb_id=COALESCE(episodes.tvdb_id,excluded.tvdb_id),'
            ' imdb_id=COALESCE(episodes.imdb_id,excluded.imdb_id),'
            ' tmdb_id=COALESCE(episodes.tmdb_id,excluded.tmdb_id),'
            ' anilist_id=COALESCE(episodes.anilist_id,excluded.anilist_id),'
            ' mal_id=COALESCE(episodes.mal_id,excluded.mal_id),'
            ' title=COALESCE(excluded.title,episodes.title),'
            ' aired=COALESCE(excluded.aired,episodes.aired),'
            ' runtime=COALESCE(excluded.runtime,episodes.runtime)',
            base + [runtime, None])
    else:
        con.execute(
            'INSERT INTO episodes(show_id,season,episode,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,'
            'title,aired,watched,play_count,runtime,remaining)'
            ' VALUES(?,?,?,?,?,?,?,?,?,?,0,0,?,?)'
            ' ON CONFLICT(show_id,season,episode) DO UPDATE SET'
            ' tvdb_id=COALESCE(episodes.tvdb_id,excluded.tvdb_id),'
            ' imdb_id=COALESCE(episodes.imdb_id,excluded.imdb_id),'
            ' tmdb_id=COALESCE(episodes.tmdb_id,excluded.tmdb_id),'
            ' anilist_id=COALESCE(episodes.anilist_id,excluded.anilist_id),'
            ' mal_id=COALESCE(episodes.mal_id,excluded.mal_id),'
            ' title=COALESCE(excluded.title,episodes.title),'
            ' aired=COALESCE(excluded.aired,episodes.aired),'
            ' runtime=COALESCE(excluded.runtime,episodes.runtime),'
            ' remaining=COALESCE(excluded.remaining,episodes.remaining)',
            base + [runtime, remaining])


def _episode_ids_of(row):
    return {key: row[key] for key in _ID_KEYS}


# ------------------------------------------------------------------ public API
def _caller_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
                episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id):
    series = _media_ids(tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id)
    episode = _media_ids(episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    return series, episode


def _has_name(title, series):
    return bool(_txt(title) or _known(series))


def mark_watched(title=None, year=None, season=None, episode=None, tvdb_id=None,
                 imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None, watched=True, source=None,
                 played_at=None, episode_title=None, aired=None,
                 episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
                 episode_anilist_id=None, episode_mal_id=None,
                 notify=True, runtime=None, remaining=None):
    """Add an episode to watch history (season+episode given) or a movie as watched/unwatched.
    Any of TVDB, IMDb, TMDB, AniList or MAL identifies the same show, movie or episode file.
    runtime and remaining are seconds, used to resume playback.
    """
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    is_ep = (season is not None and episode is not None) or _known(ep_ids)
    if not _has_name(title, series) and not _known(ep_ids):
        return {'ok': False, 'error': 'need a title or an id'}
    ts = played_at or _now()
    watched = bool(watched)
    runtime, remaining = _secs(runtime), _secs(remaining)
    with db() as con:
        if is_ep:
            sid, season, episode = _resolve_episode(con, title, year, series, season, episode, ep_ids)
            if not sid or season is None or episode is None:
                return {'ok': False, 'error': 'need a season and episode'}
            _write_episode(con, sid, season, episode, ep_ids, episode_title, aired,
                           'watch' if watched else 'unwatch', ts, runtime, remaining)
            s = con.execute('SELECT * FROM shows WHERE id=?', (sid,)).fetchone()
            row = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
            seq = _log_change(con, 'episode', s['title'], s['year'], s['tvdb_id'], s['imdb_id'],
                              s['tmdb_id'], season, episode, watched, source, runtime,
                              remaining if watched else None, s['anilist_id'], s['mal_id'],
                              _episode_ids_of(row))
        else:
            mid = _movie_id(con, title, year, **series)
            if watched:
                con.execute(
                    'UPDATE movies SET watched=1, play_count=play_count+1, last_watched=?,'
                    ' runtime=COALESCE(?, runtime), remaining=COALESCE(?, remaining) WHERE id=?',
                    (ts, runtime, remaining, mid))
            else:
                con.execute(
                    'UPDATE movies SET watched=0, play_count=0, last_watched=NULL, remaining=NULL,'
                    ' runtime=COALESCE(?, runtime) WHERE id=?', (runtime, mid))
            m = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
            seq = _log_change(con, 'movie', m['title'], m['year'], m['tvdb_id'], m['imdb_id'],
                              m['tmdb_id'], None, None, watched, source, runtime,
                              remaining if watched else None, m['anilist_id'], m['mal_id'])
    if notify:
        _notify('changed', {'seq': seq, 'source': source})
    return {'ok': True, 'seq': seq}


def mark_unwatched(**kw):
    kw['watched'] = False
    return mark_watched(**kw)


def save_progress(title=None, year=None, season=None, episode=None, tvdb_id=None,
                  imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None, source=None,
                  episode_title=None, aired=None, episode_tvdb_id=None, episode_imdb_id=None,
                  episode_tmdb_id=None, episode_anilist_id=None, episode_mal_id=None,
                  runtime=None, remaining=None, notify=True):
    """Store runtime and time remaining without changing the watched flag or play count.
    Both values are seconds. Used when playback stops before it counts as watched.
    """
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    is_ep = (season is not None and episode is not None) or _known(ep_ids)
    if not _has_name(title, series) and not _known(ep_ids):
        return {'ok': False, 'error': 'need a title or an id'}
    runtime, remaining = _secs(runtime), _secs(remaining)
    if runtime is None and remaining is None:
        return {'ok': False, 'error': 'need a runtime or time remaining'}
    if runtime is not None and remaining is not None and remaining > runtime:
        remaining = runtime
    with db() as con:
        if is_ep:
            sid, season, episode = _resolve_episode(con, title, year, series, season, episode, ep_ids)
            if not sid or season is None or episode is None:
                return {'ok': False, 'error': 'need a season and episode'}
            _write_episode(con, sid, season, episode, ep_ids, episode_title, aired,
                           'progress', None, runtime, remaining)
            s = con.execute('SELECT * FROM shows WHERE id=?', (sid,)).fetchone()
            row = con.execute(
                'SELECT * FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
            seq = _log_change(con, 'episode', s['title'], s['year'], s['tvdb_id'], s['imdb_id'],
                              s['tmdb_id'], season, episode, row['watched'], source,
                              row['runtime'], row['remaining'], s['anilist_id'], s['mal_id'],
                              _episode_ids_of(row))
        else:
            mid = _movie_id(con, title, year, **series)
            con.execute(
                'UPDATE movies SET runtime=COALESCE(?, runtime), remaining=COALESCE(?, remaining) WHERE id=?',
                (runtime, remaining, mid))
            m = con.execute('SELECT * FROM movies WHERE id=?', (mid,)).fetchone()
            seq = _log_change(con, 'movie', m['title'], m['year'], m['tvdb_id'], m['imdb_id'],
                              m['tmdb_id'], None, None, m['watched'], source, m['runtime'], m['remaining'],
                              m['anilist_id'], m['mal_id'])
    if notify:
        _notify('changed', {'seq': seq, 'source': source})
    return {'ok': True, 'seq': seq, 'runtime': runtime, 'remaining': remaining}


def _resume_dict(row):
    if not row:
        return None
    runtime, remaining = row['runtime'], row['remaining']
    position = None
    if runtime is not None and remaining is not None and remaining <= runtime:
        position = runtime - remaining
    return {'runtime': runtime, 'remaining': remaining, 'position': position,
            'watched': bool(row['watched'])}


def get_resume(season=None, episode=None, tvdb_id=None, title=None, year=None,
               imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None,
               episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
               episode_anilist_id=None, episode_mal_id=None):
    """Runtime, time remaining, and resume position in seconds. None if unknown."""
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    with db() as con:
        if (season is not None and episode is not None) or _known(ep_ids):
            sid, season, episode = _resolve_episode(con, title, year, series, season, episode, ep_ids, create=False)
            if not sid or season is None or episode is None:
                return None
            row = con.execute(
                'SELECT runtime, remaining, watched FROM episodes WHERE show_id=? AND season=? AND episode=?',
                (sid, season, episode)).fetchone()
        else:
            mid = _movie_id(con, title, year, create=False, **series)
            if not mid:
                return None
            row = con.execute('SELECT runtime, remaining, watched FROM movies WHERE id=?', (mid,)).fetchone()
    return _resume_dict(row)


def watched_episodes(tvdb_id=None, title=None, year=None, imdb_id=None, tmdb_id=None,
                     anilist_id=None, mal_id=None):
    """-> {season: [episode, ...]} of watched episodes for one show (sorted)."""
    with db() as con:
        sid = _show_id(con, title, year, tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id, create=False)
        out = {}
        if sid:
            for r in con.execute('SELECT season,episode FROM episodes WHERE show_id=? AND watched=1'
                                 ' ORDER BY season,episode', (sid,)):
                out.setdefault(r['season'], []).append(r['episode'])
        return out


def is_watched(season=None, episode=None, tvdb_id=None, title=None, year=None,
               imdb_id=None, tmdb_id=None, anilist_id=None, mal_id=None,
               episode_tvdb_id=None, episode_imdb_id=None, episode_tmdb_id=None,
               episode_anilist_id=None, episode_mal_id=None):
    """Episode check when season+episode or an episode id is given, otherwise a movie check."""
    season, episode = _int(season), _int(episode)
    series, ep_ids = _caller_ids(
        tvdb_id, imdb_id, tmdb_id, anilist_id, mal_id,
        episode_tvdb_id, episode_imdb_id, episode_tmdb_id, episode_anilist_id, episode_mal_id)
    with db() as con:
        if (season is not None and episode is not None) or _known(ep_ids):
            sid, season, episode = _resolve_episode(con, title, year, series, season, episode, ep_ids, create=False)
            if not sid or season is None or episode is None:
                return False
            row = con.execute('SELECT watched FROM episodes WHERE show_id=? AND season=? AND episode=?',
                              (sid, season, episode)).fetchone()
            return bool(row and row['watched'])
        mid = _movie_id(con, title, year, create=False, **series)
        if not mid:
            return False
        return bool(con.execute('SELECT watched FROM movies WHERE id=?', (mid,)).fetchone()['watched'])


def watched_movies():
    with db() as con:
        return [dict(r) for r in con.execute(
            'SELECT title,year,tvdb_id,imdb_id,tmdb_id,anilist_id,mal_id,play_count,last_watched,'
            ' runtime,remaining FROM movies WHERE watched=1 ORDER BY lower(title)')]


def last_seq():
    with db() as con:
        return con.execute('SELECT COALESCE(MAX(seq),0) FROM changes').fetchone()[0]


def get_changes(since=0, limit=2000, exclude_source=None):
    with db() as con:
        rows = [dict(r) for r in con.execute(
            'SELECT * FROM changes WHERE seq>? ORDER BY seq LIMIT ?', (_int(since) or 0, limit))]
    if exclude_source:
        rows = [r for r in rows if r['source'] != exclude_source]
    return rows


def _full_marker(seq):
    return {'seq': seq, 'ts': _now(), 'kind': 'full', 'title': None, 'year': None,
            'tvdb_id': None, 'imdb_id': None, 'tmdb_id': None, 'anilist_id': None, 'mal_id': None,
            'season': None, 'episode': None, 'watched': None, 'source': None,
            'runtime': None, 'remaining': None, 'ep_tvdb_id': None, 'ep_imdb_id': None,
            'ep_tmdb_id': None, 'ep_anilist_id': None, 'ep_mal_id': None}


def pull_changes(addon_id, ack=True):
    """Everything that changed since this add-on last pulled (its own changes
    excluded).  A row with kind == 'full' means: do a full resync with
    get_clean_list().  A new source (ack_seq below 0), a wiped add-on, a gap in
    the change log, or a full wipe of watch history returns that one marker.
    """
    with db() as con:
        src = con.execute('SELECT * FROM sources WHERE addon_id=?', (addon_id,)).fetchone()
        ack_seq = src['ack_seq'] if src else 0
        max_seq = con.execute('SELECT COALESCE(MAX(seq),0) FROM changes').fetchone()[0]
        needs_full = bool(src) and ack_seq < 0
        if not needs_full:
            min_seq = con.execute('SELECT MIN(seq) FROM changes').fetchone()[0]
            if ack_seq > max_seq:
                needs_full = True
            elif min_seq is not None and ack_seq >= 0 and min_seq > ack_seq + 1:
                needs_full = True
            elif con.execute("SELECT 1 FROM changes WHERE seq>? AND kind='full' LIMIT 1",
                             (ack_seq,)).fetchone():
                needs_full = True
        if needs_full:
            if ack and src:
                con.execute('UPDATE sources SET ack_seq=? WHERE addon_id=?', (max_seq, addon_id))
            return [_full_marker(max_seq)]
        rows = [dict(r) for r in con.execute(
            'SELECT * FROM changes WHERE seq>? ORDER BY seq', (ack_seq,))]
        if ack and src and rows:
            con.execute('UPDATE sources SET ack_seq=? WHERE addon_id=?', (rows[-1]['seq'], addon_id))
    return [r for r in rows if r['source'] != addon_id]


# --------------------------------------------------------------------- sources
def add_source(addon_id, name=None):
    with db() as con:
        seq = con.execute('SELECT COALESCE(MAX(seq),0) FROM changes').fetchone()[0]
        # ack_seq -1: this source has never pulled, so the next pull is a full sync
        con.execute('INSERT OR IGNORE INTO sources(addon_id,name,enabled,ack_seq,added) VALUES(?,?,1,-1,?)',
                    (addon_id, name or addon_id, _now()))
        con.execute('UPDATE sources SET enabled=1, name=COALESCE(?,name) WHERE addon_id=?', (name, addon_id))
    return seq


def remove_source(addon_id):
    with db() as con:
        con.execute('DELETE FROM sources WHERE addon_id=?', (addon_id,))


def set_source_enabled(addon_id, enabled):
    with db() as con:
        con.execute('UPDATE sources SET enabled=? WHERE addon_id=?', (int(bool(enabled)), addon_id))


def get_sources():
    with db() as con:
        return [dict(r) for r in con.execute('SELECT addon_id,name,enabled,added FROM sources ORDER BY lower(name)')]


def get_source(addon_id):
    if not addon_id:
        return None
    with db() as con:
        r = con.execute('SELECT addon_id,name,enabled,added FROM sources WHERE addon_id=?', (addon_id,)).fetchone()
        return dict(r) if r else None


# ------------------------------------------------------------- clean list/dump
def _dump(con, watched_only=False, compact=False, include_movies=True):
    shows = []
    for s in sorted(con.execute('SELECT * FROM shows'), key=lambda r: (_sort_title(r['title']), r['year'] or 0)):
        q = 'SELECT * FROM episodes WHERE show_id=?'
        if watched_only:
            q += ' AND watched=1'
        eps = list(con.execute(q + ' ORDER BY season, episode', (s['id'],)))  # season 0 (specials) first
        if watched_only and not eps:
            continue
        if compact:
            ep_out = ['S%02dE%02d' % (e['season'], e['episode']) for e in eps]
        else:
            ep_out = [{'season': e['season'], 'episode': e['episode'], 'title': e['title'],
                       'aired': e['aired'], 'tvdb_id': _col(e, 'tvdb_id'), 'imdb_id': _col(e, 'imdb_id'),
                       'tmdb_id': _col(e, 'tmdb_id'), 'anilist_id': _col(e, 'anilist_id'),
                       'mal_id': _col(e, 'mal_id'), 'watched': bool(e['watched']),
                       'play_count': e['play_count'], 'last_watched': e['last_watched'],
                       'runtime': _col(e, 'runtime'), 'remaining': _col(e, 'remaining')} for e in eps]
        shows.append({'title': s['title'], 'year': s['year'], 'tvdb_id': s['tvdb_id'],
                      'imdb_id': s['imdb_id'], 'tmdb_id': s['tmdb_id'],
                      'anilist_id': _col(s, 'anilist_id'), 'mal_id': _col(s, 'mal_id'),
                      'episodes': ep_out})
    movies = []
    if include_movies:
        q = 'SELECT * FROM movies' + (' WHERE watched=1' if watched_only else '')
        for m in sorted(con.execute(q), key=lambda r: (_sort_title(r['title']), r['year'] or 0)):
            movies.append({'title': m['title'], 'year': m['year'], 'tvdb_id': m['tvdb_id'],
                           'imdb_id': m['imdb_id'], 'tmdb_id': m['tmdb_id'],
                           'anilist_id': _col(m, 'anilist_id'), 'mal_id': _col(m, 'mal_id'),
                           'watched': bool(m['watched']), 'play_count': m['play_count'],
                           'last_watched': m['last_watched'],
                           'runtime': _col(m, 'runtime'), 'remaining': _col(m, 'remaining')})
    sources = [{'addon_id': r['addon_id'], 'name': r['name'], 'enabled': bool(r['enabled'])}
               for r in con.execute('SELECT * FROM sources ORDER BY lower(name)')]
    return {'format': FORMAT, 'version': FORMAT_VERSION, 'exported': _now(),
            'shows': shows, 'movies': movies, 'sources': sources}


def get_clean_list(watched_only=False, compact=False, include_movies=True):
    """Sorted list: show name, year, tvdb id, episodes (season 0 specials first,
    then season 1, 2 ... each in aired/episode order).  compact=True gives
    episodes as 'S01E02' strings.  This is what helper scripts sync from."""
    with db() as con:
        return _dump(con, watched_only, compact, include_movies)


def _parse_ep(e):
    if isinstance(e, str):
        m = re.match(r'^\s*s(\d+)\s*e(\d+)\s*$', e, re.I)
        if not m:
            return None
        return {'season': int(m.group(1)), 'episode': int(m.group(2)), 'watched': True}
    if isinstance(e, dict) and _int(e.get('season')) is not None and _int(e.get('episode')) is not None:
        return e
    return None


def _merge(con, data, replace=False):
    if not isinstance(data, dict):
        raise ValueError('not a WatchVault file')
    if 'shows' not in data and 'movies' not in data:
        raise ValueError('not a WatchVault file (no "shows" or "movies")')
    if 'shows' in data and not isinstance(data.get('shows'), list):
        raise ValueError('not a WatchVault file ("shows" must be a list)')
    if 'movies' in data and not isinstance(data.get('movies'), list):
        raise ValueError('not a WatchVault file ("movies" must be a list)')
    if replace:
        con.execute('DELETE FROM episodes')
        con.execute('DELETE FROM shows')
        con.execute('DELETE FROM movies')
    n_eps = n_movies = 0
    for s in data.get('shows') or []:
        if not isinstance(s, dict):
            continue
        if not (_txt(s.get('title')) or _known(_media_ids(
                s.get('tvdb_id'), s.get('imdb_id'), s.get('tmdb_id'), s.get('anilist_id'), s.get('mal_id')))):
            continue
        sid = _show_id(con, s.get('title'), s.get('year'), s.get('tvdb_id'), s.get('imdb_id'),
                       s.get('tmdb_id'), anilist_id=s.get('anilist_id'), mal_id=s.get('mal_id'))
        for raw in s.get('episodes') or []:
            e = _parse_ep(raw)
            if not e:
                continue
            if isinstance(raw, dict):
                w = 1 if raw.get('watched') else 0
            else:
                w = 1
            pc = _int(e.get('play_count')) or (1 if w else 0)
            ep_ids = _media_ids(e.get('tvdb_id'), e.get('imdb_id'), e.get('tmdb_id'),
                                e.get('anilist_id'), e.get('mal_id'))
            runtime, remaining = _secs(e.get('runtime')), _secs(e.get('remaining'))
            _write_episode(con, sid, int(e['season']), int(e['episode']), ep_ids, e.get('title'),
                           e.get('aired'), 'progress', None, runtime, remaining)
            con.execute(
                'UPDATE episodes SET watched=MAX(watched,?),'
                ' play_count=MAX(play_count,?),'
                ' last_watched=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>last_watched)'
                '  THEN ? ELSE last_watched END,'
                ' runtime=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched)'
                '  THEN COALESCE(?, runtime) ELSE COALESCE(runtime, ?) END,'
                ' remaining=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched)'
                '  THEN COALESCE(?, remaining) ELSE COALESCE(remaining, ?) END'
                ' WHERE show_id=? AND season=? AND episode=?',
                (w, pc, _txt(e.get('last_watched')) if w else None,
                 _txt(e.get('last_watched')) if w else None, _txt(e.get('last_watched')) if w else None,
                 _txt(e.get('last_watched')) if w else None, _txt(e.get('last_watched')) if w else None,
                 runtime, runtime,
                 _txt(e.get('last_watched')) if w else None, _txt(e.get('last_watched')) if w else None,
                 remaining, remaining, sid, int(e['season']), int(e['episode'])))
            n_eps += 1
    for m in data.get('movies') or []:
        if not isinstance(m, dict) or not (_txt(m.get('title')) or _known(_media_ids(
                m.get('tvdb_id'), m.get('imdb_id'), m.get('tmdb_id'), m.get('anilist_id'), m.get('mal_id')))):
            continue
        mid = _movie_id(con, m.get('title'), m.get('year'), m.get('tvdb_id'), m.get('imdb_id'),
                        m.get('tmdb_id'), anilist_id=m.get('anilist_id'), mal_id=m.get('mal_id'))
        w = 1 if m.get('watched', True) else 0
        pc = _int(m.get('play_count')) or (1 if w else 0)
        runtime, remaining = _secs(m.get('runtime')), _secs(m.get('remaining'))
        con.execute(
            'UPDATE movies SET watched=MAX(watched,?), play_count=MAX(play_count,?),'
            ' last_watched=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>last_watched) THEN ? ELSE last_watched END,'
            ' runtime=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched) THEN COALESCE(?, runtime) ELSE COALESCE(runtime, ?) END,'
            ' remaining=CASE WHEN ? IS NOT NULL AND (last_watched IS NULL OR ?>=last_watched) THEN COALESCE(?, remaining) ELSE COALESCE(remaining, ?) END'
            ' WHERE id=?',
            (w, pc, _txt(m.get('last_watched')), _txt(m.get('last_watched')), _txt(m.get('last_watched')),
             _txt(m.get('last_watched')), _txt(m.get('last_watched')), runtime, runtime,
             _txt(m.get('last_watched')), _txt(m.get('last_watched')), remaining, remaining, mid))
        n_movies += 1
    for src in data.get('sources') or []:
        if isinstance(src, dict) and _txt(src.get('addon_id')):
            con.execute('INSERT OR IGNORE INTO sources(addon_id,name,enabled,ack_seq,added) VALUES(?,?,?,0,?)',
                        (src['addon_id'], src.get('name') or src['addon_id'],
                         1 if src.get('enabled', True) else 0, _now()))
    _log_change(con, 'full')
    return {'episodes': n_eps, 'movies': n_movies}


def import_dict(data, replace=False):
    with db() as con:
        res = _merge(con, data, replace)
    _notify('changed', {'full': True})
    return res


# ---------------------------------------------------------- export / import
def export_json(path, watched_only=False):
    data = get_clean_list(watched_only=watched_only)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)
    return {'shows': len(data['shows']), 'movies': len(data['movies'])}


def import_json(path, replace=False):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return import_dict(data, replace)


def export_db(path):
    src = connect()
    try:
        if os.path.exists(path):
            os.remove(path)
        dst = sqlite3.connect(path)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def import_db(path, replace=False):
    raw = sqlite3.connect(path)
    raw.row_factory = sqlite3.Row
    try:
        tables = {r[0] for r in raw.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'shows', 'episodes', 'movies'} <= tables:
            raise ValueError('not a WatchVault database file')
        data = _dump(raw)
    finally:
        raw.close()
    return import_dict(data, replace)


def counts():
    with db() as con:
        return {
            'shows': con.execute('SELECT COUNT(*) FROM shows').fetchone()[0],
            'episodes': con.execute('SELECT COUNT(*) FROM episodes WHERE watched=1').fetchone()[0],
            'movies': con.execute('SELECT COUNT(*) FROM movies WHERE watched=1').fetchone()[0],
        }


def db_info():
    """Shows, every episode row, and the database file size in bytes."""
    path = db_path()
    size = os.path.getsize(path) if os.path.exists(path) else 0
    with db() as con:
        return {
            'shows': con.execute('SELECT COUNT(*) FROM shows').fetchone()[0],
            'episodes': con.execute('SELECT COUNT(*) FROM episodes').fetchone()[0],
            'watched_episodes': con.execute('SELECT COUNT(*) FROM episodes WHERE watched=1').fetchone()[0],
            'movies': con.execute('SELECT COUNT(*) FROM movies').fetchone()[0],
            'bytes': size,
        }


def purge_all():
    """Delete every show, episode and movie. Registered video add-ons stay."""
    with db() as con:
        con.execute('DELETE FROM episodes')
        con.execute('DELETE FROM shows')
        con.execute('DELETE FROM movies')
        _log_change(con, 'full')
    _notify('changed', {'full': True})
    return db_info()


def delete_show(show_id):
    with db() as con:
        con.execute('DELETE FROM shows WHERE id=?', (show_id,))
        _log_change(con, 'full')


def delete_movie(movie_id):
    with db() as con:
        con.execute('DELETE FROM movies WHERE id=?', (movie_id,))
        _log_change(con, 'full')


# ------------------------------------------------------- helper for add-ons
def announce(**info):
    """Call right before playback from a plugin so WatchVault knows exactly what
    is playing: title, year, season, episode, tvdb_id, imdb_id, tmdb_id, source."""
    try:
        import xbmcgui
        info['ts'] = time.time()
        xbmcgui.Window(10000).setProperty('watchvault.announce', json.dumps(info))
    except Exception:
        pass
