# -*- coding: utf-8 -*-
"""Optional TVDB episode lists (aired order, specials = season 0).

Runs only when the user has typed their own TVDB API key. No key is stored
here, and an empty key makes no network call.
"""
import json
import urllib.error
import urllib.parse
import urllib.request

import watchvault as wv

API = 'https://api4.thetvdb.com/v4'
_token = {}


def _req(path, token=None, data=None):
    headers = {'Accept': 'application/json', 'Content-Type': 'application/json',
               'User-Agent': 'WatchVault'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = urllib.request.Request(API + path, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        raise RuntimeError('TVDB request failed (%s)' % e.code)
    except urllib.error.URLError:
        raise RuntimeError('TVDB request failed')


def _login(key):
    key = (key or '').strip()
    if not key:
        raise RuntimeError('TVDB key is empty')
    if _token.get('key') != key:
        res = _req('/login', data={'apikey': key})
        token = ((res.get('data') or {}).get('token')) if isinstance(res, dict) else None
        if not token:
            raise RuntimeError('TVDB login failed')
        _token['key'] = key
        _token['token'] = token
    return _token['token']


def resolve_tvdb_id(key, title, year=None):
    if not (key or '').strip() or not (title or '').strip():
        return None
    tok = _login(key)
    q = '/search?type=series&query=' + urllib.parse.quote(title)
    if year:
        q += '&year=%s' % year
    res = _req(q, token=tok)
    for r in (res.get('data') or []) if isinstance(res, dict) else []:
        tid = r.get('tvdb_id') or str(r.get('id') or '').replace('series-', '')
        try:
            return int(tid)
        except (TypeError, ValueError):
            continue
    return None


def _episodes_from(res):
    data = res.get('data') if isinstance(res, dict) else None
    if isinstance(data, dict):
        return data.get('episodes') or []
    if isinstance(data, list):
        return data
    return []


def fetch_episodes(key, tvdb_id):
    """Aired-order episodes for one series. Empty key: no network, empty list."""
    if not (key or '').strip():
        return []
    tok = _login(key)
    tvdb_id = int(tvdb_id)
    out, page = [], 0
    while page < 500:
        res = _req('/series/%d/episodes/default?page=%d' % (tvdb_id, page), token=tok)
        out.extend(_episodes_from(res))
        links = res.get('links') if isinstance(res, dict) else None
        if not links or not links.get('next'):
            break
        page += 1
    return out


def fetch_series(key, tvdb_id):
    """Name and year for a series id. Empty key: no network."""
    if not (key or '').strip():
        return {'title': None, 'year': None}
    tok = _login(key)
    res = _req('/series/%d' % int(tvdb_id), token=tok)
    data = res.get('data') if isinstance(res, dict) else None
    if not isinstance(data, dict):
        data = {}
    year = data.get('year')
    if not year and data.get('firstAired'):
        year = str(data.get('firstAired'))[:4]
    try:
        year = int(str(year)[:4])
    except (TypeError, ValueError):
        year = None
    return {'title': data.get('name') or None, 'year': year}


def _norm_ep(e):
    if not isinstance(e, dict):
        return None
    season = e.get('seasonNumber', e.get('season'))
    number = e.get('number', e.get('episode'))
    if season is None or number is None:
        return None
    try:
        season, number = int(season), int(number)
    except (TypeError, ValueError):
        return None
    eid = e.get('id') if ('seasonNumber' in e or 'number' in e) else e.get('tvdb_id')
    if 'seasonNumber' not in e and 'number' not in e:
        eid = e.get('tvdb_id')
    title = e.get('name') if e.get('name') else e.get('title')
    return {'season': season, 'episode': number, 'tvdb_id': eid,
            'title': title or None, 'aired': e.get('aired') or None}


def _placeholder(title, tvdb_id):
    t = (title or '').strip()
    return t in ('', 'Unknown show') or t == 'TVDB %s' % tvdb_id


def replace_with_episodes(tvdb_id, episodes, title=None, year=None, show_id=None):
    """Purge saved episode entries for this TVDB id, then write the given list
    as watched. No network. Returns the number of episodes written."""
    tvdb_id = int(tvdb_id)
    rows = []
    for raw in episodes or []:
        ep = _norm_ep(raw)
        if ep:
            rows.append(ep)
    if not rows:
        return {'ok': False, 'error': 'no episodes', 'episodes': 0, 'title': title, 'tvdb_id': tvdb_id}
    with wv.db() as con:
        by_tv = con.execute('SELECT * FROM shows WHERE tvdb_id=?', (tvdb_id,)).fetchone()
        target = None
        if show_id:
            target = con.execute('SELECT * FROM shows WHERE id=?', (int(show_id),)).fetchone()
        if target and by_tv and by_tv['id'] != target['id']:
            con.execute('DELETE FROM episodes WHERE show_id=?', (by_tv['id'],))
            con.execute('UPDATE shows SET tvdb_id=NULL WHERE id=?', (by_tv['id'],))
            con.execute('DELETE FROM shows WHERE id=?', (by_tv['id'],))
            by_tv = None
        if target is None:
            target = by_tv
        final_year = year
        if target is None:
            name = title or ('TVDB %s' % tvdb_id)
            cur = con.execute(
                'INSERT INTO shows(tvdb_id,imdb_id,tmdb_id,title,year,created) VALUES(?,?,?,?,?,?)',
                (tvdb_id, None, None, name, year, wv._now()))
            sid = cur.lastrowid
            final_title = name
        else:
            sid = target['id']
            con.execute('DELETE FROM episodes WHERE show_id=?', (sid,))
            final_title = target['title']
            if title and _placeholder(final_title, tvdb_id):
                final_title = title
            final_year = target['year'] or year
            con.execute('UPDATE shows SET tvdb_id=?, title=?, year=? WHERE id=?',
                        (tvdb_id, final_title, final_year, sid))
        n = 0
        ts = wv._now()
        for ep in rows:
            con.execute(
                'INSERT INTO episodes(show_id,season,episode,tvdb_id,title,aired,watched,play_count,last_watched)'
                ' VALUES(?,?,?,?,?,?,1,1,?) ON CONFLICT(show_id,season,episode) DO UPDATE SET'
                ' tvdb_id=COALESCE(excluded.tvdb_id,episodes.tvdb_id),'
                ' title=COALESCE(excluded.title,episodes.title),'
                ' aired=COALESCE(excluded.aired,episodes.aired),'
                ' watched=1, play_count=1, last_watched=excluded.last_watched',
                (sid, ep['season'], ep['episode'], wv._id(ep.get('tvdb_id')), ep.get('title'),
                 ep.get('aired'), ts))
            n += 1
        wv._log_change(con, 'full', final_title, final_year, tvdb_id, None, None, None, None, True, 'manual')
    wv._notify('changed', {'full': True})
    return {'ok': True, 'episodes': n, 'title': final_title, 'tvdb_id': tvdb_id, 'show_id': sid}


def purge_and_complete(key, tvdb_id, show_id=None):
    """Confirm-path: fetch the series, then purge saved entries and mark the
    full aired-order list watched. Empty key does not touch the network or the
    database."""
    if not (key or '').strip():
        return {'ok': False, 'error': 'no key', 'episodes': 0}
    try:
        tvdb_id = int(tvdb_id)
    except (TypeError, ValueError):
        return {'ok': False, 'error': 'bad id', 'episodes': 0}
    if tvdb_id <= 0:
        return {'ok': False, 'error': 'bad id', 'episodes': 0}
    meta = fetch_series(key, tvdb_id)
    eps = fetch_episodes(key, tvdb_id)
    if not eps:
        return {'ok': False, 'error': 'no episodes', 'episodes': 0, 'title': meta.get('title'),
                'tvdb_id': tvdb_id}
    return replace_with_episodes(tvdb_id, eps, title=meta.get('title'), year=meta.get('year'),
                                 show_id=show_id)


def fill_show(key, show_id):
    """Resolve the tvdb id if missing, then add every aired-order episode
    (leaving watched flags alone) so the list is complete.
    Returns the number of episodes seen. Empty key: 0, no network."""
    if not (key or '').strip():
        return 0
    with wv.db() as con:
        s = con.execute('SELECT * FROM shows WHERE id=?', (show_id,)).fetchone()
    if not s:
        return 0
    tvdb_id = s['tvdb_id']
    if not tvdb_id:
        tvdb_id = resolve_tvdb_id(key, s['title'], s['year'])
        if not tvdb_id:
            return 0
        with wv.db() as con:
            if not con.execute('SELECT 1 FROM shows WHERE tvdb_id=?', (tvdb_id,)).fetchone():
                con.execute('UPDATE shows SET tvdb_id=? WHERE id=?', (tvdb_id, show_id))
    eps = fetch_episodes(key, tvdb_id)
    count = 0
    with wv.db() as con:
        for raw in eps:
            ep = _norm_ep(raw)
            if not ep:
                continue
            con.execute(
                'INSERT INTO episodes(show_id,season,episode,tvdb_id,title,aired,watched,play_count)'
                ' VALUES(?,?,?,?,?,?,0,0) ON CONFLICT(show_id,season,episode) DO UPDATE SET'
                ' tvdb_id=COALESCE(excluded.tvdb_id,episodes.tvdb_id),'
                ' title=COALESCE(excluded.title,episodes.title),'
                ' aired=COALESCE(excluded.aired,episodes.aired)',
                (show_id, ep['season'], ep['episode'], wv._id(ep.get('tvdb_id')), ep.get('title'),
                 ep.get('aired')))
            count += 1
    return count
