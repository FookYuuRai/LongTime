# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
import watchvault as wv  # noqa: E402

BACKUP_NAME = 'watchvault-backup.json'


def log(msg):
    xbmc.log('[WatchVault] %s' % msg, xbmc.LOGINFO)


def cfg():
    return xbmcaddon.Addon()


def _source_from(path):
    m = re.match(r'^plugin://([^/]+)/', path or '')
    return m.group(1) if m else None


def _blank(v):
    return v is None or v == ''


class HistoryService(xbmc.Player):
    """History service: updates watch history from playback."""

    def __init__(self):
        super().__init__()
        self.cur = None
        self.pos = 0.0
        self.total = 0.0

    # ---- Kodi callbacks
    def onAVStarted(self):
        try:
            self.cur = self._snapshot()
        except Exception as e:  # never let a bad plugin crash the service
            log('snapshot failed: %s' % e)
            self.cur = None
        self.pos = self.total = 0.0

    def onPlayBackEnded(self):
        self._finish(True)

    def onPlayBackStopped(self):
        self._finish(False)

    def onPlayBackError(self):
        self.cur = None

    # ---- logic
    def _snapshot(self):
        win = xbmcgui.Window(10000)
        ann = {}
        raw = win.getProperty('watchvault.announce')
        if raw:
            win.clearProperty('watchvault.announce')
            try:
                ann = json.loads(raw)
                if time.time() - float(ann.get('ts', 0)) > 180:
                    ann = {}
            except ValueError:
                ann = {}

        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            playing = ''
        source = ann.get('source') or _source_from(playing) or _source_from(
            xbmc.getInfoLabel('Player.Filenameandpath')) or xbmc.getInfoLabel('Container.PluginName') or None

        mode = cfg().getSettingInt('track_mode')  # 0 = only add-ons I added, 1 = everything
        src_row = wv.get_source(source)
        if mode == 0 and not (src_row and src_row['enabled']):
            return None
        if src_row is not None and not src_row['enabled']:
            return None

        info = {'title': None, 'year': None, 'season': None, 'episode': None,
                'tvdb_id': None, 'imdb_id': None, 'tmdb_id': None,
                'anilist_id': None, 'mal_id': None,
                'episode_tvdb_id': None, 'episode_imdb_id': None, 'episode_tmdb_id': None,
                'episode_anilist_id': None, 'episode_mal_id': None}
        mediatype = ''
        try:
            tag = self.getVideoInfoTag()
            mediatype = tag.getMediaType()
            if mediatype == 'episode':
                info['title'] = tag.getTVShowTitle()
                info['season'] = tag.getSeason() if tag.getSeason() >= 0 else None
                info['episode'] = tag.getEpisode() if tag.getEpisode() >= 0 else None
            else:
                info['title'] = tag.getTitle() or tag.getOriginalTitle()
            info['year'] = tag.getYear() or None
            show_keys = (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'),
                         ('anilist', 'anilist_id'), ('mal', 'mal_id'))
            ep_keys = (('tvdb', 'episode_tvdb_id'), ('imdb', 'episode_imdb_id'),
                       ('tmdb', 'episode_tmdb_id'), ('anilist', 'episode_anilist_id'),
                       ('mal', 'episode_mal_id'))
            for key, fld in show_keys:
                try:
                    v = tag.getUniqueID(key)
                    if v:
                        info[fld] = v
                except Exception:
                    pass
            if mediatype == 'episode':
                for key, fld in ep_keys:
                    try:
                        v = tag.getUniqueID('episode.' + key)
                        if v:
                            info[fld] = v
                    except Exception:
                        pass
            try:  # a movie's own tvdb id, or an explicit show-level id
                keys = ('tvshow.tvdb', 'tvdb') if mediatype == 'episode' else ('tvdb',)
                for k in keys:
                    v = tag.getUniqueID(k)
                    if v:
                        info['tvdb_id'] = v
                        break
            except Exception:
                pass
        except RuntimeError:
            pass
        if not info['title']:
            info['title'] = xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or xbmc.getInfoLabel('VideoPlayer.Title')
        if not mediatype:
            mediatype = 'episode' if xbmc.getInfoLabel('VideoPlayer.TVShowTitle') else 'movie'
            if mediatype == 'episode':
                info['season'] = xbmc.getInfoLabel('VideoPlayer.Season')
                info['episode'] = xbmc.getInfoLabel('VideoPlayer.Episode')
        for key, fld in (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'), ('tvdb', 'tvdb_id'),
                         ('anilist', 'anilist_id'), ('mal', 'mal_id')):
            if _blank(info.get(fld)):
                v = xbmc.getInfoLabel('VideoPlayer.UniqueID(%s)' % key)
                if not _blank(v):
                    info[fld] = v
        info.update({k: v for k, v in ann.items() if k in info and not _blank(v)})
        if ann and not _blank(info.get('season')) and not _blank(info.get('episode')):
            mediatype = 'episode'       # an explicit announce wins over Kodi's guess
        elif mediatype in ('', 'video'):
            mediatype = 'movie'
        if mediatype == 'episode' and (_blank(info.get('season')) or _blank(info.get('episode'))):
            return None
        if mediatype == 'movie':
            info['season'] = info['episode'] = None
            for key in ('episode_tvdb_id', 'episode_imdb_id', 'episode_tmdb_id',
                        'episode_anilist_id', 'episode_mal_id'):
                info[key] = None
        named = (info['title'], info['tvdb_id'], info['imdb_id'], info['tmdb_id'],
                 info['anilist_id'], info['mal_id'])
        if mediatype not in ('episode', 'movie') or not any(not _blank(v) for v in named):
            return None
        info['episode_title'] = ann.get('episode_title') or (
            xbmc.getInfoLabel('VideoPlayer.Title') if mediatype == 'episode' else None)
        info['aired'] = ann.get('aired')
        return {'info': info, 'source': source}

    def tick(self):
        if self.cur and self.isPlayingVideo():
            try:
                self.pos = self.getTime()
                self.total = self.getTotalTime()
            except RuntimeError:
                pass

    def _timing(self, ended):
        total = self.total if self.total and self.total > 0 else 0.0
        pos = self.pos if self.pos and self.pos > 0 else 0.0
        if total and pos > total:
            pos = total
        if not total:
            return None, None
        runtime = int(round(total))
        if ended:
            remaining = 0
        else:
            remaining = max(0, int(round(total - pos)))
        return runtime, remaining

    def _finish(self, ended):
        cur, self.cur = self.cur, None
        if not cur:
            return
        pct = 100.0 if ended else (self.pos / self.total * 100.0 if self.total > 0 else 0.0)
        runtime, remaining = self._timing(ended)
        extra = {}
        if runtime is not None:
            extra['runtime'] = runtime
        if remaining is not None:
            extra['remaining'] = remaining
        if pct < cfg().getSettingInt('threshold'):
            if extra:
                wv.save_progress(source=cur['source'], **cur['info'], **extra)
                log('progress %s from %s runtime=%s remaining=%s' % (
                    cur['info'].get('title'), cur['source'], runtime, remaining))
            return
        res = wv.mark_watched(source=cur['source'], **cur['info'], **extra)
        log('marked %s from %s: %s' % (cur['info'].get('title'), cur['source'], res))
        if res.get('ok') and cfg().getSettingBool('notify'):
            i = cur['info']
            label = i['title'] if _blank(i.get('season')) else '%s S%02dE%02d' % (
                i['title'], int(i['season']), int(i['episode']))
            xbmcgui.Dialog().notification(
                cfg().getAddonInfo('name') or 'WatchVault',
                cfg().getLocalizedString(30120) % label,
                xbmcgui.NOTIFICATION_INFO, 2500, False)
        self._maybe_catalog(i=cur['info'])

    def _maybe_catalog(self, i):
        c = cfg()
        key = c.getSettingString('tvdb_key').strip()
        if i.get('season') is None or not key or not c.getSettingBool('fetch_catalog'):
            return
        try:
            import tvdb_catalog
            with wv.db() as con:
                sid = wv._show_id(con, i['title'], i.get('year'), i.get('tvdb_id'), i.get('imdb_id'),
                                  i.get('tmdb_id'), create=False)
                have = con.execute('SELECT COUNT(*) FROM episodes WHERE show_id=? AND watched=0',
                                   (sid,)).fetchone()[0] if sid else 1
            if sid and not have:
                tvdb_catalog.fill_show(key, sid)
        except Exception as e:
            log('catalog fetch failed: %s' % e)


# ------------------------------------------------------------------ backups
def _backup_dir():
    folder = cfg().getSettingString('backup_path')
    return folder or None


def _write_backup():
    folder = _backup_dir()
    if not folder or not cfg().getSettingBool('auto_backup'):
        return
    tmp = os.path.join(xbmcvfs.translatePath('special://temp/'), BACKUP_NAME)
    wv.export_json(tmp)
    dest = xbmcvfs.makeLegalFilename(folder.rstrip('/\\') + '/' + BACKUP_NAME) if not folder.startswith(
        ('smb://', 'nfs://', 'special://')) else folder.rstrip('/') + '/' + BACKUP_NAME
    if xbmcvfs.exists(dest):
        xbmcvfs.delete(dest)
    xbmcvfs.copy(tmp, dest)


def _restore_if_empty():
    folder = _backup_dir()
    c = wv.counts()
    if not folder or c['shows'] or c['movies']:
        return
    src = folder.rstrip('/\\') + '/' + BACKUP_NAME
    if not xbmcvfs.exists(src):
        return
    tmp = os.path.join(xbmcvfs.translatePath('special://temp/'), 'watchvault-restore.json')
    if xbmcvfs.copy(src, tmp):
        try:
            res = wv.import_json(tmp)
            log('restored from automatic backup: %s' % res)
            xbmcgui.Dialog().notification(
                cfg().getAddonInfo('name') or 'WatchVault',
                cfg().getLocalizedString(30121),
                xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception as e:
            log('restore failed: %s' % e)


def main():
    monitor = xbmc.Monitor()
    player = HistoryService()
    log('history service started')
    try:
        _restore_if_empty()
    except Exception as e:
        log('restore error: %s' % e)
    last_seq = wv.last_seq()
    last_backup = time.time()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        player.tick()
        if time.time() - last_backup > 30:
            try:
                seq = wv.last_seq()
                if seq != last_seq:
                    _write_backup()
                    last_seq = seq
            except Exception as e:
                log('backup error: %s' % e)
            last_backup = time.time()
    try:
        _write_backup()
    except Exception as e:
        log('final backup error: %s' % e)


if __name__ == '__main__':
    main()
