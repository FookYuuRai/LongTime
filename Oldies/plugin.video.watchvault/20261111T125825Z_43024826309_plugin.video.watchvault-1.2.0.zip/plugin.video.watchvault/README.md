# WatchVault (plugin.video.watchvault)

Local watch history for Kodi. No Trakt / Simkl / MDBList account.

* Shows: show name, year, TVDB id, episodes as season/episode (season 0 = specials, TVDB aired order).
* Movies: title, year, TVDB id (imdb / tmdb optional).
* Add the video add-ons you use (Add-on > "+ Add a video add-on", or Settings > Add a video add-on).
  Playback from those add-ons is added to watch history at the "mark as watched after %" point.
* The history service (HistoryService) watches playback and applies that rule.
* Wipe or update any video add-on: the history lives here, and the add-on pulls it back through the helper.
* Export / import: JSON file and database file (merge or replace). Optional automatic JSON backup folder;
  if WatchVault's own data is ever wiped it restores from that backup at start-up.
* Nothing is sent over the internet. Optional: enter your own TVDB API key to fetch full episode lists. No keys are bundled.
* Manual TVDB id: Settings has a text field for a TVDB series id. Enter the id and choose
  "Purge saved entries and complete this TVDB id" (also on the main menu, or on a show).
  After you confirm, WatchVault purges that show's saved episode entries and writes the full
  TVDB episode list as watched. An empty API key does nothing and makes no network call.
* One show, episode or movie keeps TVDB, IMDb, TMDB, AniList and MAL ids on the same row.
  A later update that only has one of those ids still finds that same file.
* Playback stores runtime and time remaining (seconds) so it can be resumed.
  A stop below the watched threshold saves that progress and does not mark the item watched.
  At the threshold, or when playback ends, it is marked watched and the time remaining is kept
  (zero when it played to the end).
* Database count lists shows, episodes and the database file size. Purge all now clears saved
  shows, episodes and movies after you confirm. Video add-ons you added are kept.

## For add-on authors
Copy `helper/watchvault_helper.py` into your add-on (docs at the top of the file).
Without the helper you can also call, from any add-on:

    RunPlugin(plugin://plugin.video.watchvault/?action=mark_watched&title=Show&year=2019&season=1&episode=2&tvdb_id=12345&source=plugin.video.x)
    RunPlugin(plugin://plugin.video.watchvault/?action=announce&title=Show&year=2019&season=1&episode=2&tvdb_id=12345&source=plugin.video.x)

JSON layout: `{"format":"watchvault","version":1,"shows":[{"title","year","tvdb_id","imdb_id","tmdb_id","episodes":[{"season","episode","title","aired","watched","play_count","last_watched"}]}],"movies":[...],"sources":[...]}`

## Watch history details
* Watch history: a played item is saved as watched at the "mark as watched after %" point, or when it plays to the end. Add-ons that pass the TVDB id, season and episode give the most reliable results. Use the helper's `announce()` or `mark()` when the add-on doesn't pass these.
* Matching: items without a TVDB id are matched by show name and year, and get their id later.
* Episode lists: the full aired-order list (specials as season 0) needs your own TVDB API key in Settings. It is off by default.
