# -*- coding: utf-8 -*-
"""Unified media store. See helpers/CONTRACT.md for the record shape, merge rules and lookups.

One table, one row per show, movie or episode. Every known id sits in its own column; ids from namespaces without a
column go in extra_ids (JSON). A row is kept when it has at least one id."""
import json
import re

# column per id namespace
NAMESPACES = {'anidb': 'anidb_id', 'anilist': 'anilist_id', 'mal': 'mal_id', 'tvdb': 'tvdb_id',
              'tmdb': 'tmdb_id', 'imdb': 'imdb_id'}
ID_COLS = tuple(NAMESPACES.values())
# one-to-one keys decide whether two records are the same title (TVDB and IMDb are shared by many anime)
MERGE_KEYS = {
    'show': ('anidb_id', 'anilist_id', 'mal_id', 'tmdb_id'),   # tmdb show ids are unique per show
    'movie': ('anidb_id', 'anilist_id', 'mal_id', 'tmdb_id'),
    'episode': ('tvdb_id', 'tmdb_id'),
}
EXTRA_COLS = ('ep_tvdb_season', 'ep_tvdb_number', 'ep_tmdb_season', 'ep_tmdb_number', 'ep_type', 'air_date',
              'tvdb_season_id', 'tmdb_season_id', 'meta', 'parent_id')
WATCH_COLS = ('watched', 'play_count', 'last_watched', 'runtime', 'remaining', 'play_source')
FIELDS = ('title', 'title_en', 'year', 'tvdb_season', 'tvdb_epoffset', 'numbering') + ID_COLS + EXTRA_COLS

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS media(
         id INTEGER PRIMARY KEY,
         kind TEXT NOT NULL,
         show_id INTEGER,
         season INTEGER,
         number INTEGER,
         title TEXT,
         title_en TEXT,
         year INTEGER,
         anidb_id INTEGER,
         anilist_id INTEGER,
         mal_id INTEGER,
         tvdb_id INTEGER,
         tmdb_id INTEGER,
         imdb_id TEXT,
         tvdb_season INTEGER,
         tvdb_epoffset INTEGER,
         numbering TEXT,
         extra_ids TEXT,
         sources TEXT,
         watched INTEGER DEFAULT 0,
         play_count INTEGER DEFAULT 0,
         last_watched TEXT,
         runtime INTEGER,
         remaining INTEGER,
         play_source TEXT)""",
    "CREATE INDEX IF NOT EXISTS ix_media_anidb ON media(anidb_id)",
    "CREATE INDEX IF NOT EXISTS ix_media_anilist ON media(anilist_id)",
    "CREATE INDEX IF NOT EXISTS ix_media_mal ON media(mal_id)",
    "CREATE INDEX IF NOT EXISTS ix_media_tvdb ON media(tvdb_id)",
    "CREATE INDEX IF NOT EXISTS ix_media_tmdb ON media(tmdb_id)",
    "CREATE INDEX IF NOT EXISTS ix_media_imdb ON media(imdb_id)",
    "CREATE INDEX IF NOT EXISTS ix_media_show ON media(show_id, season, number)",
    "CREATE INDEX IF NOT EXISTS ix_media_title ON media(title)",
    """CREATE TABLE IF NOT EXISTS season(
         id INTEGER PRIMARY KEY,
         show_id INTEGER NOT NULL,
         number INTEGER NOT NULL,
         order_type TEXT NOT NULL,
         tvdb_season_id INTEGER,
         tmdb_season_id INTEGER,
         name TEXT,
         sources TEXT,
         UNIQUE(show_id, number, order_type))""",
    "CREATE INDEX IF NOT EXISTS ix_season_tvdb ON season(tvdb_season_id)",
    "CREATE TABLE IF NOT EXISTS ref_index(ns TEXT NOT NULL, val TEXT NOT NULL, media_id INTEGER NOT NULL, PRIMARY KEY(ns, val, media_id)) WITHOUT ROWID",
    "CREATE INDEX IF NOT EXISTS ix_season_tmdb ON season(tmdb_season_id)",
]


def _ensure_body(con):
    for stmt in SCHEMA:
        con.execute(stmt)
    try:
        con.execute('CREATE INDEX IF NOT EXISTS ix_media_kind_watched ON media(kind, watched)')
    except Exception:
        pass
    if con.execute('SELECT 1 FROM ref_index LIMIT 1').fetchone() is None:
        for rid, extra in con.execute('SELECT id, extra_ids FROM media WHERE extra_ids IS NOT NULL').fetchall():
            _index_extras(con, rid, json.loads(extra or '{}'))
    # add episode columns to stores created by earlier builds
    have = {r[1] for r in con.execute('PRAGMA table_info(media)').fetchall()}
    for col in EXTRA_COLS:
        if col not in have:
            con.execute('ALTER TABLE media ADD COLUMN %s %s' % (col, 'TEXT' if col in ('ep_type', 'air_date', 'meta') else 'INTEGER'))
    if 'season' not in {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
        for stmt in SCHEMA:
            if 'season' in stmt.split('(')[0]:
                con.execute(stmt)
    for col, decl in (('watched', 'INTEGER DEFAULT 0'), ('play_count', 'INTEGER DEFAULT 0'),
                       ('last_watched', 'TEXT'), ('runtime', 'INTEGER'), ('remaining', 'INTEGER'),
                       ('play_source', 'TEXT')):
        if col not in have:
            con.execute('ALTER TABLE media ADD COLUMN %s %s' % (col, decl))


_ENSURED = set()


def ensure(con):
    """Create and migrate the unified tables once per database file in this process (it used to run on every call)."""
    key = con.execute('PRAGMA database_list').fetchone()[2] or ':memory:'
    if key in _ENSURED:
        return
    _ensure_body(con)
    _ENSURED.add(key)


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


ANIME_KEYS = ('anidb_id', 'anilist_id', 'mal_id')   # identify an anime whether it is a show or a movie

# Sources that typically supply English display titles (TMDb/TVDB/Nightshift/providers).
ENGLISH_SOURCES = frozenset({
    'nightshift', 'tmdb', 'tvdb', 'mdblist', 'trakt', 'simkl', 'punchplay', 'local', 'test',
})


def _is_cjk_heavy(text):
    """True when the string contains CJK / Hangul / fullwidth characters."""
    if not text:
        return False
    n = 0
    for ch in str(text):
        o = ord(ch)
        if (0x3040 <= o <= 0x30FF or 0x3400 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF
                or 0xAC00 <= o <= 0xD7AF or 0xFF66 <= o <= 0xFF9D):
            n += 1
    return n >= 1


def _looks_english_title(text):
    """Latin-script title suitable as English display (not empty, little/no CJK)."""
    if not text or not str(text).strip():
        return False
    if _is_cjk_heavy(text):
        return False
    letters = sum(1 for ch in str(text) if ch.isalpha())
    latin = sum(1 for ch in str(text) if ('A' <= ch <= 'Z') or ('a' <= ch <= 'z'))
    return letters > 0 and latin >= max(1, int(letters * 0.6))


def _title_merge(have_title, have_title_en, new_title, new_title_en, source):
    """Return (title, title_en) after applying English-aware merge rules.

    - title: original/romaji/native preferred; English may overwrite only when existing is CJK-heavy.
    - title_en: English sources may always fill or overwrite with an English-looking title.
    - When an English source brings a Latin title and title is already Latin (e.g. romaji),
      the English value goes to title_en and title is left unchanged.
    """
    title, title_en = have_title, have_title_en
    src_en = (source or '') in ENGLISH_SOURCES

    # Prefer explicit title_en from the record.
    cand_en = new_title_en if new_title_en not in (None, '') else None
    if cand_en is None and src_en and _looks_english_title(new_title):
        cand_en = new_title
    if cand_en is not None and _looks_english_title(cand_en):
        if title_en in (None, '') or src_en:
            title_en = cand_en

    if new_title not in (None, ''):
        if title in (None, ''):
            title = new_title
        elif src_en and _looks_english_title(new_title) and _is_cjk_heavy(title):
            # Non-English (CJK) title may be replaced by English display title.
            if title_en in (None, ''):
                title_en = new_title
            title = new_title
        elif src_en and _looks_english_title(new_title) and title != new_title:
            # Romaji/other Latin stays in title; English lands in title_en.
            if title_en in (None, '') or src_en:
                title_en = new_title
    return title, title_en




def _find(con, kind, rec, show_id=None):
    """Existing row for this record, or None.
    Anime (show, movie): AniDB id first (one row owns one AniDB id). Otherwise AniList, MAL or TMDb ids, but only
    a row that does not conflict with an id both sides already hold. Episodes match within their show by episode ids."""
    if kind in ('show', 'movie'):
        return _find_anime(con, kind, rec)
    parts, args = [], []
    for col in MERGE_KEYS.get(kind, ()):
        if rec.get(col) is None:
            continue
        parts.append('(kind=? AND %s=?)' % col)
        args.extend([kind, rec[col]])
    if not parts:
        return None
    sql = 'SELECT id FROM media WHERE %s' % ' OR '.join(parts)
    if kind == 'episode':
        sql += ' AND show_id=?'
        args += [show_id]
    row = con.execute(sql + ' ORDER BY id LIMIT 1', args).fetchone()
    return row[0] if row else None


def _find_anime(con, kind, rec):
    if rec.get('anidb_id') is not None:
        row = con.execute('SELECT id FROM media WHERE kind IN ("show","movie") AND anidb_id=? ORDER BY id LIMIT 1',
                          (rec['anidb_id'],)).fetchone()
        if row:
            return row[0]
    for col in ('anilist_id', 'mal_id', 'tmdb_id'):
        if rec.get(col) is None:
            continue
        kinds = (kind,) if col == 'tmdb_id' else ('show', 'movie')
        marks = ','.join('?' * len(kinds))
        for (rid, a, an, m) in con.execute(
                'SELECT id, anidb_id, anilist_id, mal_id FROM media WHERE kind IN (%s) AND %s=? ORDER BY id'
                % (marks, col), kinds + (rec[col],)):
            have = {'anidb_id': a, 'anilist_id': an, 'mal_id': m}
            if any(rec.get(k) is not None and have[k] is not None and have[k] != rec[k] for k in have):
                continue   # conflicting ids: a different title
            return rid
    return None

def _index_extras(con, media_id, extra):
    for k, v in (extra or {}).items():
        if v not in (None, ''):
            con.execute('INSERT OR IGNORE INTO ref_index(ns, val, media_id) VALUES(?,?,?)', (k, str(v), media_id))


def _rows_for_extra(con, kinds, ns, value):
    """Row ids of the given kinds that carry extra id ns:value (indexed)."""
    marks = ','.join('?' * len(kinds))
    return [r[0] for r in con.execute(
        'SELECT r.media_id FROM ref_index r JOIN media m ON m.id=r.media_id '
        'WHERE r.ns=? AND r.val=? AND m.kind IN (%s)' % marks, (ns, str(value).strip()) + tuple(kinds))]


def _extra_clauses(extra):
    """Clauses matching extra namespaces (kitsu, anime_planet, ...) stored in extra_ids (JSON)."""
    clauses, args = [], []
    for k, v in (extra or {}).items():
        if v in (None, ''):
            continue
        clauses.append('extra_ids LIKE ?')
        args.append('%' + json.dumps({k: str(v)}, sort_keys=True)[1:-1] + '%')
    return clauses, args


def _norm_title(text):
    return re.sub(r'\s+', ' ', re.sub(r'[^0-9a-z\u3040-\u30ff\u4e00-\u9fff]+', ' ', (text or '').lower())).strip()


def _find_any(con, kind, rec):
    """Provider linking: any shared id links the row. The candidate sharing the most ids wins; ties go to the
    lowest id. Only rows of the same kind are candidates."""
    counts = {}
    for col in ID_COLS:
        if rec.get(col) is None:
            continue
        for (rid,) in con.execute('SELECT id FROM media WHERE kind=? AND %s=?' % col, (kind, rec[col])):
            counts[rid] = counts.get(rid, 0) + 1
    for k, v in (rec.get('extra') or {}).items():
        if v not in (None, ''):
            for rid in _rows_for_extra(con, (kind,), k, v):
                counts[rid] = counts.get(rid, 0) + 1
    if not counts:
        return None
    best = max(counts.values())
    top = sorted(r for r, c in counts.items() if c == best)
    if len(top) == 1:
        return top[0]
    try:
        import xbmc
        shared = [ref for ref in ('%s:%s' % (c, rec[c]) for c in ID_COLS if rec.get(c) is not None)][:1]
        xbmc.log('[WatchVault link] %s shares %s with %d rows; deciding by title' % (
            kind, ','.join(shared) or 'extra ids', len(top)), xbmc.LOGWARNING)
    except Exception:
        pass
    # several rows share the best count (one TVDB id covers several anime): the title decides;
    # with no title agreement the record stays separate rather than attaching to an arbitrary row
    want = {_norm_title(rec.get('title')), _norm_title(rec.get('title_en'))} - {''}
    if want:
        for rid in top:
            have = con.execute('SELECT title, title_en FROM media WHERE id=?', (rid,)).fetchone()
            if {_norm_title(have[0]), _norm_title(have[1])} & want:
                return rid
    return None


def upsert(con, kind, rec, source, show_id=None, link='one_to_one'):
    """Insert or merge one row from a helper record (see CONTRACT.md). Existing values are never overwritten;
    empty fields are filled, extra ids are added, and the source is recorded. Returns the row id."""
    ensure(con)
    values = {f: rec.get(f) for f in FIELDS if rec.get(f) is not None}
    extra = dict(rec.get('extra') or {})
    if kind in ('show', 'movie') and link == 'any':
        row_id = _find_any(con, kind, rec)
    else:
        row_id = _find(con, kind, rec, show_id)
    if row_id is None and kind in ('show', 'movie'):
        # one-to-one anime keys first, then extra namespaces (records that carry only kitsu / anime-planet ids)
        for k, v in extra.items():
            if v not in (None, ''):
                hits = _rows_for_extra(con, ('show', 'movie'), k, v)
                if hits:
                    row_id = min(hits)
                    break
    if row_id is None:
        # Seed English title_en when an English-source title is all we have.
        if values.get('title_en') in (None, '') and (source or '') in ENGLISH_SOURCES:
            if _looks_english_title(values.get('title')):
                values['title_en'] = values.get('title')
        cols = ['kind', 'show_id', 'season', 'number', 'extra_ids', 'sources'] + list(values)
        vals = [kind, show_id, rec.get('season'), rec.get('number'),
                json.dumps(extra, sort_keys=True) if extra else None, source] + list(values.values())
        cur = con.execute('INSERT INTO media(%s) VALUES(%s)' % (','.join(cols), ','.join('?' * len(cols))), vals)
        _index_extras(con, cur.lastrowid, extra)
        return cur.lastrowid
    cols = [d[0] for d in con.execute('SELECT * FROM media LIMIT 0').description]
    have = dict(zip(cols, con.execute('SELECT * FROM media WHERE id=?', (row_id,)).fetchone()))
    sets, args = [], []
    # English-aware title merge (may overwrite CJK title; English always updates title_en).
    if any(k in values for k in ('title', 'title_en')) or have.get('title') or have.get('title_en'):
        new_title = values.pop('title', None) if 'title' in values else None
        new_title_en = values.pop('title_en', None) if 'title_en' in values else None
        # If caller only sent title, still allow EN path via source.
        merged_title, merged_en = _title_merge(
            have.get('title'), have.get('title_en'), new_title, new_title_en, source)
        if merged_title != have.get('title') and merged_title is not None:
            sets.append('title=?')
            args.append(merged_title)
        if merged_en != have.get('title_en') and merged_en is not None:
            sets.append('title_en=?')
            args.append(merged_en)
    for col, val in values.items():
        if have.get(col) is None:
            sets.append('%s=?' % col)
            args.append(val)
    old_extra = json.loads(have.get('extra_ids') or '{}')
    merged = dict(extra)
    merged.update(old_extra)
    if merged != old_extra:
        sets.append('extra_ids=?')
        args.append(json.dumps(merged, sort_keys=True))
    srcs = set(filter(None, (have.get('sources') or '').split(',')))
    if source not in srcs:
        srcs.add(source)
        sets.append('sources=?')
        args.append(','.join(sorted(srcs)))
    if sets:
        con.execute('UPDATE media SET %s WHERE id=?' % ','.join(sets), args + [row_id])
    _index_extras(con, row_id, merged)
    return row_id


def _rows(cur):
    names = [d[0] for d in cur.description]
    out = []
    for r in cur.fetchall():
        row = dict(zip(names, r))
        row['extra_ids'] = json.loads(row['extra_ids'] or '{}')
        out.append(row)
    return out


def find(con, query):
    """Lookup. 'anidb:7294', 'mal:7669', 'tvdb:81797', 'tmdb:1396', 'imdb:tt0903747', 'anilist:...', 'kitsu:...'
    (extra namespaces match extra_ids), a bare number (every match, with the id types it matched), or a title.
    Each result is a row dict with 'matched': the id types that matched."""
    ensure(con)
    text = str(query).strip()
    cur = con.cursor()
    if ':' in text:
        ns, value = text.split(':', 1)
        ns = ns.lower()
        if ns in NAMESPACES:
            col = NAMESPACES[ns]
            v = value.strip() if col == 'imdb_id' else _int(value)
            if v is None:
                return []
            cur.execute('SELECT * FROM media WHERE %s=? ORDER BY kind, id' % col, (v,))
            out = _rows(cur)
            for r in out:
                r['matched'] = [ns]
            return out
        # extra namespace (kitsu, anime_planet, ...): match inside extra_ids
        ids = [r[0] for r in con.execute('SELECT media_id FROM ref_index WHERE ns=? AND val=?', (ns, value.strip()))]
        out = []
        for rid in sorted(ids):
            cur.execute('SELECT * FROM media WHERE id=? ORDER BY kind, id', (rid,))
            out.extend(_rows(cur))
        for r in out:
            r['matched'] = [ns]
        return out
    if text.isdigit():
        by_id = {}
        for ns, col in NAMESPACES.items():
            if col == 'imdb_id':
                continue
            cur.execute('SELECT * FROM media WHERE %s=? ORDER BY kind, id' % col, (int(text),))
            for r in _rows(cur):
                entry = by_id.setdefault(r['id'], dict(r, matched=[]))
                entry['matched'].append(ns)
        return list(by_id.values())
    norm = re.sub(r'\s+', ' ', re.sub(r'[^0-9a-z]+', ' ', text.lower())).strip()
    cur.execute('SELECT * FROM media WHERE kind IN ("show","movie") AND '
                '(lower(title)=? OR lower(title_en)=? OR lower(title) LIKE ?) ORDER BY id',
                (text.lower(), text.lower(), '%' + norm + '%'))
    out = _rows(cur)
    for r in out:
        r['matched'] = ['title']
    return out


_RESOLVE_FIELDS = ('title', 'year', 'anidb_id', 'tvdb_id', 'imdb_id', 'tmdb_id', 'anilist_id', 'mal_id')


def resolve(con, title=None, year=None, tvdb_id=None, imdb_id=None, tmdb_id=None,
            anilist_id=None, mal_id=None, anidb_id=None, movie=False):
    """Same contract as anime_data.resolve: one match as a dict (title, year, every id, sources) or None.
    Ids are tried in order anidb, anilist, mal, tvdb, tmdb, imdb. When any id is given and none matches,
    the result is None (no title fallback). Title fallback needs an exact title or English title match;
    several matches are narrowed by year, and ambiguity gives None."""
    ensure(con)
    kind = 'movie' if movie else 'show'
    id_pairs = [('tvdb_id', tvdb_id), ('tmdb_id', tmdb_id),
                ('anidb_id', anidb_id), ('anilist_id', anilist_id), ('mal_id', mal_id),
                ('imdb_id', imdb_id)]
    given = [(c, v) for c, v in id_pairs if v not in (None, '')]
    rows = []
    if given:
        for col, val in given:
            value = str(val).strip() if col == 'imdb_id' else _int(val)
            if value is None:
                continue
            cur = con.execute('SELECT * FROM media WHERE kind=? AND %s=? ORDER BY id' % col, (kind, value))
            rows = _rows(cur)
            if not rows:  # an id belongs to one title; the other kind is a fallback
                cur = con.execute('SELECT * FROM media WHERE %s=? ORDER BY id' % col, (value,))
                rows = _rows(cur)
            if rows:
                break
        if not rows:
            return None
    elif title:
        for k in (kind, 'movie' if kind == 'show' else 'show'):   # a title may be a movie
            cur = con.execute('SELECT * FROM media WHERE kind=? AND (lower(title)=? OR lower(title_en)=?) ORDER BY id',
                              (k, str(title).lower(), str(title).lower()))
            rows = _rows(cur)
            if rows:
                break
        if year and len(rows) > 1:
            rows = [r for r in rows if r.get('year') == _int(year)] or rows
        if len(rows) != 1:
            return None
    else:
        return None
    row = rows[0]
    out = {f: row.get(f) for f in _RESOLVE_FIELDS}
    out['sources'] = {f: row.get('sources') for f in _RESOLVE_FIELDS[2:] if row.get(f) is not None}
    return out


def _show_id_for_tmdb(con, tmdb, source):
    return upsert(con, 'show', {'kind': 'show', 'tmdb_id': tmdb}, source, link='any')


def ingest_catalog(con, records, source):
    """Catalog records from helpers (see CONTRACT.md). Shows and movies link by any shared id; episodes belong
    to their show and merge on a shared episode id. Returns counts per kind."""
    ensure(con)
    counts = {'show': 0, 'movie': 0, 'episode': 0}
    touched = set()
    for rec in records:
        kind = rec.get('kind')
        if kind == 'episode':
            show_key = {'tmdb_id': rec.get('show_tmdb_id'), 'tvdb_id': rec.get('show_tvdb_id'),
                        'imdb_id': rec.get('show_imdb_id')}
            show_rec = {k: v for k, v in show_key.items() if v is not None}
            show_rec.update({'kind': 'show', 'extra': rec.get('show_extra') or {}})
            if show_rec.get('tmdb_id') is None and show_rec.get('tvdb_id') is None and show_rec.get('imdb_id') is None:
                continue
            show_id = upsert(con, 'show', show_rec, source, link='any')
            touched.add(show_id)
            upsert(con, 'episode', {
                'season': rec.get('season'), 'number': rec.get('number'), 'tvdb_id': rec.get('tvdb_id'),
                'tmdb_id': rec.get('tmdb_id'), 'numbering': rec.get('numbering') or 'tmdb',
                'title': rec.get('title'), 'air_date': rec.get('air_date'), 'ep_type': rec.get('ep_type'),
                'extra': rec.get('extra') or {}}, source, show_id=show_id)
        else:
            row = {k: rec.get(k) for k in ('title', 'year', 'tmdb_id', 'imdb_id', 'tvdb_id', 'anidb_id',
                                           'anilist_id', 'mal_id') if rec.get(k) is not None}
            row['extra'] = rec.get('extra') or {}
            if not any(row.get(c) for c in ID_COLS) and not row['extra']:
                continue
            upsert(con, kind, row, source, link='any')
        counts[kind] = counts.get(kind, 0) + 1
    counts['touched'] = sorted(touched)
    counts['attached'] = attach_orphans(con)
    return counts


def name_from_nightwatch(con, title, source='nightwatch', **keys):
    """Nightwatch passes a title and at least one key. Find the rows by key and fill an empty title.
    No key match: a new row is added. Returns the row ids touched."""
    ensure(con)
    key = next(((k, v) for k, v in keys.items() if v not in (None, '') and k in NAMESPACES_COL), None)
    if key is None:
        raise ValueError('nightwatch needs at least one key')
    rows = find(con, '%s:%s' % (NAMESPACES_COL[key[0]], key[1]))
    if not rows:
        kind = keys.pop('kind', 'show')
        row_id = upsert(con, kind, dict(keys, title=title), source)
        return [row_id]
    touched = []
    for r in rows:
        if not r.get('title'):
            con.execute('UPDATE media SET title=? WHERE id=?', (title, r['id']))
        touched.append(r['id'])
    return touched



def open_db(path=None):
    """Open the single WatchVault database (unified media store)."""
    import os
    import sqlite3
    if path is None:
        try:
            import watchvault as wv
            path = wv.db_path()
        except Exception:
            path = os.path.join(os.path.expanduser('~'), '.watchvault', 'watchvault.db')
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    con = sqlite3.connect(path)
    ensure(con)
    return con


def set_watched(con, kind, rec, watched=True, source=None, played_at=None,
                runtime=None, remaining=None, show_id=None):
    """Upsert the media row, then set watch state. kind is movie or episode (shows are not marked watched).
    Returns row id."""
    if kind not in ('movie', 'episode'):
        raise ValueError('set_watched only for movie or episode')
    row_id = upsert(con, kind, rec, source or 'local', show_id=show_id)
    watched = 1 if watched else 0
    if watched:
        con.execute(
            'UPDATE media SET watched=1, play_count=COALESCE(play_count,0)+1, last_watched=?,'
            ' runtime=COALESCE(?, runtime), remaining=COALESCE(?, remaining), play_source=COALESCE(?, play_source)'
            ' WHERE id=?',
            (played_at, runtime, remaining, source, row_id),
        )
    else:
        con.execute(
            'UPDATE media SET watched=0, play_count=0, last_watched=NULL, remaining=NULL,'
            ' runtime=COALESCE(?, runtime), play_source=? WHERE id=?',
            (runtime, source, row_id),
        )
    return row_id


def is_watched_row(con, kind=None, tvdb_id=None, tmdb_id=None, imdb_id=None,
                   anilist_id=None, mal_id=None, season=None, number=None, show_tmdb_id=None, show_tvdb_id=None):
    """True when a matching movie/episode row has watched=1."""
    ensure(con)
    if kind == 'movie' or (season is None and number is None):
        parts, args = [], []
        for col, val in (('tmdb_id', tmdb_id), ('tvdb_id', tvdb_id), ('imdb_id', imdb_id),
                         ('anilist_id', anilist_id), ('mal_id', mal_id)):
            if val not in (None, ''):
                parts.append('%s=?' % col)
                args.append(val if col != 'imdb_id' else str(val))
        if not parts:
            return False
        sql = 'SELECT watched FROM media WHERE kind="movie" AND (%s) ORDER BY id LIMIT 1' % ' OR '.join(parts)
        row = con.execute(sql, args).fetchone()
        return bool(row and row[0])
    # episode: resolve show then season/number
    show_parts, show_args = [], []
    for col, val in (('tmdb_id', show_tmdb_id or tmdb_id), ('tvdb_id', show_tvdb_id or tvdb_id),
                     ('imdb_id', imdb_id), ('anilist_id', anilist_id), ('mal_id', mal_id)):
        if val not in (None, '') and col != 'imdb_id' or (col == 'imdb_id' and val):
            if val in (None, ''):
                continue
            show_parts.append('%s=?' % col)
            show_args.append(val if col != 'imdb_id' else str(val))
    if not show_parts or season is None or number is None:
        return False
    show = con.execute(
        'SELECT id FROM media WHERE kind="show" AND (%s) ORDER BY id LIMIT 1' % ' OR '.join(show_parts),
        show_args,
    ).fetchone()
    if not show:
        # try episode-level ids
        ep = con.execute(
            'SELECT watched FROM media WHERE kind="episode" AND season=? AND number=? AND '
            '(tmdb_id=? OR tvdb_id=?) LIMIT 1',
            (season, number, tmdb_id, tvdb_id),
        ).fetchone()
        return bool(ep and ep[0])
    row = con.execute(
        'SELECT watched FROM media WHERE kind="episode" AND show_id=? AND season=? AND number=? LIMIT 1',
        (show[0], season, number),
    ).fetchone()
    return bool(row and row[0])


def list_watched(con):
    """All watched movie and episode rows (for provider export helpers)."""
    ensure(con)
    cur = con.execute(
        'SELECT * FROM media WHERE watched=1 AND kind IN ("movie","episode") ORDER BY kind, id'
    )
    return _rows(cur)


def watched_for_providers(con):
    """Shape used by provider_sync: shows with seasons/episodes + movies, ids tvdb-first."""
    ensure(con)
    movies_out = []
    shows = {}  # show_id -> structure
    for row in list_watched(con):
        if row['kind'] == 'movie':
            ids = {}
            if row.get('tvdb_id'):
                ids['tvdb'] = row['tvdb_id']
            if row.get('tmdb_id'):
                ids['tmdb'] = row['tmdb_id']
            if row.get('imdb_id'):
                ids['imdb'] = row['imdb_id']
            if row.get('mal_id'):
                ids['mal'] = row['mal_id']
            if row.get('anilist_id'):
                ids['anilist'] = row['anilist_id']
            movies_out.append({'ids': ids, 'title': row.get('title'), 'year': row.get('year')})
            continue
        sid = row.get('show_id')
        if sid not in shows:
            show = con.execute('SELECT * FROM media WHERE id=?', (sid,)).fetchone()
            if not show:
                continue
            cols = [d[0] for d in con.execute('SELECT * FROM media LIMIT 0').description]
            show = dict(zip(cols, show))
            ids = {}
            if show.get('tvdb_id'):
                ids['tvdb'] = show['tvdb_id']
            if show.get('tmdb_id'):
                ids['tmdb'] = show['tmdb_id']
            if show.get('imdb_id'):
                ids['imdb'] = show['imdb_id']
            if show.get('mal_id'):
                ids['mal'] = show['mal_id']
            if show.get('anilist_id'):
                ids['anilist'] = show['anilist_id']
            shows[sid] = {
                'ids': ids,
                'title': show.get('title'),
                'year': show.get('year'),
                'seasons': {},
            }
        seasons = shows[sid]['seasons']
        sn = row.get('season')
        seasons.setdefault(sn, []).append({'number': row.get('number')})
    shows_out = []
    for s in shows.values():
        season_list = [{'number': n, 'episodes': eps} for n, eps in sorted(s['seasons'].items(), key=lambda x: (x[0] is None, x[0]))]
        shows_out.append({'ids': s['ids'], 'title': s['title'], 'year': s['year'], 'seasons': season_list})
    return {'shows': shows_out, 'movies': movies_out}


# ---- reference format: every id is written as "namespace:value" (anilist:1412, mal:1412, tvdb:71863, ...) ----
REF_NAMESPACES = tuple(NAMESPACES) + ('kitsu', 'anime_planet', 'anisearch')


def format_ref(namespace, value):
    """'tvdb', 71863 -> 'tvdb:71863'. Used in lookups, logs and the contract."""
    ns = str(namespace).lower()
    if ns not in REF_NAMESPACES:
        raise ValueError('unknown id namespace: %s' % namespace)
    return '%s:%s' % (ns, str(value).strip())


def parse_ref(text):
    """'tvdb:71863' -> ('tvdb', '71863'). A bare number gives (None, '71863') and is ambiguous across namespaces."""
    text = str(text).strip()
    if ':' in text:
        ns, value = text.split(':', 1)
        ns = ns.strip().lower()
        if ns not in REF_NAMESPACES:
            raise ValueError('unknown id namespace: %s' % ns)
        return ns, value.strip()
    return None, text


def describe(con, ref):
    """Every row a reference points at, with the rows' titles and their refs. Use it to check a match by hand.
    Returns {'ref': ..., 'count': n, 'rows': [{'title', 'year', 'kind', 'refs': [...]}]}."""
    rows = find(con, ref)
    out = []
    for r in rows:
        refs = [format_ref(ns, r[col]) for ns, col in NAMESPACES.items()
                if r.get(col) is not None]
        refs += ['%s:%s' % (k, v) for k, v in (r.get('extra_ids') or {}).items()]
        out.append({'title': r.get('title'), 'year': r.get('year'), 'kind': r.get('kind'), 'refs': refs})
    return {'ref': ref, 'count': len(out), 'rows': out}


def attach_to_series(con, series_id):
    """Make the show and movie rows of one series children of its series row (parent_id). A show belongs when it
    shares the series' TVDB or TMDb id; a movie when it shares the TVDB id. Returns how many rows were attached."""
    ensure(con)
    tvdb, tmdb = con.execute('SELECT tvdb_id, tmdb_id FROM media WHERE id=?', (series_id,)).fetchone()
    n = 0
    if tvdb is not None:
        cur = con.execute('UPDATE media SET parent_id=? WHERE parent_id IS NULL AND kind IN ("show","movie") '
                          'AND (tvdb_id=? OR (kind="show" AND tmdb_id=?))', (series_id, tvdb, tmdb))
        n += cur.rowcount
    elif tmdb is not None:
        cur = con.execute('UPDATE media SET parent_id=? WHERE parent_id IS NULL AND kind="show" AND tmdb_id=?',
                          (series_id, tmdb))
        n += cur.rowcount
    return n


def children(con, series_id):
    """The show and movie rows of a series, in release order."""
    cur = con.execute('SELECT * FROM media WHERE parent_id=? ORDER BY year, id', (series_id,))
    return _rows(cur)


def attach_orphans(con):
    """Attach every show or movie without a parent to its series row: a show by a shared TVDB or TMDb id, a movie
    by a shared TVDB id. Loops over the series rows (few) and uses the id indexes. Returns the rows attached."""
    ensure(con)
    n = 0
    for sid, tvdb, tmdb in con.execute('SELECT id, tvdb_id, tmdb_id FROM media WHERE kind="series"').fetchall():
        if tvdb is not None:
            n += con.execute('UPDATE media SET parent_id=? WHERE parent_id IS NULL AND kind="show" '
                             'AND (tvdb_id=? OR tmdb_id=?)', (sid, tvdb, tmdb)).rowcount
            n += con.execute('UPDATE media SET parent_id=? WHERE parent_id IS NULL AND kind="movie" '
                             'AND tvdb_id=?', (sid, tvdb)).rowcount
        elif tmdb is not None:
            n += con.execute('UPDATE media SET parent_id=? WHERE parent_id IS NULL AND kind="show" '
                             'AND tmdb_id=?', (sid, tmdb)).rowcount
    return n


_FOLD_FIELDS = ('title', 'title_en', 'year', 'tvdb_id', 'tmdb_id', 'imdb_id', 'anilist_id', 'mal_id',
                'tvdb_season', 'tvdb_epoffset', 'numbering', 'meta', 'parent_id')


def _fold(con, keep_id, drop_id):
    """Move everything from drop_id onto keep_id, then delete drop_id."""
    for col in _FOLD_FIELDS:
        con.execute('UPDATE media SET %s = COALESCE(%s, (SELECT %s FROM media WHERE id=?)) WHERE id=?'
                    % (col, col, col), (drop_id, keep_id))
    keep_extra = json.loads(con.execute('SELECT extra_ids FROM media WHERE id=?', (keep_id,)).fetchone()[0] or '{}')
    drop_extra = json.loads(con.execute('SELECT extra_ids FROM media WHERE id=?', (drop_id,)).fetchone()[0] or '{}')
    merged = dict(drop_extra)
    merged.update(keep_extra)
    con.execute('UPDATE media SET extra_ids=? WHERE id=?', (json.dumps(merged, sort_keys=True) if merged else None, keep_id))
    keep_src = set(filter(None, (con.execute('SELECT sources FROM media WHERE id=?', (keep_id,)).fetchone()[0] or '').split(',')))
    drop_src = set(filter(None, (con.execute('SELECT sources FROM media WHERE id=?', (drop_id,)).fetchone()[0] or '').split(',')))
    con.execute('UPDATE media SET sources=? WHERE id=?', (','.join(sorted(keep_src | drop_src)), keep_id))
    con.execute('UPDATE media SET show_id=? WHERE show_id=?', (keep_id, drop_id))
    con.execute('UPDATE media SET parent_id=? WHERE parent_id=?', (keep_id, drop_id))
    con.execute('DELETE FROM season WHERE show_id=? AND (number, order_type) IN '
                '(SELECT number, order_type FROM season WHERE show_id=?)', (drop_id, keep_id))
    con.execute('UPDATE season SET show_id=? WHERE show_id=?', (keep_id, drop_id))
    con.execute('DELETE FROM ref_index WHERE media_id=?', (drop_id,))
    _index_extras(con, keep_id, merged)
    con.execute('DELETE FROM media WHERE id=?', (drop_id,))


def consolidate_anime(con):
    """Fold rows that describe the same anime. A row without an AniDB id joins the row that has one when they share
    an AniList or MAL id and their ids do not conflict. Rows that hold different AniDB ids are source conflicts and
    are left alone. Returns the number of rows folded."""
    ensure(con)
    folded = 0
    for _pass in range(3):
        changed = 0
        for col in ('mal_id', 'anilist_id'):
            values = [r[0] for r in con.execute(
                'SELECT %s FROM media WHERE kind IN ("show","movie") AND %s IS NOT NULL GROUP BY %s HAVING COUNT(*)>1'
                % (col, col, col)).fetchall()]
            for val in values:
                rows = [dict(zip(('id', 'anidb_id', 'anilist_id', 'mal_id'), r)) for r in con.execute(
                    'SELECT id, anidb_id, anilist_id, mal_id FROM media WHERE kind IN ("show","movie") AND %s=? '
                    'ORDER BY id' % col, (val,)).fetchall()]
                owners = [r for r in rows if r['anidb_id'] is not None]
                if len({o['anidb_id'] for o in owners}) != 1:
                    continue           # no owner, or several owners with different AniDB ids: a conflict
                owner = owners[0]
                for r in rows:
                    if r['id'] == owner['id'] or r['anidb_id'] is not None:
                        continue
                    if any(r[k] is not None and owner[k] is not None and r[k] != owner[k]
                           for k in ('anilist_id', 'mal_id')):
                        continue
                    _fold(con, owner['id'], r['id'])
                    folded += 1
                    changed += 1
        if not changed:
            break
    return folded
