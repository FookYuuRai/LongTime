# -*- coding: utf-8 -*-
"""One-time (on demand) import of watched history into WatchVault from MDBList, Trakt, Simkl or PunchPlay.
Adds only: items WatchVault already has as watched are skipped and nothing is marked unwatched.
Each provider's watches are stored with that provider's name as the source, so the sync echo guard
never sends them back to the provider they came from."""
import threading

import xbmc

import episode_map
import fullscreen
import login_flow
import provider_sync as ps
import watchvault as wv

LABELS = {'mdblist': 'MDBList', 'trakt': 'Trakt', 'simkl': 'Simkl', 'punchplay': 'PunchPlay'}
_running = {'busy': False}


def _ts(value):
    """Provider dates -> WatchVault's format (UTC, 'YYYY-MM-DDTHH:MM:SSZ'); None lets WatchVault use now."""
    if not value:
        return None
    try:
        from datetime import datetime
        return datetime.strptime(str(value)[:19], '%Y-%m-%dT%H:%M:%S').strftime('%Y-%m-%dT%H:%M:%SZ')
    except Exception:
        return None


def _num(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _movie(title, year, tmdb, imdb, tvdb, played, mal=None, anilist=None):
    return {'kind': 'movie', 'title': title, 'year': year, 'tmdb_id': tmdb, 'imdb_id': imdb,
            'tvdb_id': tvdb, 'mal_id': _num(mal), 'anilist_id': _num(anilist), 'played_at': played}


def _episode(show, season, number, ep_tmdb, ep_tvdb, numbering, played, ep_title=None):
    return {'kind': 'episode', 'title': show.get('title'), 'year': show.get('year'),
            'tvdb_id': show.get('tvdb'), 'imdb_id': show.get('imdb'), 'tmdb_id': show.get('tmdb'),
            'mal_id': _num(show.get('mal')), 'anilist_id': _num(show.get('anilist')),
            'season': season, 'episode': number, 'ep_tmdb': ep_tmdb, 'ep_tvdb': ep_tvdb,
            'numbering': numbering, 'played_at': played, 'ep_title': ep_title}


def _normalize(provider, kind, row):
    """Yield normalized movie/episode records from one raw row of a provider's history."""
    if provider == 'mdblist':
        if kind == 'movie':
            m = row.get('movie') or {}
            ids = m.get('ids') or {}
            yield _movie(m.get('title'), m.get('year'), ids.get('tmdb'), ids.get('imdb'), None,
                         _ts(row.get('watched_at')))
            return
        ep = row.get('episode') or {}
        sh = ep.get('show') or {}
        show = {'title': sh.get('title'), 'year': sh.get('year'), 'tvdb': (sh.get('ids') or {}).get('tvdb'),
                'imdb': (sh.get('ids') or {}).get('imdb'), 'tmdb': (sh.get('ids') or {}).get('tmdb')}
        eids = ep.get('ids') or {}
        tv = ep.get('tvdb') if isinstance(ep.get('tvdb'), dict) else {}
        tv_ids = ep.get('tvdb_ids') if isinstance(ep.get('tvdb_ids'), dict) else {}
        # Which episode: TVDB official order when MDBList sends it, otherwise the default order.
        # Either way the watch is stored in TMDb numbering (what Nightshift's next-episode logic checks),
        # taken from the same row, so TVDB numbers are never written.
        order = 'tvdb' if (tv.get('season_number') is not None and tv.get('episode_number') is not None) else 'default'
        season, number = ep.get('season'), ep.get('number')
        # The episode's TVDB id is ids.tvdb. tvdb_ids.episode is the episode NUMBER (tvdb=11 for episode 11),
        # so it is never used as an id.
        rec = _episode(show, season, number, eids.get('tmdb'), eids.get('tvdb'),
                       'tmdb', _ts(row.get('last_watched_at') or row.get('watched_at')), ep.get('name'))
        rec['order'] = order
        rec['raw_ids'] = eids
        rec['raw_tvdb_ids'] = tv_ids
        yield rec
        return
    if provider == 'trakt':
        played = _ts(row.get('watched_at'))
        if row.get('type') == 'movie':
            m = row.get('movie') or {}
            ids = m.get('ids') or {}
            yield _movie(m.get('title'), m.get('year'), ids.get('tmdb'), ids.get('imdb'), ids.get('tvdb'), played)
        elif row.get('type') == 'episode':
            s = row.get('show') or {}
            sids = s.get('ids') or {}
            e = row.get('episode') or {}
            eids = e.get('ids') or {}
            show = {'title': s.get('title'), 'year': s.get('year'), 'tvdb': sids.get('tvdb'),
                    'imdb': sids.get('imdb'), 'tmdb': sids.get('tmdb')}
            # Trakt numbering is not verified as TMDb; the record is kept only to be skipped (never written).
            yield _episode(show, e.get('season'), e.get('number'), eids.get('tmdb'), eids.get('tvdb'),
                           'unverified', played, e.get('title'))
        return
    if provider == 'punchplay':
        played = _ts(row.get('watchedAt'))
        if row.get('type') == 'movie':
            yield _movie(row.get('title'), row.get('year'), row.get('tmdbId'), None, None, played)
        elif row.get('type') == 'episode' and row.get('showTmdbId'):
            season = row.get('sourceSeason') if row.get('sourceSeason') is not None else row.get('season')
            number = row.get('sourceEpisode') if row.get('sourceEpisode') is not None else row.get('episode')
            show = {'title': row.get('title'), 'year': row.get('year'), 'tmdb': row.get('showTmdbId')}
            yield _episode(show, season, number, row.get('tmdbId'), None, 'tmdb', played, row.get('episodeTitle'))
        return
    if provider == 'simkl':
        ids = row.get('ids') or {}
        if kind == 'movie':
            yield _movie(row.get('title'), row.get('year'), ids.get('tmdb'), ids.get('imdb'), ids.get('tvdb'),
                         _ts(row.get('last_watched_at')), ids.get('mal'), ids.get('anilist'))
            return
        show = {'title': row.get('title'), 'year': row.get('year'), 'tvdb': ids.get('tvdb'),
                'imdb': ids.get('imdb'), 'tmdb': ids.get('tmdb'), 'mal': ids.get('mal'),
                'anilist': ids.get('anilist')}
        for season in row.get('seasons') or []:
            for ep in season.get('episodes') or []:
                if not ep.get('watched_at'):
                    continue            # only episodes Simkl reports as watched
                eids = ep.get('ids') or {}
                yield _episode(show, season.get('number'), ep.get('number'), eids.get('tmdb'),
                               eids.get('tvdb') or eids.get('tvdb_id'), 'unverified',
                               _ts(ep.get('watched_at')), ep.get('title'))
        return


READERS = {'mdblist': ps.mdblist_watched_rows, 'trakt': ps.trakt_history_rows,
           'simkl': ps.simkl_watched_rows, 'punchplay': ps.punchplay_history_rows}


def _addon_str(name):
    try:
        import xbmcaddon
        return (xbmcaddon.Addon().getSettingString(name) or '').strip()
    except Exception:
        return ''


def _resolve_by_map(rec):
    """Episode with a TVDB episode id -> (season, number) in TMDb numbering, through the stored TVDB->TMDb map.
    The map is built once per show (TVDB episode list + TMDb episode list); later lookups use the database only."""
    tvdb_show, tvdb_ep = rec.get('tvdb_id'), rec.get('ep_tvdb')
    if not tvdb_show or not tvdb_ep:
        return None
    tvdb_key = wv._tvdb_settings()[0]
    tvdb_pin = wv._tvdb_settings()[1]
    tmdb_key = _addon_str('tmdb_api')
    with wv.db() as con:
        episode_map.ensure_tables(con)
        if not episode_map.build_for_show(con, tvdb_show, tvdb_key, tvdb_pin, tmdb_key,
                                          tmdb_show=rec.get('tmdb_id')):
            return None
        return episode_map.lookup(con, tvdb_show, tvdb_ep)


def _log(msg):
    xbmc.log('[WatchVault import] %s' % msg, xbmc.LOGINFO)


def _label(rec):
    if rec['kind'] == 'movie':
        return 'movie %r (%s) tmdb=%s imdb=%s' % (rec.get('title'), rec.get('year'), rec.get('tmdb_id'), rec.get('imdb_id'))
    return 'episode %r S%sE%s [%s] show tmdb=%s tvdb=%s episode tmdb=%s tvdb=%s' % (
        rec.get('title'), rec.get('season'), rec.get('episode'), rec.get('order') or rec.get('numbering'),
        rec.get('tmdb_id'), rec.get('tvdb_id'), rec.get('ep_tmdb'), rec.get('ep_tvdb'))


def _skip(provider, rec, counts, reason):
    counts['skipped'] += 1
    reasons = counts.setdefault('reasons', {})
    reasons[reason] = reasons.get(reason, 0) + 1
    _log('%s %s: skipped, %s' % (provider, _label(rec), reason))


def _added(provider, rec, counts, kind):
    counts[kind] += 1
    _log('%s %s: added' % (provider, _label(rec)))


def _apply(provider, rec, counts, con=None):
    # Always keep unified media in sync (single store).
    sid = None
    try:
        import unified
        with wv._use(con) as con:
            unified.ensure(con)
            if rec['kind'] == 'movie':
                unified.upsert(con, 'movie', {
                    'kind': 'movie', 'title': rec.get('title'), 'year': rec.get('year'),
                    'tmdb_id': rec.get('tmdb_id'), 'tvdb_id': rec.get('tvdb_id'),
                    'imdb_id': rec.get('imdb_id'), 'mal_id': rec.get('mal_id'),
                    'anilist_id': rec.get('anilist_id'),
                }, provider, link='any')
            else:
                sid = unified.upsert(con, 'show', {
                    'kind': 'show', 'title': rec.get('title'), 'year': rec.get('year'),
                    'tmdb_id': rec.get('tmdb_id'), 'tvdb_id': rec.get('tvdb_id'),
                    'imdb_id': rec.get('imdb_id'), 'mal_id': rec.get('mal_id'),
                    'anilist_id': rec.get('anilist_id'),
                }, provider, link='any')
                unified.upsert(con, 'episode', {
                    'kind': 'episode', 'season': rec.get('season'), 'number': rec.get('episode'),
                    'tmdb_id': rec.get('ep_tmdb'), 'tvdb_id': rec.get('ep_tvdb'),
                    'numbering': rec.get('numbering') or 'tmdb', 'title': rec.get('ep_title'),
                }, provider, show_id=sid)
    except Exception as exc:
        xbmc.log('[WatchVault store] write failed for %s: %s' % (provider, exc), xbmc.LOGERROR)
        counts['store_errors'] = counts.get('store_errors', 0) + 1
    if sid is not None:
        counts.setdefault('touched', set()).add(sid)
    if rec['kind'] == 'movie':
        if not (rec.get('tmdb_id') or rec.get('imdb_id')):
            return _skip(provider, rec, counts, 'no TMDb or IMDb id')
        kw = dict(title=rec.get('title'), year=rec.get('year'), tmdb_id=rec.get('tmdb_id'), imdb_id=rec.get('imdb_id'),
                  mal_id=rec.get('mal_id'), anilist_id=rec.get('anilist_id'))
        watched, where = wv._watched_reason(con=con, **kw)
        if watched:
            return _skip(provider, rec, counts, 'already watched (%s store)' % where)
        try:
            res = wv.mark_watched(watched=True, source=provider, played_at=rec.get('played_at'), notify=False,
                                  con=con, **kw)
        except Exception as exc:
            return _skip(provider, rec, counts, 'error writing: %s' % exc)
        if not res or res.get('ok') is False:
            return _skip(provider, rec, counts, 'write refused: %s' % ((res or {}).get('error') or 'no result'))
        return _added(provider, rec, counts, 'movies')
    if rec.get('season') is None or rec.get('episode') is None or \
            not (rec.get('tvdb_id') or rec.get('imdb_id') or rec.get('tmdb_id')):
        return _skip(provider, rec, counts, 'no season, episode or show id')
    if rec['numbering'] != 'tmdb':
        if con is not None:
            con.commit()        # _resolve_by_map opens its own connection
        resolved = _resolve_by_map(rec)
        if resolved is None:
            counts['unverified'] += 1
            _log('%s %s: not verified, no TVDB to TMDb map, not written' % (provider, _label(rec)))
            return None
        rec['season'], rec['episode'] = resolved
        rec['numbering'], rec['order'] = 'tmdb', 'map'
    counts[{'tvdb': 'tvdb_order', 'map': 'by_map'}.get(rec.get('order'), 'default_order')] += 1
    kw = dict(title=rec.get('title'), year=rec.get('year'), tvdb_id=rec.get('tvdb_id'),
              imdb_id=rec.get('imdb_id'), tmdb_id=rec.get('tmdb_id'),
              mal_id=rec.get('mal_id'), anilist_id=rec.get('anilist_id'))
    ids = dict(episode_tmdb_id=rec.get('ep_tmdb'), episode_tvdb_id=rec.get('ep_tvdb'))
    if counts.get('raw_logged', 0) < 3:
        counts['raw_logged'] = counts.get('raw_logged', 0) + 1
        _log('%s raw ids for %s: ids=%s tvdb_ids=%s' % (provider, _label(rec), rec.get('raw_ids'), rec.get('raw_tvdb_ids')))
    watched, where = wv._watched_reason(season=rec['season'], episode=rec['episode'], strict=True, con=con,
                                        **dict(ids, **kw))
    if watched:
        return _skip(provider, rec, counts, 'already watched (%s store)' % where)
    try:
        res = wv.mark_watched(season=rec['season'], episode=rec['episode'], watched=True, source=provider,
                              played_at=rec.get('played_at'), episode_title=rec.get('ep_title'),
                              notify=False, strict=True, con=con, **dict(ids, **kw))
    except Exception as exc:
        return _skip(provider, rec, counts, 'error writing: %s' % exc)
    if not res or res.get('ok') is False:
        return _skip(provider, rec, counts, 'write refused: %s' % ((res or {}).get('error') or 'no result'))
    return _added(provider, rec, counts, 'episodes')


def _pair_touched(touched):
    """Pair episodes that carry only one provider's id, for each show this import touched."""
    if not touched:
        return 0
    import sqlite3
    from helpers import series
    paired = 0
    with wv.db() as con:
        for sid in sorted(touched):
            paired += series.link_episodes(con, sid)
        con.commit()
    return paired


def _progress(label, counts):
    fullscreen.update_notice(label + ' import', 'Importing watched history...\n\n'
                             'Added: %d movies, %d episodes\nAlready watched or not matched: %d\n'
                             'Order: TVDB official %d, default %d. Not verified (skipped): %d'
                             % (counts['movies'], counts['episodes'], counts['skipped'],
                                counts['tvdb_order'], counts['default_order'], counts['unverified']))


def run(provider):
    label = LABELS[provider]
    heading = label + ' import'
    counts = {'movies': 0, 'episodes': 0, 'skipped': 0, 'unverified': 0, 'tvdb_order': 0, 'default_order': 0,
              'by_map': 0, 'reasons': {}}
    fullscreen.close_modal_settings()
    fullscreen.show_notice(heading, 'Starting import from %s...' % label)
    before = wv.store_counts()
    _log('%s import started (adds only). Watched before: %s' % (label, before))
    n = 0
    text = ''
    try:
        # Read every page first (network only, no write lock held), then write everything in one run:
        # one connection, committed in batches. Nightshift's MDBList sync does the same (read all, then bulk write).
        rows = list(READERS[provider]())
        _log('%s read %d rows; writing' % (label, len(rows)))
        with wv.db() as con:
            for kind, row in rows:
                for rec in _normalize(provider, kind, row):
                    try:
                        _apply(provider, rec, counts, con)
                    except Exception as exc:
                        _skip(provider, rec, counts, 'error: %s' % exc)
                n += 1
                if n % 500 == 0:
                    con.commit()
                    _progress(label, counts)
                    _log('%s progress: %d rows, %d episodes and %d movies added, %d skipped'
                         % (label, n, counts['episodes'], counts['movies'], counts['skipped']))
        text = ('Done. Added %d movies and %d episodes.\nAlready watched or not matched: %d.\n'
                'Order used: TVDB official %d, default %d, by TVDB map %d. Not verified (skipped): %d.'
                % (counts['movies'], counts['episodes'], counts['skipped'],
                   counts['tvdb_order'], counts['default_order'], counts['by_map'], counts['unverified']))
    except Exception as e:
        xbmc.log('[WatchVault import] %s stopped: %s' % (provider, e), xbmc.LOGWARNING)
        _log('%s import stopped after %d rows: %s' % (label, n, e))
        text = ('Import stopped: %s\nAdded so far: %d movies, %d episodes. Run it again later to finish.'
                % (e, counts['movies'], counts['episodes']))
    if provider == 'mdblist':
        try:
            _log('%s in-progress rows: %d' % (label, ps.mdblist_pull_playback()))
        except Exception as exc:
            _log('%s in-progress import failed: %s' % (label, exc))
    try:
        paired = _pair_touched(counts.pop('touched', set()))
        import unified as _unified
        with wv.db() as _c:
            _unified.ensure(_c)
            _unified.attach_orphans(_c)
            _c.commit()
        text += ' Episodes paired across providers: %d.' % paired
    except Exception as exc:
        xbmc.log('[WatchVault import] pairing failed: %s' % exc, xbmc.LOGWARNING)
        _log('%s pairing failed: %s' % (label, exc))
    reasons = counts.get('reasons') or {}
    why = ', '.join('%s %d' % (k, v) for k, v in sorted(reasons.items(), key=lambda kv: -kv[1])) or 'none'
    _log('%s import finished: %d rows read, %d episodes and %d movies added, %d skipped, %d not verified. '
         'Skip reasons: %s' % (label, n, counts['episodes'], counts['movies'], counts['skipped'],
                               counts['unverified'], why))
    _log('%s watched after: %s' % (label, wv.store_counts()))
    text += '\nSkipped: %s. Per-item detail: Kodi log, [WatchVault import].' % why
    login_flow._finish(heading, text)
    _running['busy'] = False

def tick():
    """Called once a second by the service. Starts a queued import in its own thread."""
    raw = login_flow._win().getProperty('watchvault.job') or ''
    if not raw.startswith('import:') or _running['busy']:
        return
    provider = raw.split(':', 1)[1]
    login_flow._win().clearProperty('watchvault.job')
    if provider not in READERS:
        return
    _running['busy'] = True
    threading.Thread(target=run, args=(provider,), daemon=True).start()


def request(provider):
    """Called by the plugin when an import button is pressed."""
    login_flow._win().setProperty('watchvault.job', 'import:' + provider)


def import_file(provider, path):
    """Parse a provider export file via helpers, merge catalog into the store, write watches add-only."""
    import os
    import sqlite3
    import anime_data
    import unified

    if not path or not os.path.exists(path):
        return {'ok': False, 'error': 'file not found'}
    if provider == 'mdblist':
        from helpers import mdblist as helper
    elif provider == 'trakt':
        from helpers import trakt as helper
    elif provider == 'simkl':
        from helpers import simkl as helper
    else:
        return {'ok': False, 'error': 'no file helper for %s' % provider}

    parsed = helper.parse(path)
    catalog = parsed.get('catalog') or []
    watches = parsed.get('watches') or []

    # catalog -> unified media rows (incremental merge)
    try:
        up = anime_data.unified_path()
        os.makedirs(os.path.dirname(up), exist_ok=True)
        con = sqlite3.connect(up)
        unified.ensure(con)
        show_ids = {}
        for rec in catalog:
            kind = rec.get('kind')
            if kind == 'show':
                rid = unified.upsert(con, 'show', rec, provider, link='any')
                if rec.get('tmdb_id') is not None:
                    show_ids[rec['tmdb_id']] = rid
            elif kind == 'movie':
                unified.upsert(con, 'movie', rec, provider, link='any')
            elif kind == 'episode':
                show_tmdb = rec.get('show_tmdb_id')
                sid = show_ids.get(show_tmdb)
                if sid is None and show_tmdb is not None:
                    sid = unified.upsert(con, 'show', {'kind': 'show', 'tmdb_id': show_tmdb}, provider, link='any')
                    show_ids[show_tmdb] = sid
                unified.upsert(con, 'episode', rec, provider, show_id=sid)
        con.commit()
        con.close()
    except Exception as e:
        return {'ok': False, 'error': 'unified catalog: %s' % e}

    # watches -> WatchVault history through the same path as live provider import
    counts = {'movies': 0, 'episodes': 0, 'skipped': 0, 'unverified': 0, 'tvdb_order': 0,
              'default_order': 0, 'by_map': 0}
    for w in watches:
        if w.get('kind') == 'show':
            # show-level aggregate without per-episode detail: skip (episodes carry the detail)
            continue
        if w.get('kind') == 'movie':
            rec = {
                'kind': 'movie',
                'title': w.get('title') or ('TMDb %s' % (w.get('tmdb_id') or '')),
                'year': w.get('year'),
                'tmdb_id': w.get('tmdb_id'),
                'imdb_id': w.get('imdb_id'),
                'tvdb_id': w.get('tvdb_id'),
                'mal_id': w.get('mal_id'),
                'anilist_id': w.get('anilist_id'),
                'played_at': w.get('played_at'),
            }
        elif w.get('kind') == 'episode':
            rec = {
                'kind': 'episode',
                'title': w.get('title') or ('TMDb %s' % (w.get('tmdb_id') or '')),
                'year': w.get('year'),
                'tmdb_id': w.get('tmdb_id'),
                'tvdb_id': w.get('tvdb_id'),
                'imdb_id': w.get('imdb_id'),
                'mal_id': w.get('mal_id'),
                'anilist_id': w.get('anilist_id'),
                'season': w.get('season'),
                'episode': w.get('episode'),
                'ep_tmdb': w.get('ep_tmdb'),
                'ep_tvdb': w.get('ep_tvdb'),
                'numbering': w.get('numbering') or 'tmdb',
                'played_at': w.get('played_at'),
                'ep_title': w.get('ep_title'),
            }
        else:
            continue
        try:
            _apply(provider, rec, counts)
        except Exception:
            counts['skipped'] += 1
    return {
        'ok': True,
        'catalog': len(catalog),
        'watches': len(watches),
        'movies': counts['movies'],
        'episodes': counts['episodes'],
        'skipped': counts['skipped'],
        'unverified': counts['unverified'],
        'truncated': parsed.get('truncated'),
        'mode': parsed.get('mode'),
    }
