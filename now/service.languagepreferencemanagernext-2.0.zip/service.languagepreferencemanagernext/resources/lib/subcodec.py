"""
Reads the text of the embedded subtitle tracks of a Matroska (.mkv) file, for the sub converter: the events (start,
end, text) of the tracks wanted, through the file's own index (Cues) when it has one, else by walking the file.
The format of a track (which codec it is) comes from subformat.py, which the subtitle format preference needs as well.
"""
import queue
import threading
import time

from subformat import (_EBML_HEADER, _SEGMENT, _SEEK_HEAD, _SEEK, _SEEK_ID, _SEEK_POSITION, _TRACKS, _CLUSTER,
                       _TRACK_ENTRY, _TRACK_TYPE, _CODEC_ID, _CODEC_PRIVATE, _SUBTITLE_TYPE, _MAX_ELEMENTS,
                       _MAX_TRACKS_BYTES, _MAX_SEEK_HEAD_BYTES, _Reader, _vint, _header, _children, _uint, is_ass,
                       is_webvtt, format_of_codec, format_of_extension, format_of_name, SUBTITLE_FORMATS,
                       matroska_subtitle_codecs, subtitle_codecs)


class _Buffered:
    """read(n) / seek(pos) on top of a reader, fetching _CHUNK bytes at a time. The converter walks the element
    headers of the whole file (a few hundred bytes of every video / audio block); a read per header is one round
    trip each over nfs / smb / http (tens of thousands of them), a few large sequential reads are what a demuxer
    such as ffmpeg does, and as fast as the link can carry the file."""
    _CHUNK = 4 << 20

    def __init__(self, reader, chunk=None):
        self.chunk = chunk or self._CHUNK
        self.r = reader
        enable = getattr(reader, 'enable_stream', None)
        if enable:
            enable()                      # sequential reads of the whole file: one long request, not one per chunk
        self.start = 0
        self.buf = b''
        self.pos = 0

    def seek(self, pos):
        self.pos = pos

    def read(self, n):
        end = self.pos + n
        if not (self.start <= self.pos and end <= self.start + len(self.buf)):
            self.r.seek(self.pos)
            data = self.r.read(max(n, self.chunk))
            if not data:
                return b''
            self.start, self.buf = self.pos, data
        out = self.buf[self.pos - self.start:end - self.start]
        self.pos += len(out)
        return out


def is_convertible(codec):
    """True for the text subtitle formats the sub converter handles (yellow, at the top): ASS/SSA, WebVTT and SRT
    (S_TEXT/UTF8). Not the picture formats (PGS / SUP, VobSub, DVB), which hold bitmaps and would need OCR."""
    return is_ass(codec) or is_webvtt(codec) or format_of_codec(codec) == 'srt'


def is_bitmap(codec):
    c = (codec or '').upper()
    return c.startswith(('S_HDMV/PGS', 'S_VOBSUB', 'S_DVBSUB', 'S_IMAGE'))


# ---------------------------------------------------------------------------------------------------------------
# The events (text and timing) of one embedded subtitle track, for the sub converter

_INFO = 0x1549A966
_TIMESTAMP_SCALE = 0x2AD7B1
_TRACK_NUMBER = 0xD7
_CLUSTER_TIMESTAMP = 0xE7
_SIMPLE_BLOCK = 0xA3
_BLOCK_GROUP = 0xA0
_BLOCK = 0xA1
_BLOCK_DURATION = 0x9B
_DEFAULT_DURATION_MS = 3000
_CUES = 0x1C53BB6B
_CUE_POINT = 0xBB
_CUE_TIME = 0xB3
_CUE_TRACK_POSITIONS = 0xB7
_CUE_TRACK = 0xF7
_CUE_CLUSTER_POSITION = 0xF1
_CUE_RELATIVE_POSITION = 0xF0
_MAX_CUES_BYTES = 64 << 20
_PROBE_SMALL = 64 << 10          # the two reads that tell how a source answers: a small one and a large one
_PROBE_LARGE = 2 << 20
_PROBE_HUGE = 16 << 20           # a third, long read: a new connection starts slowly, so a short read under-reports the speed
_MIN_GAP = 32 << 10              # blocks closer than this are always one read
_MAX_GAP = 32 << 20
_STALL_SECONDS = 30              # no block read for this long: the source is not answering
_BLOCK_READ = 2048               # what is read for one subtitle block (a longer one is read on)
_WALK_CEILING = 15 << 20         # one long read of the whole file keeps about this on a debrid service (measured: 15 MB/s
                                 # where a 16 MB read showed 30), whatever the short probe says
_INDEX_MARGIN = 0.7              # the index method must be estimated at this share of the whole file's time, or less


def _subtitle_tracks(tracks):
    """[(track number, CodecID, CodecPrivate bytes)] of the subtitle tracks, in track order."""
    found = []
    for eid, entry in _children(tracks):
        if eid != _TRACK_ENTRY:
            continue
        number, kind, codec, private = None, None, '', b''
        for cid, payload in _children(entry):
            if cid == _TRACK_NUMBER:
                number = _uint(payload)
            elif cid == _TRACK_TYPE:
                kind = _uint(payload)
            elif cid == _CODEC_ID:
                codec = payload.decode('ascii', 'replace').rstrip('\0')
            elif cid == _CODEC_PRIVATE:
                private = payload
        if kind == _SUBTITLE_TYPE and number is not None:
            found.append((number, codec, private))
    return found


def _block(payload, track):
    """(relative timestamp in ticks, data) of a Block / SimpleBlock payload of the given track, else None."""
    number, n = _vint(payload, 0, False)
    if number != track or len(payload) < n + 3:
        return None
    rel = int.from_bytes(payload[n:n + 2], 'big', signed=True)
    return rel, payload[n + 3:]


def _read_exact(reader, size):
    """size bytes from the reader's position (fewer at the end of the file), asked for in pieces of at most 4 MB (the
    reader's max_read, when it has one)."""
    parts, got = [], 0
    piece = getattr(reader, 'max_read', 4 << 20)          # a reader that makes one request per read takes it whole
    while got < size:
        data = reader.read(min(size - got, piece))
        if not data:
            break
        parts.append(data)
        got += len(data)
    return b''.join(parts)


def _cue_entries(cues, tracks):
    """{track number: [(cluster position, position in the cluster, cue time)]} for the wanted track numbers, from
    the data of the Cues element."""
    entries = {}
    for cid, point in _children(cues):
        if cid != _CUE_POINT:
            continue
        time, found = None, []
        for pid, payload in _children(point):
            if pid == _CUE_TIME:
                time = _uint(payload)
            elif pid == _CUE_TRACK_POSITIONS:
                fields = dict(_children(payload))
                if _CUE_TRACK in fields and _CUE_CLUSTER_POSITION in fields and _CUE_RELATIVE_POSITION in fields:
                    number = _uint(fields[_CUE_TRACK])
                    if number in tracks:
                        found.append((number, _uint(fields[_CUE_CLUSTER_POSITION]), _uint(fields[_CUE_RELATIVE_POSITION])))
        for number, cluster, relative in found:
            entries.setdefault(number, []).append((cluster, relative, time))
    return entries


def _parse_cluster_head(head):
    """(length of the cluster's header, its timestamp or None) from the first bytes of a Cluster element, else None."""
    eid, n1 = _vint(head, 0, True)
    size, n2 = _vint(head, n1, False) if eid is not None else (None, 0)
    if eid != _CLUSTER or size is None:
        return None
    stamp = None
    tid, t1 = _vint(head, n1 + n2, True)
    tsize, t2 = _vint(head, n1 + n2 + t1, False) if tid is not None else (None, 0)
    if tid == _CLUSTER_TIMESTAMP and tsize is not None and tsize <= 8:
        begin = n1 + n2 + t1 + t2
        stamp = _uint(head[begin:begin + tsize])
    return n1 + n2, stamp


def _parse_block_element(head, at, number, stamp, fallback_ticks, to_ms, reader):
    """(start ms, end ms, text) of the SimpleBlock / BlockGroup of track `number` whose element starts at `head`
    (the bytes read from file position `at`; more is read through `reader` when the block is longer), or a text
    saying why it is not such a block."""
    eid, n1 = _vint(head, 0, True)
    size, n2 = _vint(head, n1, False) if eid is not None else (None, 0)
    if size is None or size < 0 or size > 16 << 20 or eid not in (_SIMPLE_BLOCK, _BLOCK_GROUP):
        return 'a place listed in the index is not a subtitle block'
    body = head[n1 + n2:n1 + n2 + size]
    if len(body) < size:
        reader.seek(at + n1 + n2 + len(body))
        body += _read_exact(reader, size - len(body))
        if len(body) < size:
            raise IOError('a subtitle block could not be read completely')
    duration = None
    if eid == _BLOCK_GROUP:
        block = None
        for cid, payload in _children(body):
            if cid == _BLOCK:
                block = payload
            elif cid == _BLOCK_DURATION:
                duration = _uint(payload)
        body = block
    parsed = _block(body, number) if body else None
    if not parsed:
        return 'a place listed in the index is not a block of subtitle track number {0}'.format(number)
    rel, text = parsed
    ticks = (stamp + rel) if stamp is not None else fallback_ticks
    begin = int(round(ticks * to_ms))
    span = int(round(duration * to_ms)) if duration else _DEFAULT_DURATION_MS
    return begin, begin + span, text.decode('utf-8', 'replace')


def _probe_source(reader, size, base):
    """(latency in seconds, bytes per second) of the source behind reader, from one small and one large read in the
    middle of the file; None when the file is too small to bother, the reads fail, or the source is so fast (a local
    disk) that its speed does not matter."""
    span = size - base
    if span < 4 * _PROBE_LARGE:
        return None
    try:
        started = time.time()
        reader.seek(base + span // 2)
        small = _read_exact(reader, _PROBE_SMALL)
        t1 = max(time.time() - started, 1e-4)
        started = time.time()
        reader.seek(base + span // 3)
        large = _read_exact(reader, _PROBE_LARGE)
        t2 = max(time.time() - started, 1e-4)
    except Exception:
        return None
    if len(small) < _PROBE_SMALL or len(large) < _PROBE_LARGE:
        return None
    if t2 < 0.02:
        return None                     # a local disk or a cache: every read is cheap, nothing to be clever about
    if t2 > t1 * 1.3:
        speed = (_PROBE_LARGE - _PROBE_SMALL) / (t2 - t1)
        fixed = max(t1 - _PROBE_SMALL / speed, 1e-4)
    else:
        speed, fixed = _PROBE_LARGE / t2, t1      # the large read cost no more than the small one: latency decides
    if t2 < 4 and speed < _WALK_CEILING and span >= 8 * _PROBE_HUGE:
        # a longer read tells the speed the source keeps up (a read of a few MB on a new connection is still ramping
        # up); what a request costs is then what is left of the large read's time
        try:
            started = time.time()
            reader.seek(base + span // 4)
            huge = _read_exact(reader, _PROBE_HUGE)
            t3 = max(time.time() - started, 1e-4)
        except Exception:
            return fixed, speed
        if len(huge) == _PROBE_HUGE and t3 > t2:
            kept = min((_PROBE_HUGE - _PROBE_LARGE) / (t3 - t2), 200 << 20)
            if kept > speed:
                return max(t2 - _PROBE_LARGE / kept, t1), kept
    return fixed, speed


def _cue_scan(reader, seg_data, cues, tracks, scale, should_stop=None, on_blocks=None, opener=None, threads=1,
              size=None, log=None):
    """Reads the subtitle blocks of the wanted tracks (tracks: {track number: events list}) from the places the file's
    own index (the Cues element) lists for them, not the whole file. Cluster by cluster: the cluster's header and its
    subtitle blocks come with one read when they lie close together, else with a read for the header and one for each
    block, one after the other (a forward jump of a few KB is cheap, a jump of megabytes is not). The clusters are
    spread over `threads` workers with a handle each (opener() gives a new reader of the file). The source is measured
    first (latency and speed of two reads) and when reading this way would take longer than reading the whole file - a
    dense track in a small file, a source that answers slowly - the file is walked instead. A read that fails or a
    source that stops answering (no block for 30 s) gives up instead of hanging.
    on_blocks(done, total) reports the progress. Returns None when it worked, else the reason it did not (then the
    file has to be walked)."""
    entries = _cue_entries(cues, tracks)
    missing = sorted(n for n in tracks if n not in entries)
    if missing:
        return 'the index of the file has no entries for subtitle track number(s) {0}'.format(missing)
    places = sorted(set((cluster, relative, number) for number, items in entries.items()
                        for cluster, relative, _t in items))
    cue_time = dict(((cluster, relative, number), t) for number, items in entries.items()
                    for cluster, relative, t in items)
    to_ms = scale / 1e6
    total = len(places)
    by_cluster = {}                      # cluster position -> [(position in the cluster, track number, place index)]
    for n, (cluster, relative, number) in enumerate(places):
        by_cluster.setdefault(cluster, []).append((relative, number, n))
    units = sorted(by_cluster.items())
    workers = max(1, threads) if opener else 1
    one_read = _MIN_GAP                  # a cluster whose blocks all lie within this many bytes of its start is one read
    probe = _probe_source(reader, size, seg_data) if size else None
    if probe:
        latency, speed = probe
        one_read = min(_MAX_GAP, max(_MIN_GAP, int(latency * speed / workers)))
        requests = volume = 0
        for cluster, items in units:
            span = items[-1][0] + _BLOCK_READ + 48
            if span <= one_read:
                requests, volume = requests + 1, volume + span
            else:
                requests, volume = requests + 1 + len(items), volume + 32 + _BLOCK_READ * len(items)
        walk_speed = min(speed, _WALK_CEILING)          # the walk cannot go faster than the parsing does
        index_s = requests * latency / workers + volume / speed
        walk_s = size / walk_speed
        if log:
            log('Sub converter: this source answers a request in {0:.0f} ms and delivers {1:.1f} MB/s; reading {2} '
                'blocks through the index: about {3} requests, {4:.1f} MB, {5:.0f} s - the whole file: {6:.0f} s'.format(
                    latency * 1000, speed / 1048576.0, total, requests, volume / 1048576.0, index_s, walk_s))
        if index_s > walk_s * _INDEX_MARGIN:
            return 'reading the whole file ({0:.0f} s) is estimated faster than the index ({1:.0f} s)'.format(walk_s, index_s)
    state = {'failed': None, 'done': 0, 'beat': time.time()}
    results = [None] * total
    lock = threading.Lock()

    def read_at(rdr, start, length):
        if size:
            length = min(length, size - start)
        if length <= 0:
            raise IOError('a read beyond the end of the file')
        rdr.seek(start)
        data = _read_exact(rdr, length)
        if len(data) < length:
            raise IOError('a read returned {0} of {1} bytes'.format(len(data), length))
        return data

    def block_done(n, result):
        results[n] = result
        if isinstance(result, str):
            state['failed'] = state['failed'] or result
            return False
        with lock:
            state['done'] += 1
            done = state['done']
        if on_blocks:
            on_blocks(done, total)
        return True

    def do_cluster(rdr, cluster, items):
        start = seg_data + cluster
        span = items[-1][0] + _BLOCK_READ + 48
        if span <= one_read:
            data = read_at(rdr, start, span)
            head_length = 32
        else:
            data = None
            head = read_at(rdr, start, 32)
            head_length = 32
        parsed = _parse_cluster_head(data[:head_length] if data is not None else head)
        if parsed is None:
            state['failed'] = state['failed'] or 'a place listed in the index is not a cluster'
            return
        header_length, stamp = parsed
        for relative, number, n in items:
            at = start + header_length + relative
            if data is not None:
                chunk = data[header_length + relative:header_length + relative + _BLOCK_READ]
            else:
                chunk = read_at(rdr, at, _BLOCK_READ)
            if not block_done(n, _parse_block_element(chunk, at, number, stamp, cue_time[(cluster, relative, number)],
                                                      to_ms, rdr)):
                return

    def run_stage(stage_units):
        todo = queue.Queue()
        for unit in stage_units:
            todo.put(unit)

        def work(rdr):
            while state['failed'] is None:
                if should_stop and should_stop():
                    state['failed'] = 'stopped'
                    return
                try:
                    cluster, items = todo.get_nowait()
                except queue.Empty:
                    return
                do_cluster(rdr, cluster, items)
                state['beat'] = time.time()

        def worker():
            rdr = None
            try:
                rdr = opener()
                work(rdr)
            except Exception as e:
                state['failed'] = state['failed'] or 'a read failed: {0}'.format(e)
            finally:
                if rdr is not None and hasattr(rdr, 'close'):
                    try:
                        rdr.close()
                    except Exception:
                        pass
        state['beat'] = time.time()
        if opener:
            pool = [threading.Thread(target=worker, name='LPM-index-{0}'.format(k), daemon=True)
                    for k in range(min(workers, len(stage_units)))]
            for t in pool:
                t.start()
            while any(t.is_alive() for t in pool):
                for t in pool:
                    t.join(0.25)
                if state['failed'] is None and time.time() - state['beat'] > _STALL_SECONDS:
                    state['failed'] = 'the source gave no block for {0} s'.format(_STALL_SECONDS)
                if state['failed'] is not None:
                    break
        else:
            try:
                work(reader)
            except Exception as e:
                state['failed'] = state['failed'] or 'a read failed: {0}'.format(e)

    run_stage(units)
    if state['failed'] is not None:
        return state['failed']
    if any(r is None or isinstance(r, str) for r in results):
        return 'a read did not finish'
    for (cluster, relative, number), event in zip(places, results):
        tracks[number].append(event)
    return None


def matroska_subtitle_scan(reader, wanted=None, should_stop=None, progress=None, use_cues=True, log=None,
                           on_blocks=None, opener=None, threads=1, walk_all=False, file_size=None):
    """Walks the Matroska file behind reader once and collects the events of several embedded subtitle tracks at
    the same time: {ordinal (0 = first subtitle track): {'events': [(start ms, end ms, raw block text)], 'header':
    the track's CodecPrivate text (the ASS script header), 'codec': CodecID}}. wanted: the ordinals, or None for all
    text tracks (ASS/SSA, SRT, WebVTT; picture formats are left out). The text of an ASS block is "ReadOrder,Layer,
    Style,Name,MarginL,MarginR,MarginV,Effect,Text". The whole file is walked, but only the headers of the elements:
    the bulk (video, audio) is skipped by seeking. should_stop() is asked between clusters; progress(position) is
    called there too. When use_cues is on and the file's index (the Cues element, which the usual muxers fill with an
    entry for every subtitle block) lists the wanted tracks, only those blocks are read, a few hundred small reads
    instead of the whole file (and only the wanted tracks: reading the others later costs the same again, so it is left
    until they are wanted); log(text) says which way it went, on_blocks(done, total) reports the progress of that
    read, opener and threads let several workers fetch the blocks at the same time (see _cue_scan). When the file has
    to be walked, walk_all reads every text track in that one pass (the walk costs the same for one or all). None
    when the file is no Matroska file, there are no subtitle tracks, or should_stop() says so. The whole of the
    track is always read: where the video is playing, or a seek, makes no difference."""
    raw = reader
    reader = _Buffered(reader, 256 << 10)          # the headers are small; the big reads start with the clusters
    top = _header(reader, 0)
    if not top or top[0] != _EBML_HEADER or top[1] < 0:
        return None
    pos = top[2] + top[1]
    seg = _header(reader, pos)
    if not seg or seg[0] != _SEGMENT:
        return None
    pos += seg[2]
    scale = 1000000                      # nanoseconds per tick
    found = None                         # {ordinal: result entry}
    by_number = {}                       # track number -> events list
    ordinal_of = {}                      # track number -> ordinal
    seg_data = pos
    cues_at = None                       # position of the Cues element relative to the start of the segment data
    cues = None                          # its data, when it comes before the clusters
    cues_tried = False
    while True:
        if should_stop and should_stop():
            return None
        el = _header(reader, pos)
        if not el:
            break                        # end of the file
        eid, size, hlen = el
        if size < 0:
            return None
        body = pos + hlen
        if eid == _INFO and size <= _MAX_SEEK_HEAD_BYTES:
            reader.seek(body)
            for cid, payload in _children(reader.read(size)):
                if cid == _TIMESTAMP_SCALE:
                    scale = _uint(payload) or scale
        elif eid == _TRACKS and size <= _MAX_TRACKS_BYTES:
            reader.seek(body)
            track_list = _subtitle_tracks(reader.read(size))
            found = {}

            def add_track(ordinal):
                number, codec, private = track_list[ordinal]
                found[ordinal] = {'events': [], 'header': private.decode('utf-8', 'replace'), 'codec': codec}
                by_number[number] = found[ordinal]['events']
                ordinal_of[number] = ordinal
            for ordinal, (number, codec, private) in enumerate(track_list):
                if (wanted is None and is_convertible(codec)) or (wanted is not None and ordinal in wanted):
                    add_track(ordinal)
            if not found:
                return None
        elif eid == _SEEK_HEAD and size <= _MAX_SEEK_HEAD_BYTES:
            reader.seek(body)
            for sid, entry in _children(reader.read(size)):
                if sid == _SEEK:
                    fields = dict(_children(entry))
                    if _uint(fields.get(_SEEK_ID, b'')) == _CUES and _SEEK_POSITION in fields:
                        cues_at = _uint(fields[_SEEK_POSITION])
        elif eid == _CUES and size <= _MAX_CUES_BYTES and cues is None:
            reader.seek(body)
            cues = _read_exact(reader, size)
        elif eid == _CLUSTER:
            if found is None:
                return None
            if use_cues and by_number and not cues_tried:
                cues_tried = True
                unanswered = False               # the source did not answer when the index was asked for
                if cues is None and cues_at is not None:
                    for attempt in range(3):
                        el = _header(raw, seg_data + cues_at)
                        if el and el[0] == _CUES and 0 < el[1] <= _MAX_CUES_BYTES:
                            raw.seek(seg_data + cues_at + el[2])
                            data = _read_exact(raw, el[1])
                            if len(data) == el[1]:
                                cues = data
                                break
                        elif el:
                            break                    # an element that is not the index: the file has none
                        unanswered = True
                        if should_stop and should_stop():
                            return None
                        if attempt < 2:              # a source that refuses a connection now may accept it in a moment
                            if log:
                                log('Sub converter: the source did not answer for the index of the file - trying again')
                            time.sleep(1)
                    if cues is not None:
                        unanswered = False
                if cues is None:
                    why = ('the index of the file could not be read - the source did not answer' if unanswered
                           else 'the file has no index (Cues) to find')
                else:
                    workers_now = threads
                    while True:
                        why = _cue_scan(raw, seg_data, cues, by_number, scale, should_stop, on_blocks, opener,
                                        workers_now, file_size, log)
                        if (why and why.startswith('a read failed') and opener and workers_now > 1
                                and not (should_stop and should_stop())):
                            # a source that refuses many connections at once (a debrid service): fewer, not the whole file
                            workers_now = max(1, workers_now // 2)
                            if log:
                                log('Sub converter: {0} - trying again with {1} parallel read{2}'.format(
                                    why, workers_now, '' if workers_now == 1 else 's'))
                            time.sleep(2)
                            continue
                        break
                    if why == 'stopped':
                        return None
                if why is None:
                    if log:
                        log('Sub converter: read the subtitle blocks of track(s) {0} through the index of the file '
                            '({1} blocks), not the whole file'.format(
                                sorted(o + 1 for o in found), sum(len(e) for e in by_number.values())))
                    return found
                for events in by_number.values():
                    del events[:]
                if log:
                    log('Sub converter: reading the whole file - {0}'.format(why))
            if walk_all and wanted is not None:
                for ordinal, (number, codec, private) in enumerate(track_list):
                    if ordinal not in found and is_convertible(codec):
                        add_track(ordinal)
            reader.chunk = _Buffered._CHUNK
            if progress:
                progress(pos)
            _cluster_events(reader, body, body + size, by_number, scale)
        pos = body + size
    return found


def matroska_subtitle_events(reader, ordinal, should_stop=None, info=None):
    """The events of the ordinal-th (0 = first) subtitle track of the Matroska file behind reader as
    [(start ms, end ms, raw block text)] (see matroska_subtitle_scan). None when the file is no Matroska file, the
    track is missing, or should_stop() says so. When info is a dict, info['header'] gets the track's CodecPrivate
    text and info['codec'] its CodecID."""
    found = matroska_subtitle_scan(reader, {ordinal}, should_stop)
    if not found or ordinal not in found:
        return None
    if info is not None:
        info['header'] = found[ordinal]['header']
        info['codec'] = found[ordinal]['codec']
    return found[ordinal]['events']


def _cluster_events(reader, pos, end, tracks, scale):
    stamp = 0
    to_ms = scale / 1e6
    while pos < end:
        reader.seek(pos)
        window = reader.read(96)
        eid, n1 = _vint(window, 0, True)
        size, n2 = _vint(window, n1, False) if eid is not None else (None, 0)
        if size is None or size < 0:
            return
        body = n1 + n2
        wanted = None                    # (block payload offset in file, block size, duration ticks or None)
        if eid == _CLUSTER_TIMESTAMP:
            stamp = _uint(window[body:body + size])
        elif eid == _SIMPLE_BLOCK:
            number, _n = _vint(window, body, False)
            if number in tracks:
                wanted = (pos + body, size, None, number)
        elif eid == _BLOCK_GROUP:
            cid, c1 = _vint(window, body, True)
            csize, c2 = _vint(window, body + c1, False) if cid is not None else (None, 0)
            if cid == _BLOCK and csize is not None:
                number, _n = _vint(window, body + c1 + c2, False)
                if number in tracks:
                    wanted = (pos + body + c1 + c2, csize, 'group', number)
                    group = (pos + body, size)
        if wanted:
            start, length, kind, number = wanted
            reader.seek(start)
            parsed = _block(reader.read(length), number)
            duration = None
            if kind == 'group':
                reader.seek(group[0])
                for cid, payload in _children(reader.read(group[1])):
                    if cid == _BLOCK_DURATION:
                        duration = _uint(payload)
            if parsed:
                rel, data = parsed
                begin = int(round((stamp + rel) * to_ms))
                span = int(round(duration * to_ms)) if duration else _DEFAULT_DURATION_MS
                tracks[number].append((begin, begin + span, data.decode('utf-8', 'replace')))
        pos += body + size
