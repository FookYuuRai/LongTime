# SPDX-License-Identifier: GPL-2.0-or-later
"""Segments from the chapters of a file (libmsefp's probe lists them with their titles)."""
import re

KINDS = [
    ('recap', re.compile(r'^\s*(recap|previously|previous episode|last time|story so far)\b', re.I)),
    ('intro', re.compile(r'^\s*(op|opening|intro|introduction|title sequence|titles?|main title|theme song|'
                         r'opening (credits|theme|song))\b[\s\d:.\-]*$', re.I)),
    ('credits', re.compile(r'^\s*(ed|ending|outro|end credits|closing credits|credits|closing)\b[\s\d:.\-]*$', re.I)),
    ('preview', re.compile(r'^\s*(preview|next time|next episode|coming up|trailer|teaser)\b', re.I)),
]
MIN_S = {'intro': 10, 'recap': 5, 'credits': 10, 'preview': 5}


def from_chapters(chapters, duration):
    """{'intro': [...], ...} from [{'start_s', 'end_s', 'title'}]. Chapters need a recognised title; an ending ending
    within 2 s of the end of the video is left open (the end of the video)."""
    out = {}
    for ch in chapters or []:
        title = (ch.get('title') or '').strip()
        try:
            start, end = float(ch['start_s']), float(ch['end_s'])
        except (KeyError, TypeError, ValueError):
            continue
        for kind, rx in KINDS:
            if rx.match(title):
                if end - start >= MIN_S[kind]:
                    open_end = kind in ('credits', 'preview') and duration and end >= duration - 2.0
                    out.setdefault(kind, []).append({'start': start, 'end': None if open_end else end,
                                                     'source': 'chapters', 'score': 0.5})
                break
    return out
