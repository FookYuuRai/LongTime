# SPDX-License-Identifier: GPL-2.0-or-later
"""fingerprint.db: fingerprints and results only. Streamed audio and video are never stored.

Tables: themes (a theme's fingerprint), episodes (head / tail fingerprint of an episode), results (what was found
for an episode), shows (when a show was last played). Purge removes the episodes, results and shows not played for
a number of days.
"""
import os
import sqlite3
import threading
import time

DAY = 86400
SCHEMA = """
CREATE TABLE IF NOT EXISTS themes (key TEXT PRIMARY KEY, fp BLOB NOT NULL, seconds REAL, created INTEGER);
CREATE TABLE IF NOT EXISTS episodes (show TEXT, season INTEGER, episode INTEGER, kind TEXT, fp BLOB NOT NULL,
  first_s REAL, duration REAL, created INTEGER, PRIMARY KEY (show, season, episode, kind));
CREATE TABLE IF NOT EXISTS results (show TEXT, season INTEGER, episode INTEGER, segment TEXT, source TEXT,
  start_s REAL, end_s REAL, score REAL, created INTEGER, PRIMARY KEY (show, season, episode, segment, source));
CREATE TABLE IF NOT EXISTS shows (show TEXT PRIMARY KEY, last_played INTEGER, title TEXT);
CREATE TABLE IF NOT EXISTS tried (show TEXT, season INTEGER, episode INTEGER, step TEXT, created INTEGER,
  PRIMARY KEY (show, season, episode, step));
"""


class Db:
    def __init__(self, path):
        if path != ':memory:':
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        self.path = path
        self.lock = threading.RLock()
        self.con = sqlite3.connect(path, check_same_thread=False)
        self.con.executescript(SCHEMA)

    def close(self):
        with self.lock:
            self.con.close()

    def _run(self, sql, args=()):
        with self.lock:
            cur = self.con.execute(sql, args)
            self.con.commit()
            return cur

    def _all(self, sql, args=()):
        with self.lock:
            return self.con.execute(sql, args).fetchall()

    # themes
    def get_theme(self, key):
        r = self._all('SELECT fp FROM themes WHERE key=?', (key,))
        return bytes(r[0][0]) if r else None

    def put_theme(self, key, fp, seconds):
        self._run('INSERT OR REPLACE INTO themes VALUES (?,?,?,?)', (key, sqlite3.Binary(fp), seconds, int(time.time())))

    # episodes
    def get_episode(self, show, season, episode, kind):
        r = self._all('SELECT fp, first_s, duration FROM episodes WHERE show=? AND season=? AND episode=? AND kind=?',
                      (show, season, episode, kind))
        return (bytes(r[0][0]), r[0][1], r[0][2]) if r else None

    def put_episode(self, show, season, episode, kind, fp, first_s, duration):
        self._run('INSERT OR REPLACE INTO episodes VALUES (?,?,?,?,?,?,?,?)',
                  (show, season, episode, kind, sqlite3.Binary(fp), first_s, duration, int(time.time())))

    def other_episodes(self, show, season, episode, kind, limit=6):
        """Stored fingerprints of the same show and season (other episodes), nearest episode numbers first."""
        rows = self._all('SELECT episode, fp, first_s, duration FROM episodes WHERE show=? AND season=? AND episode<>? '
                         'AND kind=? ORDER BY ABS(episode-?) LIMIT ?', (show, season, episode, kind, episode, limit))
        return [(r[0], bytes(r[1]), r[2], r[3]) for r in rows]

    # results
    def put_result(self, show, season, episode, segment, source, start_s, end_s, score):
        self._run('INSERT OR REPLACE INTO results VALUES (?,?,?,?,?,?,?,?,?)',
                  (show, season, episode, segment, source, start_s, end_s, score, int(time.time())))

    def get_results(self, show, season, episode):
        return self._all('SELECT segment, source, start_s, end_s, score FROM results WHERE show=? AND season=? AND '
                         'episode=?', (show, season, episode))

    def mark_tried(self, show, season, episode, step):
        self._run('INSERT OR REPLACE INTO tried VALUES (?,?,?,?,?)', (show, season, episode, step, int(time.time())))

    def was_tried(self, show, season, episode, step):
        return bool(self._all('SELECT 1 FROM tried WHERE show=? AND season=? AND episode=? AND step=?',
                              (show, season, episode, step)))

    # played / purge
    def played(self, show, title=''):
        self._run('INSERT INTO shows VALUES (?,?,?) ON CONFLICT(show) DO UPDATE SET last_played=excluded.last_played',
                  (show, int(time.time()), title))

    def purge(self, days, now=None):
        """Removes every show not played for `days` days (its episodes, results and tried marks), and shows that were
        never played. days <= 0: nothing. Returns the number of shows removed."""
        if days <= 0:
            return 0
        cutoff = int(now if now is not None else time.time()) - int(days * DAY)
        with self.lock:
            stale = [r[0] for r in self.con.execute('SELECT show FROM shows WHERE last_played < ?', (cutoff,))]
            known = {r[0] for r in self.con.execute('SELECT show FROM shows')}
            for table in ('episodes', 'results', 'tried'):
                for (s,) in self.con.execute('SELECT DISTINCT show FROM %s' % table).fetchall():
                    if s not in known:
                        stale.append(s)             # fingerprints of a show that was never marked as played
            stale = set(stale)
            for s in stale:
                for table in ('episodes', 'results', 'tried', 'shows'):
                    self.con.execute('DELETE FROM %s WHERE show=?' % table, (s,))
            self.con.commit()
            return len(stale)

    def purge_all(self):
        with self.lock:
            for table in ('episodes', 'results', 'tried', 'shows', 'themes'):
                self.con.execute('DELETE FROM %s' % table)
            self.con.commit()
            self.con.execute('VACUUM')

    def stats(self):
        n = lambda t: self._all('SELECT COUNT(*) FROM %s' % t)[0][0]
        size = os.path.getsize(self.path) if self.path != ':memory:' and os.path.exists(self.path) else 0
        return {'themes': n('themes'), 'episodes': n('episodes'), 'results': n('results'), 'shows': n('shows'),
                'bytes': size}
