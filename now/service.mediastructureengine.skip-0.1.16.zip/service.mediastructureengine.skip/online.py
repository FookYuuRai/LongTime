# SPDX-License-Identifier: GPL-2.0-or-later
# Based on TheIntroDB's Kodi add-on (introdb.py): read-only lookups, no submissions.
"""Segment lookups at TheIntroDB (v3 /media) and IntroDB (/segments), and small JSON/bytes downloads.

Segments are dicts {'start': seconds or None, 'end': seconds or None, 'source': name, 'score': float}, in
{'intro': [...], 'recap': [...], 'credits': [...], 'preview': [...]}. For intro and recap a missing start means 0;
for credits and preview a missing end means the end of the video.
"""
import json
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

THEINTRODB = 'https://api.theintrodb.org/v3/media'
INTRODB = 'https://api.introdb.app/segments'
USER_AGENT = 'Kodi MediaStructureEngine-Skip/0.1'
TIMEOUT = 8
MIN_GAP = 0.4

_lock = threading.Lock()
_last = 0.0
_blocked_until = {}


def log(msg):
    try:
        import xbmc
        xbmc.log('[MSE Skip] ' + msg, xbmc.LOGINFO)
    except ImportError:
        pass


def _gap(host):
    global _last
    with _lock:
        now = time.time()
        if now < _blocked_until.get(host, 0):
            return False
        if now - _last < MIN_GAP:
            time.sleep(MIN_GAP - (now - _last))
        _last = time.time()
    return True


def get_json(url, host, headers=None, timeout=TIMEOUT):
    """GET a JSON document; None on any failure (404 included). A 429 pauses that host for the time it asks."""
    if not _gap(host):
        return None
    req = Request(url, headers=dict({'Accept': 'application/json', 'User-Agent': USER_AGENT}, **(headers or {})))
    try:
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8'))
    except HTTPError as e:
        if e.code == 429:
            wait = 300
            for h in ('X-UsageLimit-Reset', 'X-RateLimit-Reset', 'Retry-After'):
                try:
                    wait = int(e.headers.get(h))
                    break
                except (TypeError, ValueError):
                    pass
            _blocked_until[host] = time.time() + wait
        log('%s: HTTP %s' % (host, e.code))
    except (URLError, ValueError, OSError) as e:
        log('%s: %s' % (host, e))
    return None


def get_bytes(url, limit=64 << 20, timeout=30):
    """GET a file into memory (never to disk); None on failure or when larger than limit."""
    req = Request(url, headers={'User-Agent': USER_AGENT})
    try:
        with urlopen(req, timeout=timeout) as r:
            data = r.read(limit + 1)
        return data if len(data) <= limit else None
    except (HTTPError, URLError, OSError) as e:
        log('download %s: %s' % (url.split('?')[0], e))
        return None


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _score(seg):
    conf = seg.get('confidence')
    conf = 0.5 if conf is None else float(conf)
    return conf + float(seg.get('submission_count') or 1) * 0.001


def _from_ms(rows, kind, source):
    out = []
    for seg in rows or []:
        if not isinstance(seg, dict):
            continue
        start, end = _num(seg.get('start_ms')), _num(seg.get('end_ms'))
        if kind in ('intro', 'recap'):
            if end is None:
                continue
            start = 0.0 if start is None else start
        elif start is None:
            continue
        if end is not None and end <= start:
            continue
        out.append({'start': start / 1000.0, 'end': None if end is None else end / 1000.0, 'source': source,
                    'score': _score(seg)})
    out.sort(key=lambda s: -s['score'])
    return out


def _ids_query(ids, extra=None):
    """Query parameters for the ids at hand: tmdb, else tvdb, else imdb; season and episode for TV."""
    q = {}
    tmdb, tvdb, imdb = ids.get('tmdb_id'), ids.get('tvdb_id'), ids.get('imdb_id')
    if tmdb and str(tmdb).isdigit() and int(tmdb) > 0:
        q['tmdb_id'] = str(int(tmdb))
    elif tvdb and str(tvdb).isdigit() and int(tvdb) > 0:
        q['tvdb_id'] = str(int(tvdb))
    elif imdb and str(imdb).startswith('tt'):
        q['imdb_id'] = str(imdb)
    else:
        return None
    if not ids.get('is_movie'):
        try:
            s, e = int(ids.get('season')), int(ids.get('episode'))
        except (TypeError, ValueError):
            return None
        if s <= 0 or e <= 0:
            return None
        q['season'], q['episode'] = s, e
    q.update(extra or {})
    return q


def theintrodb(ids, duration_ms=None, api_key=''):
    """All four segment types from TheIntroDB, {} when unknown."""
    q = _ids_query(ids, {'duration_ms': int(duration_ms)} if duration_ms else None)
    if not q:
        return {}
    headers = {'Authorization': 'Bearer ' + api_key} if api_key else None
    data = get_json(THEINTRODB + '?' + urlencode(q), 'theintrodb', headers)
    if not data or 'error' in data:
        return {}
    out = {}
    for kind in ('intro', 'recap', 'credits', 'preview'):
        rows = _from_ms(data.get(kind), kind, 'theintrodb')
        if rows:
            out[kind] = rows
    return out


def introdb(ids):
    """intro, recap and outro (as credits) from IntroDB (needs an IMDb id)."""
    imdb = ids.get('imdb_id')
    if not imdb or not str(imdb).startswith('tt') or ids.get('is_movie'):
        return {}
    try:
        q = {'imdb_id': imdb, 'season': int(ids.get('season')), 'episode': int(ids.get('episode'))}
    except (TypeError, ValueError):
        return {}
    data = get_json(INTRODB + '?' + urlencode(q), 'introdb')
    if not data or 'error' in data:
        return {}
    out = {}
    for src, kind in (('intro', 'intro'), ('recap', 'recap'), ('outro', 'credits'), ('post_credits', 'preview')):
        seg = data.get(src)
        if not isinstance(seg, dict):
            continue
        start = _num(seg.get('start_sec', None))
        end = _num(seg.get('end_sec', None))
        if start is None and seg.get('start_ms') is not None:
            start = float(seg['start_ms']) / 1000.0
        if end is None and seg.get('end_ms') is not None:
            end = float(seg['end_ms']) / 1000.0
        if kind in ('intro', 'recap'):
            if end is None:
                continue
            start = 0.0 if start is None else start
        elif start is None:
            continue
        if end is not None and end <= start:
            continue
        out[kind] = [{'start': start, 'end': end, 'source': 'introdb', 'score': _score(seg)}]
    return out
