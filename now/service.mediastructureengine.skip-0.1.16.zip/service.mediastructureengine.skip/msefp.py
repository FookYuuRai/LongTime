"""ctypes wrapper for libmsefp: audio fingerprints of a video's sound, and where one occurs in another.

Works in Kodi's Python (Android: ctypes is available) and on a PC:

    import msefp
    lib = msefp.Library("/path/to/libmsefp.so")
    f = xbmcvfs.File("smb://server/TV/Show/S01E01.mkv")     # any path Kodi can open, or a local path without reader
    ep = lib.fingerprint("S01E01.mkv", reader=f, start_s=0, duration_s=360)
    theme = lib.fingerprint("op.ogg", reader=io.BytesIO(data), duration_s=0)   # a theme downloaded into memory
    m = lib.match(theme.values, ep.values)                   # where the theme occurs in the episode
    if m.found:
        start, end = ep.first_s + m.b_start_s, ep.first_s + m.b_end_s
    lib.probe("S01E01.mkv", reader=f)                         # dict: duration_s, chapters, audio streams

Fingerprint values are bytes (uint32, little-endian), ready to be stored. reader: any object with read(n) -> bytes (or
Kodi's readBytes(n)), seek(offset, whence) -> new position, and size() or tell(). Call lib.cancel() from another
thread to stop a fingerprint early.

On Android the library must be loaded from the app's internal storage (Kodi copies its own add-on libraries to
special://xbmcaltbinaddons/ for the same reason); copy it there first and pass that path.
"""
import ctypes
import json
import sys
import threading

RATE = 11025
ITEM_S = 4096.0 / 3.0 / RATE                                # seconds between fingerprint values
ITEM_SPAN_S = (19 * 4096.0 / 3.0 + 4096.0 * 2.0 / 3.0) / RATE   # sound one value describes
INFO_SIZE = 8192
SEEK_SIZE = 0x10000
OK, CANCELLED, ERROR = 0, 1, -1

_READ_FN = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint8), ctypes.c_int)
_SEEK_FN = ctypes.CFUNCTYPE(ctypes.c_int64, ctypes.c_void_p, ctypes.c_int64, ctypes.c_int)


class _Params(ctypes.Structure):
    _fields_ = [("start_s", ctypes.c_double), ("duration_s", ctypes.c_double), ("audio_stream", ctypes.c_int),
                ("threads", ctypes.c_int), ("cancel", ctypes.POINTER(ctypes.c_int)),
                ("progress_ms", ctypes.POINTER(ctypes.c_int64)), ("stop_ref", ctypes.POINTER(ctypes.c_uint32)),
                ("stop_ref_n", ctypes.c_int), ("min_match_s", ctypes.c_double)]


class _Result(ctypes.Structure):
    _fields_ = [("fp", ctypes.POINTER(ctypes.c_uint32)), ("n", ctypes.c_int), ("first_s", ctypes.c_double),
                ("audio_stream", ctypes.c_int), ("stopped_early", ctypes.c_int), ("info", ctypes.c_char * INFO_SIZE)]


class _Match(ctypes.Structure):
    _fields_ = [("found", ctypes.c_int), ("a_start_s", ctypes.c_double), ("a_end_s", ctypes.c_double),
                ("b_start_s", ctypes.c_double), ("b_end_s", ctypes.c_double), ("offset", ctypes.c_int),
                ("score", ctypes.c_int), ("mean_bits", ctypes.c_double)]


class Fingerprint:
    """values: bytes (uint32 LE); first_s: time of the first value in the video; info: dict from the library."""

    def __init__(self, values, first_s, audio_stream=-1, stopped_early=False, info=None, cancelled=False):
        self.values = values
        self.first_s = first_s
        self.audio_stream = audio_stream
        self.stopped_early = stopped_early
        self.info = info or {}
        self.cancelled = cancelled

    @property
    def n(self):
        return len(self.values) // 4

    @property
    def seconds(self):
        """Length of the sound described (0 when there are no values)."""
        return (self.n - 1) * ITEM_S + ITEM_SPAN_S if self.n else 0.0


class Match:
    def __init__(self, m):
        self.found = bool(m.found)
        self.a_start_s, self.a_end_s = m.a_start_s, m.a_end_s
        self.b_start_s, self.b_end_s = m.b_start_s, m.b_end_s
        self.offset, self.score, self.mean_bits = m.offset, m.score, m.mean_bits

    @property
    def seconds(self):
        return self.b_end_s - self.b_start_s

    def as_dict(self):
        return {k: getattr(self, k) for k in ("found", "a_start_s", "a_end_s", "b_start_s", "b_end_s", "offset",
                                              "score", "mean_bits")}


class FingerprintError(Exception):
    pass


def _values_array(values):
    """bytes (uint32 LE) -> a ctypes uint32 array the library can read."""
    n = len(values) // 4
    arr = (ctypes.c_uint32 * max(n, 1))()
    if n:
        ctypes.memmove(arr, bytes(values[:n * 4]), n * 4)
        if sys.byteorder != "little":
            for i in range(n):
                arr[i] = int.from_bytes(values[i * 4:i * 4 + 4], "little")
    return arr, n


class _Reader:
    """Adapts a Python or Kodi file object to the library's read/seek callbacks."""

    def __init__(self, f):
        self.f = f
        self.read_bytes = getattr(f, "readBytes", None) or f.read
        self.pos = 0
        self.error = None

    def read(self, _opaque, buf, size):
        try:
            data = self.read_bytes(size)
            n = len(data)
            if n:
                ctypes.memmove(buf, bytes(data), n)
            self.pos += n
            return n
        except Exception as exc:                   # a read error must not cross into C
            self.error = exc
            return -1

    def seek(self, _opaque, offset, whence):
        try:
            if whence == SEEK_SIZE:
                if hasattr(self.f, "size"):
                    return int(self.f.size())
                here = self.pos
                end = self.f.seek(0, 2)
                self.f.seek(here, 0)
                return int(end)
            new = self.f.seek(offset, whence)
            self.pos = int(new) if new is not None else (self.f.tell() if hasattr(self.f, "tell") else offset)
            return self.pos
        except Exception as exc:
            self.error = exc
            return -1


class Library:
    def __init__(self, path):
        self.lib = ctypes.CDLL(path)
        L = self.lib
        L.msefp_default_params.argtypes = [ctypes.POINTER(_Params)]
        L.msefp_probe.argtypes = [ctypes.c_char_p, _READ_FN, _SEEK_FN, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int,
                                  ctypes.c_char_p, ctypes.c_int]
        L.msefp_probe.restype = ctypes.c_int
        L.msefp_fingerprint.argtypes = [ctypes.c_char_p, _READ_FN, _SEEK_FN, ctypes.c_void_p, ctypes.POINTER(_Params),
                                        ctypes.POINTER(_Result), ctypes.c_char_p, ctypes.c_int]
        L.msefp_fingerprint.restype = ctypes.c_int
        L.msefp_free_result.argtypes = [ctypes.POINTER(_Result)]
        L.msefp_match.argtypes = [ctypes.POINTER(ctypes.c_uint32), ctypes.c_int, ctypes.POINTER(ctypes.c_uint32),
                                  ctypes.c_int, ctypes.c_double, ctypes.c_int, ctypes.POINTER(_Match)]
        L.msefp_match.restype = ctypes.c_int
        L.msefp_version.restype = ctypes.c_char_p
        self._cancel = ctypes.c_int(0)
        self._progress = ctypes.c_int64(0)
        self._lock = threading.Lock()

    def version(self):
        return self.lib.msefp_version().decode("utf-8", "replace")

    def cancel(self):
        self._cancel.value = 1

    def progress_s(self):
        """Position reached by the running fingerprint, in seconds from the video's start."""
        return self._progress.value / 1000.0

    @staticmethod
    def _callbacks(reader):
        adapter = _Reader(reader) if reader is not None else None
        return adapter, (_READ_FN(adapter.read) if adapter else _READ_FN()), \
            (_SEEK_FN(adapter.seek) if adapter else _SEEK_FN())

    def probe(self, name, reader=None):
        """dict: format, duration_s, start_s, chapters [{start_s, end_s, title}], audio_streams, audio_stream."""
        adapter, read_cb, seek_cb = self._callbacks(reader)
        out = ctypes.create_string_buffer(65536)
        err = ctypes.create_string_buffer(512)
        ret = self.lib.msefp_probe(str(name).encode("utf-8"), read_cb, seek_cb, None, out, len(out), err, len(err))
        if ret != OK:
            detail = err.value.decode("utf-8", "replace")
            if adapter and adapter.error:
                detail += f" (reader: {adapter.error})"
            raise FingerprintError(detail)
        return json.loads(out.value.decode("utf-8", "replace"))

    def fingerprint(self, name, reader=None, start_s=0.0, duration_s=360.0, audio_stream=-1, threads=0,
                    stop_ref=None, min_match_s=0.0):
        """Fingerprint of the sound from start_s (negative: that many seconds before the end) for duration_s
        (0 = to the end). stop_ref: values (bytes) of a theme; reading stops once it has been found whole.
        Raises FingerprintError on failure; a cancelled run returns what was read (cancelled=True)."""
        p = _Params()
        self.lib.msefp_default_params(ctypes.byref(p))
        p.start_s, p.duration_s = float(start_s), float(duration_s)
        p.audio_stream, p.threads = int(audio_stream), int(threads)
        p.cancel = ctypes.pointer(self._cancel)
        p.progress_ms = ctypes.pointer(self._progress)
        ref = None
        if stop_ref:
            ref, n = _values_array(stop_ref)
            p.stop_ref, p.stop_ref_n = ctypes.cast(ref, ctypes.POINTER(ctypes.c_uint32)), n
            p.min_match_s = float(min_match_s)
        res = _Result()
        err = ctypes.create_string_buffer(512)
        adapter, read_cb, seek_cb = self._callbacks(reader)
        with self._lock:                               # one at a time (production limit)
            self._cancel.value = 0
            self._progress.value = 0
            ret = self.lib.msefp_fingerprint(str(name).encode("utf-8"), read_cb, seek_cb, None, ctypes.byref(p),
                                             ctypes.byref(res), err, len(err))
        if ret == ERROR:
            detail = err.value.decode("utf-8", "replace")
            if adapter and adapter.error:
                detail += f" (reader: {adapter.error})"
            raise FingerprintError(detail)
        try:
            values = ctypes.string_at(res.fp, res.n * 4) if res.n else b""
            if values and sys.byteorder != "little":
                values = b"".join(res.fp[i].to_bytes(4, "little") for i in range(res.n))
            info = json.loads(res.info.decode("utf-8", "replace")) if res.info else {}
            return Fingerprint(values, res.first_s, res.audio_stream, bool(res.stopped_early), info,
                               ret == CANCELLED)
        finally:
            self.lib.msefp_free_result(ctypes.byref(res))
            del ref

    def match(self, a, b, min_match_s=0.0, min_score=0):
        """Where fingerprint a (bytes) occurs in b: Match with the stretch in both (seconds from their first value).
        min_match_s: shortest stretch that counts as found (0 = 15 s); min_score: 0 = 40."""
        aa, na = _values_array(a)
        bb, nb = _values_array(b)
        m = _Match()
        self.lib.msefp_match(aa, na, bb, nb, float(min_match_s), int(min_score), ctypes.byref(m))
        return Match(m)
