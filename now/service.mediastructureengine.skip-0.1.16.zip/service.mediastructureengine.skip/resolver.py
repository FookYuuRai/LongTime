# SPDX-License-Identifier: GPL-2.0-or-later
"""Finds the segments (intro, recap, credits, preview) of one episode, source by source, in this order:

  1. TheIntroDB   2. IntroDB (/segments)   3. AnimeThemes + fingerprint   4. chapters   5. cross-episode match

A source only fills the segment kinds the earlier ones left empty. Steps 3 to 5 read the sound of the playing file
(through `open_file`, so any path Kodi can open works) and compare fingerprints: with the one theme AnimeThemes lists
for the episode, or with the opening of other episodes of the same show stored in fingerprint.db. Only fingerprints
are stored; the audio itself is never saved.
"""
import io
import re

import animethemes
import chapters as chapters_mod
import online

KINDS = ('intro', 'recap', 'credits', 'preview')
HEAD_S = 360.0
TAIL_S = 360.0
SHARED_MIN_S = 15.0
SHARED_MAX_S = 200.0


def show_key(media):
    """A stable key for the show: its TMDb, TVDB or IMDb id, else its title."""
    for name, prefix in (('tmdb_id', 'tmdb'), ('tvdb_id', 'tvdb'), ('imdb_id', 'imdb')):
        v = media.get(name)
        if v and str(v) not in ('0', 'None', 'tt0000000'):
            return '%s:%s' % (prefix, v)
    title = re.sub(r'\W+', ' ', str(media.get('title') or '')).strip().lower()
    return 'title:' + title if title else ''


def _add(found, kind, segs):
    if segs and not found.get(kind):
        found[kind] = segs
        return True
    return False


class Resolver:
    """settings: object with get(name) -> bool/str/int (see service.Settings). lib: msefp.Library or None."""

    def __init__(self, db, lib, settings, ids_path=None, log=online.log):
        self.db, self.lib, self.cfg, self.ids_path, self.log = db, lib, settings, ids_path, log
        self._kometa = None

    # -- API sources (cheap; also used before a file is playing) ---------------------------------------------------
    def from_apis(self, media):
        found = {}
        dur = media.get('duration_s')
        dur_ms = int(dur * 1000) if dur else None
        if self.cfg.get('use_theintrodb'):
            for kind, segs in online.theintrodb(media, dur_ms, self.cfg.get('introdb_api_key') or '').items():
                _add(found, kind, segs)
        if self.cfg.get('use_introdb') and not all(found.get(k) for k in ('intro', 'credits')):
            for kind, segs in online.introdb(media).items():
                _add(found, kind, segs)
        return found

    # -- full resolution -------------------------------------------------------------------------------------------
    def resolve(self, media, open_file=None, on_update=None, apis_only=False):
        """-> segments dict. on_update(found, final) is called after each step that added something, and at the end.
        open_file() -> (name, file object) for the playing file; None when nothing plays (APIs only)."""
        found = {}
        key = show_key(media)
        season, episode = media.get('season'), media.get('episode')
        tv = not media.get('is_movie') and season is not None and episode is not None
        notify = lambda final=False: on_update(dict(found), final) if on_update else None

        found.update(self.from_apis(media))
        notify()
        if apis_only or open_file is None or not self.lib or not tv or not key:
            notify(True)
            return found
        want = lambda: [k for k in ('intro', 'credits') if not found.get(k)]
        if not want():
            notify(True)
            return found

        try:
            season, episode = int(season), int(episode)
            self.db.played(key, media.get('title') or '')
            self._stored(found, key, season, episode)
            if want() and self.cfg.get('use_animethemes'):
                if self._anime(found, media, key, season, episode, open_file):
                    notify()
            if want() and self.cfg.get('use_chapters'):
                if self._chapters(found, media, open_file):
                    notify()
            if self.cfg.get('use_crossmatch'):
                if self._cross(found, media, key, season, episode, open_file):
                    notify()
        except Exception as exc:              # a failed fingerprint must never stop playback or the service
            self.log('resolve failed: %r' % (exc,))
        notify(True)
        return found

    # -- steps -----------------------------------------------------------------------------------------------------
    def _stored(self, found, key, season, episode):
        for kind, source, s, e, score in self.db.get_results(key, season, episode):
            _add(found, kind, [{'start': s, 'end': e, 'source': source, 'score': score}])

    def _store(self, key, season, episode, kind, seg):
        self.db.put_result(key, season, episode, kind, seg['source'], seg['start'], seg['end'], seg['score'])

    def _theme_fp(self, theme):
        fp = self.db.get_theme(theme['key'])
        if fp:
            return fp
        data = online.get_bytes(theme['link'])
        if not data:
            return None
        res = self.lib.fingerprint(theme['key'].split(':', 1)[-1], reader=io.BytesIO(data), duration_s=0)
        if res.n < 20:
            return None
        self.db.put_theme(theme['key'], res.values, res.seconds)
        return res.values

    def _fingerprint(self, open_file, start_s, duration_s, stop_ref=None):
        name, f = open_file()
        try:
            return self.lib.fingerprint(name, reader=f, start_s=start_s, duration_s=duration_s, stop_ref=stop_ref)
        finally:
            close = getattr(f, 'close', None)
            if close:
                close()

    def _head(self, key, season, episode, open_file, stop_ref=None):
        """(values, first_s) of the opening minutes: stored, else read now (and stored when learning is on)."""
        stored = self.db.get_episode(key, season, episode, 'head')
        if stored:
            return stored[0], stored[1]
        res = self._fingerprint(open_file, 0.0, HEAD_S, stop_ref)
        if res.n and self.cfg.get('learn'):
            self.db.put_episode(key, season, episode, 'head', res.values, res.first_s, res.info.get('duration_s'))
        return res.values, res.first_s

    def _tail(self, key, season, episode, open_file, duration):
        stored = self.db.get_episode(key, season, episode, 'tail')
        if stored:
            return stored[0], stored[1]
        if not duration or duration < TAIL_S + 60:
            return b'', 0.0
        res = self._fingerprint(open_file, -TAIL_S, 0.0)
        if res.n and self.cfg.get('learn'):
            self.db.put_episode(key, season, episode, 'tail', res.values, res.first_s, duration)
        return res.values, res.first_s

    def _anime(self, found, media, key, season, episode, open_file):
        if self.db.was_tried(key, season, episode, 'anime'):
            return False
        if self._kometa is None:
            self._kometa = animethemes.load_ids(self.ids_path) if self.ids_path else {}
        m = animethemes.map_episode(self._kometa, media.get('tvdb_id'), media.get('imdb_id'), media.get('tmdb_id'),
                                    season, episode)
        if not m:
            return False                       # not an anime (or unknown to the list): nothing is marked as tried
        anime = animethemes.fetch_anime(m['mal_id'], m['anilist_id'])
        added = False
        duration = media.get('duration_s')
        for theme_kind, seg_kind in (('OP', 'intro'), ('ED', 'credits')):
            if found.get(seg_kind):
                continue
            themes = animethemes.themes_for(anime, m['episode'], theme_kind)
            fps = [fp for fp in (self._theme_fp(t) for t in themes) if fp]
            if not fps:
                continue
            if seg_kind == 'intro':
                # one theme listed: stop reading as soon as it has been found
                values, first = self._head(key, season, episode, open_file, fps[0] if len(fps) == 1 else None)
            else:
                values, first = self._tail(key, season, episode, open_file, duration)
            best = None
            for fp in fps:
                mt = self.lib.match(fp, values)
                if mt.found and (best is None or mt.seconds > best.seconds):
                    best = mt
            if best:
                start = max(0.0, first + best.b_start_s - best.a_start_s) if seg_kind == 'intro' else first + best.b_start_s
                end = first + best.b_end_s
                if seg_kind == 'credits' and duration and end >= duration - 3.0:
                    end = None
                seg = {'start': start, 'end': end, 'source': 'animethemes', 'score': best.score / 700.0}
                found[seg_kind] = [seg]
                self._store(key, season, episode, seg_kind, seg)
                added = True
        if not added:
            self.db.mark_tried(key, season, episode, 'anime')
        return added

    def _chapters(self, found, media, open_file):
        name, f = open_file()
        try:
            info = self.lib.probe(name, reader=f)
        finally:
            close = getattr(f, 'close', None)
            if close:
                close()
        added = False
        for kind, segs in chapters_mod.from_chapters(info.get('chapters'), info.get('duration_s')).items():
            added |= _add(found, kind, segs)
        return added

    def _cross(self, found, media, key, season, episode, open_file):
        """Intro-Skipper style: the stretch the opening (or ending) of this episode shares with another episode of the
        same season, 15 to 200 s long, is the intro (or the credits)."""
        added = False
        duration = media.get('duration_s')
        for seg_kind, kind in (('intro', 'head'), ('credits', 'tail')):
            if found.get(seg_kind):
                continue
            others = self.db.other_episodes(key, season, episode, kind)
            if kind == 'head':
                values, first = self._head(key, season, episode, open_file)
            else:
                values, first = self._tail(key, season, episode, open_file, duration)
            if not values:
                continue
            best = None
            for _ep, fp, _first, _dur in others:
                mt = self.lib.match(fp, values)
                if mt.found and SHARED_MIN_S <= mt.seconds <= SHARED_MAX_S and (best is None or mt.seconds > best.seconds):
                    best = mt
            if best:
                end = first + best.b_end_s
                if seg_kind == 'credits' and duration and end >= duration - 3.0:
                    end = None
                seg = {'start': first + best.b_start_s, 'end': end, 'source': 'crossmatch',
                       'score': min(1.0, best.score / 700.0)}
                found[seg_kind] = [seg]
                self._store(key, season, episode, seg_kind, seg)
                added = True
        return added
