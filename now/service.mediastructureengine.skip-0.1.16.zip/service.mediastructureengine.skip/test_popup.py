# SPDX-License-Identifier: GPL-2.0-or-later
"""Settings > "Show a test popup": shows the skip button in the chosen style for each kind of segment (5 s each)."""
import sys

import xbmc
import xbmcaddon

import overlay


def show_db():
    """Settings > "Show what fingerprint.db holds": a text viewer with every show, its episodes and found segments."""
    import os
    import sqlite3
    import time
    import xbmcgui
    import xbmcvfs
    addon = xbmcaddon.Addon()
    path = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'fingerprint.db')
    if not os.path.exists(path):
        xbmcgui.Dialog().ok('fingerprint.db', 'No fingerprint.db yet: nothing has been learned.')
        return
    con = sqlite3.connect('file:%s?mode=ro' % path, uri=True)
    try:
        q = lambda sql, a=(): con.execute(sql, a).fetchall()
        shows = q('SELECT show, title, last_played FROM shows ORDER BY last_played DESC')
        known = {s[0] for s in shows}
        for (s,) in q('SELECT DISTINCT show FROM episodes UNION SELECT DISTINCT show FROM results'):
            if s not in known:
                shows.append((s, '', 0))
        lines = ['[B]fingerprint.db: %.1f MB[/B]' % (os.path.getsize(path) / 1e6),
                 '%d shows, %d episode fingerprints, %d themes, %d results' % (
                     len(shows), q('SELECT COUNT(*) FROM episodes')[0][0], q('SELECT COUNT(*) FROM themes')[0][0],
                     q('SELECT COUNT(*) FROM results')[0][0]), '']
        for show, title, played in shows:
            when = time.strftime('%Y-%m-%d', time.localtime(played)) if played else 'never'
            lines.append('[B]%s[/B]  (id %s, last played %s)' % (title or show, show, when))
            eps = {}
            for s, e, kind in q('SELECT season, episode, kind FROM episodes WHERE show=? ORDER BY season, episode',
                                (show,)):
                eps.setdefault((s, e), {'kinds': [], 'seg': []})['kinds'].append(kind)
            for s, e, seg, src, a, b, score in q(
                    'SELECT season, episode, segment, source, start_s, end_s, score FROM results WHERE show=? '
                    'ORDER BY season, episode, segment', (show,)):
                eps.setdefault((s, e), {'kinds': [], 'seg': []})['seg'].append(
                    '%s %s-%s (%s)' % (seg, '%.0fs' % a if a is not None else '?', '%.0fs' % b if b is not None else 'end', src))
            for (s, e), d in sorted(eps.items(), key=lambda x: (x[0][0] or 0, x[0][1] or 0)):
                lines.append('    S%02dE%02d  fingerprints: %s  |  %s' % (
                    s or 0, e or 0, ', '.join(d['kinds']) or '-', '; '.join(d['seg']) or 'no segments'))
            lines.append('')
        themes = q('SELECT key, seconds FROM themes ORDER BY key')
        if themes:
            lines.append('[B]Themes (%d)[/B]' % len(themes))
            lines.extend('    %s  %.0fs' % (k, s or 0) for k, s in themes)
        xbmcgui.Dialog().textviewer('MSE Skip: fingerprint.db', '\n'.join(lines))
    finally:
        con.close()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'db':
        return show_db()
    addon = xbmcaddon.Addon()
    style = 'card' if addon.getSetting('button_style') == '1' else 'pill'
    xbmc.executebuiltin('Notification(MSE Skip, %s, 2500)' % ('Card' if style == 'card' else 'Pill'))
    monitor = xbmc.Monitor()
    for kind in ('intro', 'recap', 'preview', 'credits'):
        if monitor.abortRequested():
            break
        overlay.show_skip_overlay(monitor=monitor, segment_type=kind, style=style, test=True)


if __name__ == '__main__':
    main()
