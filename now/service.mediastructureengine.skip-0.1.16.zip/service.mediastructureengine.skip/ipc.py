# SPDX-License-Identifier: GPL-2.0-or-later
"""How other add-ons ask this one for the segments of an episode.

Request: JSON-RPC NotifyAll with sender SENDER, message "Resolve" and data
  {"tmdb_id","imdb_id","tvdb_id","season","episode","title","duration_s","mode","buttons"}
mode "api": the online databases only (no file needed, e.g. while scraping); mode "full": also the sound of the file that
is playing now (AnimeThemes, chapters, other episodes).
Answer: the Home window property "mse_skip.result.<key>" holds JSON {"status": "pending"|"done", "segments":
{"intro": [{"start","end","source","score"}], ...}}; "pending" answers already hold what earlier sources found.
"buttons" (optional): the kinds ("intro","recap","preview","credits") the caller shows its own skip button for; without it
all kinds. This add-on shows its own button for the other kinds, or for all of them when the setting "use the player's
buttons" is off. Start and end offsets from the settings are already in the answered times.
"""
import json

SENDER = 'service.mediastructureengine.skip'
PREFIX = 'mse_skip.'
HOME = 10000


def request_key(media):
    parts = [media.get('tmdb_id') or '', media.get('tvdb_id') or '', media.get('imdb_id') or '',
             media.get('season') if media.get('season') is not None else '',
             media.get('episode') if media.get('episode') is not None else '']
    return '|'.join(str(p) for p in parts)


def result_property(key):
    return PREFIX + 'result.' + key


def encode(status, segments):
    return json.dumps({'status': status, 'segments': segments}, separators=(',', ':'))


def decode(text):
    try:
        data = json.loads(text) if text else None
    except ValueError:
        return None
    return data if isinstance(data, dict) and 'status' in data else None
