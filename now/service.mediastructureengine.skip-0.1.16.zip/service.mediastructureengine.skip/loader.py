# SPDX-License-Identifier: GPL-2.0-or-later
"""Finds and loads libmsefp for this Kodi process."""
import ctypes
import os
import platform
import re
import shutil

import msefp


def abi():
    """The library folder for this process (a 32-bit Kodi on a 64-bit device needs the 32-bit library)."""
    machine = platform.machine().lower()
    bits64 = ctypes.sizeof(ctypes.c_void_p) == 8
    if machine.startswith(('arm', 'aarch')):
        return 'arm64-v8a' if bits64 else 'armeabi-v7a'
    if machine in ('x86_64', 'amd64'):
        return 'x86_64' if bits64 else 'x86'
    return machine


def prune_other_abis(addon_path, keep=None):
    """The add-on zip carries the library of every supported device type; once this device's library has loaded, the
    other folders under lib/ are removed so they do not take space. Returns the names removed."""
    keep = keep or abi()
    root = os.path.join(addon_path, 'lib')
    removed = []
    try:
        names = os.listdir(root)
    except OSError:
        return removed
    for name in names:
        path = os.path.join(root, name)
        if name != keep and os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            removed.append(name)
    return removed


def load_library(addon_path, internal_dir=None):
    """Loads libmsefp. On Android a library cannot be loaded from the add-on folder (shared storage), so it is copied
    first to Kodi's internal folder for add-on libraries (special://xbmcaltbinaddons/), as Kodi does for its own.
    Returns (msefp.Library, path); raises RuntimeError when there is no library for this device."""
    src = os.path.join(addon_path, 'lib', abi(), 'libmsefp.so')
    if not os.path.exists(src):
        raise RuntimeError('this add-on has no libmsefp.so for %s' % abi())
    target = internal_dir
    if target is None:
        try:
            import xbmcvfs
            target = xbmcvfs.translatePath('special://xbmcaltbinaddons/')
        except ImportError:
            target = ''
        target = target or os.environ.get('KODI_BINADDON_PATH', '')
    if not target or target == '/' or not os.path.isabs(target):
        lib = msefp.Library(src)
        prune_other_abis(addon_path)
        return lib, src
    os.makedirs(target, exist_ok=True)
    st = os.stat(src)
    dst = os.path.join(target, 'libmsefp-%d-%d.so' % (st.st_size, int(st.st_mtime)))
    if not os.path.exists(dst):
        for old in os.listdir(target):
            if re.fullmatch(r'libmsefp-\d+-\d+\.so', old):
                try:
                    os.remove(os.path.join(target, old))
                except OSError:
                    pass
        shutil.copyfile(src, dst + '.tmp')
        os.replace(dst + '.tmp', dst)
    lib = msefp.Library(dst)
    prune_other_abis(addon_path)
    return lib, dst
