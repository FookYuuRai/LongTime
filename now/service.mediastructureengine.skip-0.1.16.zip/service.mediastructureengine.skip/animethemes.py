# SPDX-License-Identifier: GPL-2.0-or-later
"""AnimeThemes (api.animethemes.moe): find the opening and ending themes of an anime episode.

A show is mapped to its MyAnimeList / AniList id with the Kometa Anime-IDs list (by TVDB id and season, else IMDb or
TMDb id); the theme entries are filtered by their episode ranges, and each theme's audio (.ogg, from the video's
audio link) is fetched into memory by the caller.
"""
import json
import os
import re
import time
from urllib.parse import urlencode

import online

KOMETA = 'https://raw.githubusercontent.com/Kometa-Team/Anime-IDs/master/anime_ids.json'
ANIMETHEMES = 'https://api.animethemes.moe/anime'
REFRESH_DAYS = 7


def load_ids(cache_path, fetch=None):
    """The Kometa list (dict keyed by AniDB id), cached in cache_path and refreshed after REFRESH_DAYS days."""
    fresh = os.path.exists(cache_path) and time.time() - os.path.getmtime(cache_path) < REFRESH_DAYS * 86400
    if not fresh:
        data = (fetch or (lambda: online.get_bytes(KOMETA, 8 << 20, 60)))()
        if data:
            try:
                json.loads(data)
                tmp = cache_path + '.tmp'
                with open(tmp, 'wb') as f:
                    f.write(data)
                os.replace(tmp, cache_path)
            except ValueError:
                pass
    try:
        with open(cache_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def map_episode(ids_list, tvdb_id=None, imdb_id=None, tmdb_id=None, season=None, episode=None):
    """-> {'mal_id', 'anilist_id', 'episode'} for the entry of the list that holds this episode, or None.
    The entry's episode number is the show's own (the TVDB episode minus the entry's offset)."""
    season, episode = _int(season), _int(episode)
    if episode is None or episode <= 0:
        return None
    tvdb_id, tmdb_id = _int(tvdb_id), _int(tmdb_id)
    entries = [e for e in ids_list.values() if isinstance(e, dict)]
    if tvdb_id:
        cands = [e for e in entries if _int(e.get('tvdb_id')) == tvdb_id]
    elif imdb_id:
        cands = [e for e in entries if e.get('imdb_id') == imdb_id]
    elif tmdb_id:
        cands = [e for e in entries if _int(e.get('tmdb_show_id')) == tmdb_id]
    else:
        return None
    if not cands:
        return None
    # the entries of this season (-1: absolute numbering, only when the season is 1 or unknown)
    same = [e for e in cands if _int(e.get('tvdb_season')) == season]
    if not same and season in (None, 1):
        same = [e for e in cands if _int(e.get('tvdb_season')) == -1]
    if not same:
        return None
    # several entries can share a season (cours): the last one that starts before this episode
    same.sort(key=lambda e: _int(e.get('tvdb_epoffset')) or 0)
    pick = None
    for e in same:
        if (_int(e.get('tvdb_epoffset')) or 0) < episode:
            pick = e
    if pick is None or not (_int(pick.get('mal_id')) or _int(pick.get('anilist_id'))):
        return None
    return {'mal_id': _int(pick.get('mal_id')), 'anilist_id': _int(pick.get('anilist_id')),
            'episode': episode - (_int(pick.get('tvdb_epoffset')) or 0)}


def in_range(spec, ep):
    """Does an entry's episode text ("1-47", "2-3, 5-13", "1-", empty = all) hold the episode?"""
    if not spec or not str(spec).strip():
        return True
    for part in re.split(r'[,;]', str(spec)):
        part = part.strip()
        m = re.match(r'^(\d+)\s*-\s*(\d*)$', part)
        if m:
            lo = int(m.group(1))
            hi = int(m.group(2)) if m.group(2) else 10 ** 6
            if lo <= ep <= hi:
                return True
        elif part.isdigit() and int(part) == ep:
            return True
    return False


def themes_for(anime, ep, kind):
    """Audio links of the themes of one kind ('OP' or 'ED') whose entries hold the episode, best candidates first:
    [{'key', 'slug', 'version', 'episodes', 'link'}]. Themes without audio are left out."""
    out, seen = [], set()
    for th in (anime or {}).get('animethemes', []) or []:
        if th.get('type') != kind:
            continue
        for en in th.get('animethemeentries', []) or []:
            if not in_range(en.get('episodes'), ep):
                continue
            for v in en.get('videos', []) or []:
                a = v.get('audio') or {}
                if a.get('link'):
                    base = a.get('basename') or a['link']
                    if base not in seen:
                        seen.add(base)
                        out.append({'key': 'at:' + base, 'slug': th.get('slug'), 'version': en.get('version'),
                                    'episodes': en.get('episodes'), 'link': a['link']})
                    break
    return out


def fetch_anime(mal_id=None, anilist_id=None):
    """The anime with its themes, entries, videos and audio: dict, {} when AnimeThemes has none."""
    site, ext = ('MyAnimeList', mal_id) if mal_id else ('AniList', anilist_id)
    if not ext:
        return {}
    q = urlencode({'filter[has]': 'resources', 'filter[site]': site, 'filter[external_id]': ext,
                   'include': 'animethemes.animethemeentries.videos.audio'})
    data = online.get_json(ANIMETHEMES + '?' + q, 'animethemes', timeout=15)
    lst = (data or {}).get('anime') or []
    return lst[0] if lst else {}
