# SPDX-License-Identifier: GPL-2.0-or-later
"""Runs the resolutions one at a time (production limit: one video at a time) and keeps their answers.

Both this add-on's own playback and other add-ons' requests (ipc.py) go through request(); a second request for an
episode that is being resolved, or already was, shares that answer.
"""
import queue
import threading

import ipc


class Coordinator:
    def __init__(self, resolver, publish, log=lambda m: None, cancelled=lambda: False, adjust=None):
        self.resolver, self.publish, self.log, self.cancelled = resolver, publish, log, cancelled
        self.adjust = adjust or (lambda segments: segments)   # start/end offsets, applied each time an answer is read
        self.results = {}                 # key -> {'status', 'segments' (as found, no offsets), 'mode'}
        self.claimed = []                 # episodes another add-on asked for: it skips by itself
        self._queue = queue.Queue()
        self._lock = threading.Lock()
        self._thread = None
        self._stop = False
        self.current_key = None

    def start(self):
        self._thread = threading.Thread(target=self._run, name='mse-skip-resolver', daemon=True)
        self._thread.start()

    def stop(self):
        self._stop = True
        self._queue.put(None)

    def reset_playback(self):
        """A new file starts: answers for full resolutions hold for the episode, so they stay; claims end."""
        self.claimed.clear()

    def request(self, media, mode, open_file=None, external=False):
        key = ipc.request_key(media)
        if not key.strip('|'):
            return key
        with self._lock:
            if external:
                self.claimed.append(media)
            have = self.results.get(key)
            if have and (have['status'] == 'done' and (have['mode'] == 'full' or mode == 'api')):
                self.publish(key, have['status'], self.adjust(have['segments']))
                return key
            if have and have['status'] == 'pending' and (have['mode'] == 'full' or mode == 'api'):
                return key                # already on its way
            self.results[key] = {'status': 'pending', 'segments': (have or {}).get('segments', {}), 'mode': mode}
        self.publish(key, 'pending', self.adjust(self.results[key]['segments']))
        self._queue.put((key, media, mode, open_file))
        return key

    def is_claimed(self, media, kind=None):
        """Did another add-on ask for this episode (same season and episode, and a shared show id) and does it show a
        button for this kind of segment? (Its request may list the kinds it shows in "buttons"; without the list: all.)"""
        for other in self.claimed:
            if kind and isinstance(other.get('buttons'), list) and kind not in other['buttons']:
                continue
            if str(other.get('season')) != str(media.get('season')) or str(other.get('episode')) != str(media.get('episode')):
                continue
            for name in ('tmdb_id', 'tvdb_id', 'imdb_id'):
                if other.get(name) and str(other.get(name)) == str(media.get(name)):
                    return True
        return False

    def segments(self, key):
        # offsets are applied here, on every read, so a changed setting also works for episodes already resolved
        return self.adjust((self.results.get(key) or {}).get('segments') or {})

    def _run(self):
        while not self._stop:
            item = self._queue.get()
            if item is None:
                break
            key, media, mode, open_file = item
            self.current_key = key

            def update(found, final=False, key=key, mode=mode):
                self.results[key] = {'status': 'pending', 'segments': found, 'mode': mode}
                self.publish(key, 'pending', self.adjust(found))

            try:
                found = self.resolver.resolve(media, open_file, update, apis_only=(mode == 'api'))
            except Exception as exc:
                self.log('resolve error: %r' % (exc,))
                found = self.results.get(key, {}).get('segments', {})
            if mode == 'full' and self.cancelled():
                self.results.pop(key, None)       # playback ended mid-way: the answer is incomplete, ask again later
            else:
                self.results[key] = {'status': 'done', 'segments': found, 'mode': mode}
            self.publish(key, 'done', self.adjust(found))
            self.current_key = None
